function out = ucc(c,h,gam,psi)

if psi~=0
    out =     (c.^(1-gam).*(1-h).^gam).^psi.*(gam-1).*(1+(gam-1)*psi)./c.^2;
else
    out =     -(1-gam).*c.^-2;
end