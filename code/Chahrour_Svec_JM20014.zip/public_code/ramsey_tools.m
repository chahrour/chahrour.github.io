%RAMSEY_TOOLS - Compute the policy tools that deliver the ramsey
%allocations.


function [OM,TAU,BB,RF,OM0,TAU0,DR0,k1] = ramsey_tools(coeffs,pg,ggrid,bet,alph,del,gam,thet,psi,xgrid,xxgrid,k_,jinit,om0,Q)


kgrid = xgrid{1};
mgrid = xgrid{2};
kkgrid = xxgrid(1,:);
mmgrid = xxgrid(2,:);

ng = length(pg);
nk = length(kgrid);
nm = length(mgrid);
nknm = nk*nm;

xi = coeffs(end-2);
c0 = coeffs(end-1);
h0 = coeffs(end);

Gpol = reshape(coeffs(0*ng*nk*nm*ng+1:1*ng*nk*nm*ng), [nm*nk,ng,ng]);
hpol = reshape(coeffs(1*ng*nk*nm*ng+1:2*ng*nk*nm*ng), [nm*nk,ng,ng]);
Vpol = reshape(coeffs(2*ng*nk*nm*ng+1:3*ng*nk*nm*ng), [nm*nk,ng,ng]);
Epol = reshape(coeffs(3*ng*nk*nm*ng+1:4*ng*nk*nm*ng), [nm*nk,ng,ng]);
Hpol = reshape(coeffs(4*ng*nk*nm*ng+1:4*ng*nk*nm*ng+nk*nm*ng), [nm*nk,ng]);
EPSpol = zeros(size(hpol));
DRpol  = zeros(size(hpol));

%Next period things
hprime = zeros(ng,nknm,ng);
cprime = zeros(ng,nknm,ng);
Gprime = zeros(ng,nknm,ng);
mprime = zeros(ng,nknm,ng);
vprime = zeros(ng,nknm,ng);
Hprime = zeros(ng,nknm);
Eprime = zeros(ng,nknm,ng);
EPSprime = zeros(ng,nknm,ng);

%This period things
h   = zeros(ng,nknm);
E   = zeros(ng,nknm);
vg  = zeros(ng,nknm);
GAM = zeros(ng,nknm);
OM  = zeros(ng,nknm,ng);
TAU = zeros(ng,nknm,ng);
BB  = zeros(ng,nknm,ng);
RF  = zeros(ng,nknm,ng);
EPS = zeros(ng,nknm,ng);
DR  = zeros(ng,nknm,ng);

%TIME ZERO VALUES
mu1 = zeros(ng,1); h1 = zeros(ng,1); c1 = zeros(ng,1); v1 = zeros(ng,1); enpv = zeros(ng,1);
k =  k_^alph*h0^(1-alph) + (1-del)*k_  - c0 - ggrid(jinit)'; %RC Constraint
for jj = 1:ng
   [h1(jj),Q1] = ndim_simplex_eval(xgrid,[k;0],hpol(:,jj,jinit));
   v1(jj)   = Q1*Vpol(:,jj,jinit);
   enpv(jj) = Q1*Epol(:,jj,jinit); %Assuming GAM_ starts at 0  
   c1(jj)   = cfunc(k,h1(jj),alph,xi,psi,0,gam);
   mu1(jj)  = mufunc(c1(jj),h1(jj),xi,psi,0,gam); 
end

m1= mfunc(v1,repmat(pg(jinit,:),[ng,1]),thet); 
rk0 = 1+(1-om0)*(alph*k_^(alph-1)*h0^(1-alph)  - del);                       %Definition
mu0 =  bet*pg(jinit,:)*(m1.*mu1.*(alph*k^(alph-1).*h1.^(1-alph) + 1 - del)); %FOC k0


TAU0 = 1 + ul(c0,h0,gam,psi)./(uc(c0,h0,gam,psi).*(1-alph)*(k_./h0).^alph);
OM0 = (pg(jinit,:)*(m1.*uc(c1,h1,gam,psi)./uc(repmat_row(c0,ng),repmat_row(h0,ng),gam,psi).*(alph*(k./h1).^(alph-1) + 1 - del)) - 1/bet)./...
      (pg(jinit,:)*(m1.*uc(c1,h1,gam,psi)./uc(repmat_row(c0,ng),repmat_row(h0,ng),gam,psi).*(alph*(k./h1).^(alph-1) - del)));

k1 = k;

for ll = 1:ng
    
    %Time T values at the grid points
    for jj = 1:ng
        h(jj,:)   = Q*hpol(:,jj,ll);
        GAM(jj,:) = Q*Gpol(:,jj,ll);
        vg(jj,:)  = Q*Vpol(:,jj,ll);
        E(jj,:)   = Q*Epol(:,jj,ll);
    end
    H = (Q*Hpol(:,ll))';  
    
    %Use the C and H equations to get C and K next period
    repk_ = repmat_row(kkgrid,ng);
    c = cfunc(repk_,h,alph,xi,psi,GAM,gam);
    k = repk_.^alph.*h.^(1-alph) + (1-del)*repk_ - c - repmat_col(ggrid',nknm);
    fl = (1-alph)*(repk_./h).^alph;

    %Next-period values at the grid point advanced according to the policy
    %functions
    for jj = 1:ng
        [~,Q1] = ndim_simplex_eval(xgrid,[k(jj,:);GAM(jj,:)],hpol(:,1,jj));
        for mm = 1:ng
            hprime(mm,:,jj) = Q1*hpol(:,mm,jj);
            Gprime(mm,:,jj) = Q1*Gpol(:,mm,jj);
            vprime(mm,:,jj) = Q1*Vpol(:,mm,jj);
            Eprime(mm,:,jj) = Q1*Epol(:,mm,jj);
            cprime(mm,:,jj) = cfunc(k(jj,:),hprime(mm,:,jj),alph,xi,psi,Gprime(mm,:,jj),gam);
        end
        mprime(:,:,jj) = mfunc(vprime(:,:,jj), repmat_row(pg(jj,:),ng),thet);
        Hprime(jj,:) = Q1*Hpol(:,jj);  %Does not depend on lagged state
    end
    
  
   %PER-PERIOD DISTORTION
   for jj = 1:ng
       EPS(jj,:,ll) = pg(jj,:)*(mprime(:,:,jj).*log(mprime(:,:,jj)));
       EPSpol(:,jj,ll) = ndim_simplex(xgrid,xxgrid,EPS(jj,:,ll));
   end
   
   %EX ANTE TAX RATE
   for jj = 1:ng
       
       fkprime = alph*(repmat_row(k,ng)./hprime(:,:,jj)).^(alph-1);
       OM(jj,:,ll) = (pg(jj,:)*(mprime(:,:,jj).*uc(cprime(:,:,jj),hprime(:,:,jj),gam,psi)./uc(repmat_row(c(jj,:),ng),repmat_row(h(jj,:),ng),gam,psi).*(fkprime + 1 - del)) - 1/bet)./...
                     (pg(jj,:)*(mprime(:,:,jj).*uc(cprime(:,:,jj),hprime(:,:,jj),gam,psi)./uc(repmat_row(c(jj,:),ng),repmat_row(h(jj,:),ng),gam,psi).*(fkprime - del)));
   end
   
   %LABOR TAX
   TAU(:,:,ll)  = 1 + ul(c,h,gam,psi)./(uc(c,h,gam,psi).*fl);                                       %First equation in section 3.1.1
   
   %BONDS
   for jj = 1:ng
      BB(jj,:,ll) = (bet*pg(jj,:)*(mprime(:,:,jj).*Eprime(:,:,jj)))./uc(c(jj,:),h(jj,:),gam,psi) - k(jj,:); %Equation 15 in draft
   end
   
   %RISK FREE RETURN
   for jj = 1:ng
        RF(jj,:,ll) = (bet*(pg(jj,:)*(mprime(:,:,jj).*uc(cprime(:,:,jj),hprime(:,:,jj),gam,psi)))./uc(c(jj,:),h(jj,:),gam,psi)).^-1 -1;
   end

end

EPStmp = zeros(ng,nm*nk);
%Use the EPSpol to compute PV distortion
for ll = 1:ng
    %Time T values at the grid points
    for jj = 1:ng
        h(jj,:)   = Q*hpol(:,jj,ll);
        GAM(jj,:) = Q*Gpol(:,jj,ll);
        vg(jj,:)  = Q*Vpol(:,jj,ll);
        E(jj,:)   = Q*Epol(:,jj,ll);
        EPStmp(jj,:) = Q*EPSpol(:,jj,ll);
    end

    H = (Q*Hpol(:,ll))';  
    
    %Use the C and H equations to get C and K next period
    repk_ = repmat_row(kkgrid,ng);
    c = cfunc(repk_,h,alph,xi,psi,GAM,gam);
    k = repk_.^alph.*h.^(1-alph) + (1-del)*repk_ - c - repmat_col(ggrid',nknm);
    fl = (1-alph)*(repk_./h).^alph;

    
    %Next-period values at the grid point advanced according to the policy
    %functions
    for jj = 1:ng
        [~,Q1] = ndim_simplex_eval(xgrid,[k(jj,:);GAM(jj,:)],hpol(:,1,jj));
        for mm = 1:ng
            hprime(mm,:,jj) = Q1*hpol(:,mm,jj);
            Gprime(mm,:,jj) = Q1*Gpol(:,mm,jj);
            vprime(mm,:,jj) = Q1*Vpol(:,mm,jj);
            Eprime(mm,:,jj) = Q1*Epol(:,mm,jj);
            cprime(mm,:,jj) = cfunc(k(jj,:),hprime(mm,:,jj),alph,xi,psi,Gprime(mm,:,jj),gam);
            EPSprime(mm,:,jj) = Q1*EPSpol(:,mm,jj);
        end
        mprime(:,:,jj) = mfunc(vprime(:,:,jj), repmat_row(pg(jj,:),ng),thet);
        Hprime(jj,:) = Q1*Hpol(:,jj);  %Does not depend on lagged state
    end
    
    
    for jj = 1:ng
        DR(jj,:,ll) =  EPStmp(jj,:) + bet*pg(jj,:)*(mprime(:,:,jj).*EPSprime(:,:,jj));
        DRpol(:,jj,ll) = ndim_simplex(xgrid,xxgrid,DR(jj,:,ll));
    end
end

%Measuring the total distortion.
EPS0 = pg(jinit,:)*(m1.*log(m1));
DR1 = zeros(ng,1);
for jj = 1:ng
   DR1(jj) = ndim_simplex_eval(xgrid,[k1;0],DRpol(:,jj,jinit)); 
end
DR0 =  EPS0 + bet*pg(jinit,:)*(m1.*DR1);