%*************************************************************************
% MAIN_PROG - Solves the robust-control model Chahrour and Svec (2014)
% "Optimal Capital Taxation and Consumer Uncertainty" Jorunal of Macroeconomics
% using a collocation approach and linear finite element functions over a simplex.
%
% For details, see file Contents.text included in this directory.
%%*************************************************************************


%Code for making tables automatically.
addpath(genpath([cd,'/latex']))

%Parameters for period 0 things
b_ = 1;
k_ = 1.05;
om0 = .271;
rb0 = .2;
jinit = 2;

%Parameters from param.m
param= parameters;
xi   = param.xi;
bet  = param.bet;
alph = param.alph;
del  = param.del;
GAM  = param.GAM;
gam  = param.gam;
thet = param.thet;
psi  = param.psi;
rho  = param.rho;
sigg = param.sigg;
dir  = param.dir;              %Where figures will be saved.
scale_thet = param.scale_thet;


%Vector of thetas to solve
nthet = 25;
thet_vec = [100000, 10000, 1000, exp(linspace(log(150),log(10),nthet-3))];
thet_vec = scale_thet*thet_vec;


%Simuation parameters
nper  = 500;   %Period in simuations
ndrop = 100;   %Periods dropped in each simulation
nsim  = 100;   %Number of simuations

%Impulse response parameters
nburn = 400;   %Burn in for impulse responses.
nperiods = 12; %Period in impulse response


%Solve linear, no Robust Control model
solve_linear     

%Initial policy functions
use_saved = 0;   %use_saved = 1, use parameters save previously; use_saved = 0, use linearized coeffs

%**************************************************************************
%SET EXOGENOUS PROCESS, GRIDS, AND INITIAL POLICY FUNCTION
%**************************************************************************
nk = 11;     %Points in K grid
nm = 11;    %Points in Lagrange mult grid
ng = 3;     %Points in discrete government expenditure grid

[ggrid,pg] = AR1_rouwen(ng,param.rho,0,sigg); %AR1 process in logs
kgrid = linspace(-.5,.2,nk); %Capital grid in percent deviations 
mgrid = linspace(-.4,.4,nm); %Lagrange grid in level deviations

kgrid = 1.5.*exp(kgrid);  %Steady-state capital roughly 1.5
ggrid = gss.*exp(ggrid);  %Steady-state g given by gss
[kkgrid,mmgrid] = ndgrid(kgrid,mgrid);  %Two-dimensional grid

%Combine grids for use in ndim_simplex function
xgrid = cell(1,2);
xgrid{1} = kgrid;
xgrid{2} = mgrid;
xxgrid = [kkgrid(:),mmgrid(:)]';

%Initialize policy functions
kpol_gr = zeros(nm,nk,ng); 
hpol_gr = zeros(nm,nk,ng); 
cpol_gr = zeros(nm,nk,ng);
vpol_gr = zeros(nm,nk,ng);
epol_gr = zeros(nm,nk,ng);
Hpol_gr = zeros(nm,nk,ng);
for kk = 1:nk
    for mm = 1:nm
        for jj = 1:ng
            kpol_gr(mm,kk,jj) = kp_init(ggrid(jj), kgrid(kk), mgrid(mm));
            hpol_gr(mm,kk,jj) = hp_init(ggrid(jj), kgrid(kk), mgrid(mm));
            vpol_gr(mm,kk,jj) = vp_init(ggrid(jj), kgrid(kk), mgrid(mm));
            epol_gr(mm,kk,jj) = ep_init(ggrid(jj), kgrid(kk), mgrid(mm));
            Hpol_gr(mm,kk,jj) = Hp_init(ggrid(jj), kgrid(kk), mgrid(mm));
        end
    end
end


%Initial Policy Function (based on initial guess for hours and gamma
%policy function)
hpol_init = zeros(nk*nm,ng,ng); 
Gpol_init = zeros(nk*nm,ng,ng);  
vpol_init = zeros(nk*nm,ng,ng);  
epol_init = zeros(nk*nm,ng,ng); 
Hpol_init = zeros(nk*nm,ng); 
for jj = 1:ng
    for ll = 1:ng
        [Gpol_init(:,jj,ll),Q] = ndim_simplex(xgrid,xxgrid,0*mmgrid(:)');  %Guess constant gamma
        hpol_init(:,jj,ll) = ndim_simplex(xgrid,xxgrid,vec(hpol_gr(:,:,jj)));
        vpol_init(:,jj,ll) = ndim_simplex(xgrid,xxgrid,vec(vpol_gr(:,:,jj)));
        epol_init(:,jj,ll) = ndim_simplex(xgrid,xxgrid,vec(epol_gr(:,:,jj)));   
    end
    Hpol_init(:,jj) = ndim_simplex(xgrid,xxgrid,vec(Hpol_gr(:,:,jj)));
end


DR_store   = zeros(1,nthet);
TAX_store  = zeros(3,4,nthet);
TAUL_store = zeros(1,nthet);
ETA_store  = zeros(1,nthet);
TAUL0_store= zeros(1,nthet);
OM0_store  = zeros(1,nthet);
irdata     = zeros(nperiods,6,nthet);
for tt = 1:nthet
    if tt == 1
        use_saved = 0;
    else
        use_saved = 1;
    end
    
    thet = thet_vec(tt);
    
    %SOLVE AND SIMULATE
    solve_simulate
    
    %STORE VALUES FOR TABLE
    DR_store(tt) = DR0;
    TAX_store(1,:,tt) = ltax_table;
    TAX_store(2,:,tt) = omtax_table;
    TAX_store(3,:,tt) = eta_table;
    TAX_store(4,:,tt) = tauk_table;
    
    TAUL_store(tt) = TAUL_abs;
    ETA_store(tt) = ETA_abs;
    
    TAUL0_store(tt) = TAU0;
    OM0_store(tt) = OM0;
    
    irdata(:,:,tt) = irdat;
    
end

eval(['save ' param.diro 'Table_Data DR_store TAX_store thet_vec TAUL_store ETA_store irdata TAUL0_store OM0_store']);


%*************************************************************************
% PLOT FIGURES
%*************************************************************************
plot_policy(kgrid,mgrid,hpol_init,hpol,'Hours');
plot_policy(kgrid,mgrid,Gpol_init,Gpol,'\Gamma');
plot_policy(kgrid,mgrid,vpol_init,vpol,'Vg');
plot_policy(kgrid,mgrid,epol_init,epol,'Eg');
plot_policy(kgrid,mgrid,0*epol_init,BBpol,'Bonds');
plot_policy(kgrid,mgrid,repmat(Hpol_init,[1,1,ng]),repmat(Hpol,[1,1,ng]),'H');


plot_policy(kgrid,mgrid,NaN+Gpol_init,OMpol, 'Ex Ante Tax');
plot_policy(kgrid,mgrid,NaN+Gpol_init,TAUpol, 'Labor Tax');
    
    