% MODEL_SS - Return the steady state of the model computed analytically
%
% usage:
% 
% [ss, parameters] =model_ss(param)


function [ss,param] = model_ss(param)


bet = param.bet;  %Never call anything beta...it's a matlab function
gam = param.gam;  %Average gross growth rate of TFP
del = param.del;  %Depreciation Rate
alph = param.alph;%Capital Share
xi = param.xi;
GAM = param.GAM;
psi = param.psi;
g = param.g;

options = optimset('fsolve');
options = optimset(options, 'display', 'on');

%Use closed form expressions for the ss values.
kh = ((1/bet -1 + del)/alph)^(1/(alph-1));

obj = @(x) [ul(x(1),x(2),gam,psi)*(1-GAM) + xi*(ucl(x(1),x(2),gam,psi)*x(1) + ul(x(1),x(2),gam,psi) + ull(x(1),x(2),gam,psi)*x(2)) - x(3)*(1-alph)*(kh)^alph;
            uc(x(1),x(2),gam,psi)*(1-GAM) + xi*(ucc(x(1),x(2),gam,psi)*x(1) + uc(x(1),x(2),gam,psi) + ucl(x(1),x(2),gam,psi)*x(2)) + x(3);
            x(1) + g + kh*x(2) - (kh*x(2))^alph*x(2)^(1-alph) - (1-del)*kh*x(2)];
ck_init = [.5 .5 1];

[a,b]  = fsolve(obj, ck_init, options);
disp('Model SS')
disp([num2str(a), ' resid: ', num2str(b')]);
c = a(1);
h = a(2);
mu = a(3);
k = kh*h;

%Put the ss values in a vector consistent with X and Y vectors in model.m
v = 1/(1-bet)*u(c,h,gam,psi);
e = 1/(1-bet)*(uc(c,h,gam,psi)*c + ul(c,h,gam,psi)*h);
H = v + xi*e;

bb = bet*e/uc(c,h,gam,psi) - k;

xx = [g k 0];
yy  = [c h v e H mu bb];

ss = [yy xx];
