% PARAMETETRS - This function returns a parameter structure to use in the model solution.


function param = parameters()


param.bet   = 0.98;   %Discount factor
param.gam   = 0.75;   %Weight on leisure in utility function
param.del   = 0.08;   %Depreciation Rate
param.alph  = 0.34;   %Capital Share
param.GAM   = 0.0;    %Steady-state lag. multiplier
param.g     = 0.07;   %Average level of G (absolute, not percentange of GDP)
param.rho   = 0.89;   %Peristance of G shocks (0 for no peristence, 0.89 for high persistance.
param.sigG  = 0.153522062157279;                    %Variance of government spending, total.
param.sigg  = sqrt(param.sigG^2*(1-param.rho^2));   %Variance of log of shock to G shocks 
param.psi   = 0;      %Risk aversion (0 = log utility, -5 is high risk aversion)
param.thet  = 100000; %Robustness parameter

param.xi    = .20;     %Starting guess for xi
param.scale_thet = 1;  %When risk aversion is 0, set this to 1.  When = -5, set this to 3.  This keeps the implied distortion roughly constant.

param.diro = 'Figures_AR_baseline/';    %Directory to save .mat files with model solutions.
param.dir  = '';                        %Directory to save figures.

