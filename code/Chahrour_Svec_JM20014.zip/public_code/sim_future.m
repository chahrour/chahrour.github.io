%SIM_FUTURE - Simulate the economy given with random G realizations.


function [kt,GAMt,ct,ht,OMt,TAUt,BBt,RFt,ETAt,Gt,dent,numt,rkt,TAUKt,wt] = sim_future(nper,Gpol,hpol,OMpol,TAUpol,BBpol,RFpol,pg,ggrid,bet,alph,del,gam,thet,psi,xgrid,c0,h0,k1,OM0,TAU0,jinit,xi)

ct   = zeros(1,nper);
ht   = zeros(1,nper);
kt   = zeros(1,nper);
OMt  = zeros(1,nper);
TAUt = zeros(1,nper);
GAMt = zeros(1,nper);
BBt  = zeros(1,nper);
RFt  = zeros(1,nper);
Gt   = zeros(1,nper);
mpk  = zeros(1,nper);
mpl  = zeros(1,nper);
ETAt = zeros(1,nper);
dent = zeros(1,nper);
numt = zeros(1,nper);
rkt  = zeros(1,nper);
TAUKt= zeros(1,nper);

jj = jinit;
ht(1) = h0;
ct(1) = c0;
OMt(1) = OM0;
TAUt(1) = TAU0;
kt(1) = k1;
GAMt(1) = 0;
Gt(1) = ggrid(jinit);
for tt = 2:nper
    
    ll = jj;                   %Store lagged state
    jj = rand_bin(pg(jj,:),1); %Update current state

    Gt(tt) = ggrid(jj);
    
    %Store current per values
    [ht(tt),Q]  = ndim_simplex_eval(xgrid,[kt(tt-1);GAMt(tt-1)],hpol(:,jj,ll));
    GAMt(tt)= Q*Gpol(:,jj,ll);
    BBt(tt) = Q*BBpol(:,jj,ll);
    RFt(tt) = Q*RFpol(:,jj,ll);
    OMt(tt) = Q*OMpol(:,jj,ll);
    TAUt(tt)= Q*TAUpol(:,jj,ll);
    
    mpk(tt) = alph    *(kt(tt-1)/ht(tt))^(alph-1);
    mpl(tt) = (1-alph)*(kt(tt-1)/ht(tt))^alph;
    ct(tt) = cfunc(kt(tt-1),ht(tt),alph,xi,psi,GAMt(tt-1),gam);
    
    kt(tt) = kt(tt-1)^alph.*ht(tt).^(1-alph) + (1-del)*kt(tt-1) - ct(tt) - ggrid(jj);
    
    %Compute the private assets tax using current and lagged values
    numt(tt)=  (Gt(tt) - TAUt(tt)*mpl(tt)*ht(tt) - BBt(tt) + (1+RFt(tt-1))*BBt(tt-1));
    dent(tt)= (mpk(tt) - del)*kt(tt) + RFt(tt-1)*BBt(tt-1);
    rkt(tt) = (mpk(tt) - del);
    ETAt(tt) = numt(tt)/dent(tt);

    
    %Compute the capital tax rate assuming risk-free bond (no tax on
    %bonds.)
    TAUKt(tt) = numt(tt)/((mpk(tt) - del)*kt(tt));
end
wt = mpl;