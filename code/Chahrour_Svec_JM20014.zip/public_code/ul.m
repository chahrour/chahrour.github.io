function out = ul(c,h,gam,psi)

if psi~=0
    out = (c.^(1-gam).*(1-h).^gam).^psi.*gam./(h-1);
else
    out =     gam.*(h-1).^-1;
end