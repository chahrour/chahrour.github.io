% MODEL_LINEAR - Linearized version of the simple RBC model example from 
% EC860.
%
% usage:
%
% [fy, fx, fyp, fxp] = model_linear(param, xidx, yidx, xpidx, ypidx)
%
% where
%
% param = a parameters object, created in parmeters.m
%
% NOTES: This program, which generates the model matrices in cannonical form,
%        requires the MATLAB symbolic toolbox! The algorithms used to solve 
%        the model, however, are numerical, and require no additonal m-files
%        beyond those that appear in this directory.
%
% Code by Ryan Chahrour, Boston College, 2012
 

function [fyn, fxn, fypn, fxpn ,ss] = model(param)

%Steady State

[ss param] = model_ss(param);
param
ss
%Declare parameters
bet = param.bet;  %Never call anything beta...it's a matlab function
gam = param.gam;  %Average gross growth rate of TFP
del = param.del;  %Depreciation Rate
alph= param.alph;%Capital Share
xi  = param.xi;
GAM = param.GAM;
psi = param.psi;
rho = param.rho;
gbar= ss(8);


%Declare Needed Symbols
syms K K_p A A_p G G_p
syms C C_p H H_p W W_p R R_p I I_p  V V_p E E_p  HH HH_p GAM GAM_p MU MU_p BB BB_p

%Declare X and Y vectors
X  = [G   K   GAM];
XP = [G_p K_p GAM_p];

Y  = [C   H    V   E   HH   MU   BB];
YP = [C_p H_p  V_p E_p HH_p MU_p BB_p] ;

% load nlss
% ss = nlss

%Model Equations
f(1) = ul(C,H,gam,psi)*(1-GAM) + xi*(ucl(C,H,gam,psi)*C + ul(C,H,gam,psi) + ull(C,H,gam,psi)*H) - MU*(1-alph)*(K/H)^alph;
f(2) = uc(C,H,gam,psi)*(1-GAM) + xi*(ucc(C,H,gam,psi)*C + uc(C,H,gam,psi) + ucl(C,H,gam,psi)*H) + MU;
f(3) = MU - bet*MU_p*(alph*(K_p/H_p)^(alph-1)+1-del);
f(4) = C + G + K_p - K^alph*H^(1-alph) - (1-del)*K;
f(5) = log(G_p/gbar) - rho*log(G/gbar);
f(6) = V - u(C,H,gam,psi) - bet*V_p;
f(7) = E - uc(C,H,gam,psi)*C - ul(C,H,gam,psi)*H - bet*E_p;
f(8) = HH - u(C,H,gam,psi) - xi*(uc(C,H,gam,psi)*C +ul(C,H,gam,psi)*H) + GAM*V - GAM_p*(V - u(C,H,gam,psi)) -  bet*HH_p;
f(9) = GAM_p - .99999999*GAM;
f(10) = BB - bet*E_p/uc(C,H,gam,psi) + K;

%Check Computation of Steady-State Numerically
fnum = double(subs(f, [Y X YP XP], [ss, ss]));

if sum(abs(fnum))>10e-7
    display(['model ss warning:']);
    fnum
end

%Log-linear approx
log_var = [];%[X(1:end-1) Y XP(1:end-1) YP];
f = subs(f, log_var, exp(log_var)); 
   
%differentiate
fx = jacobian(f, X);
fy = jacobian(f,Y);
fxp = jacobian(f,XP);
fyp = jacobian(f,YP);

%Plug back into levels
fx =  subs(fx, log_var, log(log_var));
fy =  subs(fy, log_var, log(log_var));
fxp = subs(fxp, log_var, log(log_var));
fyp = subs(fyp, log_var, log(log_var));

%Numerical
fxn =  double(subs(fx, [Y X YP XP], [ss, ss]));
fyn =  double(subs(fy, [Y X YP XP], [ss, ss]));
fxpn = double(subs(fxp, [Y X YP XP], [ss, ss]));
fypn = double(subs(fyp, [Y X YP XP], [ss, ss]));
