function out = ull(c,h,gam,psi)

if psi~=0
    out = (c.^(1-gam).*(1-h).^gam).^psi.*gam*(-1+gam*psi)./((h-1).^2);
else
    out =     -gam*(h-1).^-2;
end