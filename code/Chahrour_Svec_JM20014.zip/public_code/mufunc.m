%CFUNC - Delivers C as a function of 


function out = mufunc(c,h,xi,psi,GAM,gam)

out = (c.^(1-gam).*(1-h).^gam).^psi.*(-1+gam).*(-1+h + GAM - h.*GAM + (-1 + h + gam)*xi*psi)./(c.*(h-1));
        
%Test FOC w/r to cg;
%uc(c,h,gam,psi) + xi*(ucc(c,h,gam,psi).*c +uc(c,h,gam,psi) + ucl(c,h,gam,psi).*h) + out - GAM.*uc(c,h,gam,psi)


