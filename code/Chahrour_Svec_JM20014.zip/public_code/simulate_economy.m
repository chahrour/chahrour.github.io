

%Simulate a bunch of times
c0 = coeffs_final(end-1);
h0 = coeffs_final(end);
kt = zeros(nsim,nper);
GAMt = zeros(nsim,nper);
ct   = zeros(nsim,nper);
ht   = zeros(nsim,nper);
OMt  = zeros(nsim,nper);
TAUt = zeros(nsim,nper);
BBt  = zeros(nsim,nper);
RFt  = zeros(nsim,nper);
ETAt = zeros(nsim,nper);
Gt   = zeros(nsim,nper);
DENt = zeros(nsim,nper);
rkt  = zeros(nsim,nper);
TAUKt = zeros(nsim,nper);

disp('SIMULATING ECONOMY'); 

ltax_table  = zeros(1,4,nsim);
omtax_table = zeros(1,4,nsim);
eta_table   = zeros(1,4,nsim);
tauk_table   = zeros(1,4,nsim);
for nn = 1:nsim
    [kt(nn,:),GAMt(nn,:),ct(nn,:),ht(nn,:),OMt(nn,:),TAUt(nn,:),BBt(nn,:), RFt(nn,:), ETAt(nn,:), Gt(nn,:), DENt(nn,:),~, rkt(nn,:), TAUKt(nn,:)] = sim_future(nper,Gpol,hpol,OMpol,TAUpol,BBpol,RFpol,pg,ggrid,bet,alph,del,gam,thet,psi,xgrid,c0,h0,k1,OM0,TAU0,jinit,xi);
    
    TAUtmp = TAUt(nn,ndrop:end)';
    Gtmp   = Gt  (nn,ndrop:end)';
    OMtmp  = OMt (nn,ndrop:end)';
    ETAtmp = ETAt(nn,ndrop:end)';
    TAUktmp = TAUKt(nn,ndrop:end)';
    
    ltax_table(1,1,nn) = 100*mean(TAUtmp);
    ltax_table(1,2,nn) = 100*std(TAUtmp);
    ltax_table(1,3,nn) = ar_coef(TAUtmp);
    ltax_table(1,4,nn) = corr(TAUtmp,Gtmp);
    
    omtax_table(1,1,nn) = 100*mean(OMtmp);
    omtax_table(1,2,nn) = 100*std(OMtmp);
    omtax_table(1,3,nn) = ar_coef(OMtmp);
    omtax_table(1,4,nn) = corr(OMtmp,Gtmp);
    
    
    eta_table(1,1,nn) = 100*mean(ETAtmp);
    eta_table(1,2,nn) = 100*std(ETAtmp);
    eta_table(1,3,nn) = ar_coef(ETAtmp);
    eta_table(1,4,nn) = corr(ETAtmp,Gtmp);
    
    tauk_table(1,1,nn) = 100*mean(TAUktmp);
    tauk_table(1,2,nn) = 100*std(TAUktmp);
    tauk_table(1,3,nn) = ar_coef(TAUktmp);
    tauk_table(1,4,nn) = corr(TAUktmp,Gtmp);
end
    

ltax_table  = mean(ltax_table,3)
omtax_table = mean(omtax_table,3)
eta_table   = mean(eta_table,3)
tauk_table  = mean(tauk_table,3)
%Histograms
% figure
% subplot(1,2,1);
% hist(kt(:)); xlabel('k');
% subplot(1,2,2);
% hist(GAMt(:));xlabel('GAM');
% 
% figure
% hist(DENt(:))

E_K   = mean(vec(kt  (:,100:end)))
E_GAM = mean(vec(GAMt(:,100:end))); %Recall E(GAM) is not well defined, in fact
E_OM  = mean(vec(OMt (:,100:end)));
E_TAU = mean(vec(TAUt(:,100:end)));

sum(rkt(:)<0)/length(rkt(:));

disp('SIMULATIONS COMPLETE'); disp(' ');