%IMPULSE RESPONSES - Compute impulse responses for the model economy by
%comparing two histories, one in which government expenditure is always at
%it's steady state and one in which it is high for a single period, but then
%retuns to steady-state after that.


%With Shock
states = [2*ones(1,nburn),3,2*ones(1,nperiods-1)];
[kt,GAMt,ct,ht,OMt,TAUt,BBt,RFt,ETAt,Gt,dent,numt,rkt,taukt,wt,Vt] = det_future(Gpol,hpol,OMpol,TAUpol,BBpol,RFpol,vpol,ggrid,alph,del,gam,psi,xgrid,c0,h0,k1,OM0,TAU0,xi,states);

%Without Shock
states(nburn+1) = 2;
[ktb,GAMtb,ctb,htb,OMtb,TAUtb,BBtb,RFtb,ETAtb,Gtb,dentb,numtb,rktb,tauktb,wtb,Vtb] = det_future(Gpol,hpol,OMpol,TAUpol,BBpol,RFpol,vpol,ggrid,alph,del,gam,psi,xgrid,c0,h0,k1,OM0,TAU0,xi,states);

%Impulse responses are difference between two cases.
irk    = kt   (nburn+1:end) - ktb   (nburn+1:end);
irg    = Gt   (nburn+1:end) - Gtb   (nburn+1:end);
irtaul = TAUt (nburn+1:end) - TAUtb (nburn+1:end);
irOM   = OMt  (nburn+1:end) - OMtb  (nburn+1:end);
irETA  = ETAt (nburn+1:end) - ETAtb (nburn+1:end);
irTAUK = taukt(nburn+1:end) - tauktb(nburn+1:end);
irBB   = BBt  (nburn+1:end) - BBtb  (nburn+1:end);
irV    = Vt   (nburn+1:end) - Vtb   (nburn+1:end);


figure
plot(kt)
figure
plot(GAMt)

%Stack IR data
irdat = [ irtaul',irOM',irETA', irBB',irg',irV'];

%Total change in G over horizon
DG = Gt(nburn+1:end) - Gtb(nburn+1:end);

%Absorbtion by asset taxes
ETA_abs = sum(numt(nburn+1:end) - numtb(nburn+1:end))/sum(DG);

%Absorbtion by labor taxes
TAUL_rev  = TAUt .*wt .*ht;
TAUL_revb = TAUtb.*wtb.*htb;
TAUL_abs  = sum(TAUL_rev(nburn+1:end) - TAUL_revb(nburn+1:end))/sum(DG);