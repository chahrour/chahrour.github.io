function out = ar_coef(dat)


y = dat(2:end);
x = [ones(length(y),1),dat(1:end-1)];

bet = x\y;

out = bet(2);