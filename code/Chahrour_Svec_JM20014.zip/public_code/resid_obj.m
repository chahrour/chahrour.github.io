%RESID_OBJ - Compute the residual of five of the model equations for given
%policy functions Gpol,hpol,Vpol,Epol,Hpol.

function [out,hpol,Gpol,Vpol,Epol,Hpol,xi] = resid_obj(coeffs,pg,ggrid,bet,alph,del,gam,thet,psi,xgrid,xxgrid,jinit,b_,k_,rb0,om0,Q)

kgrid  = xgrid{1};
mgrid  = xgrid{2};
kkgrid = xxgrid(1,:);
mmgrid = xxgrid(2,:);

ng = length(pg);
nk = length(kgrid);
nm = length(mgrid);
nknm = nk*nm;

%Intiali period values
xi = coeffs(end-2);
c0 = coeffs(end-1);
h0 = coeffs(end);

%Policy functions
Gpol = reshape(coeffs(0*ng*nk*nm*ng+1:1*ng*nk*nm*ng), [nm*nk,ng,ng]);
hpol = reshape(coeffs(1*ng*nk*nm*ng+1:2*ng*nk*nm*ng), [nm*nk,ng,ng]);
Vpol = reshape(coeffs(2*ng*nk*nm*ng+1:3*ng*nk*nm*ng), [nm*nk,ng,ng]);
Epol = reshape(coeffs(3*ng*nk*nm*ng+1:4*ng*nk*nm*ng), [nm*nk,ng,ng]);
Hpol = reshape(coeffs(4*ng*nk*nm*ng+1:4*ng*nk*nm*ng+nk*nm*ng), [nm*nk,ng]);

%Initialize residuals
resid1 = zeros(ng,nknm,ng); resid2 = zeros(ng,nknm,ng); resid3 = zeros(ng,nknm,ng); resid4 = zeros(ng,nknm,ng); resid5 = zeros(ng,nknm);

%TIME ZERO EQUATIONS
mu1 = zeros(ng,1); h1 = zeros(ng,1); c1 = zeros(ng,1); v1 = zeros(ng,1); enpv = zeros(ng,1);
GAM_ = 0;
k =  k_^alph*h0^(1-alph) + (1-del)*k_  - c0 - ggrid(jinit)'; %RC Constraint
for jj = 1:ng
    [h1(jj), Q0]   = ndim_simplex_eval(xgrid,[k;GAM_],hpol(:,jj,jinit));
    v1(jj)   = Q0*Vpol(:,jj,jinit);
    enpv(jj) = Q0*Epol(:,jj,jinit); 
    c1(jj)   = cfunc (k,h1(jj),alph,xi,psi,GAM_,gam);
    mu1(jj)  = mufunc(c1(jj),h1(jj),xi,psi,GAM_,gam);
end
m1= mfunc(v1,pg(jinit,:),thet);
rk0 = 1+(1-om0)*(alph*k_^(alph-1)*h0^(1-alph)  - del);                       %Definition
mu0 =  bet*pg(jinit,:)*(m1.*mu1.*(alph*k^(alph-1).*h1.^(1-alph) + 1 - del)); %FOC k0

%Equations for time zero
resid0(1) =  bet*pg(jinit,:)*(m1.*enpv) + uc(c0,h0,gam,psi)*c0 + ul(c0,h0,gam,psi)*h0 - uc(c0,h0,gam,psi)*(rb0*b_ + rk0*k_); %PVIC
resid0(2) =  uc(c0,h0,gam,psi) + xi*(ucc(c0,h0,gam,psi)*c0 + uc(c0,h0,gam,psi) + ucl(c0,h0,gam,psi)*h0) + mu0                       - xi*ucc(c0,h0,gam,psi)*(rb0*b_ + rk0*k_);   %foc c0                      %FOC c0
resid0(3) =  ul(c0,h0,gam,psi) + xi*(ucl(c0,h0,gam,psi)*c0 + ul(c0,h0,gam,psi) + ull(c0,h0,gam,psi)*h0) - mu0*(1-alph)*(k_/h0)^alph - xi*ucl(c0,h0,gam,psi)*(rb0*b_ + rk0*k_) - xi*uc(c0,h0,gam,psi)*(1-om0)*alph*(1-alph)*k_^(alph-1)*h0^-alph; %FOC l0

%Residual from recursive part of the problem; writtent to be compatible
%with parfor outside loop.
for ll = 1:ng
    
    %This period things, to initilize
    h   = zeros(ng,nknm);
    E   = zeros(ng,nknm);
    vg  = zeros(ng,nknm);
    GAM = zeros(ng,nknm);
    
    %Next period things, to initialize
    hprime = zeros(ng,nknm,ng);
    cprime = zeros(ng,nknm,ng);
    Gprime = zeros(ng,nknm,ng);
    mprime = zeros(ng,nknm,ng);
    vprime = zeros(ng,nknm,ng);
    Eprime = zeros(ng,nknm,ng);
    Hprime = zeros(ng,nknm);

    %Temporary variables for residuals
    tmp1 = zeros(ng,nk*nm);
    tmp2 = zeros(ng,nk*nm);
    tmp3 = zeros(ng,nk*nm);
    tmp4 = zeros(ng,nk*nm);
    
    %Time T values at the grid points
    for jj = 1:ng
        h(jj,:)   = Q*hpol(:,jj,ll); %This is equivalent to calling simplex_eval_mex(kgrid,mgrid,kkgrid,mmgrid,hpol(:,jj,ll));
        GAM(jj,:) = Q*Gpol(:,jj,ll);
        vg(jj,:)  = Q*Vpol(:,jj,ll);
        E(jj,:)   = Q*Epol(:,jj,ll);
    end
    H = (Q*Hpol(:,ll))';
    
    %Use the C and H equations to get C and next period K 
    repk_ = repmat_row(kkgrid,ng);
    c = cfunc(repk_,h,alph,xi,psi,GAM,gam);
    k = repk_.^alph.*h.^(1-alph) + (1-del)*repk_ - c - repmat_col(ggrid',nknm);
    
    %Current period things, which need to be computed across all current states
    mg  = mfunc(vg,repmat_row(pg(ll,:),ng),thet);
    
    %Next-period values at the grid points advanced according to the policy
    %functions
    for jj = 1:ng
        %The evaluate points are the same for each mm, so can get Q1 here
        [~,Q1] = ndim_simplex_eval(xgrid,[k(jj,:);GAM(jj,:)],hpol(:,1,jj));
        for mm = 1:ng
            hprime(mm,:,jj) = Q1*hpol(:,mm,jj);
            Gprime(mm,:,jj) = Q1*Gpol(:,mm,jj);
            vprime(mm,:,jj) = Q1*Vpol(:,mm,jj);
            Eprime(mm,:,jj) = Q1*Epol(:,mm,jj);
            cprime(mm,:,jj) = cfunc(k(jj,:),hprime(mm,:,jj),alph,xi,psi,Gprime(mm,:,jj),gam);
        end
        mprime(:,:,jj) = mfunc(vprime(:,:,jj), repmat_row(pg(jj,:),ng),thet);
        Hprime(jj,:) = Q1*Hpol(:,jj);  %Does not depend on lagged state
    end
    om  = omfunc(c,h,GAM,repmat_row(mmgrid,ng),Hprime,xi,vg,mg,thet,gam,psi,bet);
    
    %Compute here rather than in loop to save time
    ucul = uc(c,h,gam,psi).*c + ul(c,h,gam,psi).*h;
    uu = u(c,h,gam,psi);
    repk = repmat_row(k,ng);
    
    %Loop computing residuals for each current state
    for jj = 1:ng
        
        %These lines to save repeated indexing
        cjj   = c(jj,:);
        hjj   = h(jj,:);
        GAMjj = GAM(jj,:);
        vgjj  = vg(jj,:);
        mprimejj = mprime(:,:,jj);
        hprimejj = hprime(:,:,jj);
        cprimejj = cprime(:,:,jj);
        Gprimejj = Gprime(:,:,jj);
        vprimejj = vprime(:,:,jj);
        Eprimejj = Eprime(:,:,jj);
        
        %FOC for kg
        mu = mufunc(cjj,hjj,xi,psi,GAMjj,gam);
        muprime = mufunc(cprimejj,hprimejj,xi,psi,Gprimejj,gam);
        fkprime = alph*(repk./hprimejj).^(alph-1);
        tmp1(jj,:) = mu - bet*pg(jj,:)*(mprimejj.*muprime.*(fkprime + 1 - del));
        
        %FOC for Vg
        tmp2(jj,:) = -mmgrid + GAMjj + 1/thet*(om(jj,:) - pg(jj,:)*(mg.*om));
        
        %FOC for GAMg
        tmp3(jj,:) = vgjj - uu(jj,:) - bet*pg(jj,:)*(mprimejj.*(vprimejj + thet*log(mprimejj)));
                
        %Recursive part of the implementability constraint
        tmp4(jj,:) = E(jj,:) - ucul(jj,:) - bet*pg(jj,:)*(mprimejj.*Eprimejj);
        
    end
    
    %Store resids in sliced variable for parfor loop
    resid1(:,:,ll) = tmp1;
    resid2(:,:,ll) = tmp2;
    resid3(:,:,ll) = tmp3;
    resid4(:,:,ll) = tmp4;
    
    %Definition of HPRIME
    resid5(ll,:) = H - pg(ll,:)*(mg.*(uu + xi*ucul - repmat_row(mmgrid,ng).*(vg + thet*log(mg)) + GAM.*(vg - uu) + bet*Hprime));
    
end

%Combine all residuals, including time-zero residuals
out = [resid1(:);resid2(:);resid3(:);resid4(:);resid5(:);resid0'];

