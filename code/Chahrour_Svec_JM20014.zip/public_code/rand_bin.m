% RAND_BIN(N,T) - Generate random index numbers from bins
%
% where
%
% D = the density of each bin
% T = the number of samples
%
%
% EXAMPLE:
% Y = rand_bin([.1,.9], 10)
%
% yields
%
% Y =
%
%     2     2     2     1     2     2     2     2     2     1
%

function out = rand_bin(D, T)


N = length(D);

rand_den = [0,D];  %Not ready yet
rand_cden = cumsum(rand_den);
r = rand(1,T);
out = zeros(1,T);
for j = 1:N
    out(r>rand_cden(j)) = j;
end






