function out = ucl(c,h,gam,psi)

if psi~=0
    out = (-(c.^(1-gam).*(1-h).^gam).^psi.*(-1+gam)*gam*psi)./(c.*(h-1));
else
    out =     0;
end