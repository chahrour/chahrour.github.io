% Helper that will take any string phrase and surround it by the
% appropriate commands to have the corresponding effect
% Usage:
% out_text = style(in_test, 'italic')

function output = style(in_text, format, size)

    switch format
        case 'italic'
            output = ['\textit{',in_text,'}'];
        case 'slanted'
             output = ['\textsl{',in_text,'}'];
        case 'smallcaps'
             output = ['\textsc{',in_text,'}'];
        case 'bold'
             output = ['\textbf{',in_text,'}'];
        case 'sans-serif'
             output = ['\textsf{',in_text,'}'];
        case 'monospace'
             output = ['\texttt{',in_text,'}'];
        case 'emphasis'
             output = ['\emph{',in_text,'}'];
        case 'normal'
            output = in_text;
        case ''
            output = [];
        otherwise
            error ('Invalid entry for text style');
    end
    
    %tiny, scriptsize,footnotesize,small,
%normalsize,large, Large,LARGE,huge,HUGE
   
if ~isempty(size)
    if ~isempty(output);
        output = ['\',size,' ',output];
    end
end
end
       



            
            
            