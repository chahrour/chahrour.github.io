function out = u(c,h,gam,psi)

if psi ~= 0
    out =   (1/psi)*(c.^(1-gam).*(1-h).^gam).^psi;
else
    out =   (1-gam)*log(c) + gam*log(1-h);
end