%**********************************************************************
%SOLVE MODEL
%***********************************************************************
disp('SOLVING NONLINEAR MODEL');
if use_saved
    %Load from previous run?
    load coeffs_final coeffs_final
    coeffs_init = coeffs_final;
else
    %Initial coeffs based on linearization. 
    %last three elements are for time zero problem.
    coeffs_init = [Gpol_init(:);hpol_init(:);vpol_init(:);epol_init(:);Hpol_init(:);xi;0.3456;  0.2762];
end

% %Using this starting value improves solver performance.
% coeffs_init(end-2) = .4;


%Test initial point
obj = @(x) resid_obj(x,pg,ggrid,bet,alph,del,gam,thet,psi,xgrid,xxgrid,jinit,b_,k_,rb0,om0,Q);
finit = obj(coeffs_init);
sum(abs(finit))

%Solve Collocation Problem (non-linear system of equations) using built-in
%fsolve
%  tic
% options_c = optimset('fsolve');
% options_c = optimset(options_c, 'display', 'iter', 'tolfun', 1e-15, 'maxfunevals', 15000);
% [coeffs_final, fval] = fsolve(obj,coeffs_init, options_c);
% [fval,hpol,Gpol,vpol,epol,Hpol,xi] = obj(coeffs_final);
% toc

%Solve Collocation Problem (non-linear system of equations) using Broyden
%from Compecon toolbox
tic
optset('broyden','showiters',1); optset('broyden','maxit', 200);optset('broyden','tol', 1e-10);
[coeffs_final, fval2] = broyden(obj,coeffs_init);
[fval2,hpol,Gpol,vpol,epol,Hpol,xi] = obj(coeffs_final);
toc

%Solve for exante tax expression
[OM,TAU,BB,RF,OM0,TAU0,DR0,k1] = ramsey_tools(coeffs_final,pg,ggrid,bet,alph,del,gam,thet,psi,xgrid,xxgrid,k_,jinit,om0,Q);

%Policy functions OM, etc
OMpol  = zeros(nk*nm,ng,ng);
TAUpol = zeros(nk*nm,ng,ng);
BBpol  = zeros(nk*nm,ng,ng);
RFpol  = zeros(nk*nm,ng,ng);
for jj = 1:ng
    for ll = 1:ng     
       OMpol(:,jj,ll)  = ndim_simplex(xgrid,xxgrid,OM(jj,:,ll));
       TAUpol(:,jj,ll) = ndim_simplex(xgrid,xxgrid,TAU(jj,:,ll));
       BBpol(:,jj,ll)  = ndim_simplex(xgrid,xxgrid,BB(jj,:,ll));
       RFpol(:,jj,ll)  = ndim_simplex(xgrid,xxgrid,RF(jj,:,ll));
    end
end
disp('NONLINEAR MODEL SOLVED');disp(' ');

%*************************************************************************
% SIMULATE ECONOMY
%*************************************************************************
rng(0);  %Seed so no difference due to different random sequences
simulate_economy




impulse_responses

%*************************************************************************
% SAVE COEFFS
%*************************************************************************
save coeffs_final coeffs_final thet

eval(['save ' param.diro, 'outsave_thet',num2str(tt)])