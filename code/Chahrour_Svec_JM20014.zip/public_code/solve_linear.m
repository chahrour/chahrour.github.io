%**************************************************************
% MAIN_PROG - Solves the neoclassical model with a random walk 
% TFP solved in class in EC860. Compute impulse responses, and 
% plots them.
%
% Code by Ryan Chahrour, Boston College, 2012
%**************************************************************

disp('SOLVING LINEAR MODEL ...')

%Compute the first-order coefficiencients of the model
[fyn, fxn, fypn, fxpn, ss] = model(param);

%Compute the transition and policy functions, using code by
%Stephanie Schmitt-Groh� and Mart�n Uribe (and available on their wedsite.)
[gx,hx]=gx_hx_alt(fyn,fxn,fypn,fxpn);


css = ss(1);
hss = ss(2);
vss = ss(3);
ess = ss(4);
Hss = ss(5);
gss = ss(8);
kss = ss(end-1);

kp_init = @(g,k,GAM) kss + hx(2,1)*(g-gss)+hx(2,2)*(k-kss)+hx(2,3)*GAM;
hp_init = @(g,k,GAM) hss + gx(2,1)*(g-gss)+gx(2,2)*(k-kss)+gx(2,3)*GAM;
vp_init = @(g,k,GAM) vss + gx(3,1)*(g-gss)+gx(3,2)*(k-kss)+gx(3,3)*GAM;
ep_init = @(g,k,GAM) ess + gx(4,1)*(g-gss)+gx(4,2)*(k-kss)+gx(4,3)*GAM;
Hp_init = @(g,k,GAM) Hss + gx(5,1)*(g-gss)+gx(5,2)*(k-kss)+gx(5,3)*GAM;


ck_init = [css,kss];
save ck_init ck_init

disp('LINEAR MODEL SOLVED');
disp(' ');



iry = ir(gx,hx,[1 0 0]',100);

plot(iry(:,7))