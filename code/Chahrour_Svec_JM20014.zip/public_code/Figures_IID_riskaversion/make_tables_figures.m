%MAKE THE TABLES AND FIGURES FOR CHAHROUR-SVEC 2014
load Table_Data
clear set
suff = 'averseIID';

tools = {'Labor Tax', 'Ex-ante Capital Tax', 'Priv. Asset Tax', 'Cap. Tax w. Safe Debt'};
stats = {'Mean', 'Std. Dev.', 'Autocorr.', 'Corr. w/ G'};



%FIGURES
f = figure;
plot(log(thet_vec), log(DR_store), '-k', 'color', 'black', 'linewidth', 2);
xlabel('log(\theta)');
ylabel('log(distortion)')
saveas(f,[dir,'figure1_' suff, '.eps'], 'epsc')

f = figure;
for ll = 1:4
    for mm = 1:4
        s = subplot(4,4,(ll-1)*4 + mm);
        hold on
        if mm == 1
            ylabel(tools{ll});
            if ll == 1
                xlabel('Distortion');
            end
        end
        if ll == 1
            title(stats{mm});
        end
        plot(log(DR_store),reshape(TAX_store(ll,mm,:), [1,nthet]), '-','linewidth', 2, 'color', 'k')
        ylim = get(s, 'ylim');
        if diff(ylim) < 1e-2
            ylim = [mean(ylim) - .1,mean(ylim) + .1];
            set(s, 'ylim', ylim);
        end
        set(s, 'xtick', []);
        set(s, 'xlim',  [-1 + min(log(DR_store)),1+max(log(DR_store))]);
        
    end
end
saveas(f, [dir,'figure2_' suff, '.eps'], 'epsc');

%INITIAL TAXES
f = figure;
s = subplot(1,2,1);
plot(log(DR_store), 100*TAUL0_store,'-k','linewidth',2);
xlabel('Distortion');
ylabel('Labor Tax in Period Zero');
set(s,'xtick', []);
s = subplot(1,2,2);
plot(log(DR_store), 100*OM0_store,'-k','linewidth',2);
xlabel('Distortion');
ylabel('Ex Ante Capital Tax in Period Zero');
set(s,'xtick', []);
saveas(f, [dir,'figure3_' suff, '.eps'], 'epsc');

%ABSORBTION FIGURE
f = figure;
s = subplot(1,1,1);
plot(log(DR_store), TAUL_store, '-k','linewidth',2); hold on
plot(log(DR_store), ETA_store, '--k', 'linewidth',2);
xlabel('Distortion');
set(s,'xtick', [], 'ylim', [-.2,1.4]);
ylabel('Cumulative Absorbtion');
legend('Labor Tax', 'Private Asset Tax', 'location', 'northwest');
saveas(f, [dir,'figure4_' suff, '.eps'], 'epsc');


%TABLES
thet_table = [1,(nthet+1)/2, nthet];
dist_level = {'no distortion.', 'modest distortion.', 'high distortion.'};
for jj =1:3
    filename{jj} = [dir,'table', num2str(jj), '_', suff];
    dat = TAX_store(:,:,thet_table(jj));
    table1 = ltable(dat, {'blank', stats{:}}, tools', ['Ramsey tax moments for the risk-averse calibration with i.i.d. shocks and ' dist_level{jj}],'table_format_file',filename{jj});
end
make_file([dir,'tables_for_paper'], 'file_format', filename{:});


irdata_tmp = irdata;
irdata_tmp(:,1:3,:) = 100*irdata_tmp(:,1:3,:);
irf = ir_figure(irdata_tmp(:,:,thet_table), {'Labor Tax', 'Ex-Ante Cap. Tax', 'Private Assets Tax', 'Bonds', 'Government Spending', 'Consumer Welfare'}, '', {'-', '--g', '-*r'}, {'No Distortion', 'Moderate Distortion', 'High Distortion'});
saveas(irf, [dir,'figure5_' suff, '.eps'], 'epsc');