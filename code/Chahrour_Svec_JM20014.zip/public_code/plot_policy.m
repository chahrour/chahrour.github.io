function f = plot_policy(kgrid,mgrid,pol_init,pol,tit)

ng = size(pol,2);
xgrid{1} = kgrid;
xgrid{2} = mgrid;

%Plot initial and final policy functions together
f = figure;clist = {'g','r','c'};

%With respect to capital
subplot(1,2,1);hold on;
for jj = 1:ng
    for ll = 1:ng
        hh1 = ndim_simplex_eval(xgrid,[kgrid; mean(mgrid)+0*kgrid],pol_init(:,jj,ll));
        hh2 = ndim_simplex_eval(xgrid,[kgrid; mean(mgrid)+0*kgrid],pol(:,jj,ll));
        plot(kgrid,hh1, '-o');
        plot(kgrid,hh2, ['-s', clist{ll}]);
    end
end
xlabel('Capital');

%With respect to GAM
subplot(1,2,2);hold on;
for jj = 1:ng
    for ll = 1:ng
        hh1 = ndim_simplex_eval(xgrid,[mean(kgrid)+0*mgrid; mgrid],pol_init(:,jj,ll));
        hh2 = ndim_simplex_eval(xgrid,[mean(kgrid)+0*mgrid; mgrid],pol(:,jj,ll));
        plot(mgrid,hh1, '-o');
        plot(mgrid,hh2, ['-s', clist{ll}]);
    end
end
xlabel('GAMMA');

%Title and legend
legend('Linearized Model','Nonlinear (Collocation)')
mtit(tit)
