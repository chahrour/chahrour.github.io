%MFUNC - Compute the distortions using the relevant foc.

function m = mfunc(vg,pg,thet)


m = exp(-vg/thet)./(pg*exp(-vg/thet));