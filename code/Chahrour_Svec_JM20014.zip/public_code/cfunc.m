%CFUNC - Delivers C as a function of 


function out = cfunc(k,h,alph,xi,psi,GAM,gam)


out = (k.^alph.*(-1+h).*h.^-alph.*(-1+alph).*(-1+gam).*((-1+h).*(-1+GAM) - (-1+h+gam).*xi.*psi))./(gam.*(-1 + h + GAM - h.*GAM - xi + (-1+h + gam).*xi*psi));


%Check L foc
% test = ul(out,h,gam,psi) + xi*(ucl(out,h,gam,psi).*out + ul(out,h,gam,psi) + ull(out,h,gam,psi).*h) - mufunc(out,h,xi,psi,GAM,gam).*(1-alph).*(k./h).^(alph) - GAM.*ul(out,h,gam,psi);
% 
% max(abs(test))
% pause