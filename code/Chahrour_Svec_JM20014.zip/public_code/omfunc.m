%The FOC for m_g to deliver om

function om = omfunc(c,h,GAM,GAM_,H,xi,vg,mg,thet,gam,psi,bet)

om = -u(c,h,gam,psi) - xi*(uc(c,h,gam,psi).*c + ul(c,h,gam,psi).*h) + GAM_.*(vg + thet*(1+log(mg))) - GAM.*(vg - u(c,h,gam,psi)) - bet*H;


%Test the foc
% u(c,h,gam,psi) + xi*(uc(c,h,gam,psi).*c + ul(c,h,gam,psi).*h) - GAM_.*(vg + thet*(1+log(mg))) + GAM.*(vg - u(c,h,gam,psi)) + om + bet*H
% pause