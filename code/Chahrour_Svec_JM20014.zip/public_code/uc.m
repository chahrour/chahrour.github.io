function out = uc(c,h,gam,psi)

if psi ~= 0
    out =     (c.^(1-gam).*(1-h).^gam).^psi.*(1-gam)./c;
else
    out =     (1-gam).*c.^-1;
end