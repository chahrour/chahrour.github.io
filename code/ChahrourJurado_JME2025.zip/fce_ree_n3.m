% -------------------------------------------------------------------------
% Solve for the full communication equilibrium dynamics in a 3-sector
% version of the Townsend (1983) model with heterogeneity in sensitivity to
% the common demand disturbance.
% -------------------------------------------------------------------------

% Clear workspace
clear; clc;

% Frequency grid
N    = 1000;
grid = 2*pi*(0:(N-1))/N;
z    = exp(-1i.*grid).';

% Common parameters (same as in Townsend, 1983, except rho=0.9)
f0   = 0.2;
f1   = 0;
f2   = 0.8;
b1   = 1;
rho  = 0.5;
beta = 0.96;
sigv = 1;
sige = 1;

% Sector-specific parameters
alphas   = [-1,1,2];
n        = length(alphas);

% Laws of motion for exogenous processes
hv    = sigv./(1-rho.*z);
he    = sige + 0.*z;
Sige  = sige.*eye(n);

% Reduced-form parameters
lambda  = ((1+1/beta+(b1*f0^2 + f1)/f2) - sqrt((1+1/beta+(b1*f0^2 + f1)/f2)^2 - 4/beta))/2; 
sigbar2 = 1/(mean(alphas.^2./sige^2));
sig2    = ((n*sigv^2 - (1-rho^2)*sigbar2) + sqrt((n*sigv^2 - (1-rho^2)*sigbar2)^2 +4*n*sigbar2*sigv^2))/2;
omega   = f0/f2*beta*lambda*rho/(1-beta*lambda*rho)*sig2/(sig2+sigbar2);
phi     = rho*(1 - sig2/(sig2+sigbar2));
weights = sigbar2/sige^2/n.*alphas;

%% FCE solution in closed-form
% Law of motion for target processes
target = zeros(n,n+1,N);
kps    = zeros(n,n+1,N);
ys     = zeros(n,n+1,N);
for  i = 1:N
    target(:,:,i) = alphas(:).*((beta*lambda*rho/(1-beta*lambda*rho)*sig2/(sig2+sigbar2))./(1-phi.*z(i)).*weights*[alphas(:).*hv(i),he(i).*eye(n)]);
    kps(:,:,i)    = f0/f2./(1-lambda.*z(i)).*target(:,:,i);
    ys(:,:,i)    = f0.*z(i).*kps(:,:,i);
end

% Time domain
kpst = real(ifft(kps,[],3));
yst_fce  = real(ifft(ys,[],3));

% Totals
kp = mean(kps);
y  = mean(ys);

% Time domain
kpt = real(ifft(kp,[],3));
yt_fce  = real(ifft(y,[],3));

% Rescale
yst_fce = yst_fce.*100;
yt_fce  = yt_fce.*100;

% Save results
fce.target = target;
save('fce','fce');

%% REE solution numerical
% Initial plms
load fce;
plm = fce.target + 0.01;

% Iteration loop
tol     = 1e-12;
maxiter = 1e3;
err     = 1;
iter    = 1;
while err > tol && iter < maxiter

    % Average price
    pbar = zeros(1,n+1,N);
    for i = 1:N
        term         = mean(b1*f0^2/f2.*z(i)./(1-lambda.*z(i)).*plm(:,:,i));
        pbar(:,:,i)  = [mean(alphas).*hv(i), sige./n.*ones(1,n)] - term;
    end
    
    % Observation process
    alm = zeros(n,n+1,N);
    for j = 1:n 
        obs = zeros(2,n+1,N);
        g   = zeros(2,2,N);
        for i = 1:N
            obs(:,:,i) = [alphas(j).*hv(i),Sige(j,:);pbar(:,:,i)];
            g(:,:,i)   = obs(:,:,i)*obs(:,:,i)';
        end
        
        % Wold representation
        [Gam,Gamt] = wold(g,N);
        Gam_blam   = ma_sum(Gamt,beta*lambda);     
        
        % Implied alm
        for i = 1:N
            alm(j,:,i) = beta*lambda./(z(i) - beta*lambda)*[1,0]*(Gam(:,:,i) - Gam_blam)*pinv(Gam(:,:,i))*obs(:,:,i);
        end
    end
    
    % Error
    err = norm(alm(:)-plm(:));
    disp(num2str([iter,err]));
    
    % Update
    w    = 0.5;
    plm  = w.*alm + (1-w).*plm;
    iter = iter + 1;
end

% Capital and output
kps = zeros(n,n+1,N);
ys  = zeros(n,n+1,N);
for i = 1:N
    kps(:,:,i) = f0./f2./(1-lambda.*z(i)).*alm(:,:,i);
    ys(:,:,i)  = f0.*z(i).*kps(:,:,i);
end

% Time domain
kpst = real(ifft(kps,[],3));
yst  = real(ifft(ys,[],3));

% Totals
kp = mean(kps);
y  = mean(ys);

% Time domain
kpt = real(ifft(kp,[],3));
yt  = real(ifft(y,[],3));

% Rescale
yst = yst.*100;
yt  = yt.*100;
%% Plot results
fig1 = figure(1);
h   = 10;
ind = 1:h+1;


% ROW: y1
s = subplot(n+1,n+1,1);
plot(0:h,squeeze(yst_fce(1,1,ind)),'-xk'); hold on;
plot(0:h,squeeze(yst(1,1,ind)),'-ok'); hold on;
ylabel('$y_{1t}$','interpreter','latex','FontSize',14);
title('$v_t$','interpreter','latex','FontSize',14);

s = subplot(n+1,n+1,2);
plot(0:h,squeeze(yst_fce(1,2,ind)),'-xk'); hold on;
plot(0:h,squeeze(yst(1,2,ind)),'-ok'); hold on;
title('$\varepsilon_{1t}$','interpreter','latex','FontSize',14);

s = subplot(n+1,n+1,3);
plot(0:h,squeeze(yst_fce(1,3,ind)),'-xk'); hold on;
plot(0:h,squeeze(yst(1,3,ind)),'-ok'); hold on;
title('$\varepsilon_{2t}$','interpreter','latex','FontSize',14);

s = subplot(n+1,n+1,4);
plot(0:h,squeeze(yst_fce(1,4,ind)),'-xk'); hold on;
plot(0:h,squeeze(yst(1,4,ind)),'-ok'); hold on;
title('$\varepsilon_{3t}$','interpreter','latex','FontSize',14);

% ROW: y2
subplot(n+1,n+1,5);
plot(0:h,squeeze(yst_fce(2,1,ind)),'-xk'); hold on;
plot(0:h,squeeze(yst(2,1,ind)),'-ok'); hold on;
ylabel('$y_{2t}$','interpreter','latex','FontSize',14);

s = subplot(n+1,n+1,6);
plot(0:h,squeeze(yst_fce(2,2,ind)),'-xk'); hold on;
plot(0:h,squeeze(yst(2,2,ind)),'-ok'); hold on;

s = subplot(n+1,n+1,7);
plot(0:h,squeeze(yst_fce(2,3,ind)),'-xk'); hold on;
plot(0:h,squeeze(yst(2,3,ind)),'-ok'); hold on;

s = subplot(n+1,n+1,8);
plot(0:h,squeeze(yst_fce(2,4,ind)),'-xk'); hold on;
plot(0:h,squeeze(yst(2,4,ind)),'-ok'); hold on;

%Row: y3
subplot(n+1,n+1,9);
plot(0:h,squeeze(yst_fce(3,1,ind)),'-xk'); hold on;
plot(0:h,squeeze(yst(3,1,ind)),'-ok'); hold on;
ylabel('$y_{3t}$','interpreter','latex','FontSize',14);

s = subplot(n+1,n+1,10);
plot(0:h,squeeze(yst_fce(3,2,ind)),'-xk'); hold on;
plot(0:h,squeeze(yst(3,2,ind)),'-ok'); hold on;

s = subplot(n+1,n+1,11);
plot(0:h,squeeze(yst_fce(3,3,ind)),'-xk'); hold on;
plot(0:h,squeeze(yst(3,3,ind)),'-ok'); hold on;

s = subplot(n+1,n+1,12);
plot(0:h,squeeze(yst_fce(3,4,ind)),'-xk'); hold on;
plot(0:h,squeeze(yst(3,4,ind)),'-ok'); hold on;

% Row: ysum
subplot(n+1,n+1,13);
plot(0:h,squeeze(yt_fce(1,1,ind)),'-xk'); hold on;
plot(0:h,squeeze(yt(1,1,ind)),'-ok'); hold on;
ylabel('$\bar{y}_{t}$','interpreter','latex','FontSize',14);

s = subplot(n+1,n+1,14);
plot(0:h,squeeze(yt_fce(1,2,ind)),'-xk'); hold on;
plot(0:h,squeeze(yt(1,2,ind)),'-ok'); hold on;

s = subplot(n+1,n+1,15);
plot(0:h,squeeze(yt_fce(1,3,ind)),'-xk'); hold on;
plot(0:h,squeeze(yt(1,3,ind)),'-ok'); hold on;

s = subplot(n+1,n+1,16);
p1 = plot(0:h,squeeze(yt_fce(1,4,ind)),'-xk'); hold on;
p2 = plot(0:h,squeeze(yt(1,4,ind)),'-ok'); hold on;

leg = legend([p1,p2],'FCE','REE');
set(leg,'box','off','location','southeast','FontSize',11);

for i = [2:4]; subplot(n+1,n+1,i); ylim([-1,1]); end

for i = [6:8]; subplot(n+1,n+1,i); ylim([-2,2]); end
    
for i  =  [10:12]; subplot(n+1,n+1,i); ylim([-3,3]); end

for i  = [14:16]; subplot(n+1,n+1,i); ylim([-2,2]); end


dim = [6,2.5*2];
set(gcf,'paperpositionmode','manual','paperunits','inches');
set(gcf,'papersize',dim,'paperposition',[0,0,dim]);
exportgraphics(fig1, 'output_figures/irfs_hetero.pdf','Resolution',1200);

