% Function ARMA_FIT
%
% Fits an ARMA(P,Q) to a stochastic process in the frequency domain

function [out,xopt] = arma_fit(xin,A,zgrid,p,q)

%Guess for ARMA parameters
if isempty(xin)
    xin = zeros(1,p+q+1);
end

%Reshape A if needed
A = reshape(A,size(zgrid));

%Objective
obj = @(x) resid(x,A,zgrid,p,q);

options = optimoptions('lsqnonlin');
options.Display = 'iter';
[xopt,out] = lsqnonlin(obj,xin,[],[],[],[],[],[],[],options);



end

%**************************************************************************
% Residual function
%**************************************************************************

function out = resid(xin,A,zgrid,p,q)

if length(xin)~=((p+q+1))
    error('guess is wrong size')
end

Aar = 1;
ctr = 1;
for ii = 1:p
    Aar = Aar - xin(ctr).*zgrid.^(ii); ctr = ctr+1;
end

Ama = 0;
for ii = 0:q
    Ama = Ama + xin(ctr).*zgrid.^(ii); ctr = ctr+1;
end

Aresid = Ama./Aar - A;

out = 1000*real(ifft(Aresid,[],2));


end