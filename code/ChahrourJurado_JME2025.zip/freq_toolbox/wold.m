% WOLD: provides Wold representation of a given scalar 
% spectral density f(lambda), lambda in [0,2*pi] 
%
% usage:
%
% [psii,MA_wold] = wold(f,N)
%
% where
%
% f: function handle to the spectral density that accepts *scalar* arguments, and returns (potentially) a matrix
% N: number of gridpoints in the frequency domain
%
% usages equation 3.1 from Wilson 1972 "The Factorization of Matricial
% Spectral Densities"
%
% Written by:
% Ryan Chahrour and Kyle Jurado
% 
% Modified on:
% July 2, 2020
function [psii,MA_wold] = wold(f,N)

%Grid in frequency domain
lam_grid = 2*pi*(0:(N-1))/N;

if (isequal(class(f), 'function_handle'))
    %Evaluate f at grid points
    q1 = size(f(0),1); fgrid = zeros(q1,q1,N);
    for jj = 1:N
        fgrid(:,:,jj) = f(lam_grid(jj));
    end
else
    q1 = size(f(:,:,1),1);
    fgrid = f;
end

%Check rank of fgrid and add ridge
for jj = 1:N
   if rcond(fgrid(:,:,jj))<1e-10
       fgrid(:,:,jj) = fgrid(:,:,jj)+1e-11*eye(q1);
       warning('Something''s not right')
   end
end


q2 = rank(fgrid(:,:,1));


%Initial values: crucial that guess is a Wald to start!
ma_guess        = zeros(q1,q2,N);
ma_guess(:,:,1) = eye(q1);
psii            = fft(ma_guess,[],3);


S = zeros(q2);
eyeq = eye(q2);inner = zeros(q2,q2,N);psii_new = 0*psii;
jmax = 550; crit = 1; jj = 0;
while jj<jmax && crit > 1e-12
    
    %Compute the anihilator term in 3.1
    for nn = 1:N
        psi_tmp = psii(:,:,nn);
        inner(:,:,nn) =  psi_tmp\(fgrid(:,:,nn)/psi_tmp') + eyeq;
    end
 
    MA_anih = ifftshift(ifft(inner,[],3),3);
    MA_anih(:,:,1:(N/2) ) = 0;
    MA_anih(:,:,   N/2+1) = 1/2*MA_anih(:,:,N/2+1);
    inner_plus = fft(fftshift(MA_anih,3),[],3);
    
    %Evalute 3.1 in Wilson
    for nn=1:N
        psii_new(:,:,nn) = psii(:,:,nn)*(inner_plus(:,:,nn)+S);
    end

    
    %Check for convergence
    crit = max(max(max(abs(psii_new-psii))));
    psii = 0.5*psii + 0.5*psii_new;

    %pause
    jj = jj + 1;
end

% %Check that psi coincides with original MGF
% pp = zeros(size(fgrid));
% for nn =1:N
%    pp(:,:,nn) = psii(:,:,nn)*(psii(:,:,nn)'); 
% end
% 
% crit2 = max(max(max(abs(pp - fgrid),[],3)));




%Get the MA of the Wold
MA_wold = ifft(psii_new,[],3);

% Lower triangular normalization
A0   = MA_wold(:,:,1);
Atil = chol(A0*A0','lower');
x    = A0^-1*Atil;    %Unitary matrix that converts A0 in lower triangular
for nn = 1:N
   MA_wold(:,:,nn) =  MA_wold(:,:,nn)*x;
end
psii = fft(MA_wold,[],3);

MA_wold = real(MA_wold);

%Check that psi coincides with original MGF
pp = zeros(size(fgrid));
for nn =1:N
   pp(:,:,nn) = psii(:,:,nn)*(psii(:,:,nn)'); 
end
crit2 = max(max(max(abs(pp - fgrid),[],3)));

%Confirm convergence
if crit > 1e-10 || crit2 > 1e-10
    warning(['Algorithm didn''t converge: final crit - ' num2str(crit) '|' num2str(crit2)])
end

