% MA_SUM: Compute the sum A(beta) of the z-transform of the MA process A(z)
%
% Usage:
% 
% out = ma_sum(MA,bet)
%
% where M is array of size [q,q,N]
%
% Note: code assumes the MA process is coming as generate by ifft, so first half
% of third dim is MA lags, 2nd half is MA leads
function out = ma_sum(MA,bet)

%We are assuming the MA process is coming in as order ifft, so first half
%is MA lags, 2nd half is MA leads
N = size(MA,3);
K = N/2;
%bet_lag_lead = reshape([bet.^(0:K-1),0*bet.^(-K:1:-1)],[1,1,N])

bet_lag_lead = reshape([bet.^(0:K-1),0.*(-K:1:-1)],[1,1,N]);


%Numerical safety: check for near zero MA terms and kill thme off exactly
idxz = sum(sum(abs(MA)))<eps(100000);
bet_lag_lead(idxz) = 0;

%Compute and return
out = sum(MA.*bet_lag_lead,3);

