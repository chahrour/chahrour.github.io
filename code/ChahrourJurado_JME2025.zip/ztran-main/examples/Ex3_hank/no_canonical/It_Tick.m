function a = It_Tick(Its)

global ITERATION_TICK

a = (Its/ITERATION_TICK == int32(Its/ITERATION_TICK));