% This code solves a simple asset pricing model that does not permit an
% analytical solution. See Appendix D of Han, Tan & Wu (2021): Analytic
% Policy Function Iteration.

clear
close all
clc

% Structural parameters (same as in Table 3 of Townsend, 1983, except rho=0.9)
f0   = 0.2;
f1   = 0;
f2   = 0.8;
b1   = 1;
rho  = 0.9;
beta = 0.96;
sigv = 1;
sige = 1;
sign = 1;

% Variables
xp = 1;

% Shocks
sd = 1;
ss = 2;

% Innovations
ee = 1;
eu = 2;
ev = 3;

% Dimensions
nx = 3;
ns = 3;
ne = 3;

% Model
Ax0 = zeros(nx);
Aa0 = zeros(nx);
As0 = zeros(nx,ns);

Ax1 = zeros(nx);
Aa1 = zeros(nx);
As1 = zeros(nx,ns);


Bx0 = zeros(nx);
Ba0 = zeros(nx);
Bs0 = zeros(nx);

Bx1 = zeros(nx);
Ba1 = zeros(nx);
Bs1 = zeros(nx);

C1 = zeros(ns);
D0 = zeros(ns,ne);
V  = zeros(ne);

Ax0(1,2) = -f2 - beta*(f2+f1);
Ax0(2,1) = -1;
Ax0(3,3) = -1;

Aa0(3,1) = 1;

As0(2,2) = 1;
As0(3,3) = 1;

Ax1(1,2) = f2;
Ax1(2,2) = -b1*f0;

Bx0(1,2) = 0;

Bx1(1,1:2) = [f0, beta*f2];


C1(1,1) = rho;
C1(2,1) = rho;

D0 = [1 0 0; 1 1 0; 0 0 1];


V(1,1) = sigv^2;
V(2,2) = sige^2;
V(3,3) = sign^2;

agg = {3,[1 3]};     % {var_id, inn_id}
sig = {
    1, 3, 2, false     % {eqn_id, end_id, exo_id, ave_ex}
    };

% Solve model
m = ztran(nx,ns);
m.Ax = {Ax0,Ax1};
m.Aa = {Aa0,Aa1};
m.As = {As0,As1};
m.Bx = {Bx0,Bx1};
m.Ba = {Ba0,Ba1};
m.Bs = {Bs0,Bs1};

m.C = {C1};
m.D = {D0};
m.V = V;
m.agg = agg;
m.sig = sig;
tic
m.solve('dft',1000,'crit',1e-8,'nit',{10,500,10}, 'arma',{5,5,false});
toc
%% IRF
T = 40;
var_lab = {'$p$','k','psig'};
inn_lab = {'$\varepsilon$','$\eta$','$\nu_{i}$'};

figure('Name','IRF')
res = zeros(nx,ne,T);
for i = 1:ne
    imp = zeros(ne,T);
    imp(i,1) = 1;
    res(:,i,:) = m.sol.irf(imp);
    if ismember(i,setdiff(1:ne,agg{2}))
        res(agg{1},:) = 0;
    end
    for j = 1:nx
        subplot(ne,nx,(i-1)*nx+j)
        plot(1:T,squeeze(res(j,i,:)),'linewidth',1.2)
        xlim([1 T])
        xticks([1 round(T/2) T])
        if i==1
            title(var_lab{j},'Interpreter','latex','FontSize',12)
        end
        if j==1
            ylabel(inn_lab{i},'Interpreter','latex','FontSize',12)
        end
    end
end
