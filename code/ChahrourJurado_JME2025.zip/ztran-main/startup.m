% *-----------------------------------------------------------------------*
% |   _______ _____            _   _                                      |
% |  |__   __|  __ \     /\   | \ | |   Welcome to z-Tran MATLAB Toolbox  |
% |  ___| |  | |__) |   /  \  |  \| |                                     |
% | |_  / |  |  _  /   / /\ \ | . ` |   (c) Fei Tan & Jieran Wu           |
% |  / /| |  | | \ \  / ____ \| |\  |   Last modified: 22-Aug-2023        |
% | /___|_|  |_|  \_\/_/    \_\_| \_|   Contact: tanf@slu.edu             |
% |                                                                       |
% *-----------------------------------------------------------------------*
clear
close all
clc
help startup
addpath(genpath('classes'),genpath('examples'),genpath('m'))