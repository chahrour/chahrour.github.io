xin = [ .5 .01 0];

Jmax = 7;
loss_exog = NaN(1,Jmax );
for jj = 1:Jmax 
    [loss_tmp,xout] = arma_fit(xin,Ptil1(1,1,:),L,jj,jj); %arma_fit >> arma_fit2
    loss_exog(jj) = norm(loss_tmp(:))/1000;
    xin = [xout(1:jj),0,xout(jj+1:end),0];
end

xin = [ .5 0 .01];
loss_endog = NaN(1,Jmax );
for jj = 1:Jmax 
    [loss_tmp,xout] = arma_fit(xin,Ptil(1,1,:),L,jj,jj);
    loss_endog(jj) = norm(loss_tmp(:))/1000;
    xin = [xout(1:jj),0,xout(jj+1:end),0];
end

%% Figure plotting
fig = figure(5);
s = subplot(1,1,1);
plot(1:Jmax ,max(loss_exog,1e-12), '-xk'); hold on
plot(1:Jmax ,loss_endog, '-ok');
plot(1:Jmax, zeros(1,Jmax)+1e-12, ':k');

text(1.2,exp(-27),'numerical tolerance', 'Interpreter','latex', 'FontSize',12)

s.YScale = 'log';


s.XTick = [1:Jmax];
s.XLim = [1,Jmax + 0.01];
leg = legend('exogenous signal','endogenous signal');
set(leg,'box','off','location','northeast');

dim = [6,2.5*2];
set(gcf,'paperpositionmode','manual','paperunits','inches');
set(gcf,'papersize',dim,'paperposition',[0,0,dim]);

xlabel('approximation order (p)','interpreter','latex');

ylabel('$||A(L)-\widehat A(L)||$','interpreter','latex');
s.FontSize = 13;
exportgraphics(fig, 'output_figures/arma_approx.pdf','Resolution',1200);
