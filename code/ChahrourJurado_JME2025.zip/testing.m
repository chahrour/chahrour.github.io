p = 2;
q = 9;

AR = randn(3,3,p+1);
MA = randn(3,3,q+1);

syms L

Lgrid_p = reshape(L.^[0:p],[1,1,p+1]);
Lgrid_q = reshape(L.^[0:q],[1,1,q+1]);

proc1 = 0;
for jj = 1:p+1
    proc1 = proc1 + AR(:,:,jj).*Lgrid_p(jj);
end

proc2 = 0;
for jj =1:q+1
    proc2 = proc2 + MA(:,:,jj).*Lgrid_q(jj);
end

proc = inv(proc1)*proc2;

[num,den] = numden(proc(3,2))

collect(num)
collect(den)


