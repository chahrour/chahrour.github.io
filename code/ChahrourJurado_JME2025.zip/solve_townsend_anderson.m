% -------------------------------------------------------------------------
% Solve the Townsend (1983) model under different information assumptions
% -------------------------------------------------------------------------


% Defaults, normally set in run_all.m
if ~exist('n','var')
    addpath('freq_toolbox')
    n = 1000;
end

if ~exist('plot_figs','var')
    plor_figs = true;
end

% Frequency grid
grid = 2*pi*(0:(n-1))/n;
L    = reshape(exp(-1i.*grid).',[1,1,n]);

% Structural parameters (same as in Table 3 of Townsend, 1983, except rho=0.9)
f0   = 1.1;
f1   = 0.0;
f2   = 0.8;
b1   = 1;
rho  = 0.9;
beta = 0.96;
sigv = 1;
sige = 1;
sign = .2;

% Reduced-form parameters
lambda = ((1+1/beta+(b1*f0^2 + f1)/f2) - sqrt((1+1/beta+(b1*f0^2 + f1)/f2)^2 - 4/beta))/2;

% Laws of motion for exogenous processes
hv = sigv./(1-rho.*L);
he = sige + 0.*L;
hn = sign + 0.*L;

%%-------------------------------------------------------------------------
% Full information solution
% -------------------------------------------------------------------------

X0    = zeros(1,3,n);
K0    = zeros(1,3,n);
Y0    = zeros(1,3,n);
P0    = zeros(1,3,n);
Ptil0 = zeros(1,3,n);
F0    = zeros(1,3,n); %Aggregate forecast error
for i = 1:n
    X0(:,:,i)    = [beta*lambda*rho./(1-beta*lambda*rho).*hv(i),0,0];
    K0(:,:,i)    = f0/f2.*L(i)./(1-lambda.*L(i)).*X0(:,:,i);
    Y0(:,:,i)    = f0.*K0(:,:,i);
    P0(:,:,i)    = -b1.*Y0(:,:,i) + [hv(i),0,0]; % Aggregate price level
    Ptil0(:,:,i) = [hv(i),hn(i),0] - b1.*Y0(:,:,i);
end
K0t    = real(ifft(K0,[],3));
Y0t    = real(ifft(Y0,[],3));
P0t    = real(ifft(P0,[],3));
F0t    = real(ifft(F0,[],3));
Ptil0t = real(ifft(Ptil0,[],3));

% -------------------------------------------------------------------------
% Dispersed information with exogenous signals
% -------------------------------------------------------------------------

% Law of motion of observation process
M1    = zeros(2,3,n);
M1M1p = zeros(2,2,n);
for i = 1:n
    M1(:,:,i) = [hv(i),0,he(i);hv(i),hn(i),0];
    M1M1p(:,:,i) = M1(:,:,i)*M1(:,:,i)';
end

% Find Wold representation
[Gamma1,Gamma1t]  = wold(M1M1p,n);
Gamma1_betalambda = ma_sum(Gamma1t,beta*lambda);

%Get implied alm
target1 = zeros(1,3,n);
alm1    = zeros(1,2,n);
for i = 1:n
    target1(:,:,i) = beta*lambda./(L(i) - beta*lambda)*[1,0]*(Gamma1(:,:,i) - Gamma1_betalambda)*pinv(Gamma1(:,:,i))*M1(:,:,i);
    alm1(:,:,i)    = [hv(i),hn(i)] - b1*f0^2/f2.*L(i)./(1-lambda.*L(i)).*target1(:,1:2,i);
end

% Higher-order expectations?
if plot_figs
    J       = 6;
    theta1  = zeros(1,2,n,J);
    theta1t = zeros(1,2,n,J);

    % Initialize zeroth order expectation
    for i = 1:n
        theta1(:,:,i,1)  = [hv(i),0];
    end

    % Recursion
    for j = 1:J-1
        for i = 1:n
            inside(:,:,i) = ([theta1(:,:,i,j),0]*M1(:,:,i)')*pinv(Gamma1(:,:,i)');
        end
        insidet                = ifft(inside,[],3);
        insidet(:,:,n/2+1:end) = 0;
        inside_plus            = fft(insidet,[],3);
        for i = 1:n
            theta1(:,:,i,j+1) = inside_plus(:,:,i)*pinv(Gamma1(:,:,i))*[hv(i),0;hv(i),hn(i)];
        end
    end

    for j = 1:J
        theta1t(:,:,:,j) = real(ifft(theta1(:,:,:,j),[],3));
    end

end

% Laws of motion for aggregates
K1    = zeros(1,3,n);
Y1    = zeros(1,3,n);
P1    = zeros(1,3,n);
Ptil1 = zeros(1,3,n);
F1    = zeros(1,3,n);
for i = 1:n
    K1(:,:,i)    = f0/f2.*L(i)./(1-lambda.*L(i)).*[target1(:,1:2,i),0];
    Y1(:,:,i)    = f0.*K1(:,:,i);
    P1(:,:,i)    = -b1.*Y1(:,:,i) + [hv(i),0,0];
    Ptil1(:,:,i) = [hv(i),hn(i),0] - b1.*Y1(:,:,i);
    F1(:,:,i)    = [hv(i),0,0] - (1-beta*lambda*rho)/(beta*lambda*rho).*[target1(:,1:2,i),0];
end
K1t    = real(ifft(K1,[],3));
Y1t    = real(ifft(Y1,[],3));
P1t    = real(ifft(P1,[],3));
F1t    = real(ifft(F1,[],3));
Ptil1t = real(ifft(Ptil1,[],3));

% -------------------------------------------------------------------------
% Dispersed information with endogenous signals
% -------------------------------------------------------------------------

% Initial plm
plm = Ptil1(1,1:2,:);
K    = zeros(1,3,n);
Y    = zeros(1,3,n);
P    = zeros(1,3,n);
Ptil = zeros(1,3,n);
F    = zeros(1,3,n);

% Iteration loop
tol     = 1e-12;
maxiter = 1e3;
err     = 1;
iter    = 1;
M   = zeros(2,3,n); MMp = zeros(2,2,n);target = zeros(1,3,n);alm    = zeros(1,2,n);
while err > tol && iter < maxiter

    % Law of motion of observation process
    for i = 1:n
        M(:,:,i)   = [hv(i),0,he(i);plm(:,:,i),0];
    end

    %Predict fundamental to get K(i,t+1)
    K_f  = (f0/f2).*L./(1-lambda*L).*freq_proj(beta*lambda.*L.^-1./(1-beta*lambda*L.^-1).*M(1,:,:),M,L);
  
    Y(1,1:2,:)    = f0.*K_f(1,1:2,:);
    P(1,1:2,:)    = -b1.*Y(1,1:2,:); P(1,1,:) = P(1,1,:) + hv;
    Ptil(1,1:2,:) = P(1,1:2,:);
    Ptil(1,2,:)   = Ptil(1,2,:) + hn;

    %Get implied alm
    alm = Ptil(1,1:2,:);
  
    % Diplay error
    err = norm(alm(:)-plm(:));
    disp(num2str([iter,err]));

    % Update
    rlx = .9;
    plm  = rlx*plm + (1-rlx)*alm; iter = iter + 1;
end
disp(num2str([iter,err]));

% Compute higher order expectations?
if plot_figs
   
    theta  = zeros(1,2,n,J);
    thetat = zeros(1,2,n,J);

    % Initialize zeroth order expectation
    for i = 1:n
        theta(:,:,i,1)  = [hv(i),0];
    end

    % Recursion
    for j = 1:J-1
        for i = 1:n
            inside(:,:,i) = ([theta(:,:,i,j),0]*M(:,:,i)')*pinv(Gamma(:,:,i)');
        end
        insidet                = ifft(inside,[],3);
        insidet(:,:,n/2+1:end) = 0;
        inside_plus            = fft(insidet,[],3);
        for i = 1:n
            theta(:,:,i,j+1) = inside_plus(:,:,i)*pinv(Gamma(:,:,i))*[hv(i),0;alm(:,:,i)];
        end
    end

    for j = 1:J
        thetat(:,:,:,j) = real(ifft(theta(:,:,:,j),[],3));
    end

end

% Laws of motion for aggregates
K    = zeros(1,3,n);
Y    = zeros(1,3,n);
P    = zeros(1,3,n);
Ptil = zeros(1,3,n);
F    = zeros(1,3,n);
for i = 1:n
    K(:,:,i)    = f0/f2.*L(i)./(1-lambda.*L(i)).*[target(:,1:2,i),0];
    Y(:,:,i)    = f0.*K(:,:,i);
    P(:,:,i)    = -b1.*Y(:,:,i) + [hv(i),0,0];
    Ptil(:,:,i) = [hv(i),hn(i),0] - b1.*Y(:,:,i);
    F(:,:,i)    = [hv(i),0,0] - (1-beta*lambda*rho)/(beta*lambda*rho).*[target(:,1:2,i),0];
end
Kt    = real(ifft(K,[],3));
Yt    = real(ifft(Y,[],3));
Pt    = real(ifft(P,[],3));
Ft    = real(ifft(F,[],3));
Ptilt = real(ifft(Ptil,[],3));

%%
if plot_figs

    %% Plot results for output
    fig = figure(3);
    h   = 15;
    ind = 1:h+1;

    subplot(3,2,1);
    plot(0:h,squeeze(Y0t(1,1,ind)),'-k'); hold on;
    plot(0:h,squeeze(Y1t(1,1,ind)),'-xk');
    plot(0:h,squeeze(Yt(1,1,ind)),'-ok');
    ylabel('$y_t$','interpreter','latex','FontSize',14);
    title('$v_t$','interpreter','latex','FontSize',14);

    subplot(3,2,2);
    plot(0:h,squeeze(Y0t(1,2,ind)),'-k'); hold on;
    plot(0:h,squeeze(Y1t(1,2,ind)),'-xk');
    plot(0:h,squeeze(Yt(1,2,ind)),'-ok');
    title('$\eta_t$','interpreter','latex','FontSize',14);
    ylim([-0.01,inf]);

    subplot(3,2,3);
    plot(0:h,squeeze(P0t(1,1,ind)),'-k');hold on;
    plot(0:h,squeeze(P1t(1,1,ind)),'-xk');
    plot(0:h,squeeze(Pt(1,1,ind)),'-ok');
    ylabel('$p_t$','interpreter','latex','FontSize',14);
    ylim([-0.01,inf]);

    subplot(3,2,4);
    plot(0:h,squeeze(P0t(1,2,ind)),'-k'); hold on;
    plot(0:h,squeeze(P1t(1,2,ind)),'-xk');
    plot(0:h,squeeze(Pt(1,2,ind)),'-ok');
    ylim([-inf,0.01]);

    subplot(3,2,5);
    plot(0:h,-squeeze(F0t(1,1,ind)),'-k');  hold on;
    plot(0:h,-squeeze(F1t(1,1,ind)),'-xk');
    plot(0:h,-squeeze(Ft(1,1,ind)),'-ok');
    ylabel('$\bar{E}_t\theta_t - \theta_t$','interpreter','latex','FontSize',14);
    ylim([-inf,0.05]);

    subplot(3,2,6);
    plot(0:h,-squeeze(F0t(1,2,ind)),'-k'); hold on;
    plot(0:h,-squeeze(F1t(1,2,ind)),'-xk');
    plot(0:h,-squeeze(Ft(1,2,ind)),'-ok');
    leg = legend('full information','exogenous signal','endogenous signal');
    set(leg,'box','off','location','northeast','FontSize',11);
    ylim([-0.05,inf]);

    % Print
    dim = [6,2.5*2];
    set(gcf,'paperpositionmode','manual','paperunits','inches');
    set(gcf,'papersize',dim,'paperposition',[0,0,dim]);
    exportgraphics(fig, 'output_figures/endo_comp.pdf','Resolution',1200);



   
%%
    fig = figure(4);
    h   = 6;
    ind = 1:h+1;

    styles = {'-',':','-.','--',':','-.','--',':','-.','--',':','-.','--'};

    subplot(2,2,1);
    for j = 1:J
        plot(0:h,squeeze(theta1t(1,1,ind,j)),'color','k','linestyle',styles{j}); hold on;
    end
    title('$v_t$','interpreter','latex','FontSize',14);
    ylabel('exogenous signal', 'FontSize',12);

    subplot(2,2,2);
    for j = 1:J
        plot(0:h,squeeze(theta1t(1,2,ind,j)),'color','k','linestyle',styles{j}); hold on;
        labels{j} = ['k = ',num2str(j-1)];
    end
    leg = legend(labels{:});
    set(leg,'box','off');
    title('$\eta_t$','interpreter','latex', 'FontSize',14);
    ylim([-0.1,inf]);
    leg.FontSize = 11;

    subplot(2,2,3);
    for j = 1:J
        plot(0:h,squeeze(thetat(1,1,ind,j)),'color','k','linestyle',styles{j}); hold on;
    end
    ylabel('endogenous signal', 'FontSize',12);

    subplot(2,2,4);
    for j = 1:J
        plot(0:h,squeeze(thetat(1,2,ind,j)),'color','k','linestyle',styles{j}); hold on;
    end
    ylim([-0.1,inf]);

    dim = [6,2.5*2*2/3];
    set(gcf,'paperpositionmode','manual','paperunits','inches');
    set(gcf,'papersize',dim,'paperposition',[0,0,dim]);
    exportgraphics(fig, 'output_figures/endo_comp_hoe.pdf','Resolution',1200);


end

