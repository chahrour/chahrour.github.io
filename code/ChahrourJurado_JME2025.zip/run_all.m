% RUN_ALL
%
% Runs all code and replicates figures from "Revisting the Expectations of Others"
% by Chahrour & Jurado, May 6 2025.

% Add key toolbox
addpath('freq_toolbox')

%% Figure 1: solution of N sector Townsend model
fce_ree_n3

%% Figure 2-3: solutions to many-sector Townsend model
n = 2500;
plot_figs = true;
solve_townsend;

%% Figue 4: compare to low-order ARMA fitted processes
% ARMA fit of LOM
arma_compare

%% Figure 5: compare to Zhan et Al Method. 
% (Note that figure will different depending on processor used/load/etc)
plot_figs = true;
compare_methods;

