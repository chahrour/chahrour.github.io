
% Add path
addpath('freq_toolbox')
warning off 
%% Kyle and Ryan Method
ngrid = [100:100:700,2500];

ng = numel(ngrid);

times = zeros(1,ng);
ptcell = cell(1,ng);
ytcell = cell(1,ng);
plot_figs = false;
for jj = 1:ng
    n = ngrid(jj);
    tic
    solve_townsend
    times(jj) = toc;
    ptcell{jj} = Pt;
    ytcell{jj} = Yt;
end


%% Zhao et al
addpath('ztran-main'); addpath('ztran-main/classes');addpath('ztran-main/m')
pq = [1 1; 2 2; 3 3; 4 4; 5 5; 6 6; 7 7];

npq = length(pq);
times_z = zeros(1,npq);
ptcell_z = cell(1,npq);
for jj = 1:npq
    pqz = pq(jj,:);
    tic
    solve_townsend_han_et_al
    times_z(jj) = toc;
    ptcell_z{jj} = res;
end

rmpath('ztran-main');rmpath('ztran-main/classes');rmpath('ztran-main/m')
%% Compute errs relative to best solution
errs = zeros(1,ng);
errs_a = zeros(1,ng);
for jj = 1:7
    errs(jj) = sqrt(sum(vec((ptcell{jj}(1,1:2,1:50)-ptcell{end}(1,1:2,1:50)).^2)) + ...
               0*sum(vec(0-ptcell{end}(1,1:2,ngrid(jj)/2+1:1250)).^2));
end

errs_z = zeros(1,npq);
for jj = 1:npq
    tmp = ptcell_z{jj}(3,1:2,1:50);
    tmp(1,2,1) = 0;  %Take out the nose
    errs_z(jj) = sqrt(sum(vec((tmp - ptcell{end}(1,1:2,1:50)).^2)));
end

save output_figures/fig_data errs times errs_z times_z ngrid pq
%%

load output_figures/fig_data
f = figure(2);
s = subplot(1,1,1);
plot(errs,times,'-kx'); hold on
plot(errs_z,times_z,'-ko');

%plot(errs_a,times_a,'-kv','linewidth',2);
xlabel('approximation error','fontsize',14, 'interpreter','latex'); ylabel('time (seconds)','fontsize',14, 'interpreter','latex'); hold on;
%d = plot(1e-4,t0, 'v', 'MarkerSize',10, 'color','k','MarkerFaceColor','k');
s.XScale = 'log';
s.YScale = 'log';
s.XLim = [exp(-38),1];
s.YLim = [.6, 20];
set(gca, 'XDir','reverse')
legend('proposed algorithm', 'Han et al. (2022)', 'fontsize',11,'location','northeast', 'interpreter', 'latex');


x1 = errs*2.5;
y1 = times*.92;

y1(1) = y1(1)*1.2;

x1(4) = x1(4)*1.2;

x1(5) = x1(5)*.4;
y1(5) = y1(5)*1.02;

x1(6) = x1(6)*.25;
y1(6) = y1(6)*1.1;

x1(7) = x1(7)*.25;
y1(7) = y1(7)*1.1;
for jj = 1:7
    text(x1(jj),y1(jj),['n = ' num2str(ngrid(jj))])
end

x2 = errs_z*1.02;
y2 = times_z*.92;

x2(3) = x2(3)*8;
y2(3) = y2(3)*1.20;


y2(4) = y2(4)*1.22;

x2(5) = x2(5)*1.25;

x2(6) = x2(6)*.7;
y2(6) = y2(6)*1.05;

x2(7) = x2(7)*.6;
y2(7)= y2(7)*1.1
for jj = 1:7
    text(x2(jj),y2(jj),['p = ' num2str(jj)])
end


s.Position = [0.1300 0.1300 0.8 0.7];
exportgraphics(f, 'output_figures/zhan_al_compare.pdf','Resolution',1200);

