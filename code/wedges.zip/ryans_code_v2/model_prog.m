function [f fx fy fxp fyp eta R set dgam_dtheta deta_dtheta dR_dtheta] = model_prog(param, set)

%Assign parameter values to named variables.
taus = param(1);
bet = param(2);
alph = param(3);
xi = param(4);
epps = param(5);
rho = param(6);
nbar = param(7);
phi = param(8);
gbar = param(9);
urbar = param(10);
rho11 = param(11);
rho12 = param(12);
rho13 = param(13);
rho14 = param(14);
rho15 = param(15);
rho21 = param(16);
rho22 = param(17);
rho23 = param(18);
rho24 = param(19);
rho25 = param(20);
rho31 = param(21);
rho32 = param(22);
rho33 = param(23);
rho34 = param(24);
rho35 = param(25);
rho41 = param(26);
rho42 = param(27);
rho43 = param(28);
rho44 = param(29);
rho45 = param(30);
rho51 = param(31);
rho52 = param(32);
rho53 = param(33);
rho54 = param(34);
rho55 = param(35);
kappa = param(36);
gam = param(37);
g = param(38);
vbar = param(39);

%Assign set values to named variables.
adiff = set(1);

%BEGIN_EXTRACT_HERE
ebar = 1-urbar;

s = nbar*(1/ebar - 1 + rho);
kh = rho*nbar/s;
thet = kh^(1/(1-xi));
v = s*thet;
chi = 1/(1-xi)*thet^xi - bet*(1-rho)*(1-xi*thet^(1-xi))/((1-xi)*thet^-xi);
gam = (1-alph)*nbar^-alph/chi;

c = nbar^(1-alph)*(1-gbar) - gam*v;  %RC constraint

gam*v/(nbar^(1-alph));

lfp = nbar + (1-kh)*s;

kappa = 1/taus*gam*xi/(1-xi)*thet*lfp^(-1/epps)/c;

g = gbar*nbar^(1-alph);

er = nbar; %nbar/(nbar+(1-kh)*s);
vbar = v;
Yss = [nbar c s v thet  c/(nbar^(1-alph)) lfp er   kh gbar taus];
Xss = [nbar 1 1 taus 1 g]; 


%END_EXTRACT_HERE
%Compute Steady State
NL= Xss(1);
Z= Xss(2);
GAM= Xss(3);
TAUS= Xss(4);
TAUD= Xss(5);
G= Xss(6);
N= Yss(1);
C= Yss(2);
S= Yss(3);
V= Yss(4);
THET= Yss(5);
CY= Yss(6);
LFP= Yss(7);
ER= Yss(8);
JFR= Yss(9);
GY= Yss(10);
TAUN= Yss(11);
NL_p= Xss(1);
Z_p= Xss(2);
GAM_p= Xss(3);
TAUS_p= Xss(4);
TAUD_p= Xss(5);
G_p= Xss(6);
N_p= Yss(1);
C_p= Yss(2);
S_p= Yss(3);
V_p= Yss(4);
THET_p= Yss(5);
CY_p= Yss(6);
LFP_p= Yss(7);
ER_p= Yss(8);
JFR_p= Yss(9);
GY_p= Yss(10);
TAUN_p= Yss(11);

%Evaluate F.
f = [[C*LFP^(1/epps)*TAUS*kappa + (THET^xi*THET^(1 - xi)*xi*(gam + phi*(V - vbar)^2 + V*phi*(2*V - 2*vbar)))/(xi - 1), TAUD*((THET^xi*(gam + phi*(V - vbar)^2 + V*phi*(2*V - 2*vbar)))/(GAM*(xi - 1)) - (C*THET_p^xi*bet*(GAM_p*THET_p^(1 - xi)*xi - 1)*(rho - 1)*(gam + phi*(V_p - vbar)^2 + V_p*phi*(2*V_p - 2*vbar)))/(C_p*GAM_p*(xi - 1))) - (Z*(alph - 1))/N^alph, C + G + V*(gam + phi*(V - vbar)^2) - N^(1 - alph)*Z, N + NL*(rho - 1) - GAM*S^xi*V^(1 - xi), log(Z_p) - rho12*log(GAM) - rho14*log(TAUD) - rho11*log(Z) - rho15*log(G/g) - rho13*log(TAUS/taus), log(GAM_p) - rho22*log(GAM) - rho24*log(TAUD) - rho21*log(Z) - rho25*log(G/g) - rho23*log(TAUS/taus), log(TAUS_p/taus) - rho32*log(GAM) - rho34*log(TAUD) - rho31*log(Z) - rho35*log(G/g) - rho33*log(TAUS/taus), log(TAUD_p) - rho42*log(GAM) - rho44*log(TAUD) - rho41*log(Z) - rho45*log(G/g) - rho43*log(TAUS/taus), log(G_p/g) - rho52*log(GAM) - rho54*log(TAUD) - rho51*log(Z) - rho55*log(G/g) - rho53*log(TAUS/taus), THET - V/S, NL_p - N, CY - (C*N^(alph - 1))/Z, LFP - N + S*(JFR - 1), ER - N, JFR - (GAM*S^xi*V^(1 - xi))/S, GY - (G*N^(alph - 1))/Z, TAUN - TAUD*TAUS]];
%Evaluate derivative expressions.
fx = [[0, 0, 0, C*LFP^(1/epps)*TAUS*kappa, 0, 0]; [0, -(Z*(alph - 1))/N^alph, -(TAUD*THET^xi*(gam + phi*(V - vbar)^2 + V*phi*(2*V - 2*vbar)))/(GAM*(xi - 1)), 0, TAUD*((THET^xi*(gam + phi*(V - vbar)^2 + V*phi*(2*V - 2*vbar)))/(GAM*(xi - 1)) - (C*THET_p^xi*bet*(GAM_p*THET_p^(1 - xi)*xi - 1)*(rho - 1)*(gam + phi*(V_p - vbar)^2 + V_p*phi*(2*V_p - 2*vbar)))/(C_p*GAM_p*(xi - 1))), 0]; [0, -N^(1 - alph)*Z, 0, 0, 0, G]; [NL*(rho - 1), 0, -GAM*S^xi*V^(1 - xi), 0, 0, 0]; [0, -rho11, -rho12, -rho13, -rho14, -rho15]; [0, -rho21, -rho22, -rho23, -rho24, -rho25]; [0, -rho31, -rho32, -rho33, -rho34, -rho35]; [0, -rho41, -rho42, -rho43, -rho44, -rho45]; [0, -rho51, -rho52, -rho53, -rho54, -rho55]; [0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0]; [0, (C*N^(alph - 1))/Z, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0]; [0, 0, -(GAM*S^xi*V^(1 - xi))/S, 0, 0, 0]; [0, (G*N^(alph - 1))/Z, 0, 0, 0, -(G*N^(alph - 1))/Z]; [0, 0, 0, -TAUD*TAUS, -TAUD*TAUS, 0]];
fy = [[0, LFP^(1/epps)*TAUS*kappa, 0, (THET^xi*THET^(1 - xi)*xi*(2*V*phi + 2*phi*(2*V - 2*vbar)))/(xi - 1), (xi^2*(gam + phi*(V - vbar)^2 + V*phi*(2*V - 2*vbar)))/(xi - 1) - xi*(gam + phi*(V - vbar)^2 + V*phi*(2*V - 2*vbar)), 0, (C*LFP^(1/epps - 1)*TAUS*kappa)/epps, 0, 0, 0, 0]; [(Z*alph*(alph - 1))/N^(alph + 1), -(TAUD*THET_p^xi*bet*(GAM_p*THET_p^(1 - xi)*xi - 1)*(rho - 1)*(gam + phi*(V_p - vbar)^2 + V_p*phi*(2*V_p - 2*vbar)))/(C_p*GAM_p*(xi - 1)), 0, (TAUD*THET^xi*(2*V*phi + 2*phi*(2*V - 2*vbar)))/(GAM*(xi - 1)), (TAUD*THET^(xi - 1)*xi*(gam + phi*(V - vbar)^2 + V*phi*(2*V - 2*vbar)))/(GAM*(xi - 1)), 0, 0, 0, 0, 0, 0]; [(Z*(alph - 1))/N^alph, 1, 0, gam + phi*(V - vbar)^2 + V*phi*(2*V - 2*vbar), 0, 0, 0, 0, 0, 0, 0]; [1, 0, -GAM*S^(xi - 1)*V^(1 - xi)*xi, (GAM*S^xi*(xi - 1))/V^xi, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, V/S^2, -1/S, 1, 0, 0, 0, 0, 0, 0]; [-1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [-(C*N^(alph - 2)*(alph - 1))/Z, -N^(alph - 1)/Z, 0, 0, 0, 1, 0, 0, 0, 0, 0]; [-1, 0, JFR - 1, 0, 0, 0, 1, 0, S, 0, 0]; [-1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0]; [0, 0, (GAM*S^xi*V^(1 - xi))/S^2 - (GAM*S^(xi - 1)*V^(1 - xi)*xi)/S, (GAM*S^xi*(xi - 1))/(S*V^xi), 0, 0, 0, 0, 1, 0, 0]; [-(G*N^(alph - 2)*(alph - 1))/Z, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]];
fxp = [[0, 0, 0, 0, 0, 0]; [0, 0, TAUD*((C*THET_p^xi*bet*(GAM_p*THET_p^(1 - xi)*xi - 1)*(rho - 1)*(gam + phi*(V_p - vbar)^2 + V_p*phi*(2*V_p - 2*vbar)))/(C_p*GAM_p*(xi - 1)) - (C*THET_p^xi*THET_p^(1 - xi)*bet*xi*(rho - 1)*(gam + phi*(V_p - vbar)^2 + V_p*phi*(2*V_p - 2*vbar)))/(C_p*(xi - 1))), 0, 0, 0]; [0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0]; [0, 1, 0, 0, 0, 0]; [0, 0, 1, 0, 0, 0]; [0, 0, 0, 1, 0, 0]; [0, 0, 0, 0, 1, 0]; [0, 0, 0, 0, 0, 1]; [0, 0, 0, 0, 0, 0]; [NL_p, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0]];
fyp = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, (C*TAUD*THET_p^xi*bet*(GAM_p*THET_p^(1 - xi)*xi - 1)*(rho - 1)*(gam + phi*(V_p - vbar)^2 + V_p*phi*(2*V_p - 2*vbar)))/(C_p^2*GAM_p*(xi - 1)), 0, -(C*TAUD*THET_p^xi*bet*(2*V_p*phi + 2*phi*(2*V_p - 2*vbar))*(GAM_p*THET_p^(1 - xi)*xi - 1)*(rho - 1))/(C_p*GAM_p*(xi - 1)), TAUD*((C*bet*xi*(rho - 1)*(gam + phi*(V_p - vbar)^2 + V_p*phi*(2*V_p - 2*vbar)))/C_p - (C*THET_p^(xi - 1)*bet*xi*(GAM_p*THET_p^(1 - xi)*xi - 1)*(rho - 1)*(gam + phi*(V_p - vbar)^2 + V_p*phi*(2*V_p - 2*vbar)))/(C_p*GAM_p*(xi - 1))), 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]];

eta = [[0, 0, 0, 0, 0]; [1/100, 0, 0, 0, 0]; [0, 1/200, 0, 0, 0]; [0, 0, 1/200, 0, 0]; [0, 0, 0, 1/200, 0]; [0, 0, 0, 0, 1/200]];
R = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]; [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]];
