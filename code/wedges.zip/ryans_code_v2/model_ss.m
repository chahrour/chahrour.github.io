% MODEL_SS - Return the steady state of the model computed analytically
%
% usage:
%
% [ss, parameters] =model_ss(param)


function [Yss, Xss, param,set] = model_ss(param, set)


%This loop assigns values to variables with the same names as the fields in
%param.
nms = fieldnames(param);
for j = 1:length(nms)
    eval([nms{j} '='  'param.' nms{j} ';'])
end

set_list = fieldnames(set);
set_val = struct2array(set);
for j = 1:length(set_list)-2
    eval([set_list{j} '= set_val(j);']);
end


%BEGIN_EXTRACT_HERE
ebar = 1-urbar;

s = nbar*(1/ebar - 1 + rho);
kh = rho*nbar/s;
thet = kh^(1/(1-xi));
v = s*thet;
chi = 1/(1-xi)*thet^xi - bet*(1-rho)*(1-xi*thet^(1-xi))/((1-xi)*thet^-xi);
gam = (1-alph)*nbar^-alph/chi;

c = nbar^(1-alph)*(1-gbar) - gam*v;  %RC constraint

gam*v/(nbar^(1-alph));

lfp = nbar + (1-kh)*s;

kappa = 1/taus*gam*xi/(1-xi)*thet*lfp^(-1/epps)/c;

g = gbar*nbar^(1-alph);

er = nbar; %nbar/(nbar+(1-kh)*s);
vbar = v;
Yss = [nbar c s v thet  c/(nbar^(1-alph)) lfp er   kh gbar taus];
Xss = [nbar 1 1 taus 1 g]; 


%END_EXTRACT_HERE
