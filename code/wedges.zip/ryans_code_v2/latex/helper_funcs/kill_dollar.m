function out = kill_dollar(t)

if iscell(t)
   nt = size(t,1)*size(t,2);
   out = cell(size(t,1),size(t,2));
   for j = 1:nt
       out{j} = kill_dollar_help(t{j});
   end
else
    
    out = kill_dollar_help(t);
end


function out = kill_dollar_help(t)



idx = ('$'==t) + ('%' == t) + ('&' == t);

nd = sum(idx);

if nd > 0



    out = char(length(t)+nd);


    idx = find(idx);
    xtra = 0;

    out(1:idx(1)+xtra-1) = t(1:idx(1)-1);

    for j = 1:length(idx)-1;

        out(idx(j)+xtra) = '\';
        xtra = xtra+1;
        out(idx(j)+xtra:idx(j+1)+xtra-1) = t(idx(j):idx(j+1)-1);

    end
    out(idx(end)+xtra) = '\';
    xtra = xtra+1;
    out(idx(end)+xtra:length(t)+xtra) = t(idx(end):end);

else
    out = t;
end
