% This program takes an m-file and prints to printer using latex.  You can 
% also use it create a latex version of your code.  Or enter a vector
% limit the number of lines printed.
%
% Usage:
% publish_mfile(mfile, 'no m')

function publish_mfile(mfile, varargin)

if ~isempty(varargin) && strcmp('no m', varargin(1))
    fid= fopen (mfile, 'r');
elseif ~strcmp('.', mfile(end-3))
    fid= fopen ([mfile,'.m',], 'r');
else
    fid= fopen (mfile, 'r');
end

output = fopen ([mfile,'.tex'],'w');

fprintf(output,'%s\n','\documentclass{article}');
fprintf(output,'%s\n','\usepackage{graphicx}');
fprintf(output,'%s\n','\usepackage{color}');
fprintf(output,'%s\n','\sloppy');
fprintf(output,'%s\n','\definecolor{lightgray}{gray}{0.5}');
fprintf(output,'%s\n','\setlength{\parindent}{0pt}');
fprintf(output,'%s\n','\oddsidemargin=-10mm');
fprintf(output,'%s\n','\topmargin=-20mm');
fprintf(output,'%s\n','\begin{document}');



fprintf(output,'%s\n','\begin{verbatim}');

fprintf(output, '%s\n\n', [mfile,'.m']);

line = fgets(fid);
while line~= -1
    fprintf(output, '%s', line);
    line = fgets(fid);
end

fprintf(output,'%s\n','\end{verbatim}');
fprintf(output,'%s\n','\end{document}');

fclose(output);
fclose(fid);

eval(['!latex ' mfile]);

a = input('Print Now?');

if a == 1
    eval(['!dvips ' mfile]);
end
end
    

