%This functions creates a data structure that contain all the format information for a latex table.
%Usage:
%struct = table_format(format_file)
%
%Note: Enter argument 'def' to use default format file.

function p = table_format(varargin)

    %This section of the code gets all the format variable from the format
    %fle
    if strcmp(varargin{1},'def')
        %Default format field
        format = fopen([home_dir, 'ryan_lib/latex/table_format_file'], 'r');
        p.file = [home_dir, 'ryan_lib/latex/table_format_file'];
    else
        try
            format = fopen(varargin{1}, 'r');
            p.file = varargin{1};
        catch
            error('Invalid file format file name or file path');
        end
    end
    
    %Gets vertical and horizontal line info from format file.
    %Must be first and second arguments in format file.
    p.vert_lines = str2num(next_arg(format));
    p.horiz_lines = str2num(next_arg(format));
    
    %Get multicol titles.
    i = 1;
    p.multicol{i} = next_arg(format);
    while ~strcmp(p.multicol{i}, ' last')
        i = i+1;
        p.multicol{i} = next_arg(format);
    end
    
    %Get Multicol text format
    p.multicol_text = next_arg(format);
    
    
    %Gets shading info
    p.row_shade = next_arg(format);
    
    %Get Header info
    p.headers = str2num(next_arg(format));
    p.header_style = next_arg(format);
    p.nonheader = next_arg(format);
    
    %Center or left justfied
    p.justify = next_arg(format);
    %p.justify = p.justify(1);   %Ensure only 1 char is picked up
    p.vert_just = next_arg(format);
    
    %Lanscape or not?
    p.landscape = next_arg(format);
    
    %Include Page Numbers?
    p.pages = next_arg(format);
    
    %Gets title font size
    p.font_size = next_arg(format);
    
    %Gets title text style
    p.text_style = next_arg(format);
    
    %Gets title buffers
    p.buff_up = next_arg(format);
    p.buff_down = next_arg(format);
    
    %Decimal Places and Total Digits Format Argument
    p.decimals = str2num(next_arg(format));
    p.digits = next_arg(format);
    p.parens =str2num(next_arg(format));
    p.parens_row = str2num(next_arg(format));
    
    
    %Pecentage Tolerances for *'s
    p.one_star = str2num(next_arg(format));
    p.two_star = str2num(next_arg(format));
    p.three_star =str2num(next_arg(format));
    
    p.label = next_arg(format);
    
    %Overide any options by hand?
    if length(varargin)>1
        p = override(p, varargin{2});
    end
    



function p = override(p,new)

newl = fieldnames(new);

for j = 1:length(newl)
    eval(['p.' newl{j}, '= new.' newl{j}, ';']);
end
    


