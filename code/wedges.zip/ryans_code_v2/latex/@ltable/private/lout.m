%Function that returns the relevant string for latex output.
%NaN and any string equal to 'blank' returns empty string.
%OTherwise a string is returned without changes and numbers
%a strings.  Use the parens arg to include parenthis around value.
%Usage:
%string = lout(input, format, parens)


function str = lout(input,format, varargin)

if  isempty(input) || sum(isnan(input))
    str = [];
elseif ischar(input)
    if strcmp(input,'blank')
        str = [];
    else
        str = input;
    end
else
    if ~isempty(varargin) & (varargin{1} == 1)
        str =['(', num2str(input,format),')'];
    else
        str = num2str(input,format);
    end

end
end
