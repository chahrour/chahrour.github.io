%**************************************************************************
% MAIN_PROG - Performs the computations for Social Planners search problem.
%
%**************************************************************************

disp(' ');
disp('STARTING NEW RUN...');
disp(' ');
%Add relevant paths
addpath([cd, '/Bayesian_Progs'])
addpath([cd, '/ts_box'])

ndrop = 0;

%import_data
load data_for_mainprog

dat = dat(1:5,:);

%Load model object and proceed
load model_object

%Load parameters from paramteres.m
[param,set] = parameters;
paramv      = struct2array(param);
setv        = struct2array(set);

%Get model derivatives
[f, fx, fy, fxp, fyp, eta, R]=model_prog(paramv,setv);

%Check steady-state
if max(abs(f))>1e-8
    disp('Warning: Non-zero steady-state');
    pause
end

%Solve model
[gx,hx] = gx_hx_alt(fy,fx,fyp,fxp);

%Select observables in model
S = zeros(1,size(fy,2));
S(1,cy_idx)  = 1;
S(2,gy_idx)  = 1;
S(3,v_idx)   = 1;
S(4,lfp_idx) = 1;
S(5,n_idx)   = 1;
no   = size(S,1);


%What are the shocks and observables
disp('SHOCKS:');disp(transpose(modl.X*modl.shck));
disp('OBSERVABLES:');disp(S*transpose(modl.Y));

%Smooth wedges, using iterative technique to pin down (rational) expectations
wdg_list = {'Z','GAM', 'TAUS', 'TAUD', 'G'};
wedge_idx = [z_idx,gam_idx,taus_idx,taud_idx,g_idx]-ny;
crit = 1; kk = 1;
bet_old = zeros(5);
while crit > 1e-9 && kk < 100

    %Resolve model with new exog process
    [f, fx, fy, fxp, fyp]=model_prog(paramv,setv);
    [gx,hx] = gx_hx_alt(fy,fx,fyp,fxp);
    
    %Smooth shocks
    [out,Ysmooth,Xsmooth,Xtt] = kalman_gh_smooth(S*gx,hx,eta,S*R*S',dat,ndrop);
    wedges = Xsmooth(wedge_idx,:)';
    
    %Perform VAR and impose on exogenous dynamics
    [bet,c,mu] = quick_var(wedges, 1);
    bet = .5*bet' + .5*bet_old;
    
    
    crit = max(max(abs(bet-bet_old)));
    disp(num2str(crit));
    bet_old = bet;
    
    %Impose on shock processes;
    eta(wedge_idx,1:end) = c;  %shocks
    
    for ii = 1:4;
        for jj = 1:4
            eval(['param.rho',num2str(ii), num2str(jj), '= bet(ii,jj);']);   
        end
    end
       
    paramv      = struct2array(param);
    kk = kk+1;
end

ts = cell(1,5);
for jj = 1:5
   ts{jj} = ts_make(wedges(:,jj),4,195101, wdg_list{jj});
   ts_plot(ts{jj});
end



ts_out('../wedges.xls', ts{:});

Ysmooth = gx*Xsmooth;
ts = ts_make(Ysmooth(taun_idx,:),4,195101, 'TAUN');
ts_plot(ts);


