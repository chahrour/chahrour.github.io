%*************************************
% SET UP THE MODEL_PROG.M FILE FOR THE
% MODEL SOLUTION
%*************************************

%Add relevant paths
addpath('Bayesian_Progs')
addpath('ts_box')

%Load Parameters
[param,set,rhosym] = parameters;

%Generate a mod object
modl = model(param,set,rhosym);

%Get dimensions of the model
nx = length(modl.X);
ny = length(modl.Y);
neps = size(modl.shck,2);
neq  = nx+ny;
np   = length(struct2array(param));

%Generate model file
model_func(modl);

%Save model object and idx variables
load v_idx
save  model_object modl *_idx ny neps rhosym

