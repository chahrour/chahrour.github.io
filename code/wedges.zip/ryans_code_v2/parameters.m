% PARAMETETRS - This function returns a parameter structure to use in the model solution.


function [param,set,rhosym] = parameters()

param.taus = 0.4;    %long-run static wedge

param.bet = .99;
param.alph = .3;      %share of fixed input. (labor share is 1-alph)
param.xi   = .5;      %s share in cobb-douglas matching function
param.epps  = .18;    %Frisch elasticity
param.rho  = .9999;   %Separation rate
param.nbar  = .2;     %long-run labor -> pins kappa
param.phi  = 0;       %vacancy posting costs

param.gbar = .2;      %long run share of g
param.urbar = .1;     %long run unemployment


%Make VAR coeffs for one-lag VAR
nwedge = 5;
rhosym = sym(zeros(nwedge));
for ii = 1:nwedge
    for jj = 1:nwedge
        eval(['param.rho',num2str(ii), num2str(jj), '= .9*(jj==ii);']);
        rhosym(ii,jj) = sym(['rho' num2str(ii), num2str(jj)]);
    end
end


%Determined in ss
param.kappa = NaN;  % disultility of labor scaling
param.gam   = NaN;  %linear cost of posting
param.g     = NaN;  %long run level of governemtn
param.vbar  = NaN;
set.adiff = 0;
%Degree of Approximation
set.me_eq = [NaN];      %Measurement Error to the 1st observation equation
set.approx_deg = 1;


