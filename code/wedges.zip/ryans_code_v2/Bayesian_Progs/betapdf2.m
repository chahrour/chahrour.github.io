%Mcuh faster than maltab's built in version.
function out = betpdf2(x,shape,scale)

alph = shape;
bet = scale;

out = x.^(alph-1).*(1-x).^(bet-1)./beta(alph,bet);