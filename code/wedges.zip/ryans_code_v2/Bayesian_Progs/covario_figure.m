function f = covario_figure(dat,mod,corr_opt,var_list,fig_title,varargin)

nv = length(var_list);

titles = cell(nv^2,1);
for k = 1:nv
    for l = 1:nv
        titles{l+nv*(k-1)} = [var_list{k} ' vs. '  var_list{l}];
    end
end

%Sort to get confidence
nsmp = size(mod,3);
mod = sort(mod,3);

m = median(mod,3);
l = mod(:,:,ceil(.025*nsmp));
h = mod(:,:,ceil(.975*nsmp));


dat(:,:,2) = m;
dat(:,:,3) = l;
dat(:,:,4) = h;
f = make_figure(dat, titles, corr_opt, fig_title, varargin{1}, varargin{2});

% Make Figure - Based on code of ir_figure.m
%
% usage
%
% fig_out = ir_fig(y,var_list, cor_opt, fig_title, lstyle(optional))
%
% where
%
% y = a TxN matrix of impulse responses
% var_list = name of the variables plotted
% fig_title = Title for entire figure
% lstyle = a cellarray of line style (eg 'r-*' means red, stared line). '-' is default.
% legend = a cellarray of titles for each IR plotted

function fig = make_figure(y, var_list, cor_opt, fig_title,  varargin)
lw = [1.3,1.3,1,1];
%Create figure, set size
fig = figure;
set(fig, 'PaperOrientation','landscape', 'PaperPosition', [.25, .25, 11,8]);


%Figure dimensions
n = length(var_list);
n_col = ceil(sqrt(n));
n_row = ceil(n/n_col);
n_slide = size(y,3);  %Are the confidence bands
if size(y,2) ~= n
    error('Unequal number of columns and variable titles');
end
t = size(y,1);

%Choose Line Style
if ~isempty(varargin)
    lstyle = varargin{1};
else
    lstyle = {'-'};
end

%ylim(1) = min(min(min(y))); ylim(1)= ylim(1) - .1*max(abs(ylim));
%ylim(2) = max(max(max(y))); ylim(2)= ylim(2) + .1*max(abs(ylim));
%Plot each IR
for j = 1:n
    s = subplot(n_row,n_col,j);
    hold on
    for k = 1:n_slide
        p = plot([1:t]', y(:,j,k), lstyle{k}, 'linewidth', lw(k));
    end
    plot([1:t]', 0*[1:t]', ':k');
    tt = title(var_list{j}, 'fontsize', 10);

    if j ==1
        xlabel('j')
        if cor_opt
            ylabel([ '\rho(x_t, x_{t+j})']);
        else
            ylabel([ '\sigma(x_t, x_{t+j})']);
        end
    end

    
    set(s, 'xlim', [1,t],'Xtick', [1:4:t],'XTickLabel', [0:4:t-1], 'fontsize', 8);
    %Legend
    if n_slide > 1 && ~isempty(varargin{2}) && j/n_col == 1


        l=legend(varargin{2}, 'Location', 'NorthEast', 'Fontsize', 10);
        %set(l, 'OuterPosition', [0.63 0.15 0.219 0.248], 'FontSize', 14,'Interpreter', 'tex')

        %set(l, 'location', 'southeastoutside');
        %set(l,'interpreter', 'latex', 'fontsize', 10, 'string',varargin{2});
    end
end

%Title on figure
if ~isempty(fig_title)
    suptitle(fig_title);
end


function hout=suptitle(str)
%SUPTITLE puts a title above all subplots.
%
%	SUPTITLE('text') adds text to the top of the figure
%	above all subplots (a "super title"). Use this function
%	after all subplot commands.
%
%   SUPTITLE is a helper function for yeastdemo.

%   Copyright 2003-2010 The MathWorks, Inc.


% Warning: If the figure or axis units are non-default, this
% will break.

% Parameters used to position the supertitle.

% Amount of the figure window devoted to subplots
plotregion = .92;

% Y position of title in normalized coordinates
titleypos  = .95;

% Fontsize for supertitle
fs = get(gcf,'defaultaxesfontsize')+4;

% Fudge factor to adjust y spacing between subplots
fudge=1;

haold = gca;
figunits = get(gcf,'units');

% Get the (approximate) difference between full height (plot + title
% + xlabel) and bounding rectangle.

if (~strcmp(figunits,'pixels')),
    set(gcf,'units','pixels');
    pos = get(gcf,'position');
    set(gcf,'units',figunits);
else
    pos = get(gcf,'position');
end
ff = (fs-4)*1.27*5/pos(4)*fudge;

% The 5 here reflects about 3 characters of height below
% an axis and 2 above. 1.27 is pixels per point.

% Determine the bounding rectangle for all the plots

% h = findobj('Type','axes');

% findobj is a 4.2 thing.. if you don't have 4.2 comment out
% the next line and uncomment the following block.

h = findobj(gcf,'Type','axes');  % Change suggested by Stacy J. Hills

max_y=0;
min_y=1;
oldtitle = NaN;
numAxes = length(h);
thePositions = zeros(numAxes,4);
for i=1:numAxes
    pos=get(h(i),'pos');
    thePositions(i,:) = pos;
    if (~strcmp(get(h(i),'Tag'),'suptitle')),
        if (pos(2) < min_y)
            min_y=pos(2)-ff/5*3;
        end;
        if (pos(4)+pos(2) > max_y)
            max_y=pos(4)+pos(2)+ff/5*2;
        end;
    else
        oldtitle = h(i);
    end
end

if max_y > plotregion,
    scale = (plotregion-min_y)/(max_y-min_y);
    for i=1:numAxes
        pos = thePositions(i,:);
        pos(2) = (pos(2)-min_y)*scale+min_y;
        pos(4) = pos(4)*scale-(1-scale)*ff/5*3;
        set(h(i),'position',pos);
    end
end

np = get(gcf,'nextplot');
set(gcf,'nextplot','add');
if ishghandle(oldtitle)
    delete(oldtitle);
end
axes('pos',[0 1 1 1],'visible','off','Tag','suptitle');
ht=text(.5,titleypos-1,str);set(ht,'horizontalalignment','center','fontsize',fs);
set(gcf,'nextplot',np);
axes(haold); %#ok<MAXES>
if nargout,
    hout=ht;
end



