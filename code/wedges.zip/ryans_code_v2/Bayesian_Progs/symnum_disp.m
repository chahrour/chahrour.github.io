function out = symnum_disp(x,xval)

s = [];
for j = 1:length(x)
    s = [s,sprintf('%s\t', char(x(j)))];
end
s2 = [];
for j = 1:length(x)
    s2 = [s2, sprintf('%1.2f\t', xval(j))];
end
disp(s)
disp(s2)