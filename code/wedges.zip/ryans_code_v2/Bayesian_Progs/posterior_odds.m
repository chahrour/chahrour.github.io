function marglik = posterior_odds(pchain,pval,set,S,data,ndrop,tau)


np = size(pchain,1);
nt = size(pchain,2);

stdz_pchn = stdz(pchain')';
V  = hac_autocov(stdz_pchn',1);
detV = log_det(V);
invV = inv(V);
M    = mean(stdz_pchn,2);


logf = nan(nt,1);
marglik = zeros(nt,1);
for jj = 1:nt
    %Compute the value of F
    logf(jj)  = fdens(stdz_pchn(:,jj),invV,M,detV,np,tau);
    idx_keep = ~isnan(logf);
    
    %Scale levls of F and L so that average log difference is zero
    const = mean(-logf(idx_keep) + pval(idx_keep));

    %the scaled statistic
    marglik(jj) = -log(mean(exp(logf(idx_keep) + const - pval(idx_keep)))) + const;
    
end

function out = fdens(param,invV,M,detV,np,tau)
trun = chi2inv(tau,np);
eterm = (param-M)'*invV*(param-M); 

if eterm>trun
    out = NaN;
else
    out = -log(tau) - np/2*log(2*pi) - 1/2*detV -1/2*eterm;
end


function out = log_det(M)
try
    C = chol(M);
    V = diag(C);
    out = 2*sum(log(V));
catch
    out = 1000;
end