function [shape,scale] = gamma_params(mu,sd)



k = (mu/sd)^2;
thet = mu/k;


shape = k;
scale = thet;
