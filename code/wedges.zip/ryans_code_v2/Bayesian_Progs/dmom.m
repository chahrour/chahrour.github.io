% DMOM - Function providing analytical derivatives of the contemporary covariances 
% SigX and SigY for a given model, generated using model_prog.
%
% usage
%
% [dsigx, dsigy, dh_dtheta, dg_dtheta, deta_dtheta, dR_dtheta] = dmom(param,set,S)
%
% where
% 
% param = the vector of parameters at which to comupute derivative
% set   = a vector of parameters that do not vary
% S     = a matrix selecting the desired rows of y_t

function [dsigx, dsigy, dh_dtheta, dg_dtheta, deta_dtheta, dR_dtheta, dgam_dtheta, g, h, eta, R] = dmom(param,set,S)

%In this case, tau = vec(hx;gx);
[f A2 B2 A1 B1 eta R set dgam_dtheta deta_dtheta dR_dtheta]=model_prog(param,set);

dgam_dtheta = sparse(dgam_dtheta);
deta_dtheta = sparse(deta_dtheta);
dR_dtheta = sparse(dR_dtheta);

[g,h,flag]=gx_hx_alt(B2,A2,B1,A1); 

nx = size(h,1);
ny = size(g,1);
nn = nx^2+ny*nx;

%Using the implicit function theorem, taking advantage of fact that GAM*A where GAM = [A1 B1 A2 B2].
A =   [h; g*h; speye(nx); g];
df_dtau = kron(speye(nx), (A1 + B1*g))*kron(eye(nx),[speye(nx), sparse(zeros(nx,ny))]) + (kron(speye(nx),B2) + kron(h',B1))*kron(speye(nx), [sparse(zeros(ny,nx)), speye(ny)]);
df_dtheta = kron(A',speye(nx+ny))*dgam_dtheta;
dtau_dtheta = -df_dtau\df_dtheta;

%Recreating dh/dtheta, dg/dtheta using a trick
idx = rem(1:nn,nx+ny); idx = [0, idx(1:end-1)];
dh_dtheta = dtau_dtheta(idx<nx,:);
dg_dtheta = dtau_dtheta(idx>=nx,:);

%Derivative of the moments
dhh2 = kron(kron(speye(nx), commute(nx,nx)),speye(nx))*(kron(speye(nx*nx),h(:)) + kron(h(:),speye(nx*nx)))*dh_dtheta;%d(h kron h)
dnn2 = (speye(nx*nx)+commute(nx,nx))*kron(eta,speye(nx))*deta_dtheta;


dhh2 = sparse(dhh2);
dnn2 = sparse(dnn2);

eta_eta = sparse(eta*eta');
tmp = sparse((speye(nx*nx)-kron(h,h))\speye(nx*nx));

dsigx1 = kron(eta_eta(:)'*tmp', speye(nx^2)*tmp)*dhh2;
dsigx2 = sparse((speye(nx^2)-kron(h,h))\dnn2);
dsigx = dsigx1+dsigx2;

%Do the computation for dsigy, using previous result
[~,sigx] = mom(g,h,eta*eta');
dgg2 = kron(kron(speye(nx), commute(nx,ny)),speye(ny))*(kron(speye(ny*nx),g(:)) + kron(g(:),speye(nx*ny)))*dg_dtheta;%d(g kron g)
dsigy  = kron(S,S)*(kron(g,g)*dsigx + kron(sigx(:)', speye(ny^2))*dgg2 + dR_dtheta);

%Return only dg_tilde, dR_tilde (only for those variables observed by econometrician)
dg_dtheta = kron(speye(nx), S)*dg_dtheta;
dR_dtheta = kron(S,S)*dR_dtheta;
g = S*g;
R = S*R*S';