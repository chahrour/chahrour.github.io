
%Using the build in mac functions
%mex -v kalman_gh_mex.c  -L/Applications/MATLAB_R2013a.app/bin/maci64 -L/usr/lib -lcblas -lclapack
%mex -v kalman_gh_mobs_mex.c  -L/Applications/MATLAB_R2013a.app/bin/maci64 -L/usr/lib -lcblas -lclapack

%using the matlab versions for clapack 
%mex -v kalman_gh_mobs_mex2.c  -L/Applications/MATLAB_R2012b.app/bin/maci64 -lmwlapack -L/usr/lib -lcblas 

%using the matlab versions for clapack and cblas
mex -v kalman_gh_mobs_mex3.c  -L/Applications/MATLAB_R2013a.app/bin/maci64 -lmwlapack -lmwblas

%mex -v gx_hx_mex3.c  -lmwlapack -lmwblas
