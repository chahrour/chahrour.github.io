#include <math.h>
#include <mex.h>
#include <lapack.h>
#include <blas.h>
#include <stdlib.h>

/* Input Arguments */

#define	G_IN	prhs[0]
#define	H_IN	prhs[1]
#define	eta_IN	prhs[2]
#define	R_IN	prhs[3]
#define	Y_IN	prhs[4]
#define	N_DROP_IN	prhs[5]

/* Output Arguments */

#define	LL_OUT	plhs[0]

#if !defined(MAX)
#define	MAX(A, B)	((A) > (B) ? (A) : (B))
#endif

#if !defined(MIN)
#define	MIN(A, B)	((A) < (B) ? (A) : (B))
#endif
static double p2 = 2*3.141592653589793238462643;

/* Prints an MxN matrix to Screen*/
void printmat_rowmaj(int m, int n, double M[m*n]){
    int x,y;
    int k = 0;
    printf("\n");
    for(x=0;x<m;x++){
        for(y=0;y<n;y++){
            printf("%1.7lf\t", M[k]);
            k++;
        }
        printf("%\n");
    }
    return;
}

/* Prints an MxN matrix to Screen*/
void printmat_colmaj(int m, int n, double M[m*n]){
    int x,y;
    printf("\n");
    for(x=0;x<m;x++){
        for(y=0;y<n;y++){
            printf("%1.7lf\t", M[y*m+x]);
        }
        printf("%\n");
    }
    return;
}

/* Prints an MxN matrix to Screen*/
void print_2darray(int m, int n, double M[m][n]){
    int x,y;
    printf("\n");
    for(x=0;x<m;x++){
        for(y=0;y<n;y++){
            printf("%1.3lf\t", M[x][y]);
        }
        printf("%\n");
    }
    return;
}


/*Prints a dim(N) vector to screen.*/
void print_dvec(int n, double M[]){
    int x;
    printf("\n");
    for(x=0;x<n;x++){
        printf("%1.4lf\t", M[x]);
    }
    printf("\n");
    return;
}

/*Prints a dim(N) vector to screen.*/
void print_ivec(int n, int M[]){
    int x;
    printf("\n");
    for(x=0;x<n;x++){
        printf("%i\t", M[x]);
    }
    printf("\n");
    return;
}

void subset_copy(int start_idx, int nx, double X[], double Y[nx]){
    int i = 0;
    for(i=0;i<nx;i++){
        Y[i] = X[start_idx+i];
    }
}

/*Compute the Determinant of a Pos-Def Matrix*/
double log_det(ptrdiff_t nx, double M[nx*nx]){
    
    double out=0;
    ptrdiff_t one = 1;
    /*Counters, Temp matrix*/
    int j;
    ptrdiff_t nxnx = nx*nx;
    double C[nxnx];
    
    /*LAPACK Input Args*/
    char uplo ={'u'};
    ptrdiff_t info;
    
    /*Copy matrix and take cholesky*/
    dcopy(&nxnx, M, &one, C, &one);
    dpotrf(&uplo, &nx, C, &nx, &info);
    
    
    /*Get Sum of log Diagonal */
    for(j=0;j<nx;j++){
        out = out+2*log(C[j*nx+j]);
    }
    
    
    /*Return*/
    return out;
}

/* Repear a matrix over and over*/
int repmat(int n_row, int n_col, int n_rep,double *F_, double *F){
    
    int x;
    int y;
    int n;
    int k;
    
    
    for (n=0;n<n_rep;n++) {
        k = 0;
        for (y=0;y<n_col;y++) {
            for (x=0;x<n_row;x++){
                F_[n*n_row*n_col + k] = F[k];
                /*printf("%lf\n", F[n_col*y + x]);*/
                k++;
            }
        }
    }
    return 0;
}

/*Sum the columns of a matrix*/
int col_sum(int m, int n, double *M_, double *M){
    int i,j;
    
    for (j=0;j<m;j++){
        M[j] = 0;
        for (i=0;i<n;i++)	M[j] += M_[j*m+i];
    }
    return 0;
}

/*Subtract two vectors*/
void v_sub(int n, double *M, double *M2, double *M_out){
    int j;
    for (j=0;j<n;j++) M_out[j] = M[j] - M2[j];
}


void lpack_test(ptrdiff_t nx, ptrdiff_t ny, ptrdiff_t neps, int nt, int ndrop, double *G, double *H, double *ETA, double *R, double *Y, double ll_tmp[]) {
    
    /*BLAS Constants*/
    char blasLeft = 'L';
    char blasUpper = 'U';
    char blasNoTrans = 'N';
    char blasTrans = 'T';
    char blasNonUnit = 'N';
    
    double zone[1];
    zone[0]= 1;
    double mone[1];
    mone[0]= -1;
    double zero[1];
    zero[0]= 0;
    double mp5[1];
    mp5[0] = -.5;
    
    /*Matric Dimensions*/
    ptrdiff_t nxnx = nx*nx;
    ptrdiff_t nyny = ny*ny;
    ptrdiff_t nxny = nx*ny;
    ptrdiff_t one = 1;
    
    /*Arguments for LAPACK*/
    char uplo ={'l'};
    ptrdiff_t info = 0;
    
    
    /*Variables used to compute LL*/
    double ll = 0;
    double detHPR = 0;
    double expval = 0;
    double tmp = 0;
    
    /*Counters Used for Loops*/
    int tt,jj,kk,rr;
    double crit = 1;
    
    /*Initialize with constant term included.*/
    double LL = 0;
    
    
    
    /*double H_sq[nxnx];*/
    double *H_sq = malloc(nxnx*sizeof(double));
    /*double Q[nxnx];*/
    double *Q = malloc(nxnx*sizeof(double));
    
    /*double P10[nxnx];*/
    double *P10 = malloc(nxnx*sizeof(double));
    
    
    /*double P11[nxnx];*/
    double *P11 = malloc(nxnx*sizeof(double));
    
    /*double P10n[nxnx];*/
    double *P10n = malloc(nxnx*sizeof(double));
    
    /*double hP11[nxnx];*/
    double *hP11 = malloc(nxnx*sizeof(double));
    

    double om10[nyny];
    double sigg[nxnx];
    double sigx[nxnx];
    double x10[nx];
    double yerr[ny];
    double omyerr[ny];
    double omgP[nxny];
    
    double P10_tmp[nxnx];
    double gP10[nxny]; 
    double sigg_tmp[nxnx];
    double sigx_tmp[nxnx];
    double sigx_tmp2[nxnx];
    double x10_tmp[nx];
    double yerr_tmp[ny];
    double om10_hold[nyny];
    double P10gomy[nx];
    
    
    /*Variables added for missing data functionality*/
    double Gj[ny*nx];
    double Rj[ny*ny];
    double Rjtmp[ny*ny];
    double Yj[ny];
    double yerrj[ny];
    double tmpv;
    ptrdiff_t nyj,nyjnyj,nxnyj;

     /**********************************
      Intialize P0
      *********************************/
    
    /*sigg = g*P10*g' + R*/
    dgemm(&blasNoTrans, &blasTrans, &nx, &nx, &neps, zone, ETA, &nx, ETA, &nx, zero, Q, &nx);
    
    /*h_sq = h*h*/
    dgemm(&blasNoTrans, &blasNoTrans, &nx, &nx, &nx, zone, H, &nx, H, &nx, zero, H_sq, &nx);

    /*sigg = h*Q*h'*/
    dcopy(&nxnx, Q, &one, sigg, &one); /*sigg = Q*/
    dgemm(&blasNoTrans, &blasNoTrans, &nx, &nx, &nx, zone, H, &nx, Q, &nx, zero, sigg_tmp, &nx); /* h*Q */
    dgemm(&blasNoTrans, &blasTrans, &nx, &nx, &nx, zone, sigg_tmp, &nx, H, &nx, zone, sigg, &nx);/* sigg = h*Q*h +Q */
   
    /*Loop to get sigx, unconditinal variance of model*/
    jj = 0;
    dcopy(&nxnx,Q,&one,sigx,&one);
    while(jj<1000 && crit > pow(10,-15)){
        dcopy(&nxnx,sigg,&one,sigx_tmp,&one);
        dgemm(&blasNoTrans, &blasNoTrans, &nx, &nx, &nx, zone, H_sq, &nx, sigx, &nx, zero, P10_tmp, &nx); /* h*sigx */
        dgemm(&blasNoTrans, &blasTrans, &nx, &nx, &nx, zone, P10_tmp, &nx, H_sq, &nx, zone, sigx_tmp, &nx); /* h_sq*sigx*h_sq'+sigg */
        
        /*compute convergence crit*/
        dcopy(&nxnx,sigx_tmp,&one,sigx_tmp2,&one);
        daxpy(&nxnx,mone,sigx,&one,sigx_tmp2,&one); /* sigx-sigx_tmp2 */
        crit = dasum(&nxnx,sigx_tmp2,&one);
        
        /*Copy over the new result to sigx, index counter*/
        dcopy(&nxnx,sigx_tmp,&one,sigx,&one);
        jj++;
    }
    

     
    /*Copy over sigx to P10*/
    dcopy(&nxnx,sigx,&one,P10,&one);
    
    /*Intialize x0, find a better way?*/
    for (jj=0;jj<nx;jj++){x10[jj]=0;}
    
    /********************************
    * Start the Kalman Filter
    ********************************/
    tt = 0;
    while (tt < nt){
        rr = 0;
        nyj = 0;
        for(kk=0;kk<ny;kk++){
            tmpv = Y[tt*ny+kk];
            if (tmpv == tmpv){
                nyj++;
                }
        }

        for(kk=0;kk<ny;kk++){
            tmpv = Y[tt*ny+kk]; 
            if (tmpv == tmpv){
                yerrj[rr] = tmpv; /*Copy over data*/
                dcopy(&ny,&R[kk],&ny,&Rjtmp[rr],&nyj); /*Copy over that row of R*/
                dcopy(&nx,&G[kk],&ny,&Gj[rr],&nyj); /*Copy over that row of G*/
                rr++; /* Index forward the number of valid observations*/
            }
        }
        
        rr = 0;
        for(kk=0;kk<ny;kk++){
            tmpv = Y[tt*ny+kk];
            if (tmpv == tmpv){
                    dcopy(&nyj,&Rjtmp[nyj*kk],&one,&Rj[nyj*rr],&one); /*Copy column of matrix*/
                rr++; /* Index forward the number of valid observations*/
            }
        }
        
        nyj = rr;
        nyjnyj = nyj*nyj;
        nxnyj = nx*nyj;
        
        
            
         /*yerr = (Y(:,j)-g*x10)*/
        dgemv(&blasNoTrans, &nyj, &nx, mone, Gj, &nyj, x10, &one, zone, yerrj, &one);
   
        /*om10 = g*P10*g'+R;*/
        dcopy(&nyjnyj,Rj,&one,om10,&one); /*Copy over R*/
        
        /*printmat_rowmaj(nyj,ny,Rjtmp);*/
        /*printmat_rowmaj(nyj,nyj,Rj);*/
        /*printf("\n");   */
        
        dgemm(&blasNoTrans, &blasNoTrans, &nyj, &nx, &nx, zone, Gj, &nyj, P10, &nx, zero, gP10, &nyj); /*g*P10 */
        dgemm(&blasNoTrans, &blasTrans,  &nyj, &nyj, &nx, zone, gP10,&nyj, Gj, &nyj, zone, om10, &nyj);/*sigg = g*P10*g' + R */
        
        dcopy(&nyjnyj,om10,&one,om10_hold,&one); /*om10_hold = om10*/
        dcopy(&nyj,yerrj,&one,omyerr,&one);      /*omyerr = yerr*/
        
 
        
        dposv(&uplo, &nyj, &one, om10_hold, &nyj, omyerr, &nyj, &info); /* omyerr = om10\yerr */
      
 
        
        /*Only update liklihood if past initialization stage*/
        if (tt>=ndrop){
            
            /* LL = LL -1/2*(log_det(om10) + yerr'*(om10\yerr)) */
            LL = LL -.5*rr*log(p2);            /*Constant varies according to number of observations;*/
            LL = LL -.5*log_det(nyj,om10);    
            dgemv(&blasNoTrans,&one,&nyj,mp5,yerrj,&one,omyerr,&one,zone,&LL,&one); /*LL = LL - .5*(yerr'*(om10\yerr) */
        }
        
        /*x10 = h*x10 + h*P10*g'*(om10\yerr)*/
        dgemv(&blasTrans, &nyj, &nx, zone, gP10, &nyj, omyerr, &one, zero, P10gomy, &one);/*P10*g'*(om10\yerr) -> switched to dgemv from dgemm*/
        daxpy(&nx,zone,x10,&one,P10gomy,&one); /*x10 + P10*g'*(om10\yerr)*/
        dgemv(&blasNoTrans, &nx, &nx, zone, H, &nx, P10gomy, &one, zero, x10, &one);/*x10 = h*x10 + h*P10*g'*(om10\yerr) -> switched to dgemv from dgemm*/
        
        /*P11 = P10 - P10*g'*(om10\(g*P10))*/
        dcopy(&nxnx,P10,&one,P11,&one); /*P11 = P10*/
        dcopy(&nxnyj,gP10,&one,omgP,&one); /*omgP = g*P10*/
        dposv(&uplo, &nyj, &nx, om10, &nyj, omgP, &nyj, &info); /* omgP = om10\(g*P10)*/
        dgemm(&blasTrans, &blasNoTrans, &nx, &nx, &nyj, mone, gP10, &nyj, omgP, &nyj, zone, P11, &nx);/*P11 = P10 - P10*g'*(om10\(g*P10))*/
        
        /*P10n = h*P11*h' + Q*/
        dcopy(&nxnx,Q,&one,P10n,&one); /*Copy over R*/
        dgemm(&blasNoTrans, &blasNoTrans, &nx, &nx, &nx, zone, H, &nx, P11, &nx, zero, hP11, &nx); /* hP11=H*P11 */
        dgemm(&blasNoTrans, &blasTrans, &nx, &nx, &nx, zone, hP11, &nx, H, &nx, zone, P10n, &nx);/* P10n = H*P11*H'+Q */
        
        /*compute convergence crit (not testing for convernce right now, though)*/
        daxpy(&nxnx,mone,P10n,&one,P10,&one); /*sigx-sigx_tmp2*/
        crit = dasum(&nxnx,P10,&one);
         
        /*Copy over the new result to sigx*/
        dcopy(&nxnx,P10n,&one,P10,&one);
        tt++;
    }
    
    
    ll_tmp[0] = LL;
    
    free(H_sq);
    free(Q);
    free(P10);
    free(P11);
    free(P10n);
    free(hP11);
    
    
    
    return;
}



void mexFunction( int nlhs, mxArray *plhs[],
        int nrhs, const mxArray*prhs[] )
        
{
    double *ll_o;
    double *G, *H, *ETA, *R, *Y, *ndropin;
    int nx,ny,nt,neps,ndrop;
    int one = 1;
    
    
    
    /*Check for proper number of arguments */
    if (nrhs != 6) {
        mexErrMsgTxt("6 inputs arguments required.");
    }
    
    /* Get Dimensions of Input Arguments*/
    ny = mxGetM(G_IN);
    nx = mxGetM(H_IN);
    nt = mxGetN(Y_IN);
    neps = mxGetN(eta_IN);
    
    /* Create a matrix for the return argument */
    LL_OUT =  mxCreateNumericArray(1, &one, mxDOUBLE_CLASS, mxREAL);
    
    
    /* Assign pointers to the various parameters  */
    ll_o = mxGetPr(LL_OUT);
    
    G = mxGetPr(G_IN);
    H = mxGetPr(H_IN);
    ETA = mxGetPr(eta_IN);
    R = mxGetPr(R_IN);
    Y = mxGetPr(Y_IN);
    ndropin = mxGetPr(N_DROP_IN);
    ndrop = (int) *ndropin;
    
    ptrdiff_t nxx = nx;
    ptrdiff_t nyy = ny;
    
    
    /* Do the actual computations in a subroutine*/
    lpack_test(nxx,nyy,neps,nt,ndrop,G,H,ETA,R,Y,ll_o);
    
    return;
    
}