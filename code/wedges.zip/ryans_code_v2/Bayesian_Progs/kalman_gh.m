% KALMAN_GH - Compute the liklihood of the data for a model solved
% in the canonical way.
%
% usage
%
% LL = kalman_gh(g,h,eta,R,Y)
%
% where the matrices g,h,eta,R come from the model solution
%
%
% x(t+1) = h*x(t) + eta*eps(t+1)
% y(t)   = g*x(t) + w(t)
% cov(w) = R
%
% and Y is a ny-by-nt vector of observations in the data.
%
% NOTE: Also implemented in kalman_gh_mex, with a major speedup!

function [LL,sigx,LLv] = kalman_gh(g,h,eta,R,Y,ndrop)

%Some parameters to store
nx = size(h,1);
ny = size(g,1);
nt = size(Y,2);

%Initial value for P matrix (checked against mom.m)
Q = eta*eta';
h_sq = h*h;
h_sqp = h_sq';

crit = 1;
sigx = Q;
sigg = h*Q*h' + Q;
while crit>1e-15
    sigx_new = h_sq*sigx*h_sqp + sigg;
    crit = max(max(abs(sigx_new-sigx)));
    sigx = sigx_new;
end

%Staring the recursion
P10 = sigx;
x10 = zeros(nx,1);
LL = -(nt-ndrop)/2*ny*log(2*pi); %This is the constant term, so not in recursive sum.

%While P10 still changing, update it each time around
j = 1;
crit = 1;
while crit > 1e-18 && j<=nt
    
    %Forecast errors in y
    yerr = (Y(:,j)-g*x10);                           %y(t,t-1)
    om10 = g*P10*g'+R ;                              %Forcast errror of y(t,t-1)
    
    ldt = log_det(om10);
    om10inv_yerr = (om10\yerr);
    
    %Compute the log-liklihood
    if j > ndrop
        LL = LL -1/2*(ldt+ yerr'*om10inv_yerr);
LLv(j) = -1/2*(ldt+ yerr'*om10inv_yerr);
    end
    %Iterate filter forward
    x10 = h*x10 + h*P10*g'*om10inv_yerr;              %X(t+1,t);
    P11 = P10 - P10*g'*(om10\(g*P10));              %Forecast error of x(t,t);
    P10n = h*P11*h' + Q;                            %Forecast error of x(t+1,t);
    
    crit = max(max(abs(P10n-P10)));
    P10 = P10n;
    
    %And REPEAT the loop
    j = j+1;
    
end

%Once P10 has converged, we cans stop updating the FEV's and some related
%terms
ldetom = log_det(om10);
hP10gp_om = (h*P10*g')/om10;
for ii = j:nt
    %Forecast errors in y
    yerr = (Y(:,ii)-g*x10);                           %y(t,t-1)
    
    %Compute the log-liklihood
    LL = LL -1/2*(ldetom + yerr'*(om10\yerr));
    
    %Iterate filter forward
    x10 = h*x10 + hP10gp_om*yerr;                     %X(t+1,t);
end


function out = log_det(M)
try
    C = chol(M);
    V = diag(C);
    out = 2*sum(log(V));
catch
    out = 1000;
end