%Mcuh faster than maltab's built in version.
function out = gampdf2(x,shape,scale)

k = shape;
thet = scale;

out = x.^(k-1).*exp(-x./thet)./(thet^k*gamma(k));