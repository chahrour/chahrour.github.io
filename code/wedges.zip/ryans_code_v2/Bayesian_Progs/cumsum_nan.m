function out = cumsum_nan(x)


idx = ~isnan(x);

out = x;
out(idx) = cumsum(x(idx));