%LINFILL - Interpolate missing values using linear interpolation. 
%
% out = linfill(x)
%
% x is column vector with NAN for mising values.

function x = linfill(x)


nx = size(x,1);
grid = 1:nx;
gridy = grid(~isnan(x));
alph = ndim_simplex({gridy}, gridy, x(~isnan(x)));


grid = grid(find(~isnan(x),1, 'first'):find(~isnan(x),1,'last'));
x(grid) = ndim_simplex_eval({gridy}, grid,alph);
