%*******************************************************
% SYMMAT_PRINT:
% Print a symbolic expresison to a evaluateable function.
%*******************************************************
function str = symmat_print(x)
if isa(x, 'double')
    %Not actually symbolic
    str = mat2str(x);
    
else
    %Actually symbolic
    str = char(x);
    str = str(8:end-1);
    
    %Make into matlab matrix notation
    row_idx = findstr(str, '],');
%row_idx = strfind(str, '],');
    for j = 1:length(row_idx)
        str(row_idx(j):row_idx(j)+1)='];';
    end
    
end