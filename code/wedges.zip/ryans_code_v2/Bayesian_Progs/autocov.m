function out = autocov(D,j)

np = size(D,2);
N = size(D,1);
D = demean(D);

D1 = D(1:N-j,:);
D2 = D(j+1:end,:);

out = zeros(1,np);
for j = 1:np
    out(j) = D1(:,j)'*D2(:,j)/(N-j-1);
end