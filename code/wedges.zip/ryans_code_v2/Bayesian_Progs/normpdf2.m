%Mcuh faster than maltab's built in version.
function out = normpdf2(x,shape,scale)

mu = shape;
sig = scale;

out = (1/sig).*(2*pi)^(-1/2).*exp(-1/2*((x-mu)./sig).^2);