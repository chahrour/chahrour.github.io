function out = se_est(pchain)


out = autocov(pchain',0);
N = length(pchain);  %Number of entries

for j = 1:N-1
   out = out + 2*autocov(pchain',j)*(N-j)/N; 
end

out = (out./N).^(1/2);
out = out';






