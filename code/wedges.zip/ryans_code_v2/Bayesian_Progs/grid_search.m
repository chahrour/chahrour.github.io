%grid_search(f,start,lb,ub,n)

function [param, min] = grid_search(f,start,lb,ub,n)

if length(start) ~= length(lb)
    error('length(start) != length(lb)');
end
%Make grid
grid = zeros(length(lb),n+1);
for j = 1:length(lb)
    grid(j,:) = [linspace(lb(j),ub(j),n),start(j)];
end


%Initialize values
idx = (n+1) + zeros(length(lb),1);
idx_new = idx;
min = f(start);
min_new = min;
param = start;
param_new = param;

i = 1;
return_id = false;
disp(['Intial fval: ', num2str(min)]);
while i <8 && ~return_id
    
    %param_old = param;
    for k = 1:length(lb)
        for j = 1:n+1
            param_new(k) = grid(k,j);
            f_new = f(param_new);
            if f_new<min_new
                
                param(k) = param_new(k);
                min_new = f_new;
                idx_new(k) =j; 
                
            end
        end
        
        param_new = param;
    end
    
    %Update Thigs for nex loop
    disp(['Improvement: ', num2str(min-min_new)]);
    if min_new==min
        return_id = true;
    end
    min = min_new;
    disp(['fval: ', num2str(min)])
    disp(' ');
    
    param_new = param;
    i = i+1;
    
    
end

    
    

