function f = mixing_figure(pchain,param_list,varargin)
nparam = size(pchain,1);
nrow = ceil(sqrt(nparam));
ncol = ceil(nparam/nrow);
f = figure;
set(f, 'paperposition', [.25 .25 10.5 8]);
for j = 1:nparam
    s = subplot(nrow,ncol,j);  hold on
    plot(pchain(j,:));
    title(param_list{j}, 'fontsize', 14);
end
