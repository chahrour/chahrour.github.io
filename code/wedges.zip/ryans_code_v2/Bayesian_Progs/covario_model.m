function  outmat = covario_model(gx,hx,eta,nj,vars,corr_opt)
nv = length(vars);

outmat = zeros(nj+1,nv^2);

%Stack to get right observables
gx = [gx;hx];
gx = gx(vars,:);

%Compute moments
sigY = zeros(size(gx,1),size(gx,1),nj+1);
for j = 0:nj
    sigY(:,:,j+1) = mom(gx,hx,eta*eta',j);
end

for k = 1:nv
    for l = 1:nv
        for j = 0:nj
            if corr_opt
                outmat(j+1, l+nv*(k-1)) = sigY(k,l,j+1)/sqrt(sigY(l,l,1)*sigY(k,k,1));
            else
                outmat(j+1, l+nv*(k-1)) = sigY(k,l,j+1);
            end
        end
    end
end