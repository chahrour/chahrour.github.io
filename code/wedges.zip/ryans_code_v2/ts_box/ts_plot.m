
%TS_PLOT - Plot one or more timeseries object nicely, with recession shading.
%
%
% usage
%
% ts_plot(ser1, ser2, ...)
%

function [f1 s] = ts_plot(varargin)



%In case the last argument is a set limits on the y-axis
if isnumeric(varargin{end})
    ylimits = varargin{end};
    varargin = varargin(1:end-1);
    ylimits = repmat(ylimits,[length(varargin),1]);
    gen_ylim = 0;
else
    gen_ylim = 1;
end

%Number of series
nser = length(varargin);

%Load NBER series from proper directory
try
    str = which('ts_plot');
    nber_dir = str(1:end-9);
    load([nber_dir, 'NBER_rec.mat'])
    nber = 1;
catch
    nber = 0;
    warning('Could not acccess saved NBER recession series');
end


%Used to find the earliest starting ts, and latest ending ts
starts = zeros(nser,1);
ends = zeros(nser,1);
for i = 1:nser
    starts(i) = varargin{i}.sd;
    ends(i) = varargin{i}.ed;
    freq(i) = varargin{i}.freq;
    tits{i} = varargin{i}.name;
end
start = min(starts);
ender = max(ends);

%Check to make sure of same freq
if ~(sum(freq==freq(1))==length(freq))
    error('Incompatible Frequencies, ts_plot requires al series to be eithe quaterly or monthly');
else
    freq=freq(1);
end


%Check for NBER Conversion
if nber && freq == 4
    NBER = M2Q(NBER);
end

%How many periods
start_y = floor(start/100);
per_start = mod(start,100);
end_y = floor(ender/100);
per_end = mod(ender,100);
nper = (end_y-start_y)*freq+per_end-per_start+1;

%Make a column of dates
date_col = zeros(nper,1);
date_col(1) = start;
for j = 1:nper-1
   date_col(j+1) =  MQ_index(date_col(j), 1, freq);
end

%Creat the figure, set figure paper placement, number of cols and rows in figure
f1 = figure;
set(f1, 'PaperPosition', [.25, .25, 10,5.5]);%, 'paperorientation', 'landscape');
hold on
ncol = floor(sqrt(nser));
nrow = ceil(nser/ncol);



%Print data for each figure
for i = 1:nser
    
    idx1 = find(date_col==starts(i));
    idx2= find(date_col==ends(i));
    

    data = varargin{i}.dat;
        

    %Set y-limits if not set by hand
    if gen_ylim
        ylimits(i,:) = [min(data)-.05*abs(min(data)), max(data)+.05*abs(max(data))];
    end
   
    %Series ofNBER dates
%     NBER.dat = NBER.dat'
%     starts
%     ends
    if nber
        nber_dates = vect(NBER, 0, [starts(i), ends(i)])>.5;
    end
    
    %Plot away!
    %s{i} = subplot(nrow, ncol, i);
    
    s{i} = subplot(1,1,1);
    
    idxer = floor(length(data)/10);
    xtick = 1:idxer:(idx2-idx1);
    if (idx2-idx1+1 - xtick(end)) > .3*idxer
        xtick = [xtick, idx2-idx1+1];
    end
    
    xticklab = round(date_col(xtick+idx1-1)/100);
    
    color_list = {'b', 'r', 'k','k'};
    
    lwvec = [1.5,1.5,1,1];
    lstyle = {'-', '-','--', '--'};
    
    p = plot(data,'-k', 'LineWidth', lwvec(i), 'Color', color_list{i}, 'linestyle', lstyle{i});hold on;
    xlabel('Year', 'FontSize', 14);

    set(s{i}, 'xtick', xtick, 'xticklabel', xticklab, 'xlim', [1,idx2-idx1+1], 'ylim', ylimits(i,:));
    if (min(data) < 0) && (max(data) > 0)
        plot(0*data, ':');
        
    end
    %Titles
    %   legend(tits{i})

    %Shade recessions
    try
        
    if nber && i == nser
        
        shade_recession(s{i}, nber_dates);
    end
    catch
    end

end



if nser > 1
 
    f  = get(s{1}, 'children');
    legend(f([1,3,5,7]),tits);

else
    legend(s{1}(1),tits{1})
end
