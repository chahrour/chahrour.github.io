[a,b] = xlsread('Data_ForRyan_06072015.xls', 'Rates');



n0 = 1;
nn = length(a)-2;

cy  = a(n0:nn,2);
gy  = a(n0:nn,3);
v   = a(n0:nn,4);
lfp = a(n0:nn,5);
e   = a(n0:nn,6);
jfr = a(n0:nn,7);

dat = demean([cy,gy,v,lfp,e,jfr])';


save data_for_mainprog