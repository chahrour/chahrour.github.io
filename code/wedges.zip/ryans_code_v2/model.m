% MODEL - File describing the equilibrium conditions of Chahrour, Chugh,
% Potter (2014).
%
% usage:
%
% mod = model_linear(param, set)
%
% where
%
% param = a parameters object, created in parmeters.m
% set = a settings object, also created in parameters.m
%
% NOTES: This program, which generates the model matrices in cannonical form,
%        requires the MATLAB symbolic toolbox! The algorithms used to solve
%        the model, however, are numerical, and require no additonal m-files
%        beyond those that appear in this directory.
%
%
% Code by Ryan Chahrour, Boston College, 2014


function [mod] = model(param,set,rhosym)

%Name of text files
mod.fname   = 'model_prog.m';
mod.ss_call = 'model_ss.m';

%Declare parameters symbols: parameters are values to be estimated
param_list = fieldnames(param);
syms(param_list{1:end});
for j = 1:length(param_list)
    eval(['PARAM(j) = ',param_list{j} ,';']);
end
PARAM

%Declare setting symbols: symbols are values that are "fixed"
set_list = fieldnames(set);
syms(set_list{1:end});
for j = 1:length(set_list)
    eval(['SET(j) = ',set_list{j} ,';']);
end
SET


syms N C S V THET NL Z LFP G CY TAUS TAUD ER JFR GAM TAU0 GY TAUN

Y = [N C S V THET CY LFP ER JFR GY TAUN];
X = [NL Z GAM TAUS TAUD G];

YP = make_prime(Y); for j=1:length(YP); eval(['syms ' char(YP(j))]);end
XP = make_prime(X); for j=1:length(XP); eval(['syms ' char(XP(j))]);end

%Loop creates indexes to track variables (for figures, etc)
ny = length(Y);
nx = length(X);
for j=1:ny;
    vn = char(Y(j));
    eval([lower(vn), '_idx = j;'])
end
for j=1:nx;
    vn = char(X(j));
    eval([lower(vn), '_idx = ny+j;'])
end

[1:length(X);X]
[1:length(Y);Y]

%*******************************
%FUNCTIONAL FORMS, DEFINITIONS
%*******************************
%GAM = 1; GAM_p = 1;


vpc = @(v) v*(gam + phi*(v-vbar)^2);
VPC = vpc(V);
dVPC = diff(VPC,V);

VPC_p = vpc(V_p);
dVPC_p = diff(VPC_p,V_p);



Uc = 1/C;
Uc_p = 1/C_p;

Hlfp = kappa*LFP^(1/epps);

M = GAM*S^xi*V^(1-xi);

Ms = GAM*xi*THET^(1-xi);
Ms_p = GAM_p*xi*THET_p^(1-xi);

Mv = GAM*(1-xi)*THET^-xi;
Mv_p = GAM_p*(1-xi)*THET_p^-xi;

%*******************************
%EQ CONDITIONS
%*******************************
f(1)     =  TAUS*Hlfp/Uc - dVPC*Ms/Mv;

f(end+1) = Z*(1-alph)*N^-alph + TAUD*(-dVPC/Mv  + (1-rho)*bet*Uc_p/Uc*dVPC_p/Mv_p*(1-Ms_p));

f(end+1) = C + G + VPC - Z*N^(1-alph);

f(end+1) = N - (1-rho)*NL - M;

%*******************************
%WEDGE VAR PROCESS
%*******************************
f(end+(1:5)) = [log(Z_p);log(GAM_p);log(TAUS_p/taus);log(TAUD_p);log(G_p/g)] - rhosym*[log(Z); log(GAM); log(TAUS/taus);log(TAUD); log(G/g)];

%*******************************
%DEFITIONS
%*******************************

f(end+1) = THET - V/S;

f(end+1) = NL_p - N;

f(end+1) = CY - C/(Z*N^(1-alph));  %CONS-OUTPUT RATION

f(end+1) = LFP - N -(1-JFR)*S; %LABOR FORCE PARTICIPATION

f(end+1) = ER - N;             %EMPLOYMENT RATE

f(end+1) = JFR - M/S;          %JOB FINDING PROB

f(end+1) = GY - G/(Z*N^(1-alph));  %GOV-OUTPUT RATIO

f(end+1) = TAUN - TAUS*TAUD;

%f(end+1) = TAUN - xi/(1-xi)*(1-CY-GY)/CY*LFP^-(1+1/epps)*alph*(1-xi)/(1-CY-GY);

%cy.*lfp.^(1/.18).*er.*1./jfp

%*****************************************
%EXTRA EQUATIONS TO DETERMINE NUMERICAL SS
%*****************************************
disp(['Number of equations: ' num2str(length(f))])
disp(['Number of variables: ' num2str(length(X) + length(Y))])


%Log-linear approx
xlog = true(1,length(X)); 
ylog = false(1,length(Y)); 
log_var = [X(xlog) XP(xlog)];

mod.f = subs(f, log_var, exp(log_var));
mod.X = X;
mod.XP = XP;
mod.Y = Y;
mod.YP = YP;
mod.xlog = xlog;
mod.ylog = ylog;
mod.PARAM = PARAM;
mod.param = param;
mod.SET = SET;
mod.set = set;
%mod.Xss = Xss;
%mod.Yss = Yss;
mod.adiff = set.adiff; %Include anaylytical derivatives?

%Standard Errors
mod.shck = sym(zeros(length(X),4));
mod.shck(2,1) = .01;
mod.shck(3,2) = .005;
mod.shck(4,3) = .005;
mod.shck(5,4) = .005;
mod.shck(6,5) = .005;
%Measurement Error (parameters are std-devs in param.m file)
mod.me = sym(zeros(length(Y)));
for j = 1:length(set.me_eq) - isnan(set.me_eq(1))
    eval(['mod.me(set.me_eq(j),set.me_eq(j)) = sig_ME' num2str(set.me_eq(j))  '^2;']);
end

%Derivatives using numerical toolbox
mod = anal_deriv(mod);

%Save index variables for use in main_prog
!rm -f v_idx.mat
save v_idx *_idx


%*************************************************************************
% MAKE_PRIME - For any symoblic vector, return a vector with symoblic
% elements of the same names with a _p suffix.
%
%
% usage (by example)
%
% out = make_prime([X1 X2])
%
% out =
%       [X1_p X2_p]
%**************************************************************************
function Vp = make_prime(V)

Vp = sym('Vp');

for j = 1:length(V)
    Vp(j) = sym([char(V(j)), '_p']);
end

