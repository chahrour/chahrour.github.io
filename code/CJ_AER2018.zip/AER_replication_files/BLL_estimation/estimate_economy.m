addpath('../DSGE_tools');

load v_idx
[param,set] = parameters;
paramv = struct2array(param);
nms = fieldnames(parameters);

%FOR A LOOK AT RESULTS
vlist     = {'dGDP', 'dC',    'dN',  'PI',  'IR'  'DA'};
vvidx     = [dy_idx, dc_idx, dn_idx, pi_idx, irt_idx, da_idx];
prefs.ndec = 3;

%What do I want to see?
names    = {'dY', 'dC','dN','PI', 'IR'};
gx_idx   = [dy_idx,dc_idx,dn_idx,pi_idx,irt_idx];

load ../data/data_final data_vec

%5% measurement error
%rmax = .05*var(data_vec);

%2.5% measurement error
rmax = .025*var(data_vec);

%% TIME TO ESTIMATE
lbnd = [.0001; 
     0.0001;
     0.0001;
     0.0001;
     1/5  ;
     0.001     ;
     0.001     ;
     0.001     ;
     0.001   ;
     1.01 ;
     0.001;
     0.001;
     0.75;
     0.00001;
     0*rmax'];
 
ubnd = [.99;
    10 ;
    10;
    .99;
    5;
    10;
    15;
    0.999;
    0.999;%.002; (Use the tight bound for the flex wage case!)
    5;
    2;
    .999;
    .999;
    3;
    rmax'];

% disp(' ');disp('LB|Init|UB');
% for jj =1:length(paramv)
%     disp([sprintf('%s\t', nms{jj}), ':' sprintf('%2.3f\t',lbnd(jj)), ' ', sprintf('%2.3f\t',paramv(jj)), ' ' sprintf('%2.3f\t',ubnd(jj))])
% end

param0 = paramv;
%% Test objective
obj1 = @(paramv)model_loss(paramv,set,gx_idx,data_vec);
obj1(param0);
obj2 = obj1;

%% SAVED RESULTS

% 5% noise estimate: LL = 779.7494
%param_final = [0.90265671	1.08215797	0.0001004	0.7171096	0.2	0.001	14.99999988	0.87588199	0.88424704	4.38765819	0.001	0.40603167	0.999	0.26949639	0.03836669	0.01370243	0.03532726	0.01612468	0.04035373]

% 2.5% measurement error: LL = 964.5871
param_final = [0.89109239	1.22947646	0.00010004	0.7065925	0.2	0.00789486	14.99999998	0.86454188	0.87082524	3.86401984	0.001	0.45401745	0.999	0.2792126	0.01918334	0.00685121	0.01766363	0.00806234	0.02017686];

%Flex wage estimate: LL = 1084.2129
%param_final = [0.80675547	1.69551956	0.000102	0.47264414	0.2	0.001	14.99999989	0.89291474	0.002	1.01	0.41350367	0.11267828	0.94808767	0.411164	0.01918334	0.00685121	0.01766363	0.00806234	0.02017686];


[gx,hx,eta,crit] = imperfect_solve(param_final,set,0);
%mom_tab(gx,hx,eta*eta',vvidx,vlist,prefs);disp(' ');
LL = -obj1(param_final);
BIC = log(length(data_vec))*length(paramv)-2*LL;
%fevd_table(gx,hx,eta,[1,4,8,16,20],dc_idx,'DC',prefs);
[Vy] = vdfilter(gx([dc_idx,dy_idx],:),hx,eta,2*pi./[6,32]);
Vyc = Vy(5,1);
%disp(['Cons Noise Shr: ' num2str(Vyc)])
%disp(['BIC           : ' num2str(BIC)]);

 %For BLL baseline IRs (line 75 uncommented only)
save ../info_figure/bll_base gx hx eta *_idx


%Uncommonet for flex wage case at baseline estimates (These IRs are used for figure 6)

% For BLL flex wage IRs (lines 75 and 78 uncommented)
param_final(9) = .001;
[gx,hx,eta,crit] = imperfect_solve(param_final,set,0);
save ../info_figure/bll_base_flex gx hx eta *_idx

return
%% ESTIMATION
loc = pwd;
if strcmp(loc(2), 'U')
    % LOCAL SEARCH - FMINCON
    warning off;
    param0 = param_final;
    options = optimoptions('fmincon');
    options.Display = 'iter';
    options.UseParallel = false;
    options.MaxFunctionEvaluations = 1000;
    param_final = fmincon(obj1,param0,[],[],[],[],lbnd,ubnd,[],options);
else
    % GLOBAL SEARCH
    ns     = 8*24;  %Number of global_search threads
    opt.type = 'fmincon';
    global_search
end

for jj =1:length(paramv)
    disp([sprintf('%s\t', nms{jj}), ':' sprintf('%2.3f\t',lbnd(jj)), ' ', sprintf('%2.3f\t',param_final(jj)), ' ' sprintf('%2.3f\t',ubnd(jj))])
end
param_struct = array2struct(nms,param_final);


