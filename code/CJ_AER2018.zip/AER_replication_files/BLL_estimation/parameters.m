% PARAMETERS - This function returns a parameter structure to use in the model solution.


function [param,set,GG,GG2,Gxmat] = parameters()
                                                       
set.adiff      = 0;
set.approx_deg = 1;

%Full or partial info
set.fullm = 1;

%Parameters BLL info
sigtmp = 1.1977;
param.rho = .9426;
param.sigtmp = sigtmp;
param.sigv = 1.4738;


%economic parameters BLL, calibrated?
set.bet  = .99;            %discount factor
set.delt = .025;         %Depreciation
set.GAM  = 1.00;         %Growth Rate
set.psii = .21875;           %Goverment share
set.muw  = .05;  

%Estimatied
param.h     = 0.5262;          %habit
set.alph  = 0.36;        %capital share
param.zeta  = 2.0871;          %frisch
param.xi   = 3.4919;         %capacity cost
param.chi  = 4.3311;          %adjustment cost
param.thet = 0.8770;          %calvo price
param.thetw = 0.8690;         %calvo wage
param.gampi =  1.0137;       %Taylor inflation
param.gamy  =  .0050;        %Taylor output
set.gamy2 = 0;               %taylor rule on output growth           

%Other estimated exogenous processes
set.rhod = .4641;
set.sigd = 0*11.098;

set.rhop = .7722;
set.phip = -.4953;
set.sigp = 0*.1778;

set.rhow = 0.9530;
set.phiw = -.9683;
set.sigw = 0*.3057;


param.rhor = 0.5583;
param.rhoq = 0.95;
param.sigq = 0.3500;
set.rhog = 0.95;
set.sigg = 0.25;

param.me1 = 0.005;
param.me2 = 0.005;
param.me3 = 0.005;
param.me4 = 0.005;
param.me5 = 0.005;

%Determined in equilbrium
set.cybar  = NaN;      
set.iybar = NaN;
set.rkpybar = NaN;
set.kap = NaN;
set.kapw = NaN;


%**************************************************************************
% CHOOSE INFO STRUCTURE TO SOLVE WITH
%**************************************************************************
set.bllinfo = 1;   %true mean use BLL rep; false means use nosie rep

%**************************************************************************
% ORIGINAL BLL INFO STRUCTURE
%**************************************************************************

ggvec = quick_kalman(param);

%parameters from kalman filter
GG = cell(1,6);
mm = 1;
ns = 4;
for jj = 0:5
    ncol = ns; if jj == 3; ncol= 2;end
    GG{jj+1} = sym(zeros(ns,ncol));
    for kk = 1:ncol
        for ll = 1:ns
            str = ['gg' num2str(jj), '_' num2str(ll) '_' num2str(kk)];
            eval(['set.' str '=ggvec(mm);']);   
            GG{jj+1}(ll,kk) = sym(str);
            mm = mm+1;
        end
    end
  
end



%**************************************************************************
% FULL NOISE ROTATION
%**************************************************************************
ggvec2 = quick_kalman_noise(param);
%parameters from kalman filter
GG2 = cell(1,6);
mm = 1;
ns = 12;
for jj = 0:5
    ncol = ns; if jj == 3; ncol= 2;end
    GG2{jj+1} = sym(zeros(ns,ncol));
    for kk = 1:ncol
        for ll = 1:ns
            str = ['gg_2' num2str(jj), '_' num2str(ll) '_' num2str(kk)];
            eval(['set.' str '=ggvec2(mm);']);   
            GG2{jj+1}(ll,kk) = sym(str);
            mm = mm+1;
        end
    end
end


%**************************************************************************
% PLM PARAMETERS
%**************************************************************************
nx = 46;
Gxmat = sym(zeros(8,nx));

%PLM
for mm = 1:nx
    for jj = 1:8
        str = ['gx_' num2str(jj),'_', num2str(mm)];
        eval(['set.' str '=0;']);
        Gxmat(jj,mm) = sym(str);
    end
end


