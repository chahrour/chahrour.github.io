function Loss = model_loss(paramv,set,gx_idx,data_vec)


ndrop = 21;
R = diag(paramv(end-4:end));

[gx,hx,eta] = imperfect_solve(paramv,set,1); %Last argument = 1 means use BLL info structure

if isnan(gx(1))
    Loss = 1e8;
else
    gx = gx(gx_idx,:);
    %Loss = -kalman_gh_mobs_mex4(gx,hx,eta,R,data_vec',ndrop);
    Loss = -kalman_gh_mobs(gx,hx,eta,R,data_vec',ndrop);
end




