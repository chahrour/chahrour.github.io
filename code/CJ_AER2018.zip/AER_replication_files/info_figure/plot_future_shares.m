% -------------------------------------------------------------------------
% Plot past vs future fundamental shares as a function of detrending
% paramter lamba
% -------------------------------------------------------------------------
clear set

% Load SGU shares
load shares_sgu;
pshares_sgu = pshares;
fshares_sgu = fshares;
total_sgu   = pshares + fshares;

% Load BS shares
load shares_bs;
pshares_bs = pshares;
fshares_bs = fshares;
total_bs   = pshares + fshares;

% Load BLL shares
load shares_bll;
pshares_bll = pshares;
fshares_bll = fshares;
total_bll   = pshares + fshares;

% Plot results
fig = figure;
ny = size(pshares,1);
titles = {'output','consumption','investment','hours'};
for i = 1:ny
    subplot(ny/2,ny/2,i);
    plot(lam,(fshares_sgu(i,:)./total_sgu(i,:))','k');hold on;
    plot(lam,(fshares_bs(i,:)./total_bs(i,:))','--k');
    plot(lam,(fshares_bll(i,:)./total_bll(i,:))','-.k');
    ylim([0,1]);
    xlim([lam(1),lam(end)]);
    title(titles{i}); grid on;
    if i==1;leg=legend('SGU','BS','BLL'); set(leg,'location','northwest');end
end


% Print
dim = [7,5];
set(gcf,'paperpositionmode','manual','paperunits','inches');
set(gcf,'papersize',dim,'paperposition',[0,0,dim]);
%print(fig,'-dpdf','ppf');
