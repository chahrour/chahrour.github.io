% FIGURE 6 - NOISE SHOCK IMPULSE RESPONSES

f = figure;
f.PaperOrientation = 'portrait';
fs = 14;
nper = 20;


%BASELINE ESTIMATED MODEL
load bll_base.mat
nidx = zeros(size(eta,2),1);nidx(5) = 1; %Where is the noise shock?
ir_base = ir(gx,hx,eta*nidx,nper);
ir_base = ir_base(:,[dy_idx,dc_idx,di_idx,dn_idx]);
ir_base(:,1:4) = cumsum(ir_base(:,1:4));

%FLEX WAGE AT BASELINE ESTIMATES
load bll_base_flex.mat
nidx = zeros(size(eta,2),1);nidx(5) = 1; %Where is the noise shock?
ir_flex = ir(gx,hx,eta*nidx,nper);
ir_flex = ir_flex(:,[dy_idx,dc_idx,di_idx,dn_idx]);
ir_flex(:,1:4) = cumsum(ir_flex(:,1:4));

vnames = {'GDP', 'Cons', 'Inv', 'Hrs'};
for jj = 1:4
   
   s = subplot(2,2,jj);
   plot(0:nper-1,ir_base(:,jj), 'linewidth', 2, 'color', [.2,.2,.2]); hold on;
   plot(0:nper-1,ir_flex(:,jj), 'linewidth', 2, 'color', [.7,.7,.7]);
   plot(0:nper-1,zeros(1,nper), ':k');
   s.XLim=[0,nper-1];
    if jj == 1
        xlabel('period');
        ylabel('pct change');
    end
   title(vnames{jj})
end
legend('baseline', 'flex Wage', 'location', 'northeast')
