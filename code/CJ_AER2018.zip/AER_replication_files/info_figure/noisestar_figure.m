%% FIGURE 1 - NOISE V NOISESTAR

f = figure;
f.PaperOrientation = 'portrait';
fs = 14;


s1 = subplot(1,2,1);
load bs_noise_noisestar.mat
plot(noise_star_grid,noise_shar0,'linewidth',3,'color', [.1,.1,.1]); hold on;
plot(noise_star_grid,noise_shar1,'linewidth',3,'color', [.6,.6,.6])
s1.YLim = [0,.2];
s1.XLim = [0,1];
plot([sig_noise0,sig_noise0],s1.YLim, '--k');
s1.FontSize = 12;
xlabel('Std. dev. of noise*','fontsize',fs)
ylabel('% of Cons. Flucs.','fontsize',fs);


s2 = subplot(1,2,2);
load bll_noise_noisestar.mat
plot(noise_star_grid,noise_shar0,'linewidth',3,'color', [.1,.1,.1]); hold on;
plot(noise_star_grid,noise_shar1,'linewidth',3,'color', [.6,.6,.6]);
s2.YLim = [0,.8];
s2.XLim = [0,6];
plot([sig_noise0,sig_noise0],s2.YLim, '--k');
s2.FontSize = 12;

xlabel('Std. dev. of noise*','fontsize',fs);
legend('Noise','Noise*','location', 'northeast');
%saveas(f, '../../paper/noise_noisestar.eps', 'epsc');