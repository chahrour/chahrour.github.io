%% FIGURE 4 - SWAPPING INFORMATION STRUCTURES

%Construct the BS group
load cshr_bs_bsinfo.mat
bs_row = [cshr_bc];
load cshr_bs_bllinfo.mat
bs_row = [bs_row,cshr_bc];

%Construct the BS group
load cshr_bll_bsinfo.mat
bll_row = [cshr_bc];
load cshr_bll_bllinfo.mat
bll_row = [bll_row,cshr_bc];

f = figure;
s = subplot(1,1,1);
p = bar([1,3],[bs_row;bll_row]);

l=legend('BS Info' , 'BLL Info', 'location', 'Northwest');
l.FontSize = 12;
s.XTickLabel = {'BS model', 'BLL model'};
ylabel('Noise Share', 'fontsize',14);
p(1).FaceColor = [.8,.8,.8];
p(1).EdgeColor = [1,1,1];


p(2).FaceColor = [.4,.4,.4];
p(2).EdgeColor = [1,1,1];

s.YLim = [0,1];
s.YTick = [0,.5,1];
s.FontSize = 12;
%saveas(f, '../../paper/swap_figure.eps','epsc');