%% FIGURE 5 - COMPARING INFORMATION STRUCTURES

f = figure;
f.PaperOrientation = 'portrait';
fs = 14;

nhor = 30;

s1 = subplot(1,2,1); 
load bll_forecasts.mat 
p1 = plot(1:nhor,fe_var(1:nhor).^.5,'-k');hold on;
p2 = plot(1:nhor,fe_varn(1:nhor).^.5,'-kx');hold on;

load bs_forecasts.mat 
p3 = plot(1:nhor,fe_var(1:nhor).^.5,'--k');hold on;
p4 = plot(1:nhor,fe_varn(1:nhor).^.5,'--kx');hold on;


legend('BLL', 'BLL no signal', 'BS', 'BS no signal', 'location', 'southeast')
title('forecast error standard deviation');
s1.XLim = [1,nhor];

s1 = subplot(1,2,2);
load bll_forecasts.mat 

p1 = plot(1:nhor,fnshr_bc(2,2:nhor+1),'-k'); hold on;
load bs_forecasts.mat 
p2 = plot(1:nhor,fnshr_bc(2,2:nhor+1),'--k');
legend('BLL','BS', 'location', 'southeast')
s1.XLim = [1,nhor];

title('noise share of forecast');
