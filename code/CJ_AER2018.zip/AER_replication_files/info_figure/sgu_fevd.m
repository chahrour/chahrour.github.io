load sgu_fevd
vvlab     = {'output', 'consumption', 'investment', 'hours'};
f = figure;
for jj = 1:4
   s = subplot(2,2,jj);
   plot(1:20,fevd_lines(jj,:),'k');
   s.YLim = [0,1];s.XLim = [1,20];s.XTickLabel{end} = 'inf';
   title(vvlab{jj})
end
