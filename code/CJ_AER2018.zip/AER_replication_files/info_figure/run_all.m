addpath('../DSGE_tools')
dir_list = {'../SGU_reproduction/'
            '../BS_reproduction/'
            '../BS_reproduction_BLLinfo/'
            '../BLL_reproduction_BSinfo/'
            '../BLL_reproduction/'};

est_list = {'../BS_estimation/'  
            '../BS_estimation_BLLinfo/'
            '../BLL_estimation_BSinfo/'
            '../BLL_estimation/'
            '../BLL_estimation_BSinfo_flex/'
            '../BLL_estimation_flex/'};
              
%% CANNONICAL FORMS FOR REPLICATED MODELS
for ff = 1:5
   disp(dir_list{ff})
   cd(dir_list{ff}) 
   generate_file
   rehash;
end

%% CANNONICAL FORMS FOR ESTIMATED MODELS
for ff = 1:6
   disp(est_list{ff})
   cd(est_list{ff}) 
   generate_file
   rehash;
end


%% SOLVE EACH REPLICATED MODEL      
for ff = 1:5
    disp(dir_list{ff})
    cd(dir_list{ff})
    solve_linear
    if ff==1 ||ff==2 || ff == 5
        make_vdtable;
        ppf_detrend
        if ff ~=1 
            compare_info;
            noise_noisestar;
        end
        
    end
end
cd ../info_figure/


%% ESTIMATION

%load data
cd ../data
make_data
cd ../info_figure

%Table 4: 
table4a = nan(2,3);
table4b = nan(2,3);
for ff = 1:6   
   cd(est_list{ff}) 
   estimate_economy
   table4a(ff) = Vyc;
   table4b(ff) = BIC;
end
cols = {' '; 'BS mod' ;'BLL mod'; 'BLL flex'};
rows = {'BSinfo'; 'BLLinfo'};

disp('**********************************************')
disp('TABLE 4:');
disp('**********************************************') 
disp(cellprintf('%s\t',cols))
pretty_print(table4a,2,rows)
disp(' ')
disp(cellprintf('%s\t',cols))
pretty_print(table4b,0,rows)
disp('**********************************************') 
cd ../info_figure/

%% PLOT FIGURES
noisestar_figure
plot_future_shares
sgu_fevd
swap_figure
forecast_figure
impulse_figure