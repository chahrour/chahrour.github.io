% NOT FINISHED! M2Q - Convert data to quarterly observations from monthly using arithmetic mean.
%
% usage
%
% out = QtoA(data, start_date, options)
%
% where 
% 
% data  = a matrix of data with quarterly observation along the columns
% start_date = a matlab date number corresponding to the first observation
%
% out = quarterly averaged values
% start = a number with year-quarter format (e.g. 2003Q4 is 200304)
%
%
% IMPORTANT NOTES: Partial quarters will be returned as NaN, as will quarters with
% any missing values.  Options arguments are not yet defined.



function [out, start] = Q2A(data)
sd = data.sd;
if ts_is(data)
    ts = data;
    data = ts.dat;
end

if size(data,1)<size(data,2)
    data = data';
end

t = size(data,1);
n = size(data,2);




j = 1;
while mod(sd,100)~=1
    j = j+1;
    sd = index(sd,1,4); %One period forward
end

na = floor((t-j+1)/4); %number of whole years

new_dat = 1/4*(data(j:4:(j-1)+na*4) + data(j+1:4:j+na*4) + data(j+2:4:j+1+na*4) + data(j+3:4:j+2+na*4)); 

  
if exist('ts')
   out = ts_make(new_dat,1,sd, ts.name); 
end
    
