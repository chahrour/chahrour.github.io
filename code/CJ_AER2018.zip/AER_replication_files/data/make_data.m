%Data imported from St Federal Reserve FRED database using matlab's 
%built-in command "fetch" on October 25, 2017.
addpath('ts_box')

load data

gdp  = ts_make(data.gdp.Data(:,2),4,194701);
cons = ts_make(data.pcnd.Data(:,2)+data.pcsv.Data(:,2),4,194701);
defl = ts_make(data.def.Data(:,2),4,194701);
hrs  = ts_make(data.hrs.Data(:,2),4,194701);
ffr  = M2Q(ts_make(data.ffr.Data(:,2)./400,12,195407));
pop  = M2Q(ts_make(data.pop.Data(:,2),12,194801));

date_range  = [195404,201702];  %for level variables
date_rangeg = [195403,201702];  %for growth variables

pop_def = vect(pop,0,date_rangeg).*vect(defl,0,date_rangeg);
gdpv    = 100*diff(log(vect(gdp,0,date_rangeg)./pop_def));
consv   = 100*diff(log(vect(cons,0,date_rangeg)./pop_def));
piiv    = 100*diff(log(vect(defl,0,date_rangeg)));
hrsv    = 100*diff(log(vect(hrs,0,date_rangeg)./vect(pop,0,date_rangeg)));
ffedv   = 100*vect(ffr,0,date_range);

data_vec = demean([gdpv,consv,hrsv,piiv,ffedv]);

save data_final data_vec
