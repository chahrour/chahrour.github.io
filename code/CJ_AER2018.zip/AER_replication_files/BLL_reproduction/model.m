% MODEL - Generate linearized version of the Blanchard et al (2013) model

function [mod,param,set] = model(param,set,GGmat,GGmat2,Gxmat)


%Name of text files
mod.fname   = 'model_prog.m';
mod.ss_call = 'model_ss.m';

%Declare parameters symbols: parameters are values to be estimated, symbols are values that are "fixed"
PARAM = struct2sym(param);
SET   = struct2sym(set);

%Declare Needed Symbols
syms KBAR CL IL IRL WL D DA MPT MWT G GDPL DY DC DI DA Q EPSP EPSW SIGNAL RREAL
syms C I GDP N K U LAM PHI RK W PI M IRT DY DW DN NL DX Z ZL V DXT ZT ZLT VT
syms DX DZ ETTA V VL DXT DZT ETTAT VT VLT CPT DAPT LAMPT PIPT  PIPT PHIPT RKPT IPT WPT

syms DELAT MP3T MP2T MP1T MMT ML1T ML2T XIT XILT EXT EXLT EXL2T DELA MP3 MP2 MP1 MM ML1 ML2 XI XIL EX EXL EXL2 DELAT MP3T MP2T MP1T MT ML1T ML2T XIT XILT EXT EXLT EXL2T
%Declare X and Y vectors
X  = [KBAR CL IL IRL WL NL D MPT MWT G Q EPSP EPSW GDPL... %Non-info/productivity shocks
    DX Z ZL V, DXT ZT ZLT VT    ];                  %BLL Fundamentals/Expectations

X = [X,       DELA MP3 MP2 MP1 MM ML1 ML2 XI XIL EX EXL EXL2...
    DELAT MP3T MP2T MP1T MMT ML1T ML2T XIT XILT EXT EXLT EXL2T];

%Noise Rep Fundamentals/Expectations
Y  = [DY DC DI DW DN PI C I GDP N K U LAM PHI RK W  M IRT RREAL ...
    CPT DAPT LAMPT PIPT PHIPT RKPT IPT WPT DA]; %Variables that appear as expectations
XP = make_prime(X);
YP = make_prime(Y);
make_index([Y,X]);

%Model Equations
f(1)     = (GAM-h*bet)*(GAM-h)*LAM - h*bet*GAM*CPT + (GAM^2+h^2*bet)*C - h*GAM*CL - h*bet*GAM*DAPT + h*GAM*DA;
f(end+1) = LAM-IRT-LAMPT+DAPT+PIPT;
f(end+1)  = PHI-(1-delt)*bet*GAM^-1*(PHIPT-DAPT)-(1-(1-delt)*bet*GAM^-1)*(LAMPT - DAPT + RKPT);
f(end+1) = LAM - PHI - D + chi*GAM^2*(I-IL+DA) - bet*chi*GAM^2*(IPT - I + DAPT);
f(end+1) = RK-xi*U;
f(end+1) = M - alph*RK - (1-alph)*W;
f(end+1) = RK - W + K - N;
f(end+1) = K - U - KBAR + DA;
f(end+1) = KBAR_p - (1-delt)*GAM^-1*(KBAR-DA) - (1-(1-delt)*GAM^-1)*(D+I);
f(end+1) = GDP - alph*K - (1-alph)*N;
f(end+1) = (1-psii)*GDP - cybar*C - iybar*I - rkpybar*U - (1-psii)*G;
f(end+1) = PI - bet*PIPT - kap*M - MPT;
f(end+1) = W - 1/(1+bet)*WL - bet/(1+bet)*(WPT) + 1/(1+bet)*(PI+DA) - bet/(1+bet)*(PIPT + DAPT) + kapw*(W - zeta*N + LAM) - MWT;
f(end+1) = IRT - rhor*IRL - (1-rhor)*(gampi*PI+gamy*GDP + gamy2*DY) - Q;


%Impose alternative PLM
f(end+1) = CPT   -fullm*C_p    -(~fullm)*Gxmat(1,:)*transpose(X);
f(end+1) = DAPT  -fullm*DA_p   -(~fullm)*Gxmat(2,:)*transpose(X);
f(end+1) = LAMPT -fullm*LAM_p  -(~fullm)*Gxmat(3,:)*transpose(X);
f(end+1) = PIPT  -fullm*PI_p   -(~fullm)*Gxmat(4,:)*transpose(X);

f(end+1) = PHIPT -fullm*PHI_p  -(~fullm)*Gxmat(5,:)*transpose(X);
f(end+1) = RKPT  -fullm*RK_p   -(~fullm)*Gxmat(6,:)*transpose(X);
f(end+1) = IPT   -fullm*I_p    -(~fullm)*Gxmat(7,:)*transpose(X);
f(end+1) = WPT   -fullm*W_p    -(~fullm)*Gxmat(8,:)*transpose(X);

%EXOGN PROCESS
f(end+1) = D_p - rhod*D;
f(end+1) = MPT_p - rhop*MPT - phip*EPSP;
f(end+1) = MWT_p - rhow*MWT - phiw*EPSW;
f(end+1) = G_p-rhog*G;
f(end+1) = Q_p-rhoq*Q;
f(end+1) = EPSP_p;
f(end+1) = EPSW_p;

%Fundamental Process - BLL Formulation
f(end+(1:4)) = [DX_p;Z_p;ZL_p;V_p] - GGmat{5}*[DX;Z;ZL;V];

%Kalman Filter - BLL Formulation
f(end+(1:4)) = [DXT_p;ZT_p;ZLT_p;VT_p]- GGmat{1}*[DX;Z;ZL;V] - GGmat{2}*[DXT;ZT;ZLT;VT];

XXS_noise   = transpose([DELA MP3 MP2 MP1 MM ML1 ML2 XI XIL EX EXL EXL2]);
XXS_noisep  = transpose([DELA_p MP3_p MP2_p MP1_p MM_p ML1_p ML2_p XI_p XIL_p EX_p EXL_p EXL2_p]);
XXST_noise  = transpose([DELAT MP3T MP2T MP1T MMT ML1T ML2T XIT XILT EXT EXLT EXL2T]);
XXST_noisep = transpose([DELAT_p MP3T_p MP2T_p MP1T_p MMT_p ML1T_p ML2T_p XIT_p XILT_p EXT_p EXLT_p EXL2T_p]);

%Fundamental Process - Noise Formulation
f(end+(1:12)) = XXS_noisep - GGmat2{5}*XXS_noise;

%Kalman Filter - Noise Formulation
f(end+(1:12)) = XXST_noisep- GGmat2{1}*XXS_noise - GGmat2{2}*XXST_noise;

%Real interest rate
f(end+1) = RREAL - (IRT - PIPT);

%AUX DEFINITIONS
f(end+1) = CL_p  - C;
f(end+1) = IRL_p - IRT;
f(end+1) = IL_p - I;
f(end+1) = WL_p  - W;
f(end+1) = NL_p  - N;
f(end+1) = GDPL_p - GDP;
f(end+1) = DY - GDP + GDPL - DA;
f(end+1) = DC - C + CL - DA;
f(end+1) = DI - I + IL - DA;
f(end+1) = DW - W + WL - DA;
f(end+1) = DN - N + NL;

%Link to economy
f(end+1) = DA - bllinfo*(DX+(Z-ZL)) - (1-bllinfo)*DELA;

% disp(['Nx:   ' num2str(length(X))]);
% disp(['Neq:  ', num2str(length(f))]);
% disp(['Nvar: ', num2str(length(X)+length(Y))]);



%Log-linear approx (Pure linear if log_var = [])
xlog = false(1,length(X));
ylog = false(1,length(Y));
log_var = [X(xlog) Y(ylog) XP(xlog) YP(ylog)];


mod.f = subs(f, log_var, exp(log_var));
mod.X = X;
mod.XP = XP;
mod.Y = Y;
mod.YP = YP;
mod.PARAM = PARAM;
mod.param = param;
mod.SET = SET;
mod.set = set;
mod.adiff = set.adiff; %Include anaylytical derivatives?
mod.xlog = xlog;
mod.ylog = ylog;


%Standard Errors
nx = length(X);
ny = length(Y);
mod.shck = sym(zeros(nx,10));

%Shock order: [eps,eta,v]
%Productivity Shocks/Innovations Rep
mod.shck((dx_idx:v_idx)-ny  ,[1,2,3])   = GGmat{6}(:,[1,2,4]); %From fundamental terms
mod.shck((dxt_idx:vt_idx)-ny,[1,2,3])   = GGmat{3}(:,[1,2,4]);  %From measurement terms

%add shocks for noise process using GMAT2
mod.shck((dela_idx:exl2_idx)-ny  ,[4 5])   = GGmat2{6}(:,[2,8]);
mod.shck((delat_idx:exl2t_idx)-ny,[4 5])   = GGmat2{3}(:,[2,8]);


%Other fund shocks
mod.shck(d_idx-ny,6) = sigd;
mod.shck([mpt_idx,epsp_idx]-ny,7) = sigp;
mod.shck([mwt_idx,epsw_idx]-ny,8) = sigw;
mod.shck(q_idx-ny,9) = sigq;
mod.shck(g_idx-ny,10) = sigg;

%Measurement Error (parameters are std-devs in param.m file)
mod.me = [];

%Derivatives using numerical toolbox
mod = anal_deriv(mod);

%Save index variables for use in main_prog
!rm -f v_idx.mat
save v_idx *_idx



