saved_files = {'Solution_BLL','Solution_GenNoise'};

load v_idx

K = 100;
bp_range = [6,32];
hrange = [1 4 8 12 20];
vdidx = [dy_idx,dc_idx,di_idx,dn_idx];
nper = 50;
nv = length(vdidx);
nh = length(hrange);
tab_out3 = nan(6,nv);
tab_out5 = nan(6,nv);

for mm = 1:2
    
    
    prod_only  = [1 2 4];
    noise_only = [3,5];
    
    clear hx2 gx2 eta2
    load(saved_files{mm}, 'gx2', 'hx2', 'eta2');
    ny = size(gx2,1);
    nx = size(hx2,1);
    neps = size(eta2,2);
    
    %Growth Rate PEV
    Vy = variance_decomposition(gx2,hx2,eta2);
    tab_out3((mm-1)*3+1,:) = sum(Vy(prod_only,vdidx));
    tab_out3((mm-1)*3+2,:) = sum(Vy(noise_only,vdidx));
    tab_out3((mm-1)*3+3,:) = 1-tab_out3((mm-1)*3+2,:)-tab_out3((mm-1)*3+1,:);
    
    %Filtered PEV
    [Vy,variances] = vdfilter(gx2,hx2,eta2,2*pi./bp_range([2,1]));
    tab_out5((mm-1)*3+1,(1:nv),1) = sum(Vy(prod_only,vdidx),1);
    tab_out5((mm-1)*3+2,(1:nv),1) = sum(Vy(noise_only,vdidx),1);
    tab_out5((mm-1)*3+3,(1:nv),1) = 1-sum(Vy(prod_only,vdidx),1)-sum(Vy(noise_only,vdidx),1);
end

cols1 = {''
        'News*'
        'Noise*'};
cols2 =  {''
        'Fund'
        'Noise'};


rows = {'Y', 'C', 'I', 'N'};

disp('**********************************************')
disp('TABLE 3:');
disp('**********************************************')   
disp(cellprintf('%s\t',cols1))
pretty_print(tab_out5(1:2,:)',2,rows)

disp(' ');  
disp(cellprintf('%s\t',cols2))
pretty_print(tab_out5(4:5,:)',2,rows)
disp('**********************************************')

