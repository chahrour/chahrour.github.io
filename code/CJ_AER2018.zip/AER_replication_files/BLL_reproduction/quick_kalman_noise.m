%QUICK_KALMAN_NOISE - Noise representation of the Blanchard et al (2013)
%information structure

function [out,H,F,Q,GG0,GG1,GG2,sqQ,P] = quick_kalman_noise(param)
scl = 500;

sigtmp = param.sigtmp;
sige = sigtmp*(1-param.rho);
sign = sqrt(param.rho)*sigtmp;

sigv = param.sigv;
rhox = param.rho;
rhoz = param.rho;

%variable order in state
C = [rhox, -((1+rhox)^2+rhoz*(sige^2/sign^2)),(1+rhox)^2 + (1+rhox^2) + (1+rhoz^2)*sige^2/sign^2, -((1+rhox)^2+rhoz*sige^2/sign^2),rhox];
rts = roots(C);
del1 = rts(3);
del2 = rts(4);

C = [del1*del2,-(del1+del2)*(1+del1*del2), ((del1+del2)^2 + (1+del1^2*del2^2) + del1*del2/rhox*sige^2/sigv^2), -(del1+del2)*(1+del1*del2), del1*del2];
rts = roots(C);
bet1 = rts(3);
bet2 = rts(4);

phi1 = del1+del2;
phi2 = -del1*del2;

thet1 = -(bet1+bet2);
thet2 = bet1*bet2;

lam2 = rhox;
lam1 = -(del1+del2)*(1+del1*del2)/(del1*del2)*lam2;
lam0 = ((del1+del2)^2 + (1+del1^2*del2^2))/(del1*del2)*lam2;

psi1 = rhoz+del1+del2;
psi2 = -rhoz*(del1+del2) - del1*del2;
psi3 = rhoz*del1*del2;

sigem = sqrt(del1*del2/rhox*sign^2)/scl;
sigex = sqrt(del1*del2/(bet1*bet2)*sigv^2);

%X =[al1 mp2 mp1 m0 ml1 ml2 ml3 xl1 xl2 ex1 ex2 ex3]

%state evol
F = spzeros(12,12);
F(1,1:6) = [rhox, scl*lam2,scl*lam1,scl*lam0,scl*lam1,scl*lam2];
F(2,[2 3 4]) = [psi1,psi2,psi3];
F(3,2) = 1;
F(4,3) = 1;
F(5,4) = 1;
F(6,5) = 1;
F(7,6) = 1;

F(8,8:11) = [phi1,phi2,thet1,thet2];
F(9,8) = 1;
F(11,10) = 1;
F(12,11) = 1;

%Observation
H = spzeros(2,12);
H(1,1)    = 1;
H(2,[3 4 5 8]) = [-scl*rhox scl*(1+rhox) -scl 1];
H = H';

%H = H(:,1);
Q = spzeros(12,12);%shocks to stats
Q(2,2) = sigem^2; %Shock hits M and EPSM
Q([8,10],[8,10]) = sigex^2; %Shock his xi and epsx;
R = zeros(size(H,2));
%P = dare(F',H,Q,R,0*H,eye(8));

%max(max(abs(((P-(F*(P-P*H*((H'*P*H+R)\(H'*P)))*F' + Q))))));


F = real(F);
H = real(H);
P = eye(size(F,1));
crit = 1;
mm = 1;
while crit > 1e-13 && mm < 15000
    P_new = (F*(P-P*H*((H'*P*H+R)\(H'*P)))*F' + Q);
    crit = max(max(abs(P-P_new)));
    P = .975*P + .025*1/2*(P_new + P_new');
    mm = mm+1;
end

%Depdendence on xi(t-1)
GG0 = P*H*((H'*P*H+R)\(H'*F));

%Depedence on xi(t-1,t-1)
GG1 = F + P*H*((H'*P*H+R)\(-H'*F));

%Depepdence on v(t), state shocks
GG2 = P*H*((H'*P*H+R)\(H'))*sqrt(Q);

%Depepdence on w(t), obs shocks
GG3 = P*H/(H'*P*H+R)*sqrt(R);

sqQ = sqrt(Q);
sqR = sqrt(R);

[sigY,sigX] = mom(H',F,Q);


out = [GG0(:);GG1(:);GG2(:);GG3(:);F(:);sqQ(:)];

out = full(out);

K = (F*P*H)/(H'*P*H+R);
eig(F-K*H');

H'*P*H;
H'*F*P*F'*H + H'*Q*H + R;

function out = obj(P,H,F,Q,R)

P = reshape(P,[11,12]);
out = 10000*vec(P-(F*(P-P*H*((H'*P*H+R)\(H'*P)))*F' + Q));