addpath('../DSGE_tools');
load v_idx
[param,set] = parameters;
paramv = struct2array(param);

np = 50;

noise_star_grid = linspace(.0001,12,np);
noise_shar0 = zeros(1,np);
noise_shar1 = zeros(1,np);
sig_noise0 = paramv(3);
for jj = 1:np
    
    paramv(3) = noise_star_grid(jj);
    
    [gx0,hx0,eta0] = imperfect_solve(paramv,set,0);  %Gen noise
    [gx1,hx1,eta1] = imperfect_solve(paramv,set,1);  %Orig Stucture
    
    Vy0 = vdfilter(gx0(dc_idx,:),hx0,eta0,2*pi./[6,32]);
    Vy1 = vdfilter(gx1(dc_idx,:),hx1,eta1,2*pi./[6,32]);
    
    noise_shar0(jj) = Vy0(5);%/(Vy0(7)+Vy0(6));
    noise_shar1(jj) = Vy1(3);%/(Vy1(1)+Vy1(2)+Vy1(5));
end

save ../info_figure/bll_noise_noisestar noise_star_grid noise_shar0 noise_shar1 sig_noise0
