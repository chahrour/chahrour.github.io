%COMPARE_INFO - compare forecasts with and without signals and compute
%noise share of forecasts.

bp_range = [6,32];
Hmax = 100;
%param = parameters;

%% NO SIGNAL CASE
%Compute the kalman filter equations for 
[~,H,F,Q,GG0,GG1,GG2,sqQ,P] = quick_kalman_noise_compare(param);

%Compute F^0 + F^1 + F^2 + ...
Fjj = zeros(size(F,1),size(F,2),Hmax);
Fjj(:,:,1) = eye(size(F));
for jj = 1:Hmax
    Fjj(:,:,jj+1) = F*Fjj(:,:,jj);
end
FJ = cumsum(Fjj,3);

%Compute FEV using inefficient nested loop
FEVn = zeros(size(H,2),size(H,2),Hmax);
for jj = 1:Hmax
   FEVn(:,:,jj) = H'*FJ(:,:,jj)*P*FJ(:,:,jj)'*H;
   for kk = (jj-1):-1:1
       FEVn(:,:,jj) = FEVn(:,:,jj) + H'*FJ(:,:,kk)*Q*FJ(:,:,kk)'*H;
   end
end
fe_varn = squeeze(FEVn(1,1,:));


%% YES SIGNAL CASE

%Compute the kalman filter equations with the signal
[~,H,F,Q,GG0,GG1,GG2,sqQ,P] = quick_kalman_noise(param);

%Compute F^0 + F^1 + F^2 + ...
Fjj = zeros(size(F,1),size(F,2),Hmax);
Fjj(:,:,1) = eye(size(F));
for jj = 1:Hmax
    Fjj(:,:,jj+1) = F*Fjj(:,:,jj);
end
FJ = cumsum(Fjj,3);

%Compute FEV using inefficient nested loop
FEV = zeros(size(H,2),size(H,2),Hmax);
for jj = 1:Hmax
   FEV(:,:,jj) = H'*FJ(:,:,jj)*P*FJ(:,:,jj)'*H;
   for kk = (jj-1):-1:1
       FEV(:,:,jj) = FEV(:,:,jj) + H'*FJ(:,:,kk)*Q*FJ(:,:,kk)'*H;
   end
end
fe_var = squeeze(FEV(1,1,:));

%% NO COMPUTE FORECAST NOISE SHARE

%Write the system as [x(t);x(t,t)] = HH*[x(t-1);x(t-1,t-1)] + ET*eps(t);
HH = [F,zeros(size(F));GG0,GG1];
ET = [sqQ;GG2];
ET = ET(:,[2,8]);

select_da = H(:,1)';
select_exp = zeros(length(F),2*length(F)); select_exp(:,length(F)+1:end) = eye(length(F));
gx_for = zeros(Hmax,2*length(F));
for jj = 1:Hmax
    %Forecast for growth rates
    gx_for(jj,:) = select_da*F^(jj-1)*select_exp;
end
%Forecast for levels
gx_for = cumsum(gx_for);

sigE       = mom(gx_for,HH,ET*ET');
sigE_noise = mom(gx_for,HH,ET(:,2)*ET(:,2)');
sigE_fund  = mom(gx_for,HH,ET(:,1)*ET(:,1)');

prefstmp.ndec   = 0;
prefstmp.toscr  = false;
fnshr           = vdecom_table(gx_for,HH,ET,1:Hmax,{},prefstmp);
fnshr_bc        = vdfilter(gx_for,HH,ET,2*pi./bp_range([2,1]));


save ../info_figure/bll_forecasts fnshr fnshr_bc fe_var fe_varn
