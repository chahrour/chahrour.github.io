% -------------------------------------------------------------------------
% Compute projection coefficients
% -------------------------------------------------------------------------

% Load transition matrices
load Solution_BLL

nx = size(hx2,1);
ny = size(gx2,1);
prefs.ndec = 2;
vlist     = { 'DGDP',  'DC',   'DI',  'DN'};
vvidx     = [ dy_idx,dc_idx,di_idx,dn_idx];

funds_idx = [da_idx];
other_funds_idx = [d_idx,mpt_idx,mwt_idx,g_idx,q_idx];

%Drop things
keep_idx = 1:(vt_idx-ny);

A = gx2(:,keep_idx);
B = hx2(keep_idx,keep_idx);
C = eta2(keep_idx,:);
D = zeros(size(A));

% Endogenous variables and fundamentals
H = A(da_idx,:);
A = A([dy_idx,dc_idx,di_idx,dn_idx],:);

% Grid for detrending parameter
lam = linspace(0,0.9,10)';

% Outer loop
J  = 1000;
ny = size(A,1);
nx = size(B,1);
ne = size(C,2);
nz = size(H,1);
for i = 1:length(lam);

% Augmented transition matrices    
Alam = [eye(ny),zeros(ny,nx)]; 
Blam = [lam(i).*eye(ny),A;zeros(nx,ny),B];
Clam = [zeros(ny,ne);C];
Hlam = [zeros(nz,ny),H];

% Projection on productivity shocks
[M,Q,K,V] = proj(Alam,Blam,Clam,Hlam,J);

% Current and past fundamental share
pshare = M(:,:,J+1)*V*M(:,:,J+1)';
for j = J+2:2*J+1
    pshare = pshare + M(:,:,j)*V*M(:,:,j)';
end
var_c = Q;
pshares(:,i) = diag(pshare)./diag(var_c);

% Future fundamental share
fshare = 0;
for j = 1:J
    fshare = fshare + M(:,:,j)*V*M(:,:,j)';
end
fshares(:,i) = diag(fshare)./diag(var_c);    
%disp(lam(i));
end

% Save results
save('../info_figure/shares_bll','pshares','fshares','lam');


