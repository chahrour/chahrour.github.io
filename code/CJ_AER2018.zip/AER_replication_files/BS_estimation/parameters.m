% PARAMETERS - This function returns a parameter structure to use in the model solution.


function [param,set,GG,GG2,Gxmat] = parameters()
                                                       

set.adiff      = 0;
set.approx_deg = 1;

%Filled in later
set.lam0 = [];
set.lam1 = [];
set.lam2 = [];


%Full or partial info
set.fullm = 1;

%parameters B&S calibrate
set.bet = .99;            %discount factor
set.alph = 0.36;          %capital share
set.delt = .03;            %depreciation rate
set.gstar = exp(.0033);   %steady-state TFP growth
set.Gshr = .2;            %govm't share
set.rhog = 0.95;          %peristence of govenment rate
set.sigg = .25;           %govt shock.



param.rhoga = 0.7373;         %autocorrelation of growth rate
param.sigga = 0.1784;         %shock to growth rate
param.sigea = 0.5748;         %shock to level
param.siges = 0.1225;         %noise in signal


%pi target shocks
param.rhop  = 0.95;     



%BS parameters
param.phipi = 1.2915;         %taylor rule on inflation
param.phiy  = 0.9447;         %taylor rule on output growth
param.rhoi  = 0.6566;         %taylor smoothing

param.kapp  = 0.3029;          %habit
param.gam   = 0.1677/(set.delt+set.gstar^(1/(1-set.alph))-1); %adjustment cost elasticity (denom aligns with B&S code)
param.etta  = 1.3234;          %labor supply elasticity (don't confuse with eta, covariance matrix of structural shocks)
param.sigi  = .5*0.2146;          %shocks to taylor rule?
set.xi    = 13.71;         %elatisticy of substitution in aggregator
param.thet  = 0.7649;          %calvo prop of not changing

param.me1 = 0.005;
param.me2 = 0.005;
param.me3 = 0.005;
param.me4 = 0.005;
param.me5 = 0.005;

%Determined in equilbrium
set.ybar  = NaN;      
set.mcbar = NaN;
set.ikbar = NaN;
set.irbar = NaN;


%**************************************************************************
% CHOOSE INFO STRUCTURE TO SOLVE WITH
%**************************************************************************
set.bsinfo = true;   %true mean use B&S rep; false means use nosie rep

%**************************************************************************
% ORIGINAL BS INFO STRUCTURE
%**************************************************************************

ggvec = quick_kalman(param);

%parameters from kalman filter
GG = cell(1,6);
mm = 1;
ns = 2;
for jj = 0:5
    GG{jj+1} = sym(zeros(2));
    for kk = 1:ns
        for ll = 1:ns
            str = ['gg' num2str(jj), '_' num2str(ll),num2str(kk)'];
            eval(['set.' str '=ggvec(mm);']);   
            GG{jj+1}(ll,kk) = sym(str);
            mm = mm+1;
        end
    end
end



%**************************************************************************
% FULL NOISE ROTATION
%**************************************************************************
[ggvec2,H] = quick_kalman_noise(param);
%parameters from kalman filter
GG2 = cell(1,6);
mm = 1;
ns = 5;
for jj = 0:5
    GG2{jj+1} = sym(zeros(2));
    for kk = 1:ns
        ncol = ns; if jj == 3; ncol= 2;end
        for ll = 1:ncol
            str = ['gg_2' num2str(jj), '_' num2str(ll),num2str(kk)'];
            eval(['set.' str '=ggvec2(mm);']);   
            GG2{jj+1}(ll,kk) = sym(str);
            mm = mm+1;
        end
    end
end
set.lam0 = H(1);
set.lam1 = H(2);
set.lam2 = H(3);

%**************************************************************************
% PLM PARAMETERS
%**************************************************************************

nx = 23;
Gxmat = sym(zeros(5,nx));
%PLM
for mm = 1:nx
    for jj = 1:5
        str = ['gx_' num2str(jj),'_', num2str(mm)];
        eval(['set.' str '=0;']);
        Gxmat(jj,mm) = sym(str);
    end
end


