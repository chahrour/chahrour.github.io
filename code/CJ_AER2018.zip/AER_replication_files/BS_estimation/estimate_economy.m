addpath('../DSGE_tools');

load v_idx
[param,set] = parameters;
paramv = struct2array(param);
nms = fieldnames(parameters);

%FOR A LOOK AT RESULTS
vlist     = {'dGDP', 'dC',    'dN',  'PI',  'IR'  'DA'};
vvidx     = [dy_idx, dc_idx, dn_idx, pi_idx, ir_idx, da_idx];
prefs.ndec = 3;

%What do I want to see?
names    = {'dY', 'dC','dN','PI', 'IR'};
gx_idx   = [dy_idx,dc_idx,dn_idx,pi_idx,ir_idx];

load ../data/data_final data_vec

%5% measurement error
%rmax = .05*var(data_vec);

%2.5% measurement error
rmax = .025*var(data_vec);

%% TIME TO ESTIMATE
lbnd = [.0001;
     0.0001; 
     0.0001;
     0.0001;
     0.75;
     1.01 ;
     -0.5  ;
     0     ;
     0     ;
     0     ;
     0.1   ;
     0.001 ;
     0.01  ;
     0*rmax'];
 
ubnd = [.99;
    10;
    10 ;
    10;
    .999;
    5;
    2;
    0.999;
    0.999;
    15;
    5;
    5;
    .999;
    rmax'];

% disp(' ');disp('LB|Init|UB');
% for jj =1:length(paramv)
%     disp([sprintf('%s\t', nms{jj}), ':' sprintf('%2.3f\t',lbnd(jj)), ' ', sprintf('%2.3f\t',paramv(jj)), ' ' sprintf('%2.3f\t',ubnd(jj))])
% end
    
param0 = paramv;
%% Test objective
obj1 = @(paramv)model_loss(paramv,set,gx_idx,data_vec);
obj1(param0);
obj2 = obj1;

%% SAVED RESULTS

% 5.0% noise estimation: LL = 1135.5142
%param_final = [0.94916274	0.19533676	0.82082433	0.00039178	0.99850749	4.78780995	0.05077816	0.5187036	0.25255287	6.00555636	4.9994511	0.13833202	0.94689553	0.03836467	0.01369896	0.03532693	0.01612461	0.04035297];

% 2.5% noise estimation: LL = 1763.4293
param_final = [0.923148	0.219023	0.871648	0.000124	0.99892	4.807296	0.004223	0.507224	0.314478	5.209284	4.99759	0.134321	0.942018	0.019176	0.006744	0.017642	0.008053	0.020147];

[gx,hx,eta,crit] = imperfect_solve(param_final,set,0);
%mom_tab(gx,hx,eta*eta',vvidx,vlist,prefs);disp(' ');
LL = -obj1(param_final);
BIC = log(length(data_vec))*length(paramv)-2*LL;
%fevd_table(gx,hx,eta,[1,4,8,16,20],dc_idx,'DC',prefs);
[Vy] = vdfilter(gx([dc_idx,dy_idx],:),hx,eta,2*pi./[6,32]);
Vyc = Vy(end,1);
%disp(['Cons Noise Shr: ' num2str(Vyc)])
%disp(['BIC           : ' num2str(BIC)]);

return

%% REDO ESTIMATION
loc = pwd;
if strcmp(loc(2), 'U')
    % LOCAL SEARCH - FMINCON
    warning off;
    param0 = param_final;
    options = optimoptions('fmincon');
    options.Display = 'iter';
    options.UseParallel = false;
    options.MaxFunctionEvaluations = 1000;
    param_final = fmincon(obj1,param0,[],[],[],[],lbnd,ubnd,[],options);
else
    % GLOBAL SEARCH
    ns     = 4;%8*24;  %Number of global_search threads
    opt.type = 'fmincon';
    global_search
end

for jj =1:length(paramv)
    disp([sprintf('%s\t', nms{jj}), ':' sprintf('%2.3f\t',lbnd(jj)), ' ', sprintf('%2.4f\t',param_final(jj)), ' ' sprintf('%2.3f\t',ubnd(jj))])
end
param_struct = array2struct(nms,param_final);



