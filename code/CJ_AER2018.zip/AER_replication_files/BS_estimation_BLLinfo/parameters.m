% PARAMETERS - This function returns a parameter structure to use in the model solution.


function [param,set,GG,GG2,Gxmat] = parameters()
                                                       

set.adiff      = 0;
set.approx_deg = 1;


%Full or partial info
set.fullm = 1;

%parameters B&S calibrate
set.bet = .99;            %discount factor
set.alph = 0.36;          %capital share
set.delt = .03;            %depreciation rate
set.gstar = exp(.0033);   %steady-state TFP growth
set.Gshr = .2;            %govm't share
set.rhog = 0.95;          %peristence of govenment rate
set.sigg = .25;           %govt shock.


%Parameters BLL info
sigtmp = 1.1977;
rho = 0.9426;
param.rho    = rho;
param.sigtmp = 1.1977;
param.sigv   = 1.4738;



param.rhop  = 0.95;        

%BS Rule
param.phipi = 1.31;         %taylor rule on inflation
param.phiy  = 0.94;         %taylor rule on output growth
param.rhoi  = 0.66;         %taylor smoothing


param.kapp  = 0.31;          %habit
param.gam   = 0.16/(set.delt+set.gstar^(1/(1-set.alph))-1); %adjustment cost elasticity (denom aligns with B&S code)
param.etta  = 1.32;          %labor supply elasticity (don't confuse with eta, covariance matrix of structural shocks)
param.sigi  = .5*0.21;          %shocks to taylor rule?
set.xi    = 13.71;         %elatisticy of substitution in aggregator
param.thet  = 0.76;          %calvo prop of not changing

param.me1 = 0.005;
param.me2 = 0.005;
param.me3 = 0.005;
param.me4 = 0.005;
param.me5 = 0.005;

%Determined in equilbrium
set.ybar  = NaN;      
set.mcbar = NaN;
set.ikbar = NaN;
set.irbar = NaN;


%**************************************************************************
% CHOOSE INFO STRUCTURE TO SOLVE WITH
%**************************************************************************
set.bsinfo = true;   %true mean use B&S rep; false means use nosie rep

%********************* *****************************************************
% ORIGINAL BLL INFO STRUCTURE
%**************************************************************************

ggvec = quick_kalman(param);

%parameters from kalman filter
GG = cell(1,6);
mm = 1;
ns = 4;
for jj = 0:5
    ncol = ns; if jj == 3; ncol= 2;end
    GG{jj+1} = sym(zeros(ns,ncol));
    for kk = 1:ncol
        for ll = 1:ns
            str = ['gg' num2str(jj), '_' num2str(ll) '_' num2str(kk)];
            eval(['set.' str '=ggvec(mm);']);   
            GG{jj+1}(ll,kk) = sym(str);
            mm = mm+1;
        end
    end
  
end



%**************************************************************************
% FULL NOISE ROTATION
%**************************************************************************
ggvec2 = quick_kalman_noise(param);
%parameters from kalman filter
GG2 = cell(1,6);
mm = 1;
ns = 12;
for jj = 0:5
    ncol = ns; if jj == 3; ncol= 2;end
    GG2{jj+1} = sym(zeros(ns,ncol));
    for kk = 1:ncol
        for ll = 1:ns
            str = ['gg_2' num2str(jj), '_' num2str(ll) '_' num2str(kk)];
            eval(['set.' str '=ggvec2(mm);']);   
            GG2{jj+1}(ll,kk) = sym(str);
            mm = mm+1;
        end
    end
end



%**************************************************************************
% PLM PARAMETERS
%**************************************************************************

nx = 40;
Gxmat = sym(zeros(5,nx));
%PLM
for mm = 1:nx
    for jj = 1:5
        str = ['gx_' num2str(jj),'_', num2str(mm)];
        eval(['set.' str '=0;']);
        Gxmat(jj,mm) = sym(str);
    end
end


