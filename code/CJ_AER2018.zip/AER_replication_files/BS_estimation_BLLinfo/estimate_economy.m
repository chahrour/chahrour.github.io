addpath('../DSGE_tools');

load v_idx
[param,set] = parameters;
paramv = struct2array(param);
nms = fieldnames(parameters);

%FOR A LOOK AT RESULTS
vlist     = {'dGDP', 'dC',    'dN',  'PI',  'IR'  'DA'};
vvidx     = [dy_idx, dc_idx, dn_idx, pi_idx, ir_idx, da_idx];
prefs.ndec = 3;

%What do I want to see?
names    = {'dY', 'dC','dN','PI', 'IR'};
gx_idx   = [dy_idx,dc_idx,dn_idx,pi_idx,ir_idx];

load ../data/data_final data_vec

%5% measurement error
%rmax = .05*var(data_vec);

%2.5% measurement error
rmax = .025*var(data_vec);

%% TIME TO ESTIMATE
lbnd = [.0001;
     0.0001; 
     0.0001;
     0.75;
     1.01 ;
     -0.5  ;
     0     ;
     0     ;
     0     ;
     0.1   ;
     0.001 ;
     0.01  ;
     0*rmax'];
 
ubnd = [.99;
    10;
    10;
    .999;
    5;
    2;
    0.999;
    0.999;
    15;
    5;
    5;
    .999;
    rmax'];

% disp(' ');disp('LB|Init|UB');
% for jj =1:length(paramv)
%     disp([sprintf('%s\t', nms{jj}), ':' sprintf('%2.3f\t',lbnd(jj)), ' ', sprintf('%2.3f\t',paramv(jj)), ' ' sprintf('%2.3f\t',ubnd(jj))])
% end
    
param0 = paramv;
%% Test objective
obj1 = @(paramv)model_loss(paramv,set,gx_idx,data_vec);
obj1(param0);
obj2 = obj1;

%% SAVED RESULTS

% 5% estimation: LL 1186.0168
%param_final = [0.8596644	1.2481206	0.00069629	0.9920891	4.99998432	0.04859033	0.35638955	0.02533188	3.66942327	4.9812918	0.20883932	0.93016408	0.03777525	0.01356793	0.03520824	0.01612377	0.03990896];

%2.5% estimation: LL 1780.0209
param_final = [0.858113	1.263327	0.000997	0.989155	4.889657	0.048411	0.407376	0.025232	3.46699	4.999926	0.162896	0.930904	0.019143	0.00681	0.017663	0.00806	0.019941];
    

[gx,hx,eta,crit] = imperfect_solve(param_final,set,0);
%mom_tab(gx,hx,eta*eta',vvidx,vlist,prefs);disp(' ');
LL = -obj1(param_final);
BIC = log(length(data_vec))*length(paramv)-2*LL;
%fevd_table(gx,hx,eta,[1,4,8,16,20],dc_idx,'DC',prefs);
[Vy] = vdfilter(gx([dc_idx,dy_idx],:),hx,eta,2*pi./[6,32]);
Vyc = Vy(end,1);
%disp(['Cons Noise Shr: ' num2str(Vyc)])
%disp(['BIC           : ' num2str(BIC)]);

return
%% ESTIMATION
loc = pwd;
if strcmp(loc(2), 'U')
    % LOCAL SEARCH - FMINCON
    warning off;
    param0 = param_final;
    options = optimoptions('fmincon');
    options.Display = 'iter';
    options.UseParallel = false;
    options.MaxFunctionEvaluations = 1000;
    param_final = fmincon(obj1,param0,[],[],[],[],lbnd,ubnd,[],options);
else
    % GLOBAL SEARCH
    ns     = 8*24;  %Number of global_search threads
    opt.type = 'fmincon';
    global_search
end

for jj =1:length(paramv)
    disp([sprintf('%s\t', nms{jj}), ':' sprintf('%2.3f\t',lbnd(jj)), ' ', sprintf('%2.3f\t',param_final(jj)), ' ' sprintf('%2.3f\t',ubnd(jj))])
end
param_struct = array2struct(nms,param_final);



