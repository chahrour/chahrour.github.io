addpath('../DSGE_tools');

load v_idx
[param,set] = parameters;
paramv = struct2array(param);
nms = fieldnames(parameters);

%FOR A LOOK AT RESULTS
vlist     = {'dGDP', 'dC',    'dN',  'PI',  'IR'  'DA'};
vvidx     = [dy_idx, dc_idx, dn_idx, pi_idx, ir_idx, da_idx];
prefs.ndec = 3;

%What do I want to see?
names    = {'dY', 'dC','dN','PI', 'IR'};
gx_idx   = [dy_idx,dc_idx,dn_idx,pi_idx,ir_idx];

load ../data/data_final data_vec

%5% measurement error
%rmax = .05*var(data_vec);

%2.5% measurement error
rmax = .025*var(data_vec);

%% TIME TO ESTIMATE
lbnd = [.0001;
     0.0001; 
     0.0001;
     0.0001;
     0.0001;
     1/5  ;
     0.001     ;
     0.001     ;
     0.001     ;
     0.001   ;
     1.01 ;
     0.001;
     0.001;
     0.75;
     0.00001;
     0*rmax'];
 
ubnd = [.99;
    10;
    10 ;
    10;
    .99;
    5;
    10;
    15;
    0.999;
    0.002;%0.999; (Use the tight bound for the flex wage case!)
    5;
    2;
    .999;
    .999;
    3;
    rmax'];

% disp(' ');disp('LB|Init|UB');
% for jj =1:length(paramv)
%     disp([sprintf('%s\t', nms{jj}), ':' sprintf('%2.3f\t',lbnd(jj)), ' ', sprintf('%2.3f\t',paramv(jj)), ' ' sprintf('%2.3f\t',ubnd(jj))])
% end

param0 = paramv;
%% Test objective
obj1 = @(paramv)model_loss(paramv,set,gx_idx,data_vec);
obj1(param0);
obj2 = obj1;

%% SAVED RESULTS

%5% estimate: LL = 786.8635
%param_final = [0.91949823	0.21319396	0.89501206	0.00010221	0.81812156	0.2	0.46015564	14.99999992	0.88227517	0.90587287	4.85819522	0.001	0.41565409	0.999	0.32978858	0.03836669	0.01370243	0.03532726	0.01612468	0.04035373];

%2.5% estimate: LL = 965.0481
%param_final =[0.91662769	0.25528428	0.9762111	0.0001026	0.81447308	0.2	0.50234279	14.99999993	0.87707838	0.90133525	4.22587958	0.001	0.46859188	0.999	0.33940413	0.01918334	0.00685121	0.01766363	0.00806234	0.02017686];

%Flex wage: LL = 1098.9185
param_final = [0.89796526	0.4429724	1.23579295	0.00010317	0.62088851	0.2	0.4627527	14.99999992	0.86538926	0.002	1.01	0.47415575	0.28125818	0.94252555	0.30886143	0.01918334	0.00685121	0.01766363	0.0049885	0.02017686];

[gx,hx,eta,crit] = imperfect_solve(param_final,set,0);
%mom_tab(gx,hx,eta*eta',vvidx,vlist,prefs);disp(' ');
LL = -obj1(param_final);
BIC = log(length(data_vec))*length(paramv)-2*LL;
%fevd_table(gx,hx,eta,[1,4,8,16,20],dc_idx,'DC',prefs);
[Vy] = vdfilter(gx([dc_idx,dy_idx],:),hx,eta,2*pi./[6,32]);
Vyc = Vy(5,1);
%disp(['Cons Noise Shr: ' num2str(Vyc)])
%disp(['BIC           : ' num2str(BIC)]);

return
%% ESTIMATION
loc = pwd;
if strcmp(loc(2), 'U')
    % LOCAL SEARCH - FMINCON
    warning off;
    param0 = param_final;
    options = optimoptions('fmincon');
    options.Display = 'iter';
    options.UseParallel = false;
    options.MaxFunctionEvaluations = 1000;
    param_final = fmincon(obj1,param0,[],[],[],[],lbnd,ubnd,[],options);
else
    % GLOBAL SEARCH
    ns     = 8*24;  %Number of global_search threads
    opt.type = 'fmincon';
    global_search
end

for jj =1:length(paramv)
    disp([sprintf('%s\t', nms{jj}), ':' sprintf('%2.3f\t',lbnd(jj)), ' ', sprintf('%2.3f\t',param_final(jj)), ' ' sprintf('%2.3f\t',ubnd(jj))])
end
param_struct = array2struct(nms,param_final);


