% MODEL - Generate linearized version of the Blanchard et al (2013) model
% with Barksy-Sims (2012) information structures
 

function [mod,param,set] = model(param,set,GGmat,GGmat2,Gxmat)


%Name of text files
mod.fname   = 'model_prog.m';
mod.ss_call = 'model_ss.m';

%Declare parameters symbols: parameters are values to be estimated, symbols are values that are "fixed"
PARAM = struct2sym(param);
SET   = struct2sym(set);

%Declare Needed Symbols 
syms KBAR CL IL IRL WL D DA MPT MWT G GDPL DY DC DI DA Q EPSP EPSW SIGNAL
IR = sym('IR');
syms C I GDP N K U LAM PHI RK W PI M DY DW DN NL DX Z ZL V DXT ZT ZLT VT 
syms DX DZ ETTA V VL DXT DZT ETTAT VT VLT CPT DAPT LAMPT PIPT  PIPT PHIPT RKPT IPT WPT
syms DELAT MP3T MP2T MP1T MMT ML1T ML2T XIT XILT EXT EXLT EXL2T DELA MP3 MP2 MP1 MM ML1 ML2 XI XIL EX EXL EXL2 DELAT MP3T MP2T MP1T MT ML1T ML2T XIT XILT EXT EXLT EXL2T
syms XX XXL XXLL V EV XXT XXLT XXLLT VT EVT MU1 GG MU1T GGT
syms MP1 MM ML1 XI XIL EX EXL AAL MP1T MMT ML1T XIT XILT EXT EXLT AALT

%For Noise Rep
XXS_noise   = [XX XXL XXLL V EV];
XXS_noisep  = make_prime(XXS_noise);

XXST_noise  = [XXT XXLT XXLLT VT EVT];
XXST_noisep  = make_prime(XXST_noise);

%For BLL rep
XXS_bll   = [MU1 GG];
XXS_bllp  = make_prime(XXS_bll);

XXST_bll  = [MU1T GGT];
XXST_bllp = make_prime(XXST_bll);

%Declare X and Y vectors
X  = [KBAR CL IL IRL WL NL D MPT MWT G Q EPSP EPSW GDPL ... %Non-info/productivity shocks
      XXS_bll  XXST_bll ...                                 %BS Fundamentals/Expectations
      XXS_noise XXST_noise];                               %Noise rep Fundamentals/Expectations
     

  %Noise Rep Fundamentals/Expectations
Y  = [DY DC DI DW DN PI C I GDP N K U LAM PHI RK W  M IR  DA SIGNAL...
      CPT DAPT LAMPT PIPT PHIPT RKPT IPT WPT DX]; %Variables that appear as expectations
XP = make_prime(X);
YP = make_prime(Y);
make_index([Y,X]);

%Model Equations
f(1)     = (GAM-h*bet)*(GAM-h)*LAM - h*bet*GAM*CPT + (GAM^2+h^2*bet)*C - h*GAM*CL - h*bet*GAM*DAPT + h*GAM*DA;
f(end+1) = LAM-IR-LAMPT+DAPT+PIPT;
f(end+1)  = PHI-(1-delt)*bet*GAM^-1*(PHIPT-DAPT)-(1-(1-delt)*bet*GAM^-1)*(LAMPT - DAPT + RKPT);
f(end+1) = LAM - PHI - D + chi*GAM^2*(I-IL+DA) - bet*chi*GAM^2*(IPT - I + DAPT);
f(end+1) = RK-xi*U;
f(end+1) = M - alph*RK - (1-alph)*W;
f(end+1) = RK - W + K - N;
f(end+1) = K - U - KBAR + DA;
f(end+1) = KBAR_p - (1-delt)*GAM^-1*(KBAR-DA) - (1-(1-delt)*GAM^-1)*(D+I);
f(end+1) = GDP - alph*K - (1-alph)*N;
f(end+1) = (1-psii)*GDP - cybar*C - iybar*I - rkpybar*U - (1-psii)*G;
f(end+1) = PI - bet*PIPT - kap*M - MPT;
f(end+1) = W - 1/(1+bet)*WL - bet/(1+bet)*(WPT) + 1/(1+bet)*(PI+DA) - bet/(1+bet)*(PIPT + DAPT) + kapw*(W - zeta*N + LAM) - MWT;
f(end+1) = IR - rhor*IRL - (1-rhor)*(gampi*PI+gamy*GDP + gamy2*DY) - Q;


%Impose alternative PLM
f(end+1) = CPT  -fullm*C_p   -(~fullm)*Gxmat(1,:)*transpose(X);
f(end+1) = DAPT -fullm*DA_p  -(~fullm)*Gxmat(2,:)*transpose(X);
f(end+1) = LAMPT -fullm*LAM_p -(~fullm)*Gxmat(3,:)*transpose(X);
f(end+1) = PIPT -fullm*PI_p  -(~fullm)*Gxmat(4,:)*transpose(X);

f(end+1) = PHIPT -fullm*PHI_p  -(~fullm)*Gxmat(5,:)*transpose(X);
f(end+1) = RKPT -fullm*RK_p  -(~fullm)*Gxmat(6,:)*transpose(X);
f(end+1) = IPT -fullm*I_p  -(~fullm)*Gxmat(7,:)*transpose(X);
f(end+1) = WPT -fullm*W_p  -(~fullm)*Gxmat(8,:)*transpose(X);


%EXOGN PROCESS
f(end+1) = D_p - rhod*D;
f(end+1) = MPT_p - rhop*MPT - phip*EPSP;
f(end+1) = MWT_p - rhow*MWT - phiw*EPSW;
f(end+1) = G_p-rhog*G;
f(end+1) = Q_p-rhoq*Q;
f(end+1) = EPSP_p;
f(end+1) = EPSW_p;

%Define DX
f(end+1) = DX - (XX-XXL);

%Fundamental Process - BS Formulation
f(end+(1:2)) = transpose(XXS_bllp) - GGmat{5}*transpose(XXS_bll);

%Kalman Filter - BS Formulation
f(end+(1:2)) = transpose(XXST_bllp)- GGmat{1}*transpose(XXS_bll) - GGmat{2}*transpose(XXST_bll);

%Fundamental Process - Noise Formulation
f(end+(1:5)) = transpose(XXS_noisep) - GGmat2{5}*transpose(XXS_noise);

%Kalman Filter - Noise Formulation
f(end+(1:5)) = transpose(XXST_noisep) - GGmat2{1}*transpose(XXS_noise) - GGmat2{2}*transpose(XXST_noise);

%Link to economy
f(end+1) = DA - bllinfo*(MU1) - (1-bllinfo)*([lam0,lam1,lam2]*[XX;XXL;XXLL]);

%Signal in noise economy
f(end+1) = SIGNAL - sum(XXS_noise([2,4]));

% %Smooth-detrended variables
% f(end+1) = YDTL_p - YDT;
% f(end+1) = YDT - (1-omeg)*(YDTL + DY);
% 
% f(end+1) = CDTL_p - CDT;
% f(end+1) = CDT - (1-omeg)*(CDTL + DC);
% 
% f(end+1) = IDTL_p - IDT;
% f(end+1) = IDT - (1-omeg)*(IDTL + DI);
% 
% f(end+1) = NDTL_p - NDT;
% f(end+1) = NDT - (1-omeg)*(NDTL + DN);

%AUX DEFINITIONS
f(end+1) = CL_p  - C;
f(end+1) = IRL_p - IR;
f(end+1) = IL_p - I;
f(end+1) = WL_p  - W;
f(end+1) = NL_p  - N;
f(end+1) = GDPL_p - GDP;
f(end+1) = DY - GDP + GDPL - DA;
f(end+1) = DC - C + CL - DA;
f(end+1) = DI - I + IL - DA;
f(end+1) = DW - W + WL - DA;
f(end+1) = DN - N + NL;

% disp(['Nx:   ' num2str(length(X))]);
% disp(['Neq:  ', num2str(length(f))]);
% disp(['Nvar: ', num2str(length(X)+length(Y))]);



%Log-linear approx (Pure linear if log_var = [])
xlog = false(1,length(X));
ylog = false(1,length(Y));
log_var = [X(xlog) Y(ylog) XP(xlog) YP(ylog)];


mod.f = subs(f, log_var, exp(log_var));
mod.X = X;
mod.XP = XP;
mod.Y = Y;
mod.YP = YP;
mod.PARAM = PARAM;
mod.param = param;
mod.SET = SET;
mod.set = set;
mod.adiff = set.adiff; %Include anaylytical derivatives?
mod.xlog = xlog;
mod.ylog = ylog;


%Standard Errors
nx = length(X);
ny = length(Y);
mod.shck = sym(zeros(nx,10));

%Productivity Shocks/Innovations Rep
mod.shck((mu1_idx:gg_idx)-ny  ,[2 1])   = GGmat{6};
mod.shck((mu1t_idx:ggt_idx)-ny,[2 1])   = GGmat{3};
mod.shck((mu1t_idx:ggt_idx)-ny,[3])     = GGmat{4}(:,2);

%add shocks for noise process using GMAT2
mod.shck((xx_idx:ev_idx)-ny  ,[4 5])   = GGmat2{6}(:,[1,4]);
mod.shck((xxt_idx:evt_idx)-ny,[4 5])   = GGmat2{3}(:,[1,4]);
 
%Other fund shocks
mod.shck(d_idx-ny,6) = sigd;
mod.shck([mpt_idx,epsp_idx]-ny,7) = sigp;
mod.shck([mwt_idx,epsw_idx]-ny,8) = sigw;
mod.shck(q_idx-ny,9) = sigq;
mod.shck(g_idx-ny,10) = sigg;

%Measurement Error (parameters are std-devs in param.m file)
mod.me = [];

%Derivatives using numerical toolbox
mod = anal_deriv(mod);

%Save index variables for use in main_prog
!rm -f v_idx.mat
save v_idx *_idx



