function [M,Q,K,V] = proj(A,B,C,H,h)
% -------------------------------------------------------------------------
% Project y(t) onto innovations in {z(t)} in a model of the form
%       y(t) = A*x(t)
%       x(t) = b + B*x(t-1) + C*e(t)
%       z(t) = H*x(t);
% -------------------------------------------------------------------------

% Options
if nargin < 5; h = 1000; end;

% Initialize
ny = size(A,1);
nx = size(B,1);

% Fundamental innovations
[K,V] = kalman(H,B,C);
K = double(K);
V = double(V);

% Augmented state
Bs = [B,zeros(nx);K*H*B,B-K*H];
Cs = [C;K*H*C];

% Augmented observation
Ay = [A*B,zeros(ny,nx)];
Dy = A*C;
Aw = [H*B,-H];
Dw = H*C;

% Impact projection matrices
G_ss0 = lyapunov(Bs,Cs*Cs');
G_yw0 = Ay*G_ss0*Aw' + Dy*Dw';
M0    = G_yw0/V;
Q     = Ay*G_ss0*Ay' + Dy*Dy'; %variance of y(t)

% Other leads and lags
G_ssp = G_ss0;
G_sep = Cs;
M     = M0;
for j = 1:h
    G_ssp     = Bs*G_ssp;
    G_ywp     = Ay*G_ssp*Aw' + Ay*G_sep*Dw'; 
    Mp        = G_ywp/V;
    G_ssm     = G_ssp';
    G_ywm     = Ay*G_ssm*Aw' + Dy*G_sep'*Aw';
    Mm        = G_ywm/V;
    M         = cat(3,Mm,M,Mp);
    G_sep     = Bs*G_sep;
end
end

% -------------------------------------------------------------------------
% Auxiliary functions
% -------------------------------------------------------------------------

function [K,V] = kalman(A,B,C,D,iter)
% -------------------------------------------------------------------------
% Compute innovations representation of a model of the form
%       y(t) = a + A*x(t) + D*u(t)
%       x(t) = b + B*x(t-1) + C*e(t)
% -------------------------------------------------------------------------

% Options
if nargin < 5; iter = 1; end;
if nargin < 4; D = 0; end;

% Run filter
if iter == 1;
    err   = 1;
    count = 0;
    P     = 0.01*eye(size(B,1));
    while err > 1e-14;
        Pnew = B*P*B' + C*C' - B*P*A'/(A*P*A' + D*D')*A*P*B';
        err   = max(max(abs(Pnew-P)));
        P     = Pnew;
        count = count + 1;
        if count > 1e5; 
            fprintf('ricatti convergence norm = %d\n',err); break; 
        end;
    end
elseif iter == 0;
    P = dare(B',A',C*C',D*D');
end
V = A*P*A' + D*D';
K = B*P*A'/V;
end

function X = lyapunov(A,B,version)
% -------------------------------------------------------------------------
% Solve Lyapunov equation: X = A*X*A' + B
% -------------------------------------------------------------------------

% Options
if nargin < 3; version = 'doubling'; end;

% Matlab built-in
if strcmp(version,'dlyap');
    X = dlyap(A,B);
end

% Analytical solution
if strcmp(version,'analytical');
    n    = size(A,1);
    vecX = (eye(n^2) - kron(A,A))\reshape(B,n^2,1);
    X    = reshape(vecX,n,n);
end

% Doubling algorithm
if strcmp(version,'doubling');
    A0   = A;
    B0   = B;
    X0   = eye(size(A));
    err  = 1e10;
    while err > 1e-25;
        X   = A0*X0*A0' + B0;
        err = max(max(abs(X - X0)));
        B0  = A0*B0*A0' + B0;
        A0  = A0*A0;
        X0  = X;
    end
end
end