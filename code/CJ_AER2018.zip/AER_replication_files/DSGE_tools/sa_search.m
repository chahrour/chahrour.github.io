
function [vml,pout,flag] = sa_search(obj1,obj2,lbnd,ubnd,opt)

Aeq = [];
beq = [];

%genetic step
options = optimoptions('ga');
options.MaxGenerations = 25;
options.MaxTime        =  15*60;%10;%2*60*75;
options.PopulationSize = 75;
pout = ga(obj1,length(lbnd),[],[],Aeq,beq,lbnd,ubnd,[],options);

if nargin>4 && strcmp(opt.type, 'fmincon')
    %Use fmincon
    options = optimoptions('fmincon');
    options.TolX   = 1e-6;
    options.TolFun = 1e-6;
    options.Display = 'iter';
    options.MaxIterations= 600;
    [pout, vml, flag]= fmincon(obj2,pout,[],[],[],[],lbnd,ubnd,[],options);
else
    %Use lsqnonlin
    options = optimoptions('lsqnonlin');
    options.TolX = 1e-6;
    options.TolFun = 1e-5;
    options.Display = 'iter';
    options.MaxFunctionEvaluations = 600;
    [pout, vml, ~, flag]= lsqnonlin(obj2,pout,lbnd,ubnd,options);
end

pout = pout(:);

