%*******************************************************************
% COMPILE MEX FILES - WORKS ON A MAC OSX 10.9 FOR SURE
%
% Uncomment/comment to compile only particular files
%*******************************************************************
mex -v -largeArrayDims ../DSGE_tools/kalman_gh_mobs_mex4.c  -lmwlapack -lmwblas