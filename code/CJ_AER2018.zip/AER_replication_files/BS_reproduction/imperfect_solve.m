function [gx2,hx2,eta2,crit] = imperfect_solve(paramv,set,which_noise)

param.rhoga=paramv(1);
param.sigga=paramv(2);
param.sigea=paramv(3);
param.siges=paramv(4);

load v_idx
fnms = fieldnames(set);

if which_noise == 0
    idx_gg = [find(strcmp(fnms, 'gg_20_11')),find(strcmp(fnms, 'gg_25_55'))];
    [ggvec,H] = quick_kalman_noise(param);
    
    setv = struct2array(set);
    setv(idx_gg(1):idx_gg(2)) = ggvec;
    
    set = array2struct(fnms,setv);
    
    set.lam0 = H(1);
    set.lam1 = H(2);
    set.lam2 = H(3);

else
    idx_gg = [find(strcmp(fnms, 'gg0_11')),find(strcmp(fnms, 'gg5_22'))];
    ggvec = quick_kalman(param);
    setv = struct2array(set);
    setv(idx_gg(1):idx_gg(2)) = ggvec;
    
    set = array2struct(fnms,setv);
end


%**************************************************************
% NOISE MODELS
%**************************************************************
set.bsinfo = which_noise;  % 0 = GenNoise, 1 = BS
set.fullm = 1; 
[f1, fx1, fy1, fxp1, fyp1, eta1]=model_prog(paramv,struct2array(set));
[gx1,hx1,flag]=gx_hx_alt(fy1,fx1,fyp1,fxp1);
if flag ~=1
    gx2 = nan;
    hx2 = nan;
    eta2 = nan;
    return
end

nx = size(hx1,1);
ny = size(gx1,1);

%Use version of model where PLM is parameter
set.fullm = 0; setv2 = struct2array(set);
setv2(idx_gg(1):idx_gg(2)) = ggvec;

%Exogenous impose gx1 PLM in full info forecasts
setv2(end-5*nx+1:end) = vec(gx1(e1t_idx:dapt_idx,:));

%Solve economy with gx1 PLM imposed
[f2, fx2, fy2, fxp2, fyp2, eta2,~, ss]=model_prog(paramv,setv2);
[gx2,hx2,flag]=gx_hx_alt(fy2,fx2,fyp2,fxp2);

if flag ~=1
    gx2 = nan;
    hx2 = nan;
    eta2 = nan;
    return
end

%Check
crit = max(max(abs([gx2; hx2] - [gx1;hx1])));

if crit > 1e-6
   disp(['Warning PLM=ALM under full info, residual = ' num2str(max(max(abs([gx2; hx2] - [gx1;hx1]))))])
end

%Pull out conjectured LOM
Gxmatn = gx2(e1t_idx:dapt_idx,:);

%For unknown states, move all dependence of beliefs from actual state
%to perceived state
if set.bsinfo
    plm_idx = (mu1t_idx:ggt_idx)-ny;
    alm_idx = (mu1_idx:gg_idx)-ny;
else
    plm_idx = (xxt_idx:evt_idx)-ny;
    alm_idx = (xx_idx:ev_idx)-ny;
end
Gxmatn(:,plm_idx) = Gxmatn(:,plm_idx)+Gxmatn(:,alm_idx);
Gxmatn(:,alm_idx) = 0;

%Re-solve the model
setv2(end-5*nx+1:end) = vec(Gxmatn);


[f2, fx2, fy2, fxp2, fyp2, eta2,~, ss]=model_prog(paramv,setv2);
[gx2,hx2]=gx_hx_alt(fy2,fx2,fyp2,fxp2);
