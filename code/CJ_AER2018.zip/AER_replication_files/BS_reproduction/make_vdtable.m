
saved_files = {'Solution_BS','Solution_GenNoise'};
load v_idx
bp_range = [6,32];
hrange = [1 4 8 12 20];
vdidx = [dy_idx,dc_idx,di_idx,dn_idx];
nv = length(vdidx);
nh = length(hrange);

tab_out3 = nan(8,nv);
tab_out4 = nan(8,nv);

for mm = 1:2
   
    news_only  = 1;
    prod_only  = [2,6];
    noise_only = [5,7];
    
    clear hx2 gx2 eta2
    load(saved_files{mm}, 'gx2', 'hx2','eta2');
 
    %Growth Rate PEV
    Vy = variance_decomposition(gx2,hx2,eta2);
    tab_out3((mm-1)*4+1,:) = sum(Vy(news_only,vdidx),1);
    tab_out3((mm-1)*4+2,:) = sum(Vy(prod_only,vdidx),1);
    tab_out3((mm-1)*4+3,:) = sum(Vy(noise_only,vdidx),1);
    tab_out3((mm-1)*4+4,:) = 1-tab_out3((mm-1)*4+1,:)-tab_out3((mm-1)*4+2,:)-tab_out3((mm-1)*4+3,:);
    
    %Filterd PEV
    [Vy,variances] = vdfilter(gx2,hx2,eta2,2*pi./bp_range([2,1]));
    tab_out4((mm-1)*4+1,(1:nv),1) = sum(Vy(news_only,vdidx),1);
    tab_out4((mm-1)*4+2,(1:nv),1) = sum(Vy(prod_only,vdidx),1);
    tab_out4((mm-1)*4+3,(1:nv),1) = sum(Vy(noise_only,vdidx),1);
    tab_out4((mm-1)*4+4,(1:nv),1) = 1-sum(Vy(news_only,vdidx),1)-sum(Vy(prod_only,vdidx),1)-sum(Vy(noise_only,vdidx),1);
end
tab_out4(tab_out4==0) = NaN;

cols1 = {''
        'Surp*'
        'News*'
        'Noise*'};
cols2 =  {''
        'Fund'
        'Noise'};


rows = {'Y', 'C', 'I', 'N'};
    
disp('**********************************************')
disp('TABLE 2:');
disp('**********************************************')   
disp(cellprintf('%s\t',cols1))
pretty_print(tab_out4([2 1 3],:)',2,rows)
disp(' ')   
disp(cellprintf('%s\t',cols2))
pretty_print(tab_out4(6:7,:)',2,rows)
disp('**********************************************')
disp('**********************************************')
