% MODEL - Generate linearized version of the Barsky-Sims (2012) model with
% Blanchard et al (2013) information structures

function [mod,param,set] = model(param,set,GGmat,GGmat2,Gxmat)

%Name of text files
mod.fname   = 'model_prog.m';
mod.ss_call = 'model_ss.m';

%Declare parameters symbols: parameters are values to be estimated, symbols are values that are "fixed"
PARAM = struct2sym(param);
SET   = struct2sym(set);

%Declare Needed Symbols 
syms K DA GG GSHR CL IRL YL EI ES MU1 GGL MU1T GGT  XX XXL XXLL V EV XXT XXLT XXLLT VT EVT DAT
syms C I GDP GOV N W REN R PI LAM Q MC DY E1 E2 E3 E4 E1T E2T E3T E4T IL DC DI SIGNAL DN NL
IR = sym('IR');

syms DELA MP3 MP2 MP1 MM ML1 ML2 XI XIL EX EXL EXL2 DELAT MP3T MP2T MP1T MMT ML1T ML2T XIT XILT EXT EXLT EXL2T
syms DX Z ZL V DXT ZT ZLT VT DAPT

%For Noise Rep
XXS_noise   = [DELA MP3 MP2 MP1 MM ML1 ML2 XI XIL EX EXL EXL2];
XXS_noisep  = make_prime(XXS_noise);
XXST_noise  = [DELAT MP3T MP2T MP1T MMT ML1T ML2T XIT XILT EXT EXLT EXL2T];
XXST_noisep = make_prime(XXST_noise);

%For BLL rep
XXS_bll   = [DX Z ZL V];
XXS_bllp  = make_prime(XXS_bll);
XXST_bll  = [DXT ZT ZLT VT];
XXST_bllp = make_prime(XXST_bll);



%Declare X and Y vectors
X  = [K GSHR CL IL IRL YL NL EI ES...
      XXS_bll XXST_bll...                        %BLL Fundamentals/Expectations
      XXS_noise XXST_noise];                     %Noise Rep Fundamentals/Expectations
Y  = [C I GDP GOV N W REN R IR PI LAM Q MC DY DC DI DN DA E1 E2 E3 E4 E1T E2T E3T E4T DAPT];
XP = make_prime(X);
YP = make_prime(Y);
make_index([Y,X]);


%Adjustment cost
PHI = @(x) x - gam/2*(x-ikbar)^2;
PHIP = @(x) 1 - gam*(x-ikbar);

%Model Equations
f(1)     = LAM - E1T;
f(end+1) = LAM/R - E2T;
f(end+1) = N^(1/etta) - LAM*W;
f(end+1) = W - MC*(1-alph)*DA^(alph/(alph-1))*K^alph*N^(-alph);
f(end+1) = REN - MC*( alph )*DA                *K^(alph-1)*N^(1-alph);
f(end+1) = PI - (mcbar^((1-thet)/thet*(1-bet*thet)))^-1*MC^((1-thet)/thet*(1-bet*thet))*E3T^bet;
f(end+1) = Q*PHIP(I/K*DA^(1/(1-alph)))-1;
f(end+1) = Q - E4T;
f(end+1) = GDP - DA^(alph/(alph-1))*K^alph*N^(1-alph);
f(end+1) = GDP - C - I - GOV;
f(end+1) = R - IR/E3T;
f(end+1) = log(IR/irbar) - rhoi*log(IRL/irbar) - (1-rhoi)*phipi*log(PI) - (1-rhoi)*phiy*log(DY/gstar^(1/(1-alph))) - log(EI);
f(end+1) = K_p - (1-delt)*DA^(1/(alph-1))*K - I;

%Define expectations terms
f(end+1) = E1 - (C-kapp*CL*DA^(1/(alph-1)))^-1 + bet*kapp*(C_p*DA_p^(1/(1-alph)) - kapp*C)^-1;
f(end+1) = E2 - bet*LAM_p*DA_p^(1/(alph-1));
f(end+1) = E3 - PI_p;
f(end+1) = E4 - bet*(LAM_p/LAM*DA_p^(1/(alph-1))*(REN_p + Q_p*((1-delt) + PHI(I_p/K_p*DA_p^(1/(1-alph))) - I_p/K_p*DA_p^(1/(1-alph))*PHIP(I_p/K_p*DA_p^(1/(1-alph))))));

%Impose alternative PLM
f(end+1) = log(E1T)-fullm*log(E1)-(~fullm)*Gxmat(1,:)*log(transpose(X));
f(end+1) = log(E2T)-fullm*log(E2)-(~fullm)*Gxmat(2,:)*log(transpose(X));
f(end+1) = log(E3T)-fullm*log(E3)-(~fullm)*Gxmat(3,:)*log(transpose(X));
f(end+1) = log(E4T)-fullm*log(E4)-(~fullm)*Gxmat(4,:)*log(transpose(X));
f(end+1) = log(DAPT)-fullm*log(DA_p/gstar)  -(~fullm)*Gxmat(5,:)*log(transpose(X));

%Fundamental Process - BLL Formulation
f(end+(1:4)) = transpose(XXS_bllp) - GGmat{5}*transpose(XXS_bll);

 %Kalman Filter - BLL Formulation
f(end+(1:4)) = transpose(XXST_bllp)- GGmat{1}*transpose(XXS_bll) - GGmat{2}*transpose(XXST_bll);

%Fundamental Process - Noise Formulation
f(end+(1:12)) = transpose(XXS_noisep) - GGmat2{5}*transpose(XXS_noise);

%Kalman Filter - Noise Formulation
f(end+(1:12)) = transpose(XXST_noisep)- GGmat2{1}*transpose(XXS_noise) - GGmat2{2}*transpose(XXST_noise);

%Link to economy
f(end+1) = log(DA/gstar) - bsinfo*(DX+(Z-ZL)) - (1-bsinfo)*DELA;

%AUX DEFINITIONS
f(end+1) = CL_p  - C;
f(end+1) = IRL_p - IR;
f(end+1) = YL_p  - GDP;
f(end+1) = IL_p - I;
f(end+1) = NL_p - N;
f(end+1) = DY    - GDP/YL*DA^(1/(1-alph));
f(end+1) = DC    - C/CL*DA^(1/(1-alph));
f(end+1) = DI    - I/IL*DA^(1/(1-alph));
f(end+1) = DN    - N/NL;
f(end+1) = log(EI_p);
f(end+1) = log(ES_p);
f(end+1) = GOV/GDP - GSHR;
f(end+1) = log(GSHR_p/Gshr) - rhog*log(GSHR/Gshr);

% disp(['Nx:   ' num2str(length(X))]);
% disp(['Neq:  ', num2str(length(f))]);
% disp(['Nvar: ', num2str(length(X)+length(Y))]);

%Log-linear approx (Pure linear if log_var = [])
xlog = true(1,length(X));
ylog = true(1,length(Y));
log_var = [X(xlog) Y(ylog) XP(xlog) YP(ylog)];


mod.f = subs(f, log_var, exp(log_var));
mod.X = X;
mod.XP = XP;
mod.Y = Y;
mod.YP = YP;
mod.PARAM = PARAM;
mod.param = param;
mod.SET = SET;
mod.set = set;
mod.adiff = set.adiff; %Include anaylytical derivatives?
mod.xlog = xlog;
mod.ylog = ylog;


%Standard Errors
nx = length(X);
ny = length(Y);
mod.shck = sym(zeros(nx,7));

%Shock order: [News, One-Time Growth,Gov't Spending,Taylor Rule, Noise, eps(x), epx(v)]
mod.shck(gshr_idx-ny,3) = sigg;  %Shockt to gov't
mod.shck(ei_idx-ny,4)   = sigi;  %Taylor Shock
mod.shck(es_idx-ny,5)   = siges; %Noise shock


%Shock order: [eps,eta,v]
%Productivity Shocks/Innovations Rep
mod.shck((dx_idx:v_idx)-ny  ,[2,1,5])   = GGmat{6}(:,[1,2,4]); %From fundamental terms
mod.shck((dxt_idx:vt_idx)-ny,[2,1,5])   = GGmat{3}(:,[1,2,4]);  %From measurement terms

%add shocks for noise process using GMAT2
mod.shck((dela_idx:exl2_idx)-ny  ,[6 7])   = GGmat2{6}(:,[2,8]);
mod.shck((delat_idx:exl2t_idx)-ny,[6 7])   = GGmat2{3}(:,[2,8]);


%Measurement Error (parameters are std-devs in param.m file)
mod.me = [];

%Derivatives using numerical toolbox
mod = anal_deriv(mod);

%Save index variables for use in main_prog
!rm -f v_idx.mat
save v_idx *_idx



