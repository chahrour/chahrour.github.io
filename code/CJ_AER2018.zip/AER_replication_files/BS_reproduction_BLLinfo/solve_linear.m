%**************************************************************
% SOLVE_LINEAR: Solves the full info and incomplete info versions of the
% model
%**************************************************************
addpath('../DSGE_tools');

load model_object
[param,set] = parameters;
[~,param] = model_ss(param,set);
paramv = struct2array(param);

%Get indexes to track
load v_idx
vlist     = {'GDP', 'C',      'I',    'N', 'PI',   'DA',   'DA+1|t',   'R'};
vvidx     = [dy_idx, dc_idx, di_idx, n_idx,pi_idx, da_idx,dapt_idx,r_idx];
prefs.ndec = 3;

%Define the neps shocks
shock = eye(neps); shcks = cell(1,neps);
for ss = 1:neps; shcks{ss} = shock(:,ss);end;
lnm = {'News-Perm', 'One-time Growth','Gov', 'Taylor', 'Noise', 'Alt Fund.', 'Alt. Noise' };
lstyle =  {'-b', '-r', '-g', '-m', '-k', '--r', '--k'};

%Cumulate growth-rates impulse responses to get level effects
cumsum_idx =[dy_idx,dc_idx,di_idx,da_idx];


%**************************************************************
% FULL INFO MODEL USING BLL FUNDAMENTAL PROCESS
%**************************************************************
set.fullm = 1; set.bsinfo = 1;
[f, fx, fy, fxp, fyp, eta]=model_prog(paramv,struct2array(set));
[gx,hx]=gx_hx_alt(fy,fx,fyp,fxp,1.00001);

%**************************************************************
% NOISE MODELS
%**************************************************************
forms = {'GenNoise','BS'};
set.bsinfo = 0;  % 0 = GenNoise, 1 = BS

set.fullm = 1; 
[f1, fx1, fy1, fxp1, fyp1, eta1]=model_prog(paramv,struct2array(set));
[gx1,hx1]=gx_hx_alt(fy1,fx1,fyp1,fxp1,1.00001);

%Use version of model where PLM is parameter
set.fullm = 0; setv2 = struct2array(set);

%Exogenous impose gx1 PLM in full info forecasts
setv2(end-5*nx+1:end) = vec(gx1(e1t_idx:dapt_idx,:));

%Solve economy with gx1 PLM imposed
[f2, fx2, fy2, fxp2, fyp2, eta2,~, ss]=model_prog(paramv,setv2);
[gx2,hx2]=gx_hx_alt(fy2,fx2,fyp2,fxp2,1.00001);

%Pull out conjectured LOM
Gxmatn = gx2(e1t_idx:dapt_idx,:);

%For unknown states, move all dependence of beliefs from actual state
%to perceived state
if set.bsinfo == 1
    plm_idx = (dxt_idx:vt_idx)-ny;
    alm_idx = (dx_idx:v_idx)-ny;
else
    plm_idx = (delat_idx:exl2t_idx)-ny;
    alm_idx = (dela_idx:exl2_idx)-ny;
end
Gxmatn(:,plm_idx) = Gxmatn(:,plm_idx)+Gxmatn(:,alm_idx);
Gxmatn(:,alm_idx) = 0;

%Re-solve the model
setv2(end-5*nx+1:end) = vec(Gxmatn);
[f2, fx2, fy2, fxp2, fyp2, eta2,~, ss]=model_prog(paramv,setv2);
[gx2,hx2]=gx_hx_alt(fy2,fx2,fyp2,fxp2,1.0000);


[Vy_bc] = vdfilter(gx2(dc_idx,:),hx2,eta2,2*pi./[6,32]);
cshr_bc = Vy_bc(7);
save ../info_figure/cshr_bs_bllinfo cshr_bc

clear mm simdata
eval(['save Solution_' forms{set.bsinfo+1} ' gx2 hx2 eta2 *_idx']);
