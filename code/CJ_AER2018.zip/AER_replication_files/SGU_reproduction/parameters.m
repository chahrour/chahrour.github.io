% PARAMETERS - This function returns a parameter structure to use in the model solution.


function [param,set,GG,GG2,Gxmat] = parameters()
                                                       

set.adiff      = 0;
set.approx_deg = 1;


%Full or partial info
set.fullm = 1;

% Calibrated parameters
set.bet   = 0.99;
set.alphak = 0.225;
set.alphah = 0.675;
set.delta0 = 0.025;
set.muybar = 1.0045;
set.muabar = 0.9957;
set.G_Y    = 0.2;
set.hbar   = 0.2;
set.L      = 1;
set.sig  = 1;
set.muwbar = 1.15;


%Estimated parameters
load parameter;
param_in       = median_bayesian;
param.theta    = param_in(1) + 1; 
param.gam      = param_in(2);
param.kappa    = param_in(3);
param.rdelta   = param_in(4);
param.b        = param_in(5)*0.99; 
param.rhoxg    = param_in(6)*0.99; 
param.rhozY    = param_in(7)*0.99; 
param.rhomua   = param_in(8)*0.99; 
param.rhog     = param_in(9)*0.99; 
param.rhomux   = param_in(10)- 0.5; 
param.rhomuw   = param_in(11)*0.99; 
param.rhozeta  = param_in(12)*0.99; 
param.rhozI    = param_in(13)*0.99; 
param.sig0zY   = param_in(14);
param.sig4zY   = param_in(15);
param.sig8zY   = param_in(16);
param.sig0mua  = param_in(17);
param.sig4mua  = param_in(18);
param.sig8mua  = param_in(19);
param.sig0g    = param_in(20);
param.sig4g    = param_in(21);
param.sig8g    = param_in(22);
param.sig0mux  = param_in(23);
param.sig4mux  = param_in(24);
param.sig8mux  = param_in(25);
param.sig0muw  = param_in(26);
param.sig4muw  = param_in(27);
param.sig8muw  = param_in(28);
param.sig0zeta = param_in(29);
param.sig4zeta = param_in(30);
param.sig8zeta = param_in(31);
param.sig0zI   = param_in(32);
param.sig4zI   = param_in(33);
param.sig8zI   = param_in(34);
param.sigyme   = param_in(35);

% Implied steady-state values
set.mua    = set.muabar;
set.muy    = set.muybar; %1.004500000000000
set.muw    = set.muwbar;
set.mux    = set.muy*set.mua^(set.alphak/(1-set.alphak));
set.muxbar = set.mux;
set.mui    = set.mux*set.mua^(1/(set.alphak-1));
set.h      = set.hbar;
set.xg     = set.muy^(1/(param.rhoxg-1));

%Determined in equilbrium
set.ybar  = NaN;      
set.mcbar = NaN;
set.ikbar = NaN;
set.irbar = NaN;
set.delta1 = NaN;
set.delta2 = NaN;
set.psii   = NaN;
set.gbar = NaN;
%**************************************************************************
% CHOOSE INFO STRUCTURE TO SOLVE WITH
%**************************************************************************
set.sguinfo = true;   %true mean use SGU rep; false means use noise rep


