function [M,etaM,xs,xsp] = nper_news(nms,pvec,sigvec)

%Transition equation here
M = sym(zeros(max(pvec)));
M(1:end-1,2:end) = eye(length(M)-1);

%Shocks go here
etaM = sym(zeros(length(M),length(pvec)));
etaM(pvec+1,:) = diag(sigvec);

%Symbols here
xs = sym(zeros(1,length(M)));
for jj = 1:length(M)
   xs(jj) = sym([nms,num2str(jj)]); 
end
xsp = make_prime(xs);