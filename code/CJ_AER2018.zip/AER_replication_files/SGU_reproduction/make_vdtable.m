
load v_idx
bp_range = [6,32];

vdidx = [gy_idx,gc_idx,gai_idx,gh_idx];

tab_out3 = zeros(2,4);
tab_out4 = zeros(2,4);

load SGU_solution

surp_only = 1:3:21;
news_only  =[2:3:21,3:3:21];

%% Filterd PEV
[Vy,variances1] = vdfilter(gx,hx,eta,2*pi./bp_range([2,1]));
tab_out3(1,:) = sum(Vy(surp_only,vdidx),1);
tab_out3(2,:) = sum(Vy(news_only,vdidx),1);
%%
%Filterd PEV
[Vy,variances2] = vdfilter2(gx3,hx3,eta3,2*pi./bp_range([2,1]));
tab_out4(1,:) = sum(Vy(surp_only,vdidx),1);
tab_out4(2,:) = sum(Vy(news_only,vdidx),1);
%%

cols1 = {''
        'Surp'
        'News'};
cols2 =  {''
        'Fund'
        'Noise'};


rows = {'Y', 'C', 'I', 'N'};
    
disp('**********************************************')
disp('TABLE 1:');
disp('**********************************************')   
disp(cellprintf('%s\t',cols1))
pretty_print(tab_out3',2,rows)
disp(' ')   
disp(cellprintf('%s\t',cols2))
pretty_print(tab_out4',2,rows)
disp('**********************************************')
disp('**********************************************')
