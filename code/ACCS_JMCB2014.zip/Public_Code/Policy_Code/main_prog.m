%*************************************************************************
% MAIN_PROG: Solve the ramsey problem for the model in Arseneau, Chahrour, 
% Chugh, Shapiro, "Optimal Fiscal and Monetary Policy in Customer Markets"
% JMCB, 2014/2015.
%*************************************************************************

tic

addpath('Helper_Funcs');

eval (['delete ../Figures_and_Tables/' case_name]);   %Delete old diary
eval (['diary ../Figures_and_Tables/', case_name]);%Start new diary
eval( ['load model_obj_' case_name(1:11)]);        %Load model object 
eval( ['load run_params_' case_name(1:11)]);       %Load associated parameters

ny = length(modl.Y);
nx = length(modl.X);

%For the competative equilibrium taun's and taua's are zero in steady-state
%and dynamically.
if strcmp(case_name(1:11), 'COMPETITIVE')
    set.taun1 = 0;
    set.taun2 = 0;
    set.taua1 = 0;
    set.taua2 = 0;
end

%If a flex-price case, set varphi = 0
if strcmp(case_name(13:16), 'FLEX')
    set.varphi = 0;
end

%If a limited instrument case, set taun's and taua's equal to long run
%optimal levels for all t
if strcmp(case_name(1:11), 'RAMSEY_LMTD')
    set.taun1 = -0.475519957870581;
    set.taun2  = -0.477358169088114;
    set.taua1  = 0.117389153582192;
    set.taua2  =   0.107259507693965;
end

%If no search, set the utility share of search goods to near zero, but
%leave all other fundamental parameters the same.
if strcmp(case_name(end-7:end), 'NOSEARCH');
    set.vartheta = 1e-5;
end

%If no search, with limited instruments, must change the long-run level of
%the taxes.
if strcmp(case_name(1:end), 'RAMSEY_LMTD_NOSEARCH')
    set.taun1  = -0.446977282916163;
    set.taun2  = -0.449136566538740;
    set.taua1  =  0.484631143764931;
    set.taua2  =  0.476944826489565;
end


%Determine Steady State Policy and Allocations
x0_alloc = [
   0.060462729515603
   0.005661403680374
   0.066523583790081
   0.064053158622710
   0.323119035149313]';
x0_tools = [
   0.187428975017953
  -0.475519957870581
  -0.477358169088114
   0.117389153582192
   0.107259507693965
   0.992399999832099]';

if strcmp(case_name(end-7:end), 'NOSEARCH')
    %Different starting point for no search..
    x0_alloc = [
        0.062694221632705
        0.000076619667065
        0.000900266988074
        0.000866844834838
        0.187312766070211]';
    x0_tools = [
        0.328759206732572
       -0.446977282916163
       -0.449136566538740
        0.484631143764931
        0.476944826489565
        0.992399991881907]';
elseif strcmp(case_name(1:11), 'COMPETITIVE')
    load estparam x0
    x0_alloc = x0;
end
x0 = [x0_alloc, x0_tools(tools)];

%FSOLVE FOR SS
options = optimset('fsolve');
options = optimset(options,  'display', 'iter', 'maxfunevals', 50000, 'tolfun', 1e-15, 'tolx', 1e-13, 'maxiter', 5000);
eval(['obj = @(X) model_prog_' case_name(1:11) '(X,struct2array(set),tools);']);
[paramo,b] = fsolve(obj, x0,options);

%STEADY-STATE MODEL EQUATIONS
[lag_ssn,lamss,f,fx,fy,fxp,fyp,eta,R,~,ss_util,wdg,yss,xss] = obj(paramo);
yxss = [yss,lamss(length(modl.lam_X)+1:end)' ,xss, lamss(1:length(modl.lam_X))'];

%DYNAMICS
[gx,hx] = gx_hx_alt(fy,fx,fyp,fxp,1.0000000+.0000001);
resid = fx+fy*gx+fxp*hx+fyp*gx*hx;
tt = sum(sum(abs(resid)));
disp(['Numerical abs sum residual of matrix quadratic equation, using standard alg: ', num2str(tt)]);

%Solving gx_hx full precision
[gx,hx] = gx_hx_vpa(fy,fx,fyp,fxp,1,.0001);
resid = fx+fy*gx+fxp*hx+fyp*gx*hx;
tt = sum(sum(abs(resid)));

%**************************************************************************
%MAKE TABLE OUTPUTS
%**************************************************************************
tool_list = {'taul', 'taun1', 'taun2', 'taua1', 'taua2', 'pi'};
var_idx =   [gdp_idx    pii_idx     r_idx   l_idx   bb_idx   a_idx  s1_idx  s2_idx  p1_idx  p2_idx  wdg1_idx wdg2_idx wdg3_idx  wdg4_idx wdg5_idx   taul_idx]; 
var_names = {'GDP',     'PI',       'R',    'L',    'B',    'A',    'S1'    'S2'    'P1'    'P2'   'WDG1',  'WDG2',  'WDG3',  'WDG4',   'WDG5',     'TAUL'} ; 

%ARE SS EQUATIONS SATISFIED?
max(abs(f))

%ACTIVE SHOCKS
disp('X*ETA:');
disp(modl.X*modl.shck)

%DISPLAY INFORMATION ON STEADY STATE
disp('STEADY-STATE INSTRUMENTS AND WEDGES:');
print_vals(tool_list(ss_tools), paramo(6:end)); 
print_vals({'Stat', 'Srch1', 'Srch2', 'Inter1', 'Inter2'}, wdg);
disp(' ');


%DISPLAY INFORMATION ON SECOND MOMENTS
disp('SECOND MOMENTS: 100 PERIODS X 5000 SAMPLES'); disp('');
nsim = 5000;  %Number of simulations
nper = 100;   %Periods in each
mpref.ndec = 2; %Number of decimals in tables

vars = zeros(nsim,length(var_idx)); simdat = zeros(nx+ny,nper,nsim);
eta = [eta(:,1:2), zeros(size(eta,1),2)];  %Only Z and G shocks
randn('seed', 123456);                     %Fix seed so no small-sample differences.
for j = 1:nsim
    [xsim,ysim] = sim_dat(gx,hx,eta,nper,0);
    simdat(:,:,j) = [ysim;xsim];
    vars(j,:) = std(simdat(var_idx,:,j),0,2);
end
coefvar = 100*median(vars)./yxss(var_idx);

disp('OUTPUT FOR TABLE 3 & 4:');
var_names = {'GDP', 'A',   'X',   'N',     'S',   'THET1',    'THET2', 'L', 'PI', 'R', 'N1', 'N2', 'X1', 'X2'};
var_idx = [gdp_idx, a_idx, xx_idx, n_idx,  s_idx, thet1_idx, thet2_idx, l_idx, pii_idx, r_idx, n1_idx, n2_idx, x1_idx, x2_idx];
mom_tab_sim(simdat, var_idx, var_names,yxss(var_idx), mpref);
disp(' ');

disp('OTPUT FOR TBLE 5:');
if sum(tools)>2
    taus = [taul_idx, taun1_idx, taun2_idx, taua1_idx, taua2_idx];
    tau_nms = {'TAUL', 'TAUN1', 'TAUN2', 'TAUA1', 'TAUA2'};
elseif sum(tools) == 2
    taus = [taul_idx];
    tau_nms = {'TAUL'};
else
    taus = [];
    tau_nms = {};
end
var_names = {'GDP', 'PI', 'R', tau_nms{tools(1:5)}};
var_idx = [gdp_idx,pii_idx, r_idx, taus(tools(1:5))];
mom_tab_sim(simdat, var_idx, var_names,yxss(var_idx), mpref);
disp(' ');


disp('WEDGE MOMENTS (NOT REPORTED):')
var_names = {'GDP', 'WD1', 'WD2', 'WD3', 'WD3', 'WD4', 'WD5'};
var_idx = [gdp_idx,wdg1_idx,wdg2_idx,wdg3_idx,wdg4_idx,wdg5_idx];
mom_tab_sim(simdat, var_idx, var_names,yxss(var_idx), mpref);

%**************************************************************************
%COMPUTE IMPULSE RESPONSES, NORMALIZED BY SS VALUES
%**************************************************************************
nper = 50;
muz = eta(z_idx-ny,:)'>0;
mug = eta(g_idx-ny,:)'>0;
irz = ir(gx,hx,eta*muz,nper)./repmat(yxss,[nper,1]);
irg = ir(gx,hx,eta*mug,nper)./repmat(yxss,[nper,1]);
if sum(tools) == 0
    mut = eta(taul_idx-ny,:)'>0;
    mur = eta(epp_idx-ny,:)'>0;
    irt = ir(gx,hx,eta*mut,nper)./repmat(yxss,[nper,1]);
    irr = ir(gx,hx,eta*mur,nper)./repmat(yxss,[nper,1]);
end


diary OFF
eval(['save ../Figures_and_Tables/' case_name]);