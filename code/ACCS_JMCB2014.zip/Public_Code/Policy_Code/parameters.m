% PARAMETETRS - This function returns a parameter structure to use in the model solution.

function [param,set] = parameters(ss_tools,lump_sum)

%Include lump sum taxes
set.lump_sum = lump_sum;
set.minL = 1e-11;        %If multiplier is less than this, assume exactly zero.

%Allocations that must be search over in ss
param.x2 = NaN;
param.s2 = NaN;
param.n1 = NaN;
param.n2 = NaN;
param.lbar = 0.3;

%Input Parameters (are set to estimated values in main_prog.m)
set.bet    = 0.9924;  %Discount Rate
set.sigx   = 2.5127;  %CRRA coeff for walras goods
set.sigc   = 2.5127;  %CRRA coeff for search goods
set.phix   = 0.79;    %CES elastivity for walras goods
set.phic   = 0.79;    %CES elasticity for search goods
set.nu     = 2;       %Frisch elasticity
set.rhox   = 1-0.4832;%Exogenous separation in search goods
set.xi     = 0.5 ;    %Cobb-douglas coefficient in matching function
set.veps   = 5;       %CES elasticity for final good production
set.varphi = 20.6013;       %Price stickiness parameters

set.kapx = 0.5;       %CES weight on x_2   
set.kap  = 0.8377;       %Coupon rate


%Parameters that I take as input parameters, but others (might) take as oputput parametrs. 
set.adshr1 = .01;   %ss adverstising 
set.adshr2 = .01;   %ss adverstising 

set.kf1 = .5;       %finding rate 1, firm side    
set.kf2 = .5;       %finding rate 2, firm side

set.kh1 = NaN;       %finding rate 1, consumer side        
set.kh2 = NaN;       %finding rate 2, consumer side

set.nshr1 = 0.19;    %share of n1 goods in output
set.nshr2 = 0.19;    %share of n2 in output
set.gshr  = 0.2;   %share of x goods in output


%Paramters that I take as output parameters but other might take as inputs
set.zet = NaN;          %Disutility of labor
set.vartheta = NaN;     %Weight on search goods

set.gam1 = NaN;         %Cost of adver 1
set.gam2 = NaN;         %Cost of adver 2

set.psi1 = NaN;         %Matching efficiency 1
set.psi2 = NaN;         %Matching efficiency 2

set.eta1 = .5325;       %Nash Bargaining Parameter 1
set.eta2 = .5314;       %Nash Bargaining Parameter 2

set.kapc = NaN;         %CES weight on N_2 
set.xshr = (1-set.adshr1 - set.adshr2 - set.nshr1 - set.nshr2 - set.gshr); %Government share
set.gbar = NaN;         %ss level (not share) of government

set.bshr = NaN;  %Set one or the other of these if b is set exogenous (as is the case with policy.)
set.bbar = .15;

%Exogenous processes
set.sigz = 0.0141;
set.sigg = 0.0035;

set.rhoz  = 0.8099;
set.rhog  = 0.9297;

%ss taxes on labor, firm side
set.tauw  = set.veps/(set.veps-1)-1;

%ss taxes on labor, consumer side
if ss_tools(1)
    param.taul = 0.185969628191926;
else
    set.taul   = 0.22;    
end

if ss_tools(2)
    param.taun1 = -0.456323576608324;
else
    set.taun1   = 0*-0.456323576608324;
end

if ss_tools(3)
    param.taun2 = -0.439319612017422;
else
    set.taun2   = 0*-0.439319612017422;
end      

if ss_tools(4)
    param.taua1 = 0.290656867569801;
else
    set.taua1   = 0*0.290656867569801;
end

if ss_tools(5)
    param.taua2 = 0.416267930151232;
else
    set.taua2   = 0*0.416267930151232;
end

%Average inflation
if ss_tools(6) %|| (sum(ss_tools)==0)
    param.pistar = .9924;
else
    set.pistar = .9924;           
end

%Exogenous taylor rule parameters
set.rhor   = 0.7552;
set.alphpi = 1.4903;
set.alphy  = 0.0128;
set.gdp    = NaN;
set.sigr   = 0.0024;
set.p1 = NaN;
set.p2 = NaN;
%Exogenous taylor rule parameters
set.rhotl = .9692;
set.sigt  = .0052;

%Rotemberg inflation target.
%set.pibar = 1;


set.rbar = NaN;


%Degree of Approximation
set.me_eq = [];      %Measurement Error to the 1st observation equation
set.approx_deg = 1;