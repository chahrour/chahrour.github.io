 [param,set,tools,ss_tools] = parameters;
 [yss,xss,param,set,x0] = model_ss(param,set);
 