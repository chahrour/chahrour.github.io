function out = print_vals(sims,vals)


ny = min(length(sims),length(vals));

str1 = [];
str2 = [];
for j = 1:ny
    str1 = [str1, sprintf('%s\t', char(sims(j)))];
    str2 = [str2, sprintf('%1.4f\t', vals(j))];
end


disp(str1);
disp(str2);
disp(' ');