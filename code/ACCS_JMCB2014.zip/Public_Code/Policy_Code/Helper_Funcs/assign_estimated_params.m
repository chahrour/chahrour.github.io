% ASSIGN_ESTIMATED_PARAMS - Assign a vector of values to a data structure.
%
% Usage
%
% [param_out, set_out] = assign_estimated_params(param_in,set_in,param_out,set_out)

function [param_out, set_out] = assign_estimated_params(param_in,set_in,param_out,set_out)

names_p = fieldnames(param_in);
names_s = fieldnames(set_in);

for j = 1:length(names_p)
    if isfield(param_out, names_p{j});
        eval(['param_out.' names_p{j} ' = param_in.' names_p{j} ';']);
    end
    if isfield(set_out, names_p{j});
        eval(['set_out.' names_p{j} ' = param_in.',names_p{j} ';']);
    end
end
    
for j = 1:length(names_s)
    if isfield(param_out, names_s{j});
        eval(['param_out.' names_s{j} ' = set_in.' names_s{j} ';']);
    end
    if isfield(set_out, names_s{j});
        eval(['set_out.' names_s{j} ' = set_in.',names_s{j} ';']);
    end
end
    
