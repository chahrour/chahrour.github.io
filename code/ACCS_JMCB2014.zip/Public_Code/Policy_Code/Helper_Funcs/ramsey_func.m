% MODEL_FUNC - Convert a mod object into a matlab file that evaluates the
% first order derivatives of a model without reference to the symbolic
% toolbox.
%
% Usage:
%
% model_func(mod_obj)
%
% where
%
% mod_obj = a data structure which contains the following fields...
%
%
% Code by Ryan Chahrour, Boston College, 2012

function ramsey_func(model)


nx = length(model.X) - length(model.lam_X);
ny = length(model.Y) - length(model.lam_Y);

%**************************************************************************
%This section of the code generates matlab programs for transforming/untransforming the
%parameter vector so that parameters can easily be bound, either above zero
%or between a and b
%**************************************************************************

f = fopen(model.fname, 'w');

%The function call will take the parameters and settings as arguments
if model.set.approx_deg == 1
    str = 'function [lag_ssn,lamss,f,fx,fy,fxp,fyp,eta,ME,set,ss_util,wdg,Yss,Xss] = model_prog(param, set, tools)';
else
    str = 'function [lag_ssn,lamss,f,fx,fy,fxp,fyp,fypyp,fypy,fypxp,fypx,fyyp,fyy,fyxp,fyx,fxpyp,fxpy,fxpxp,fxpx,fxyp,fxy,fxxp,fxx,eta,R,set] = model_prog(param, set, tools)';
end
fprintf(f, '%s\n\n', str);

%Assign parameter values to named variables
str = '%Assign parameter values to named variables.'; fprintf(f, '%s\n', str);
for j = 1:length(model.PARAM)
    str = [char(model.PARAM(j)) ' = param(' num2str(j), ');']; fprintf(f, '%s\n',str);
end
fprintf(f, '%s\n', '');

%Assign set values to named variables
str = '%Assign set values to named variables.'; fprintf(f, '%s\n', str);
for j = 1:length(model.SET)-2
    str = [char(model.SET(j)) ' = set(' num2str(j), ');'];fprintf(f, '%s\n',str);
end
fprintf(f, '%s\n', '');


if isfield(model, 'xtra') 
    %Assign values to matrix parameters
    str = '%Assign vectors values to named vector parameters.';
    fprintf(f, '%s\n', str);
    
    xlist = fieldnames(model.xtra);
    for j = 1:length(xlist)
        stmp = eval(['symmat_print(model.xsym.' xlist{j} ');']);
        str = [xlist{j} ' = ' stmp  ';'];
        fprintf(f, '%s\n',str);
    end
end


%***************************************************
%Compute SS variables using external code 
%***************************************************
if any(strcmp('ss_call',fieldnames(model)))
    sscode = fopen(model.ss_call, 'r');
    l = fgetl(sscode);
    j = 1;
    while ~strcmp('%BEGIN_EXTRACT_HERE', l) && j < 300
        l = fgetl(sscode);
        j = j+1;
    end
    
    fprintf(f, '%s\n', l);
    while ~strcmp('%END_EXTRACT_HERE', l) && j < 600
        l = fgetl(sscode);
        j = j+1;
        fprintf(f, '%s\n', l);
    end
    
    fclose(sscode);
    

    str = '%Compute Steady State'; fprintf(f, '%s\n', str);
    for j = 1:nx
        str = [char(model.X(j)) '= Xss(' num2str(j) ');']; fprintf(f, '%s\n', str);
    end
    
    for j = 1:ny
        str = [char(model.Y(j)) '= Yss(' num2str(j) ');']; fprintf(f, '%s\n', str);
    end
    
    for j = 1:nx
        str = [char(model.XP(j)) '= Xss(' num2str(j) ');']; fprintf(f, '%s\n', str);
    end
    
    for j = 1:ny
        str = [char(model.YP(j)) '= Yss(' num2str(j) ');']; fprintf(f, '%s\n', str);
    end
    
end    
    


%********************************
%STEADY-STATE RAMSEY FOCS
%********************************
if isfield(model, 'XLAG') && isfield(model, 'YLAG')
    str = ['xlag = ' symmat_print(model.XLAG) ';'];
    fprintf(f, '%s\n', str);
    str = ['ylag = ' symmat_print(model.YLAG) ';'];
    fprintf(f, '%s\n', str);
    str = 'lamss = (xlag\ylag'');';
    fprintf(f, '%s\n', str);
    
    for j = 1:length(model.lam_X)
        str = [char(model.lam_X(j)) '=lamss(' num2str(j) ');']; fprintf(f, '%s\n', str);
        str = [char(model.lam_X(j)) 'p=lamss(' num2str(j) ');']; fprintf(f, '%s\n', str);
    end
    
    for j = 1:length(model.lam_Y)
        str = [char(model.lam_Y(j)) '=lamss(' num2str(j+length(model.lam_X)) ');']; fprintf(f, '%s\n', str);
        str = [char(model.lam_Y(j)) '_p=lamss(' num2str(j+length(model.lam_X)) ');']; fprintf(f, '%s\n', str);
    end
    
    str = ['lag_ssn = [' symmat_print([model.LAG_SS,model.xtra_rest]) ',fo];']; fprintf(f, '%s\n\n', str);
    str = '%Return if just searching for lagrange multiplier steady-state.'; fprintf(f, '%s\n',str);
    str = 'if nargout<3; return; end;'; fprintf(f, '%s\n', str);
end

%********************************
%STEADY-STATE RAMSEY FOCS
%********************************
str = 'lamss(abs(lamss)<minL) = 0;';
fprintf(f, '%s\n', str);

for j = 1:length(model.lam_X)
    str = [char(model.lam_X(j)) '=lamss(' num2str(j) ');']; fprintf(f, '%s\n', str);
    str = [char(model.lam_X(j)) 'p=lamss(' num2str(j) ');']; fprintf(f, '%s\n', str);
end

for j = 1:length(model.lam_Y)
    str = [char(model.lam_Y(j)) '=lamss(' num2str(j+length(model.lam_X)) ');']; fprintf(f, '%s\n', str);
    str = [char(model.lam_Y(j)) '_p=lamss(' num2str(j+length(model.lam_X)) ');']; fprintf(f, '%s\n', str);
end

%***************************
%F
%***************************
fprintf(f,'%s\n', '%Evaluate F.'); 
str = ['f = ' symmat_print(model.f) ';']; fprintf(f, '%s\n', str);

%***************************
%FX
%***************************
fprintf(f, '%s\n', '%Evaluate derivative expressions.');
str = ['fx = ' symmat_print(model.fx) ';']; fprintf(f, '%s\n', str);

%***************************
%FY
%***************************
str = ['fy = ' symmat_print(model.fy) ';']; fprintf(f, '%s\n', str);

%***************************
%FXP
%***************************
str = ['fxp = ' symmat_print(model.fxp) ';']; fprintf(f, '%s\n', str);


%***************************
%FYP
%***************************
str = ['fyp = ' symmat_print(model.fyp) ';']; fprintf(f, '%s\n\n', str);

%*************************************************************************
% Exogenous Variances and Measurement Error
%*************************************************************************
str = ['eta = ' symmat_print(model.shck) ';']; fprintf(f, '%s\n', str);
str = ['ME = ' symmat_print(model.me) ';']; fprintf(f, '%s\n', str);

%********************************
%SECOND ORDER DYNAMICS?
%********************************
if isfield(model, 'fxx')
    %fypyp,fypy,fypxp,fypx,fyyp,fyy,fyxp,fyx,fxpyp,fxpy,fxpxp,fxpx,fxyp,fxy,fxxp,fxx
    
    vars = [model.X(model.xlog), model.Y(model.ylog), model.XP(model.xlog), model.YP(model.ylog)];
    varslog = log(vars);
    
    disp('fypyp')
     model.fypyp = subs(model.fypyp,vars,varslog);
    str = ['fypyp = ' symmat_print(model.fypyp) ';'];fprintf(f, '%s\n', str);
    
    disp('fypyp')
    model.fypy = subs(model.fypy,vars,varslog);
    str = ['fypy = ' symmat_print(model.fypy) ';'];fprintf(f, '%s\n', str);
        
    disp('fypyp')
    model.fypxp = subs(model.fypxp,vars,varslog);
    str = ['fypxp = ' symmat_print(model.fypxp) ';'];fprintf(f, '%s\n', str);
        
    disp('fypyp')
    model.fypx = subs(model.fypx,vars,varslog);
    str = ['fypx = ' symmat_print(model.fypx) ';'];fprintf(f, '%s\n', str);
        
    disp('fypyp')
    model.fyyp = subs(model.fyyp,vars,varslog);
    str = ['fyyp = ' symmat_print(model.fyyp) ';'];fprintf(f, '%s\n', str);
        
    disp('fypyp')
    model.fyy = subs(model.fyy,vars,varslog);
    str = ['fyy = ' symmat_print(model.fyy) ';'];fprintf(f, '%s\n', str);
        
    disp('fypyp')
    model.fyxp = subs(model.fyxp,vars,varslog);
    str = ['fyxp = ' symmat_print(model.fyxp) ';'];fprintf(f, '%s\n', str);
        
    disp('fypyp')
    model.fyx = subs(model.fyx,vars,varslog);
    str = ['fyx = ' symmat_print(model.fyx) ';'];fprintf(f, '%s\n', str);
        
    disp('fypyp')
    model.fxpyp = subs(model.fxpyp,vars,varslog);
    str = ['fxpyp = ' symmat_print(model.fxpyp) ';'];fprintf(f, '%s\n', str);
        
    disp('fypyp')
    model.fxpy = subs(model.fxpy,vars,varslog);
    str = ['fxpy = ' symmat_print(model.fxpy) ';'];fprintf(f, '%s\n', str);
    
    disp('fypyp')
    model.fxpxp = subs(model.fxpxp,vars,varslog);
    str = ['fxpxp = ' symmat_print(model.fxpxp) ';'];fprintf(f, '%s\n', str);
        
    disp('fypyp')
    model.fxpx = subs(model.fxpx,vars,varslog);
    str = ['fxpx = ' symmat_print(model.fxpx) ';'];fprintf(f, '%s\n', str);
        
    disp('fypyp')
    model.fxyp = subs(model.fxyp,vars,varslog);
    str = ['fxyp = ' symmat_print(model.fxyp) ';'];fprintf(f, '%s\n', str);
        
    disp('fypyp')
    model.fxy = subs(model.fxy,vars,varslog);
    str = ['fxy = ' symmat_print(model.fxy) ';'];fprintf(f, '%s\n', str);
        
    disp('fypyp')
    model.fxxp = subs(model.fxxp,vars,varslog);
    str = ['fxxp = ' symmat_print(model.fxxp) ';'];fprintf(f, '%s\n', str);
       
    disp('fypyp') 
    model.fxx = subs(model.fxx,vars,varslog);
    str = ['fxx = ' symmat_print(model.fxx) ';'];fprintf(f, '%s\n', str);
end


fclose(f);

pause(.05); %A brief pause to ensure file has written to HD before accessing again.

%*******************************************************
% SYMMAT_PRINT:
% Print a symbolic expresison to a evaluateable function.
%*******************************************************
function str = symmat_print(x)
 msize = size(x);
if isa(x, 'double')
    %Not actually symbolic
    str = mat2str(x);
    
elseif length(msize)==3
    %Make matrix into a string (good for multi-dimensional arrays)
    str = char(x(:));
    str = ['reshape( ' str(8:end-1) ',[' num2str(msize), '])'];
else
    %For one and two-dimensional matrices
    str = char(x);
    str = str(8:end-1);
    
    %Make into matlab matrix notation
    row_idx = strfind(str, '],');
    for j = 1:length(row_idx)
        str(row_idx(j):row_idx(j)+1)='];';
    end
end