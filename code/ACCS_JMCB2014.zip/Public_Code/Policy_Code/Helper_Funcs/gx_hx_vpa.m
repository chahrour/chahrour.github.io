%An altnerative algorithm for computing gx_hx based on variable precision
%arithmetic.  Uses gx_hx_alt as a starting point for its iteration.

function [gx, hx, resid] = gx_hx_vpa(fy,fx,fyp,fxp,rlx,crit)

if nargin < 6
    crit = 1e-7;
end

%Double precision answer
[gx,hx] = gx_hx_alt(fy,fx,fyp,fxp,1.0000001);

%Turn everything to symbols
syms hx_old gh_new
gx = sym(gx);
hx = sym(hx);
fy = sym(fy);
fx = sym(fx);
fyp = sym(fyp);
fxp = sym(fxp);

ny = size(fy,2);
tic

%Loop for fixed point
resid = 1;jj = 1;
while jj < 250 && resid>crit
    
    gh_new = vpa([fy (fxp+fyp*gx)]\(-fx));

    if  1 < jj && jj < 100
        gx = rlx*gh_new(1:ny,:)     +  (1-rlx)*gx;
        hx = rlx*gh_new(ny+1:end,:) +  (1-rlx)*hx;
    else
        gx = gh_new(1:ny,:)   ;
        hx = gh_new(ny+1:end,:);
    end
    resid = sum(sum(abs(double(vpa(fx+fy*gx+fxp*hx+fyp*gx*hx)))));
    disp(['Iter: ' num2str(jj), ' Residual: ', num2str(resid)]);
    jj = jj+1;
end
tt1 = sum(sum(abs(double(vpa(fx+fy*gx+fxp*hx+fyp*gx*hx)))));
disp(['Numerical abs sum residual of matrix quadratic equation, full precision: ', num2str(tt1)]);

gx = double(gx);
hx = double(hx);

tt2 = sum(sum(abs(double(fx+fy*gx+fxp*hx+fyp*gx*hx))));
disp(['Numerical abs sum residual of matrix quadratic equation, returning to double: ', num2str(tt2)]);



toc