%
% mom_tab - make the basic moment tables to screen
%
% usage:
% 
% mom_tab(gx, hx, varshock, var_idx, var_names)
%
% where
%
% gx,hx,varshock are as in mom.m
% var_idx = indexies of the relevant variables in Y (first value should index output)
% var_names = names of the variables

function [sig ar_rho rho] = mom_tab(data, var_idx, var_names,yss,varargin)

if nargin>4
    prefs = varargin{1};
else
    prefs.ndec = 3;
end

sformat = ['%1.' num2str(prefs.ndec), 'f\t'];

nsim =size(data,3);
nt = size(data,2);
cov0 = zeros(length(var_idx),length(var_idx),nsim);
covl = zeros(length(var_idx),length(var_idx),nsim);
for j = 1:size(data,3)
    dat = demean(data(var_idx,:,j)');
    cov0(:,:,j) = dat'*dat/(nt-1);
    covl(:,:,j) = dat(1:end-1,:)'*dat(2:end,:)/(nt-2);
end
 
SigY0 = median(cov0,3);
SigY1 = median(covl,3);
    
tit_str = [];
for j = 1:length(var_idx)
    sig(j) = sqrt(SigY0(j,j))./yss(j);
    rho(j) = SigY0(j,1)/sqrt(SigY0(j,j)*SigY0(1,1));
    ar_rho(j) = SigY1(j,j)/(SigY0(j,j));
    tit_str = [tit_str, var_names{j}, '\t'];
end


    
disp('Standard Deviations')
disp(sprintf(tit_str))
disp(sprintf(sformat, 100*sig))
disp(' ');


disp('Stddev(X)/Stddev(Y)')
disp(sprintf(tit_str))
disp(sprintf(sformat, sig/(sig(1))))
disp(' ');


disp('Auto-correlations')
disp(sprintf(tit_str))
disp(sprintf(sformat, ar_rho))
disp(' ');

disp('Correlation w/ Y')
disp(sprintf(tit_str))
disp(sprintf(sformat, rho))
disp(' ');
