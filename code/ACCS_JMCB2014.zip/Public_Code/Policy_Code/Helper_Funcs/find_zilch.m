XLAG = mod.XLAG
[nx,ny] = size(XLAG);
out = zeros(nx,ny);

for jj = 1:nx
    for kk = 1:ny
        tmp = strfind(findsym(XLAG(jj,kk)),'zilch');
        
        if ~isempty(tmp)
            out(jj,kk) = 1;
        end
    end
end
out