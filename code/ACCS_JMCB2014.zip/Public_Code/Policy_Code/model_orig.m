
% MODEL
%
%
% To the get the automatic Ramsey working, you cannot have leads and lags
% of the same variable in the sam


function mod = model(param,set,tools,case_name)

mod.fname = ['model_prog_' case_name '.m'];
mod.ss_call = 'ss_objective.m';

%Declare parameters symbols: parameters are values to be estimated
param_list = fieldnames(param);
syms(param_list{1:end});
for j = 1:length(param_list)
    eval(['PARAM(j) = ',param_list{j} ,';']);
end
PARAM

%Declare setting symbols: symbols are values that are "fixed"
set_list = fieldnames(set);
syms(set_list{1:end});
for j = 1:length(set_list)
    eval(['SET(j) = ',set_list{j} ,';']);
end
SET



%Add in aggregate variables
syms X1 X2 P1 P2 KF1 KF2 A1 A2 S1 S2 THET1 THET2 W L R PII RS W GDP A RL BB ZL EPP EPPL EPPA EPPB  AT1 AT2 GBCL L4 L5 L6 L7 L10 L11
syms N1 N2 TAUL Z MU G X1L N1L P1L TAUW TAUN1 TAUN2 TAUA1 TAUA2 TAUN1L TAUN2L N1L N1 N2 N2L X1L P1L P2L TAUN1L TAUN2L TAUA1L TAUA2L RL TAULL TAUWL WL S1L S2L THET1L THET2L BBL Z G LL GL PIIL

TV = [TAUL TAUN1 TAUN2 TAUA1 TAUA2 EPP];  %Depending on what is a Ramsey tool, may be exogenous or endogenous.

Y = [P1 P2 X1 X2 PII R L S1 THET1 S2 THET2 W BB AT1 AT2 TV(tools(1:end-1))];
X = [N1 N2 GBCL Z G];  

if ~tools(1);   X = [X,TAUL];end; %Include exog labor tax?
if ~tools(end); X = [X,EPP RL];end; %Include exog money policy & money dhock?

YP = make_prime(Y); for j=1:length(YP); eval(['syms ' char(YP(j))]);end
XP = make_prime(X); for j=1:length(XP); eval(['syms ' char(XP(j))]);end

%For exogenous taxes that are fixed
if ~tools(2); TAUN1 = taun1; TAUN1_p = taun1; end;
if ~tools(3); TAUN2 = taun2; TAUN2_p = taun2; end;
if ~tools(4); TAUA1 = taua1; TAUA1_p = taua1; end;
if ~tools(5); TAUA2 = taua2; TAUA2_p = taua2; end;

%*******************************
%FUNCTIONAL FORMS
%*******************************

ux   = @(x1,x2) (((1-kapx)*x1^phix + kapx*x2^phix)^((1-sigx)/phix)-1)/(1-sigx);
vn   = @(n1,n2) (((1-kapc)*n1^phic + kapc*n2^phic)^((1-sigc)/phic)-1)/(1-sigc);
hl   = @(x) (zet/(1+1/nu))*x^(1+1/nu);

hp = @(x) zet*(x)^(1/nu);
u1  = @(x1,x2) ((1-kapx)*x1^phix + kapx*x2^phix)^((1-sigx-phix)/phix)*(1-kapx)*x1^(phix-1);
u2  = @(x1,x2) ((1-kapx)*x1^phix + kapx*x2^phix)^((1-sigx-phix)/phix)*kapx*x2^(phix-1);
v1  = @(n1,n2) ((1-kapc)*n1^phic + kapc*n2^phic)^((1-sigc-phic)/phic)*(1-kapc)*n1^(phic-1);
v2  = @(n1,n2) ((1-kapc)*n1^phic + kapc*n2^phic)^((1-sigc-phic)/phic)*kapc*n2^(phic-1);
m1 =  @(s1,a1) psi1*s1^xi*a1^(1-xi);
m2 =  @(s2,a2) psi2*s2^xi*a2^(1-xi);
kh1 = @(thet1)  psi1*thet1^(1-xi);
kh2 = @(thet2)  psi2*thet2^(1-xi);
kf1 = @(thet1)  psi1*thet1^-xi;
kf2 = @(thet2)  psi2*thet2^-xi;


%********************************
% PERIOD SOCIAL WELFARE FUNCTION
%********************************
Util = ux(X1,X2) + vartheta*vn(N1,N2) - hl(S1+S2+L);

%***********************************************************
%EQ CONDITIONS (CONSTRAINTS ON RAMSEY POLICY)
%**********************************************************

%LABOR-LEISURE
f(1) = hp(L+S1+S2)/u2(X1,X2) - (1-TAUL)*(1+tauw)*W; 

%INTEREST RATE
f(end+1) = u1(X1,X2)/u2(X1,X2) - R; 

%BOND ACCUMULATION
f(end+1) = u1(X1,X2)/R - bet*u1(X1_p, X2_p)/PII_p; 

%SEARCH CHOICE
f(end+1) = hp(L+S1+S2)/kh1(THET1) - (1/kh1(THET1)-1)*kap*u2(X1,X2) - bet*(1-rhox)*(vartheta*v1(N1_p,N2_p) - P1_p*R_p*(1+TAUN1_p)*u2(X1_p,X2_p) + hp(L_p+S1_p+S2_p)/kh1(THET1_p) - kap*u2(X1_p,X2_p)*(1-kh1(THET1_p))/kh1(THET1_p)); 
f(end+1) = hp(L+S1+S2)/kh2(THET2) - (1/kh2(THET2)-1)*kap*u2(X1,X2) - bet*(1-rhox)*(vartheta*v2(N1_p,N2_p) - P2_p*(1+TAUN2_p)*u2(X1_p,X2_p)     + hp(L_p+S1_p+S2_p)/kh2(THET2_p) - kap*u2(X1_p,X2_p)*(1-kh2(THET2_p))/kh2(THET2_p)); 

%ADVERTISING CHOICE
f(end+1) = (1-TAUA1)*gam1/kf1(THET1)*u2(X1,X2) - bet*(1-rhox)*u2(X1_p,X2_p)*AT1_p; 
f(end+1) = (1-TAUA2)*gam2/kf2(THET2)*u2(X1,X2) - bet*(1-rhox)*u2(X1_p,X2_p)*AT2_p; 

%ADV. ENVELOPE CONDITION
f(end+1) = AT1 - P1 +1 - gam1*(1-TAUA1)/kf1(THET1);
f(end+1) = AT2 - P2 +1 - gam2*(1-TAUA2)/kf2(THET2);

%PRICING EQ
f(end+1) = u2(X1,X2)*(R*(1+TAUN1)*(AT1*eta1/(1-eta1) + P1) - (vartheta*v1(N1,N2)/u2(X1,X2)-kap)) - (1-rhox)*bet*u2(X1_p, X2_p)*R_p*(1+TAUN1_p)*eta1/(1-eta1)*AT1_p;
f(end+1) = u2(X1,X2)*((1+TAUN2)*(AT2*eta2/(1-eta2) + P2) - (vartheta*v2(N1,N2)/u2(X1,X2)-kap))   - (1-rhox)*bet*u2(X1_p, X2_p)*(1+TAUN2_p)*eta2/(1-eta2)*AT2_p;

%EVOLUTION OF MATCHES
f(end+1) = N1_p - (1-rhox)*(N1 + m1(S1,THET1*S1)); 
f(end+1) = N2_p - (1-rhox)*(N2 + m2(S2,THET2*S2)); 

%NKPC
f(end+1) = ((1-veps + veps*W/Z)*(Z*L) - varphi*(PII-pistar)*PII)*u2(X1,X2) + bet*u2(X1_p,X2_p)*varphi*(PII_p-pistar)*PII_p; 

%RC
f(end+1) = X1+X2+N1+N2+G+gam1*THET1*S1+gam2*THET2*S2+varphi/2*(PII-pistar)^2-Z*L; 

if set.lump_sum
    %LUMP SUM TAXES GBCL AND BB DON'T MATTER
    f(end+1) = BB-bbar;
    f(end+1) = log(GBCL_p) - 0; 
else
    %WITH BUDGET CONSTRAINT
    dt = (P1-1)*N1 + (P2-1)*N2 - (1-TAUA1)*gam1*S1*THET1 - (1-TAUA2)*gam2*S2*THET2;
    mp = (1-W/Z)*Z*L - varphi/2*(PII - pistar)^2;
    f(end+1) =  GBCL_p - (dt + mp + TAUL*(1+tauw)*W*L  + P2*TAUN2*N2 - X1 - P1*N1 - R*BB - G - kap*((1-kh1(THET1))*S1 + (1-kh2(THET2))*S2) - TAUA1*gam1*THET1*S1 - TAUA2*gam2*THET2*S2 - tauw*W*L) ; 
    f(end+1) = (X1 + P1*(1+TAUN1)*N1)*PII + BB*PII + GBCL;
end


%**********************************
% EXOGENOUS PROCESSES
%**********************************
f(end+1) = log(Z_p) - rhoz*log(Z); 
f(end+1) = log(G_p/gbar) - rhog*log(G/gbar);   

%**************************************************************************
% EXOGENOUS POLICIES (WHEN NOT RAMSEY TOOLS)
%**************************************************************************
if ~tools(1)
    f(end+1) = log(TAUL_p/taul)-rhotl*log(TAUL/taul);
end
if ~tools(end)
    f(end+1) =  log(R/rbar) - rhor*log(RL/rbar) - (1-rhor)*(alphpi*log(PII/pistar) + alphy*log(GDP/gdp)) - log(EPP);
    f(end+1) =  log(EPP_p);
    f(end+1) =  RL_p - R;
end

neq = length(f);
nvar = length(X) + length(Y);

%***********************************************************
% DEFINITIONAL EQUATIONS (NOT CONSTRAINTS ON RAMSEY) POLICY
%
% these variables will appear at the last (non-lagrange)
% entries in Y and YP.  Requires some care in choosing logvar
% appropriately.
%***********************************************************
syms WDG1 WDG2 WDG3 WDG4 WDG5 V S N XX 
defY =  [A A1 A2 S XX N GDP WDG1 WDG2 WDG3 WDG4 WDG5 V];
defYP = make_prime(defY); for j=1:length(defYP); eval(['syms ' char(defYP(j))]);end

def(1) = (gam2*THET2*S2 + gam1*THET1*S1) - A;
def(end+1) = gam1*THET1*S1 - A1;
def(end+1) = gam2*THET2*S2 - A2;
def(end+1) = N - N1 - N2;
def(end+1) = S - S1 - S2;
def(end+1) = XX - X1 - X2;
def(end+1) = GDP - Z*L;
def(end+1) = WDG1 - (hp(L+S1+S2)/u2(X1,X2))/Z;
def(end+1) = WDG2 - (hp(L+S1+S2)/u2(X1,X2))*((1-xi)/xi)/(gam1*THET1);
def(end+1) = WDG3 - (hp(L+S1+S2)/u2(X1,X2))*((1-xi)/xi)/(gam2*THET2);
def(end+1) = WDG4 - u2(X1,X2)*gam1/(psi1*(1-xi)*THET1^(-xi)*bet*(1-rhox)*(vartheta*v1(N1_p,N2_p)-u2(X1_p,X2_p)*(1-gam1/(psi1*(1-xi)*THET1_p^(-xi)))));
def(end+1) = WDG5 - u2(X1,X2)*gam2/(psi2*(1-xi)*THET2^(-xi)*bet*(1-rhox)*(vartheta*v2(N1_p,N2_p)-u2(X1_p,X2_p)*(1-gam2/(psi2*(1-xi)*THET2_p^(-xi)))));
def(end+1) = V - Util - bet*V_p;

transpose(f)

%**************************************************************************
% RAMSEY CODE - AUTOMATIC
%**************************************************************************
if neq < nvar
    
    zilch = sym('zilch');
    
    fram = f;

    %Take t+1 and t-1 version of equations
    fp = subs(fram, [Y X YP XP], [YP, XP, 0*YP+zilch, 0*XP+zilch]);
    fl = subs(fram, [YP XP Y X], [Y,  X,  0*YP+zilch, 0*XP+zilch]);
    
    Utilp = subs(Util, [Y X YP XP], [YP, XP, 0*YP+zilch, 0*XP+zilch]);
    Utill = subs(Util, [YP XP Y X], [Y,  X,  0*YP+zilch, 0*XP+zilch]);
    
    %Automatically Generate the proper lagrange multipliers and linking
    %equations for them.
    lam_X = []; lam_XP = []; lam_Y = []; lam_YP = []; eq_link = [];
    for j = 1:neq
        eval(['syms L',num2str(j), ' L',num2str(j), '_l' ' L',num2str(j), '_p' ' L',num2str(j), '_lp']);
        eval(['lam_X = [lam_X, L' num2str(j) '_l];']);
        eval(['lam_XP = [lam_XP, L' num2str(j) '_lp];']);
        eval(['lam_Y = [lam_Y, L' num2str(j) '];']);
        eval(['lam_YP = [lam_YP, L' num2str(j) '_p];']);
        eval(['eq_link =[eq_link,  L' num2str(j) '- L' num2str(j), '_lp];']);
    end
    
    %SS Lagrange variables and the competative equilibrium variables
    cee_var = [Y, XP];
    
    %Get the Ramsey FOC's
    obj = Util + (1/bet)*Utill + bet*Utilp ...            %Welfare function
        - (1/bet)*lam_X*transpose(fl) ...                 %Lagged lagrange multipliers
        - lam_Y*transpose(fram) ...                          %Current constraints
        - bet*lam_YP*transpose(fp);                       %Future constraints

    foc = jacobian(obj, cee_var);
    cee_var
    %Drop uneeded lambdas
    syms_in = findsym(foc);
    keep_x = [];
    keep_y = [];
    for j = 1:neq
        keep_x(j) = ~isempty([findstr(syms_in, ['L', num2str(j), '_l']) findstr(syms_in, ['L', num2str(j), '_lp'])]);
        keep_y(j) = ~isempty([findstr(syms_in, ['L', num2str(j)]) findstr(syms_in, ['L', num2str(j), '_p'])]);
    end
    keep_lnk = (keep_x + keep_y)==2;
    keep_x = logical(keep_x);
    keep_y = logical(keep_y);
    eq_link = eq_link(keep_lnk);
    
    lam_X = lam_X(keep_x);
    lam_XP = lam_XP(keep_x);
    lam_Y = lam_Y;%(keep_y);
    lam_YP = lam_YP;%(keep_y);

    %Combine eq's and plug in logvars
    f = [f, foc, def, eq_link];
    
    %Add in the lagrange multipliers to our set of variables
    X   = [X,  lam_X];
    XP  = [XP, lam_XP];
    Y   = [Y,  defY,  lam_Y];
    YP  = [YP, defYP, lam_YP];
    dvar= [lam_X, lam_Y];
    
    
    %Generate symbolic matrices for linear regression in num_model.m
    LAG_SS = subs([foc, eq_link], lam_XP, lam_X);
    LAG_SS = subs(LAG_SS, lam_YP, lam_Y);
    YLAG = subs(LAG_SS, dvar, 0*dvar);
    XLAG = -jacobian(LAG_SS, dvar);
    
    mod.xtra_rest = [BB-bbar];%.00001*(bshr - 0);
    
    mod.keep_lnk = keep_lnk;
    mod.YLAG = YLAG;
    mod.XLAG = XLAG;
    mod.LAG_SS = LAG_SS;
    mod.dvar = dvar;
    mod.lam_X = lam_X;
    mod.lam_Y = lam_Y;
else
    
    Y = [Y,  defY];
    YP = [YP, defYP];
    f = [f,def];
    
    mod.xtra_rest = [];
    mod.YLAG = [];
    mod.XLAG = [];
    mod.LAG_SS = [];
    mod.dvar = [];
    mod.lam_X = [];
    mod.lam_Y = [];
end


%****************************************************
% CONTINUE WITH SOLVING THE MODEL
%****************************************************

%Loop creates indexes to track variables (for figures, etc)
ny = length(Y);
nx = length(X);
for j=1:ny; 
    vn = char(Y(j));
    eval([lower(vn), '_idx = j;'])
end
for j=1:nx; 
    vn = char(X(j));
    eval([lower(vn), '_idx = ny+j;'])
end

xlog = [z_idx,g_idx];
if ~tools(1)
    xlog = [xlog,taul_idx];
end
if ~tools(end)
    xlog = [xlog,epp_idx];
end
xlog = xlog-ny;
ylog = [];

logvars = [X(xlog) Y(ylog) XP(xlog) YP(ylog)];
f = subs(f, logvars, exp(logvars));

disp(['Number of eq conditions: ' num2str(neq)]);
disp(['Number of endog variables: ' num2str(nvar)]);
disp(['Number of equations: ' num2str(length(f))]);
disp(['Number of variables: ' num2str(length(X)+length(Y))]);

%Put Everything in an object to pass, and take derivatives
mod.f = f;
mod.Y = Y;
mod.X = X;
mod.YP = YP;
mod.XP = XP;
mod.xlog = xlog;
mod.ylog = ylog;
mod.logvars = logvars;


mod.PARAM = PARAM;
mod.param = param;
mod.SET = SET;
mod.set = set;
mod.adiff = 0;

%Exogenous processes
neps = 2 + sum(~tools([1,end]));
mod.shck = sym(zeros(length(X),neps));
mod.shck(4:4+neps-1,1:neps) = diag([sigz,sigg,sigt,sigr]);

mod.shck

%Measurement Error
mod.me = sym(zeros(length(Y)));
for j = 1:length(set.me_eq)
    eval(['mod.me(set.me_eq(j),set.me_eq(j)) = sig_ME' num2str(set.me_eq(j))  ';']);
end


%Take Derivatives
[1:length(X);X]
[1:length(Y);Y]

mod = anal_deriv(mod);

%Put levels back in for f and first-derivatives
vars= [mod.X(mod.xlog), mod.Y(mod.ylog),mod.XP(mod.xlog), mod.YP(mod.ylog)];
varslog = log(vars);
mod.f = subs(mod.f,vars,varslog);
mod.fx = subs(mod.fx,vars,varslog);
mod.fy = subs(mod.fy,vars,varslog);
mod.fxp = subs(mod.fxp,vars,varslog);
mod.fyp = subs(mod.fyp,vars,varslog);


%Save index variables for use in main_prog
save v_idx *_idx
