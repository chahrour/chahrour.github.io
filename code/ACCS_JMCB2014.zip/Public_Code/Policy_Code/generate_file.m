function case_name = generate_file(case_name)

%Functions called by the Ramsey code that are not specific to this problem.
addpath(genpath('Helper_Funcs'));

%Ramsey instruments that are adjusted in SS
%Tools are (tauL, tauN1, tauN2, tauA1, tauA2, R);
ss_tools = logical([1 1 1 1 1 1]);

%Ramsey intruments that are adjusted dynamically
tools = ss_tools;

%Gov't get lump-sum taxes (only allow for competitive eq.)
lump_sum = 0;

%Drop Ramsey tools for cases when not available
if strcmp(case_name, 'RAMSEY_LMTD')
    tools(2:5) = 0;
    ss_tools(2:5) = 0;
elseif strcmp(case_name, 'COMPETITIVE')
    tools(:) = 0;
    ss_tools(:) = 0;
    lump_sum = 1;
end

%Default parameters values
[param,set] = parameters(ss_tools, lump_sum);

%Symbolic code for generating model equations
modl = model_orig(param,set,tools,case_name); 

%Convert symbolic expressions to mfile for (much) faster execution
ramsey_func(modl); 

%Save model object and index variables for each element of X and Y
load v_idx
eval(['save model_obj_' case_name, ' modl *_idx']);
delete v_idx.mat

%Load parameters from estimation
load estparam
[param,set] = assign_estimated_params(param_est,set_est,param,set);
set.tauw  = set.veps/(set.veps-1)-1;
set.minL = 1e-10;

%Lump sum taxes only for the competative case
eval(['save run_params_' case_name ' param set tools ss_tools']);