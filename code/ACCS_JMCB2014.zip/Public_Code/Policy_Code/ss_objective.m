function [out,Yss,Xss] =  ss_objective(X, pistar,bet,sigx,sigc,phix,phic,nu,rhox,xi,veps,kapx,kapc,kap,gbar,zet,vartheta,gam1,gam2,kf1,kf2,eta1,eta2,psi1,psi2,taul,tauw,taun1,taun2,taua1,taua2,bbar,lump_sum,tools)

x2 = X(1);
s2 = X(2);
n1 = X(3);
n2 = X(4);
lbar = X(5);


%BEGIN_EXTRACT_HERE


%from equation 3
rbar = pistar/bet;

%from 2
x1 = (rbar*kapx/(1-kapx))^(1/(phix-1))*x2;

%Definitions
RHO = (1-rhox)*bet/(1-(1-rhox)*bet);
%u1 = ((1-kapx)*x1^phix + kapx*x2^phix)^((1-sigx-phix)/phix)*(1-kapx)*x1^(phix-1) ;
u2 = ((1-kapx)*x1^phix + kapx*x2^phix)^((1-sigx-phix)/phix)*kapx*x2^(phix-1);
v1 = ((1-kapc)*n1^phic + kapc*n2^phic)^((1-sigc-phic)/phic)*(1-kapc)*n1^(phic-1);
v2 = ((1-kapc)*n1^phic + kapc*n2^phic)^((1-sigc-phic)/phic)*kapc*n2^(phic-1);


%from NKPC
w = (veps-1)/veps;


%from equation 1
s1 = ((w*(1-taul)*(1+tauw)*u2)/zet)^nu - lbar -s2;

%from equation 11-12
a1 = (rhox*n1/((1-rhox)*psi1*s1^xi))^(1/(1-xi));
a2 = (rhox*n2/((1-rhox)*psi2*s2^xi))^(1/(1-xi));

%from nash pricing equation
vk1 = (vartheta*v1/u2-kap);
vk2 = (vartheta*v2/u2-kap);
thet1 = a1/s1;
thet2 = a2/s2;
kf1 = psi1*thet1^-xi;
kf2 = psi2*thet2^-xi;
% w1 = 1/(1+(1-(1-rhox)*bet)*eta1/(1-eta1));
% w2 = 1/(1+(1-(1-rhox)*bet)*eta2/(1-eta2));
% p1 = w1*vk1/(rbar*(1+taun1)) + (1-w1)*(1-gam1*(1-taua1)/kf1)
% p2 = w2*vk2/(1+taun2) + (1-w2)*(1-gam2*(1-taua2)/kf2)
p1 = (1-eta1)*(vartheta*v1/u2-kap)/(rbar*(1+taun1)) + eta1;
p2 = (1-eta2)*(vartheta*v2/u2-kap)/(1+taun2) + eta2;
%definition
kh1 = psi1*(a1/s1)^(1-xi);
kh2 = psi2*(a2/s2)^(1-xi);

%Check eq 5 and 6
fo(1) = (1-taul)*(1+tauw)*w - kap*(1-kh1) - RHO*kh1*(vartheta*v1/u2 - p1*rbar*(1+taun1));
fo(2) = (1-taul)*(1+tauw)*w - kap*(1-kh2) - RHO*kh2*(vartheta*v2/u2 - p2*(1+taun2));

%Check eq 7-8
fo(3) = (1-taua1)*gam1/(psi1*(a1/s1)^(-xi)) - RHO*(p1-1);
fo(4) = (1-taua2)*gam2/(psi2*(a2/s2)^(-xi)) - RHO*(p2-1);

%from rc
fo(5) = lbar - (x1+x2+n1+n2+gbar+gam1*a1+gam2*a2);


%fo = fo + (a1<0)*abs(a1) + (a2<0)*abs(a2) + (s1<0)*abs(s1) + (s2<0)*abs(s2) + (pistar<bet)*(bet-pistar);

fo = [fo, (a1<0)*abs(a1), (a2<0)*abs(a2), (s1<0)*abs(s1), (s2<0)*abs(s2), (pistar<bet)*(bet-pistar)];

%SS bonds
if lump_sum
    bb = bbar;
else   
    dtl = (p1-1)*n1 + (p2-1)*n2 - (1-taua1)*gam1*a1 - (1-taua2)*gam2*a2;
    mp = (1-w)*lbar;
    bb = (pistar*(x1 + p1*(1+taun1)*n1) + dtl + mp + taul*(1+tauw)*w*lbar + p2*taun2*n2 - x1 - p1*n1 - gbar - ((1-kh1)*s1 + (1-kh2)*s2)*kap - taua1*gam1*a1 - taua2*gam2*a2 - tauw*w*lbar)/(rbar - pistar);
end




%Envelope condition

at1 = p1 - 1 + gam1*(1-taua1)/kf1;
at2 = p2 - 1 + gam2*(1-taua2)/kf2;

%SS Wedges
hl = zet*(lbar+s1+s2)^(1/nu);
ma1 = psi1*(1-xi)*thet1^(-xi);
ma2 = psi2*(1-xi)*thet2^(-xi);
ms1 = psi1*xi*thet1^(1-xi);
ms2 = psi2*xi*thet2^(1-xi);

wd1 = hl/u2;
wd2 = hl*(1-xi)/(u2*gam1*thet1*xi);
wd3 = hl*(1-xi)/(u2*gam2*thet2*xi);
wd4 = inv(bet*(1-rhox)*(vartheta*v1/u2 - 1 + gam1/ma1)*ma1/gam1);
wd5 = inv(bet*(1-rhox)*(vartheta*v2/u2 - 1 + gam2/ma2)*ma2/gam2);
wdg = [wd1 wd2 wd3 wd4 wd5];
gdp = x1 + x2 + gbar + gam1*a1 + gam2*a2 + n1 + n2;

%SS Util
ux   = @(x1,x2) (((1-kapx)*x1^phix + kapx*x2^phix)^((1-sigx)/phix)-1)/(1-sigx);
vn   = @(n1,n2) (((1-kapc)*n1^phic + kapc*n2^phic)^((1-sigc)/phic)-1)/(1-sigc);
hl   = @(x) (zet/(1+1/nu))*x^(1+1/nu);
ss_util = (ux(x1,x2) + vartheta*vn(n1,n2) - hl(s1+s2+lbar))/(1-bet);

if lump_sum
    bb = bbar;
    gbcl = 1;
else   
    dt = (p1-1)*n1 + (p2-1)*n2 - (1-taua1)*gam1*a1 - (1-taua2)*gam1*a2;
    mp = (1-w)*lbar;
    bb = (pistar*(x1 + p1*(1+taun1)*n1) + mp + dt + taul*(1+tauw)*w*lbar + p2*taun2*n2 - x1 - p1*n1 - gbar - ((1-kh1)*s1 + (1-kh2)*s2)*kap - taua1*gam1*a1 - taua2*gam2*a2 - tauw*w*lbar)/(rbar - pistar);
    gbcl = dt + mp + taul*(1+tauw)*w*lbar  + p2*taun2*n2 - x1 - p1*n1 - rbar*bb - gbar - kap*((1-kh1)*s1 + (1-kh2)*s2) - taua1*gam1*a1 - taua2*gam2*a2 - tauw*w*lbar;
end

zbar = 1;
eppbar = 1;


tv = [taul taun1 taun2 taua1 taua2];
Yss = [p1 p2 x1 x2 pistar rbar lbar s1 thet1 s2 thet2 w bb at1 at2 tv(tools(1:end-1)) (gam1*a1+gam2*a2) gam1*a1 gam2*a2 (s1+s2) (x1+x2) (n1+n2)  lbar wd1 wd2 wd3 wd4 wd5  ss_util];
Xss = [n1 n2 gbcl zbar gbar];

if ~tools(1); Xss=[Xss,taul]; end;
if ~tools(end);Xss = [Xss,eppbar,rbar]; end;

%END_EXTRACT_HERE


out = [100*fo, 100*(s1<0), 100*(s2<0)];

