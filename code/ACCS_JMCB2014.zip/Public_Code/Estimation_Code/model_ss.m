% MODEL_SS - Return the steady state of the model computed analytically
%
% usage:
% 
% [ss, parameters] =model_ss(param)


function [Yss, Xss, param,set] = model_ss(param,set,varargin)
param

%This loop assigns values to variables with the same names as the fields in
%param.
nms = fieldnames(param);

for j = 1:length(nms)
    eval([nms{j} '='  'param.' nms{j} ';'])
end

if nargin>2
    for j = 1:length(nms)
    eval([nms{j} '='  'varargin{1}(j);'])
end
end
    
ns = fieldnames(set);
for j = 1:length(ns)
    eval([ns{j} '='  'set.' ns{j} ';'])
end


%BEGIN_EXTRACT_HERE
xshr = 1 - adshr1 - adshr2 - nshr - gshr;
%tauw = 0;
taua1 = 0;
taua2 = 0;
taun1 = 0;
taun2 = 0;
sigx = sigxc;
sigc = sigxc;
nshr1 = .5*nshr;
nshr2 = .5*nshr;

%Set SS output to zero-markup level
tauw = 1-(veps-1)/veps;
w = (veps-1)/veps*1/(1-tauw);
rbar = pistar/bet; %Inerest rate
X = xshr*lbar;
n1 = nshr1*lbar;
n2 = nshr2*lbar;
adbar1 = adshr1*lbar;
adbar2 = adshr2*lbar;
gbar = gshr*lbar;
rhox = (1-rho);


%Use closed form expressions for the ss values.
RHO = (1-rhox)*bet/(1-(1-rhox)*bet);

%Pin down prices
p1 = 1+adbar1/(rhox/(1-rhox)*n1)*((1-taua1)/RHO);
p2 = 1+adbar2/(rhox/(1-rhox)*n2)*((1-taua2)/RHO);



% %get eta1 and eta2
% OMEGA1 = (- (RHO-1)/RHO*kap + ((1-taul)*w - kap)/(RHO*kh1))/((p1-1)*rbar*(1+taun1));
% OMEGA2 = (- (RHO-1)/RHO*kap + ((1-taul)*w - kap)/(RHO*kh2))/((p2-1)*(1+taun2));
% 
% eta1 = OMEGA1/(1+OMEGA1);
% eta2 = OMEGA2/(1+OMEGA2);

%het kh1 kh2

kh1 = ((1-taul)*w-kap)/((p1-1)*RHO*rbar*(1+taun1)*eta1/(1-eta1) - (1-RHO)*kap);
kh2 = ((1-taul)*w-kap)/((p2-1)*RHO*(1+taun2)*eta2/(1-eta2) - (1-RHO)*kap);

%Get advertising, tightness, etc
thet1 = kh1/kf1;  psi1 = kf1/(thet1^(-xi));
thet2 = kh2/kf2;  psi2 = kf2/(thet2^(-xi));

gam1 = RHO*(p1-1)*kf1/(1-taua1);
gam2 = RHO*(p2-1)*kf2/(1-taua2);

s1 = adbar1/(gam1*thet1);
s2 = adbar2/(gam2*thet2);

a1 = thet1*s1;
a2 = thet2*s2;

%Back out x and related marginal utilities
x2 = X*(1-kapx)^(1/(phix-1))/((kapx*rbar)^(1/(phix-1))+(1-kapx)^(1/(phix-1)));
x2tmp = X*(1+ ((kapx/(1-kapx))*rbar)^(1/(phix-1)))^-1;

%[x2 x2tmp]
x1 = X-x2;
u1 = ((1-kapx)*x1^phix + kapx*x2^phix)^((1-sigx-phix)/phix)*(1-kapx)*x1^(phix-1) ;
u2 = ((1-kapx)*x1^phix + kapx*x2^phix)^((1-sigx-phix)/phix)*kapx*x2^(phix-1);

%Pin down kapc
v1v2 = ((p1-eta1)/(1-eta1)*rbar*(1+taun1) + kap)/((p2-eta2)/(1-eta2)*(1+taun2) + kap);
kapc = 1/((n1/n2)^(1-phic)*v1v2+1);

%Marginal utilities
v1 = ((1-kapc)*n1^phic + kapc*n2^phic)^((1-sigc-phic)/phic)*(1-kapc)*n1^(phic-1);
v2 = ((1-kapc)*n1^phic + kapc*n2^phic)^((1-sigc-phic)/phic)*kapc*n2^(phic-1);

RS = (kh2/kh1);

at1 = p1 - 1 + gam1*(1-taua1)/kf1;
at2 = p2 - 1 + gam2*(1-taua2)/kf2;

%Pin down vartheta
% x1
% x2
% phix
% kapx
vartheta = u2/v1*(kap+(p1-eta1)/(1-eta1)*rbar*(1+taun1));
zet = (1-taul)*w*u2*(lbar+s1+s2)^(-1/nu);
%xshr+nshr1+nshr2+adshr1+adshr2
if xshr < 0 || xshr > 1
    disp('Hello There');
    pause
end
%**********************************************************
% EQUATION CHECKS: COMMENT OUT
%**********************************************************
%  disp('Checking equations...')
% 
%  
%  %check 2
%  zet*(lbar+s1+s2)^(1/nu) - (1-taul)*w*u2
%  
%  %Check 3
%  u1/u2 - rbar
%  
%  %Check eq 5 and 6
%  (1-taul)*w*(1-bet*(1-rhox)) - kap*(1-kh1)*(1-bet*(1-rhox)) - bet*(1-rhox)*(vartheta*v1/u2 - p1*rbar*(1+taun1))*kh1
%  (1-taul)*w*(1-bet*(1-rhox)) - kap*(1-kh2)*(1-bet*(1-rhox)) - bet*(1-rhox)*(vartheta*v2/u2 - p2*(1+taun2))*kh2
% 
%  %Check eq 7-8
%  (1-taua1)*gam1/(psi1*thet1^(-xi)) - RHO*(p1-1)
%  (1-taua2)*gam2/(psi2*thet2^(-xi)) - RHO*(p2-1)
% 
%  %Check eq 9-10
%  p1 - (1-eta1)*(vartheta*v1/u2-kap)/(rbar*(1+taun1)) - eta1
%  p2 - (1-eta2)*(vartheta*v2/u2-kap)/(1+taun2) - eta2
% 
%  %Check 11-12
%  rhox*n1-(1-rhox)*psi1*s1^xi*a1^(1-xi)
%  rhox*n2-(1-rhox)*psi2*s2*thet2^(1-xi)
%  
%  adbar1 - gam1*a1
%  adbar2 - gam2*a2
%  %RC
%  x1+x2+n1+n2+gbar+gam1*a1+gam2*a2-lbar
%[eta1,eta2,vartheta,kap]
if (eta1<0) || (eta1>1) || (eta2<0) || (eta2>1)
    flg = 1;
else
    flg = 0;
end

ngdp = lbar;%x1 + x2 + gbar + gam1*a1 + gam2*a2 + p1*n1 + p2*n2;
ay = (gam1*a1+gam2*a2); 
Yss = [p1 p2 x1 x2 pistar rbar lbar s1 thet1 s2 thet2  w ngdp at1 at2 ay (n1 + n2) (s1+s2) 1 1 1 1 1 ones(1,9+15)];
Xss = [ n1 n2 rbar ay ay ay  1 1 gbar taul  ngdp ay ay ay ay pistar ones(1,9+12)];

%END_EXTRACT_HERE
set.vartheta = vartheta;
set.zet = zet;
set.psi1 = psi1;
set.psi2 = psi2;
set.gam1 = gam1;
set.gam2 = gam2;
set.gbar = gbar;
set.eta1 = eta1;
set.eta2 = eta2;
set.kapc = kapc;
set.rbar = rbar;
set.rhox = rhox;
set.nshr1 = nshr1;
set.nshr2 = nshr2;
set.sigx = sigx;
set.sigc  = sigc;


