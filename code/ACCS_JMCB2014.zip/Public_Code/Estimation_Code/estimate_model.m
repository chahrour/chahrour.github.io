%**************************************************************************
% ESTIMATE_MODEL - Perform estiamtion of model, starting with an
% optimization using FMINCON, followed by a set of MC-MC chains. Use
% matlabpool command to take advantage of parallel computation of the 
% MC-MC chains.
%**************************************************************************


diary ESTIMATION

%Step length for MC-MC 
np = length(paramv);
paramv = paramv(:);
lbnd = lbnd(:);
ubnd = ubnd(:);
step = (ubnd-lbnd)/575;

%Load actual data
load main_data dat_reg
dat = dat_reg;
ndrop = 21;

%Use previous estimates as starting point, with some randomization.
load estparam param_est
param_start = struct2array(param_est)';
param_start = min(max(param_start + 50*step.*rand(np,1), lbnd),ubnd)';

%ML estimation (i.e. posterior mode)
obj = @(x)-liklhd(x,setv,S,dat,ndrop);
options = optimset('fmincon');
options = optimset(options, 'display', 'iter', 'maxfunevals', 8000);

[param_ml,pinit] = fmincon(obj, param_start',[],[],[],[],lbnd,ubnd,[],options);
param_start = param_start(:); param_ml = param_ml(:); lbnd = lbnd(:); ubnd = ubnd(:);
[param_start, param_ml, lbnd ubnd]

%****************************************
%SAMPLE USING MCMC
%****************************************

%Start chain
 nchain = 1;
 chaint = 10000;

% nchain = 8;
% chaint = 2000000;

accept = zeros(nchain,1);
lklval = zeros(nchain,chaint);
pchain_cell = cell(nchain,1);
ttime = zeros(nchain,1);
bndlowkk = zeros(np,nchain);
bndhighkk = zeros(np,nchain);
for j = 1:nchain
    pchain_cell{j} = zeros(np,chaint);
    pchain_cell{j}(:,1) = min(max(param_ml + 5*step.*rand(np,1), lbnd),ubnd);
end


%Run parrallel chains
parfor kk = 1:nchain
    
    %Intialize pvalue
    p = zeros(1,chaint);
    accept_tmp = 0;
    bndlow = 0;
    bndhigh = 0;
    
    tic
    %inital point from ML estimation
    p(1) = -obj(pchain_cell{kk}(:,1));
    
    %Main Loop
    for j = 1:chaint-1
        [pchain_cell{kk}(:,j+1),p(j+1),yn,~,tmplow,tmphigh] = mcmc(pchain_cell{kk}(:,j),setv,S,dat,p(j),step,lbnd,ubnd,ndrop);
        accept_tmp = accept_tmp+yn;
        bndlow = bndlow+tmplow;
        bndhigh = bndhigh+tmphigh;
        if mod(j,1000)==0
            disp(['chain ' num2str(kk), ' iteration ', num2str(j/1000), ' thousand. ' num2str(toc/60) ' minutes. Accept rate ' num2str(accept_tmp/j)]);
        end
    end  
    
    %Store output for each chain
    accept(kk) = accept_tmp;
    lklval(kk,:) = p;
    ttime(kk) = toc;
    bndlowkk(:,kk) = bndlow;
    bndhighkk(:,kk) = bndhigh;
end
accept_rate = accept./chaint;
save estimate_out
diary OFF