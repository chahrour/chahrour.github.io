%***************************************************************************
% MAIN_PROG - Prepares the workspace for the estimation in Arseneau, Chahrour, 
% Chugh, Shapiro, "Optimal Fiscal and Monetary Policy in Customer Markets"
% JMCB, 2014/2015.
%**************************************************************************


rng('default')

diary ../Figures_and_Tables/ESTIMATED_MOMENTS

%The model equations, etc, are stored in model_obj
load model_obj


%Load Parameters from parameters.m
[param,set] = parameters;

%Use the median estimated parameters
try
    load estparam
    param = param_est;
    set   = set_est;
catch
    disp('Estimated parameter file not available.  Using default parameters.');
end

%Compute steady-state and implied parameter/set values
[yss,xss,param,set] = model_ss(param,set);

%Turn parameter structures to array. Elements of param are estimated,
%elements of set are fixed.
paramv = struct2array(param);
setv = struct2array(set);

%Compute Model Matrices
[f, fx, fy, fxp, fyp, eta, R]=model_prog(paramv,setv);

if max(abs(f))>1e-10
    disp('Warning: Non-zero steady-state');
    pause
end

%Observable selector matrix
S = zeros(4,size(fy,2));
S(1,dy_idx) = 1;
S(2,pii_idx) = 1;
S(3,r_idx) = 1;
S(4,da_idx) = 1;

disp('OBSERVABLES:');
disp(S*transpose(modl.Y));
disp('Shock SD''s:');
disp(modl.X*modl.shck);

%Solve model from starting parameters
[gx,hx] = gx_hx_alt(fy,fx,fyp,fxp);

%TABLE 1: Data and model
mpref.ndec = 2;
var_names = {'D-Y', 'D-ADV.', 'PI', 'R'};
var_idx = [dy_idx, da_idx, pii_idx, r_idx];
[sig, rho_ar, rho_y,SigY1] = mom_tab(gx, hx, eta*eta', var_idx, var_names, mpref);

%RHOA is special, because the data-side allow us to compute only
%RHOA(t,t-4). This moment is easier to compute via simulation (rather than
%add a bunch of states)
rng('default');
[xsim, ysim, shock] = sim_dat(gx,hx,eta,1001000,1000);
rhoa = corr(ysim(da_idx,5:end)',ysim(da_idx,1:end-4)')
data_side

%More Moments
var_names = {'GDP', 'N', 'A', 'S', 'THET1', 'THET2'};
var_idx = [gdp_idx, n_idx, a_idx, s_idx, thet1_idx, thet2_idx];
mom_tab(gx, hx, eta*eta', var_idx, var_names, mpref);

%Variance Decomposition
vd = vdecom_table(gx,hx,eta,var_idx,var_names);
disp(' ')
diary OFF
