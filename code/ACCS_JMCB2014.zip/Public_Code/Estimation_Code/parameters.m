% PARAMETERS - Returns parameters and setings for model solution and
% estimation.

function [param,set] = parameters()


set.growth = true; %Include annual growth in advertising.

%Fixed parameters related to utility function
set.bet    = 0.9924;  %Discount Rate
set.sigx   = 2.0;     %CRRA coeff for walras goods
set.sigc   = 2.0;     %CRRA coeff for search goods
set.phix   = 0.79;    %CES elastivity for walras goods
set.phic   = 0.79;    %CES elasticity for search goods
set.kapx   = 0.5;     %CES weight on x_2   
set.nu     = 2.0;     %Frisch elasticity
set.veps   = 5.0;     %CES elasticity for final good production

%Fixed parameter related to exogenous policy
set.pistar = 1.0074;   %Average inflation
set.taul   = 0.22;     %Steady-state taxes on labor, consumer side

%Fixed parameter related cobb-douglas mataching
set.xi  = 0.5;       %Cobb-douglas coefficient in matching function
set.kf1 = 0.5;       %finding rate 1, firm side  (Does not affect any allocations in SS or dyanmics)    
set.kf2 = 0.5;       %finding rate 2, firm side  (Does not affect any allocations in SS or dyanmics) 

%Normalization of steady-state hours
set.lbar   = 0.3;     %Steady-state hours

%Fixed shares of output; remaining share is distributed among x goods
set.nshr   = 0.38;
set.adshr1 = 0.01;      %ss adverstising 
set.adshr2 = 0.01;      %ss adverstising 
set.gshr   = 0.20;      %ss share of government


%*************************************************************************
%PARAMETERS ESTIMATED (These were original starting points)
%*************************************************************************
param.varphi  = 24;      %Price stickiness parameters
param.rho     = 0.5;     %One minus exogenous separation in search goods (this way for estimation convenience)
param.kap     = 0.3;     %Coupon rate
param.eta1    = 0.3;     %Nash Bargaining Parameter 1
param.eta2    = 0.3;     %Nash Bargaining Parameter 2
param.sigxc   = 2.0;     %Sigmas

%Exogenous processes, standard deviations
param.sigr = 0.005;
param.sigz = 0.02;
param.sigg = 0.01;
param.sigt = 0.10; 

%Exogenous processes, autocorrelations
param.rhor   = 0.50;
param.rhoz   = 0.95;
param.rhog   = 0.75;
param.rhotl  = 0.75;

%Policy parameters
param.alphpi = 1.5;
param.alphy = 0.225;    


%************************************************************************
%Paramters implied by things calibrated/estimated above
%*************************************************************************
set.zet = NaN;          %Disutility of labor
set.vartheta = NaN;     %Weight on search goods

set.gam1 = NaN;         %Cost of adver 1
set.gam2 = NaN;         %Cost of adver 2

set.psi1 = NaN;         %Matching efficiency 1
set.psi2 = NaN;         %Matching efficiency 2

set.kh1 = NaN;          %finding rate 1, consumer side        
set.kh2 = NaN;          %finding rate 2, consumer side

set.kapc = NaN;         %CES weight on N_2 
set.xshr = NaN;         %share of x goods in output

set.rhox   = NaN;       %Exogenous separation in search goods

set.gbar   = NaN;      %ss level of government
set.rbar   = NaN;
set.ngdp   = NaN;      %Real GDP taking into account p1 and p2

set.nshr1  = NaN;      %share of n1  in output
set.nshr2  = NaN;      %share of n2 in output

set.tauw   = NaN;      %Used to offset steady-state markup

%No measurement error
set.me_eq = [];      

%First order approximation
set.approx_deg = 1;


%bounds on parameters
paraml = param;
paramh = param;
small = 1e-3;
