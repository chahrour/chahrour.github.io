%**********************************************************
% STAGE 4: Analysing Results
%**********************************************************

addpath('Bayesian_Progs')
load estimate_out

ndrop = floor(chaint*.1);  %Drop 10% of observations
nskip = 100;               %Keep 1/100 draws
cds = nan(np,nchain);
cdp = nan(np,nchain);
for j = 1:nchain
    pchain_cell{j} = pchain_cell{j}(:,ndrop+1:nskip:end);
    cds(:,j) = cd_stat(pchain_cell{j});
    cdp(:,j) = 2*normcdf(-abs(cds(:,j)));
end

%Stack results from each chain
pchain = [pchain_cell{:}];

%Mean, Median Stddev
meanp = mean(pchain,2);
medp = median(pchain,2);
stds = std(pchain,[],2);

%Confidence bands
nn = length(pchain);
pchain_ord = sort(pchain,2);
lowp = pchain_ord(:,floor(.05*nn));
highp = pchain_ord(:,ceil(.95*nn));


paramv = paramv(:);
param_ml = param_ml(:);

dispmat = [paramv, param_ml];
for j = 1:nchain
    dispmat = [dispmat, median(pchain_cell{j},2)];
end
dispmat = [dispmat, meanp, medp, lowp, highp, stds, cdp]
f = posterior_figure(pchain,prior_obj,fieldnames(param));

%Save estimation for use in tables, and in next run of main_prog.
save results dispmat pchain medp lowp highp prior_obj;
!cp results.mat ../Figures_and_Tables/results.mat

%Save the fundamental parameters for use in the policy problem
[param,set] = parameters;
param = assign_params(param,medp);
[yss,xss,param_est,set_est] = model_ss(param,set);

load model_obj
ny = length(modl.Y);
x0 = [yss([x2_idx,s2_idx]), xss(n1_idx-ny), xss(n2_idx-ny), yss(l_idx)];

disp('Press enter to replace estparam.mat with new estimates.');
pause
save estparam param_est set_est x0
