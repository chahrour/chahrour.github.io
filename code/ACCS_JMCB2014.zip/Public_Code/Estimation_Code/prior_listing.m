function paramp = prior_listing

%Ordering is {Type, mean, stddev, min, max}
paramp.varphi = {'norm',   14.0,   5.0,  0.5   , 50   };        
paramp.rho 	  = {'beta',   0.5 ,   0.15, 0.01  , 0.99 };        
paramp.kap 	  = {'gaminv', 0.5 ,   0.5,  0.001 , 2.0  };        
paramp.eta1   = {'beta',   0.5 ,   0.1,  0.01  , 0.99 };       
paramp.eta2   = {'beta',   0.5 ,   0.1,  0.01  , 0.99 };        
paramp.sigxc  = {'norm',   2.0 ,   0.3,  0.8   , 8    };      

paramp.sigr  = {'gaminv',   0.05, 0.2, 0.001, 0.2};                     
paramp.sigz  = {'gaminv',   0.05, 0.2, 0.001, 0.2};      
paramp.sigg  = {'gaminv',   0.05, 0.2, 0.001, 0.2};                   
paramp.sigt  = {'gaminv',   0.05, 0.2, 0.001, 0.2};                    

paramp.rhor   = {'beta',   0.5, 0.10, 0.001, 0.999};        
paramp.rhoz   = {'beta',   0.8, 0.05, 0.001, 0.999};         
paramp.rhog   = {'beta',   0.5, 0.10, 0.001, 0.999};         
paramp.rhotl  = {'beta',   0.5, 0.10, 0.001, 0.999};           

paramp.alphpi = {'gam',   2.0 , 0.50, 1.05 ,  5.0 };       
paramp.alphy  = {'gam',   0.1 , 0.05, 0.001,  0.5 };       
