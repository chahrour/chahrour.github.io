%*************************************
% SET UP THE MODEL_PROG.M FILE FOR THE
% MODEL SOLUTION
%*************************************

%Add relevant paths
addpath('Bayesian_Progs')
addpath('ts_box')

%Load Parameters
[param,set] = parameters;

%Generate a mod object
modl = model(param,set);

%Get dimensions of the model
nx = length(modl.X);
ny = length(modl.Y);
neq = nx+ny;

%Generate a matlab function that can compute the derivative matrices
[~,~,lbnd,ubnd,~,~,~,prior_obj] = generate_priors;

%ss_func(modl);
model_func(modl)

load v_idx
save model_obj modl *_idx lbnd ubnd

delete v_idx.mat