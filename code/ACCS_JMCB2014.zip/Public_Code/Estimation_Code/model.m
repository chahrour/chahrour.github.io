% MODEL - Model equations from Arseneau, Chahrour, 
% Chugh, Shapiro, "Optimal Fiscal and Monetary Policy in Customer Markets"
% JMCB, 2014/2015.
%
% usage:
%
% mod = model(param, set)
%
% where
%
% param = a parameters object, created in parmeters.m
% set = a settings object, also created in parameters.m
%
% NOTES: This program, which generates the model matrices in cannonical form,
%        requires the MATLAB symbolic toolbox! The algorithms used to solve 
%        the model, however, are numerical, and require no additonal m-files
%        beyond those that appear in this directory.
 

function [mod] = model(param,set)

%Name of text files
mod.fname = 'model_prog.m';

%Name of file that computes steady-state
mod.ss_call = 'model_ss.m';

%Declare parameters symbols: parameters are values to be estimated
param_list = fieldnames(param);
syms(param_list{1:end});
for j = 1:length(param_list)
    eval(['PARAM(j) = ',param_list{j} ,';']);
end
PARAM

%Declare setting symbols: symbols are values that are "fixed"
set_list = fieldnames(set);
syms(set_list{1:end});
for j = 1:length(set_list)
    eval(['SET(j) = ',set_list{j} ,';']);
end
SET

%Add in aggregate variables

syms X1 X2 P1 P2 KF1 KF2 A1 A2 S1 S2 THET1 THET2 W L R PII RS W GDP A PIM NGDP DY DA AT1 AT2 DA4 N S
syms DPII DR YDT  YDTP   DYP PIIDT  PIIDTP   DPIIP  RDT  RDTP DRP    DAP1 DAP2 DAP3 DAP4 DAP5 DAP6 DAP7 ADT ADTP1 ADTP2 ADTP3 ADTP4 ADTP5 ADTP6 ADTP7
syms N1 N2 TAUL Z MU G X1L N1L P1L P2L TAUW TAUN1 TAUN2 TAUA1 TAUA2 RL EPP GDPL NGDPL DNGDP AL1 AL2 AL3 AL4 AL5 AL6 AL7 AT 
syms PIIL YDTL YDTLL  DYL PIIDTL PIIDTLL  DPIIL  RDTL RDTLL   DRL    DAL1 DAL2 DAL3 DAL4 ADTL1 ADTL2 ADTL3 ADTL4 ADTL5 ADTL6 ADTL7 ADTL8 LL DL PPSI
Y = [P1 P2 X1 X2 PII R L S1 THET1 S2 THET2 W GDP AT1 AT2 A N S];
X = [N1 N2 RL AL1 AL2 AL3 EPP Z G TAUL];

if set.growth
    Y = [Y, DY DA ];
    X = [X, GDPL AL4 AL5 AL6 AL7];
end

YP = make_prime(Y); for j=1:length(YP); eval(['syms ' char(YP(j))]);end
XP = make_prime(X); for j=1:length(XP); eval(['syms ' char(XP(j))]);end

TAUA1 = 0;
TAUA2 = 0;
TAUN1 = 0;
TAUN2 = 0;
TAUW  = tauw;

TAUA1_p = 0;
TAUA2_p = 0;
TAUN1_p = 0;
TAUN2_p = 0;
TAUW_p  = tauw;

[1:length(X);X]
[1:length(Y);Y]


%*******************************
%FUNCTIONAL FORMS
%*******************************
hp = @(x) zet*(x)^(1/nu);
u1  = @(x1,x2) ((1-kapx)*x1^phix + kapx*x2^phix)^((1-sigx-phix)/phix)*(1-kapx)*x1^(phix-1);
u2  = @(x1,x2) ((1-kapx)*x1^phix + kapx*x2^phix)^((1-sigx-phix)/phix)*kapx*x2^(phix-1);
v1  = @(n1,n2) ((1-kapc)*n1^phic + kapc*n2^phic)^((1-sigc-phic)/phic)*(1-kapc)*n1^(phic-1);
v2  = @(n1,n2) ((1-kapc)*n1^phic + kapc*n2^phic)^((1-sigc-phic)/phic)*kapc*n2^(phic-1);
m1 =  @(s1,a1) psi1*s1^xi*a1^(1-xi);
m2 =  @(s2,a2) psi2*s2^xi*a2^(1-xi);
kh1 = @(thet1)  psi1*thet1^(1-xi);
kh2 = @(thet2)  psi2*thet2^(1-xi);
kf1 = @(thet1)  psi1*thet1^-xi;
kf2 = @(thet2)  psi2*thet2^-xi;

%*******************************
%EQ CONDITIONS
%*******************************
f(1) = hp(L+S1+S2)/u2(X1,X2) - (1-TAUL)*W; 

f(end+1) = u1(X1,X2)/u2(X1,X2) - R; 

f(end+1) = u1(X1,X2)/R - bet*u1(X1_p, X2_p)/PII_p; 

%SEARCH CHOICE
f(end+1) = hp(L+S1+S2)/kh1(THET1) - (1/kh1(THET1)-1)*kap*u2(X1,X2) - bet*(1-rhox)*(vartheta*v1(N1_p,N2_p) - P1_p*R_p*(1+TAUN1_p)*u2(X1_p,X2_p) + hp(L_p+S1_p+S2_p)/kh1(THET1_p) - kap*u2(X1_p,X2_p)*(1-kh1(THET1_p))/kh1(THET1_p)); 
f(end+1) = hp(L+S1+S2)/kh2(THET2) - (1/kh2(THET2)-1)*kap*u2(X1,X2) - bet*(1-rhox)*(vartheta*v2(N1_p,N2_p) - P2_p*(1+TAUN2_p)*u2(X1_p,X2_p)     + hp(L_p+S1_p+S2_p)/kh2(THET2_p) - kap*u2(X1_p,X2_p)*(1-kh2(THET2_p))/kh2(THET2_p)); 

%ADVERTISING CHOICE
f(end+1) = (1-TAUA1)*gam1/kf1(THET1)*u2(X1,X2) - bet*(1-rhox)*u2(X1_p,X2_p)*AT1_p; 
f(end+1) = (1-TAUA2)*gam2/kf2(THET2)*u2(X1,X2) - bet*(1-rhox)*u2(X1_p,X2_p)*AT2_p; 

%ADV. ENVELOPE CONDITION
f(end+1) = AT1 - P1 +1 - gam1*(1-TAUA1)/kf1(THET1);
f(end+1) = AT2 - P2 +1 - gam2*(1-TAUA2)/kf2(THET2);

%NEW PRICING EQ
f(end+1) = u2(X1,X2)*(R*(1+TAUN1)*(AT1*eta1/(1-eta1) + P1) - (vartheta*v1(N1,N2)/u2(X1,X2)-kap)) - (1-rhox)*bet*u2(X1_p, X2_p)*R_p*(1+TAUN1_p)*eta1/(1-eta1)*AT1_p;
f(end+1) = u2(X1,X2)*((1+TAUN2)*(AT2*eta2/(1-eta2) + P2) - (vartheta*v2(N1,N2)/u2(X1,X2)-kap))   - (1-rhox)*bet*u2(X1_p, X2_p)*(1+TAUN2_p)*eta2/(1-eta2)*AT2_p;

%EVOLUTION OF MATCHES
f(end+1) = N1_p - (1-rhox)*(N1 + m1(S1,THET1*S1)); 
f(end+1) = N2_p - (1-rhox)*(N2 + m2(S2,THET2*S2)); 


%NKPC
f(end+1) = ((1-veps + veps*(1-TAUW)*W/Z)*(Z*L) - varphi*(PII-pistar)*PII)*u2(X1,X2) + bet*u2(X1_p,X2_p)*varphi*(PII_p-pistar)*PII_p; 
 
%RC
f(end+1) = X1+X2+N1+N2+G+gam1*THET1*S1+gam2*THET2*S2+varphi/2*(PII-pistar)^2-Z*L; 

%Definitions
f(end+1) = (gam2*THET2*S2 + gam1*THET1*S1) - A; 
f(end+1) = GDP - Z*L;%(X1 + X2 + P1*N1 + P2*N2 + G + (gam2*THET2*S2 + gam1*THET1*S1)); 


%*******************************
% LINKING EQUATIONS
%*******************************
f(end+1) = AL1_p - A;      
f(end+1) = AL2_p - AL1;    
f(end+1) = AL3_p - AL2;  

if set.growth
    
    %*****************************************
    % MEASUREMENT EQUATIONS FOR GROWTH RATES
    %****************************************
    f(end+1) = GDPL_p - GDP;   
    f(end+1) = DY - GDP/GDPL;  

    f(end+1) = AL4_p - AL3;  
    f(end+1) = AL5_p - AL4;  
    f(end+1) = AL6_p - AL5;  
    f(end+1) = AL7_p - AL6; 
    f(end+1) = DA - (A + AL1 + AL2 + AL3)/(AL4 + AL5 + AL6 + AL7); 

end

%*******************************
% EXOGENOUS PROCESSES (including measurement trend)
%*******************************
f(end+1) = log(TAUL_p/taul) - rhotl*log(TAUL/taul); 
f(end+1) = log(Z_p) - rhoz*log(Z); 
f(end+1) = log(G_p/gbar) - rhog*log(G/gbar);   

%*******************************
% TAYLOR RULE
%*******************************
f(end+1) = log(R/rbar) - rhor*log(RL/rbar) - (1-rhor)*(alphpi*log(PII/pistar) + alphy*log(GDP/ngdp)) - log(EPP); 

f(end+1) = RL_p - R; 
f(end+1) = log(EPP_p); 

f(end+1) = N - N1 - N2;
f(end+1) = S - S1 - S2;




transpose(f)


%*****************************************
%EXTRA EQUATIONS TO DETERMINE NUMERICAL SS
%*****************************************
disp(['Number of equations: ' num2str(length(f))])
disp(['Number of variables: ' num2str(length(X) + length(Y))])



%Log-linear approx
xlog = 1:length(X);
ylog = 1:length(Y);
log_var = [X(xlog) Y(ylog) XP(xlog) YP(ylog)];

mod.f = subs(f, log_var, exp(log_var));
mod.X = X;
mod.XP = XP;
mod.Y = Y;
mod.YP = YP;
mod.xlog = xlog;
mod.ylog = ylog;
mod.PARAM = PARAM;
mod.param = param;
mod.SET = SET;
mod.set = set;
mod.adiff = false; %Include anaylytical derivatives?

%Standard Errors
neps = 4;

mod.shck = sym(zeros(length(X),neps));
mod.shck(7:7+neps-1,1:neps) = diag([sigr, sigz, sigg, sigt]);

mod.shck

%Measurement Error
mod.me = sym(zeros(length(Y)));
for j = 1:length(set.me_eq)
    eval(['mod.me(set.me_eq(j),set.me_eq(j)) = sig_ME' num2str(set.me_eq(j))  ';']);
end

%Derivatives using numerical toolbox
mod = anal_deriv(mod);


%Loop creates indexes to track variables (for figures, etc)
ny = length(mod.Y);
nx = length(mod.X);
for j=1:ny; 
    vn = char(Y(j));
    eval([lower(vn), '_idx = j;'])
end
for j=1:nx; 
    vn = char(X(j));
    eval([lower(vn), '_idx = ny+j;'])
end

%Save index variables for use in main_prog
save v_idx *_idx
