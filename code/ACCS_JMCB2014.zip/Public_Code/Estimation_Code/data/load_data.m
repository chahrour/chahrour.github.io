%LOAD_DATA: Imports the data for the model estimation, and saves in parent
%directory for estimation. Data from FRED downloaded on November 3, 2013.

%Monthly Series
[mdat,nms] = xlsread('FRED_data_Nov3_2013.xlsx', 'Monthly');
emp = ts_make(mdat(:,2),12,193401);      %Employment
pop = ts_make(mdat(:,3),12,193401);      %Population
tb3 = ts_make(mdat(:,5)/400,12,193401);  %3-mo tbill

%Quarterly Series
[qdat,nms] = xlsread('FRED_data_Nov3_2013.xlsx', 'Quarterly');
rgdp = ts_make(qdat(:,2),4,194701);    %Real GDP
def96 = ts_make(qdat(:,3),4,194701);   %GDP defl

%Adverstising from Hall (2013) spreadsheet
[hdat,~] = xlsread('Calcs.xlsx', 'Data');
adv = ts_make(hdat(5:end-1,5),1,195001);  %Nominal adversting exp

%Dates for quearterly data
ts_sd1 = 196004;
ts_ed1 = 201004;

%Series 1: Log change of real per capita gdp, demeaned
popq = M2Q(pop);
rgdp_pc = ts_div(rgdp,popq);
l_rgdp_pc = rgdp_pc; l_rgdp_pc.dat = log(l_rgdp_pc.dat);
dl_rgdp_pc = ts_diff(l_rgdp_pc);
ser1 = demean(vect(dl_rgdp_pc,0,[ts_sd1, ts_ed1]));

%Series 2: Log change of the price level, linear detrended
ldef96 = def96; ldef96.dat = log(def96.dat);
pi = ts_diff(ldef96);
ser2 = detrend(vect(pi,0,[ts_sd1,ts_ed1]));

%Series 3: 3-mo tbill rate
tb3q = M2Q(tb3);
ser3 = detrend(vect(tb3q, 0, [ts_sd1,ts_ed1]));

%Series 4: Annual growth rate of real per-captita adverstising
popa = Q2A(ts_make(vect(popq,0,[195001,201004]),4,195001));
defa = Q2A(ts_make(vect(def96,0,[195001,201004]),4,195001));
l_radv_pc = adv; l_radv_pc.dat = log(adv.dat./(popa.dat.*defa.dat));
dl_radv_pc = ts_diff(l_radv_pc);

ts_sd2 = 196001;
ts_ed2 = 201001;
ser4 = demean(vect(dl_radv_pc,0,[ts_sd2,ts_ed2]));

%Insert annual adversting every four quarters
dat_reg = [ser1';ser2';ser3'];
dat_reg(4,:) = NaN;
dat_reg(4,1:4:end) = ser4';

%Save data
save ../main_data dat_reg

