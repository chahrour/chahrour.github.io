
%*************************
% Data in rates of growth
%*************************

load main_data dat_reg


%Assign variables to each col
y = dat_reg(1,:);
pi = dat_reg(2,:);
r = dat_reg(3,:);
add = dat_reg(4,:);



%Changes
stddev_row = 100*[std([y'  pi' r']), std(add(1:4:end)')];
tmp = corr(y(1:4:end)', add(1:4:end)');
corr_row = [corr([y', pi',r'], y')', corr(y(1:4:end)', add(1:4:end)')];
dat = [y', pi', r'];

auto_add = corr(add(1:4:end-1)', add(5:4:end)');
auto_row = [diag(corr(dat(2:end,:), dat(1:end-1,:)))' auto_add];



stddev_row([1,4,2,3])
auto_row([1,4,2,3])
corr_row([1,4,2,3])