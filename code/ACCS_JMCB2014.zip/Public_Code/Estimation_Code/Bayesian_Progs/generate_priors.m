function [paramv,setv,lb,ub,mb,sdp,paramp,prior_obj] = generate_priors

%parmeters from parameters.m
[param,set] = parameters;
paramv = struct2array(param);
setv = struct2array(set);
np = length(paramv);
pnm = fieldnames(param);
lb = zeros(1,np);
ub = zeros(1,np);
mb = zeros(1,np);

prior_obj = cell(np,1);
%Priors from prior_listing.m
paramp = prior_listing;
parampc = struct2cell(paramp);
lnm  = fieldnames(paramp);


%Create file
f = fopen('priors_auto.m', 'w');
str = ['function out = priors_auto(param)']; fprintf(f, '%s\n', str); fprintf(f, '%s\n', '');

%Compute sum
str = 'out = ';
for j = 1:np
   idx = strcmp(pnm{j},lnm);
   
   dist = parampc{idx}{1};
   mu   = parampc{idx}{2};
   sd   = parampc{idx}{3};

   sdp(j) = sd;
   mb(j) = mu;
   lb(j) = parampc{idx}{4};
   ub(j) = parampc{idx}{5};
  
   if ~strcmp(dist, 'flat')
       [shape, scale] = eval([dist, '_params(mu,sd)']);
       str_tmp = ['log(' dist 'pdf2(param(' num2str(j) '),' num2str(shape) ',' num2str(scale), '))+'];
       str = [str,str_tmp];
   end
   
   %Create object for future plotting
   tmp.xgrid = linspace(lb(j),ub(j),100);
   
   if ~strcmp(dist, 'flat')
       tmp.ygrid = eval([dist, 'pdf2(tmp.xgrid,' num2str(shape) ', ' num2str(scale), ')']);
   else
       tmp.ygrid = 0*tmp.xgrid;
   end
   prior_obj{j} = tmp;
   
   

    
end
str = [str(1:end-1),';'];
fprintf(f, '%s\n', str);
fclose(f);


