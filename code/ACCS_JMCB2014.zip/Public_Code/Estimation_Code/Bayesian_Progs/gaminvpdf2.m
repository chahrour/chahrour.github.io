function out = gaminvpdf(x,shape,scale)

a= shape;
b = scale;

out = b^a/gamma(a).*(1./x).^(a+1).*exp(-b./x);
