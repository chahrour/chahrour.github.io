function out = liklhd(param,set,S,data,ndrop)

%Get the numerical values of the first order canonical represnetation
[f, fxn, fyn, fxpn, fypn, eta, R]=model_prog(param,set);

%Use MEX code to speed computation; compiled on mac OSX
%[gx,hx,flg] = gx_hx_mex3(fyn,fxn,fypn,fxpn);
[gx,hx,flg] = gx_hx_alt(fyn,fxn,fypn,fxpn);


%Compute liklihood, tossing cases that are non-unique or have no solution
if flg~=1 
    out = -100000;
elseif sum(abs(f)) > 1e-8
    out = -100000;
else
    %Use MEX code to speed computation; compiled on mac OSX
    %out = kalman_gh_mobs_mex3(S*gx,hx,eta,S*R*S',data,ndrop)  + priors_auto(param);
    out = kalman_gh_mobs(S*gx,hx,eta,S*R*S',data,ndrop)  + priors_auto(param);
end


if isnan(out)
    disp('Warning: NaN case.');
    out = -100000;
end

