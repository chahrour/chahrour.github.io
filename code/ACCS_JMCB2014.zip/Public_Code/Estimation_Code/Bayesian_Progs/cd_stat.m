%CD_STAT - Compute the CD statistic for each element of the param vector
%
%I will drop one quarter of the chain. And then use quarters 2 and 4 for
%the test.

function out = cd_stat(pchain)
nparam = size(pchain,1);
n = floor(length(pchain)/3);



p1 = pchain(:,1:n);
p3 = pchain(:,2*n+1:3*n);

    
m1bar = mean(p1,2);
m3bar = mean(p3,2);

se1 = se_est(p1);
se3 = se_est(p3);
     
out = (m1bar-m3bar)./(se1+se3);



