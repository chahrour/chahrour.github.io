function [param1,p1,accept,bndreject,bndlow,bndhigh] = mcmc(param0,set,S,Y,p0,step,lbnd,ubnd,ndrop)
accept = 0;
bndreject = 0;
nparam = length(param0);


%Step 1: Draw a new set of parameters from uniform distribution
%fstep = 2*(rand(nparam,1)-.5); %Point from -1 to 1 of step size.
fstep = randn(nparam,1);       %Randn stddev 1
paramp = param0+fstep.*step;   %New set of parameters.

% load paramp
%  [param0, paramp]
% lbnd
% ubnd
%Step 2: Compute liklihood at new set of parameters, and compare
bndlow = paramp<lbnd;
bndhigh= paramp>ubnd; 
if sum(bndlow) + sum(bndhigh)
    b = 0;  %Reject if outside of bnds (aka priors)
    param1 = param0;
    p1 = p0;
    bndreject = 1;
    return
else
    pp = liklhd(paramp,set,S,Y,ndrop);
    
    %save paramp paramp
    b = exp(pp-p0);  %Ratio of liklihoods
end
% pause

%Step 3: Choose to accept or reject
if b >= 1 %Accept for sure
    param1 = paramp;
    p1 = pp;
    accept = 1;
elseif rand(1,1)<=b; %Accept w/p b;
    param1 = paramp;
    p1 = pp;
    accept=1;
else
    param1 = param0;
    p1 = p0;
end
