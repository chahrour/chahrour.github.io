load results

%Rho is really 1 - rhox
pchain(2,:) = 1 - pchain(2,:);

nchain = 12;

nn = length(pchain);
medp = median(pchain,2);
pchain_ord = sort(pchain,2);
lowp = pchain_ord(:,floor(.05*nn));
highp = pchain_ord(:,ceil(.95*nn));

horiz = {'blank', '5\%', 'Median',  '95\%'};

vert = {'$\varphi$', '$\rho$', '$\kappa$', '$\eta_1$', '$\eta_2$', '$\sigma_x = \sigma_c$', '$\sigma_r$', '$\sigma_z$', '$\sigma_g$', '$\sigma_\tau$', '$\rho_r$','$\rho_z$','$\rho_g$','$\rho_\tau$', '$\alpha_\pi$', '$\alpha_y$'};

dat = [lowp, medp,highp];

table1 = ltable(dat,horiz,vert', 'Estimated Parameters', 'table_format_file', 'params_table');

make_file('params_table', 'file_format', 'params_table');

save medp medp