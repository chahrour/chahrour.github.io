addpath(genpath('latex'))

estimate_table
fancy_posterior_figure
make_alloc_figure
make_search_figure
make_tax_figure
make_wedge_figure
