file_list = {'RAMSEY_CMPT_FLEX','RAMSEY_CMPT_STKY','RAMSEY_LMTD_STKY', 'RAMSEY_LMTD_STKY_NOSEARCH' };
nt = 20;

dat_g = zeros(nt,3,length(file_list));
dat_z = zeros(nt,3,length(file_list));

for ll = 1:length(file_list)
    eval(['load ' file_list{ll} ' *idx irg irz']);
    var_idx = [r_idx,taul_idx,pii_idx];
    dat_g(:,:,ll) = irg(1:nt,var_idx);
    dat_z(:,:,ll) = irz(1:nt,var_idx);
end


var_names = {'$R$', '$\tau^l$', '$\pi$'};
legend = {'Ramsey Flex', 'Ramsey Sticky (Baseline)', 'Ramsey Incomplete', 'Ramsey Incomp. No-search'};
f1 = ir_figure(100*dat_z,var_names, [], {'-ks', 'r-.o', 'g--d','c-p'},legend);
figure(f1);
 s= subplot(2,2,3);
 clear set
 set(s,'ylim', [-.001, .0013]);


f2 = ir_figure(100*dat_g,var_names, [], {'-ks', 'r-.o', 'g--d','c-p'},legend);
figure(f2);
 s= subplot(2,2,3);
 clear set
 set(s,'ylim', [-.001, .0013]);


saveas(f1, 'TaxFigureZ.pdf', 'pdf');
saveas(f2, 'TaxFigureG.pdf', 'pdf');