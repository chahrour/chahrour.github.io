file_list = {'RAMSEY_CMPT_FLEX','RAMSEY_CMPT_STKY','RAMSEY_LMTD_STKY', 'COMPETITIVE_STKY' };

nt = 20;

dat_g = zeros(nt,6,length(file_list));
dat_z = zeros(nt,6,length(file_list));

for ll = 1:length(file_list)
    eval(['load ' file_list{ll} ' *idx irg irz']);
    var_idx = [wdg1_idx,wdg2_idx,wdg3_idx,wdg4_idx,wdg5_idx,pii_idx];
    dat_g(:,:,ll) = irg(1:nt,var_idx);
    dat_z(:,:,ll) = irz(1:nt,var_idx);
end


var_names = {'$x_2/l$ wedge', '$x_2/s_1$ wedge', '$x_2/s_2$ wedge', '$x_2/n_1$ wedge', '$x_2/n_2$ wedge', '$\pi$'};
legend = {'Ramsey Flex', 'Ramsey Sticky (Baseline)', 'Ramsey Incomplete', 'Exogenous'};
f1 = ir_figure(100*dat_z,var_names, [], {'-ks', 'r-.o', 'g--d','b->'},legend);
figure(f1);
 s= subplot(3,2,6);
 clear set
 set(s,'ylim', [-.001, .0013]);


f2 = ir_figure(100*dat_g,var_names, [], {'-ks', 'r-.o', 'g--d','b->'},legend);
figure(f2);
 s= subplot(3,2,6);
 clear set
 set(s,'ylim', [-.001, .0013]);


saveas(f1, 'WedgeFigureZ.pdf', 'pdf');
saveas(f2, 'WedgeFigureG.pdf', 'pdf');