% This simple program creates a file in which to embed your latex
% graphics objects.  Enter 'def' to use default format file
% Usage:
% file = make_file (filename, format_file, table1, table 2, ...)

function file = make_file(name, varargin)

%Default not landscape
lscape = 0;
if strcmp (varargin{1},'def') || isempty(varargin{1})
    format = fopen ([home_dir, 'ryan_lib/latex/file_format'], 'r');
else
    try
        format = fopen (varargin{1}, 'r');
    catch
        error('Invalid format_file name.');
    end
end
%format;
file = fopen ([name,'.tex'], 'w');

fprintf(file,'%s\n','\documentclass{article}','');

%Include packages
pack = next_arg(format);
while ~strcmp(pack,'last package')
    fprintf(file, '%s\n', ['\usepackage{',pack,'}'], '');
    pack = next_arg(format);
end

%Set margins
fprintf(file,  '%s\n', ['\oddsidemargin  =',next_arg(format)]);   %Left Margin
fprintf(file,  '%s\n', ['\evensidemargin  =',next_arg(format)]);   %RightMargin
fprintf(file,  '%s\n', ['\topmargin  =',next_arg(format)]); %Top Margin
%     fprint(file,  '%s\n', ['\oddsidemargin  =',next_arg(format)]);   %Left Margin
%     fprint(file,  '%s\n', ['\oddsidemargin  =',next_arg(format)]);   %Left Margin
%

fprintf(file,'%s\n','\begin{document}','','','');

if strcmp(next_arg(format), 'yes')
    lscape = 1;
    fprintf(file,'%s\n','\begin{landscape}','','','');
end
%Insert figure
for j = 2:size(varargin,2)
    fprintf(file, '%s\n', ['%Table ', num2str(j-1)], ['\input{',varargin{j}, '.text}'],'','');
end
if lscape == 1
    fprintf(file,'%s\n','\end{landscape}','','','');
end
%End document
fprintf(file,'%s\n', '\end{document}');
end
