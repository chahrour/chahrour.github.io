%NEXT_TOK - Returns the next token in a file.


function [tok, remains] = next_tok(input)
   
    tok = [];
    if strcmp (input(1), '{')
        i = 2;
        while ~strcmp(input(i),'}')
            tok = [tok input(i)];
            i = i+1;
        end
        remains = input(i+2:end);
    else
       [tok, remains]= strtok(input);
       remains = remains(2:end);
    end
end
