function f = posterior_figure(pchain,prior,param_list,varargin)
nparam = size(pchain,1);
nrow = ceil(sqrt(nparam));
ncol = ceil(nparam/nrow);
f = figure;
set(f, 'paperposition', [.25 .25 10.5 8], 'paperorientation', 'landscape');
for j = 1:nparam
    lbnd = min(prior{j}.xgrid);
    ubnd = max(prior{j}.xgrid);
    [~, dens,xmesh] = kde(pchain(j,:)',1.5^10,lbnd,ubnd);
    s = subplot(nrow,ncol,j);  hold on
    plot(prior{j}.xgrid, prior{j}.ygrid, '--', 'linewidth', 2);
    plot(xmesh,dens, 'linewidth', 2', 'color', 'r');
    
    %Plot vert lines
    if nargin>3
        ylim = get(s, 'ylim');
        plot([varargin{1}(j), varargin{1}(j)], [ylim(1), ylim(2)], 'color', 'k', 'linestyle', '--');
        set(s, 'ylim', [ylim(1), ylim(2)]);
    end
    set(s, 'xlim', [lbnd,ubnd], 'ytick', [], 'yticklabel', []);
    
    
    
    title(param_list{j}, 'interpreter', 'latex', 'fontsize', 14);
end

legend('Prior', 'Posterior', 'location', 'NorthEast')