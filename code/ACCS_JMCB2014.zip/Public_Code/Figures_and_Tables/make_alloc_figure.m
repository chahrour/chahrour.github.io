file_list = {'RAMSEY_CMPT_FLEX','RAMSEY_CMPT_STKY','RAMSEY_LMTD_STKY', 'COMPETITIVE_STKY' };

nt = 20;

dat_g = zeros(nt,5,length(file_list));
dat_z = zeros(nt,5,length(file_list));

for ll = 1:length(file_list)
    eval(['load ' file_list{ll} ' *idx irg irz']);
    var_idx = [x1_idx,x2_idx,n1_idx,n2_idx,gdp_idx];
    dat_g(:,:,ll) = irg(1:nt,var_idx);
    dat_z(:,:,ll) = irz(1:nt,var_idx);
end


var_names = {'$x_1$', '$x_2$', '$N_1$', '$N_2$', 'GDP'};
legend = {'Ramsey Flex', 'Ramsey Sticky (Baseline)', 'Ramsey Incomplete', 'Exogenous'};
f1 = ir_figure(100*dat_z,var_names, [], {'-ks', 'r-.o', 'g--d','b->'},legend, 'Southeastoutside');
figure(f1);

f2 = ir_figure(100*dat_g,var_names, [], {'-ks', 'r-.o', 'g--d','b->'},legend, 'Southeastoutside');
figure(f2);


saveas(f1, 'AllocFigureZ.pdf', 'pdf');
saveas(f2, 'AllocFigureG.pdf', 'pdf');