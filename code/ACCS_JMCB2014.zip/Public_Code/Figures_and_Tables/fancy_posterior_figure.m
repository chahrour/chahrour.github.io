
load results
names = {'$\varphi$', '$\rho$', '$\kappa$', '$\eta_1$', '$\eta_2$', '$\sigma_c = \sigma_x$', '$\sigma_r$', '$\sigma_z$', '$\sigma_g$', '$\sigma_t$', '$\rho_r$', '$\rho_z$', '$\rho_g$', '$\rho_{\tau^l}$','$\alpha_\pi$', '$\alpha_y$'};

%Rho is really 1-rhox

pchain(2,1:end) = 1 - pchain(2,1:end);
prior_obj{2}.xgrid = 1 - prior_obj{2}.xgrid;

f = posterior_figure(pchain,prior_obj,names,medp);

saveas(f, 'Posterior.pdf', 'pdf');