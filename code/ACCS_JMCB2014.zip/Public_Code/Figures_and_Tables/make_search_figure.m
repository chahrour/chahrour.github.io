file_list = {'RAMSEY_CMPT_FLEX','RAMSEY_CMPT_STKY','RAMSEY_LMTD_STKY', 'COMPETITIVE_STKY' };

nt = 20;

dat_g = zeros(nt,6,length(file_list));
dat_z = zeros(nt,6,length(file_list));

for ll = 1:length(file_list)
    eval(['load ' file_list{ll} ' *idx irg irz']);
    var_idx = [a1_idx,a2_idx,s1_idx,s2_idx,thet1_idx,thet2_idx];
    dat_g(:,:,ll) = irg(1:nt,var_idx);
    dat_z(:,:,ll) = irz(1:nt,var_idx);
end


var_names = {'$a_1$', '$a_2$', '$s_1$', '$s_2$', '$\theta_1$', '$\theta_2$'};
legend = {'Ramsey Flex', 'Ramsey Sticky (Baseline)', 'Ramsey Incomplete', 'Exogenous'};
f1 = ir_figure(100*dat_z,var_names, [], {'-ks', 'r-.o', 'g--d','b->'},legend);
f2 = ir_figure(100*dat_g,var_names, [], {'-ks', 'r-.o', 'g--d','b->'},legend);



saveas(f1, 'AdvFigureZ.pdf', 'pdf');
saveas(f2, 'AdvFigureG.pdf', 'pdf');