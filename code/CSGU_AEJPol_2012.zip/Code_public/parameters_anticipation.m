% PARAMETERS: Returns a parameter structure to use in the model solution. 
% This version includes anticipated shocks
%
% usage:
% 
% param = parameters_anticipation
%

function param = parameters_anticipation()

%Calibrated Parameters (following MR)
param.alph =.36;
param.gam_z = 1.005;
param.delta_k = .025;
param.delta_v = .025;
param.delta_tau = .05;
param.n_bar = .25;
param.u_bar = 1;
param.dshare = .119;
param.tau_k = .42;
param.tau_n = .26;
param.gbar = .201;
param.A_bar = 1;

%Estimated by MR
param.sig = 3.762;
param.b = .880;
param.kappa = .976;  %AKA kappa
param.phi_kk = 8.488;
param.phi_vv = 7.795;
param.psi_pp_p = .619; 
param.bet = 1.03^-.25/(param.gam_z^(1-param.sig));

%AR Coeffs
param.rho1n = 1.483;
param.rho2n = -.484;
param.rho1k = 1.707;
param.rho2k = -.729;

%Parameters Determined in SS
param.rhog = .9;
param.rhoa = .95;
param.rhomu = .9;
param.pi_g = 0;     %Feedback of government expenditure; we assume = 0 always

%Calibrated Surprise Shock Variances
param.sigT = .0055/4;
param.sigA = .02/4;
param.sigMU = .0924/4;
param.sigG = .1095/4;

param.sigT_ant = .0055/4;
param.sigA_ant = .02/4;
param.sigMU_ant = .0924/4;
param.sigG_ant = .1095/4;

%Values determined in SS
param.psi_p = -999; 
param.psi_pp = -999;
param.mu_bar = -999;  
param.nu = -999;   
param.ybar = -999;
param.tbar = -999;

