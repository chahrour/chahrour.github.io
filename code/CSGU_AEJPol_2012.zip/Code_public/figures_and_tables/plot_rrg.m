%Figure 3: plot the Romer-Romer (growth version) average impulse responses.

clear

load figures_data_250.mat

ir_rrg =mean_rrg(:,:,1);

f = figure;
j = 1; %taxes
subplot(2,2,1)
h=plot(ir_mod(:,j,1),'b-');
set(h,'linewidth', 3)

hold on
h=plot(ir_rrg(:,j),'r--');
set(h,'linewidth', 3)


legend('DSGE','RR-G')
plot( ir_mod(:,j,1)*0 )


xlim([1 20])
xlabel('quarters')
ylabel('% deviations from ss output')
title('Tax Revenue')

set(gca,'XTick',[1:2:19])


j = 3; %output
subplot(2,2,2)
h=plot(ir_mod(:,j,1),'b-');
set(h,'linewidth', 3)

hold on

h=plot( ir_rrg(:,j),'r--');
set(h,'linewidth', 3)

legend('DSGE','RR-G')
plot(ir_mod(:,j,1)*0)

q_min = find(ir_mod(:,j,1)==min(ir_mod(:,j,1)));
plot([1 20],[1 1]*ir_mod(q_min,j),':' )

h=plot(q_min, ir_mod(q_min,j,1),'b.');
set(h,'markersize', 20)

rrg_min = find(ir_rrg(:,j)==min(ir_rrg(:,j)));
h=plot(rrg_min, ir_rrg(rrg_min,j),'r.');
set(h,'markersize', 20)


set(gca,'YTick',[-2 round(100*ir_mod(q_min,j,1))/100  -1.5 -1 -.5 0])
set(gca,'XTick',[1:2:19])

xlim([1 20])
xlabel('quarters')
ylabel('% deviations from steady state')
title('Output')
hold off

saveas(f, 'figure3.pdf', 'pdf')
