plot_bp               %Figure 1
plot_rr               %Figure 2
plot_rrg              %Figure 3    
plot_news             %Figure 4   
impulse_response_tau  %Figure 5
plot_fg               %Figure 6
small_sample_uncertainty %Table 2


