%Figure 2: plot the average Romer-Romer responses

clear 
load figures_data_250.mat  %1000 replications

% The dimensions of the 4D array  ir_rr are:
%[time from shock:1:20       variable(T G Y)     Replication(1:1000)     Model(No News, News, Gov Feedback) ]

%Pick only data from the no-news model
mir_rr = mean_rr(:,:,1);

f = figure;
j = 1; %taxes
subplot(2,2,1)
h=plot(ir_mod(:,j,1),'b-');
set(h,'linewidth', 3)

hold on
h=plot(mir_rr(:,j),'r--');
set(h,'linewidth', 3)


legend('DSGE','RR')
plot( ir_mod(:,j,1)*0 );


xlim([1 20])
xlabel('quarters')
ylabel('% deviations from ss output')
title('Tax Revenue')

set(gca,'XTick',[1:2:19])


j = 3; %output
subplot(2,2,2)
h=plot(ir_mod(:,j,1),'b-');
set(h,'linewidth', 3)

hold on

h=plot( mir_rr(:,j),'r--');
set(h,'linewidth', 3)

legend('DSGE','RR')
plot(ir_mod(:,j,1)*0)

q_min = find(ir_mod(:,j,1)==min(ir_mod(:,j,1)));
plot([1 20],[1 1]*ir_mod(q_min,j),':' )

h=plot(q_min, ir_mod(q_min,j,1),'b.');
set(h,'markersize', 20)

rr_min = find(mir_rr(:,j)==min(mir_rr(:,j)));
h=plot(rr_min, mir_rr(rr_min,j),'r.');
set(h,'markersize', 20)


set(gca,'YTick',[-2 round(100*ir_mod(q_min,j,1))/100  -1.5 -1 -.5 0]);
set(gca,'XTick',[1:2:19]);

xlim([1 20])
xlabel('quarters')
ylabel('% deviations from steady state')
title('Output')
hold off
saveas(f,'figure2.pdf', 'pdf');
