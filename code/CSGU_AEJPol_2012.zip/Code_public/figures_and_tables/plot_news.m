%Figure 4: plot the BP and RR responses for the news (anticipation) version
%of the model.

clear


f = figure;

load figures_data_250.mat

j = 1; %taxes
subplot(2,2,1)
h=plot(ir_mod(:,j,1),'b-');
set(h,'linewidth', 3)
hold on

h=plot(mean_bp(:,j,2),'r--');
set(h,'linewidth', 3)

legend('DSGE','BP')
plot( ir_mod(:,j,1)*0 ,'w')


xlim([1 20])
xlabel('quarters')
ylabel('% deviations from ss output')
title('Tax Revenue')

set(gca,'XTick',[1:2:19])


j = 3; %output
subplot(2,2,2)
h=plot(ir_mod(:,j,1),'b-');
set(h,'linewidth', 3)

hold on

h=plot( mean_bp(:,j,2),'r--');
set(h,'linewidth', 3)

legend('DSGE','BP')
plot(ir_mod(:,j,1)*0,'w')

q_min = find(ir_mod(:,j,1)==min(ir_mod(:,j,1)));
plot([1 20],[1 1]*ir_mod(q_min,j),'w:' )

h=plot(q_min, ir_mod(q_min,j,1),'b.');
set(h,'markersize', 20)

bp_min = find(mean_bp(:,j,2)==min(mean_bp(:,j,2)));
h=plot(bp_min, mean_bp(bp_min,j,2),'r.');
set(h,'markersize', 20)


set(gca,'YTick',[-2 round(100*ir_mod(q_min,j,1))/100  -1.5 -1 -.5 0])
set(gca,'XTick',[1:2:19])

xlim([1 20])
xlabel('quarters')
ylabel('% deviations from steady state')
title('Output')
hold off
shg


j = 1; %taxes
subplot(2,2,3)
h=plot(ir_mod(:,j,1),'b-');
set(h,'linewidth', 3)
hold on

h=plot(mean_rr(:,j,2),'r--');
set(h,'linewidth', 3)

legend('DSGE','RR')
plot( ir_mod(:,j,1)*0,'w' )


xlim([1 20])
xlabel('quarters')
ylabel('% deviations from ss output')
title('Tax Revenue')

set(gca,'XTick',[1:2:19])


j = 3; %output
subplot(2,2,4)
h=plot(ir_mod(:,j,1),'b-');
set(h,'linewidth', 3)

hold on

h=plot( mean_rr(:,j,2),'r--');
set(h,'linewidth', 3)

legend('DSGE','RR')
plot(ir_mod(:,j,1)*0,'w')

q_min = find(ir_mod(:,j,1)==min(ir_mod(:,j,1)));
plot([1 20],[1 1]*ir_mod(q_min,j),'w:' )

h=plot(q_min, ir_mod(q_min,j,1),'b.');
set(h,'markersize', 20)

bp_min = find(mean_rr(:,j,2)==min(mean_rr(:,j,2)));
h=plot(bp_min, mean_rr(bp_min,j,2),'r.');
set(h,'markersize', 20)


set(gca,'YTick',[-2 round(100*ir_mod(q_min,j,1))/100  -1.5 -1 -.5 0])
set(gca,'XTick',[1:2:19])

xlim([1 20])
xlabel('quarters')
ylabel('% deviations from steady state')
title('Output')
hold off
saveas(f, 'figure4.pdf', 'pdf');
