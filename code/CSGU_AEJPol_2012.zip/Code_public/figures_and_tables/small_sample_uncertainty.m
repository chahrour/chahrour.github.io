%Table 2: Generates the data for table 2, which compares the small sample 
%performance of the estimators for different sample lengths. Requires 
%generation two version of the figures_data.mat file. One with 250 period 
%simulations, and one with 1000 period simulations. 


clear all

%Sample size = 250 quarters
load figures_data_250.mat

rr10 = -ir_rr(10,3,:,1);
rr11 = -ir_rr(11,3,:,1);
rr12 = -ir_rr(12,3,:,1);

bp10 = -ir_bp(10,3,:,1);
bp11 = -ir_bp(11,3,:,1);
bp12 = -ir_bp(12,3,:,1);



mean_bp10   = mean(bp10);
std_bp10    = std(bp10);
median_bp10 = median(bp10);

mean_bp11   = mean(bp11);
std_bp11    = std(bp11);
median_bp11 = median(bp11);


mean_bp12   = mean(bp12);
std_bp12    = std(bp12);
median_bp12 = median(bp12);


mean_rr10   = mean(rr10);
std_rr10    = std(rr10);
median_rr10 = median(rr10);

mean_rr11   = mean(rr11);
std_rr11    = std(rr11);
median_rr11 = median(rr11);


mean_rr12   = mean(rr12);
std_rr12    = std(rr12);
median_rr12 = median(rr12);


table250 = [mean_bp10 median_bp10 std_bp10 mean_rr10 median_rr10 std_rr10 mean(rr10-bp10>0)*100 mean(rr10-bp10>2)*100
mean_bp11 median_bp11 std_bp11 mean_rr11 median_rr11 std_rr11 mean(rr11-bp11>0)*100 mean(rr11-bp11>2)*100
mean_bp12 median_bp12 std_bp12 mean_rr12 median_rr12 std_rr12 mean(rr12-bp12>0)*100 mean(rr12-bp12>2)*100];


%Sample size = 1000 quarters

load figures_data_1000.mat


rr10 = -ir_rr(10,3,:,1);
rr11 = -ir_rr(11,3,:,1);
rr12 = -ir_rr(12,3,:,1);

bp10 = -ir_bp(10,3,:,1);
bp11 = -ir_bp(11,3,:,1);
bp12 = -ir_bp(12,3,:,1);


mean_bp10   = mean(bp10);
std_bp10    = std(bp10);
median_bp10 = median(bp10);

mean_bp11   = mean(bp11);
std_bp11    = std(bp11);
median_bp11 = median(bp11);


mean_bp12   = mean(bp12);
std_bp12    = std(bp12);
median_bp12 = median(bp12);


mean_rr10   = mean(rr10);
std_rr10    = std(rr10);
median_rr10 = median(rr10);

mean_rr11   = mean(rr11);
std_rr11    = std(rr11);
median_rr11 = median(rr11);


mean_rr12   = mean(rr12);
std_rr12    = std(rr12);
median_rr12 = median(rr12);


table1000 = [mean_bp10 median_bp10 std_bp10 mean_rr10 median_rr10 std_rr10 mean(rr10-bp10>0)*100 mean(rr10-bp10>2)*100
mean_bp11 median_bp11 std_bp11 mean_rr11 median_rr11 std_rr11 mean(rr11-bp11>0)*100 mean(rr11-bp11>2)*100
mean_bp12 median_bp12 std_bp12 mean_rr12 median_rr12 std_rr12 mean(rr12-bp12>0)*100 mean(rr12-bp12>2)*100];



table = [table250;table1000];

%tabletex(table)
