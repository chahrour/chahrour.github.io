%Figure 6: Plot the Favero-Giavazzi impulse responses

clear all
load figures_data_250.mat

f = figure;
j = 1; %taxes
subplot(2,2,1)
h=plot(ir_mod(:,j,1),'b-');
set(h,'linewidth', 3)
hold on

h=plot(mean_fg0(:,j,2),'r--');
set(h,'linewidth', 3)

legend('DSGE','FG')
plot( ir_mod(:,j,1)*0 ,'b')


xlim([1 20])
xlabel('quarters')
ylabel('% deviations from ss output')
title('Tax Revenue')

set(gca,'XTick',[1:2:19])


j = 3; %output
subplot(2,2,2)
h=plot(ir_mod(:,j,1),'b-');
set(h,'linewidth', 3)

hold on

h=plot( mean_fg0(:,j,2),'r--');
set(h,'linewidth', 3)

legend('DSGE','FG')
plot(ir_mod(:,j,1)*0,'b')

q_min = find(ir_mod(:,j,1)==min(ir_mod(:,j,1)));
plot([1 20],[1 1]*ir_mod(q_min,j),':' )

h=plot(q_min, ir_mod(q_min,j,1),'b.');
set(h,'markersize', 20)

fg_min = find(mean_fg0(:,j,2)==min(mean_fg0(:,j,2)));
h=plot(fg_min, mean_fg0(fg_min,j,2),'r.');
set(h,'markersize', 20)


set(gca,'YTick',[-2 round(100*ir_mod(q_min,j,1))/100  -1.5 -1 -.5 0]);
set(gca,'XTick',[1:2:19]);

xlim([1 20])
xlabel('quarters')
ylabel('% deviations from steady state')
title('Output')
hold off
saveas(f, 'figure6.pdf', 'pdf');

