%FIGURE 5: Comparing the MA coefficients of the news model

clear
load model_solution

ns = size(hx,1);

%Pick the variables of interest
GX =gx([9,15 16],:);
variables_in_GX = {'y', 'taxrev', 'govexp'};

%Length of IRs
T = 20;
t = (0:T-1)';

%Make a plot in levels
titles = {'Output','Tax Revenue', 'Government Spending'};

%Impulse responses to tax shocks
%Vectors of initial conditions

%Initial condition for IR to an unanticipated tax shock
x0tau0 = zeros(ns,1);
x0tau0([4,6]) = 1;  %Assumption that TN and TK have same loading on tax shock


%Initial condition for IR to a 6-quarter anticipated tax shock
x0tau6 = zeros(ns,1);
x0tau6(21) = 1;

%Compute impulse responses to unanticipated Tax shock
[IRtau0,IRytau0,IRxtau0]=ir(GX,hx,x0tau0,T);

%Compute impulse responses to anticipated Tax shock
[IRtau6,IRytau6,IRxtau6]=ir(GX,hx,x0tau6,T);
f = figure;
if 1>2
    %Plot Impulse Response of output to tax shocks
    plot(t,(IRytau0(:,1)),'w-')
    hold on
    plot(t,(IRytau6(:,1)),'w--')
    title('Impulse response of Outputto Tax Shocks')
    legend('Unanticipated','Anticipated')
    shg
    hold off
else
    i = 0:12;
    h=plot(i,-1.84*IRytau0(i+1,1)/IRytau0(11,1),'b-');
    set(h,'linewidth', 3)

    hold on
    h=plot(i,IRytau6(i+7,1)*(-1.84/IRytau0(11,1)),'r--');
    set(h,'linewidth', 3)

    hold off
    xlabel('i')
    legend('C^0_i','C^6_{i+6}')
end
saveas(f, 'figure5.pdf', 'pdf');
