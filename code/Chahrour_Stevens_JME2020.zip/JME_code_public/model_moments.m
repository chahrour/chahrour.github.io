%MODEL_MOMENTS - Compute key moments of the price data using the policy
%functions and transition probabilities


%Initialize Empty Data
ep1 = zeros(nsec,nm);
ep2 = zeros(nsec,nm);
ep1_1 = zeros(nsec,nm);
ep2_1 = zeros(nsec,nm);
ep1_2 = zeros(nsec,nm);
ep2_2 = zeros(nsec,nm);

ep1_sqr = zeros(nsec,nm);
ep2_sqr = zeros(nsec,nm);
ep1_sqr_1 = zeros(nsec,nm);
ep2_sqr_1 = zeros(nsec,nm);
ep1_sqr_2 = zeros(nsec,nm);
ep2_sqr_2 = zeros(nsec,nm);

stdp1 = zeros(nsec,nm);
stdp2 = zeros(nsec,nm);
stdp1_1 = zeros(nsec,nm);
stdp2_1 = zeros(nsec,nm);
stdp1_2 = zeros(nsec,nm);
stdp2_2 = zeros(nsec,nm);


ed_bord = zeros(1,nm);
ed_bord_USEXP = zeros(1,nm);
ed_bord_CAEXP = zeros(1,nm);
ed_bord_DOM = zeros(1,nm);


emu1 = zeros(nsec,nm);
emu2 = zeros(nsec,nm);
cov1 = zeros(1,nm);
cov2 = zeros(1,nm);
cov_bord = zeros(1,nm);

cov1_1 = zeros(1,nm);
cov2_1 = zeros(1,nm);
cov_bord_USEXP = zeros(1,nm);

cov1_2 = zeros(1,nm);
cov2_2 = zeros(1,nm);
cov_bord_CAEXP = zeros(1,nm);

cov_bord_DOM = zeros(1,nm);



stdd1 = zeros(1,nm);
stdd2 = zeros(1,nm);
ed = zeros(2,nm);


ep_bord = zeros(1,nm);
stdd_bord = zeros(1,nm);
policy = cell(nm,1);
mu_pol = cell(nm,1);
pc_pol1 = cell(nm,1);
pc_pol2 = cell(nm,1);


for mm = 1:1 %loop for initialization
    policy1 = cell(1,nm);
    policy2 = cell(1,nm);
    
   
    
    policy1_1 = cell(1,nm);
    policy2_1 = cell(1,nm);
    
    policy1_2 = cell(1,nm);
    policy2_2 = cell(1,nm);
    
    
    pc_pol1 = cell(1,nm);
    pc_pol2 = cell(1,nm);
    
    pc_pol1_1 = cell(1,nm);      
    pc_pol2_1 = cell(1,nm);  
    
    
    pc_pol1_2 = cell(1,nm);
    pc_pol2_2 = cell(1,nm);
    
    mu1 = cell(1,nm);
    mu2 = cell(1,nm);
end
%Compute moments from retailer side
for ss = 1:nm
    policy1{ss}  = log([P_DOM1(:,:,ss), P_FOR1(:,:,ss)]);   %Prices paid by country-1 retailers
    policy2{ss}  = log([P_DOM2(:,:,ss), P_FOR2(:,:,ss)]);   %Prices paid by country-2 retailers
    
    
    policy1_1{ss}  = log([P_DOM1(:,:,ss)]);   %Prices paid by country-1 retailers to country 1 producers
    policy2_1{ss}  = log([P_FOR2(:,:,ss)]);   %Prices paid by country-2 retailers to country 1 producers
    
    policy1_2{ss}  = log([P_FOR1(:,:,ss)]);   %Prices paid by country-1 retailers to country 2 producers
    policy2_2{ss}  = log([P_DOM2(:,:,ss)]);   %Prices paid by country-2 retailers to country 2 producers
    
    
    pc_pol1{ss}   = PROB1(:,:,ss);
    pc_pol2{ss}   = PROB2(:,:,ss);
    
    pc_pol1_1{ss} = PROB1(:,1:ngrid,ss);       for mm = 1:nsec; pc_pol1_1{ss}(mm,:)    =PROB1(mm,1:ngrid,ss)    ./sum(PROB1(mm,1:ngrid,ss)); end;
    pc_pol2_1{ss} = PROB2(:,ngrid+1:end,ss);   for mm = 1:nsec; pc_pol2_1{ss}(mm,:)    =PROB2(mm,ngrid+1:end,ss)./sum(PROB2(mm,ngrid+1:end,ss)); end;
    
    
    pc_pol1_2{ss} = PROB1(:,ngrid+1:end,ss);   for mm = 1:nsec; pc_pol1_2{ss}(mm,:)    =PROB1(mm,ngrid+1:end,ss)    ./sum(PROB1(mm,ngrid+1:end,ss)); end;
    pc_pol2_2{ss} = PROB2(:,1:ngrid,ss);       for mm = 1:nsec; pc_pol2_2{ss}(mm,:)    =PROB2(mm,1:ngrid,ss)        ./sum(PROB2(mm,1:ngrid,ss)); end;
   

    mu1{ss}  = log([P_DOM1(:,:,ss), P_FOR1(:,:,ss)])-log([MC_DOM1(:,:,ss), MC_FOR1(:,:,ss)]);   %Markups paid by country-1 retailers
    mu2{ss}  = log([P_DOM2(:,:,ss), P_FOR2(:,:,ss)])-log([MC_DOM2(:,:,ss), MC_FOR2(:,:,ss)]);   %Markups paid by country-2 retailers
    
   
    
    
   
end



%Compute within-state moments
for ss = 1:nm
    
    %E[log(p)|conditional on country and product]...average price paid by
    %retailer
    ep1(:,ss) = diag(pc_pol1{ss}*policy1{ss}');
    ep2(:,ss) = diag(pc_pol2{ss}*policy2{ss}');

    ep1_1(:,ss) = diag(pc_pol1_1{ss}*policy1_1{ss}');
    ep2_1(:,ss) = diag(pc_pol2_1{ss}*policy2_1{ss}');
    
    ep1_2(:,ss) = diag(pc_pol1_2{ss}*policy1_2{ss}');
    ep2_2(:,ss) = diag(pc_pol2_2{ss}*policy2_2{ss}');
    
    

    %Cov(pa,pb) for matched products
    cov1(ss)     = sec_dens*(ep1(:,ss).*ep1(:,ss)) - (sec_dens*ep1(:,ss))*(sec_dens*ep1(:,ss));
    cov2(ss)     = sec_dens*(ep2(:,ss).*ep2(:,ss)) - (sec_dens*ep2(:,ss))*(sec_dens*ep2(:,ss));
    cov_bord(ss) = sec_dens*(ep1(:,ss).*ep2(:,ss)) - (sec_dens*ep1(:,ss))*(sec_dens*ep2(:,ss));
 
    cov1_1(ss)     = sec_dens*(ep1_1(:,ss).*ep1_1(:,ss)) - (sec_dens*ep1_1(:,ss))*(sec_dens*ep1_1(:,ss));
    cov2_1(ss)     = sec_dens*(ep2_1(:,ss).*ep2_1(:,ss)) - (sec_dens*ep2_1(:,ss))*(sec_dens*ep2_1(:,ss));
    cov_bord_USEXP(ss) = sec_dens*(ep1_1(:,ss).*ep2_1(:,ss)) - (sec_dens*ep1_1(:,ss))*(sec_dens*ep2_1(:,ss));
 
    cov1_2(ss)     = sec_dens*(ep1_2(:,ss).*ep1_2(:,ss)) - (sec_dens*ep1_2(:,ss))*(sec_dens*ep1_2(:,ss));
    cov2_2(ss)     = sec_dens*(ep2_2(:,ss).*ep2_2(:,ss)) - (sec_dens*ep2_2(:,ss))*(sec_dens*ep2_2(:,ss));
    cov_bord_CAEXP(ss) = sec_dens*(ep1_2(:,ss).*ep2_2(:,ss)) - (sec_dens*ep1_2(:,ss))*(sec_dens*ep2_2(:,ss));
 
    cov_bord_DOM(ss) = sec_dens*(ep1_1(:,ss).*ep2_2(:,ss)) - (sec_dens*ep1_1(:,ss))*(sec_dens*ep2_2(:,ss));
    
    
    
    %E[log(p)^2|conditional on country and product]...sqaured-average price paid by
    %retailer
    ep1_sqr(:,ss) = diag(pc_pol1{ss}*(policy1{ss}.^2)');
    ep2_sqr(:,ss) = diag(pc_pol2{ss}*(policy2{ss}.^2)');

    ep1_sqr_1(:,ss) = diag(pc_pol1_1{ss}*(policy1_1{ss}.^2)');
    ep2_sqr_1(:,ss) = diag(pc_pol2_1{ss}*(policy2_1{ss}.^2)');
    
    ep1_sqr_2(:,ss) = diag(pc_pol1_2{ss}*(policy1_2{ss}.^2)');
    ep2_sqr_2(:,ss) = diag(pc_pol2_2{ss}*(policy2_2{ss}.^2)');
    
    
    %E[markup]....Markup of producers in each country, conditional on no shutdown
    emu1(:,ss) = diag(pc_pol1{ss}*mu1{ss}');
    emu2(:,ss) = diag(pc_pol2{ss}*mu2{ss}');

    %std(log(p)|conditional on country and sector)
    stdp1(:,ss) = (ep1_sqr(:,ss) - ep1(:,ss).^2).^.5;
    stdp2(:,ss) = (ep2_sqr(:,ss) - ep2(:,ss).^2).^.5;

    stdp1_1(:,ss) = (ep1_sqr_1(:,ss) - ep1_1(:,ss).^2).^.5;
    stdp2_1(:,ss) = (ep2_sqr_1(:,ss) - ep2_1(:,ss).^2).^.5;
    
    stdp1_2(:,ss) = (ep1_sqr_2(:,ss) - ep1_2(:,ss).^2).^.5;
    stdp2_2(:,ss) = (ep2_sqr_2(:,ss) - ep2_2(:,ss).^2).^.5;
    
    
    %E[dt|across countries]...average cross border price differential
    ed_bord(ss) = sec_dens*ep1(:,ss)-sec_dens*ep2(:,ss); 
    ed_bord_USEXP(ss) = sec_dens*ep1_1(:,ss)-sec_dens*ep2_1(:,ss);
    ed_bord_CAEXP(ss) = sec_dens*ep1_2(:,ss)-sec_dens*ep2_2(:,ss);
    ed_bord_DOM(ss)   = sec_dens*ep1_1(:,ss)-sec_dens*ep2_2(:,ss);
    
    %std(log(sec_dens)-log(pb)|agg state) within countries (note that covariance
    %within countries is zero, since we are picking random prices)
    stdd1(ss) = (sec_dens*ep1_sqr(:,ss) + sec_dens*ep1_sqr(:,ss) - (sec_dens*ep1(:,ss))^2 - (sec_dens*ep1(:,ss))^2 - 2*cov1(ss)).^(1/2);
    stdd2(ss) = (sec_dens*ep2_sqr(:,ss) + sec_dens*ep2_sqr(:,ss) - (sec_dens*ep2(:,ss))^2 - (sec_dens*ep2(:,ss))^2 - 2*cov2(ss)).^(1/2);
    stdd_bord(ss) = (sec_dens*ep1_sqr(:,ss) + sec_dens*ep2_sqr(:,ss) - (sec_dens*ep1(:,ss))^2 - (sec_dens*ep2(:,ss))^2 - 2*cov_bord(ss)).^(1/2);
    
    stdd1_1(ss) = (sec_dens*ep1_sqr_1(:,ss) + sec_dens*ep1_sqr_1(:,ss) - (sec_dens*ep1_1(:,ss))^2 - (sec_dens*ep1_1(:,ss))^2 - 2*cov1_1(ss)).^(1/2);
    stdd2_1(ss) = (sec_dens*ep2_sqr_1(:,ss) + sec_dens*ep2_sqr_1(:,ss) - (sec_dens*ep2_1(:,ss))^2 - (sec_dens*ep2_1(:,ss))^2 - 2*cov2_1(ss)).^(1/2);
    stdd_bord_USEXP(ss) = (sec_dens*ep1_sqr_1(:,ss) + sec_dens*ep2_sqr_1(:,ss) - (sec_dens*ep1_1(:,ss))^2 - (sec_dens*ep2_1(:,ss))^2 - 2*cov_bord_USEXP(ss)).^(1/2);
    
    stdd1_2(ss) = (sec_dens*ep1_sqr_2(:,ss) + sec_dens*ep1_sqr_2(:,ss) - (sec_dens*ep1_2(:,ss))^2 - (sec_dens*ep1_2(:,ss))^2 - 2*cov1_2(ss)).^(1/2);
    stdd2_2(ss) = (sec_dens*ep2_sqr_2(:,ss) + sec_dens*ep2_sqr_2(:,ss) - (sec_dens*ep2_2(:,ss))^2 - (sec_dens*ep2_2(:,ss))^2 - 2*cov2_2(ss)).^(1/2);
    stdd_bord_CAEXP(ss) = (sec_dens*ep1_sqr_2(:,ss) + sec_dens*ep2_sqr_2(:,ss) - (sec_dens*ep1_2(:,ss))^2 - (sec_dens*ep2_2(:,ss))^2 - 2*cov_bord_CAEXP(ss)).^(1/2);
    
    stdd_bord_DOM(ss) = (sec_dens*ep1_sqr_1(:,ss) + sec_dens*ep2_sqr_2(:,ss) - (sec_dens*ep1_1(:,ss))^2 - (sec_dens*ep2_2(:,ss))^2 - 2*cov_bord_DOM(ss)).^(1/2);
   
end


%Unconditional Expectations
u_ep1 = sec_dens*ep1*pw_bar';
u_ep2 = sec_dens*ep2*pw_bar';

u_ep1_1 = sec_dens*ep1_1*pw_bar';
u_ep2_1 = sec_dens*ep2_1*pw_bar';

u_ep1_2 = sec_dens*ep1_2*pw_bar';
u_ep2_2 = sec_dens*ep2_2*pw_bar';


u_mu1 = sec_dens*emu1*pw_bar';
u_mu2 = sec_dens*emu2*pw_bar';

%Price level stats: unconditional comovements
u_std_p1 = ((sec_dens*ep1_sqr)*pw_bar' - u_ep1.^2).^.5 ;                           %Variance of random sampled price within country   
u_std_p2 = ((sec_dens*ep2_sqr)*pw_bar' - u_ep2.^2).^.5 ;

u_std_p1_1 = ((sec_dens*ep1_sqr_1)*pw_bar' - u_ep1_1.^2).^.5 ;                           %Variance of random sampled price within country   
u_std_p2_1 = ((sec_dens*ep2_sqr_1)*pw_bar' - u_ep2_1.^2).^.5 ;

u_std_p1_2 = ((sec_dens*ep1_sqr_2)*pw_bar' - u_ep1_2.^2).^.5 ;                           %Variance of random sampled price within country   
u_std_p2_2 = ((sec_dens*ep2_sqr_2)*pw_bar' - u_ep2_2.^2).^.5 ;

%unconditional prob of a ss transition
transprob = repmat(pw_bar', [1,nm]).*pw;
itransprob = repmat(sec_dens', [1,nsec]).*repmat(sec_dens,[nsec,1]);

u_autocovp1 = itransprob(:)'*kron(ep1,ep1)*transprob(:) - (sec_dens*ep1*pw_bar')^2;  %E[sec_dens(t-1),sec_dens(t)]
u_autocovp2 = itransprob(:)'*kron(ep2,ep2)*transprob(:) - (sec_dens*ep2*pw_bar')^2;
u_autocovp_bord = itransprob(:)'*kron(ep1,ep2)*transprob(:) - (sec_dens*ep1*pw_bar')*(sec_dens*ep2*pw_bar');
u_std_dp1 = (u_std_p1^2 + u_std_p1^2 - 2*u_autocovp1)^.5;  %std[sec_dens(t)-sec_dens(t-1)]
u_std_dp2 = (u_std_p2^2 + u_std_p2^2 - 2*u_autocovp2)^.5;


u_autocovp1_1 = itransprob(:)'*kron(ep1_1,ep1_1)*transprob(:) - (sec_dens*ep1_1*pw_bar')^2;  %E[sec_dens(t-1),sec_dens(t)]
u_autocovp2_1 = itransprob(:)'*kron(ep2_1,ep2_1)*transprob(:) - (sec_dens*ep2_1*pw_bar')^2;

u_autocovp_bord_USEXP = itransprob(:)'*kron(ep1_1,ep2_1)*transprob(:) - (sec_dens*ep1_1*pw_bar')*(sec_dens*ep2_1*pw_bar');
u_std_dp1_1 = (u_std_p1_1^2 + u_std_p1_1^2 - 2*u_autocovp1_1)^.5;  %std[sec_dens(t)-sec_dens(t-1)]
u_std_dp2_1 = (u_std_p2_1^2 + u_std_p2_1^2 - 2*u_autocovp2_1)^.5;

u_autocovp1_2 = itransprob(:)'*kron(ep1_2,ep1_2)*transprob(:) - (sec_dens*ep1_2*pw_bar')^2;  %E[sec_dens(t-1),sec_dens(t)]
u_autocovp2_2 = itransprob(:)'*kron(ep2_2,ep2_2)*transprob(:) - (sec_dens*ep2_2*pw_bar')^2;
u_autocovp_bord_CAEXP = itransprob(:)'*kron(ep1_2,ep2_2)*transprob(:) - (sec_dens*ep1_2*pw_bar')*(sec_dens*ep2_2*pw_bar');
u_std_dp1_2 = (u_std_p1_2^2 + u_std_p1_2^2 - 2*u_autocovp1_2)^.5;  %std[sec_dens(t)-sec_dens(t-1)]
u_std_dp2_2 = (u_std_p2_2^2 + u_std_p2_2^2 - 2*u_autocovp2_2)^.5;

u_autocovp_bord_DOM = itransprob(:)'*kron(ep1_1,ep2_2)*transprob(:) - (sec_dens*ep1_1*pw_bar')*(sec_dens*ep2_2*pw_bar');


%All goods
u_papb1 = sec_dens*(ep1.*ep1)*pw_bar' ; %E[sec_dens,pb] unconditional
u_papb2 = sec_dens*(ep2.*ep2)*pw_bar';
u_papb_bord = sec_dens*(ep1.*ep2)*pw_bar';

u_cov_dp1 = u_papb1 + u_papb1 - 2*itransprob(:)'*kron(ep1,ep1)*transprob(:); %Cov(delta sec_dens, delta pb) in country 1 for matched goods
u_cov_dp2 = u_papb2 + u_papb2 - 2*itransprob(:)'*kron(ep2,ep2)*transprob(:);
u_cov_dp_bord = u_papb_bord + u_papb_bord - itransprob(:)'*kron(ep1,ep2)*transprob(:) - itransprob(:)'*kron(ep1,ep2)*transprob(:); %Cov(delta sec_dens, delta pb) cross country for matched goods

%US exports
u_papb1_1 = sec_dens*(ep1_1.*ep1_1)*pw_bar' ; %E[sec_dens,pb] unconditional
u_papb2_1 = sec_dens*(ep2_1.*ep2_1)*pw_bar';
u_papb_bord_USEXP = sec_dens*(ep1_1.*ep2_1)*pw_bar';

u_cov_dp1_1 = u_papb1_1 + u_papb1_1 - 2*itransprob(:)'*kron(ep1_1,ep1_1)*transprob(:); %Cov(delta sec_dens, delta pb) in country 1 for matched goods
u_cov_dp2_1 = u_papb2_1 + u_papb2_1 - 2*itransprob(:)'*kron(ep2_1,ep2_1)*transprob(:);
u_cov_dp_bord_USEXP = u_papb_bord_USEXP + u_papb_bord_USEXP - itransprob(:)'*kron(ep1_1,ep2_1)*transprob(:) - itransprob(:)'*kron(ep2_1,ep1_1)*transprob(:); %Cov(delta sec_dens, delta pb) cross country for matched goods


%CA exports
u_papb1_2 = sec_dens*(ep1_2.*ep1_2)*pw_bar' ; %E[sec_dens,pb] unconditional
u_papb2_2 = sec_dens*(ep2_2.*ep2_2)*pw_bar';
u_papb_bord_CAEXP = sec_dens*(ep1_2.*ep2_2)*pw_bar';

u_cov_dp1_2 = u_papb1_2 + u_papb1_2 - 2*itransprob(:)'*kron(ep1_2,ep1_2)*transprob(:); %Cov(delta sec_dens, delta pb) in country 1 for matched goods
u_cov_dp2_2 = u_papb2_2 + u_papb2_2 - 2*itransprob(:)'*kron(ep2_2,ep2_2)*transprob(:);
u_cov_dp_bord_CAEXP = u_papb_bord_CAEXP + u_papb_bord_CAEXP - itransprob(:)'*kron(ep1_2,ep2_2)*transprob(:) - itransprob(:)'*kron(ep2_2,ep1_2)*transprob(:); %Cov(delta sec_dens, delta pb) cross country for matched goods

%Domestic
u_papb_bord_DOM = sec_dens*(ep1_1.*ep2_2)*pw_bar';
u_cov_dp_bord_DOM = u_papb_bord_DOM + u_papb_bord_DOM - itransprob(:)'*kron(ep1_1,ep2_2)*transprob(:) - itransprob(:)'*kron(ep2_2,ep1_1)*transprob(:); %Cov(delta sec_dens, delta pb) cross country for matched goods



u_rhodp1 = u_cov_dp1/(u_std_dp1*u_std_dp1); %rho(sec_dens(t)-sec_dens(t-1),pb(t)-pb(t-1))
u_rhodp2 = u_cov_dp2/(u_std_dp2*u_std_dp2);
u_rhodp_bord = u_cov_dp_bord/(u_std_dp1*u_std_dp2);

u_rhodp1_1 = u_cov_dp1_1/(u_std_dp1_1*u_std_dp1_1); %rho(sec_dens(t)-sec_dens(t-1),pb(t)-pb(t-1))
u_rhodp2_1 = u_cov_dp2_1/(u_std_dp2_1*u_std_dp2_1);
u_rhodp_bord_USEXP = u_cov_dp_bord_USEXP/(u_std_dp1_1*u_std_dp2_1);

u_rhodp1_2 = u_cov_dp1_2/(u_std_dp1_2*u_std_dp1_2); %rho(sec_dens(t)-sec_dens(t-1),pb(t)-pb(t-1))
u_rhodp2_2 = u_cov_dp2_2/(u_std_dp2_2*u_std_dp2_2);
u_rhodp_bord_CAEXP = u_cov_dp_bord_CAEXP/(u_std_dp1_2*u_std_dp2_2);

u_rhodp_bord_DOM = u_cov_dp_bord_DOM/(u_std_dp1_1*u_std_dp2_2);



%Changes in real exchange rate
u_std_dd1 = (u_std_dp1^2 + u_std_dp1^2 - 2*u_cov_dp1)^.5;
u_std_dd2 = (u_std_dp2^2 + u_std_dp2^2 - 2*u_cov_dp2)^.5;
u_std_dd_bord = (u_std_dp1^2 + u_std_dp2^2 - 2*u_cov_dp_bord)^.5;


u_std_dd1_1 = (u_std_dp1_1^2 + u_std_dp1_1^2 - 2*u_cov_dp1_1)^.5;
u_std_dd2_1 = (u_std_dp2_1^2 + u_std_dp2_1^2 - 2*u_cov_dp2_1)^.5;
u_std_dd_bord_USEXP = (u_std_dp1_1^2 + u_std_dp2_1^2 - 2*u_cov_dp_bord_USEXP)^.5;

u_std_dd1_2 = (u_std_dp1_2^2 + u_std_dp1_2^2 - 2*u_cov_dp1_2)^.5;
u_std_dd2_2 = (u_std_dp2_2^2 + u_std_dp2_2^2 - 2*u_cov_dp2_2)^.5;
u_std_dd_bord_CAEXP = (u_std_dp1_2^2 + u_std_dp2_2^2 - 2*u_cov_dp_bord_CAEXP)^.5;

u_std_dd_bord_DOM = (u_std_dp1_1^2 + u_std_dp2_2^2 - 2*u_cov_dp_bord_DOM)^.5;

%Exchange rate moments
u_std_e = sqrt(sum(log(exch).^2.*pw_bar,2) - sum(log(exch).*pw_bar).^2);
u_cov_eed = sum(ed_bord.*log(exch).*pw_bar) -     sum(ed_bord.*pw_bar)*sum(log(exch).*pw_bar); %cov[d_bar,log(exch)]
u_std_ed_bord = sqrt(sum(ed_bord.^2.*pw_bar,2) - sum(ed_bord.*pw_bar,2).^2);               %std[d_bar]
u_rho_eed = u_cov_eed./(u_std_ed_bord*u_std_e)  ;                                           %rho(d_bar,log(exch))


u_std_cn1 = sqrt(sum(log(CN1).^2.*pw_bar,2) - sum(log(CN1).*pw_bar).^2);
u_std_cn2 = sqrt(sum(log(CN2).^2.*pw_bar,2) - sum(log(CN2).*pw_bar).^2);

u_std_ct1 = sqrt(sum(log(CT1).^2.*pw_bar,2) - sum(log(CT1).*pw_bar).^2);
u_std_ct2 = sqrt(sum(log(CT2).^2.*pw_bar,2) - sum(log(CT2).*pw_bar).^2);


u_ct1 = CT1*pw_bar';
u_ct2 = CT2*pw_bar';

u_cn1 = CN1*pw_bar';
u_cn2 = CN2*pw_bar';

[u_ct1, u_ct2;u_cn1 u_cn2];

u_ee  = exch*pw_bar';

u_autocove = [repmat(pw_bar,1,nm).*pw(1:end)]*kron(log(exch)', log(exch)') - (pw_bar*log(exch'))^2; %cov(log(e(t),log(e(t-1)))
u_std_de = sqrt(2*u_std_e^2 - 2*u_autocove) ;

u_std_L1 = pw_bar*(log(LTOT1'./LTOT1(mid)).^2) - (pw_bar*log(LTOT1'./LTOT1(mid)))^2;
u_std_L2 = pw_bar*(log(LTOT2'./LTOT2(mid)).^2) - (pw_bar*log(LTOT2'./LTOT2(mid)))^2;



u_rho_e = u_autocove/(u_std_e*u_std_e);
u_imp1 = imp_shr1*pw_bar';
u_imp2 = imp_shr2*pw_bar';


%Sales weighted markups
u_mu1_sales = sum(MU1.*pw_bar);
u_mu2_sales = sum(MU2.*pw_bar);

u_kshr1 = sum(KSHR1.*pw_bar);
u_kshr2 = sum(KSHR2.*pw_bar);

u_rfrac1 = sum(rfrac1.*pw_bar);
u_rfrac2 = sum(rfrac2.*pw_bar);

if ~exist('print_mom', 'var') || (exist('print_mom', 'var') && print_mom==true)

disp(' ')    
disp('Table 2 Column:')
disp_num(u_imp1,3);
disp_num(u_imp2,3);
disp_num(u_mu1_sales,3);
disp(' ')
disp_num(u_std_dd1_1,2); 
disp_num(u_std_dd2_1,2); 
disp_num(u_std_dd_bord_USEXP,2); 
disp(' ')
disp_num(u_std_dd1_2,2); 
disp_num(u_std_dd2_2,2); 
disp_num(u_std_dd_bord_CAEXP,2);    
 
disp(' ');
disp('Table 4 Column:')
disp_num(u_rhodp1_1,2); 
disp_num(u_rhodp2_1,2); 
disp_num(u_rhodp_bord_USEXP,2); 
disp(' ')
disp_num(u_rhodp1_2,2); 
disp_num(u_rhodp2_2,2); 
disp_num(u_rhodp_bord_CAEXP,2); 
disp(' ')
disp_num(-u_rho_eed,2);
disp_num(u_mu2_sales,2);

%Save and display output
% disp('Detailed Output');
% disp_num(alph1);
% disp_num(alph2);
% disp_num(kap1);
% disp_num(kap2);
% disp_num(sd_mc1);
% disp_num(sd_mc2);
% disp_num(sd_sec1);
% disp_num(sd_sec2);
% disp_num(std_m);
% disp_num(ice);
% disp_num(rho_m);
% disp_num(mu_w);
% 
% disp_num(nm);
% disp_num(nsec);
% disp_num(ngrid);
% disp_num(s1);
% disp_num(s2);
% disp_num(zet);
% disp_num(eta1);
% disp_num(rho);
% 
% 
% 
% disp_num(u_rho_e);
% disp_num(u_imp1);
% disp_num(u_imp2);
% disp_num(u_std_de);
% 
% 
% disp_num(u_std_dd1_1); 
% disp_num(u_std_dd2_1); 
% disp_num(u_std_dd_bord_USEXP); 
% 
% disp_num(u_std_dd1_2); 
% disp_num(u_std_dd2_2); 
% disp_num(u_std_dd_bord_CAEXP);
% 
% % disp_num(u_std_dd1_1);
% % disp_num(u_std_dd2_2); 
% % disp_num(u_std_dd_bord_DOM);
% % 
% % disp_num(u_std_dd1);
% % disp_num(u_std_dd2); 
% % disp_num(u_std_dd_bord);
% 
% 
% 
% disp_num(u_rhodp1_1); 
% disp_num(u_rhodp2_1); 
% disp_num(u_rhodp_bord_USEXP); 
% 
% disp_num(u_rhodp1_2); 
% disp_num(u_rhodp2_2); 
% disp_num(u_rhodp_bord_CAEXP); 
% disp_num(u_rho_eed);
% % disp_num(u_rhodpA_A); 
% % disp_num(u_rhodp2_2); 
% % disp_num(u_rhodp_bord_DOM); 
% % 
% % 
% % disp_num(u_rhodpA); 
% % disp_num(u_rhodp2); 
% % disp_num(u_rhodp_bord); 
% disp_num(u_mu1);
% disp_num(u_mu2);
% disp_num(u_mu1_sales);
% disp_num(u_mu2_sales);
% 
% disp_num(u_std_dp1);
% disp_num(u_std_dp2);
% disp_num(u_std_e);
% 
% disp_num(u_kshr1);
% disp_num(u_kshr2);
% 
% disp_num(u_rfrac1 );
% disp_num(u_rfrac2 );


output = [alph1	;
alph2	;
kap1	;
kap2	;
sd_mc1	;
sd_mc2	;
sd_sec1	;
sd_sec2	;
std_m	;
ice	;
rho_m	;
mu_w	;
nm	;
nsec	;
ngrid	;
s1	;
s2	;
zet	;
eta1	;
rho	;
u_rho_e	;
u_imp1	;
u_imp2	;
u_std_de	;
u_std_dd1_1	; 
u_std_dd2_1	; 
u_std_dd_bord_USEXP	; 
u_std_dd1_2	; 
u_std_dd2_2	; 
u_std_dd_bord_CAEXP	;
u_rhodp1_1	; 
u_rhodp2_1	; 
u_rhodp_bord_USEXP	; 
u_rhodp1_2	; 
u_rhodp2_2	; 
u_rhodp_bord_CAEXP	; 
u_rho_eed	;
u_mu1	;
u_mu2	;
u_mu1_sales	;
u_mu2_sales	;
u_std_dp1	;
u_std_dp2	;
u_std_e	;
u_kshr1	;
u_kshr2	;
u_rfrac1 	;
u_rfrac2 	] ; 

%disp(output); 
end




