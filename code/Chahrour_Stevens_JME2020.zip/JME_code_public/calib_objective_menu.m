function [out,param,mom_actual] = calib_objective_menu(pvec,mom_target,param,to_screen)

tic

suffix = 'baseline';


param.kapA    = pvec(1);
param.kapB    = pvec(2);
param.sd_mc1  = pvec(3);
param.sd_mc2  = pvec(4); 
param.sd_sec1 = pvec(5); %Symmetric demand shocks
param.sd_sec2 = pvec(5);
param.tauw1   = pvec(6);
param.tauw2   = pvec(7);

print_mom = false;
static_solve



%Moments to targ
try
    [mom_actual,mom_extra]= quick_sim_moment(f_p11,f_p21,f_p12,f_p22,pc_grid,sec_dens);
catch
    mom_actual(:) = 100000;
end
mom_actual(9)  = rfrac1(cntr(1));
mom_actual(10) = rfrac2(cntr(1));

out = 10*(mom_actual-mom_target)./mom_target;

out = out(3:end);


%[mom_actual;mom_target]

disp(['Time: ' num2str(toc) '|' num2str(gg) '|' num2str2(walras_check) '|| Params: ' sprintf('%1.7f ', pvec(:)') '|| Loss: ' num2str2(sum(out.^2))]);

%%
if nargin>3
disp_num(alph1);
disp_num(alph2);
disp_num(kap1);
disp_num(kap2);
disp_num(sd_mc1);
disp_num(sd_mc2);
disp_num(sd_sec1);
disp_num(sd_sec2);
disp_num(std_m);
disp_num(ice);
disp_num(rho_m);
disp_num(mu_w);

disp_num(nm);
disp_num(nsec);
disp_num(NaN);
disp_num(s1);
disp_num(s2);
disp_num(zet);
disp_num(eta1);
disp_num(rho);



disp_num(NaN);
disp_num(imp_shr1);
disp_num(imp_shr2);
disp_num(NaN);


for jj = 1:6
    disp_num(mom_actual(jj+2));
end

for jj = 1:6
    disp_num(mom_extra(jj));
end

disp_num(NaN);

disp_num(log(mu1));
disp_num(log(mu2));
disp_num(MU1);
disp_num(MU2);

%disp_num(u_std_dp1);
%disp_num(u_std_dp2);
%disp_num(u_std_e);

disp_num(NaN);
disp_num(NaN);
disp_num(NaN);

disp_num(KSHR1);
disp_num(KSHR2);

disp_num(rfrac1 ); 
disp_num(rfrac2 );
end

