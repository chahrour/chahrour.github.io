addpath('helper_funcs')
 

param = parameters;
edit parameters
edit static_solve
edit ge_iter
edit single_country_step_disc.m
edit lsq_base
edit lsq_menu
edit calib_objective_base.m
edit calib_objective_menu.m
edit global_search