% NEWEY_WEST - This function takes a reg object and creates Newey_West Variance-Covariance Estimator.
%
% Usage:
% p = Newey_West(reg_object)



function est = Newey_West(p)

n = size(p.X,1);
S = 0;
for i = 1:n  
    S = S + p.resid(i)^2*p.X(i,:)'*p.X(i,:);
end


%Determin Max Lags- suggested by White, pg 200
L = ceil(n^.25);

for j = 1:L
    for t = j+1:n
        S = S+(1-(j/(L+1)))*p.resid(t)*p.resid(t-j)*(p.X(t,:)'*p.X(t-j,:) + p.X(t-j,:)'*p.X(t,:));
    end
end
est = S;inv(p.X'*p.X)*S*inv(p.X'*p.X);


