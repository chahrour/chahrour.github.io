% PRINT_REG -  Prints a regression object to screen.
%
% Usage:
% bool = print_reg (regression)

function bool = print_reg(struct)

%Add a heading for restriced/unrestriced OLS
if struct.restricted == 0
    rstr = 'UNRESTRICTED ';
else
    rstr = 'RESTRICTED ';
end

disp ([rstr, 'OLS REGRESSION']);
disp ('-----------------------------------------------------------');
disp (['Dependent variable: ', num2str(struct.Y_label)]);
%disp (' ');

% disp ('Estimated Variance Matrix:');
% for i = 1: size(struct.var,1)
%     disp (num2str(struct.var(i,:)));
% end

%disp (' ');
disp (['N obs: ', num2str(struct.n)]);
disp (['Sum of Squared Errors: ', num2str(struct.s_sqr)]);

disp (['R-Squared: ', num2str(struct.r_sqr)]);

disp (['Adj R-Squared: ', num2str(struct.r_sqr_adj)]);
disp (' ');

disp ('-----------------------------------------------------------');
disp (sprintf('Variable \t\t Coeff \t\t\t t-stat'));
disp ('-----------------------------------------------------------');
for i =1:size(struct.X_label,2)
    disp (sprintf([' %10s \t\t %+.5f \t\t %+.5f'], struct.X_label{i},struct.beta(i), struct.t(i)))
end

disp ('-----------------------------------------------------------');
disp ('END OF REGRESSION');
disp ('-----------------------------------------------------------');

