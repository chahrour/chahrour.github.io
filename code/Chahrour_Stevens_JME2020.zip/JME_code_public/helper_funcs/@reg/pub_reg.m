% PUB_REG - This function publishes a reg objec to a latex file as figure.
%
% Usage:
% pub_reg (reg_object, print_flag)
% where
% reg_object: a regression object
% print_flag: 'to screen', 'to printer', or  'ask'

function pub_reg(reg, varargin)

%Add a heading for restriced
if reg.restricted == 1
    rstr = ['Restricted '];
else
    rstr = [''];
end
p_values = tdis_cdf(abs(reg.t), reg.n-reg.k, 'two-sided')
p_values = 1-p_values
data = [reg.beta, reg.t, p_values];

%new_data = [];
% %Splice in P Values:
% for i = 1:size(data,1)
%     new_data = [new_data; [reg.beta(i), reg.t(i)];[p_values(i), 0]];
% end
%data = new_data;

horiz = {'Variable', 'Coefficient' , ' t-statistic'};
vert = reg.X_label;

tit_str  = [rstr, 'Regression of ', reg.Y_label, ' on'];

tbl1 = ltable(data, horiz,vert,tit_str, ...
        [home_dir, '/ryan_lib/@reg/regformat'],1,'reg_out',...
        'no print');

tbl2 = ltable([reg.r_sqr; reg.r_sqr_adj], {'Additonal Statistics'}, {'R-sqr' ,'Adjust. R-sqr'},'caption',...
        [home_dir, '/ryan_lib/@reg/regformat2'],1,'reg_out2','no print');

make_file('out' ,'def', 'reg_out', 'reg_out2');
if ~isempty( varargin)
    output('out' , varargin{1})
else
    output('out' , 'ask')
end
    