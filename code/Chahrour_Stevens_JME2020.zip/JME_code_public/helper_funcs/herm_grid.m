function [pts,dens] = herm_grid(mu,sd,np)


[pts,dens] = hermquad(np);
pts        = exp(log(mu)+pts(end:-1:1)'.*sd*sqrt(2));
dens       = dens(end:-1:1)'./sum(dens);


