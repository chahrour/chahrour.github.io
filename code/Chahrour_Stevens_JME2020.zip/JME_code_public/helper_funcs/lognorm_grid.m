function [pts,dens] = lognorm_grid(mu,sd,np,nsd)

if nargin<4
    nsd = 2.5;
end

if np>1
    grid = linspace(-nsd*sd,nsd*sd,np);
else
    grid = 0;
end
pts  = log(mu) + grid;
dens = normpdf(pts,log(mu),sd);
dens = dens/sum(dens);

pts = exp(pts);