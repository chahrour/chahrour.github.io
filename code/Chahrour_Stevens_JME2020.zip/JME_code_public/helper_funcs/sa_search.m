
function [vml,pout,flag] = sa_search(obj1,obj2,lbnd,ubnd, yesmincon)

Aeq = [];
beq = [];

%genetic step
options = optimoptions('ga');
options.MaxGenerations = 10;
options.MaxTime        = 60*30;
options.PopulationSize = 10;
[pout,vml] = ga(obj1,length(lbnd),[],[],Aeq,beq,lbnd,ubnd,[],options);

%Nolinear solver
options = optimoptions('lsqnonlin');
options.TolX                   = 1e-5;
options.TolFun                 = 1e-5;
options.Display                = 'iter';
options.MaxFunctionEvaluations = 350;


options.FiniteDifferenceStepSize = .01*[ubnd-lbnd];
[pout, vml, ~, flag]= lsqnonlin(obj2,pout,lbnd,ubnd,options);




pout = pout(:);

