function out = num2str2(x)

out = sprintf('%1.3e', x);

end