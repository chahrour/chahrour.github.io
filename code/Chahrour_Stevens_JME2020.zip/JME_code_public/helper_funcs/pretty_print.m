function out = pretty_print(V,ndec)


sformat = ['%1.' num2str(ndec), 'f\t'];
for j = 1:size(V,1)
    disp(sprintf(sformat, V(j,:))); 
end