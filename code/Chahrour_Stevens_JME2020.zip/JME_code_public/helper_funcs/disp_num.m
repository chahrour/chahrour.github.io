function out = disp_num(in,varargin)

if length(varargin)==0
    ndig = 4;
else
    ndig = varargin{1};
end

out = sprintf(['%1.' num2str(ndig) 'f'], in);
disp(out);