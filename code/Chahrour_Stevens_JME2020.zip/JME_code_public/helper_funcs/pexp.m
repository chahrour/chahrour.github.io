function fout = pexp(X,lam)
X = X./lam;

ncol     = size(X,2);
fout     = zeros(size(X));
for jj = 1:ncol
    tmp = X(:,jj); 
    aa  = (tmp'-tmp);
    fout(:,jj) = sum(exp(aa),2).^-1;
end

end


% TRILV
function [out,idx] = trilv(X)

out = tril(X);

idx = tril(ones(size(X,1)));

idx = idx(:,1:size(X,2))>0;

out = out(idx);

end
  