function out = collect_results(ns,nowstr,nms)

data = [];
for jj = 1:ns
    
    try
        tmp = load(['global_tmp_' num2str(jj), '_' nowstr '.txt']);
        data = [data;tmp];
    catch
        %No file available yet
    end
end
[maxp,b] = sort(data(:,1));
data = data(b,:);


f = fopen(['param_ml_' nowstr '.xls'], 'w');
fprint_mat(f, '%1.6f\t', data, {'loss', 'flag', nms{:}});
fclose(f);

end