function out = exp_tilde(x)


%out = 1 + x + x.^2./2 + x.^3./6 + x.^4./24 + x.^5./120;

out = ((x+3).^2 + 3)./((x-3).^2+3);