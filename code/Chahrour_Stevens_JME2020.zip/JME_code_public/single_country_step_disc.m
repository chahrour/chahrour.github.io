function [pr_i,pr_idx,f_p,f_p1,f_p2,p_i,c_i,W1,CT,PT,LTOT,L2,LT,CN,PN,IMP,PI1,PI2,PI_RET,mc_grid1,mc_grid2,p_ij1,p_ij2,prob_all,active1,active2,V1prime,V2prime,diffv,rfrac,g_p_alt,chi,open1_orig,open2_orig,crit_outer] = single_country_step_disc...
    (g_p,f_p,f_p1,f_p2,chi,active1,active2,p_i,c_i,W1,CT,PT,L_for,W2,...
    V1prime,V2prime,...
    s1,m1,m2,dem_grid,sec_grid1,sec_grid2,sec_dens,mc_grid_idio1,mc_grid_idio2,mc_dens1,mc_dens2,...
    Mbar,Wss,eta,rho,kap,phit,zet,psii,mu_w,ice,tauw,...
    pc_grid,kp_grid,kp_dens,open1_orig,open2_orig,lam,gg)

Abar   = 1;      %exogenous, steady-state level of productivity
nkp    = length(kp_grid);
nsec   = length(sec_grid1);
ngrid1 = length(mc_grid_idio1);
ngrid2 = length(mc_grid_idio2);
np     = length(pc_grid);

%**************************************************************************
% INITIALIZATIONS (in loop only for code folding)
%**************************************************************************

%Sectoral things
pr_i      = zeros(nsec,nkp);
pr_idx    = zeros(nsec,nkp);
p_ij1     = zeros(nsec,ngrid1);
p_ij2     = zeros(nsec,ngrid2);
l_i1      = zeros(1,nsec);
l_i2      = zeros(1,nsec);
doms      = zeros(1,nsec);
imports   = zeros(1,nsec);
pi_i1     = zeros(1,nsec);
pi_i2     = zeros(1,nsec);
piret_i   = zeros(1,nsec);
reset_frac= zeros(1,nsec);
prob      = zeros(1,ngrid1+ngrid2);
prob_all  = zeros(nsec,ngrid1+ngrid2);
%Combine sector and firm-level shocks
mc_grid1   = W1*kron(sec_grid1',mc_grid_idio1);
mc_grid2   = W2*kron(sec_grid2',mc_grid_idio2*exp(ice));

g_p_alt = 0*g_p;

sec_mc_dens1 = sec_dens'*mc_dens1;
sec_mc_dens2 = sec_dens'*mc_dens2;

xx  = linspace(-250,250,250);
yy  = exp(xx);

%******************************************************************
% UPDATE PRODUCER PRICES
%******************************************************************
for ss = 1:nsec
    
    %Markup in sector
    eta_ss   = eta*dem_grid(ss);
    mu_ss    = eta_ss/(eta_ss-1);
    
    %******************************************************************
    % UPDATE FIRM PRICING CHOICES
    %******************************************************************
    
    %Demand
    dem_per = (mu_ss.*pc_grid).^-eta_ss*p_i(ss)^(eta_ss-rho)*PT^rho*CT; %units per retailer
    dem_com = (dem_per.*chi(ss).*g_p(ss,:))';   %times total retailers per producer time % of retailers accepting this price
    
    %Profit for producer selling at price/mc grid point
    profit_grid1 = (pc_grid' - mc_grid1(ss,:)).*dem_com;
    profit_grid2 = (pc_grid' - mc_grid2(ss,:)).*dem_com;
    
    
    if lam.lam1>0
        %If smoothing shutdown choice, a little penalty for opening and
        %selling 0.
        expp1 = exp((profit_grid1- m1*.001)./lam.lam1);
        expp2 = exp((profit_grid2- m1*.001)./lam.lam1);
        
        
        open1_new = (1+1./expp1).^-1;
        open2_new = (1+1./expp2).^-1;
    else
        % no smoothing
        
        open1_new = (profit_grid1>0);
        open2_new = (profit_grid2>0);
    end
    
    ro = .5;
    open1 = ro*open1_new + (1-ro)*open1_orig(:,:,ss);
    open2 = ro*open2_new + (1-ro)*open2_orig(:,:,ss);
    
    open1_orig(:,:,ss)=open1;
    open2_orig(:,:,ss)=open2;
    
    
    pg1tmp = profit_grid1;
    pg2tmp = profit_grid2;
    
    profit_grid1 = profit_grid1.*open1;
    profit_grid2 = profit_grid2.*open2;
    
    %starting density at price/mc grid point; since eta iid, past price dists combine
    fpfc1_init = f_p1'*sec_mc_dens1;
    fpfc2_init = f_p2'*sec_mc_dens2;
    
    %Solve firm's value function given guess about future values
    diffv = 1;
    ctrv  = 1;
    bet   = 0.98;
    
    tauw1  = tauw*m1; %units of labor to change price, based on sales volume
    tauw2  = tauw*m1; %units of labor to change price, based on sales volume
    
    while diffv > 1e-12 && ctrv<3
        
        %Value of any inherited price given an mc
        V1 = profit_grid1 + bet*(V1prime*sec_dens');
        V2 = profit_grid2 + bet*(V2prime*sec_dens');
        
        %Value of resetting price for each mc
        [V1reset, idxmax1] = max(V1);
        [V2reset, idxmax2] = max(V2);
        
        %Optimal reset choice
        V1opt = max(V1,V1reset-tauw1);
        V2opt = max(V2,V2reset-tauw2);
        
        %Next period value (assumes everything is iid)
        V1prime_new       = V1opt*mc_dens1';
        V2prime_new       = V2opt*mc_dens2';
        
        %Updating
        diffv = max(max(max(abs(V1prime_new-V1prime(:,ss)))),max(max(abs(V2prime_new-V2prime(:,ss)))));
        V1prime(:,ss) = V1prime_new;
        V2prime(:,ss) = V2prime_new;
        
        ctrv = ctrv+1;
    end
    
    p_ij1(ss,:) = pc_grid(idxmax1);
    p_ij2(ss,:) = pc_grid(idxmax2);
    
    
    %% Smooth reset probs
    if lam.lam2>0
        dd1 = exp((V1reset-V1-tauw1)./lam.lam2);
        dd2 = exp((V2reset-V2-tauw2)./lam.lam2);
        
        reset1_idx = (1+1./dd1).^-1;
        reset2_idx = (1+1./dd2).^-1;
    else
        %change price?
        reset1_idx  = V1reset-V1 >= tauw1;
        reset2_idx  = V2reset-V2 >= tauw2;
    end
    
    %**************************************************************************
    % Tracking price changers/stayers
    %**************************************************************************
    
    %% No smoothing
    
    %update densities - start with stayers
    fpfc1_stay = fpfc1_init.*(1-reset1_idx);
    fpfc2_stay = fpfc2_init.*(1-reset2_idx);
    
    %count resetters
    reset_dens1 = sum(fpfc1_init.*reset1_idx);
    reset_dens2 = sum(fpfc2_init.*reset2_idx);
    
    %track optimal reset prices for each mc
    log1 = (0:np:(ngrid1-1)*np)+idxmax1;
    log2 = (0:np:(ngrid2-1)*np)+idxmax2;
    
    fpfc1_new = fpfc1_stay;
    fpfc2_new = fpfc2_stay;
    
    %new np-by-ngrid density: stayers and resetters
    fpfc1_new(log1) = fpfc1_new(log1)  + reset_dens1;
    fpfc2_new(log2) = fpfc2_new(log2)  + reset_dens2;
    
    
    %**************************************************************************
    % RI smoother on choice of reset price
    %**************************************************************************
    
    if lam.lam3>0 && gg>150
        
        pigr1 = V1;
        pigr2 = V2;
        
        pigr1 = demean(pigr1);
        pigr2 = demean(pigr2);
        
        expP1        = exp(pigr1./lam.lam3);
        
        
        den1         = sum(expP1);
        fpfc1_change = (expP1./den1).*reset_dens1;
        
        if sum(isinf(den1))>0
            % warning('Pexp in play')
            fpfc1_change = pexp(pigr1,lam.lam3).*reset_dens1;
        end
        
        expP2        = exp(pigr2./lam.lam3);
        
        den2         = sum(expP2);
        fpfc2_change = (expP2./den2).*reset_dens2;
        
        if sum(isinf(den2))>0
            % warning('Pexp in play')
            fpfc2_change = pexp(pigr2,lam.lam3).*reset_dens2;
        end
        fpfc1_new = fpfc1_stay+fpfc1_change;
        fpfc2_new = fpfc2_stay+fpfc2_change;
        
    end
    
    
    %%
    
    %**************************************************************************
    % Tracking active/inactive
    %**************************************************************************
    
    %density among active
    fpfc1_act = fpfc1_new.*open1;
    fpfc2_act = fpfc2_new.*open2;
    
    active1(ss) = sum(fpfc1_act(:));
    active2(ss) = sum(fpfc2_act(:));
    
    fpfc1_act = fpfc1_act/active1(ss);
    fpfc2_act = fpfc2_act/active2(ss);
    
    f1_act = sum(fpfc1_act,2);
    f2_act = sum(fpfc2_act,2);
    
    %**************************************************************************
    % Price distribution faced by consumers
    %**************************************************************************
    
    %prob retailer draws a home firm
    p_home = m1*active1(ss)/(m1*active1(ss)+m2*active2(ss));
    reset_frac(ss) = sum((m1*reset_dens1 + m2*reset_dens2)/(m1+m2)); %Note this includes inactive firms
    
    %Density of sampled producers
    f_p1(ss,:) =  f1_act;
    f_p2(ss,:) =  f2_act;
    f_p(ss,:)  = (p_home*f1_act + (1-p_home)*f2_act)';
    
    
    
    %Density of accepted producers
    f_a     = m1*active1(ss)*f1_act'.*g_p(ss,:) + m2*active2(ss)*f2_act'.*g_p(ss,:);
    chi(ss) = s1/sum(f_a); %Update chi: retailer mass so that each retailer purchases from 1 producer
    f_a     = f_a/sum(f_a);
    
    %prob I encounter a firm from each MC grid point (used to compute moments
    %later)
    prob(1:ngrid1)     = m1*active1(ss)*sum(fpfc1_act);
    prob(ngrid1+1:end) = m2*active2(ss)*sum(fpfc2_act);
    prob               = prob/sum(prob);
    prob_all(ss,:)     = prob;
    %**************************************************************************
    % Aggregate outcomes
    %**************************************************************************
    
    pc_dem = pc_grid.*dem_com';
    
    %Profits for active firms
    pi_i1(ss) = m1*active1(ss)*sum(sum(fpfc1_act.*pg1tmp));
    pi_i2(ss) = m2*active2(ss)*sum(sum(fpfc2_act.*pg2tmp));
    
    %Total labor used by producers
    l_i1(ss) = m1*active1(ss)*(sum(fpfc1_act.*dem_com)*mc_grid1(ss,:)')./W1;
    l_i2(ss) = m2*active2(ss)*(sum(fpfc2_act.*dem_com)*mc_grid2(ss,:)')./W2;
    
    %Total domestic sales/imports
    doms(ss)    = m1*active1(ss)*pc_dem*f_p1(ss,:)';
    imports(ss) = m2*active2(ss)*pc_dem*f_p2(ss,:)';
    
    %Retail-level profits corresponding to sales of each producer
    %size(pc_grid'.*dem_com)
    piret_i(ss)  = (mu_ss-1)*(doms(ss)+imports(ss));
    
    %Consumer's indecies
    c_i(ss) = sum((dem_per).^((eta_ss-1)/eta_ss).*f_a)^(eta_ss/(eta_ss-1));
    p_i(ss) = sum((mu_ss*pc_grid).^(1-eta_ss).*f_a)^(1/(1-eta_ss));
    
    
end

%******************************************************************
% UPDATE RESEVATION PRICES
%******************************************************************
for ss = 1:nsec
    
    %Markup in sector
    eta_ss  = eta*dem_grid(ss);
    mu_ss   = eta_ss/(eta_ss-1);
    
    %Profits for any given draw of price
    pi = (mu_ss-1)*pc_grid.^(1-eta_ss)*mu_ss^-eta_ss*p_i(ss)^(eta_ss-rho)*PT^rho*CT;  %Retailer profits, conditonal on accepting
    
    %Value of profit if I search again
    %(assuming I will not search after that.)
    ev     = sum(f_p(ss,:).*pi);
    ev_go  = repmat(ev,[1,nkp]);
    v_stay = repmat(pi(:), [1,nkp]);
    kp_tmp = repmat(W1*kap.*kp_grid,[np,1]);
    
    diffev = 1;
    jj = 0;
    while diffev>1e-12 && jj < 250
        v         = max(v_stay,ev_go-kp_tmp);
        ev_go_new = f_p(ss,:)*v*kp_dens';
        diffev    = max(abs(ev_go_new-ev_go));
        ev_go     = ev_go_new;
        jj        = jj+1;
    end
    
    stay_idx = v_stay>=(ev_go-kp_tmp);
    ev = ev_go;
    
    if lam.lam4>0
        tmp=v_stay-ev_go+kp_tmp;
        expv=exp(tmp./lam.lam4);
        stay_idx = (1 + 1./expv).^-1;
    end
    
    %Fraction who would stay with each price
    g_p_alt(ss,:) = sum(repmat(kp_dens,[np,1]).*stay_idx,2)';
    
    %Solve indifference equations for reservation price
    pr_i(ss,:) = ((ev-W1*kap.*kp_grid)./((mu_ss-1)*mu_ss^-eta_ss*p_i(ss).^(eta_ss-rho).*PT.^rho.*CT)).^(1/(1-eta_ss));
    
    %Impose maximum for reservation price (relevant off equilibrium only)
    pr_i(ss, (ev-W1*kap.*kp_grid) < 0 ) = 5;
    
    for kk = 1:nkp
        tmp_idx = find(pr_i(ss,kk)>pc_grid, 1, 'last');
        
        if ~isempty(tmp_idx)
            pr_idx(ss,kk) = tmp_idx;
        else
            pr_idx(ss,kk) = length(pc_grid);
        end
    end
end



%Third step in GE: update aggregates
L1         = l_i1*sec_dens';     %Labor demand of domestic producers
L2         = l_i2*sec_dens';     %Labor demand of foreign producers for their exports
LT         = L1 + L_for;              %Aggregate labor in traded
IMP        = imports*sec_dens';  %Aggregate imports;
PI1        = pi_i1*sec_dens';   %Producer profits from domestic sales
PI2        = pi_i2*sec_dens';   %Foreign producers profits from sales in home country
PI_RET     = piret_i*sec_dens';   %Retailers profits from sales in home country
rfrac      = reset_frac*sec_dens'; %Average prob of resetting price

%Traded values
PT_new     = sum(p_i.^(1-rho).*sec_dens).^(1/(1-rho));
CT         = Mbar*phit/PT;  %Per-capita CT, from money velocity relation

%Non-traded, competatitve sector
PN = W1;
CN = (1-phit)*Mbar/PN;     %Per-capita
LN = CN/Abar;              %Per-capita

%Total labor
LTOT  = LT + s1*LN;        %Aggregate labor

%Update aggregate wage
W1 = mu_w*Wss + (1-mu_w)*psii*(LTOT/s1)^(1/zet)*CT*PT/phit;

%Check outer convergence
crit_outer = max(abs(PT_new-PT));
PT = PT_new;

