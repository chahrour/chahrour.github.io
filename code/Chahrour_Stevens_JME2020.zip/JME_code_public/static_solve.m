
tic


%%
%Parameters
if ~exist('print_mom', 'var') || (exist('print_mom', 'var') && print_mom==true)   
    disp('Using loaded parameters')
    param = parameters;
end

param_unpack;
mu1 = eta1/(eta1-1);
mu2 = eta2/(eta2-1);

%Producer-level idiosyncratic cost grids (asymetric)
[mc_grid_idio1,mc_dens1] = lognorm_grid(exp(mean_mc),sd_mc1,ngrid,nsd);
[mc_grid_idio2,mc_dens2] = lognorm_grid(exp(mean_mc),sd_mc2,ngrid,nsd);

%Good-level elasticity of demand grid (symmetric for home and foreign)
[agrid1_dm,pa1] = herm_grid(1,sd_sec1,sqrt(nsec));
[agrid2_dm,pa2] = herm_grid(1,sd_sec2,sqrt(nsec));

dem_grid1 = repmat(agrid1_dm,[sqrt(nsec),1]); dem_grid1 = dem_grid1(:)';
dem_grid2 = repmat(agrid2_dm,[1,sqrt(nsec)]);
sec_dens = kron(pa1,pa1);
sec_grid1 = 0*dem_grid1+1;
sec_grid2 = 0*dem_grid2+1;

%Aggregate money shocks (symmetric)
[mgrid1_dm, pw1] = AR1_rouwen(sqrt(nm),rho_m,mu_m,std_m);
mgrid1 = repmat(mgrid1_dm,[sqrt(nm),1]); mgrid1 = mgrid1(:)';
mgrid2 = repmat(mgrid1_dm,[1,sqrt(nm)]);
pw     = kron(pw1,pw1);
pw_bar = mean(pw^1000);

% Discrete price choice grid
[pc_grid,pc_dens] = lognorm_grid(W1ss,sd_mc1,np,4);
pc_dens = (1/np)+0*pc_dens;

%Density of prices for firms in C posting in C'
f_p11 = repmat_row(pc_dens,nsec);
f_p12 = repmat_row(pc_dens,nsec);
f_p21 = repmat_row(pc_dens,nsec);
f_p22 = repmat_row(pc_dens,nsec);

%Density from perspective of searchers
f_p1 = repmat_row(pc_dens,nsec);
f_p2 = repmat_row(pc_dens,nsec);

%Random search costs (not used in paper)
[kp_grid,kp_dens] = lognorm_grid(1,sigk,nk,2);

%% INITIALIZE THINGS

%Initialize vectors
W1       = 2*ones(1,nm);
W2       = 2*ones(1,nm);
LT1      = zeros(1,nm);
LT2      = zeros(1,nm);
C1       = zeros(1,nm);
C2       = zeros(1,nm);
MC_DOM1  = zeros(nsec,ngrid,nm);
MC_FOR1  = zeros(nsec,ngrid,nm);
P_DOM1   = zeros(nsec,ngrid,nm);
P_FOR1   = zeros(nsec,ngrid,nm);
PROB1    = zeros(nsec,2*ngrid,nm);

MC_DOM2   = zeros(nsec,ngrid,nm);
MC_FOR2   = zeros(nsec,ngrid,nm);
P_DOM2    = zeros(nsec,ngrid,nm);
P_FOR2    = zeros(nsec,ngrid,nm);
PROB2     = zeros(nsec,2*ngrid,nm);
chi_stat1 = zeros(1,nm);
chi_stat2 = zeros(1,nm);

%initialize reservation price indexes
pr1_idx  = zeros(nsec,nk);
pr2_idx  = zeros(nsec,nk);

pr1  = 1.4*mu1*W1(1)*ones(nsec,1);
pr2  = 1.4*mu2*W2(1)*ones(nsec,1);

pr1_idx(:)  = find(pc_grid<pr1(1),1,'last');
pr2_idx(:)  = find(pc_grid<pr2(1),1,'last');

PN1 = zeros(1,nm);
PN2 = zeros(1,nm);
IMP1 = zeros(1,nm);
IMP2 = zeros(1,nm);

LTOT1 = zeros(1,nm);
LTOT2 = zeros(1,nm);

PI1 = zeros(1,nm);
PI2 = zeros(1,nm);

PI1_for = zeros(1,nm);
PI2_for = zeros(1,nm);

PI1_RET = zeros(1,nm);
PI2_RET = zeros(1,nm);
imp_shrtmp1 = zeros(1,nm);
imp_shrtmp2 = zeros(1,nm);

pr_i1_tmp = zeros(nm,nsec);
p_i1_tmp = zeros(nm,nsec);
c_i1_tmp = zeros(nm,nsec);
W1_tmp     = zeros(1,nm);
CT1_tmp    = zeros(1,nm);
PT1_tmp    = zeros(1,nm);
L2_for_tmp= zeros(1,nm);

pr_i2_tmp = zeros(nm,nsec);
p_i2_tmp = zeros(nm,nsec);
c_i2_tmp = zeros(nm,nsec);
W2_tmp     = zeros(1,nm);
CT2_tmp    = zeros(1,nm);
PT2_tmp    = zeros(1,nm);
L1_for_tmp= zeros(1,nm);

stay_rate1 = zeros(nsec,nk);
stay_rate2 = zeros(nsec,nk);

mean_go1 = zeros(1,nsec);
mass_tot1 = zeros(1,nsec);

mean_go2 = zeros(1,nsec);
mass_tot2 = zeros(1,nsec);

exch = zeros(1,nm);

reset_idx = zeros(np,ngrid,nsec,4);

%Output arguments to use for moment calcs
W1out    = NaN(1,nm);
LT1out   = NaN(1,nm);
PT1out   = NaN(1,nm);
CT1out   = NaN(1,nm);
imp_shr1 = NaN(1,nm);
W2out    = NaN(1,nm);
LT2out   = NaN(1,nm);
PT2out   = NaN(1,nm);
CT2out   = NaN(1,nm);
imp_shr2 = NaN(1,nm);
crit2    = NaN(1,nm);

%Setting up loop to solve symmetric steady-state first
cntr = 1:nm;
mid = find((abs(mgrid1)+abs(mgrid2))==0);
cntr(mid) =[];
cntr = [mid,cntr];
mgrid1 = mgrid1(cntr);
mgrid2 = mgrid2(cntr);
pw     = pw(cntr,cntr);
pw_bar = pw_bar(cntr);

% Intialize first step GE quantities

%Good-level price indexes (higher level agg.)
p_i1   = mu1^2*W1ss*ones(1,nsec);
p_i2   = mu2^2*W2ss*ones(1,nsec);

%Good level consumption indexes
c_i1   = .25*ones(1,nsec);
c_i2   = .25*ones(1,nsec);


CT1    = .3;
CN1    = .3;

CT2    = .3;
CN2    = .3;

%Aggregate price index
PT1      = mu1^2*W1ss;
PT2      = mu2^2*W2ss;

%Labor usage index
L1_for   = .25*.4;
L2_for   = .25*.4;

W1 = 2;
W2 = 2;

Vprime = zeros(np,nsec,4);

%frac of firms active in each coutry
active = ones(4,nsec);
rfrac1 = zeros(1,nm);
rfrac2 = zeros(1,nm);

%% SOLVE STEADY-STATE FIRST
mm   = 1;%mid;
mu_w = 0;
Mbar1 = exp(mgrid1(mm));
Mbar2 = exp(mgrid2(mm));

exch_tmp = Mbar1/Mbar2;
[P_DOM1(:,:,mm), P_DOM2(:,:,mm), P_FOR1(:,:,mm), P_FOR2(:,:,mm), PROB1(:,:,mm), PROB2(:,:,mm),...
    MC_DOM1(:,:,mm), MC_FOR1(:,:,mm), MC_DOM2(:,:,mm), MC_FOR2(:,:,mm),...
    exch(mm),active,Vprime,reset_idx,...
    pr1_idx,f_p1,f_p11,f_p12,p_i1,c_i1,CN1,L1_for,PI1(mm), PI1_for(mm),W1out(mm),LT1out(mm),PT1out(mm),CT1out(mm),LTOT1(mm),imp_shr1(mm),rfrac1(mm),g_p1,chi1,...
    pr2_idx,f_p2,f_p22,f_p21,p_i2,c_i2,CN2,L2_for,PI2(mm), PI2_for(mm),W2out(mm),LT2out(mm),PT2out(mm),CT2out(mm),LTOT2(mm),imp_shr2(mm),rfrac2(mm),g_p2,chi2,walras_check,gg,crit2(mm)]...
    = ge_iter(...
    pr1_idx,f_p1,f_p11,f_p12,p_i1,c_i1,CN1,L1_for,CT1,PT1,sec_grid1,dem_grid1,mc_grid_idio1,mc_dens1,eta1,Mbar1,kap1,s1,alph1,W1,W1ss,...
    pr2_idx,f_p2,f_p22,f_p21,p_i2,c_i2,CN2,L2_for,CT2,PT2,sec_grid2,dem_grid2,mc_grid_idio2,mc_dens2,eta2,Mbar2,kap2,s2,alph2,W2,W2ss,...
    active,Vprime,reset_idx,...
    kp_grid,pc_grid,kp_dens,sec_dens,rho,phit,zet,psii,mu_w,ice,veps,tauw1,tauw2,pw_bar,exch_tmp,...
    converg,maxiter,lam);

%Consumption
CT1    = CT1out(mm);
CT2    = CT2out(mm);

%Aggregate price index
PT1      = PT1out(mm);
PT2      = PT2out(mm);

W1       = W1out(mm);
W2       = W2out(mm);
exch_tmp = exch(mm);
W1ss     = W1;
W2ss     = W2/exch(mm);

%If agg shocks
mu_w = param.mu_w;
parfor mm = 2:nm
    

    %For each aggregate state
    Mbar1 = exp(mgrid1(mm));
    Mbar2 = exp(mgrid2(mm));
    
    exch_tmp = Mbar1/Mbar2;
    
    %% Main Solution Step
    %{
        [P_DOM1(:,:,mm), P_DOM2(:,:,mm), P_FOR1(:,:,mm), P_FOR2(:,:,mm), PROB1(:,:,mm), PROB2(:,:,mm),...
            MC_DOM1(:,:,mm), MC_FOR1(:,:,mm), MC_DOM2(:,:,mm), MC_FOR2(:,:,mm),...
            exch(mm),active,Vprime,reset_idx,...
            pr1_idx,f_p1,f_p11,f_p12,p_i1,c_i1,CN1,L1_for,PI1(mm), PI1_for(mm),W1out(mm),LT1out(mm),PT1out(mm),CT1out(mm),imp_shr1(mm),rfrac1(mm),g_p1,chi1,...
            pr2_idx,f_p2,f_p22,f_p21,p_i2,c_i2,CN2,L2_for,PI2(mm), PI2_for(mm),W2out(mm),LT2out(mm),PT2out(mm),CT2out(mm),imp_shr2(mm),rfrac2(mm),g_p2,chi2,walras_check,gg,crit2(mm)]...
            = ge_iter(...
            pr1_idx,f_p1,f_p11,f_p12,p_i1,c_i1,CN1,L1_for,CT1,PT1,sec_grid1,dem_grid1,mc_grid_idio1,mc_dens1,eta1,Mbar1,kap1,s1,alph1,W1,W1ss,...
            pr2_idx,f_p2,f_p22,f_p21,p_i2,c_i2,CN2,L2_for,CT2,PT2,sec_grid2,dem_grid2,mc_grid_idio2,mc_dens2,eta2,Mbar2,kap2,s2,alph2,W2,W2ss,...
            active,Vprime,reset_idx,...
            kp_grid,pc_grid,kp_dens,sec_dens,rho,phit,zet,psii,mu_w,ice,veps,tauw1,tauw2,pw_bar,exch_tmp,...
            converg,maxiter,lam);
    %}
    [P_DOM1(:,:,mm), P_DOM2(:,:,mm), P_FOR1(:,:,mm), P_FOR2(:,:,mm), PROB1(:,:,mm), PROB2(:,:,mm),...
        MC_DOM1(:,:,mm), MC_FOR1(:,:,mm), MC_DOM2(:,:,mm), MC_FOR2(:,:,mm),...
        exch(mm),~,~,~,...
        ~,~,~,~,~,~,~,~,PI1(mm), PI1_for(mm),W1out(mm),LT1out(mm),PT1out(mm),CT1out(mm),LTOT1(mm),imp_shr1(mm),rfrac1(mm),g_p1,chi1,...
        ~,~,~,~,~,~,~,~,PI2(mm), PI2_for(mm),W2out(mm),LT2out(mm),PT2out(mm),CT2out(mm),LTOT2(mm),imp_shr2(mm),rfrac2(mm),g_p2,chi2,walras_check,gg,crit2(mm)]...
        = ge_iter(...
        pr1_idx,f_p1,f_p11,f_p12,p_i1,c_i1,CN1,L1_for,CT1,PT1,sec_grid1,dem_grid1,mc_grid_idio1,mc_dens1,eta1,Mbar1,kap1,s1,alph1,W1,W1ss,...
        pr2_idx,f_p2,f_p22,f_p21,p_i2,c_i2,CN2,L2_for,CT2,PT2,sec_grid2,dem_grid2,mc_grid_idio2,mc_dens2,eta2,Mbar2,kap2,s2,alph2,W2,W2ss,...
        active,Vprime,reset_idx,...
        kp_grid,pc_grid,kp_dens,sec_dens,rho,phit,zet,psii,mu_w,ice,veps,tauw1,tauw2,pw_bar,exch_tmp,...
        converg,maxiter,lam);
     
    %% Initialize next round
    % CT1    = CT1out(mm);
    % CT2    = CT2out(mm);
    
    %Aggregate price index
    % PT1      = PT1out(mm);
    % PT2      = PT2out(mm);
    
    %Labor usage index
    % W1       = W1out(mm);
    % W2       = W2out(mm);
    % exch_tmp = exch(mm);
    
    %Update steady-state wage
    if mm == mid
        %    W1ss = W1;
        %    W2ss = W2/exch(mm);
    end
    
end

MU1 = (PI1+PI1_for)./(W1out.*LT1out);
MU2 = (PI2+PI2_for)./(W2out.*LT2out);
KSHR1 = kap1*W1out./(PT1out.*CT1out);
KSHR2 = kap2*W2out./(PT2out.*CT2out);

