function [out,out2]= quick_sim_moment(f_p11,f_p21,f_p12,f_p22,pc_grid,sec_dens)

f_p11 = max(f_p11,0);
f_p12 = max(f_p12,0);
f_p21 = max(f_p21,0);
f_p22 = max(f_p22,0);

np = size(f_p11,2);
nsec = 4;


rng(2000);

nt       = 500;
nps      = 500;

Pus_us1 = nan(nt,nps);
Pus_us2 = nan(nt,nps);

Pus_ca1 = nan(nt,nps);
Pus_ca2 = nan(nt,nps);

Pca_us1 = nan(nt,nps);
Pca_us2 = nan(nt,nps);

Pca_ca1 = nan(nt,nps);
Pca_ca2 = nan(nt,nps);

%Generate random sample of prices
for tt = 1:nt
    
    %Random sector
    sec_us = randsample(1:nsec,nps,true,sec_dens);
    sec_ca = randsample(1:nsec,nps,true,sec_dens);
    
    for ss = 1:nsec
        
        sidx_us = sec_us==ss;
        sidx_ca = sec_ca==ss;
        
    
        %Random price from that sector
        tmp_us_us1 = randsample(1:np,sum(sidx_us),true,f_p11(ss,:));
        tmp_us_us2 = randsample(1:np,sum(sidx_us),true,f_p11(ss,:));
        
        tmp_us_ca1 = randsample(1:np,sum(sidx_ca),true,f_p21(ss,:));
        tmp_us_ca2 = randsample(1:np,sum(sidx_ca),true,f_p21(ss,:));
        
        tmp_ca_us1 = randsample(1:np,sum(sidx_us),true,f_p12(ss,:));
        tmp_ca_us2 = randsample(1:np,sum(sidx_us),true,f_p12(ss,:));
       
        tmp_ca_ca1 = randsample(1:np,sum(sidx_ca),true,f_p22(ss,:));
        tmp_ca_ca2 = randsample(1:np,sum(sidx_ca),true,f_p22(ss,:));
        
        
       
        
        Pus_us1(tt,sidx_us) = log(pc_grid(tmp_us_us1));
        Pus_us2(tt,sidx_us) = log(pc_grid(tmp_us_us2));
        
        
        Pus_ca1(tt,sidx_ca) = log(pc_grid(tmp_us_ca1));
        Pus_ca2(tt,sidx_ca) = log(pc_grid(tmp_us_ca2));
        
        
        Pca_us1(tt,sidx_us) = log(pc_grid(tmp_ca_us1));
        Pca_us2(tt,sidx_us) = log(pc_grid(tmp_ca_us2));
        
        
        Pca_ca1(tt,sidx_ca) = log(pc_grid(tmp_ca_ca1));
        Pca_ca2(tt,sidx_ca) = log(pc_grid(tmp_ca_ca2));
        

    end
end

%compute relative prices (keeps sample size
%the same across cases)
rer_us_us      = diff(Pus_us1-Pus_us2);
rer_us_ca      = diff(Pus_ca1-Pus_ca2);
rer_us_ca_bord = diff(Pus_us1-Pus_ca1);

rer_ca_ca      = diff(Pca_ca1-Pca_ca2);
rer_ca_us      = diff(Pca_us1-Pca_us2);
rer_ca_us_bord = diff(Pca_ca1-Pca_us1);

%moments
pus_mean = mean(Pus_us1(:));
pca_mean = mean(Pca_ca1(:));

%sd rers
sd_us_us   = std(rer_us_us(:));
sd_us_ca   = std(rer_us_ca(:));
sd_us_ca_b = std(rer_us_ca_bord(:));

sd_ca_ca   = std(rer_ca_ca(:));
sd_ca_us   = std(rer_ca_us(:));
sd_ca_us_b = std(rer_ca_us_bord(:));

rho_dp_us_us      = mean(diag(corr(diff(Pus_us1),diff(Pus_us2))));
rho_dp_us_ca      = mean(diag(corr(diff(Pus_ca1),diff(Pus_ca2))));
rho_dp_us_ca_bord = mean(diag(corr(diff(Pus_us1),diff(Pus_ca2))));

rho_dp_ca_ca = mean(diag(corr(diff(Pca_ca1),diff(Pca_ca2))));
rho_dp_ca_us = mean(diag(corr(diff(Pca_us1),diff(Pca_us2))));
rho_dp_ca_us_bord = mean(diag(corr(diff(Pca_ca1),diff(Pus_us2))));

out = [pus_mean, pca_mean, sd_us_us, sd_us_ca,sd_us_ca_b,...
                            sd_ca_us,sd_ca_ca,sd_ca_us_b  ];
                        
out2 = [rho_dp_us_us,rho_dp_us_ca,rho_dp_us_ca_bord,...
    rho_dp_ca_ca,rho_dp_ca_us,rho_dp_ca_us_bord];
                        