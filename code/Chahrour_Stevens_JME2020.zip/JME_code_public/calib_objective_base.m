function [out,param,mom_actual] = calib_objective_base(pvec,to_screen)

tic
param = parameters;
suffix = 'baseline';

param.alph1   = pvec(1);
param.alph2   = pvec(2);
param.kap1    = pvec(3);
param.kap2    = pvec(4);
param.sd_mc1  = pvec(5);
param.sd_mc2  = pvec(6); 
param.sd_sec1 = pvec(7); %Symmetryic demand shocks
param.sd_sec2 = pvec(7);
param.std_m   = pvec(8);
param.rho     = pvec(9);
param.eta1    = pvec(10);
param.eta2    = pvec(10);

print_mom = false;
static_solve
print_mom = false;
model_moments

out    = zeros(1,12);
out(1) = (u_imp1   - 0.021)/0.021;
out(2) = (u_imp2   - 0.175)/0.175;
out(3) = (u_std_de - 0.030)/0.030;
out(4) = (u_mu1_sales    - 0.148)/0.148;

out(5) = (u_std_dd1_1         - 0.08)/0.08;
out(6) = (u_std_dd2_1         - 0.06)/0.06;
out(7) = (u_std_dd_bord_USEXP - 0.13)/0.13; 

out(8)  = (u_std_dd1_2         - 0.10)/0.10;
out(9)  = (u_std_dd2_2         - 0.04)/0.04;
out(10) = (u_std_dd_bord_CAEXP - 0.17)/0.17;

out(11) = 100*(u_kshr1>.03)*(u_kshr1-.03)^2;
out(12) = 100*(u_kshr2>.03)*(u_kshr2-.03)^2;

out = 1000*imag(out) + real(out);

disp([num2str2(sum(10000*out.^2)), '||' sprintf('%1.2e ',crit2) '||' sprintf('%1.7f ', pvec)]);

%Print to screen?
if nargin>1 && to_screen == 2
print_mom = true;
model_moments
end