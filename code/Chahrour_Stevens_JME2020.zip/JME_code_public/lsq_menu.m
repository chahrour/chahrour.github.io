addpath('DSGE_tools')
nowstr = datestr(now,'yyyymmddTHHMMSS');
use_ml = 1;
ns     = 48;

%Bounds on parameters
lbnd = [.001 .001 .05 .05 .05  0   0 ];
ubnd = [.01  .01  .3  .3  .3  .01 .01 ];

%baseline parameters
param = parameters; 

%no aggregate shocks
param.nm = 1;


%No menu costs
param.tauw1 = 0.0;
param.tauw2 = 0.0;

param_unpack;
param0 = [kap1,kap2,sd_mc1,sd_mc2,sd_sec1,.0000,.000];
nms    = {'kap1', 'kap2', 'sd_mc1', 'sd_mc2', 'sd_sec1','tauw1','tauw2'};

print_mom = false;
static_solve
print_mom = true;

[mom_target]   = quick_sim_moment(f_p11,f_p21,f_p12,f_p22,pc_grid,sec_dens);
mom_target(9)  = 1/3;
mom_target(10) = 1/3;

%Get the baseline moments
calib_objective_menu(param0,mom_target,param, true);

%Slight blur on price change decision
param.lam.lam2 = 1*0.0001;

%The objective
obj = @(pvec) calib_objective_menu(pvec,mom_target,param);



%% Best parameters
xopt = [
   0.004084634427195
   0.008650454909950 
   0.139098795199805
   0.106637951662183
   0.140611458918973
   0.001516850646929
   0.002939981947845];
param0 = xopt;

%% Run the search

%Nolinear solver
options = optimoptions('lsqnonlin');
options.TolX = 1e-4;
options.TolFun = 1e-5;
options.Display = 'iter';
options.MaxFunctionEvaluations = 150;
options.UseParallel = true;
options.FiniteDifferenceStepSize = .001*(ubnd-lbnd);

[pout, vml, ~, flag]= lsqnonlin(obj,param0,lbnd,ubnd,options);


%% Display moment using saved parameter values (run first cell to get mom_target)
load popt_menu
[~,param_opt,mom_opt] = calib_objective_menu(popt_menu,mom_target,param, true);
