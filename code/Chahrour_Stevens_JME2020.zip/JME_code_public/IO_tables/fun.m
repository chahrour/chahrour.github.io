%MAPPING TOOLBOX REQUIRED: JUST CHECKING THE REGIONS MAKE SENSE.

lat = rand(1,100)*100;
lon = rand(1,100)*100;
temp = rand(1,100)*20;
load coastlines;
worldmap world
plot3m(coastlat,coastlon,.01,'k','LineWidth', 1.5)
gridm('GLineStyle','-','Gcolor',[.7 .7 .7],'Galtitude',.02)
hold on

miami_lat = 25.7617;
miami_lon = 80.1918;
scatterm(miami_lat,-miami_lon,30, temp(1), 'filled');

scatterm(usa_loc(:,1),usa_loc(:,2),30,'filled');
scatterm(ca_loc(:,1),ca_loc(:,2),30,'filled');
