function out = sub_rowsum(X,idx,option)

nout = length(unique(idx));
out = zeros(nout,size(X,2));

for jj = 1:nout
    idx_tmp = (idx==jj);
    
    if nargin ==2 || strcmp(option, 'sum')
        %Just sum
        out(jj,:) =  sum(X(idx_tmp,:),1);
    else
        %Average
        out(jj,:)  =  nansum(X(idx_tmp,:),1)./sum(~isnan(X(idx_tmp,:)),1);
    end
end