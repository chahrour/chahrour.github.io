function out = dperms(N)


out = [0,1]';

for jj = 1:N-1
    out_old = out;
    out = [zeros(2^jj,1),out_old; ones(2^jj,1), out_old];
end

   