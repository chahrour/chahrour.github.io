%% Define regions and locations
[regions,~,c] = xlsread('city_locations.xlsx', 'us_state_region_listing');
%get lat-long for each region
c2 = c(2:end,5:6);
c_loc = zeros(size(c2));
for jj = 1:length(c2(:))
    c_loc(jj) = str2num(c2{jj}(1:end-1));
end
c_loc = sub_rowsum(c_loc,regions,'average');
c_loc(:,2) = -c_loc(:,2);

%% The rest
[dat,b] = xlsread('US_trade_flows.xlsx', 'main');
dat = dat(:,2:end);  %Drop the column of row sums 
dat = sub_rowsum(dat,regions);  %Combine rows to regions
io_comb = sub_rowsum(dat',regions)';%Combine cols to regions


