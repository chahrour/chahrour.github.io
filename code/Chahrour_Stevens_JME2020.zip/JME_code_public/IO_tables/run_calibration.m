%Restriction on relative sizes
size_limit = .1; 



splits = logical(dperms(length(io_comb)));
ns = length(splits);

phia = nan(1,ns);
dist = nan(1,ns);

%Drob Quebec for CA case?
%splits(:,6) = -1;


national_internal_demand = sum(sum(io_comb));
for jj = 1:length(splits)
    region1 = splits(jj,:)==1;
    region2 = splits(jj,:)==0;
    
    if sum(region1)>0 && sum(region2)>0
        region1_supply = sum(sum(io_comb(region1,:)));
        region2_supply = sum(sum(io_comb(region2,:)));
        
        region1_loc = mean(c_loc(region1,:),1);
        region2_loc = mean(c_loc(region2,:),1);
        
        %Total domestic supply, region 1, region 2
        S1 = sum(sum(io_comb(region1,:)));
        S2 = sum(sum(io_comb(region2,:)));
        rel_size = S1/S2;
        
        %Total supply of each region to region 1
        r1_to_r1 = sum(sum(io_comb(region1,region1)));
        r2_to_r1 = sum(sum(io_comb(region2,region1)));
        
        
        if abs(log(rel_size))<size_limit
            %Share of region 1 demand satisfied by domestic imports.
            phia(jj) = r2_to_r1/(r1_to_r1 + r2_to_r1);
            
            %matlab mapping toolbox
            %dist(jj) = distance('gc',region1_loc(1),region1_loc(2),region2_loc(1),region2_loc(2));
            
            %shareware from web (license included)
            dist(jj) = lldistkm(region1_loc,region2_loc);
        end
    end
end

dist = dist(~isnan(phia));
phia = phia(~isnan(phia));
