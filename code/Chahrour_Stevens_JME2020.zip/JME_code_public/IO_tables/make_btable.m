
veps = 1;

%Scaling experiment
scl_phi = 1.2;

%**************************************************************************
% Get B2s
%**************************************************************************
can_calib
run_calibration
dist_ca     = dist;
phia_ca     = phia;
bet2_ca     = phia_ca./(1-phia_ca);
bet2_ca_alt = scl_phi*phia_ca./(1-scl_phi*phia_ca);

us_calib
run_calibration
dist_us = dist;
phia_us = phia;
bet2_us = phia_us./(1-phia_us);
bet2_us_alt = scl_phi*phia_us./(1-scl_phi*phia_us);

%**************************************************************************
% CA case
%**************************************************************************

sA = 1;
sB = 8;
alph = 0.87107390; %US firms licensed to post in CA
chistat = (alph*(sA*sB)/((sA^(1/veps)+sB^(1/veps))^veps))/sA;   %Ratio of active US firms exporting to CA to CA firms selling Domestically
dmatch = (sA*sA)/((sA^(1/veps)+sA^(1/veps))^veps);
fmatch = (sB*sA)/((sA^(1/veps)+sB^(1/veps))^veps);

bet3_us = .5*chistat*dmatch*(1+bet2_ca)/fmatch;
bet3_us_alt = .5*chistat*dmatch*(1+bet2_ca_alt)/fmatch;

bet3_us - alph*(1+bet2_ca)./4;
%**************************************************************************
% US case
%**************************************************************************

sA = 8;
sB = 1;
alph = 0.26679110; %CA firms licensed to post in US
chistat = (alph*(sA*sB)/((sA^(1/veps)+sB^(1/veps))^veps))/sA;   %Ratio of active for firms to dom firms
dmatch = (sA*sA)/((sA^(1/veps)+sA^(1/veps))^veps);
fmatch = (sB*sA)/((sA^(1/veps)+sB^(1/veps))^veps);

%Value of phia needed for bet2/bet3 = 2
bet3_ca = .5*chistat*dmatch*(1+bet2_us)/fmatch;
bet3_ca_alt = .5*chistat*dmatch*(1+bet2_us_alt)/fmatch;


bet3_ca - alph*(1+bet2_us)./4;


%**************************************************************************
% Make tables
%**************************************************************************

bet_tabl_us = [[median(bet2_us), min(bet2_us), max(bet2_us)];[median(bet3_us), min(bet3_us), max(bet3_us)]];
bet_tabl_ca = [[median(bet2_ca), min(bet2_ca), max(bet2_ca)];[median(bet3_ca), min(bet3_ca), max(bet3_ca)]];

bet_tabl_us_alt = [[median(bet2_us_alt), min(bet2_us_alt), max(bet2_us_alt)];[median(bet3_us_alt), min(bet3_us_alt), max(bet3_us_alt)]];
bet_tabl_ca_alt = [[median(bet2_ca_alt), min(bet2_ca_alt), max(bet2_ca_alt)];[median(bet3_ca_alt), min(bet3_ca_alt), max(bet3_ca_alt)]];

disp('US')
disp_num([median(bet2_us), min(bet2_us), max(bet2_us)]);
disp_num([median(bet3_us), min(bet3_us), max(bet3_us)]);
disp(' ');
disp('CA');
disp_num([median(bet2_ca), min(bet2_ca), max(bet2_ca)]);
disp_num([median(bet3_ca), min(bet3_ca), max(bet3_ca)]);
disp(' ');
disp('US Robust');
disp_num([median(bet2_us_alt), min(bet2_us_alt), max(bet2_us_alt)]);
disp_num([median(bet3_us_alt), min(bet3_us_alt), max(bet3_us_alt)]);
disp(' ');
disp('CA Robust');
disp_num([median(bet2_ca_alt), min(bet2_ca_alt), max(bet2_ca_alt)]);
disp_num([median(bet3_ca_alt), min(bet3_ca_alt), max(bet3_ca_alt)]);
disp(' ');


save ../figure_mfiles/bet_table_fixed bet_tabl*


%% Figure 
f1 = figure;
f1.PaperOrientation = 'landscape';
f1.PaperPosition = [0,0,8,4];
s = subplot(1,2,1);
scatter(dist_us,bet2_us, 'Marker','x'); hold on;
corr(dist_us',bet2_us');
coef_us = [ones(length(bet2_us'),1),dist_us']\(bet2_us');

dist_grid =[0:10:2000]';
plot(dist_grid, coef_us(1) + coef_us(2)*dist_grid, '-', 'linewidth', 2, 'color', [.5,.5,.5]);

text(1500,.39, 'R^2 = 0.140');
s.YTick = [.22:.03:.4];
xlabel('Distance in KM', 'Fontsize',12)
ylabel('Cross-region bias (\beta_{r2})', 'Fontsize',14)
title('US')


s= subplot(1,2,2);
coef_ca = [ones(length(bet2_ca'),1),dist_ca']\(bet2_ca');

scatter(dist_ca,bet2_ca, 'Marker','x'); hold on;

dist_grid =[0:10:2500]';
plot(dist_grid, coef_ca(1) + coef_ca(2)*dist_grid, '-','linewidth', 2, 'color', [.5,.5,.5]);
corr(dist_ca',bet2_ca')
text(2000,.16, 'R^2 = 0.018');
s.YTick = [.11:.01:.16];
title('CA')
saveas(f1, 'dist_scatter.eps', 'epsc')
