
%% Define regions and locations
[regions,~,c] = xlsread('city_locations.xlsx', 'canada_province_listing');
%get lat-long for each region
c2 = c(2:end,5:6);
c_loc = zeros(size(c2));
for jj = 1:length(c2(:))
    c_loc(jj) = str2num(c2{jj}(1:end-1));
end
c_loc = sub_rowsum(c_loc,regions,'average');
c_loc(:,2) = -c_loc(:,2);


%% The rest
[a,b] = xlsread('Interprovincial and International Trade Flows 2007-2011.xlsx', 'Goods_07');

%Full 13 province data
io = a(5:5+12,4:4+12);

%Combine Yukon,Northwest Ter., Nunavut (which are last three rows and cols)
io_comb = [io(1:10,1:10),sum(io(1:end-3,end-2:end),2); sum(io(end-2:end,1:end-3)), sum(sum(io(end-2:end,end-2:end)))];

