function  [P_DOM1, P_DOM2, P_FOR1, P_FOR2, PROB1, PROB2,...
    MC_DOM1, MC_FOR1, MC_DOM2, MC_FOR2,...
    exch,active,Vprime,reset_idx,...
    pr1_idx,f_p1,f_p11,f_p12,p_i1,c_i1,CN1,L1_for,PI1, PI1_for,W1,LT1,PT1,CT1,LTOT1,imp_shr1,rfrac1,g_p1,chi1,...
    pr2_idx,f_p2,f_p22,f_p21,p_i2,c_i2,CN2,L2_for,PI2, PI2_for,W2,LT2,PT2,CT2,LTOT2,imp_shr2,rfrac2,g_p2,chi2,...
    WALRAS_check1,gg,crit2]...
    = ge_iter(...
    pr1_idx,f_p1,f_p11,f_p12,p_i1,c_i1,CN1,L1_for,CT1,PT1,sec_grid1,dem_grid1,mc_grid_idio1,mc_dens1,eta1,Mbar1,kap1,s1,alph1,W1,W1ss,...
    pr2_idx,f_p2,f_p22,f_p21,p_i2,c_i2,CN2,L2_for,CT2,PT2,sec_grid2,dem_grid2,mc_grid_idio2,mc_dens2,eta2,Mbar2,kap2,s2,alph2,W2,W2ss,...
    active,Vprime,reset_idx,...
    kp_grid,pc_grid,kp_dens,sec_dens,rho,phit,zet,psii,mu_w,ice,veps,tauw1,tauw2,pw_bar,exch,...
    converg,maxiter,lam)

tic

nsec  = length(sec_dens);
ngrid = length(mc_grid_idio1);
nk    = length(kp_grid);
np    = length(pc_grid);
critv = zeros(1,maxiter);

%Thing to intialize inside:
for mm  = 1
    
    MC_DOM1  = zeros(nsec,ngrid);
    MC_FOR1  = zeros(nsec,ngrid);
    P_DOM1   = zeros(nsec,ngrid);
    P_FOR1   = zeros(nsec,ngrid);
    PROB1    = zeros(nsec,2*ngrid);
    
    MC_DOM2   = zeros(nsec,ngrid);
    MC_FOR2   = zeros(nsec,ngrid);
    P_DOM2    = zeros(nsec,ngrid);
    P_FOR2    = zeros(nsec,ngrid);
    PROB2     = zeros(nsec,2*ngrid);
    
    g_p1      = zeros(nsec,np);
    g_p2      = zeros(nsec,np);
    
    stay_rate1 = zeros(nsec,nk);
    stay_rate2 = zeros(nsec,nk);
    
    mean_go1  = zeros(1,nsec);
    mass_tot1 = zeros(1,nsec);
    
    mean_go2  = zeros(1,nsec);
    mass_tot2 = zeros(1,nsec);
    
    active11  = active(1,:);
    active12  = active(2,:);
    
    active22  = active(3,:);
    active21  = active(4,:);
    
    V11prime  = Vprime(:,:,1);
    V12prime  = Vprime(:,:,2);
    V22prime  = Vprime(:,:,3);
    V21prime  = Vprime(:,:,4);
    
    
    
    g_p1_new = 0*g_p1;
    g_p2_new = 0*g_p2;
    
    chi1 = zeros(1,nsec);
    chi2 = zeros(1,nsec);
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %START: Compute retailer distribution for each possible price
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Given f_p, what fraction of type k searchers will stay with you if charge price
    % p?
    
    for ss = 1:nsec
        for kk = 1:nk
            stay_rate1(ss,kk) = sum(f_p1(ss,1:pr1_idx(ss,kk)));
            stay_rate2(ss,kk) = sum(f_p2(ss,1:pr2_idx(ss,kk)));
        end
        
        mean_go1(ss)  = 1-sum(kp_dens.*stay_rate1(ss,:));  %Average change I search again
        mass_tot1(ss) = 1/(1-mean_go1(ss));              %Total number of searchers to visit each firm once
        
        mean_go2(ss)  = 1-sum(kp_dens.*stay_rate2(ss,:));  %Average change I search again
        mass_tot2(ss) = 1/(1-mean_go2(ss));              %Total number of searchers to visit each firm once
        
        for kk = 1:nk
            g_p1_new(ss,1:pr1_idx(ss,kk)) =  g_p1_new(ss,1:pr1_idx(ss,kk)) + kp_dens(kk);
            g_p2_new(ss,1:pr2_idx(ss,kk)) =  g_p2_new(ss,1:pr2_idx(ss,kk)) + kp_dens(kk);
        end
        
        %Retailers per active producer
        m1 = s1;
        m2 = alph1*s2*s1/((s1^(1/veps)+s2^(1/veps))^veps);
        chi1(ss) = s1/(m1*active11(ss) + m2*active12(ss));
        
        m1 = alph2*s1*s2/((s1^(1/veps)+s2^(1/veps))^veps);
        m2 = s2;
        chi2(ss) = s2/(m1*active22(ss) + m2*active21(ss));
        
    end
    g_p1 = g_p1_new;
    g_p2 = g_p2_new;
    
    
    
    
    
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %END: Compute retailer mass for each possible price
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
    open11 = ones(np,ngrid,nsec);
    open12 = ones(np,ngrid,nsec);
    open21 = ones(np,ngrid,nsec);
    open22 = ones(np,ngrid,nsec);
end


%%

crit2  = 1;crit3 = 1;gg = 0;toc_last=toc;
%Solve the GE problem
while (crit2 > converg || crit3 > converg) && gg < maxiter
    
    relax1  = 1;
    if crit2>1e-3
        relax2 = .1;
    else
        relax2 = .05;
    end
    relax3 = 1;
    
    
    CT2_old = CT2;
    
    
    %Country 1: given initial price distributions, update search choices
    m1 = s1;
    m2 = alph1*s2*s1/((s1^(1/veps)+s2^(1/veps))^veps);
    [pr1,pr1_idx,f_p1_tmp,f_p11_tmp,f_p12_tmp,p_i1_tmp,c_i1_tmp,W1_tmp,CT1_tmp,PT1_tmp,LTOT1,L2_for_tmp,LT1,CN1,PN1,IMP1,PI1,PI2_for,PI1_RET,MC_DOM1(:,:),MC_FOR1(:,:),P_DOM1(:,:),P_FOR1(:,:),PROB1(:,:,mm),active11,active12,V11prime,V12prime,diffv1,rfrac1,g_p1_tmp,chi1,open11,open12] ...
        = single_country_step_disc(g_p1,f_p1,f_p11,f_p12,chi1,active11,active12,p_i1,c_i1,W1,CT1,PT1,L1_for,W2,...
        V11prime,V12prime,...
        s1,m1,m2,dem_grid1,sec_grid1,sec_grid2,sec_dens,mc_grid_idio1,mc_grid_idio2,mc_dens1,mc_dens2,...
        Mbar1,W1ss,eta1,rho,kap1,phit,zet,psii,mu_w,ice,tauw1,pc_grid,kp_grid,kp_dens,open11,open12,lam,gg);
    
    
    
    %Relaxed updating
    f_p1    = relax1*f_p1_tmp    + (1-relax1)*f_p1;
    f_p11   = relax1*f_p11_tmp   + (1-relax1)*f_p11;
    f_p12   = relax1*f_p12_tmp   + (1-relax1)*f_p12;
    
    p_i1     = relax2*p_i1_tmp   + (1-relax2)*p_i1;
    c_i1     = relax2*c_i1_tmp   + (1-relax2)*c_i1;
    W1       = relax2*W1_tmp     + (1-relax2)*W1;
    CT1      = relax2*CT1_tmp    + (1-relax2)*CT1;
    PT1      = relax2*PT1_tmp    + (1-relax2)*PT1;
    L2_for   = relax2*L2_for_tmp + (1-relax2)*L2_for;
    
    g_p1     = relax3*g_p1_tmp   + (1-relax3)*g_p1;
    
    
    
    %Country 2
    m1 = alph2*s1*s2/((s1^(1/veps)+s2^(1/veps))^veps);
    m2 = s2;
    [pr2,pr2_idx,f_p2_tmp,f_p22_tmp,f_p21_tmp,p_i2_tmp,c_i2_tmp,W2_tmp,CT2_tmp,PT2_tmp,LTOT2,L1_for_tmp,LT2,CN2,PN2,IMP2,PI2,PI1_for,PI2_RET,MC_DOM2(:,:),MC_FOR2(:,:),P_DOM2(:,:),P_FOR2(:,:),PROB2(:,:,mm),active22,active21,V22prime,V21prime,diffv2,rfrac2,g_p2_tmp,chi2,open22,open21] ...
        = single_country_step_disc(g_p2,f_p2,f_p22,f_p21,chi2,active22,active21,p_i2,c_i2,W2,CT2,PT2,L2_for,W1,...
        V22prime,V21prime,...
        s2,m2,m1,dem_grid2,sec_grid2,sec_grid1,sec_dens,mc_grid_idio2,mc_grid_idio1,mc_dens2,mc_dens1,...
        exch*Mbar2,exch*W2ss,eta2,rho,kap2,phit,zet,psii,mu_w,ice,tauw2,pc_grid,kp_grid,kp_dens,open22,open21,lam,gg);
    
    %Convergence checks
    crit2    = abs(CT2_old-CT2_tmp);
    crit3    = abs(PT1*CT1+PN1*CN1-Mbar1);
    
    
    
    %Relaxed updating
    f_p2  = relax1*f_p2_tmp      + (1-relax1)*f_p2;
    f_p22 = relax1*f_p22_tmp     + (1-relax1)*f_p22;
    f_p21 = relax1*f_p21_tmp     + (1-relax1)*f_p21;
    
    p_i2     = relax2*p_i2_tmp   + (1-relax2)*p_i2;
    c_i2     = relax2*c_i2_tmp   + (1-relax2)*c_i2;
    W2       = relax2*W2_tmp     + (1-relax2)*W2;
    CT2      = relax2*CT2_tmp    + (1-relax2)*CT2;
    PT2      = relax2*PT2_tmp    + (1-relax2)*PT2;
    L1_for   = relax2*L1_for_tmp + (1-relax2)*L1_for;
    
    g_p2  = relax3*g_p2_tmp  + (1-relax3)*g_p2;
    
    
    gg = gg+1;
    
    value_intraUS = sum(.5*(pw_bar.*PI1)/(s1*(1+.31)));
    value_exportUS = sum(.5*(pw_bar.*PI2_for)/m2);
    
    value_intraCA  = sum(.5*(pw_bar.*PI2)/(s2*(1+.14)));
    value_exportCA = sum(.5*(pw_bar.*PI1_for)/m1);
    
    %Updating exchange rate
    wee      = .985;
    qratio   = max(.1,(10*IMP1+IMP2)/(10*IMP2+IMP1));
    exch_new = exch*qratio;
    estep    = max(-.1,min(.1,(1-wee)*(log(exch_new)-log(exch))));
    exch     = exp(log(exch) + estep);
    
    
    BAL_TRADE = IMP1-IMP2;
    
    WALRAS_check1 = s1*(PN1*CN1 + PT1*CT1)... %Trade and non-traded consumption, scaled to aggregate
        - W1*LTOT1 - PI1 - PI1_for - PI1_RET; %Wage income, producer profits, retailer profits
    
    WALRAS_check2 = s2*(PN2*CN2 + PT2*CT2)... %Trade and non-traded consumption, scaled to aggregate
        - W2*LTOT2 - PI2 - PI2_for - PI2_RET; %Wage income, producer profits, retailer profits
    
    
    
    critv(gg) = WALRAS_check1;
    
    if gg > 50
        crit_sd = std(critv(gg-50:gg));
    else
        crit_sd = 0;
    end
    
    %Display the news
    if (toc-toc_last)>120
        disp(['Progess ' sprintf('%i', gg), ':' sprintf('%2.3e', crit2) '|', sprintf('%2.3e', crit3) '|' sprintf('%2.3e', diffv1) '|', sprintf('%2.3e', diffv2)...
            '|' sprintf('%2.3e', abs(WALRAS_check1)) '|' sprintf('%2.3e', abs(WALRAS_check2)),'|' sprintf('%2.3e', abs(BAL_TRADE)) '|' sprintf('%2.3e', crit_sd), '|' sprintf('%0.2f',rfrac1), '|' sprintf('%0.2f',rfrac2), '|' sprintf('%3.2f', toc)]);
        toc_last = toc;
    end
    
    
end

%%
%**********************************************************************
%Tracking some values
%**********************************************************************
imp_shr1 = (IMP1/s1)/Mbar1;  %Divide by measure to get per-capita imports, since Mbar is per-capita
imp_shr2 = (IMP2/s2)/(exch*Mbar2);

C1 = CT1^phit*CN1^(1-phit);
C2 = CT2^phit*CN2^(1-phit);

imp_shrtmp1 =  IMP1/(s1*CT1*PT1);
imp_shrtmp2=   IMP2/(s2*CT2*PT2);

%**********************************************************************
%Testing several market clearing conditions
%**********************************************************************
VELA = PT1*CT1+PN1*CN1-Mbar1;
VELB = PT2*CT2+PN2*CN2-exch*Mbar2;

active(1,:) = active11;
active(2,:) = active12;
active(3,:) = active22;
active(4,:) = active21;

Vprime(:,:,1) = V11prime;
Vprime(:,:,2) = V12prime;
Vprime(:,:,3) = V22prime;
Vprime(:,:,4) = V21prime;




return

