% PARAMETERS: Initialize model parameters to their baseline values

function param = parameters

%*********************************************************************
%Set via optimization
%*********************************************************************

%parameters to adjust
param.alph1    = 0.26679110;    %fraction of B with license to export to A
param.alph2    = 0.87107390;    %fraction of A with license to export to B
param.kap1     = 0.00584630;    %search cost
param.kap2     = 0.00232430;    %search cost
param.sd_mc1   = 0.12697550;    %standard dev of log-marginal cost
param.sd_mc2   = 0.08860960;    %standard dev of log-marginal cost
param.sd_sec1  = 0.15995930;    %std of sectoral MC shocks
param.std_m    = 0.05688740;    %dtd deviation of home money shock


%outer demand elasticity
param.rho = 2.40201970;

%inner demand elasticity
param.eta1 = 5.13321990;
param.eta2 = 5.13321990;

%*********************************************************************
%Fixed
%*********************************************************************

param.ice  = .00;          %iceberg costs (not active in paper)

%menu cost
param.tauw1 = .00;             %units of firm's wage to change price, per unit of sales.
param.tauw2 = .00;             %units of firm's wage to change price, per unit of sales.

%random search costs (no active in paper)
param.nk                = 1;
param.sigk              = .00007;

%how nice a solution?
param.converg  = 1e-6;   %convergence criterion 
param.ngrid    = 200;    %number of grid points in marginal cost grid *
param.np       = 601;    %price choice grid
param.nsec     = 4;      %number of sectors (number of value for each country = sqrt(nsec)) *square
param.nm       = 9;      %grid points on money supply (sqrt(nm) distinct values per country) *sqaure
param.maxiter  = 550;1475;   %max number of iterations

%smoothing
param.lam.lam1 = 1*0.00025   ; %Smoothing shutdown choice
param.lam.lam2 = 0*0.0001   ; %Smoothing reset choice
param.lam.lam3 = 0*0.0001   ; %Smoothing optimal price choice, conditional on reset
param.lam.lam4 = 0*0.000001 ; %Smoothing optimal choice to seach/not search.

param.sd_sec2 = param.sd_sec1;
param.s1    =  8;    %Measure of country A
param.s2    =  1;    %Measure of country B
 
%matching elasticity
param.veps = 1;

%fixed cost
param.fc  = .00;

%preference parameters
param.phit = 0.66;  %share of traded consumption
param.zet  = 1;     %Frisch elasticity
param.psii = 5;     %picked to get SS labor equal to .4;

%wages  
param.mu_w = 0.85;    %0 is flex wages
param.W1ss = 2; %steady-state wage in country A dollars (value determined during run)
param.W2ss = 2; %steafy-state wage in country B dollars (value determined during run)

%idiosyncratic price distribution
param.mean_mc  = log(1);  %mean of log marginal cost
param.nsd      = 5;       %how many SD's of marginal cost to use in grid

%sectoral price distribution
param.mean_sec = log(1);     %mean of sectoral MC shocks

%money Process
param.rho_m = .95;                   %auto-correlation of money supply
param.mu_m  =  0;                    %log-mean of money supply

%print stats to screen?
param.print = false;