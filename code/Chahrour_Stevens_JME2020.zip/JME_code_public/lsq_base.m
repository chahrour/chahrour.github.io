warning off
 
%Initial parameters from parameters file
param = parameters;
param0 = [param.alph1;
          param.alph2;
          param.kap1;
          param.kap2
          param.sd_mc1;
          param.sd_mc2;
          param.sd_sec1;
          param.std_m;
          param.rho;
          param.eta1;
          ];
%Use saved values      
load popt_base
param0 = popt_tmp;

%Bounds on parameters
lbnd = [.10,.10,    .0002,  .0002,    .01,     .01,  .01,    .03   1.5 3 ];
ubnd = [.95,.95,    .0100,  .0100,    .25,     .25,  .4,     .07    5  8 ];

options = optimoptions('lsqnonlin');
options.TolX = 1e-4;
options.TolFun = 1e-5;
options.Display = 'iter';
options.MaxFunEvals = 150;
options.UseParallel = false;
options.FiniteDifferenceStepSize = .001*(ubnd-lbnd);
poptimal = lsqnonlin(@(pvec)100*calib_objective_base(pvec),param0,lbnd,ubnd,options);

%% Display moment using saved parameter values
load popt_tmp
[~,param_opt,mom_opt] = calib_objective_base(popt_tmp,true);