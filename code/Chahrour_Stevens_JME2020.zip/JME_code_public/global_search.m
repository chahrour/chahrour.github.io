%Time launched
addpath('DSGE_tools')
nowstr = datestr(now,'yyyymmddTHHMMSS');
use_ml = 1;
ns     = 24;

%Bounds on parameters
lbnd = [.001 .001 .05 .05 .05  0   0 ];
ubnd = [.01  .01  .3  .3  .3  .01 .01 ];

%baseline parameters, no adjust costs
param = parameters; param_unpack;
param0 = [kap1,kap2,sd_mc1,sd_mc2,sd_sec1,.0005,.0022];
nms = {'kap1', 'kap2', 'sd_mc1', 'sd_mc2', 'sd_sec1','tauw1','tauw2'};

param.tauw1 = 0*.0005;
param.tauw2 = 0*.0022;
static_solve
[mom_target]= quick_sim_moment(f_p11,f_p21,f_p12,f_p22,pc_grid,sec_dens);
mom_target(9) = 1/3;
mom_target(10) = 1/3;
mom_target
[rfrac1,rfrac2]

%%
%objective
obj1 = @(pvec)sum(100*calib_objective(pvec,mom_target).^2);
obj2 = @(pvec) calib_objective(pvec,mom_target);
%%
pmax = cell(1,ns);maxp = zeros(1,ns);vml_pure = zeros(1,ns);flag = zeros(1,ns);
tic
parfor jj = 1:ns
    warning on
    pmax{jj} = zeros(10,1);
    %Search for new max using genetic alg for starting point
    try
        [maxp(jj), pmax{jj}, flag(jj)] = sa_search(obj1,obj2,lbnd,ubnd,true);
        f = fopen(['global_tmp_' num2str(jj), '_' nowstr '.txt'], 'w');
        fprint_mat(f, '%1.7f\t', [maxp(jj), flag(jj), pmax{jj}']);
        fclose(f);
        pause(.1);
        %Update output files along the way!
        collect_results(ns,nowstr,nms);
    catch
        disp('woops')
    end
    
end
toc

%Make excel file with results, deleting temporary files
collect_results(ns,nowstr,nms);
for jj = 1:ns
   eval(['!rm -f '  'global_tmp_' num2str(jj), '_' nowstr '.txt']);
end

%Save all results
eval(['save global_results_' nowstr]);
[maxp,b] = sort(maxp);
pmax = pmax(b);



 


