%------------------------------------------------------------------------
% robustness.m
% File for "Price Dispersion and the Border Effect 
% Ryan Chahrour & Luminta Stevens
% August 2019
% Runs single runs for different sets of parameters for alternative 
% specifications and robustness (open, regional, no-ptm, different
% Frish or wage rigidity values, etc)  
%------------------------------------------------------------------------

clc
addpath('helper_funcs')
diary('./figure_mfiles/robust_printout'); 
OUTPUT_ROB = []; % store output from all the robustness runs 

%% Replicate baseline - confirmed? Yes... 
clearvars -except  OUTPUT_ROB
param     = parameters;
print_mom = false;
static_solve
print_mom = true;
model_moments
OUTPUT_ROB = [OUTPUT_ROB output]; 
save('./figure_mfiles/baseline.mat') 

%% regional-only export bias [as reported in the paper]
% Setting $\beta_{us,ca} = \beta_{us,us}$ for American suppliers
% and $\beta_{ca,us} = \beta_{ca,ca}$ for Canadian suppliers 

% Load baseline parameterization
clearvars -except  OUTPUT_ROB
load('./figure_mfiles/baseline.mat', 'param')
param_base = param; 

% Load baseline beta values 
load('./figure_mfiles/bet_table_fixed.mat', 'bet_tabl_us', 'bet_tabl_ca')
beta_a2      = bet_tabl_us(1,1);       % export bias of American suppliers to 'away' American region 
beta_a3_base = bet_tabl_us(2,1);       % export bias of American suppliers to either Canadian region 

beta_c2      = bet_tabl_ca(1,1);       % export bias of Canadian suppliers to 'away' Canadian region 
beta_c3_base = bet_tabl_ca(2,1);       % export bias of Canadian suppliers to either American region 

% Now reset the beta values to desired experiment 
beta_a3      = beta_a2;     % same export bias whether to away region or to away country             
beta_c3      = beta_c2;                 

% New market access parameters for US and CA -- CHECK THIS! 
%chistat1    = 4*beta_c3*param.s2/((1+beta_a2)*(param.s1+param.s2));     
%chistat2    = 4*beta_a3*param.s1/((1+beta_c2)*(param.s1+param.s2)); 

param.alph1    = 4*beta_c3/(1+beta_a2);     
param.alph2    = 4*beta_a3/(1+beta_c2);

print_mom = false;
static_solve
print_mom = true;
model_moments
OUTPUT_ROB = [OUTPUT_ROB output]; 
save('./figure_mfiles/robust_regional_use.mat') 

%% Open % all betas are equal to 1 

% Load baseline parameterization
clearvars -except  OUTPUT_ROB
load('./figure_mfiles/baseline.mat', 'param')
param_base = param; 

param.alph1    = 2;       %4beta_foreign/(1+beta_internal)
param.alph2    = 2;       
print_mom = false;
static_solve
print_mom = true;
model_moments
OUTPUT_ROB = [OUTPUT_ROB output]; 
save('./figure_mfiles/robust_open.mat') 



%% Change search costs so that no PTM 
% Load baseline parameterization
clearvars -except  OUTPUT_ROB
load('./figure_mfiles/baseline.mat', 'param')
param_base = param; 

param.kap1     = 100+param_base.kap1;      %search cost
param.kap2     = 100+param_base.kap2;      %search cost
print_mom      = false;
static_solve
print_mom = true;
model_moments
OUTPUT_ROB = [OUTPUT_ROB output]; 
save('./figure_mfiles/robust_noptm.mat') 



%% regional-only export bias [from the pov of retailers]

% Setting $\beta_{us,ca} = \beta_{ca,ca}$ for American suppliers
% and $\beta_{ca,us} = \beta_{us,us}$ for Canadian suppliers 

% Load baseline parameterization
clearvars -except  OUTPUT_ROB
load('./figure_mfiles/baseline.mat', 'param')
param_base = param; 

% Load baseline beta values 
load('./figure_mfiles/bet_table_fixed.mat', 'bet_tabl_us', 'bet_tabl_ca')
beta_a2      = bet_tabl_us(1,1);       % export bias of American suppliers to 'away' American region 
beta_a3      = bet_tabl_us(2,1);       % export bias of American suppliers to either Canadian region

beta_c2      = bet_tabl_ca(1,1);       % export bias of Canadian suppliers to 'away' Canadian region 
beta_c3      = bet_tabl_ca(2,1);       % export bias of Canadian suppliers to either American region 

% Now reset the beta values to desired experiment 
beta_a3_base = beta_a3;       
beta_c3_base = beta_c3;        

beta_a3      = beta_c2;                % no extra bias in Canada against US producers 
beta_c3      = beta_a2;                % no extra bias in US against Ca producers 

% New market access parameters for US and CA   
%chistat1    = 4*beta_c3*param.s2/((1+beta_a2)*(param.s1+param.s2));     
%chistat2    = 4*beta_a3*param.s1/((1+beta_c2)*(param.s1+param.s2)); 

param.alph1    = 4*beta_c3/(1+beta_a2);     
param.alph2    = 4*beta_a3/(1+beta_c2);

print_mom = false;
static_solve
print_mom = true;
model_moments
OUTPUT_ROB = [OUTPUT_ROB output]; 
save('./figure_mfiles/robust_regional_alt.mat') 

%% 'closed'      % virtually no international trade (a little bit, to pin down exchange rate)
% Load baseline parameterization
clearvars -except  OUTPUT_ROB
load('./figure_mfiles/baseline.mat', 'param')
param_base = param; 


param.alph1    = param_base.alph1/1000;      %Fraction of B with license to export to A
param.alph2    = param_base.alph2/1000;      %Fraction of A with license to export to B
print_mom      = false;
static_solve
print_mom = true;
model_moments
OUTPUT_ROB = [OUTPUT_ROB output]; 
save('./figure_mfiles/robust_closed.mat') 






%% Change Frisch elasticity 
% Labor economists have found estimates to be <=0.5 while macro likes1-2 
% But, small micro elasticities can be reconciled with large macro
% elasticities - see review by Keane and Rogerson \cite{KR2012jel}
 
% Load baseline parameterization
clearvars -except  OUTPUT_ROB
load('./figure_mfiles/baseline.mat', 'param')
param_base = param; 
param.zet  = 1;     % baseline Frisch elasticity is 1

% low Frisch 
param.zet  = 0.4;  
print_mom  = false;
static_solve
print_mom  = true;
model_moments
OUTPUT_ROB = [OUTPUT_ROB output]; 
save('./figure_mfiles/robust_frisch_low.mat') 


% Load baseline parameterization
clearvars -except  OUTPUT_ROB
load('./figure_mfiles/baseline.mat', 'param')
param_base = param; 

% higher Frisch 
param.zet  = 1.5;  
print_mom  = false;
static_solve
print_mom  = true;
model_moments
OUTPUT_ROB = [OUTPUT_ROB output]; 
save('./figure_mfiles/robust_frisch_higher.mat') 


% Load baseline parameterization
clearvars -except  OUTPUT_ROB
load('./figure_mfiles/baseline.mat', 'param')
param_base = param; 

% high Frisch 
param.zet  = 2;  
print_mom  = false;
static_solve
print_mom  = true;
model_moments
OUTPUT_ROB = [OUTPUT_ROB output]; 
save('./figure_mfiles/robust_frisch_high.mat') 


%% Change wage rigidity

% Load baseline parameterization
clearvars -except  OUTPUT_ROB
load('./figure_mfiles/baseline.mat', 'param')
param_base = param; 
% param.mu_w = 0.85;    %0 is flex wages

% low rigidity 
param.mu_w = 0.75;      %0 is flex wages
print_mom  = false;
static_solve
print_mom  = true;
model_moments
OUTPUT_ROB = [OUTPUT_ROB output]; 
save('./figure_mfiles/robust_wagerig_low.mat') 


% Load baseline parameterization
clearvars -except  OUTPUT_ROB
load('./figure_mfiles/baseline.mat', 'param')
param_base = param; 
% param.mu_w = 0.85;    %0 is flex wages

% high rigidity 
param.mu_w = 0.65;      %0 is flex wages
print_mom  = false;
static_solve
print_mom = true;
model_moments
OUTPUT_ROB = [OUTPUT_ROB output]; 
save('./figure_mfiles/robust_wagerig_lower.mat') 

% Load baseline parameterization
clearvars -except  OUTPUT_ROB
load('./figure_mfiles/baseline.mat', 'param')
param_base = param; 
% param.mu_w = 0.85;    %0 is flex wages

% lower rigidity (CEE have 0.64 Calvo param)
param.mu_w = 0.15;      %0 is flex wages
print_mom  = false;
static_solve
print_mom = true;
model_moments
OUTPUT_ROB = [OUTPUT_ROB output]; 
save('./figure_mfiles/robust_wagerig_tiny.mat') 

%% Change volatility of relative money supply shocks 

% Load baseline parameterization
clearvars -except  OUTPUT_ROB
load('./figure_mfiles/baseline.mat', 'param')
param_base = param; 
% param.std_m = 0.0569  

% high nominal vol 
param.std_m = 1.5*param_base.std_m;       
print_mom   = false;
static_solve
print_mom = true;
model_moments
OUTPUT_ROB = [OUTPUT_ROB output]; 
save('./figure_mfiles/robust_volm_high.mat') 


%% Small sigma-eta 
% Load baseline parameterization
clearvars -except  OUTPUT_ROB
load('./figure_mfiles/baseline.mat', 'param')
param_base     = param; 
param.sd_sec1  = param_base.sd_sec1/4; %sd of sectoral markup shocks
param.sd_sec2  = param_base.sd_sec2/4;
print_mom      = false;
static_solve
print_mom = true;
model_moments
OUTPUT_ROB = [OUTPUT_ROB output]; 
save('./figure_mfiles/robust_sigeta_low.mat') 


%% Same country sizes 

clearvars -except  OUTPUT_ROB
load('./figure_mfiles/baseline.mat', 'param')
param_base = param; 

param.s1  = 0.5*(param_base.s1+param_base.s2);
param.s2  = 0.5*(param_base.s1+param_base.s2);
print_mom = false;
static_solve
print_mom = true;
model_moments
OUTPUT_ROB = [OUTPUT_ROB output]; 
save('./figure_mfiles/robust_same_size.mat') 


%% Reduced asymmetry 
% same retailer search costs and producer productivity vol across countries 

clearvars -except  OUTPUT_ROB
load('./figure_mfiles/baseline.mat', 'param')
param_base = param; 

param.kap1     = 0.5*(param_base.kap1+param_base.kap2);
param.kap2     = 0.5*(param_base.kap1+param_base.kap2);

param.sd_mc1   = 0.5*(param_base.sd_mc1+param_base.sd_mc2);
param.sd_mc2   = 0.5*(param_base.sd_mc1+param_base.sd_mc2);

print_mom = false;
static_solve
print_mom = true;
model_moments
OUTPUT_ROB = [OUTPUT_ROB output]; 
save('./figure_mfiles/robust_symmetry.mat') 

OUTPUT_ROB(:,1:8)
disp(' ');
OUTPUT_ROB(:,9:end)


diary off
return 

