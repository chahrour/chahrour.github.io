
% function [d] = plot_data(vtp,hgrid,LineWidth)
% vtp_m = quantile(vtp,0.5,2); % median
% vtp_c =quantile(vtp,[0.05,0.95,0.16,0.84],2); % confidence
% 
% % a = fill([hgrid ,hgrid(end):-1:hgrid(1)],[vtp_c(:,1)' ,flipud(vtp_c(:,2))'],[0.9 0.9 0.9]);hold on;
% %             set(a,'EdgeAlpha',0);
%             a = fill([hgrid ,hgrid(end):-1:hgrid(1)],[vtp_c(:,3)' ,flipud(vtp_c(:,4))'],[0.7 0.7 0.7]);hold on;
%             set(a,'EdgeAlpha',0); 
% d = plot(hgrid,vtp_m,'-b','linewidth',LineWidth); hold on;
% end

function [d] = plot_data(vtp,hgrid,NOISE)
vtp_m = quantile(vtp,0.5,2); % median
vtp_c = quantile(vtp,[0.05,0.95,0.16,0.84],2); % confidence

% a = fill([hgrid ,hgrid(end):-1:hgrid(1)],[vtp_c(:,1)' ,flipud(vtp_c(:,2))'],[0.9 0.9 0.9]);hold on;
%             set(a,'EdgeAlpha',0);
            a = fill([hgrid ,hgrid(end):-1:hgrid(1)],[vtp_c(:,3)' ,flipud(vtp_c(:,4))'],[0.7 0.7 0.7]);hold on;
            set(a,'EdgeAlpha',0); 
            if NOISE == 1
d = plot(hgrid,vtp_m,'-r','linewidth',2); hold on;
            else
d = plot(hgrid,vtp_m,'-b','linewidth',2); hold on;
            end
end
