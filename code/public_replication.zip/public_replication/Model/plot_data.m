function [d] = plot_data(vtp,hgrid,NOISE)
%PLOT_DATA  Plot the median across draws over a 16-84 band.
%
%   d = plot_data(vtp, hgrid, NOISE)
%
%   vtp    nhorizon x ndraws responses
%   hgrid  horizons on the x-axis
%   NOISE  1 draws the median in red, otherwise in blue
%   d      handle of the median line
vtp_m = quantile(vtp,0.5,2); % median
vtp_c = quantile(vtp,[0.05,0.95,0.16,0.84],2); % 5, 95, 16 and 84 percent

            a = fill([hgrid ,hgrid(end):-1:hgrid(1)],[vtp_c(:,3)' ,flipud(vtp_c(:,4))'],[0.7 0.7 0.7]);hold on;
            set(a,'EdgeAlpha',0); 
            if NOISE == 1
d = plot(hgrid,vtp_m,'-r','linewidth',2); hold on;
            else
d = plot(hgrid,vtp_m,'-b','linewidth',2); hold on;
            end
end
