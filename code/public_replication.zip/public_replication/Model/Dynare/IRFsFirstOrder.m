plot_var = {'TFP', 'a20', 'ConsumptionDifferential', 'RealInterestRateDifferential', 'RealExchangeRate','ExpectedExcessCurrencyReturns' ...
            'RealExchangeRateUIP', 'RealExchangeRateLambda'}; %plot vars, use Dynare var names, can decide order
lab_model_order = {'Home TFP', 'Expected Home TFP', 'Consumption Differential', 'Interest Rate Differential' ,'Real Exchange Rate', 'Expected Excess Returns'...
            'RealExchangeRateUIP', 'RealExchangeRateLambda'};  %figure labels

[~,inds] = ismember(plot_var,M_.endo_names); 
    % oo_.dr.inv_order_var    from DR to declared order
    % oo_.dr.order_var        from declared order to DR
% Construct Gx Hx from Dynare output
nvar = size(oo_.dr.ghx,1);
% states = oo_.dr.state_var; %states in declaring order- use it to construct zero columns of GHX
states = oo_.dr.order_var(M_.nstatic+1:M_.nstatic+M_.nspred);
%--this gives you the same as oo_.dr.state_var 

% The DR-order is the following: 
% static variables appear first, 
% then purely backward variables, 
% then mixed variables, 
% and finally purely forward variables. 
% Inside each category, variables are 
% arranged according to the declaration order.

HX = zeros(nvar);
HX(:,states) = oo_.dr.ghx(oo_.dr.inv_order_var,:);
GX = zeros(1,nvar+12); 
for kk = 1:length(inds), GX(kk,inds(kk)) = 1; end

load('kalman_paramsmat2026.mat');

GHU = oo_.dr.ghu(oo_.dr.inv_order_var,[1,2]); 
HXaug = zeros(nvar+12,nvar+12);
HXaug(1:nvar,1:nvar) = HX;
HXaug(1:nvar,1:12) = HXaug(1:nvar,1:12) - GHU*inv(G)*CA; 
HXaug(:,nvar+1:end) = [GHU*inv(G)*CA; A];
ETA = [GHU*inv(G)*C*B; B];


C = GX;
A = HXaug; % P: there seems to be a change in the value and definition of A
B = ETA; % P: there seems to be a change in the value and definition of B
ny = size(C,1);
nx = size(A,1);
ne = size(B,2);

%-- IRFs

% Horizon for impulse responses
h = 100;

% -------------------------------------------------------------------------
% Noise impulse responses and variance shares
% -------------------------------------------------------------------------
% Noise shocks
ind_noise = 2;
Cnoise    = B(:,ind_noise);

% Impulse responses
x = 1;
y = [];
for j = 1:h+1
    y(:,j) = C*x*Cnoise; %this is not using the Kalman filter at all
    x      = A*x;
end
% irnoise = [zeros(ny,h),y]'.*4;
irnoise_model = [zeros(ny,h),y]';

% -------------------------------------------------------------------------
% TFP impulse responses and variance shares
% -------------------------------------------------------------------------
% TFP innovations representation
ind_tfp = 1; %tfp location 
Ctfp    = C(ind_tfp,:);

[K,V,P] = kalman(Ctfp,A,B); %note that here only inserts Ctfp that is tfps as a function 
%unobservables at time t, precisely because it needs the Wold
%representation in which we assume that agents only observe tfp so there is no news.

sqrtV   = chol(V,'lower');

% Impulse responses
x = 1;
y = [];
for j = 1:h+1
    y(:,j) = C*P*x*Ctfp'/sqrtV;
    x      = (A-K*Ctfp)'*x; 
end

y1 = fliplr(y); % negative powers of j
y  = [];
x  = 1;
for j = 2:h+1
    y(:,j) = C*A*x*P*Ctfp'/sqrtV;
    x      = A*x; %this is the actual change in x
end
irtfp_model = [y1,y(:,2:end)]';


