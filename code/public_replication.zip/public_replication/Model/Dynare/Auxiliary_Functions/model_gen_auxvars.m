function [A,B,term_rer,term_deltaq,term_expexret,ia1,exp_tfp_j] ...
    = model_gen_auxvars(b,nvars,nlags,j_cj_horizon,vcase)
%MODEL_GEN_AUXVARS  The model chain's own auxiliary-variable builder.
%
%   THE ONE DELIBERATE DUPLICATE IN THIS PACKAGE, and not a stale vintage of the
%   estimation code's gen_auxvars -- it builds a different object:
%
%       this one:  model_gen_auxvars(b, nvars, nlags, j_cj, vcase)
%                  appends 25 rows to the model's 7-variable simulated system
%       ours:      gen_auxvars(b, Aproj, keys, nvars, nlags, j_cj)
%                  appends rows to the 39-row manifest, and needs a projection
%                  matrix and key list that no model run produces
%
%   Figures 8, 9 and C.1 index their panels by column POSITION -- [1 8 19 11 4 3]
%   and [1 8 19 4 11 3] -- so substituting the estimation code's builder would
%   point every column at a different series and still draw a plausible figure.
%
%   genvars WAS reconciled, because there the two really are one function at two
%   vintages. This one is renamed so it cannot shadow, and called by name from
%   gentfp_freq_baseline_fast and gennoise_baseline_fast.

% % Optional inputs
% ip = inputParser;
% addParameter(ip, 'vcase', NaN, @isnumeric); %default is NaN 
% parse(ip, varargin{:});

    otfp = 1;
    ocons = 2;
    oinv = 3;
    oner = 4;
    oidiff = 5;
    oconsf = 6;
    ocpidiff = 7;
    oinvf = 7;
%companion matrix of demeaned VAR (=> don't include constant term)
B = companion_form(b(1:nvars*nlags,:)');

%TFP expectations
ia1 = zeros(nvars*nlags,1);
ia1(otfp) = 1;
exp_tfp_one    = ia1'*B^1;
exp_tfp_five   = ia1'*B^5;
exp_tfp_j      = ia1'*B^j_cj_horizon;

% Expected NER
ia2    = zeros(nvars*nlags,1);
ia2(oner) = 1;
term_expner = ia2'*B; %exp NER

% Expected excess return
 ia3 = zeros(nvars*nlags ,1);
 ia3(oner) = 1;
 ia3(oidiff) = 1;
 term_expexret = term_expner - ia3';

% Real exchange rate
ia4 = zeros(nvars*nlags ,1);
ia4(oner) = 1;
term_rer = ia4'; %RER = NER - (P-P*)

%\Delta q_t #RAC says this is \Delta S
ia4_delta = zeros(nvars*nlags,1);
ia4_delta(oner) = 1;
ia4_delta(oner+nvars) = -1;
term_deltaq  = ia4_delta';

% Real Int rate Differential
ia5 = zeros(nvars*nlags,1);
ia5(oidiff) = 1;
term_realrate = ia5'; %IDIFF + CPIDIFF - EXP(CPIDIFF)

% Expected Real exchange rate
term_exprer = term_expner; %RER = E(NER) - E(P-P*)

% % Realized real excess return 
ia3 = zeros(nvars*nlags ,1);
ia3(oner)   = 1;
term_ner = ia3';
ia3 = zeros(nvars*nlags ,1);
ia3(oner + nvars)   = 1;
ia3(oidiff + nvars)   = 1;
term_exret = term_ner -ia3';  %ExRet = [NER(t) - NER(t-1) - (i-i*)(t-1)]

% Backus Smith Wedge in levels (real)
ia6 = zeros(nvars*nlags ,1);
ia6(ocons) = 1; %C-C*
ia6(oconsf) = -1;
term_bs_level = term_rer - ia6';

% Backus Smith Wedge in diff  (real)
ia7 = zeros(nvars*nlags ,1);
ia7(oner+nvars) = 1; %past ner
ia7(ocons+nvars) = -1; %past C
ia7(oconsf+nvars) = 1; %past C*
term_bs_diff = term_bs_level - ia7';

% rer(eret)
if max(abs(eig(B))) >= .9999
    term_cumeret = -term_expexret;
    for j = 1:500
        term_cumeret = term_cumeret - term_expexret*B^j;
    end
else
    term_cumeret = -term_expexret/(eye(size(B))-B);
end

% realized cum excess return
if max(abs(eig(B))) >= .9999
    term_cum_rlzd_eret = -term_exret;
    for j = 1:500
        term_cum_rlzd_eret = term_cum_rlzd_eret - term_exret*B^j;
    end
else
    term_cum_rlzd_eret = -term_exret/(eye(size(B))-B);
end

%consumption differential
ia8 = zeros(nvars*nlags ,1);
ia8(ocons) = 1;
ia8(oconsf) = -1;
term_cdiff = ia8';

%investment differential
ia9 = zeros(nvars*nlags ,1);
ia9(oinv) = 1;
ia9(oinvf) = -1;
term_invdiff = ia9';

% rer(UIP)

if max(abs(eig(B))) >= .9999
    term_quip = -term_realrate;
    for j = 1:500
        term_quip = term_quip - term_realrate*B^j;
    end
else
    term_quip = -term_realrate/(eye(size(B))-B);
end

A  = [[eye(nvars),zeros(nvars,nvars*nlags-nvars)];exp_tfp_j; term_expner; term_expexret; term_realrate; ...
    term_exprer; term_exprer; term_rer; term_bs_level; term_bs_diff; term_deltaq ; term_cumeret; term_cdiff; term_invdiff; exp_tfp_one; exp_tfp_five; term_exret; term_cum_rlzd_eret; term_quip ];
