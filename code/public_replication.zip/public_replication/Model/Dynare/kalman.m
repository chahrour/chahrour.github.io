function [K,V,P] = kalman(A,B,C,D,iter)
% -------------------------------------------------------------------------
% Compute innovations representation of a model of the form
%       y(t) = a + A*x(t) + D*u(t)
%       x(t) = b + B*x(t-1) + C*e(t)
% -------------------------------------------------------------------------

% Options
if nargin < 5; iter = 1; end
if nargin < 4; D = 0; end

% Run filter
if iter == 1
    err   = 1;
    count = 0;
    P     = 0.01*eye(size(B,1));
    while err > 1e-12;
        Pnew = B*P*B' + C*C' - B*P*A'/(A*P*A' + D*D')*A*P*B';
        err   = max(max(abs(Pnew-P)));
        P     = Pnew;
        count = count + 1;
        if count > 1e5 
            fprintf('ricatti convergence norm = %d\n',err); break; 
        end
    end
elseif iter == 0
    P = dare(B',A',C*C',D*D');
end
V = A*P*A' + D*D';
K = B*P*A'/V;
end
