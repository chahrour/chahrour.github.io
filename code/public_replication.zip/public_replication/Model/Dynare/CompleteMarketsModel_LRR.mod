% Complete-markets model under Long-run risk process for TFP

// Variables and Parameters 
// Endogenous Variables 

        
     var    a20
            da daf ar_ ar_f TFP TFPForeign 
            uc ucf Q logQ Qf logQf  dc dcf             
            dx dxf dy dyf dxa dxaf xa xaf dya dyaf ya yaf 
            m // Log Home SDF in C-units
            mf 
            Em // E(m')
            Emf // E(mf')
            M // level SDF exp(m)
            Mf // level SDF exp(mf)
            EM // E(M')
            EMf // E(Mf')
            p  
            s 
            rf rff 
            ca caf 
            drer // Real Exchange Rate Growth
            RealExchangeRate // log(RER)
            ExpectedRealExchangeRate
            RER // level RER
            ExpectedExcessCurrencyReturns
            Consumption ConsumptionForeign ConsumptionDifferential RealInterestRateDifferential 
            RealExchangeRateUIP RealExchangeRateLambda
            z zf 
            ;

    // Exogenous Variables 
      varexo  ea eaf ez ezf; // Structural LRR shocks
        

    // Parameters 
        parameters beta  gam ies lambda mu rho tau theta;  
        beta   = beta_; // Subjective discount factor 

        gam    = gam_; // Risk aversion 
        ies    = ies_; // Intertemporal elasticity of substitution 

        lambda = lambda_; // Home bias 

        mu     = mu_; // Long run mean of productivity 

        rho    = rho_; // Persistence of long run shock 
        tau    = tau_; // Co-integration parameter 
        
        theta = (1-1/ies)/(1-gam);  // Composite parameter 


// Model 
model; 

    // Exogenous processes (LRR)
        da  = mu + z(-1)   + ea; // unidirectional cointegration version
        daf = mu + zf(-1) + tau*ar_(-1) + eaf;      
        ar_  = (1-tau) * ar_(-1) + z(-1) - zf(-1) + ea - eaf; // unidirectional cointegration version
        ar_f = -ar_; 
        z   = rho*z(-1)+ez; 
        zf  = rho*zf(-1)+ezf; 
        TFP  = TFP(-1) + (da-mu);
        TFPForeign = TFPForeign(-1) + (daf-mu);

        
        a20 = TFP(20);


// BLOCK 2: DEFINITIONS OF GROWTH RATES
    // Growth rates 
        dc    = lambda*dx+(1-lambda)*dy; 
        dcf   = lambda*dyf+(1-lambda)*dxf; 
        dx    = dxa+da; 
        dxf   = dxaf+da; 
        dy    = dya+daf; 
        dyf   = dyaf+daf; 
        dxa   = xa-xa(-1); 
        dxaf  = xaf-xaf(-1); 
        dya   = ya-ya(-1); 
        dyaf  = yaf-yaf(-1); 

// BLOCK 3: DEFINITIONS OF UTILITY FUNCTIONS, SDFs, BUNDLE AGGREGATORS, PRODUCTION FUNCTIONS

    // Home and Foreign utility 
       exp((1-1/ies)*uc)  = (1-beta)+beta*(Q^theta); 
       exp((1-1/ies)*ucf) = (1-beta)+beta*(Qf^theta); 

        Q       = exp((uc(+1)*(1-gam)+dc(+1)*(1-gam))); 
        logQ    = log(Q); 
        Qf      = exp((ucf(+1)+dcf(+1))*(1-gam)); 
        logQf   = log(Qf); 

  // SDFs 
     exp(m)  = beta*exp(dc*(-1/ies))  * exp((uc+dc)*(1/ies-gam))   / exp(logQ(-1)*(1-theta)); //v1
     exp(mf) = beta*exp(dcf*(-1/ies)) * exp((ucf+dcf)*(1/ies-gam)) / exp(logQf(-1)*(1-theta)); //v1

    // Consumption bundle aggregators 
        ca      = lambda * xa + (1-lambda) * (ya-ar_); 
        caf     = (1-lambda)*(xaf+ar_) + lambda*yaf; 
        
    // Prices and returns 
        // original code
         1/exp(rf)  = exp(m(+1)); 
         1/exp(rff) = exp(mf(+1)); 
   
        M = exp(m);
        Mf = exp(mf);

        Em = m(+1);
        Emf = mf(+1);

        EM = M(+1);
        EMf = Mf(+1);

 
// Terms of trade (this one holds under both COMPLETE and INCOMPLETE MKTS -- under COMPLETE it comes from goods demand)
        p = log((1-lambda)/lambda) + xa - ya + ar_;
// Resource constraints 
       1  =  exp(xa)+exp(xaf); 
       1  =   exp(ya)+exp(yaf); 


// COMPLETE MARKETS
      s  = s(-1)+m-mf+dc-dcf;     // Pareto-weights and allocations 
      s  = log((1-lambda)/lambda)+xa-xaf; 
      s  = log(lambda/(1-lambda))+ya-yaf; 
      drer = mf - m;  // v1
      drer = RealExchangeRate-RealExchangeRate(-1); 
    RER = exp(RealExchangeRate);

      Consumption  = Consumption(-1) + (dc-mu);
      ConsumptionForeign = ConsumptionForeign(-1) + (dcf-mu);
      ConsumptionDifferential = Consumption - ConsumptionForeign;

        RealInterestRateDifferential = rf -rff;
        ExpectedExcessCurrencyReturns = drer(1) - (rf - rff);

        ExpectedRealExchangeRate = RealExchangeRate(1);

RealExchangeRateUIP = - RealInterestRateDifferential + 0.9999*RealExchangeRateUIP(1);
RealExchangeRateLambda = - ExpectedExcessCurrencyReturns + 0.9999*RealExchangeRateLambda(1);

end;   

// Initital values 
initval; 

    // Exogenous processes 
        da  = mu; 
        daf = mu; 
        ar_  = 0; 
        ar_f = 0; 
        z   = 0; 
        zf  = 0; 

    // Growth rates 
        dc    = mu; 
        dcf   = mu; 
        dx    = mu; 
        dxf   = mu; 
        dy    = mu; 
        dyf   = mu; 
        dxa   = 0; 
        dxaf  = 0; 
        dya   = 0; 
        dyaf  = 0; 

    // Home and Foreign utility 
        uc    = log((1-beta)/(1-beta * exp((1-1/ies)*mu)))*(1/(1-1/ies)); 
        ucf   = uc; 

        Q     = exp((uc+mu)*(1-gam)); 
        logQ  = log(Q); 
        Qf    = Q; 
        logQf = logQ; 

    // SDFs 
        m  = log(beta)-mu/ies; 
        mf = m; 

        M = exp(m);
        Mf = exp(mf);

        EM =M;
        EMf = Mf;
    
        Em = m; 
        Emf = m;

    // Derived steady states 
        xa   = -log(1/lambda); 
        xaf  = log(1/lambda-1)+xa; 

        ya    = xaf; 
        yaf   = xa; 

    // Consumption bundle aggregators 
        ca      = lambda*xa+(1-lambda)*(ya); 
        caf     = ca; 

    // Prices and returns 
        rf  = -m; 
        rff = rf; 

    // Terms of trade 
        p  = 0; 

    // Pareto-weights and allocations 
        s  = 0; 
        RealExchangeRate = 0;
        RER = 1;
        ExpectedExcessCurrencyReturns = 0;


end;   

shocks; // LRR
var ea  = 0.001482250000000; var ez  = 0.000023532201000; 
var eaf = 0.001482250000000; var ezf = 0.000023532201000;

end;

steady;

check;

stoch_simul(order=@{ORDER}, periods=10000, nograph, irf = 25);
