%QUICK_KALMAN_NOISE - Noise representation of Blanchard et al (2013)
%information structure

function [A, KG, CA, G, K, C, S_1,B] = quick_kalman_noise_ccdgv(param)
scl = 10000;105500;


sigtmp = param.sigtmp;
sige = sigtmp*(1-param.rho);
sign = sqrt(param.rho)*sigtmp;

% sige = param.sige;
% sign = param.sign;
sigv = param.sigv;
rhox = param.rho;
rhoz = param.rho;


%variable order in state
CC = [rhox, -((1+rhox)^2+rhoz*(sige^2/sign^2)),(1+rhox)^2 + (1+rhox^2) + (1+rhoz^2)*sige^2/sign^2, -((1+rhox)^2+rhoz*sige^2/sign^2),rhox];
rts = roots(CC);
del1 = rts(3);
del2 = rts(4);

CC = [del1*del2,-(del1+del2)*(1+del1*del2), ((del1+del2)^2 + (1+del1^2*del2^2) + del1*del2/rhox*sige^2/sigv^2), -(del1+del2)*(1+del1*del2), del1*del2];
rts = roots(CC);
bet1 = rts(3);
bet2 = rts(4);

phi1 = del1+del2;
phi2 = -del1*del2;

thet1 = -(bet1+bet2);
thet2 = bet1*bet2;

lam2 = rhox;
lam1 = -(del1+del2)*(1+del1*del2)/(del1*del2)*lam2;
lam0 = ((del1+del2)^2 + (1+del1^2*del2^2))/(del1*del2)*lam2;

psi1 = rhoz+del1+del2;
psi2 = -rhoz*(del1+del2) - del1*del2;
psi3 = rhoz*del1*del2;

sigem = sqrt(del1*del2/rhox*sign^2)/scl;
sigex = sqrt(del1*del2/(bet1*bet2)*sigv^2);

%X =[al1 mp2 mp1 m0 ml1 ml2 ml3 xl1 xl2 ex1 ex2 ex3]

%state evol
A = zeros(12,12);
A(1,1:6) = [rhox, scl*lam2,scl*lam1,scl*lam0,scl*lam1,scl*lam2];
A(2,[2 3 4]) = [psi1,psi2,psi3];
A(3,2) = 1;
A(4,3) = 1;
A(5,4) = 1;
A(6,5) = 1;
A(7,6) = 1;

A(8,8:11) = [phi1,phi2,thet1,thet2];
A(9,8) = 1;
A(11,10) = 1;
A(12,11) = 1;

%Observation
C = zeros(2,12);
C(1,1)    = 1;
C(2,[3 4 5 8]) = [-scl*rhox scl*(1+rhox) -scl 1];
C = C';

%H = H(:,1);
S_1 = zeros(12,12);%shocks to stats
S_1(2,2) = sigem^2; %Shock hits M and EPSM
S_1([8,10],[8,10]) = sigex^2; %Shock hits xi and epsx;
S_2 = zeros(size(C,2));

B = zeros(12,2);
B(2,1) = sigem; %Shock hits M and EPSM
B([8,10],2) = sigex; %Shock hits xi and epsx;

A = real(A);
C = real(C);
P = eye(size(A,1));
crit = 1;
mm = 1;
while crit > 1e-13 && mm < 150000
    P_new = (A*(P-P*C*((C'*P*C+S_2)\(C'*P)))*A' + S_1);
    crit = max(max(abs(P-P_new)));
    P = .95*P + .05*1/2*(P_new + P_new');
    mm = mm+1;
end

if crit > 1e-8
    disp(num2str(crit))
end

C = C';
K = P*C'/(C*P*C' + S_2);
CA = C*A;
G = real((C*P*C'+S_2)^.5); %G
KG = K*G;



function [out,P] = obj(P,H,F,Q,R)

%Reconstruct P
P = reshape(P,[12,12]);

out = 1000*vec(P-(F*(P-P*H*((H'*P*H+R)\(H'*P)))*F' + Q));