// Standard incomplete market, endowment economy
// Pierre De Leo, August 19, 2025 

// Variables and Parameters 
// Endogenous Variables 

        
    var     aux_1 aux_2 aux_3 aux_4 aux_5 aux_6 aux_7 aux_8 aux_9 aux_10 aux_11 aux_12
            s_1 s_2
            a20
            TFP TFPForeign
            RealExchangeRate TermsOfTrade// log(RER)  
            b // foreign bonds
            RealInterestRateDifferential
            ConsumptionDifferential  
            ExpectedExcessCurrencyReturns
            X_YForeign Y_XForeign
            RealExchangeRateUIP RealExchangeRateLambda
            TFPChangeForeign TFPChange
            TFPDifferential
            ds_1
            ;

    // Exogenous Variables 
        varexo e_1 e_2;
        

    // Parameters 
        parameters BETA  GAMMA VARSIGMA SIGMA tau phi_1 
A_1_1  A_1_2  A_1_3  A_1_4  A_1_5  A_1_6  A_1_7  A_1_8  A_1_9  A_1_10  A_1_11  A_1_12  
A_2_1  A_2_2  A_2_3  A_2_4  A_2_5  A_2_6  A_2_7  A_2_8  A_2_9  A_2_10  A_2_11  A_2_12  
A_3_1  A_3_2  A_3_3  A_3_4  A_3_5  A_3_6  A_3_7  A_3_8  A_3_9  A_3_10  A_3_11  A_3_12  
A_4_1  A_4_2  A_4_3  A_4_4  A_4_5  A_4_6  A_4_7  A_4_8  A_4_9  A_4_10  A_4_11  A_4_12  
A_5_1  A_5_2  A_5_3  A_5_4  A_5_5  A_5_6  A_5_7  A_5_8  A_5_9  A_5_10  A_5_11  A_5_12  
A_6_1  A_6_2  A_6_3  A_6_4  A_6_5  A_6_6  A_6_7  A_6_8  A_6_9  A_6_10  A_6_11  A_6_12  
A_7_1  A_7_2  A_7_3  A_7_4  A_7_5  A_7_6  A_7_7  A_7_8  A_7_9  A_7_10  A_7_11  A_7_12  
A_8_1  A_8_2  A_8_3  A_8_4  A_8_5  A_8_6  A_8_7  A_8_8  A_8_9  A_8_10  A_8_11  A_8_12  
A_9_1  A_9_2  A_9_3  A_9_4  A_9_5  A_9_6  A_9_7  A_9_8  A_9_9  A_9_10  A_9_11  A_9_12  
A_10_1 A_10_2 A_10_3 A_10_4 A_10_5 A_10_6 A_10_7 A_10_8 A_10_9 A_10_10 A_10_11 A_10_12  
A_11_1 A_11_2 A_11_3 A_11_4 A_11_5 A_11_6 A_11_7 A_11_8 A_11_9 A_11_10 A_11_11 A_11_12  
A_12_1 A_12_2 A_12_3 A_12_4 A_12_5 A_12_6 A_12_7 A_12_8 A_12_9 A_12_10 A_12_11 A_12_12  

KG_1_1  KG_1_2  KG_2_1  KG_2_2  KG_3_1  KG_3_2  KG_4_1  KG_4_2  KG_5_1  KG_5_2  
KG_6_1  KG_6_2  KG_7_1  KG_7_2  KG_8_1  KG_8_2  KG_9_1  KG_9_2  KG_10_1 KG_10_2  
KG_11_1 KG_11_2 KG_12_1 KG_12_2  

CA_1_1  CA_1_2  CA_1_3  CA_1_4  CA_1_5  CA_1_6  CA_1_7  CA_1_8  CA_1_9  CA_1_10  CA_1_11  CA_1_12  
CA_2_1  CA_2_2  CA_2_3  CA_2_4  CA_2_5  CA_2_6  CA_2_7  CA_2_8  CA_2_9  CA_2_10  CA_2_11  CA_2_12  

G_1_1  G_1_2  G_2_1  G_2_2; 

        BETA   = beta_; // Subjective discount factor 

        GAMMA    = gam_; // Risk aversion 

        VARSIGMA = lambda_; // Home bias 

        tau    = tau_; // Co-integration parameter 
        
        phi_1 = phi_1_; 

        SIGMA = SIGMA_;

A_1_1 = A_1_1_;
A_1_2 = A_1_2_;
A_1_3 = A_1_3_;
A_1_4 = A_1_4_;
A_1_5 = A_1_5_;
A_1_6 = A_1_6_;
A_1_7 = A_1_7_;
A_1_8 = A_1_8_;
A_1_9 = A_1_9_;
A_1_10 = A_1_10_;
A_1_11 = A_1_11_;
A_1_12 = A_1_12_;
A_2_1 = A_2_1_;
A_2_2 = A_2_2_;
A_2_3 = A_2_3_;
A_2_4 = A_2_4_;
A_2_5 = A_2_5_;
A_2_6 = A_2_6_;
A_2_7 = A_2_7_;
A_2_8 = A_2_8_;
A_2_9 = A_2_9_;
A_2_10 = A_2_10_;
A_2_11 = A_2_11_;
A_2_12 = A_2_12_;
A_3_1 = A_3_1_;
A_3_2 = A_3_2_;
A_3_3 = A_3_3_;
A_3_4 = A_3_4_;
A_3_5 = A_3_5_;
A_3_6 = A_3_6_;
A_3_7 = A_3_7_;
A_3_8 = A_3_8_;
A_3_9 = A_3_9_;
A_3_10 = A_3_10_;
A_3_11 = A_3_11_;
A_3_12 = A_3_12_;
A_4_1 = A_4_1_;
A_4_2 = A_4_2_;
A_4_3 = A_4_3_;
A_4_4 = A_4_4_;
A_4_5 = A_4_5_;
A_4_6 = A_4_6_;
A_4_7 = A_4_7_;
A_4_8 = A_4_8_;
A_4_9 = A_4_9_;
A_4_10 = A_4_10_;
A_4_11 = A_4_11_;
A_4_12 = A_4_12_;
A_5_1 = A_5_1_;
A_5_2 = A_5_2_;
A_5_3 = A_5_3_;
A_5_4 = A_5_4_;
A_5_5 = A_5_5_;
A_5_6 = A_5_6_;
A_5_7 = A_5_7_;
A_5_8 = A_5_8_;
A_5_9 = A_5_9_;
A_5_10 = A_5_10_;
A_5_11 = A_5_11_;
A_5_12 = A_5_12_;
A_6_1 = A_6_1_;
A_6_2 = A_6_2_;
A_6_3 = A_6_3_;
A_6_4 = A_6_4_;
A_6_5 = A_6_5_;
A_6_6 = A_6_6_;
A_6_7 = A_6_7_;
A_6_8 = A_6_8_;
A_6_9 = A_6_9_;
A_6_10 = A_6_10_;
A_6_11 = A_6_11_;
A_6_12 = A_6_12_;
A_7_1 = A_7_1_;
A_7_2 = A_7_2_;
A_7_3 = A_7_3_;
A_7_4 = A_7_4_;
A_7_5 = A_7_5_;
A_7_6 = A_7_6_;
A_7_7 = A_7_7_;
A_7_8 = A_7_8_;
A_7_9 = A_7_9_;
A_7_10 = A_7_10_;
A_7_11 = A_7_11_;
A_7_12 = A_7_12_;
A_8_1 = A_8_1_;
A_8_2 = A_8_2_;
A_8_3 = A_8_3_;
A_8_4 = A_8_4_;
A_8_5 = A_8_5_;
A_8_6 = A_8_6_;
A_8_7 = A_8_7_;
A_8_8 = A_8_8_;
A_8_9 = A_8_9_;
A_8_10 = A_8_10_;
A_8_11 = A_8_11_;
A_8_12 = A_8_12_;
A_9_1 = A_9_1_;
A_9_2 = A_9_2_;
A_9_3 = A_9_3_;
A_9_4 = A_9_4_;
A_9_5 = A_9_5_;
A_9_6 = A_9_6_;
A_9_7 = A_9_7_;
A_9_8 = A_9_8_;
A_9_9 = A_9_9_;
A_9_10 = A_9_10_;
A_9_11 = A_9_11_;
A_9_12 = A_9_12_;
A_10_1 = A_10_1_;
A_10_2 = A_10_2_;
A_10_3 = A_10_3_;
A_10_4 = A_10_4_;
A_10_5 = A_10_5_;
A_10_6 = A_10_6_;
A_10_7 = A_10_7_;
A_10_8 = A_10_8_;
A_10_9 = A_10_9_;
A_10_10 = A_10_10_;
A_10_11 = A_10_11_;
A_10_12 = A_10_12_;
A_11_1 = A_11_1_;
A_11_2 = A_11_2_;
A_11_3 = A_11_3_;
A_11_4 = A_11_4_;
A_11_5 = A_11_5_;
A_11_6 = A_11_6_;
A_11_7 = A_11_7_;
A_11_8 = A_11_8_;
A_11_9 = A_11_9_;
A_11_10 = A_11_10_;
A_11_11 = A_11_11_;
A_11_12 = A_11_12_;
A_12_1 = A_12_1_;
A_12_2 = A_12_2_;
A_12_3 = A_12_3_;
A_12_4 = A_12_4_;
A_12_5 = A_12_5_;
A_12_6 = A_12_6_;
A_12_7 = A_12_7_;
A_12_8 = A_12_8_;
A_12_9 = A_12_9_;
A_12_10 = A_12_10_;
A_12_11 = A_12_11_;
A_12_12 = A_12_12_;

KG_1_1 = KG_1_1_;
KG_1_2 = KG_1_2_;
KG_2_1 = KG_2_1_;
KG_2_2 = KG_2_2_;
KG_3_1 = KG_3_1_;
KG_3_2 = KG_3_2_;
KG_4_1 = KG_4_1_;
KG_4_2 = KG_4_2_;
KG_5_1 = KG_5_1_;
KG_5_2 = KG_5_2_;
KG_6_1 = KG_6_1_;
KG_6_2 = KG_6_2_;
KG_7_1 = KG_7_1_;
KG_7_2 = KG_7_2_;
KG_8_1 = KG_8_1_;
KG_8_2 = KG_8_2_;
KG_9_1 = KG_9_1_;
KG_9_2 = KG_9_2_;
KG_10_1 = KG_10_1_;
KG_10_2 = KG_10_2_;
KG_11_1 = KG_11_1_;
KG_11_2 = KG_11_2_;
KG_12_1 = KG_12_1_;
KG_12_2 = KG_12_2_;

CA_1_1 = CA_1_1_;
CA_1_2 = CA_1_2_;
CA_1_3 = CA_1_3_;
CA_1_4 = CA_1_4_;
CA_1_5 = CA_1_5_;
CA_1_6 = CA_1_6_;
CA_1_7 = CA_1_7_;
CA_1_8 = CA_1_8_;
CA_1_9 = CA_1_9_;
CA_1_10 = CA_1_10_;
CA_1_11 = CA_1_11_;
CA_1_12 = CA_1_12_;
CA_2_1 = CA_2_1_;
CA_2_2 = CA_2_2_;
CA_2_3 = CA_2_3_;
CA_2_4 = CA_2_4_;
CA_2_5 = CA_2_5_;
CA_2_6 = CA_2_6_;
CA_2_7 = CA_2_7_;
CA_2_8 = CA_2_8_;
CA_2_9 = CA_2_9_;
CA_2_10 = CA_2_10_;
CA_2_11 = CA_2_11_;
CA_2_12 = CA_2_12_;

G_1_1 = G_1_1_;
G_1_2 = G_1_2_;
G_2_1 = G_2_1_;
G_2_2 = G_2_2_;

// Model 
model(linear); 

//  BLOCK 0: INFO STRUCTURE (BLL) 
     
aux_1  =  +A_1_1*aux_1(-1) +A_1_2*aux_2(-1) +A_1_3*aux_3(-1) +A_1_4*aux_4(-1) +A_1_5*aux_5(-1) +A_1_6*aux_6(-1) +A_1_7*aux_7(-1) +A_1_8*aux_8(-1) +A_1_9*aux_9(-1) +A_1_10*aux_10(-1) +A_1_11*aux_11(-1) +A_1_12*aux_12(-1)  +KG_1_1*e_1 +KG_1_2*e_2 ;
aux_2  =  +A_2_1*aux_1(-1) +A_2_2*aux_2(-1) +A_2_3*aux_3(-1) +A_2_4*aux_4(-1) +A_2_5*aux_5(-1) +A_2_6*aux_6(-1) +A_2_7*aux_7(-1) +A_2_8*aux_8(-1) +A_2_9*aux_9(-1) +A_2_10*aux_10(-1) +A_2_11*aux_11(-1) +A_2_12*aux_12(-1)  +KG_2_1*e_1 +KG_2_2*e_2 ;
aux_3  =  +A_3_1*aux_1(-1) +A_3_2*aux_2(-1) +A_3_3*aux_3(-1) +A_3_4*aux_4(-1) +A_3_5*aux_5(-1) +A_3_6*aux_6(-1) +A_3_7*aux_7(-1) +A_3_8*aux_8(-1) +A_3_9*aux_9(-1) +A_3_10*aux_10(-1) +A_3_11*aux_11(-1) +A_3_12*aux_12(-1)  +KG_3_1*e_1 +KG_3_2*e_2 ;
aux_4  =  +A_4_1*aux_1(-1) +A_4_2*aux_2(-1) +A_4_3*aux_3(-1) +A_4_4*aux_4(-1) +A_4_5*aux_5(-1) +A_4_6*aux_6(-1) +A_4_7*aux_7(-1) +A_4_8*aux_8(-1) +A_4_9*aux_9(-1) +A_4_10*aux_10(-1) +A_4_11*aux_11(-1) +A_4_12*aux_12(-1)  +KG_4_1*e_1 +KG_4_2*e_2 ;
aux_5  =  +A_5_1*aux_1(-1) +A_5_2*aux_2(-1) +A_5_3*aux_3(-1) +A_5_4*aux_4(-1) +A_5_5*aux_5(-1) +A_5_6*aux_6(-1) +A_5_7*aux_7(-1) +A_5_8*aux_8(-1) +A_5_9*aux_9(-1) +A_5_10*aux_10(-1) +A_5_11*aux_11(-1) +A_5_12*aux_12(-1)  +KG_5_1*e_1 +KG_5_2*e_2 ;
aux_6  =  +A_6_1*aux_1(-1) +A_6_2*aux_2(-1) +A_6_3*aux_3(-1) +A_6_4*aux_4(-1) +A_6_5*aux_5(-1) +A_6_6*aux_6(-1) +A_6_7*aux_7(-1) +A_6_8*aux_8(-1) +A_6_9*aux_9(-1) +A_6_10*aux_10(-1) +A_6_11*aux_11(-1) +A_6_12*aux_12(-1)  +KG_6_1*e_1 +KG_6_2*e_2 ;
aux_7  =  +A_7_1*aux_1(-1) +A_7_2*aux_2(-1) +A_7_3*aux_3(-1) +A_7_4*aux_4(-1) +A_7_5*aux_5(-1) +A_7_6*aux_6(-1) +A_7_7*aux_7(-1) +A_7_8*aux_8(-1) +A_7_9*aux_9(-1) +A_7_10*aux_10(-1) +A_7_11*aux_11(-1) +A_7_12*aux_12(-1)  +KG_7_1*e_1 +KG_7_2*e_2 ;
aux_8  =  +A_8_1*aux_1(-1) +A_8_2*aux_2(-1) +A_8_3*aux_3(-1) +A_8_4*aux_4(-1) +A_8_5*aux_5(-1) +A_8_6*aux_6(-1) +A_8_7*aux_7(-1) +A_8_8*aux_8(-1) +A_8_9*aux_9(-1) +A_8_10*aux_10(-1) +A_8_11*aux_11(-1) +A_8_12*aux_12(-1)  +KG_8_1*e_1 +KG_8_2*e_2 ;
aux_9  =  +A_9_1*aux_1(-1) +A_9_2*aux_2(-1) +A_9_3*aux_3(-1) +A_9_4*aux_4(-1) +A_9_5*aux_5(-1) +A_9_6*aux_6(-1) +A_9_7*aux_7(-1) +A_9_8*aux_8(-1) +A_9_9*aux_9(-1) +A_9_10*aux_10(-1) +A_9_11*aux_11(-1) +A_9_12*aux_12(-1)  +KG_9_1*e_1 +KG_9_2*e_2 ;
aux_10  =  +A_10_1*aux_1(-1) +A_10_2*aux_2(-1) +A_10_3*aux_3(-1) +A_10_4*aux_4(-1) +A_10_5*aux_5(-1) +A_10_6*aux_6(-1) +A_10_7*aux_7(-1) +A_10_8*aux_8(-1) +A_10_9*aux_9(-1) +A_10_10*aux_10(-1) +A_10_11*aux_11(-1) +A_10_12*aux_12(-1)  +KG_10_1*e_1 +KG_10_2*e_2 ;
aux_11  =  +A_11_1*aux_1(-1) +A_11_2*aux_2(-1) +A_11_3*aux_3(-1) +A_11_4*aux_4(-1) +A_11_5*aux_5(-1) +A_11_6*aux_6(-1) +A_11_7*aux_7(-1) +A_11_8*aux_8(-1) +A_11_9*aux_9(-1) +A_11_10*aux_10(-1) +A_11_11*aux_11(-1) +A_11_12*aux_12(-1)  +KG_11_1*e_1 +KG_11_2*e_2 ;
aux_12  =  +A_12_1*aux_1(-1) +A_12_2*aux_2(-1) +A_12_3*aux_3(-1) +A_12_4*aux_4(-1) +A_12_5*aux_5(-1) +A_12_6*aux_6(-1) +A_12_7*aux_7(-1) +A_12_8*aux_8(-1) +A_12_9*aux_9(-1) +A_12_10*aux_10(-1) +A_12_11*aux_11(-1) +A_12_12*aux_12(-1)  +KG_12_1*e_1 +KG_12_2*e_2 ;
s_1  =  +CA_1_1*aux_1(-1) +CA_1_2*aux_2(-1) +CA_1_3*aux_3(-1) +CA_1_4*aux_4(-1) +CA_1_5*aux_5(-1) +CA_1_6*aux_6(-1) +CA_1_7*aux_7(-1) +CA_1_8*aux_8(-1) +CA_1_9*aux_9(-1) +CA_1_10*aux_10(-1) +CA_1_11*aux_11(-1) +CA_1_12*aux_12(-1)  +G_1_1*e_1 +G_1_2*e_2 ;
s_2  =  +CA_2_1*aux_1(-1) +CA_2_2*aux_2(-1) +CA_2_3*aux_3(-1) +CA_2_4*aux_4(-1) +CA_2_5*aux_5(-1) +CA_2_6*aux_6(-1) +CA_2_7*aux_7(-1) +CA_2_8*aux_8(-1) +CA_2_9*aux_9(-1) +CA_2_10*aux_10(-1) +CA_2_11*aux_11(-1) +CA_2_12*aux_12(-1)  +G_2_1*e_1 +G_2_2*e_2 ;

// BLOCK 1: EXOGENOUS PROCESSES

//  TFP Processes  (BLL)   
        TFP - TFP(-1)    = s_1; 
        TFPForeign  - TFPForeign(-1)  = tau*(TFP(-1) - TFPForeign(-1));   // no foreign shock, as in CompleteMarketsModel.mod and the appendix
        
        TFPDifferential = TFP - TFPForeign;
        a20 = TFP(20);

        TFPChange = TFP - TFP(-1);
        TFPChangeForeign = TFPForeign - TFPForeign(-1);

        ds_1 = s_1 - s_1(-1);

//--- RestOfModel

ConsumptionDifferential = VARSIGMA * (X_YForeign) + (1-VARSIGMA) * (Y_XForeign);

ConsumptionDifferential(1) = ConsumptionDifferential + 1/GAMMA * RealInterestRateDifferential;

BETA*b - b(-1) =  - (1-VARSIGMA)*Y_XForeign - (1-VARSIGMA)*TermsOfTrade;

TFP - TFPForeign = VARSIGMA * X_YForeign + - (1-VARSIGMA) * Y_XForeign;

X_YForeign - Y_XForeign =   2*SIGMA  * TermsOfTrade;

RealExchangeRate = (2*VARSIGMA-1) * TermsOfTrade;

RealExchangeRate(1) - RealExchangeRate = RealInterestRateDifferential + phi_1 * b;
ExpectedExcessCurrencyReturns = RealExchangeRate(1) -RealExchangeRate - RealInterestRateDifferential;

RealExchangeRateUIP = - RealInterestRateDifferential + 0.99999*RealExchangeRateUIP(1);
RealExchangeRateLambda = - ExpectedExcessCurrencyReturns + 0.99999*RealExchangeRateLambda(1);

end;   

shocks;

// BLL
var e_1; stderr 0.01;  var e_2; stderr 0.01;

end;

steady;

check;

stoch_simul(order=1, periods=0, nograph, irf = 50);
// stoch_simul(order=1, periods= 120, simul_replic = 10000, irf=20, nograph); sim_array = get_simul_replications(M_,options_);

