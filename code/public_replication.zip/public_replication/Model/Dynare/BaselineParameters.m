% Preferences
beta_   = 0.99; % Subjective discount factor 
gam_    = 5;    % CRRA parameter Risk aversion (CCHH: 10.45, CC13: 8, CC11: 4.25)
lambda_ = 0.80; % 0.95   % Consumption Home bias (0.95)


% Productivity process
tau_    = 0.025; % 0.05% 0.085; % 0.0023;  Co-integration parameter (0.007, 0.0005) ANNUAL
mu_ = 0;

%only for IncompleteMarkets
phi_1_ = 10^(-2); % interest rate premium elasticity
SIGMA_ = 1; % trade elasticity 

