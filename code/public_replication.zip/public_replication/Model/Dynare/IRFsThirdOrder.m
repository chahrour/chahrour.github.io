% Reproduce IRFs for models that are solved at third order, by running
% baseline VAR on model-simulated data

clearvars -except oo_ M_ beta_ gam_ ies_ lambda_ mu_ rho_ tau_; 

% The simulated series stay in memory; this used to round-trip 21.7 MB
% through SimulatedSeries.mat only to load it straight back.

clc;
addpath DSGE_tools/
addpath Auxiliary_Functions/


%--VAR parameters:

NLAGS = 4;
SAMPLE_SIZE = 8500;

RealExchangeRate = oo_.endo_simul(strcmp(M_.endo_names, 'RealExchangeRate'),:)';
TFP = oo_.endo_simul(strcmp(M_.endo_names, 'TFP'),:)';
Consumption = oo_.endo_simul(strcmp(M_.endo_names, 'Consumption'),:)';
ConsumptionForeign = oo_.endo_simul(strcmp(M_.endo_names, 'ConsumptionForeign'),:)';
Investment = oo_.endo_simul(strcmp(M_.endo_names, 'Investment'),:)';
Bond = oo_.endo_simul(strcmp(M_.endo_names, 'b'),:)';
InvestmentForeign = oo_.endo_simul(strcmp(M_.endo_names, 'InvestmentForeign'),:)';
RealInterestRateDifferential = oo_.endo_simul(strcmp(M_.endo_names, 'RealInterestRateDifferential'),:)';
ExpectedTFP = oo_.endo_simul(strcmp(M_.endo_names, 'a20'),:)';
TFPForeign = oo_.endo_simul(strcmp(M_.endo_names, 'TFPForeign'),:)';
ZZZ = oo_.endo_simul(strcmp(M_.endo_names, 'z'),:)';
ExpectedExcessCurrencyReturns= oo_.endo_simul(strcmp(M_.endo_names, 'ExpectedExcessCurrencyReturns'),:)';

% Add measurement error:
M_ERR = 0.1;  % \% of standard deviation
RealExchangeRate = RealExchangeRate + randn(size(RealExchangeRate)).*M_ERR.*std(diff(RealExchangeRate));
TFP = TFP + randn(size(TFP)).*M_ERR.*std(diff(TFP));
Consumption = oo_.endo_simul(strcmp(M_.endo_names, 'Consumption'),:)'+ randn(size(Consumption)).*M_ERR.*std(diff(Consumption));
ConsumptionForeign = oo_.endo_simul(strcmp(M_.endo_names, 'ConsumptionForeign'),:)'+ randn(size(ConsumptionForeign)).*M_ERR.*std(diff(ConsumptionForeign));
RealInterestRateDifferential = RealInterestRateDifferential + randn(size(RealInterestRateDifferential)).*M_ERR.*std(diff(RealInterestRateDifferential));
TFPForeign = TFPForeign + randn(size(TFPForeign)).*M_ERR.*std(diff(TFPForeign));
ExpectedExcessCurrencyReturns = ExpectedExcessCurrencyReturns + randn(size(ExpectedExcessCurrencyReturns)).*M_ERR.*std(diff(ExpectedExcessCurrencyReturns));
Bond = Bond + randn(size(RealInterestRateDifferential)).*M_ERR.*std(diff(RealInterestRateDifferential));


foreign_tfp = 0; %1 include foreign tfp

if foreign_tfp == 0
  data = [TFP, Consumption, ExpectedExcessCurrencyReturns, RealExchangeRate, RealInterestRateDifferential, ConsumptionForeign, TFPForeign];
    vnames = {'Home TFP' ,'Home Consumption','Home Investment','Real Exchange Rate','Interest Rate Differential','Foreign Consumption',...
          'Foreign Investment','E[TFP]','ENER','Expected Excess Returns','Interest Rate Differential',...
          'NA','ERER','Real Exchange Rate','BS Wedge','$\Delta$BS Wedge', '$\Delta q_t$','RER(Ex. Ret)','Consumption Differential','Investment Differential', ...
           'E($TFP_{t+1}$)', 'E($TFP_{t+5}$)', 'Rlzd Excess Returns', 'Rlzd Cum Excess Ret','RER(UIP)' };

elseif foreign_tfp == 1
    data = [TFP, Consumption, Investment, RealExchangeRate, RealInterestRateDifferential, ConsumptionForeign, ...
        InvestmentForeign, TFPForeign];
    vnames = {'Home TFP' ,'Home Consumption','Home Investment','Real Exchange Rate','Interest Rate Differential','Foreign Consumption',...
          'Foreign Investment','Foreign TFP','E[TFP]','ENER','Expected Excess Returns','Interest Rate Differential',...
          'E[$TFP^*$]','ERER','Real Exchange Rate','BS Wedge','$\Delta$BS Wedge', '$\Delta q_t$','RER(Ex. Ret)','Consumption Differential','Investment Differential', ...
           'E($TFP_{t+1}$)', 'E($TFP_{t+5}$)', 'Rlzd Excess Returns', 'Rlzd Cum Excess Ret','RER(UIP)' };

end

%---estimate CJ IRFs
fdvar =[];
nvars = size(data,2);

% Choose which variables to plot  --refer to vnames cell to link indeces to variables.
order_fig2a = [1,21+foreign_tfp,22+foreign_tfp,8+foreign_tfp]; 
order_fig2b = [1,11+foreign_tfp,2,14+foreign_tfp,6,10+foreign_tfp];

order = [2,6,3,7,11+foreign_tfp,14+foreign_tfp,11+foreign_tfp,1]';
order_vdec = [1,2,6,3,7,11+foreign_tfp,14+foreign_tfp,10+foreign_tfp,17+foreign_tfp];

nlags                 = NLAGS;     % number of lags in VAR (4)
nconst                = 1;     % 1 = constant for , 0 otherwise
prior                 = 1;     % pror \in (0,inf);  1 =  standard prior;  inf = flat prior
prior_norm            = 0;     % if 1, then normalize prior variance on AR coefficients by std. dev. of Y variable residual (as per Hamilton), 0 do not (as in Kose-Otrok).
ndraws                = 1;    %Baseline: 1000 number of draws when computing error bands

% vcase selected a variable case in the retired sweep architecture and is
% always 0 on this path, so the two call sites pass the literal instead. Keeping
% it as a variable also broke parfor, which could not resolve it as a broadcast
% variable once these scripts run under evalin.
     
sample_size = SAMPLE_SIZE;  % length of the simulation

est_method   = 1;   % 1 = Bayesian estimation with Minnesota prior; 
                    % 2 = OLS point estimation and classical bootstrap
                    % 3 = VECM OLS
                    % 4 = VECM with fixed cointegration relationships
                    
shock_extract = 1;  % 1: Max share based on FEDC
                    % 2: Max share based on frequency band decomp
                    % 3: TFP news shock (Barsky-Sims, must order TFP first)
                    % 4: Chol ID of TFP surprise

point_estimate = 0; % 0: use median as the point estimate
                    % 1: use highest posterior likelihood as point
                    % estimate


bidx = ones(nlags*nvars+1,nvars);
bidx(end-1-nvars+fdvar,:) = 0.000000001;


indiv_coeff_priorvar  = bidx(:);   %%%% Scale prior variance of individual coeffs. Variable is 8 vectors of 33 stacked together. First 33 are the coeffs on all variables in first equation and etc. Constant is entry 33, 1:8 first lags of 8 vars, 9:18 second lags and etc. 
indiv_coeff_priormean = ones(nvars,1);     %%%% Can be used to zero out first-lag coefficients in self-equations


maxeig_cutoff = 1;   %% 1 to not keep explosive draws; inf to keep all; etc.

% --- VECM options
param.nlag    = nlags-1;    %Lags, in difference, in VECM
param.nrank   = 0; 
param.det_var = 1;          %Include a constant in VAR
param.ttrend  = 0;          %Include a time trend?
param.det_ec  = 0;          %Include a constant in cointegration expression?
param.nper    = 32;         %Number of periods in FEVD
param.check_rank = false;   %Check rank condition for Identification (that VAR is locally identified)

% Max share identification options
bound  = 0.16;   % dark grey    % lower bound of confidence interval
bound2 = 0.1;    % light grey   % (e.g. for bound=0.16, CI is 68%)
nimp   = 100;                   % horizon of VD and IRFs to be computed
nplot  = 40;                    % horizon to be plotted
KLbar  = 100; %100 ;                  % lower horizon bound for max FEV share objective  
KUbar  = 100; %100;                  % higher horizon bound for max FEV share objective  
KLbar_freq = 2*pi/1000;         % lower  freq bound for frequency share objective
KUbar_freq = 2*pi/2;            % higher freq bound for frequency share objective

% CJ horizon choice
j_cj_horizon = 20; %20
smax         = 200; %Baseline:4000 

vd_feh = [1,4,12,24,40,100];   %%% forecast error horizons for FEV decompositions

vd_fr = [2*pi/100,2*pi/2; 2*pi/3000,2*pi/2; 2*pi/32,2*pi/6];

% Data
data = data(1:sample_size,:);

% Estimate VARs
%
% RECONCILED WITH THE PACKAGE'S genvars. This called a script of the same name
% that read these settings out of the workspace and wrote Dataset_Output/vars
% itself. The package's genvars is that script promoted to a function -- same
% lineage, same estimator -- so it is called directly here and the settings
% defined above are passed in rather than picked up implicitly. There is one
% genvars in this package, not two.
%
% maxeig_cutoff = 1 matches estimate_one.
%
% The point estimate is the last element of each returned cell: genvars appends
% it after the draws. The chain downstream wants the point estimate alone, which
% is what the original script stored.
mdl_info = struct( ...
    'method',   est_method, ...
    'settings', struct( ...
        'nlags',                 nlags, ...
        'ndraws',                ndraws, ...
        'nconst',                nconst, ...
        'prior',                 prior, ...
        'prior_norm',            prior_norm, ...
        'indiv_coeff_priorvar',  indiv_coeff_priorvar, ...
        'indiv_coeff_priormean', indiv_coeff_priormean, ...
        'point_estimate',        point_estimate, ...
        'maxeig_cutoff',         1));

[ARs, Sigs, Res] = genvars(data, mdl_info);
ARs = ARs(end);  Sigs = Sigs(end);  Res = Res(end);

% ARs/Sigs/Res stay in the workspace: the three steps below read them directly.

% CJ IDENTIFICATION, through the package's own sweep rather than the three
% symbolic scripts this chain used to call.
%
% gentfp_gennoisecoeffs factored the log spectrum symbolically -- reset(symengine)
% and all -- and wrote coefficient files that gentfp_freq_baseline_fast and
% gennoise_baseline_fast read back to build the responses. gen_cj_irfs_tfsweep
% does the same identification without the Symbolic Math Toolbox: one 2^16-point
% frequency grid, Wold factors from the cepstrum of the log spectrum, and the
% responses by ifft. It also fixes a grid-aliasing error the old path had, where a
% near-unit root decaying over ~1e4 quarters wrapped back into the plotted lags.
%
% It needs the auxvars builder swapped, because the model's simulated system has
% no ner and no cpidiff: cj_auxfun points it at MODEL_CJ_AUXVARS, which wraps this
% chain's own MODEL_GEN_AUXVARS.
cj_auxfun = @model_cj_auxvars;

% The sweep reads these from the workspace. Aproj and datakeys are inert on this
% path -- nothing is projected -- but it expects them to exist.
Aproj    = zeros(nvars, nvars*nlags);
datakeys = cell(1, nvars);
for k = 1:nvars; datakeys{k} = sprintf('v%d', k); end

gen_cj_irfs_tfsweep;  % smax=250

% Nothing is cleared and nothing reloaded: ARs, Sigs, irtfp, irnoise and the
% variance shares are all in this workspace already.

irtfp = irtfp.*100; % for comparison with empirical responses
irnoise = irnoise.*100; % for comparison with empirical responses


%% Plot results

order_fig2a = [1,21,22,8]; 
order_fig2b = [1,11,2,14,19,10];
lab = vnames;
lab{8}='Expected Home TFP';
lab{9}='Expected Home TFP';
lab{3}='Expected Excess Returns';
 
% Horizon for impulse responses
h     = (size(irtfp,1)-1)/2;
hgrid = -50:20;
discard = 30; % how many IRFs to discard when plotting

irtfp   = cumsum(irtfp);
irnoise = cumsum(irnoise);

irtfp   = irtfp(hgrid+h+1,:,:);
irnoise = irnoise(hgrid+h+1,:,:);

irtfp1 = irtfp;
irnoise1 = irnoise;


% Figure 2: TFP only
dataplots_tfp       = NaN(size(irtfp,1)-discard,  2*size(irtfp,2),5);
dataplots_noise     = dataplots_tfp;
%%%
dataplots_tfp(:,:,1) = [irtfp1(discard+1:end,:),irtfp1(discard+1:end,:)];
dataplots_tfp(:,:,4)=  [irtfp1(discard+1:end,:),irtfp1(discard+1:end,:)];
dataplots_tfp(:,:,5)=  [irtfp1(discard+1:end,:),irtfp1(discard+1:end,:)];
dataplots_tfp(:,:,2)=  [irtfp1(discard+1:end,:),irtfp1(discard+1:end,:)];
dataplots_tfp(:,:,3)=  [irtfp1(discard+1:end,:),irtfp1(discard+1:end,:)];

% Figure 3: Noise only
dataplots_noise(:,:,1) = [irnoise1(discard+1:end,:),irnoise1(discard+1:end,:)];
dataplots_noise(:,:,4)=  [irnoise1(discard+1:end,:),irnoise1(discard+1:end,:)];
dataplots_noise(:,:,5)=  [irnoise1(discard+1:end,:),irnoise1(discard+1:end,:)];
dataplots_noise(:,:,2)=  [irnoise1(discard+1:end,:),irnoise1(discard+1:end,:)];
dataplots_noise(:,:,3)=  [irnoise1(discard+1:end,:),irnoise1(discard+1:end,:)];
dataplots_noise(:,[1 size(irtfp,2)+1],:) = zeros(41,2,5); % zero out TFP response to noise

%--September 2025
dataplots_noise(1:20,:,:) = zeros(size(dataplots_noise(1:20,:,:)));


