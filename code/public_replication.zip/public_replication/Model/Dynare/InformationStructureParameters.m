% Set parameters for exogenous processes and information structure

param.rho    = 0.891092390000000;
param.sigtmp = .5*1.229476460000000;
param.sigv   = .5*0.000100040000000;
% [A, KG, CA, G, K, C] = quick_kalman_noise_ccdgv(param); % gen kalman parameters
[A, KG, CA, G, K, C, S_1, B] = quick_kalman_noise_ccdgv(param); % gen kalman parameters

save kalman_paramsmat2026;


SIZE = size(A,2);

format long
for ii = 1:SIZE
    for jj = 1:SIZE
    temp{jj} = ['+',num2str(A(ii,jj), '%.40f'),'*','aux_',num2str(jj),'(-1)'];
    end
    for kk = 1:2
    ferr{kk} = ['+',num2str(KG(ii,kk), '%.40f'),'*','e_',num2str(kk)];
    end
    ROW = {['aux_',num2str(ii)],' = ',temp{1:SIZE},ferr{1:2},';'};
    DYN = strjoin(ROW);
    VAR{ii} = ['aux_',num2str(ii)];
end

for ii = 1:2
   for jj = 1:SIZE
   temp2{jj} = ['+',num2str(CA(ii,jj), '%.40f'),'*','aux_',num2str(jj),'(-1)'];
   end
   for kk = 1:2
   ferr2{kk} = ['+',num2str(G(ii,kk), '%.40f'),'*','e_',num2str(kk)];
   end
   ROW = {['s_',num2str(ii)],' = ',temp2{1:SIZE},ferr2{1:2},';'};
   DYN = strjoin(ROW);
   VAR2{ii} = ['s_',num2str(ii)];
end

% assign parameters for Dynare

format long
num_decimals = 100;
A_1_1_ = vpa(A(1,1), num_decimals);
A_1_2_ = vpa(A(1,2), num_decimals);
A_1_3_ = vpa(A(1,3), num_decimals);
A_1_4_ = vpa(A(1,4), num_decimals);
A_1_5_ = vpa(A(1,5), num_decimals);
A_1_6_ = vpa(A(1,6), num_decimals);
A_1_7_ = vpa(A(1,7), num_decimals);
A_1_8_ = vpa(A(1,8), num_decimals);
A_1_9_ = vpa(A(1,9), num_decimals);
A_1_10_ = vpa(A(1,10), num_decimals);
A_1_11_ = vpa(A(1,11), num_decimals);
A_1_12_ = vpa(A(1,12), num_decimals);

A_2_1_ = vpa(A(2,1), num_decimals);
A_2_2_ = vpa(A(2,2), num_decimals);
A_2_3_ = vpa(A(2,3), num_decimals);
A_2_4_ = vpa(A(2,4), num_decimals);
A_2_5_ = vpa(A(2,5), num_decimals);
A_2_6_ = vpa(A(2,6), num_decimals);
A_2_7_ = vpa(A(2,7), num_decimals);
A_2_8_ = vpa(A(2,8), num_decimals);
A_2_9_ = vpa(A(2,9), num_decimals);
A_2_10_ = vpa(A(2,10), num_decimals);
A_2_11_ = vpa(A(2,11), num_decimals);
A_2_12_ = vpa(A(2,12), num_decimals);

A_3_1_ = vpa(A(3,1), num_decimals);
A_3_2_ = vpa(A(3,2), num_decimals);
A_3_3_ = vpa(A(3,3), num_decimals);
A_3_4_ = vpa(A(3,4), num_decimals);
A_3_5_ = vpa(A(3,5), num_decimals);
A_3_6_ = vpa(A(3,6), num_decimals);
A_3_7_ = vpa(A(3,7), num_decimals);
A_3_8_ = vpa(A(3,8), num_decimals);
A_3_9_ = vpa(A(3,9), num_decimals);
A_3_10_ = vpa(A(3,10), num_decimals);
A_3_11_ = vpa(A(3,11), num_decimals);
A_3_12_ = vpa(A(3,12), num_decimals);

A_4_1_ = vpa(A(4,1), num_decimals);
A_4_2_ = vpa(A(4,2), num_decimals);
A_4_3_ = vpa(A(4,3), num_decimals);
A_4_4_ = vpa(A(4,4), num_decimals);
A_4_5_ = vpa(A(4,5), num_decimals);
A_4_6_ = vpa(A(4,6), num_decimals);
A_4_7_ = vpa(A(4,7), num_decimals);
A_4_8_ = vpa(A(4,8), num_decimals);
A_4_9_ = vpa(A(4,9), num_decimals);
A_4_10_ = vpa(A(4,10), num_decimals);
A_4_11_ = vpa(A(4,11), num_decimals);
A_4_12_ = vpa(A(4,12), num_decimals);

A_5_1_ = vpa(A(5,1), num_decimals);
A_5_2_ = vpa(A(5,2), num_decimals);
A_5_3_ = vpa(A(5,3), num_decimals);
A_5_4_ = vpa(A(5,4), num_decimals);
A_5_5_ = vpa(A(5,5), num_decimals);
A_5_6_ = vpa(A(5,6), num_decimals);
A_5_7_ = vpa(A(5,7), num_decimals);
A_5_8_ = vpa(A(5,8), num_decimals);
A_5_9_ = vpa(A(5,9), num_decimals);
A_5_10_ = vpa(A(5,10), num_decimals);
A_5_11_ = vpa(A(5,11), num_decimals);
A_5_12_ = vpa(A(5,12), num_decimals);

A_6_1_ = vpa(A(6,1), num_decimals);
A_6_2_ = vpa(A(6,2), num_decimals);
A_6_3_ = vpa(A(6,3), num_decimals);
A_6_4_ = vpa(A(6,4), num_decimals);
A_6_5_ = vpa(A(6,5), num_decimals);
A_6_6_ = vpa(A(6,6), num_decimals);
A_6_7_ = vpa(A(6,7), num_decimals);
A_6_8_ = vpa(A(6,8), num_decimals);
A_6_9_ = vpa(A(6,9), num_decimals);
A_6_10_ = vpa(A(6,10), num_decimals);
A_6_11_ = vpa(A(6,11), num_decimals);
A_6_12_ = vpa(A(6,12), num_decimals);

A_7_1_ = vpa(A(7,1), num_decimals);
A_7_2_ = vpa(A(7,2), num_decimals);
A_7_3_ = vpa(A(7,3), num_decimals);
A_7_4_ = vpa(A(7,4), num_decimals);
A_7_5_ = vpa(A(7,5), num_decimals);
A_7_6_ = vpa(A(7,6), num_decimals);
A_7_7_ = vpa(A(7,7), num_decimals);
A_7_8_ = vpa(A(7,8), num_decimals);
A_7_9_ = vpa(A(7,9), num_decimals);
A_7_10_ = vpa(A(7,10), num_decimals);
A_7_11_ = vpa(A(7,11), num_decimals);
A_7_12_ = vpa(A(7,12), num_decimals);

A_8_1_ = vpa(A(8,1), num_decimals);
A_8_2_ = vpa(A(8,2), num_decimals);
A_8_3_ = vpa(A(8,3), num_decimals);
A_8_4_ = vpa(A(8,4), num_decimals);
A_8_5_ = vpa(A(8,5), num_decimals);
A_8_6_ = vpa(A(8,6), num_decimals);
A_8_7_ = vpa(A(8,7), num_decimals);
A_8_8_ = vpa(A(8,8), num_decimals);
A_8_9_ = vpa(A(8,9), num_decimals);
A_8_10_ = vpa(A(8,10), num_decimals);
A_8_11_ = vpa(A(8,11), num_decimals);
A_8_12_ = vpa(A(8,12), num_decimals);

A_9_1_ = vpa(A(9,1), num_decimals);
A_9_2_ = vpa(A(9,2), num_decimals);
A_9_3_ = vpa(A(9,3), num_decimals);
A_9_4_ = vpa(A(9,4), num_decimals);
A_9_5_ = vpa(A(9,5), num_decimals);
A_9_6_ = vpa(A(9,6), num_decimals);
A_9_7_ = vpa(A(9,7), num_decimals);
A_9_8_ = vpa(A(9,8), num_decimals);
A_9_9_ = vpa(A(9,9), num_decimals);
A_9_10_ = vpa(A(9,10), num_decimals);
A_9_11_ = vpa(A(9,11), num_decimals);
A_9_12_ = vpa(A(9,12), num_decimals);

A_10_1_ = vpa(A(10,1), num_decimals);
A_10_2_ = vpa(A(10,2), num_decimals);
A_10_3_ = vpa(A(10,3), num_decimals);
A_10_4_ = vpa(A(10,4), num_decimals);
A_10_5_ = vpa(A(10,5), num_decimals);
A_10_6_ = vpa(A(10,6), num_decimals);
A_10_7_ = vpa(A(10,7), num_decimals);
A_10_8_ = vpa(A(10,8), num_decimals);
A_10_9_ = vpa(A(10,9), num_decimals);
A_10_10_ = vpa(A(10,10), num_decimals);
A_10_11_ = vpa(A(10,11), num_decimals);
A_10_12_ = vpa(A(10,12), num_decimals);

A_11_1_ = vpa(A(11,1), num_decimals);
A_11_2_ = vpa(A(11,2), num_decimals);
A_11_3_ = vpa(A(11,3), num_decimals);
A_11_4_ = vpa(A(11,4), num_decimals);
A_11_5_ = vpa(A(11,5), num_decimals);
A_11_6_ = vpa(A(11,6), num_decimals);
A_11_7_ = vpa(A(11,7), num_decimals);
A_11_8_ = vpa(A(11,8), num_decimals);
A_11_9_ = vpa(A(11,9), num_decimals);
A_11_10_ = vpa(A(11,10), num_decimals);
A_11_11_ = vpa(A(11,11), num_decimals);
A_11_12_ = vpa(A(11,12), num_decimals);

A_12_1_ = vpa(A(12,1), num_decimals);
A_12_2_ = vpa(A(12,2), num_decimals);
A_12_3_ = vpa(A(12,3), num_decimals);
A_12_4_ = vpa(A(12,4), num_decimals);
A_12_5_ = vpa(A(12,5), num_decimals);
A_12_6_ = vpa(A(12,6), num_decimals);
A_12_7_ = vpa(A(12,7), num_decimals);
A_12_8_ = vpa(A(12,8), num_decimals);
A_12_9_ = vpa(A(12,9), num_decimals);
A_12_10_ = vpa(A(12,10), num_decimals);
A_12_11_ = vpa(A(12,11), num_decimals);
A_12_12_ = vpa(A(12,12), num_decimals);

% Similarly for KG, CA, and G
KG_1_1_ = vpa(KG(1,1), num_decimals);
KG_1_2_ = vpa(KG(1,2), num_decimals);
KG_2_1_ = vpa(KG(2,1), num_decimals);
KG_2_2_ = vpa(KG(2,2), num_decimals);
KG_3_1_ = vpa(KG(3,1), num_decimals);
KG_3_2_ = vpa(KG(3,2), num_decimals);
KG_4_1_ = vpa(KG(4,1), num_decimals);
KG_4_2_ = vpa(KG(4,2), num_decimals);
KG_5_1_ = vpa(KG(5,1), num_decimals);
KG_5_2_ = vpa(KG(5,2), num_decimals);
KG_6_1_ = vpa(KG(6,1), num_decimals);
KG_6_2_ = vpa(KG(6,2), num_decimals);
KG_7_1_ = vpa(KG(7,1), num_decimals);
KG_7_2_ = vpa(KG(7,2), num_decimals);
KG_8_1_ = vpa(KG(8,1), num_decimals);
KG_8_2_ = vpa(KG(8,2), num_decimals);
KG_9_1_ = vpa(KG(9,1), num_decimals);
KG_9_2_ = vpa(KG(9,2), num_decimals);
KG_10_1_ = vpa(KG(10,1), num_decimals);
KG_10_2_ = vpa(KG(10,2), num_decimals);
KG_11_1_ = vpa(KG(11,1), num_decimals);
KG_11_2_ = vpa(KG(11,2), num_decimals);
KG_12_1_ = vpa(KG(12,1), num_decimals);
KG_12_2_ = vpa(KG(12,2), num_decimals);

CA_1_1_ = vpa(CA(1,1), num_decimals);
CA_1_2_ = vpa(CA(1,2), num_decimals);
CA_1_3_ = vpa(CA(1,3), num_decimals);
CA_1_4_ = vpa(CA(1,4), num_decimals);
CA_1_5_ = vpa(CA(1,5), num_decimals);
CA_1_6_ = vpa(CA(1,6), num_decimals);
CA_1_7_ = vpa(CA(1,7), num_decimals);
CA_1_8_ = vpa(CA(1,8), num_decimals);
CA_1_9_ = vpa(CA(1,9), num_decimals);
CA_1_10_ = vpa(CA(1,10), num_decimals);
CA_1_11_ = vpa(CA(1,11), num_decimals);
CA_1_12_ = vpa(CA(1,12), num_decimals);

CA_2_1_ = vpa(CA(2,1), num_decimals);
CA_2_2_ = vpa(CA(2,2), num_decimals);
CA_2_3_ = vpa(CA(2,3), num_decimals);
CA_2_4_ = vpa(CA(2,4), num_decimals);
CA_2_5_ = vpa(CA(2,5), num_decimals);
CA_2_6_ = vpa(CA(2,6), num_decimals);
CA_2_7_ = vpa(CA(2,7), num_decimals);
CA_2_8_ = vpa(CA(2,8), num_decimals);
CA_2_9_ = vpa(CA(2,9), num_decimals);
CA_2_10_ = vpa(CA(2,10), num_decimals);
CA_2_11_ = vpa(CA(2,11), num_decimals);
CA_2_12_ = vpa(CA(2,12), num_decimals);

G_1_1_ = vpa(G(1,1), num_decimals);
G_1_2_ = vpa(G(1,2), num_decimals);
G_2_1_ = vpa(G(2,1), num_decimals);
G_2_2_ = vpa(G(2,2), num_decimals);

