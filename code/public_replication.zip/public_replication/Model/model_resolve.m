function model_resolve(which, dynare_path)
%MODEL_RESOLVE  Re-solve the models with Dynare and regenerate the stored IRFs.
%
%   model_resolve                      all four solves
%   model_resolve('cm1')               complete markets, CRRA, first order
%   model_resolve('cm3')               complete markets, Epstein-Zin, third order
%   model_resolve('im')                incomplete markets, CRRA
%   model_resolve('lrr')               long-run risk, third order (Figure D.1)
%   model_resolve(which, dynare_path)  overrides mcfg.dynare_path
%
%   Optional: the exhibits build from the IRFs already in saved_model/. Needs
%   Dynare 6.1 and the Symbolic Math Toolbox. dynare_path is Dynare's matlab/
%   directory.
%
%   Each solve runs in the base workspace, because Dynare runs its driver script
%   there, and begins by clearing it. Model/Dynare is on the path while this
%   runs and shadows the estimation code; the path is restored on exit.
%
%   See also RUN_MODEL, MODEL_CONFIG, GENVARS.

    if nargin < 1 || isempty(which); which = 'all'; end
    mcfg = model_config();
    if nargin >= 2 && ~isempty(dynare_path); mcfg.dynare_path = dynare_path; end

    assert(~isempty(mcfg.dynare_path), 'model_resolve:noDynare', ...
        ['Dynare''s matlab/ directory is not set. Pass it as the second ' ...
         'argument, or set mcfg.dynare_path in model_config.m. Dynare 6.1 is ' ...
         'the version that produced the published figures.']);
    assert(isfolder(mcfg.dynare_path), 'model_resolve:badDynare', ...
        '%s is not a directory.', mcfg.dynare_path);
    assert(isfile(fullfile(mcfg.dynare_path,'dynare.m')), 'model_resolve:notDynare', ...
        '%s holds no dynare.m -- point this at Dynare''s matlab/ directory.', ...
        mcfg.dynare_path);

    fprintf(['\n  model_resolve puts Model/Dynare on the path, which shadows the\n' ...
             '  estimation code. Do empirical work in a fresh session afterwards.\n' ...
             '  IT ALSO CLEARS THE BASE WORKSPACE: each solve starts from a clean\n' ...
             '  base because Dynare runs its driver there, so any variable you had\n' ...
             '  is gone when this returns. Save anything you need first.\n']);

    addpath(mcfg.dynare_path);
    % Model/ itself: the third-order IRFs call MODEL_CJ_AUXVARS from here, and
    % the solves run from Model/Dynare, so the working directory does not reach it.
    addpath(mcfg.root);
    addpath(mcfg.dynaredir);
    addpath(genpath(fullfile(mcfg.dynaredir,'Auxiliary_Functions')));
    addpath(genpath(fullfile(mcfg.dynaredir,'DSGE_tools')));
    % The package's own code directories, which the chain also calls.
    RM = fullfile(mcfg.pkg,'CCDGV_Replication');
    addpath(RM);
    addpath(fullfile(RM,'Auxiliary_Functions'));
    addpath(fullfile(RM,'DSGE_tools'));
    addpath(fullfile(RM,'Load_Data'));
    addpath(fullfile(RM,'Bayesian_VECM'),'-end');

    here = pwd;
    cd(mcfg.dynaredir);          % Dynare writes its build products beside the .mod
    % Restore the working directory and the path on exit.
    path0   = path;
    cleanup = onCleanup(@() local_restore(here, path0));

    switch lower(char(which))
        case 'all'
            local_cm1(mcfg); local_cm3(mcfg); local_im(mcfg); local_lrr(mcfg);
        case 'cm1';  local_cm1(mcfg);
        case 'cm3';  local_cm3(mcfg);
        case 'im';   local_im(mcfg);
        case 'lrr';  local_lrr(mcfg);
        otherwise
            error('model_resolve:badWhich', ...
                  'which must be all, cm1, cm3, im or lrr -- got "%s"', char(which));
    end
    fprintf('\n  IRFs written to %s\n', mcfg.saved);
end

% =========================================================================
function local_run(cmds, label)
% Run the commands in the base workspace.
    fprintf('\n--- %s ---\n', label);
    for k = 1:numel(cmds)
        evalin('base', cmds{k});
    end
end

function local_restore(here, path0)
    cd(here);
    path(path0);
    rehash;
end

function v = local_get(name)
% Read a variable back from the base workspace.
    assert(evalin('base', sprintf('exist(''%s'',''var'')', name)) == 1, ...
        'model_resolve:noResult', ...
        ['%s is not in the base workspace after the solve. The chain did not ' ...
         'reach the step that produces it -- read the Dynare output above.'], name);
    v = evalin('base', name);
end

function local_cm1(mcfg)
% Complete markets, CRRA. First order, so IRFsFirstOrder gives the responses.
    local_run({'clearvars', ...   % base starts clean for each solve
               'InformationStructureParameters; BaselineParameters;', ...
               'ies_ = 1/gam_;', ...   % CRRA: IES is the reciprocal of risk aversion
               'dynare CompleteMarketsModel.mod -DORDER=1 noclearall', ...
               'IRFsFirstOrder;'}, 'complete markets, CRRA (first order)');
    model1tfp   = local_get('irtfp_model');
    model1noise = local_get('irnoise_model');
    save(fullfile(mcfg.saved,'model1irfs_.mat'), 'model1tfp','model1noise');
    fprintf('  wrote model1irfs_.mat\n');
end

function local_cm3(mcfg)
% Complete markets, Epstein-Zin. Third order: the responses come out of
% IRFsThirdOrder's dataplots, in the column order the figures use.
    local_run({'clearvars', ...   % base starts clean for each solve
               'InformationStructureParameters; BaselineParameters;', ...
               'ies_ = 1.2;', ...
               'dynare CompleteMarketsModel.mod -DORDER=3 noclearall', ...
               'IRFsThirdOrder;'}, 'complete markets, Epstein-Zin (third order)');
    COLS = [1 8 19 11 4 3]';
    dt = local_get('dataplots_tfp');  dn = local_get('dataplots_noise');
    model2tfp   = dt(:,COLS,1);
    model2noise = dn(:,COLS,1);
    save(fullfile(mcfg.saved,'model2irfs_.mat'), 'model2tfp','model2noise');
    fprintf('  wrote model2irfs_.mat\n');
end

function local_im(mcfg)
% Incomplete markets, CRRA.
    local_run({'clearvars', ...   % base starts clean for each solve
               'InformationStructureParameters; BaselineParameters;', ...
               'dynare IncompleteMarketsModel.mod noclearall', ...
               'IRFsFirstOrder;'}, 'incomplete markets, CRRA (first order)');
    model3tfp   = local_get('irtfp_model');
    model3noise = local_get('irnoise_model');
    save(fullfile(mcfg.saved,'model3irfs.mat'), 'model3tfp','model3noise');
    fprintf('  wrote model3irfs.mat\n');
end

function local_lrr(mcfg)
% Long-run risk, third order -- Figure D.1. Saves the plotting arrays whole,
% because plotIRF_model draws the full five-page array.
    local_run({'clearvars', ...   % base starts clean for each solve
               'InformationStructureParameters; BaselineParameters;', ...
               'rho_ = 0.995;', ...    % persistence of the long-run shock
               'tau_ = 0.000175;', ... % co-integration parameter
               'ies_ = 1.2;', ...
               'dynare CompleteMarketsModel_LRR.mod -DORDER=3 noclearall', ...
               'IRFsThirdOrder;'}, 'long-run risk (third order)');
    dataplots_tfp   = local_get('dataplots_tfp');
    dataplots_noise = local_get('dataplots_noise');
    lab             = local_get('lab');
    order           = [1 8 19 4 11 3]';   % panel order of Figure D.1
    save(fullfile(mcfg.saved,'lrr_irfs.mat'), ...
         'dataplots_tfp','dataplots_noise','lab','order');
    fprintf('  wrote lrr_irfs.mat\n');
end
