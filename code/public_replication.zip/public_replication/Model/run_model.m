function run_model()
%RUN_MODEL  Build the model exhibits: Figures 8, 9 and D.1.
%
%   run_model
%
%   Figure 8    technology disturbances: data against the three models
%   Figure 9    noise disturbances: the same
%   Figure D.1  the long-run-risk variant, solved at third order
%
%   Reads the stored model impulse responses in saved_model/ and takes the
%   empirical panels from the baseline run, so the sweep must have been run.
%   Dynare is not needed; MODEL_RESOLVE re-solves the models.
%
%   See also MODEL_DATA, MODEL_CONFIG, MODEL_RESOLVE, EXHIBITS.

    mcfg = model_config();
    % Add the package's code directories, as RUN_PATHSETUP does but without
    % resetting the path. Model/Dynare stays off the path because it shadows the
    % estimation code.
    RM = fullfile(mcfg.pkg, 'CCDGV_Replication');
    addpath(mcfg.root);
    addpath(RM);
    addpath(genpath(fullfile(RM, 'Auxiliary_Functions')));
    addpath(fullfile(RM, 'DSGE_tools'));
    addpath(fullfile(RM, 'Load_Data'));
    addpath(fullfile(RM, 'Bayesian_VECM'), '-end');
    addpath(mcfg.pkg);

    % Stop if an estimation function resolves outside CCDGV_Replication.
    local_assert_not_shadowed(mcfg);

    if ~isfolder(mcfg.figdir); mkdir(mcfg.figdir); end
    close all

    % Empirical panels, from the baseline run.
    cfg = config();
    D   = model_data(cfg, struct('key', mcfg.data_key, 'hgrid', mcfg.hgrid));
    fprintf('\n  empirical panels from %s\n', D.run);
    for k = 1:numel(D.names)
        fprintf('    %-38s column %d\n', D.names{k}, D.cols(k));
    end

    % Stored model impulse responses.
    M = local_load_models(mcfg);

    fprintf('\n--- model exhibits ---\n');
    genfig_model(D, M, mcfg, 'tfp');     % Figure 8
    genfig_model(D, M, mcfg, 'noise');   % Figure 9
    genfig_model_lrr(mcfg);              % Figure D.1

    fprintf('\nModel exhibits written to %s\n', mcfg.figdir);
end

% =========================================================================
function local_assert_not_shadowed(mcfg)
% Check that the estimation functions resolve inside CCDGV_Replication and not
% to the older copies under Model/Dynare.
    NEED = {'maxshr','genvars','plotIRF','gen_auxvars','ccdgv_manifest','var_order'};
    want = fullfile(mcfg.pkg, 'CCDGV_Replication');
    bad  = {};
    for k = 1:numel(NEED)
        w = which(NEED{k});
        if isempty(w) || ~startsWith(w, want)
            bad{end+1} = sprintf('%s -> %s', NEED{k}, ...
                local_or(w, '(not found)')); %#ok<AGROW>
        end
    end
    assert(isempty(bad), 'run_model:shadowed', ...
        ['the model block has shadowed the estimation code:\n  %s\n' ...
         'Model/Dynare holds older copies of these. Start a fresh MATLAB ' ...
         'session and run run_model without having added Model/Dynare to the ' ...
         'path.'], strjoin(bad, sprintf('\n  ')));
end

function M = local_load_models(mcfg)
% The three models' stored IRFs, trimmed to the grid they are drawn on.
    n = size(mcfg.models, 1);
    M = struct('label',{},'tfp',{},'noise',{});
    for k = 1:n
        [lab, file, vt, vn, trim] = deal(mcfg.models{k,:});
        f = fullfile(mcfg.saved, file);
        assert(isfile(f), 'run_model:noModelIRFs', ...
            ['%s not found. The model exhibits read the stored IRFs in %s; ' ...
             'MODEL_RESOLVE regenerates them from the .mod files with Dynare ' ...
             '6.1.'], file, mcfg.saved);
        R = load(f);
        for q = {vt, vn}
            assert(isfield(R, q{1}), 'run_model:badModelIRFs', ...
                '%s has no variable %s', file, q{1});
        end
        M(k).label = lab;
        M(k).tfp   = R.(vt)(trim:end, :);
        M(k).noise = R.(vn)(trim:end, :);
    end
end

function s = local_or(a, b)
    if isempty(a); s = b; else; s = a; end
end
