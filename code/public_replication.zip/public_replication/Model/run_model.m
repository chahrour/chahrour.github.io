function run_model()
%RUN_MODEL  Build the model exhibits: Figures 8, 9 and C.1.
%
%   run_model
%
%   Needs no Dynare and no Symbolic Math Toolbox. The three models' impulse
%   responses are stored in saved_model/ and the empirical panels come from this
%   package's own baseline estimate, so this runs in seconds once the sweep has
%   been run. To re-solve the models from their .mod files instead, see
%   MODEL_RESOLVE -- that is the only path that needs Dynare 6.1.
%
%   WHAT THE FIGURES ARE
%     Figure 8    technology disturbances: data against the three models
%     Figure 9    noise disturbances: the same
%     Figure C.1  the long-run-risk variant, third order
%
%   Tables 4, C.1 and C.2 are not produced here. They are calibration and
%   parameter tables, written by hand into the draft.
%
%   THE PATH IS THE WHOLE RISK IN THIS BLOCK. The model code carries its own
%   older copies of functions this package also has -- maxshr, gen_auxvars,
%   plotIRF, genvars among them -- and MATLAB's path is global, so a stale copy
%   shadowing ours would change the EMPIRICAL results while looking like nothing
%   happened. Those copies live under Dynare/ and are added only by
%   MODEL_RESOLVE, never here; the assert below checks that the functions which
%   matter still resolve inside CCDGV_Replication before anything is drawn.
%
%   See also MODEL_DATA, MODEL_CONFIG, MODEL_RESOLVE, EXHIBITS.

    mcfg = model_config();
    % THE SAME CODE DIRECTORIES THE OTHER ENTRY POINTS ADD, in the same order as
    % RUN_PATHSETUP, minus its restoredefaultpath -- a caller may already have a
    % path set up and this must not tear it down. The list used to stop after
    % Auxiliary_Functions, so DSGE_tools and Load_Data were missing and anything
    % reaching companion_form or a loader resolved differently here than under
    % run_all. Model/Dynare is deliberately absent: MODEL_RESOLVE is the only
    % thing that adds it, because it shadows the estimation code.
    RM = fullfile(mcfg.pkg, 'CCDGV_Replication');
    addpath(mcfg.root);
    addpath(RM);
    addpath(genpath(fullfile(RM, 'Auxiliary_Functions')));
    addpath(fullfile(RM, 'DSGE_tools'));
    addpath(fullfile(RM, 'Load_Data'));
    addpath(fullfile(RM, 'Bayesian_VECM'), '-end');
    addpath(mcfg.pkg);

    local_assert_not_shadowed(mcfg);

    if ~isfolder(mcfg.figdir); mkdir(mcfg.figdir); end
    close all

    cfg = config();
    D   = model_data(cfg, struct('key', mcfg.data_key, 'hgrid', mcfg.hgrid));
    fprintf('\n  empirical panels from %s\n', D.run);
    for k = 1:numel(D.names)
        fprintf('    %-38s column %d\n', D.names{k}, D.cols(k));
    end

    M = local_load_models(mcfg);

    fprintf('\n--- model exhibits ---\n');
    genfig_model(D, M, mcfg, 'tfp');     % Figure 8
    genfig_model(D, M, mcfg, 'noise');   % Figure 9
    genfig_model_lrr(mcfg);              % Figure C.1

    fprintf('\nModel exhibits written to %s\n', mcfg.figdir);
end

% =========================================================================
function local_assert_not_shadowed(mcfg)
% The empirical functions must still come from CCDGV_Replication. If one of
% them resolves under Model/, the model block has shadowed the estimation code
% and any empirical exhibit built afterwards in the same session is suspect.
    NEED = {'maxshr','genvars','plotIRF','gen_auxvars','ccdgv_manifest','var_order'};
    want = fullfile(mcfg.pkg, 'CCDGV_Replication');
    bad  = {};
    for k = 1:numel(NEED)
        w = which(NEED{k});
        if isempty(w) || ~startsWith(w, want)
            bad{end+1} = sprintf('%s -> %s', NEED{k}, ...
                local_or(w, '(not found)')); %#ok<AGROW>
        end
    end
    assert(isempty(bad), 'run_model:shadowed', ...
        ['the model block has shadowed the estimation code:\n  %s\n' ...
         'Model/Dynare holds older copies of these. Start a fresh MATLAB ' ...
         'session and run run_model without having added Model/Dynare to the ' ...
         'path.'], strjoin(bad, sprintf('\n  ')));
end

function M = local_load_models(mcfg)
% The three models' stored IRFs, trimmed to the grid they are drawn on.
    n = size(mcfg.models, 1);
    M = struct('label',{},'tfp',{},'noise',{});
    for k = 1:n
        [lab, file, vt, vn, trim] = deal(mcfg.models{k,:});
        f = fullfile(mcfg.saved, file);
        assert(isfile(f), 'run_model:noModelIRFs', ...
            ['%s not found. The model exhibits read the stored IRFs in %s; ' ...
             'MODEL_RESOLVE regenerates them from the .mod files with Dynare ' ...
             '6.1.'], file, mcfg.saved);
        R = load(f);
        for q = {vt, vn}
            assert(isfield(R, q{1}), 'run_model:badModelIRFs', ...
                '%s has no variable %s', file, q{1});
        end
        M(k).label = lab;
        M(k).tfp   = R.(vt)(trim:end, :);
        M(k).noise = R.(vn)(trim:end, :);
    end
end

function s = local_or(a, b)
    if isempty(a); s = b; else; s = a; end
end
