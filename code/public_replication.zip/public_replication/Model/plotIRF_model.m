%plotIRF.m
function plotIRF_model(data,order,vars,Title,select_vars,CJ,NOISE,SLIDE, confidence_bands)

if NOISE ==1 
LINE = '-r';
else
LINE = '-b';
end
%if slide ==1 
%end
[nimp,~,~]=size(data);
[~,nvars]=size(vars);

if CJ == 1
XX2 = 0:20;
XX2reverse = 20:-1:0;
XX = -20:20;
XXreverse = 20:-1:-20;
else
XX = 1:nimp;
XXreverse = nimp:-1:1;
    
end
N = size(order,1);
nfig = size(order,2);

R=round(N/2);
for ff = 1:nfig
    if NOISE ==1
    h=figure('Color',[0.9412 0.9412 0.9412],'Position',[1+425/2*3 1 425/2 400*1.5],'Name',Title);
    else
    h=figure('Color',[0.9412 0.9412 0.9412],'Position',[1+425/2 1 425/2 400*1.5],'Name',Title);
    end
    figure(h);
    for n= 1:N
      gg(n) =  subplot(6,1,n);
        hold on;
        if sum(n == select_vars)==1
            if ndims(data)==3   %if available, plot confidence bands
                if SLIDE == 1
                    if confidence_bands == 2                %- 90% bounds  
                 grpyat = [(XX2)' data(21:end,nvars+order(n,ff),4); (XX2reverse)' data(nimp:-1:21,nvars+order(n,ff),5)];
                 patch(grpyat(:,1),grpyat(:,2),[0.9 0.9 0.9],'edgecolor',[0.9 0.9 0.9]); %[0.85 0.85 0.85]
                    end
                    %- 68% bounds
                grpyat = [(XX2)' data(21:end,nvars+order(n,ff),2); (XX2reverse)' data(nimp:-1:21,nvars+order(n,ff),3)];
                patch(grpyat(:,1),grpyat(:,2),[0.7 0.7 0.7],'edgecolor',[0.7 0.7 0.7]); %[0.65 0.65 0.65]
                else
                if confidence_bands == 2                %- 90% bounds  
                 grpyat = [(XX)' data(1:end,nvars+order(n,ff),4); (XXreverse)' data(nimp:-1:1,nvars+order(n,ff),5)];
                 patch(grpyat(:,1),grpyat(:,2),[0.9 0.9 0.9],'edgecolor',[0.9 0.9 0.9]); %[0.85 0.85 0.85]
                end
                %- 68% bounds
                grpyat = [(XX)' data(1:end,nvars+order(n,ff),2); (XXreverse)' data(nimp:-1:1,nvars+order(n,ff),3)];
                patch(grpyat(:,1),grpyat(:,2),[0.7 0.7 0.7],'edgecolor',[0.7 0.7 0.7]); %[0.65 0.65 0.65]
            
                end
                end
            plot(XX,data(:,nvars+order(n,ff),1),LINE,'LineWidth',2); 
        end
        
        ax = gca;  % current axes
        ax.XAxis.Exponent = 0;
        ax.YAxis.Exponent = 0;

        plot(XX,zeros(nimp,1),'--k','linewidth',0.5);
        title(vars{order(n,ff)},'FontSize',11,'Interpreter','latex') %'FontWeight','bold',
        ylabel('percent','FontSize',10,'Interpreter','latex')
        set(gca,'TickLabelInterpreter','latex')
        ax = gca;
        %ax.FontSize = 7; 
        %xlabel('quarters','FontSize',12,'Interpreter','latex')
        axis tight
        %                                   axis([0 nimp ylow(n) yhigh(n) ]);
        hold off; grid on; box off
        
    end
    if size(order,2) == 3
        pos = get(gg,'Position');
        new = mean(cellfun(@(v)v(1),pos(1:2)));
        set(gg(3),'Position',[new,pos{end}(2:end)])
    end
    %print([pwd, '/Figures/',Title],'-depsc','-r0')
end
