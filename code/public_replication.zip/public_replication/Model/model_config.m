function mcfg = model_config()
%MODEL_CONFIG  Every setting the model exhibits use, in one struct.
%
%   mcfg = MODEL_CONFIG()
%
%   The empirical half of these figures comes from this package's own estimate, so
%   the paths below are derived from this file's location and the package's
%   config() -- nothing is typed twice and nothing points outside the package.

    HERE = fileparts(mfilename('fullpath'));
    PKG  = fileparts(HERE);

    mcfg = struct();
    mcfg.root       = HERE;
    mcfg.pkg        = PKG;
    mcfg.saved      = fullfile(HERE, 'saved_model');
    mcfg.dynaredir  = fullfile(HERE, 'Dynare');

    % Where the exhibits land: the same Figures directory the empirical block
    % writes to, so paper_exhibits.tex picks them up with no special case.
    mcfg.figdir     = fullfile(PKG, 'Figures_Tables', 'Figures');

    % ---- the empirical panels ----------------------------------------------
    % Which estimate the left-hand panels come from. The paper's model figures
    % compare the models against the BASELINE empirical estimate.
    mcfg.data_key   = 'base';
    mcfg.hgrid      = -20:20;      % horizons drawn, empirical and model alike

    % ---- the model panels --------------------------------------------------
    % The three solved models, in the order they are drawn, and the file each
    % one's IRFs are stored in.
    % The trailing \qquad on the first label is deliberate: the two complete-markets
    % entries share one horizontal legend row and their text abuts without it. The
    % labels are set with the latex interpreter, so the spacing travels in the
    % string rather than in a hand-tuned legend Position.
    %
    % The last column is the first row to keep. Models 1 and 3 store a longer
    % path than they draw and are trimmed at 81; model 2's third-order IRFs are
    % already on the plotted grid and take no trim. That asymmetry is in the
    % original -- model1tfp(81:end,:) and model3tfp(81:end,:) against a bare
    % model2tfp -- and it is a property of how each solution order stores its
    % output, not a choice.
    mcfg.models = { ...
        'Complete Markets; CRRA\qquad',   'model1irfs_.mat', 'model1tfp', 'model1noise',  81
        'Complete Markets; Epstein-Zin',   'model2irfs_.mat', 'model2tfp', 'model2noise',   1
        'Incomplete Markets',              'model3irfs.mat',  'model3tfp', 'model3noise',  81 };

    % MODEL ROWS AGAINST DATA ROWS. The model's variables are declared in
    % IRFsFirstOrder.m as
    %   {TFP, a20, ConsumptionDifferential, RealInterestRateDifferential,
    %    RealExchangeRate, RealExchangeRateUIP, RealExchangeRateLambda}
    % and the panels pair the 4th and 5th against the data in the opposite order,
    % which is what this permutation does. MODEL_DATA returns its six rows already
    % in panel order, so this applies to the model side only.
    mcfg.model_order = [1 2 3 5 4 6];
    mcfg.h_model     = 20;         % the model IRFs' zero-horizon row offset

    % FIXED Y-LIMITS ON THE FIRST TWO ROWS, from the published figures. Rows 3-6
    % scale to their own data with 15% padding; rows 1 and 2 are pinned so the
    % technology and noise panels can be read against each other. These numbers
    % are the published ones and are not derived from anything.
    mcfg.ylim_tfp   = {[0 1.113], [0 0.9682]};
    mcfg.ylim_noise = {[-1 1],    [0 0.6996]};
    mcfg.pad        = 0.15;

    % ROWS 1 AND 2 SHOW ONE LINE, DRAWN THREE TIMES. TFP and expected TFP respond
    % identically across the three models by construction, so the published
    % figures plot model 1's path in all three styles rather than overlaying
    % three coincident curves. Row 1 of the NOISE panel is flat at zero for the
    % same reason: a noise shock moves no model's TFP.
    mcfg.rows_shared = [1 2];

    % ---- drawing -----------------------------------------------------------
    % CANVASES FROM THE PUBLISHED FIGURES, read off their EPS bounding boxes:
    % BLL_tfp.eps is 19 16 379 642 and CC_tfp.eps is 2 53 197 561. Matching them
    % keeps the model exhibits the same proportions as the draft's.
    mcfg.canvas_bll = [360 626];
    mcfg.canvas_lrr = [195 508];

    % FONT SIZES. The published figures were drawn in R2022a (its EPS says so);
    % R2025b sets LaTeX text with different metrics, so the old 11/10 reads large
    % against a panel that is only ~100pt tall on a 6x2 grid. These are tuned to
    % the rendered result rather than copied from the original.
    mcfg.fs_title  = 9;
    mcfg.fs_label  = 8;
    mcfg.fs_tick   = 8;
    mcfg.fs_legend = 9;
    % Cap on y-axis ticks per panel. With `axis tight` on a near-flat response --
    % the interest differential under noise is the case -- MATLAB fills a narrow
    % range with ticks until the labels run together.
    mcfg.max_yticks = 5;
    % The legends sit in subplot's own bottom margin, placed relative to the
    % lowest panel rather than at fixed figure coordinates: the original's were
    % absolute and assumed its own canvas. The panels are NOT moved, because
    % lifting them to make room leaves that margin empty below the legends.
    mcfg.legend_h   = 0.026;   % height of one legend row
    mcfg.legend_pad = 0.004;   % clearance under the bottom row's tick labels
    mcfg.tick_band  = 0.022;   % how far those tick labels reach below the axes

    mcfg.colors = {'#0072BD', '#D95319', '#7E2F8E'};
    mcfg.styles = {'-', '--', ':'};
    mcfg.width  = 2;

    % ---- the optional re-solve --------------------------------------------
    % Only MODEL_RESOLVE reads this, and only if asked. Dynare 6.1 produced the
    % published figures. Set this to a Dynare matlab/ directory to re-solve the
    % .mod files; left empty, the exhibits build from the saved IRFs and Dynare is
    % not needed at all.
    % FROM cfg.dynare_path, so there is one place to set it and no machine's
    % local path is baked in here. Read only by MODEL_RESOLVE, and only when
    % asked. Dynare 6.1 produced the published figures.
    mcfg.dynare_path = '';
    try
        c = config();
        if isfield(c,'dynare_path'); mcfg.dynare_path = c.dynare_path; end
    catch
        % config() is not on the path when model_config is called on its own;
        % model_resolve's second argument then supplies the path.
    end
end
