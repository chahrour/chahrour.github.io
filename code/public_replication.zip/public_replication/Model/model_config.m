function mcfg = model_config()
%MODEL_CONFIG  Settings for the model exhibits, in one struct.
%
%   mcfg = MODEL_CONFIG()
%
%   Paths are derived from this file's location.

    HERE = fileparts(mfilename('fullpath'));
    PKG  = fileparts(HERE);

    mcfg = struct();
    mcfg.root       = HERE;
    mcfg.pkg        = PKG;
    mcfg.saved      = fullfile(HERE, 'saved_model');
    mcfg.dynaredir  = fullfile(HERE, 'Dynare');

    % Output directory: the Figures folder the empirical exhibits also use.
    mcfg.figdir     = fullfile(PKG, 'Figures_Tables', 'Figures');

    % Empirical panels: the key in sweep_infos of the run that supplies them.
    mcfg.data_key   = 'base';
    mcfg.hgrid      = -20:20;      % horizons drawn, data and model

    % The three solved models, in drawing order. Columns: legend label, file in
    % saved_model/, the technology and noise variable names, and the first row
    % to keep. Models 1 and 3 store a longer path than is drawn and are trimmed
    % at row 81; model 2 is already on the plotted grid. The \qquad on the first
    % label separates the two entries that share a legend row.
    mcfg.models = { ...
        'Complete Markets; CRRA\qquad',   'model1irfs_.mat', 'model1tfp', 'model1noise',  81
        'Complete Markets; Epstein-Zin',   'model2irfs_.mat', 'model2tfp', 'model2noise',   1
        'Incomplete Markets',              'model3irfs.mat',  'model3tfp', 'model3noise',  81 };

    % The model column drawn in each panel row. Columns 4 and 5 are swapped
    % relative to the row order of MODEL_DATA.
    mcfg.model_order = [1 2 3 5 4 6];
    mcfg.h_model     = 20;         % zero-horizon row offset of the model IRFs

    % Y-limits of rows 1 and 2 (TFP, expected TFP), set to the values in the
    % published figures. Rows 3-6 scale to their data with padding mcfg.pad.
    mcfg.ylim_tfp   = {[0 1.113], [0 0.9682]};
    mcfg.ylim_noise = {[-1 1],    [0 0.6996]};
    mcfg.pad        = 0.15;

    % Rows in which the three models coincide: model 1's path is drawn in all
    % three styles. In the noise figure, row 1 is drawn as zero.
    mcfg.rows_shared = [1 2];

    % Canvas sizes in points, matching the published figures.
    mcfg.canvas_bll = [360 626];
    mcfg.canvas_lrr = [195 508];

    % Font sizes.
    mcfg.fs_title  = 9;
    mcfg.fs_label  = 8;
    mcfg.fs_tick   = 8;
    mcfg.fs_legend = 9;
    % Maximum number of y-axis ticks per panel.
    mcfg.max_yticks = 5;
    % Legend placement, in figure units, relative to the lowest panel.
    mcfg.legend_h   = 0.026;   % height of one legend row
    mcfg.legend_pad = 0.004;   % clearance under the bottom row's tick labels
    mcfg.tick_band  = 0.022;   % how far those tick labels reach below the axes

    mcfg.colors = {'#0072BD', '#D95319', '#7E2F8E'};
    mcfg.styles = {'-', '--', ':'};
    mcfg.width  = 2;

    % Dynare's matlab/ directory, from config(). Only MODEL_RESOLVE reads it; the
    % exhibits build from the saved IRFs and do not need it.
    mcfg.dynare_path = '';
    try
        c = config();
        if isfield(c,'dynare_path'); mcfg.dynare_path = c.dynare_path; end
    catch
        % config() may not be on the path; MODEL_RESOLVE's second argument then
        % supplies the directory.
    end
end
