function fout = genfig_model_lrr(mcfg)
%GENFIG_MODEL_LRR  Figure D.1: the long-run-risk model, solved at third order.
%
%   fout = GENFIG_MODEL_LRR(mcfg)
%
%   mcfg   settings, from MODEL_CONFIG
%   fout   path of the technology panel's PDF, or '' if the figure is skipped
%
%   Draws the model's responses to technology (FigureD1a) and to noise
%   (FigureD1b) from saved_model/lrr_irfs.mat, which MODEL_RESOLVE writes. There
%   is no empirical panel. The saved arrays repeat the point estimate on every
%   page, so the bands coincide with the line. If the file is absent the figure
%   is skipped with a message.
%
%   See also MODEL_RESOLVE, PLOTIRF_MODEL, RUN_MODEL.

    fout = '';
    f = fullfile(mcfg.saved, 'lrr_irfs.mat');
    if ~isfile(f)
        fprintf(2, ['  Figure D.1 skipped: %s not found.\n' ...
                    '    It holds the long-run-risk model''s responses, which come from\n' ...
                    '    solving CompleteMarketsModel_LRR.mod. Run model_resolve(''lrr'')\n' ...
                    '    once, with Dynare 6.1 on the path, and this figure builds from\n' ...
                    '    the saved arrays thereafter.\n'], f);
        return
    end
    R = load(f);
    for q = {'dataplots_tfp','dataplots_noise','lab','order'}
        assert(isfield(R, q{1}), 'genfig_model_lrr:badSaved', ...
            '%s has no %s -- regenerate it with model_resolve(''lrr'').', f, q{1});
    end

    % Arguments 6-9: CJ = 1, NOISE (the line colour), SLIDE = 0, confidence_bands = 1.
    close all
    plotIRF_model(R.dataplots_tfp,   R.order, R.lab, 'FigureD1a', 1:6, 1, 0, 0, 1);
    fout = local_print(mcfg, 'FigureD1a');

    plotIRF_model(R.dataplots_noise, R.order, R.lab, 'FigureD1b', 1:6, 1, 1, 0, 1);
    local_print(mcfg, 'FigureD1b');
    fprintf('  wrote FigureD1a.pdf / FigureD1b.pdf\n');
end

function out = local_print(mcfg, stem)
% Restyle the current figure and print it at the canvas size mcfg.canvas_lrr.
    W = mcfg.canvas_lrr(1); H = mcfg.canvas_lrr(2);
    set(gcf, 'Position',[1 1 W/0.75 H/0.75], 'Color','white');
    for ax = findobj(gcf,'Type','axes')'
        set(ax, 'TickLabelInterpreter','latex', 'FontSize',mcfg.fs_tick, ...
                'Color','white', 'XColor','black', 'YColor','black', ...
                'GridColor','black', 'XGrid','on', 'YGrid','on');
        tt = get(ax,'Title'); if ~isempty(tt); set(tt,'FontSize',mcfg.fs_title); end
        yl = get(ax,'YLabel'); if ~isempty(yl); set(yl,'FontSize',mcfg.fs_label); end
    end
    set(gcf, 'PaperUnits','points', 'PaperPosition',[0 0 W H], 'PaperSize',[W H]);
    out = fullfile(mcfg.figdir, [stem '.pdf']);
    print(gcf, out, '-dpdf', '-r0');
end
