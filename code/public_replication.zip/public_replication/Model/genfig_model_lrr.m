function fout = genfig_model_lrr(mcfg)
%GENFIG_MODEL_LRR  Figure C.1 -- the long-run-risk model, solved at third order.
%
%   fout = GENFIG_MODEL_LRR(mcfg)
%
%   MODEL ONLY, unlike Figures 8 and 9. There is no empirical panel here: the
%   figure shows the long-run-risk variant's own responses to technology and to
%   noise. plotIRF_model draws confidence bands, so the original handed it a
%   five-page array with the point estimate repeated on every page, which makes
%   the bands collapse onto the line. That is reproduced here rather than
%   reworked, so the figure matches the published one.
%
%   READS SAVED ARRAYS, so no Dynare is needed. MODEL_RESOLVE produces
%   saved_model/lrr_irfs.mat by solving CompleteMarketsModel_LRR.mod once; this
%   function only draws. If that file is absent it says so and skips, rather than
%   failing the whole exhibit build for one figure.
%
%   See also MODEL_RESOLVE, PLOTIRF_MODEL, RUN_MODEL.

    fout = '';
    f = fullfile(mcfg.saved, 'lrr_irfs.mat');
    if ~isfile(f)
        fprintf(2, ['  Figure C.1 skipped: %s not found.\n' ...
                    '    It holds the long-run-risk model''s responses, which come from\n' ...
                    '    solving CompleteMarketsModel_LRR.mod. Run model_resolve(''lrr'')\n' ...
                    '    once, with Dynare 6.1 on the path, and this figure builds from\n' ...
                    '    the saved arrays thereafter.\n'], f);
        return
    end
    R = load(f);
    for q = {'dataplots_tfp','dataplots_noise','lab','order'}
        assert(isfield(R, q{1}), 'genfig_model_lrr:badSaved', ...
            '%s has no %s -- regenerate it with model_resolve(''lrr'').', f, q{1});
    end

    % CJ = 1, SLIDE = 0, confidence_bands = 1, as the published figure is drawn.
    % The 7th argument is the NOISE flag, which only switches the line colour.
    close all
    plotIRF_model(R.dataplots_tfp,   R.order, R.lab, 'Figure3b', 1:6, 1, 0, 0, 1);
    fout = local_print(mcfg, 'CC_tfp');

    plotIRF_model(R.dataplots_noise, R.order, R.lab, 'Figure3b', 1:6, 1, 1, 0, 1);
    local_print(mcfg, 'CC_noise');
    fprintf('  wrote CC_tfp.pdf / CC_noise.pdf (Figure C.1)\n');
end

function out = local_print(mcfg, stem)
% Canvas and export as in GENFIG_MODEL: the draft's own size, written with print
% so it survives rather than being tight-cropped by exportgraphics.
    W = mcfg.canvas_lrr(1); H = mcfg.canvas_lrr(2);
    set(gcf, 'Position',[1 1 W/0.75 H/0.75], 'Color','white');
    for ax = findobj(gcf,'Type','axes')'
        set(ax, 'TickLabelInterpreter','latex', 'FontSize',mcfg.fs_tick, ...
                'Color','white', 'XColor','black', 'YColor','black', ...
                'GridColor','black', 'XGrid','on', 'YGrid','on');
        tt = get(ax,'Title'); if ~isempty(tt); set(tt,'FontSize',mcfg.fs_title); end
        yl = get(ax,'YLabel'); if ~isempty(yl); set(yl,'FontSize',mcfg.fs_label); end
    end
    set(gcf, 'PaperUnits','points', 'PaperPosition',[0 0 W H], 'PaperSize',[W H]);
    out = fullfile(mcfg.figdir, [stem '.pdf']);
    print(gcf, out, '-dpdf', '-r0');
end
