function fout = genfig_model(D, M, mcfg, which)
%GENFIG_MODEL  Figure 8 or Figure 9: data against the three models.
%
%   fout = GENFIG_MODEL(D, M, mcfg, which)
%
%   D       empirical panels, from MODEL_DATA
%   M       the three models' impulse responses, from RUN_MODEL
%   mcfg    settings, from MODEL_CONFIG
%   which   'tfp' for Figure 8, 'noise' for Figure 9
%   fout    path of the PDF written
%
%   Six rows, two columns. The left column is the empirical estimate: the
%   posterior median with a 16-84 band. The right column is the same variable in
%   the three models. In rows 1 and 2 (TFP, expected TFP) the models coincide,
%   so model 1's path is drawn in all three styles and the y-limits are the
%   fixed ones in MODEL_CONFIG.
%
%   See also MODEL_DATA, RUN_MODEL, PLOT_DATA, MODEL_CONFIG.

    isnoise = strcmpi(which, 'noise');
    if isnoise
        emp = D.irnoise;  ylims = mcfg.ylim_noise;
        stem = 'Figure9';  fignum = 'Figure 9';
    else
        emp = D.irtfp;    ylims = mcfg.ylim_tfp;
        stem = 'Figure8';    fignum = 'Figure 8';
    end

    hgrid = D.hgrid;
    nrow  = numel(D.names);
    % Position is in pixels and print writes points at 3/4 of that, so the figure
    % is sized to export at the canvas size.
    W = mcfg.canvas_bll(1); H = mcfg.canvas_bll(2);
    figure('Color','white', 'Position',[1 1 W/0.75 H/0.75], 'Name',[fignum ' ' which]);

    for ii = 1:nrow
        % Left: the data.
        subplot(nrow, 2, 2*ii-1);
        vtp = squeeze(emp(:, ii, :));
        plot_data(vtp, hgrid, double(isnoise)); hold on
        plot(hgrid, zeros(size(hgrid)), '--k', 'LineWidth', 0.5);
        local_axes(hgrid, mcfg.fs_tick);
        if isnoise && ii == 1
            ylim(ylims{1});
        else
            axis tight
        end
        local_thin_yticks(gca, mcfg.max_yticks);
        hold off; grid on; box off
        title(D.names{ii}, 'FontSize',mcfg.fs_title, 'Interpreter','latex');
        ylabel('percent', 'FontSize',mcfg.fs_label, 'Interpreter','latex');

        % Right: the models.
        subplot(nrow, 2, 2*ii);
        plot(hgrid, zeros(size(hgrid)), '--k', 'LineWidth', 0.5); hold on
        col = mcfg.model_order(ii);
        rows = hgrid + mcfg.h_model + 1;
        hs = gobjects(1, numel(M));
        shared = ismember(ii, mcfg.rows_shared);
        for m = 1:numel(M)
            if isnoise; src = M(m).noise; else; src = M(m).tfp; end
            if shared
                % one path, three styles
                if isnoise; ref = M(1).noise; else; ref = M(1).tfp; end
                y = ref(rows, col);
                if isnoise && ii == 1; y = zeros(size(y)); end
            else
                y = src(rows, col);
            end
            hs(m) = plot(hgrid, y, 'Color',mcfg.colors{m}, ...
                         'LineStyle',mcfg.styles{m}, 'LineWidth',mcfg.width);
        end
        if shared
            ylim(ylims{ii});
        else
            local_pad(hs, mcfg.pad);
        end
        local_axes(hgrid, mcfg.fs_tick);
        local_thin_yticks(gca, mcfg.max_yticks);
        hold off; grid on; box off
        title(D.names{ii}, 'FontSize',mcfg.fs_title, 'Interpreter','latex');
    end

    % The legends go in the margin below the bottom panels.
    local_legend(hs, mcfg);

    % Print the whole canvas rather than cropping to content.
    set(gcf, 'PaperUnits','points', 'PaperPosition',[0 0 W H], 'PaperSize',[W H]);
    fout = fullfile(mcfg.figdir, [stem '.pdf']);
    print(gcf, fout, '-dpdf', '-r0');
    fprintf('  wrote %s.pdf (%s)\n', stem, fignum);
end

% =========================================================================
function local_axes(hgrid, fs)
% Axes styling, set per axes so that it does not carry over to other figures.
    ax = gca;
    ax.XAxis.Exponent = 0;
    ax.YAxis.Exponent = 0;
    ax.XTick = [-20 -10 0 10 20];
    set(ax, 'TickLabelInterpreter','latex', 'FontSize',fs, ...
            'Color','white', 'XColor','black', 'YColor','black', ...
            'GridColor','black', 'XGrid','on', 'YGrid','on');
    xlim([min(hgrid) max(hgrid)]);
end

function local_thin_yticks(ax, maxn)
% Keep at most maxn y ticks, evenly spaced across the current limits.
    yl = ylim(ax);
    if ~all(isfinite(yl)) || yl(2) <= yl(1); return; end
    if numel(get(ax,'YTick')) <= maxn; return; end
    set(ax, 'YTick', linspace(yl(1), yl(2), maxn));
end

function local_pad(hs, pad)
% Set the y-limits from all the lines in the panel, padded by the fraction pad.
    y = [];
    for k = 1:numel(hs)
        if isgraphics(hs(k)); y = [y; hs(k).YData(:)]; end %#ok<AGROW>
    end
    y = y(isfinite(y));
    if isempty(y) || range(y) == 0; return; end
    p = pad * range(y);
    ylim([min(y)-p, max(y)+p]);
end

function local_legend(hs, mcfg)
% Two legends stacked under the lowest panel: the complete-markets pair on one
% row and incomplete markets below it. The second needs its own invisible axes,
% because one axes carries one legend.
    A = findobj(gcf, 'Type','axes');
    pos = get(A, 'Position');
    if ~iscell(pos); pos = {pos}; end
    ybot = min(cellfun(@(q) q(2), pos));

    h  = mcfg.legend_h;
    y1 = ybot - mcfg.tick_band - mcfg.legend_pad - h;   % first row, under the ticks
    y2 = y1 - h;                                        % second, directly below

    labs = mcfg.models(:,1);
    legend(hs(1:2), labs(1:2), ...
        'Orientation','horizontal', 'Position',[0.05 y1 0.90 h], ...
        'Box','off', 'Interpreter','latex', 'FontSize',mcfg.fs_legend, 'TextColor','black');
    ax2 = axes('Position', get(gca,'Position'), 'Visible','off');
    legend(ax2, hs(3), labs(3), ...
        'Orientation','horizontal', 'Position',[0.30 y2 0.40 h], ...
        'Box','off', 'Interpreter','latex', 'FontSize',mcfg.fs_legend, 'TextColor','black');
end
