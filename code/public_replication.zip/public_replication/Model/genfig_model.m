function fout = genfig_model(D, M, mcfg, which)
%GENFIG_MODEL  Figure 8a or Figure 8b: data against the three models.
%
%   fout = GENFIG_MODEL(D, M, mcfg, which)
%
%   D       empirical panels, from MODEL_DATA
%   M       the three models' impulse responses, from RUN_MODEL
%   mcfg    settings, from MODEL_CONFIG
%   which   'tfp' for Figure 8a, 'noise' for Figure 8b
%   fout    path of the PDF written
%
%   Three rows of four panels, two variables to a row. Each variable gets a pair
%   of panels: on the left the empirical estimate, the posterior median with a
%   16-84 band; on the right the same variable in the three models. For the
%   first two variables (TFP, expected TFP) the models coincide, so model 1's
%   path is drawn in all three styles and the y-limits are the fixed ones in
%   MODEL_CONFIG.
%
%   Rows named in RATE_ROWS (the interest rate differential and expected excess
%   returns) are drawn annualized, data and models alike: multiplied by 4 and
%   labelled as rates.
%
%   See also MODEL_DATA, RUN_MODEL, PLOT_DATA, MODEL_CONFIG.

    isnoise = strcmpi(which, 'noise');
    if isnoise
        emp = D.irnoise;  ylims = mcfg.ylim_noise;
        stem = 'Figure8b';  fignum = 'Figure 8b';
    else
        emp = D.irtfp;    ylims = mcfg.ylim_tfp;
        stem = 'Figure8a';  fignum = 'Figure 8a';
    end

    hgrid = D.hgrid;
    nvar  = numel(D.names);
    [rates, ratelab] = rate_rows(D.names);
    sc    = 1 + 3*rates;                 % 4 for a rate row, 1 otherwise
    nrow  = nvar/2;
    % The PDF is printed at the canvas size, but the panel spacing follows the
    % on-screen size, so the window is opened at mcfg.screen_bll.
    W = mcfg.canvas_bll(1); H = mcfg.canvas_bll(2);
    figure('Color','white', 'Position',[1 1 mcfg.screen_bll], 'Name',[fignum ' ' which]);

    for ii = 1:nvar
        % Left of the pair: the data.
        subplot(nrow, 4, 2*ii-1);
        vtp = sc(ii) * squeeze(emp(:, ii, :));
        plot_data(vtp, hgrid, double(isnoise)); hold on
        plot(hgrid, zeros(size(hgrid)), '--k', 'LineWidth', 0.5);
        local_axes(hgrid, mcfg.fs_tick);
        if isnoise && ii == 1
            ylim(ylims{1});
        else
            axis tight
        end
        local_thin_yticks(gca, mcfg.max_yticks);
        hold off; grid on; box off
        title(D.names{ii}, 'FontSize',mcfg.fs_title, 'Interpreter','latex');
        if mod(ii, 2) == 1      % first panel of the row
            if rates(ii); t = ratelab; else; t = 'percent'; end
            ylabel(t, 'FontSize',mcfg.fs_label, 'Interpreter','latex');
        end

        % Right of the pair: the models.
        subplot(nrow, 4, 2*ii);
        plot(hgrid, zeros(size(hgrid)), '--k', 'LineWidth', 0.5); hold on
        col = mcfg.model_order(ii);
        rows = hgrid + mcfg.h_model + 1;
        hs = gobjects(1, numel(M));
        shared = ismember(ii, mcfg.rows_shared);
        for m = 1:numel(M)
            if isnoise; src = M(m).noise; else; src = M(m).tfp; end
            if shared
                % one path, three styles
                if isnoise; ref = M(1).noise; else; ref = M(1).tfp; end
                y = ref(rows, col);
                if isnoise && ii == 1; y = zeros(size(y)); end
            else
                y = src(rows, col);
            end
            y = sc(ii) * y;
            hs(m) = plot(hgrid, y, 'Color',mcfg.colors{m}, ...
                         'LineStyle',mcfg.styles{m}, 'LineWidth',mcfg.width);
        end
        if shared
            ylim(ylims{ii});
        else
            local_pad(hs, mcfg.pad);
        end
        local_axes(hgrid, mcfg.fs_tick);
        local_thin_yticks(gca, mcfg.max_yticks);
        hold off; grid on; box off
        title(D.names{ii}, 'FontSize',mcfg.fs_title, 'Interpreter','latex');
    end

    % The legend goes in the margin below the bottom panels.
    local_legend(hs, mcfg);

    % Print the whole canvas rather than cropping to content.
    set(gcf, 'PaperUnits','points', 'PaperPosition',[0 0 W H], 'PaperSize',[W H]);
    fout = fullfile(mcfg.figdir, [stem '.pdf']);
    print(gcf, fout, '-dpdf', '-r0');
    fprintf('  wrote %s.pdf (%s)\n', stem, fignum);
end

% =========================================================================
function local_axes(hgrid, fs)
% Axes styling, set per axes so that it does not carry over to other figures.
    ax = gca;
    ax.XAxis.Exponent = 0;
    ax.YAxis.Exponent = 0;
    ax.XTick = [-20 -10 0 10 20];
    set(ax, 'TickLabelInterpreter','latex', 'FontSize',fs, ...
            'Color','white', 'XColor','black', 'YColor','black', ...
            'GridColor','black', 'XGrid','on', 'YGrid','on');
    xlim([min(hgrid) max(hgrid)]);
end

function local_thin_yticks(ax, maxn)
% Keep at most maxn y ticks. The step is the smallest of 1, 2, 2.5 or 5 times a
% power of ten that gives no more than maxn ticks, placed at multiples of the
% step so that zero is a tick whenever it is in range.
    yl = ylim(ax);
    if ~all(isfinite(yl)) || yl(2) <= yl(1); return; end
    if numel(get(ax,'YTick')) <= maxn; return; end
    mag = 10^floor(log10((yl(2) - yl(1)) / (maxn - 1)));
    for m = [1 2 2.5 5 10]
        step = m * mag;
        t = (ceil(yl(1)/step):floor(yl(2)/step)) * step;
        if numel(t) <= maxn; break; end
    end
    set(ax, 'YTick', t);
end

function local_pad(hs, pad)
% Set the y-limits from all the lines in the panel, padded by the fraction pad.
    y = [];
    for k = 1:numel(hs)
        if isgraphics(hs(k)); y = [y; hs(k).YData(:)]; end %#ok<AGROW>
    end
    y = y(isfinite(y));
    if isempty(y) || range(y) == 0; return; end
    p = pad * range(y);
    ylim([min(y)-p, max(y)+p]);
end

function local_legend(hs, mcfg)
% One legend, the three models on one row, under the lowest panels' tick labels.
    A = findobj(gcf, 'Type','axes');
    pos = get(A, 'Position');
    if ~iscell(pos); pos = {pos}; end
    ybot = min(cellfun(@(q) q(2), pos));

    h = mcfg.legend_h;
    y = ybot - mcfg.tick_band - mcfg.legend_pad - h;
    legend(hs, mcfg.models(:,1), ...
        'Orientation','horizontal', 'Position',[0.05 y 0.90 h], ...
        'Box','off', 'Interpreter','latex', 'FontSize',mcfg.fs_legend, 'TextColor','black');
end
