function fout = genfig_model(D, M, mcfg, which)
%GENFIG_MODEL  Figure 8 or Figure 9 -- data against the three models.
%
%   fout = GENFIG_MODEL(D, M, mcfg, which)
%
%   D       from MODEL_DATA: the empirical panels, cumulated and windowed
%   M       from RUN_MODEL: the three models' IRFs, trimmed
%   which   'tfp' -> Figure 8, 'noise' -> Figure 9
%
%   SIX ROWS, TWO COLUMNS. The left column is this package's empirical estimate --
%   posterior median with a 16/84 band across draws -- and the right column is the
%   same variable in the three models. Each row is one variable, paired as
%   MODEL_DATA's docstring sets out.
%
%   ROWS 1 AND 2 CARRY ONE LINE DRAWN THREE TIMES. TFP and expected TFP respond
%   identically across the three models by construction, so drawing model 1 in all
%   three styles is what the published figures do; three coincident curves would
%   render as one anyway. In the noise figure row 1 is flat at zero, because a
%   noise shock moves no model's TFP.
%
%   Y-LIMITS on those two rows are pinned to the published values from
%   MODEL_CONFIG. The rest scale to their own data.
%
%   See also MODEL_DATA, RUN_MODEL, PLOT_DATA, MODEL_CONFIG.

    isnoise = strcmpi(which, 'noise');
    if isnoise
        emp = D.irnoise;  ylims = mcfg.ylim_noise;
        stem = 'BLL_noise';  fignum = 'Figure 9';
    else
        emp = D.irtfp;    ylims = mcfg.ylim_tfp;
        stem = 'BLL_tfp';    fignum = 'Figure 8';
    end

    hgrid = D.hgrid;
    nrow  = numel(D.names);
    % Points to pixels: the figure is sized so the export lands on the draft's
    % canvas exactly. MATLAB's Position is pixels and print writes points at 3/4.
    W = mcfg.canvas_bll(1); H = mcfg.canvas_bll(2);
    figure('Color','white', 'Position',[1 1 W/0.75 H/0.75], 'Name',[fignum ' ' which]);

    for ii = 1:nrow
        % ---- left: the data -------------------------------------------------
        subplot(nrow, 2, 2*ii-1);
        vtp = squeeze(emp(:, ii, :));
        plot_data(vtp, hgrid, double(isnoise)); hold on
        plot(hgrid, zeros(size(hgrid)), '--k', 'LineWidth', 0.5);
        local_axes(hgrid, mcfg.fs_tick);
        if isnoise && ii == 1
            ylim(ylims{1});
        else
            axis tight
        end
        local_thin_yticks(gca, mcfg.max_yticks);
        hold off; grid on; box off
        title(D.names{ii}, 'FontSize',mcfg.fs_title, 'Interpreter','latex');
        ylabel('percent', 'FontSize',mcfg.fs_label, 'Interpreter','latex');

        % ---- right: the models ----------------------------------------------
        subplot(nrow, 2, 2*ii);
        plot(hgrid, zeros(size(hgrid)), '--k', 'LineWidth', 0.5); hold on
        col = mcfg.model_order(ii);
        rows = hgrid + mcfg.h_model + 1;
        hs = gobjects(1, numel(M));
        shared = ismember(ii, mcfg.rows_shared);
        for m = 1:numel(M)
            if isnoise; src = M(m).noise; else; src = M(m).tfp; end
            if shared
                % one path, three styles -- see the header
                if isnoise; ref = M(1).noise; else; ref = M(1).tfp; end
                y = ref(rows, col);
                if isnoise && ii == 1; y = zeros(size(y)); end
            else
                y = src(rows, col);
            end
            hs(m) = plot(hgrid, y, 'Color',mcfg.colors{m}, ...
                         'LineStyle',mcfg.styles{m}, 'LineWidth',mcfg.width);
        end
        if shared
            ylim(ylims{ii});
        else
            local_pad(hs, mcfg.pad);
        end
        local_axes(hgrid, mcfg.fs_tick);
        local_thin_yticks(gca, mcfg.max_yticks);
        hold off; grid on; box off
        title(D.names{ii}, 'FontSize',mcfg.fs_title, 'Interpreter','latex');
    end

    % NO LIFT. subplot already leaves a bottom margin of roughly a tenth of the
    % figure, which is more than the two legend rows need, so the legends go
    % there. Raising the stack to make room is what left a band of dead white
    % space below them -- the original margin, now unused.
    local_legend(hs, mcfg);

    % PRINT WITH AN EXPLICIT PAPERSIZE, as GENFIG_B11 and GENFIG_B9B10 do and
    % for their reason: exportgraphics tight-crops to the content box, which
    % would discard the declared canvas and leave these figures a different size
    % from the rest.
    set(gcf, 'PaperUnits','points', 'PaperPosition',[0 0 W H], 'PaperSize',[W H]);
    fout = fullfile(mcfg.figdir, [stem '.pdf']);
    print(gcf, fout, '-dpdf', '-r0');
    fprintf('  wrote %s.pdf (%s)\n', stem, fignum);
end

% =========================================================================
function local_axes(hgrid, fs)
% The draft's model figures were drawn under a set(groot, ...) block: white axes,
% black axis lines and text, grid on in black, latex tick labels. Those are
% applied here per-axes instead, because set(groot) leaks into every figure the
% session draws afterwards -- including the empirical ones.
    ax = gca;
    ax.XAxis.Exponent = 0;
    ax.YAxis.Exponent = 0;
    ax.XTick = [-20 -10 0 10 20];
    set(ax, 'TickLabelInterpreter','latex', 'FontSize',fs, ...
            'Color','white', 'XColor','black', 'YColor','black', ...
            'GridColor','black', 'XGrid','on', 'YGrid','on');
    xlim([min(hgrid) max(hgrid)]);
end

function local_thin_yticks(ax, maxn)
% Keep at most maxn y ticks, chosen evenly across the final limits. Called after
% the limits are set, because MATLAB picks ticks from whatever range is current.
    yl = ylim(ax);
    if ~all(isfinite(yl)) || yl(2) <= yl(1); return; end
    if numel(get(ax,'YTick')) <= maxn; return; end
    set(ax, 'YTick', linspace(yl(1), yl(2), maxn));
end

function local_pad(hs, pad)
% Scale to the three lines together, so the models stay comparable within a row.
    y = [];
    for k = 1:numel(hs)
        if isgraphics(hs(k)); y = [y; hs(k).YData(:)]; end %#ok<AGROW>
    end
    y = y(isfinite(y));
    if isempty(y) || range(y) == 0; return; end
    p = pad * range(y);
    ylim([min(y)-p, max(y)+p]);
end

function local_legend(hs, mcfg)
% Two legends: the complete-markets pair on one row, incomplete markets below it.
% The second needs its own invisible axes, because one axes carries one legend.
%
% PLACED FROM THE PANELS. The lowest panel's bottom edge is measured first, and
% the rows are stacked just under it, clear of the tick labels. The originals sat
% at fixed figure coordinates, which left them stranded at the foot of the figure
% once the canvas or the panel count changed.
    A = findobj(gcf, 'Type','axes');
    pos = get(A, 'Position');
    if ~iscell(pos); pos = {pos}; end
    ybot = min(cellfun(@(q) q(2), pos));

    h  = mcfg.legend_h;
    y1 = ybot - mcfg.tick_band - mcfg.legend_pad - h;   % first row, under the ticks
    y2 = y1 - h;                                        % second, directly below

    labs = mcfg.models(:,1);
    legend(hs(1:2), labs(1:2), ...
        'Orientation','horizontal', 'Position',[0.05 y1 0.90 h], ...
        'Box','off', 'Interpreter','latex', 'FontSize',mcfg.fs_legend, 'TextColor','black');
    ax2 = axes('Position', get(gca,'Position'), 'Visible','off');
    legend(ax2, hs(3), labs(3), ...
        'Orientation','horizontal', 'Position',[0.30 y2 0.40 h], ...
        'Box','off', 'Interpreter','latex', 'FontSize',mcfg.fs_legend, 'TextColor','black');
end
