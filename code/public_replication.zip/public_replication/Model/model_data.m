function D = model_data(cfg, opt)
%MODEL_DATA  The empirical panels of Figure 8, from the baseline run.
%
%   D = MODEL_DATA(cfg)
%   D = MODEL_DATA(cfg, opt)
%
%   cfg        settings struct from config(); cfg.resultdir holds the runs
%   opt.key    key of the run in sweep_infos (default 'base')
%   opt.hgrid  horizons to return (default -20:20)
%
%   D.irtfp, D.irnoise   nhorizon x 6 x ndraws, cumulated responses on hgrid
%   D.names              1x6 panel titles, in plotting order
%   D.cols               column of each row in the run's vnames
%   D.hgrid              the horizon grid
%   D.run                name of the run file
%
%   The six rows, and the model variable each is paired with:
%     Home TFP                     TFP
%     E[TFP]                       a20, the j-quarter-ahead expectation
%     Consumption Differential     ConsumptionDifferential
%     Real Exchange Rate           RealExchangeRate
%     Interest Rate Differential   RealInterestRateDifferential. This row is the
%                                  real rate (manifest key realrate), not the
%                                  nominal differential IDIFF.
%     Expected Excess Returns      ExpectedExcessCurrencyReturns. This row is the
%                                  constructed currency return (manifest key
%                                  expexret).
%
%   See also VAR_ORDER, RUN_MODEL, GENPLOTS_PAPER.

    if nargin < 2; opt = struct(); end
    key     = getdef(opt, 'key',     'base');
    hgrid   = getdef(opt, 'hgrid',   -20:20);

    % The six rows by name, in panel order.
    NAMES = {'Home TFP', ...
             'E[TFP]', ...
             'Consumption Differential', ...
             'Real Exchange Rate', ...
             'Interest Rate Differential', ...
             'Expected Excess Returns'};
    % Panel titles.
    TITLES = {'Home TFP', ...
              'Expected Home TFP', ...
              'Consumption Differential', ...
              'Real Exchange Rate', ...
              'Interest Rate Differential', ...
              'Expected Excess Returns'};

    % Locate the run file.
    S = load_sweep_infos(cfg);
    assert(isfield(S, key), 'model_data:noKey', ...
        ['sweep_infos.mat has no "%s" run -- run sweep(cfg) first. The model ' ...
         'figures take their empirical panels from the baseline estimate.'], key);
    info = S.(key);
    [nm, f] = data_name(info);
    assert(isfile(f), 'model_data:noRun', '%s not found -- run sweep(cfg) first.', f);

    % Load the responses and resolve the six columns by name.
    R = load(f, 'irtfp', 'irnoise', 'vnames');
    for q = {'irtfp','irnoise','vnames'}
        assert(isfield(R, q{1}), 'model_data:truncated', ...
            ['%s is missing %s. A run file written by an interrupted sweep is ' ...
             'incomplete -- re-estimate that specification.'], nm, q{1});
    end

    cols = var_order(R.vnames, NAMES{:});

    % Cumulate, then take the window. The stored responses run from -h to +h, so
    % row h+1 is impact.
    h = (size(R.irtfp,1) - 1) / 2;
    assert(h == floor(h), 'model_data:evenHorizon', ...
        'irtfp has %d rows, which is not 2h+1 -- the horizon grid is not centred.', ...
        size(R.irtfp,1));
    assert(min(hgrid) + h + 1 >= 1 && max(hgrid) + h + 1 <= size(R.irtfp,1), ...
        'model_data:window', ...
        'hgrid %d..%d does not fit inside a -%d..%d response.', ...
        min(hgrid), max(hgrid), h, h);

    rows = hgrid + h + 1;
    D = struct();
    D.irtfp   = cumsum(R.irtfp,   1);
    D.irnoise = cumsum(R.irnoise, 1);
    D.irtfp   = D.irtfp(rows,   cols, :);
    D.irnoise = D.irnoise(rows, cols, :);
    D.names   = TITLES;
    D.cols    = cols(:)';
    D.hgrid   = hgrid;
    D.run     = nm;
end

function v = getdef(s, f, d)
    if isstruct(s) && isfield(s, f) && ~isempty(s.(f)); v = s.(f); else; v = d; end
end
