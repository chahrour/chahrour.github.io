function D = model_data(cfg, opt)
%MODEL_DATA  The empirical panels of Figures 8, 9 and C.1, from this package's run.
%
%   D = MODEL_DATA(cfg)
%   D = MODEL_DATA(cfg, opt)   opt.key ('base'), opt.hgrid
%
%   D.irtfp / D.irnoise   nhorizon x 6 x ndraws, cumulated and windowed
%   D.names               1x6 display names, in the figures' plotting order
%   D.hgrid               the horizon grid the panels are drawn on
%   D.cols                the resolved column of each name, for the record
%
%   RESOLVED BY NAME, NOT BY POSITION. The original read a frozen snapshot and
%   indexed it with literal column numbers:
%
%       ocons = 2; oinv = 3; oner = 4; ... orer = 15; oconsdiff = 20;
%       load baseline_Avg_APR2024.mat
%
%   Those positions belong to the April-2024 manifest. This package's manifest has
%   39 rows and no nx_gdp, so they have moved -- the real exchange rate sits at
%   column 29 in the old snapshot and 28 here. Every column below therefore comes
%   from VAR_ORDER, which errors and names what is missing rather than returning a
%   fallback index: a wrong column here would plot one series under another's
%   title and look like a result.
%
%   THE SIX ROWS, and why each is the one the figure wants. The pairing with the
%   model's own variables is in IRFsFirstOrder.m's plot_var, reordered by
%   order = [1,2,3,5,4,6]:
%
%     Home TFP                     <- TFP
%     E[TFP]                       <- a20, the j-quarter-ahead expectation
%     Consumption Differential     <- ConsumptionDifferential
%     Real Exchange Rate           <- RealExchangeRate
%     Interest Rate Differential   <- RealInterestRateDifferential
%     Expected Excess Returns      <- ExpectedExcessCurrencyReturns
%
%   'Interest Rate Differential' IS THE REAL RATE. Its manifest key is `realrate`;
%   the nominal differential is a separate row keyed `idiff` and displayed as
%   'IDIFF'. The display names collide in the obvious way, so take the row by the
%   name below and not by what it sounds like.
%
%   'Expected Excess Returns' IS THE CURRENCY RETURN, manifest key `expexret`, and
%   it is CONSTRUCTED from the VAR's own variables rather than projected onto them.
%   The model's counterpart is ExpectedExcessCurrencyReturns. Three other rows
%   invite the wrong pick: `exret_eq_lead` and `exret_bond_lead` are PROJECTED
%   equity and bond returns, and `exret` is the REALISED currency return.
%
%   CUMULATED HERE, and that is the package's own convention rather than an
%   assumption carried over from the model code. irtfp and irnoise are stored
%   per-period, and all fourteen places that plot them accumulate first --
%   GENPLOTS_PAPER does it in the identical idiom:
%
%       h = (size(irtfp,1)-1)/2;  irtfp = cumsum(irtfp);  irtfp = irtfp(hgrid+h+1,:,:);
%
%   (GENFIG_TB accumulates twice on purpose for its alternative panel, which is
%   the one deliberate exception and is commented as such there.)
%
%   The original cut the window in two steps -- take -50:20, then drop the first
%   30 rows -- which lands on -20:20. Accumulation happens over the whole stored
%   response either way, so this takes -20:20 directly and carries no `discard`.
%
%   See also VAR_ORDER, RUN_MODEL, GENPLOTS_PAPER.

    if nargin < 2; opt = struct(); end
    key     = getdef(opt, 'key',     'base');
    hgrid   = getdef(opt, 'hgrid',   -20:20);

    % The six rows, in the order the panels are drawn. One list, one place.
    NAMES = {'Home TFP', ...
             'E[TFP]', ...
             'Consumption Differential', ...
             'Real Exchange Rate', ...
             'Interest Rate Differential', ...
             'Expected Excess Returns'};
    % What each panel is titled. The original renamed position 9 by hand
    % (lab{9} = 'Expected Home TFP'); here the manifest name is mapped instead.
    TITLES = {'Home TFP', ...
              'Expected Home TFP', ...
              'Consumption Differential', ...
              'Real Exchange Rate', ...
              'Interest Rate Differential', ...
              'Expected Excess Returns'};

    L = load(fullfile(cfg.resultdir, 'sweep_infos.mat'), 'sweep_infos');
    assert(isfield(L.sweep_infos, key), 'model_data:noKey', ...
        ['sweep_infos.mat has no "%s" run -- run sweep(cfg) first. The model ' ...
         'figures take their empirical panels from the baseline estimate.'], key);
    info = L.sweep_infos.(key);
    [~, nm] = data_name(info);
    [~, stem, ext] = fileparts(nm);
    f = fullfile(cfg.resultdir, [stem ext]);
    assert(isfile(f), 'model_data:noRun', '%s not found -- run sweep(cfg) first.', f);

    R = load(f, 'irtfp', 'irnoise', 'vnames');
    for q = {'irtfp','irnoise','vnames'}
        assert(isfield(R, q{1}), 'model_data:truncated', ...
            ['%s is missing %s. A run file written by an interrupted sweep is ' ...
             'incomplete -- re-estimate that specification.'], [stem ext], q{1});
    end

    cols = var_order(R.vnames, NAMES{:});

    % Accumulate, then take the window. h is the zero-horizon row: the stored
    % responses run from -h to +h, so row h+1 is impact.
    h = (size(R.irtfp,1) - 1) / 2;
    assert(h == floor(h), 'model_data:evenHorizon', ...
        'irtfp has %d rows, which is not 2h+1 -- the horizon grid is not centred.', ...
        size(R.irtfp,1));
    assert(min(hgrid) + h + 1 >= 1 && max(hgrid) + h + 1 <= size(R.irtfp,1), ...
        'model_data:window', ...
        'hgrid %d..%d does not fit inside a -%d..%d response.', ...
        min(hgrid), max(hgrid), h, h);

    rows = hgrid + h + 1;
    D = struct();
    D.irtfp   = cumsum(R.irtfp,   1);
    D.irnoise = cumsum(R.irnoise, 1);
    D.irtfp   = D.irtfp(rows,   cols, :);
    D.irnoise = D.irnoise(rows, cols, :);
    D.names   = TITLES;
    D.cols    = cols(:)';
    D.hgrid   = hgrid;
    D.run     = [stem ext];
end

function v = getdef(s, f, d)
    if isstruct(s) && isfield(s, f) && ~isempty(s.(f)); v = s.(f); else; v = d; end
end
