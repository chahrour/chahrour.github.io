function [A, B, term_rer, term_deltaq, term_expexret, ia1, exp_tfp_j, rowkeys] = ...
         model_cj_auxvars(b, Aproj, keys, nvars, nlags, j_cj)
%MODEL_CJ_AUXVARS  Adapter letting the package's CJ sweep run on the model system.
%
%   Same signature as GEN_AUXVARS, so GEN_CJ_IRFS_TFSWEEP can call it through its
%   cj_auxfun hook, but the rows come from MODEL_GEN_AUXVARS -- the model's own
%   builder, which appends 18 constructed rows to its 7 simulated variables.
%
%   Aproj and keys are accepted and ignored: nothing in the model system is
%   projected onto a companion state, and the row names come out of the builder's
%   fixed layout rather than a manifest.
%
%   ROWKEYS. The CJ sweep looks up exactly two rows by name, 'tfp' and
%   'exp_tfp_j'. MODEL_GEN_AUXVARS stacks
%
%       A = [eye(nvars) zeros(...); exp_tfp_j; term_expner; term_expexret; ...]
%
%   so the VAR's own variables are rows 1..nvars and the expectation row is
%   nvars+1. TFP is the first simulated column. The remaining rows are named
%   positionally because nothing reads them by name.
%
%   See also GEN_CJ_IRFS_TFSWEEP, MODEL_GEN_AUXVARS, GEN_AUXVARS.

    [A, B, term_rer, term_deltaq, term_expexret, ia1, exp_tfp_j] = ...
        model_gen_auxvars(b, nvars, nlags, j_cj, 0);

    rowkeys = arrayfun(@(k) sprintf('aux%d', k), 1:size(A,1), 'UniformOutput', false);
    rowkeys{1}        = 'tfp';           % TFP is the first simulated series
    rowkeys{nvars+1}  = 'exp_tfp_j';     % the row stacked straight after eye(nvars)
end
