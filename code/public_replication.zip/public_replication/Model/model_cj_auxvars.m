function [A, B, term_rer, term_deltaq, term_expexret, ia1, exp_tfp_j, rowkeys] = ...
         model_cj_auxvars(b, Aproj, keys, nvars, nlags, j_cj)
%MODEL_CJ_AUXVARS  GEN_AUXVARS for the model system, for GEN_CJ_IRFS_TFSWEEP.
%
%   Same signature as GEN_AUXVARS, so GEN_CJ_IRFS_TFSWEEP can call it through
%   its cj_auxfun hook. The rows come from MODEL_GEN_AUXVARS, in Model/Dynare.
%   Aproj and keys are ignored.
%
%   rowkeys names row 1 'tfp' and row nvars+1 'exp_tfp_j', the two rows the
%   sweep looks up by name. The other rows are named aux<k>.
%
%   See also GEN_CJ_IRFS_TFSWEEP, MODEL_GEN_AUXVARS, GEN_AUXVARS.

    [A, B, term_rer, term_deltaq, term_expexret, ia1, exp_tfp_j] = ...
        model_gen_auxvars(b, nvars, nlags, j_cj, 0);

    rowkeys = arrayfun(@(k) sprintf('aux%d', k), 1:size(A,1), 'UniformOutput', false);
    rowkeys{1}        = 'tfp';           % TFP is the first simulated series
    rowkeys{nvars+1}  = 'exp_tfp_j';     % the first row after eye(nvars)
end
