% RUN_ALL  Reproduce every exhibit in the paper, from raw inputs.
%
%   Open MATLAB in a fresh session, cd to this folder, and type run_all.
%   Settings are in config.m. See README.md.
%
%   A fresh session matters because MATLAB's path is global. This script resets
%   the path and stops if the package's functions resolve outside this folder.

%% Path: reset it, then add only this package's folders
HERE = fileparts(mfilename('fullpath'));
restoredefaultpath;
addpath(fullfile(HERE, 'CCDGV_Replication'));
addpath(fullfile(HERE, 'CCDGV_Replication', 'Auxiliary_Functions'));
addpath(fullfile(HERE, 'CCDGV_Replication', 'DSGE_tools'));
addpath(fullfile(HERE, 'CCDGV_Replication', 'Load_Data'));
addpath(fullfile(HERE, 'CCDGV_Replication', 'Bayesian_VECM'), '-end');
addpath(fullfile(HERE, 'Data_Replication'));
% No data folder goes on the path; data files are located through raw_path.

%% Stop if any of these functions resolves outside this folder
RA_NEED = {'run_main','ccdgv_manifest','genvars','ryan_data','ccdgv_project', ...
           'data_import_and_transform','build_ew_panel'};
RA_BAD = {};
for RA_K = 1:numel(RA_NEED)
    RA_W = which(RA_NEED{RA_K});
    if isempty(RA_W)
        RA_BAD{end+1} = sprintf('%s -> NOT FOUND', RA_NEED{RA_K});   %#ok<SAGROW>
    elseif ~startsWith(RA_W, HERE)
        RA_BAD{end+1} = sprintf('%s -> %s', RA_NEED{RA_K}, RA_W);    %#ok<SAGROW>
    end
end
if ~isempty(RA_BAD)
    error('run_all:wrongCopy', ...
        ['these functions do not resolve inside %s:\n  %s\n' ...
         'Start a fresh MATLAB session and run this file again.'], ...
        HERE, strjoin(RA_BAD, sprintf('\n  ')));
end
clear RA_NEED RA_BAD RA_K RA_W

%% Settings
cfg = config();
if ~isfolder(cfg.resultdir);  mkdir(cfg.resultdir);  end
if ~isfolder(cfg.exhibitdir); mkdir(cfg.exhibitdir); end

fprintf('\n=== CCDGV replication package ===\n');
fprintf('  package   %s\n', HERE);
fprintf('  results   %s\n', cfg.resultdir);
fprintf('  exhibits  %s\n', cfg.exhibitdir);
fprintf('  ndraws    %d\n\n', cfg.ndraws);

%% Stage 1: build the data panels from the raw inputs
% Skipped when the panels are already in Data_Replication/Built_Data; delete
% them to force a rebuild.
if cfg.build_data
    fprintf('[1/4] building data panels\n');
    run(fullfile(HERE, 'Data_Replication', 'build_all_vintages.m'));
else
    fprintf('[1/4] using the panels already in Data_Replication/Built_Data\n');
end

%% Stage 2: estimate every specification
% With cfg.estimate false, the exhibits are redrawn from the runs already in
% saved_results.
if cfg.estimate
    fprintf('[2/4] estimating\n');
    sweep(cfg);
else
    d = dir(fullfile(cfg.resultdir, 'results_*.mat'));
    assert(~isempty(d), 'run_all:noRuns', ...
        ['cfg.estimate is false but %s holds no results_*.mat. Set it true ' ...
         'for the first run.'], cfg.resultdir);
    fprintf('[2/4] using the %d run(s) already in %s\n', numel(d), cfg.resultdir);
end

%% Stage 3: build the empirical exhibits
% The exhibits document is compiled after stage 4, because it includes the
% model figures.
fprintf('[3/4] building exhibits\n');
exhibits(cfg, [], false);

%% Stage 4: the model exhibits (Figures 8, 9 and D.1)
% Drawn from the impulse responses stored in Model/saved_model.
fprintf('[4/4] building the model exhibits\n');
addpath(fullfile(HERE, 'Model'));
% model_resolve clears the base workspace, and this script runs in base, so no
% variable here survives it. config() is read again afterwards.
if cfg.resolve_models
    % Re-solve the models with Dynare first, then draw.
    fprintf('      re-solving the models with Dynare\n');
    model_resolve('all', cfg.dynare_path);
end
run_model;

cfg = config();          % stage 4 may have cleared the base workspace
compile_exhibits(cfg.exhibitdir);
fprintf('\nDone. Exhibits are in %s\n', cfg.exhibitdir);
