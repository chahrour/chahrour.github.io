% RUN_ALL  Reproduce every exhibit in the paper, from raw inputs.
%
%   Open MATLAB in a FRESH session, cd to this folder, and type:
%
%       run_all
%
%   Runtime is dominated by the estimation stage. See README.md.
%
%   WHY A FRESH SESSION MATTERS. This package sits inside the research repo it
%   was extracted from, so a second copy of most of these function names exists
%   one directory up. MATLAB's path is global and last-added wins, so a session
%   that has run the research code and then runs this package can silently
%   resolve genvars, ccdgv_manifest or run_main to the wrong copy. The
%   restoredefaultpath below drops everything, and local_guard then verifies that
%   the functions this package needs resolve INSIDE this folder. If they do not,
%   it stops rather than producing plausible wrong numbers.
%
%   THERE ARE NO ENVIRONMENT VARIABLES AND NO SYMBOLIC LINKS. Every path is
%   derived from this file's own location. The only setting a replicator changes
%   is in config.m.

% ---- path: one place, derived from this file's location ---------------------
HERE = fileparts(mfilename('fullpath'));
restoredefaultpath;
addpath(fullfile(HERE, 'CCDGV_Replication'));
addpath(fullfile(HERE, 'CCDGV_Replication', 'Auxiliary_Functions'));
addpath(fullfile(HERE, 'CCDGV_Replication', 'DSGE_tools'));
addpath(fullfile(HERE, 'CCDGV_Replication', 'Load_Data'));
addpath(fullfile(HERE, 'CCDGV_Replication', 'Bayesian_VECM'), '-end');
addpath(fullfile(HERE, 'Data_Replication'));
% NO DATA DIRECTORY GOES ON THE PATH. MATLAB resolves a bare name against the
% current folder and then the path, code and data alike, so a data folder there
% lets a file be found by bare name -- a dependency nothing in the code states,
% which breaks when the addpath moves. Raw_Data was on the path for exactly that
% reason: tech_proxy_series read 'USDATA.xlsx' with no folder. It is resolved
% through raw_path now, and since the merge Raw_Data holds only subdirectories
% anyway, so this entry had stopped finding anything.

% ---- refuse to run against the wrong copy of the code ----------------------
RA_NEED = {'run_main','ccdgv_manifest','genvars','ryan_data','ccdgv_project', ...
           'data_import_and_transform','build_ew_panel'};
RA_BAD = {};
for RA_K = 1:numel(RA_NEED)
    RA_W = which(RA_NEED{RA_K});
    if isempty(RA_W)
        RA_BAD{end+1} = sprintf('%s -> NOT FOUND', RA_NEED{RA_K});   %#ok<SAGROW>
    elseif ~startsWith(RA_W, HERE)
        RA_BAD{end+1} = sprintf('%s -> %s', RA_NEED{RA_K}, RA_W);    %#ok<SAGROW>
    end
end
if ~isempty(RA_BAD)
    error('run_all:wrongCopy', ...
        ['these functions do not resolve inside %s:\n  %s\n' ...
         'Start a fresh MATLAB session and run this file again.'], ...
        HERE, strjoin(RA_BAD, sprintf('\n  ')));
end
clear RA_NEED RA_BAD RA_K RA_W

% ---- settings --------------------------------------------------------------
cfg = config();
if ~isfolder(cfg.resultdir);  mkdir(cfg.resultdir);  end
if ~isfolder(cfg.exhibitdir); mkdir(cfg.exhibitdir); end

fprintf('\n=== CCDGV replication package ===\n');
fprintf('  package   %s\n', HERE);
fprintf('  results   %s\n', cfg.resultdir);
fprintf('  exhibits  %s\n', cfg.exhibitdir);
fprintf('  ndraws    %d\n\n', cfg.ndraws);

% ---- stage 1: build the data panels from raw inputs ------------------------
% Skipped when the panels are already present, because the build is
% deterministic and reproduces them exactly. It reads every web source -- OECD
% SDMX, OECD KEI, FRED -- from the CSVs cached in Raw_Data, so it needs no
% network and no credentials. Set cfg.use_cache false in config.m to re-download
% instead; that is the only path that needs a FRED key. Delete
% Data_Replication/Built_Data to force a rebuild.
if cfg.build_data
    fprintf('[1/4] building data panels\n');
    run(fullfile(HERE, 'Data_Replication', 'build_all_vintages.m'));
else
    fprintf('[1/4] using the panels already in Data_Replication/Built_Data\n');
end

% ---- stage 2: estimate every spec -----------------------------------------
% cfg.estimate false re-renders the exhibits from the runs already in
% saved_results instead, which takes minutes rather than the better part of an
% hour. It is for REDRAWING, not for checking an estimation change: the exhibits
% then reflect whatever those files hold, however they were produced. Anything
% that changes the estimates -- a manifest edit, a projection setting, a data
% rebuild -- needs this true, and sweep always re-estimates and overwrites; it
% has no skip-if-present shortcut of its own.
if cfg.estimate
    fprintf('[2/4] estimating\n');
    sweep(cfg);
else
    d = dir(fullfile(cfg.resultdir, 'results_*.mat'));
    assert(~isempty(d), 'run_all:noRuns', ...
        ['cfg.estimate is false but %s holds no results_*.mat. Set it true ' ...
         'for the first run.'], cfg.resultdir);
    fprintf('[2/4] using the %d run(s) already in %s\n', numel(d), cfg.resultdir);
end

% ---- stage 3: build every empirical exhibit -------------------------------
fprintf('[3/4] building exhibits\n');
exhibits(cfg);

% ---- stage 4: the model exhibits ------------------------------------------
% Figures 8, 9 and C.1, from the impulse responses stored in Model/saved_model.
% No Dynare and no Symbolic Math Toolbox; Model/Dynare stays off the path, so the
% estimation code above is not shadowed, and run_model asserts that before it
% draws. model_resolve re-solves the models from their .mod files if wanted.
fprintf('[4/4] building the model exhibits\n');
addpath(fullfile(HERE, 'Model'));
% MODEL_RESOLVE CLEARS THE BASE WORKSPACE. Dynare generates its driver as a
% SCRIPT and runs it with evalin('base', ...), so each solve has to happen in
% base and has to start clean. This file is a script, so EVERY variable here --
% cfg included, and any copy of a cfg field -- lives in base and is gone
% afterwards. Nothing below stage 4 may assume otherwise; config() is re-read at
% the end instead.
if cfg.resolve_models
    % Re-solve first, then draw. model_resolve borrows the path for Model/Dynare
    % and gives it back, so run_model's shadowing assert still holds below.
    fprintf('      re-solving the models with Dynare\n');
    model_resolve('all', cfg.dynare_path);
end
run_model;

cfg = config();          % re-read: stage 4 may have cleared the base workspace
fprintf('\nDone. Exhibits are in %s\n', cfg.exhibitdir);
