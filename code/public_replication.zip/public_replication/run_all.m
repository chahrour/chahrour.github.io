% RUN_ALL  Reproduce every exhibit in the paper, from raw inputs.
%
%   Open MATLAB in a fresh session, cd to this folder, and type run_all.
%   Settings are in config.m. See README.md.
%
%   A fresh session matters because MATLAB's path is global. This script resets
%   the path and changes to this folder, so that only this package's functions
%   are found.

%% Path: reset it, then add only this package's folders
cd(fileparts(which('run_all')));
restoredefaultpath;
addpath('CCDGV_Replication', 'CCDGV_Replication/Auxiliary_Functions', ...
        'CCDGV_Replication/DSGE_tools', 'CCDGV_Replication/Load_Data', ...
        'Data_Replication');
addpath('CCDGV_Replication/Bayesian_VECM', '-end');
% No data folder goes on the path; data files are located through raw_path.


%% Settings
cfg = config();
if ~isfolder(cfg.resultdir);  mkdir(cfg.resultdir);  end
if ~isfolder(cfg.exhibitdir); mkdir(cfg.exhibitdir); end

fprintf('\n=== CCDGV replication package ===\n');
fprintf('  package   %s\n', pwd);
fprintf('  results   %s\n', cfg.resultdir);
fprintf('  exhibits  %s\n', cfg.exhibitdir);
fprintf('  ndraws    %d\n\n', cfg.ndraws);

% Figures are drawn off screen unless cfg.show_figures. The last line of this
% file puts MATLAB's own setting back.
set(groot, 'DefaultFigureVisible', matlab.lang.OnOffSwitchState(cfg.show_figures));

%% Stage 1: build the data panels from the raw inputs
% Skipped when the panels are already in Data_Replication/Built_Data; delete
% them to force a rebuild.
if cfg.build_data
    fprintf('[1/4] building data panels\n');
    run('Data_Replication/build_all_vintages.m');
else
    fprintf('[1/4] using the panels already in Data_Replication/Built_Data\n');
end

%% Stage 2: estimate every specification
% With cfg.estimate false, the exhibits are redrawn from the runs already in
% saved_results.
if cfg.estimate
    fprintf('[2/4] estimating\n');
    sweep(cfg);
else
    d = dir(fullfile(cfg.resultdir, 'results_*.mat'));
    assert(~isempty(d), 'run_all:noRuns', ...
        ['cfg.estimate is false but %s holds no results_*.mat. Set it true ' ...
         'for the first run.'], cfg.resultdir);
    fprintf('[2/4] using the %d run(s) already in %s\n', numel(d), cfg.resultdir);
end

%% Stage 3: build the empirical exhibits
% The exhibits document is compiled after stage 4, because it includes the
% model figures.
fprintf('[3/4] building exhibits\n');
exhibits(cfg, [], false);

%% Stage 4: the model exhibits (Figures 8 and D.1)
% Drawn from the impulse responses stored in Model/saved_model.
fprintf('[4/4] building the model exhibits\n');
addpath('Model');
% model_resolve clears the base workspace, and this script runs in base, so no
% variable here survives it. config() is read again afterwards.
if cfg.resolve_models
    % Re-solve the models with Dynare first, then draw.
    fprintf('      re-solving the models with Dynare\n');
    model_resolve('all', cfg.dynare_path);
end
run_model;

cfg = config();          % stage 4 may have cleared the base workspace
compile_exhibits(cfg.exhibitdir);
fprintf('\nDone. Exhibits are in %s\n', cfg.exhibitdir);
set(groot, 'DefaultFigureVisible', 'remove');
