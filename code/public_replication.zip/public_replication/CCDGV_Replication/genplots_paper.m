function genplots_paper(datafile, outdir)
%GENPLOTS_PAPER  Figures 2, 3 and 4: responses of TFP, TFP expectations, and the
%   responses to technology and noise disturbances.
%
%   genplots_paper(datafile, outdir)
%
%   datafile  a run .mat written by estimate_one
%   outdir    where to write the four PDFs
%
%   Writes Figure2a_tfp.pdf, Figure2a_noise.pdf (Figure 2), Figure2b.pdf
%   (Figure 3) and Figure3b.pdf (Figure 4).
%
%   Both arguments are required, which is what lets the extended-sample appendix
%   call this a second time with a different run file and a different directory.

    assert(nargin == 2, 'genplots_paper:args', ...
        'needs a run file and an output directory.');
    assert(isfile(datafile), 'genplots_paper:noFile', '%s not found.', datafile);

% -------------------------------------------------------------------------
% Plot results
% -------------------------------------------------------------------------

% Note: to plot two sets of confidence bands, set the option
% confidence_bands = 2 when calling functions plotIRF_paper.m or
% plotIRF_both.m

%7','UK_JUN7','G6300_temp'}; %'G6300_NOV07'}; %'G6300_JUN27'};
Label_all = {'GER','ITA','FRA','CAN','JPN','UK','G6'};

engel_rlzd_limit = 2500;


% ONE PANEL SET, NOT A LOOP. This drew seven country figures once; the package
% draws the G6 one, which is Label_all{7}. Kept as an index rather than inlined
% so the label and the data stay tied to the same entry.
jj = 7;
    
    load(datafile);                                     %#ok<LOAD>

    % Resolve panel selections BY NAME -- the literal indices below are correct
    % only for the 8-variable baseline layout. The equity specs insert US/G6
    % equity at positions 9-10, shifting everything from E[TFP] onward by +2.
    ccdgv_o_ = ccdgv_order(vnames);

    cou = Label_all{jj};
    lab = vnames;
    % By name, not index 9: in the equity specs position 9 is 'US equity', so
    % the old literal relabelled the equity series as 'Expected Home TFP' --
    % which is why the wrong panels still looked internally consistent.
    lab{strcmp(vnames,'E[TFP]')} = 'Expected Home TFP';
    % SHORT LABELS COME FROM THE MANIFEST, through the run file. run_main builds
    % vnames_short from ccdgv_manifest's `short` fields and saves it, and the
    % load above brings it in. A 24-entry literal used to overwrite it here: the
    % manifest has 39 entries and 14 of the first 18 disagreed with the literal,
    % which from row 9 on was naming different variables entirely -- "Expected
    % Home TFP" where the manifest says "US equity prices". It did no damage only
    % because nothing read it; every plotIRF call below passes `lab`. That is the
    % failure the note above warns about for indices, in its worst form, so the
    % literal is gone rather than corrected.


    % Horizon for impulse responses
    h     = (size(irtfp,1)-1)/2;
    hgrid = -50:20;
    discard = 30; % how many IRFs to discard when plotting

    irtfp   = cumsum(irtfp);
    irnoise = cumsum(irnoise);

    irtfp   = irtfp(hgrid+h+1,:,:);
    irnoise = irnoise(hgrid+h+1,:,:);

    if point_estimate
        irtfp1    = irtfp(:,:,end);
        irnoise1  = irnoise(:,:,end);
        vstfp1    = vstfp(:,:,end);
        vsnoise   = vsnoise(:,:,end);
    else
        irtfp1   = median(irtfp(:,:,:),3);
        vstfp1   = median(vstfp,3);
        irnoise1 = median(irnoise(:,:,:),3);
        vsnoise1 = median(vsnoise,3);
    end

    % Confidence bands
    qstfp   = quantile(sort(irtfp,3)  ,[bound2,1-bound2],3);
    qsnoise = quantile(sort(irnoise,3),[bound2,1-bound2],3);

    qstfp(:,:,3:4)   = quantile(sort(irtfp,3)  ,[bound,1-bound],3);
    qsnoise(:,:,3:4) = quantile(sort(irnoise,3),[bound,1-bound],3);

%%% WI plots
prefs = plotIRF(nan); %Default prefs, just to see them

%% Compile TFP and Noise responses
dataplots_tfp       = NaN(size(irtfp,1)-discard,  2*size(irtfp,2),5);
dataplots_noise     = dataplots_tfp;

%TFP
dataplots_tfp(:,:,1) = [irtfp1(discard+1:end,:),irtfp1(discard+1:end,:)];
dataplots_tfp(:,:,4)=  [qstfp(discard+1:end,:,1),qstfp(discard+1:end,:,1)];
dataplots_tfp(:,:,5)=  [qstfp(discard+1:end,:,2),qstfp(discard+1:end,:,2)];
dataplots_tfp(:,:,2)=  [qstfp(discard+1:end,:,3),qstfp(discard+1:end,:,3)];
dataplots_tfp(:,:,3)=  [qstfp(discard+1:end,:,4),qstfp(discard+1:end,:,4)];

%Noise
dataplots_noise(:,:,1) = [irnoise1(discard+1:end,:),irnoise1(discard+1:end,:)];
dataplots_noise(:,:,4)=  [qsnoise(discard+1:end,:,1),qsnoise(discard+1:end,:,1)];
dataplots_noise(:,:,5)=  [qsnoise(discard+1:end,:,2),qsnoise(discard+1:end,:,2)];
dataplots_noise(:,:,2)=  [qsnoise(discard+1:end,:,3),qsnoise(discard+1:end,:,3)];
dataplots_noise(:,:,3)=  [qsnoise(discard+1:end,:,4),qsnoise(discard+1:end,:,4)];
dataplots_noise(:,[1 size(irtfp,2)+1],:) = zeros(41,2,5); % zero out TFP response to noise

%% The trade-balance figure is drawn by GENFIG_TB.

%% Figure 2a-b
prefs.nrow = 1; prefs.ncol = 2;
prefs.position = [1 1 4/3*425 4/3*425/3];

%TFP only
fout = plotIRF(dataplots_tfp,ccdgv_o_.tfp_exp', lab,'Figure2a_tfp',[1:2],prefs);
exportgraphics(fout,fullfile(outdir, 'Figure2a_tfp.pdf'));

%Noise only
prefs.NOISE = 1;
fout = plotIRF(dataplots_noise,ccdgv_o_.tfp_exp', lab,'Figure2a_noise',[1,2],prefs);   % was [1 9]
exportgraphics(fout,fullfile(outdir, 'Figure2a_noise.pdf'));

%% Figure 3: TFP shock
order_fig2b_resubmit = ccdgv_o_.fig2b_r;   % was [1 2 6 12 15 11]
order_fig2b          = ccdgv_o_.fig2b;     % was [1 12 2 15 6 11] (loaded from the .mat)

[fout,prefs] = plotIRF(dataplots_tfp,order_fig2b_resubmit', lab,'Figure2b',1:6);
exportgraphics(fout,fullfile(outdir, 'Figure2b.pdf'));

prefs.NOISE = 1;
fout = plotIRF(dataplots_noise,order_fig2b_resubmit', lab,'Figure3b', 1:6,prefs);
exportgraphics(fout,fullfile(outdir, 'Figure3b.pdf'));

% ⚠ DISABLED 2026-07-30. This is a SLIDES variant that blanks the first 20
% quarters (dataplots_noise2(1:20,:,:) = NaN) -- i.e. the entire pre-shock
% window, which for the noise figure is the anticipation story the paper is
% about. It re-used the filename 'Figure3b', which line 164 above has ALREADY
% written with the published version via plotIRF_paper_resubmit, so being later
% it silently overwrote it. That is what was landing on disk as the paper's
% Figure 4: a slides figure with x<0 erased and a different plot helper.
% (Note the commented print(gcf,'noise_resubmit',...) at line ~171: line 164 was
% always meant to be the source of noise_resubmit.eps.)
% Re-enable ONLY with a different Title, e.g. 'Figure3b_slides'.
dataplots_noise2 = dataplots_noise;
dataplots_noise2(1:20,:,:) = NaN;
% plotIRF_slides(dataplots_noise2,order_fig2b', lab,'Figure3b', 1:6, 1, 1,1)


%% Variance decomposition table
% Derived by name from the loaded vnames rather than inherited from the caller's
% workspace. It used to arrive via genplots_uhlig (both are scripts sharing one
% workspace). The old saved value was positions into a 26-row vnames and no longer
% selects the same variables.
order_vdec = var_order(vnames, ...
    'Home TFP', 'Home Consumption', 'Foreign Consumption', ...
    'Home Investment', 'Foreign Investment', ...
    'Interest Rate Differential', 'Real Exchange Rate', ...
    'Expected Excess Returns', '$\Delta q_t$');

vdec_m_tfp   = median(vstfp(order_vdec',:,:),3);
vdec_m_noise = median(vsnoise(order_vdec',:,:),3);
vdec_m_comp  =  vdec_m_tfp + vdec_m_noise;


for jj = 1:length(order_vdec)
    disp([pad(lab{order_vdec(jj)},28), ' & ', num2str(vdec_m_comp(jj,1),'% .2f'), ' & ', num2str(vdec_m_tfp(jj,1),'% .2f'),  ' & ', num2str(vdec_m_noise(jj,1),'% .2f'), ' & ', num2str(vdec_m_comp(jj,2),'% .2f'), ' & ', num2str(vdec_m_tfp(jj,2),'% .2f'),  ' & ', num2str(vdec_m_noise(jj,2),'% .2f'), ' & ', num2str(vdec_m_comp(jj,3),'% .2f'), ' & ', num2str(vdec_m_tfp(jj,3),'% .2f'),  ' & ', num2str(vdec_m_noise(jj,3),'% .2f'),' \\']);
end

