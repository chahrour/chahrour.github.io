function genplots_paper(datafile, outdir, names)
%GENPLOTS_PAPER  Figures 2, 3 and 4, or C.2, C.3 and C.4 on the extended sample.
%
%   genplots_paper(datafile, outdir, names)
%
%   datafile  a run .mat written by estimate_one
%   outdir    where to write the four PDFs
%   names     four file stems, in order: Figure 2's technology panel, its noise
%             panel, Figure 3, Figure 4. The main text passes
%             {'Figure2a','Figure2b','Figure3','Figure4'}.
%
%   Figure 2 shows TFP and expected TFP. Figures 3 and 4 show the responses to
%   technology and to noise disturbances. The variance shares of the two
%   disturbances are also printed to the console.

    assert(nargin == 3 && numel(names) == 4, 'genplots_paper:args', ...
        'needs a run file, an output directory and four file stems.');
    assert(isfile(datafile), 'genplots_paper:noFile', '%s not found.', datafile);

Label_all = {'GER','ITA','FRA','CAN','JPN','UK','G6'};

engel_rlzd_limit = 2500;


% Only the G6 panel set is drawn: entry 7 of Label_all.
jj = 7;
    
    load(datafile);                                     %#ok<LOAD>

    % Panel orders, resolved by name.
    ccdgv_o_ = ccdgv_order(vnames);

    cou = Label_all{jj};
    lab = vnames;
    % Title of the E[TFP] panel.
    lab{strcmp(vnames,'E[TFP]')} = 'Expected Home TFP';


    % Cumulate the stored responses and take horizons -50:20.
    h     = (size(irtfp,1)-1)/2;
    hgrid = -50:20;
    discard = 30; % leading horizons dropped when plotting, leaving -20:20

    irtfp   = cumsum(irtfp);
    irnoise = cumsum(irnoise);

    irtfp   = irtfp(hgrid+h+1,:,:);
    irnoise = irnoise(hgrid+h+1,:,:);

    % Point estimates: the last page, or the median across draws.
    if point_estimate
        irtfp1    = irtfp(:,:,end);
        irnoise1  = irnoise(:,:,end);
        vstfp1    = vstfp(:,:,end);
        vsnoise   = vsnoise(:,:,end);
    else
        irtfp1   = median(irtfp(:,:,:),3);
        vstfp1   = median(vstfp,3);
        irnoise1 = median(irnoise(:,:,:),3);
        vsnoise1 = median(vsnoise,3);
    end

    % Bands: pages 1:2 at bound2, pages 3:4 at bound.
    qstfp   = quantile(sort(irtfp,3)  ,[bound2,1-bound2],3);
    qsnoise = quantile(sort(irnoise,3),[bound2,1-bound2],3);

    qstfp(:,:,3:4)   = quantile(sort(irtfp,3)  ,[bound,1-bound],3);
    qsnoise(:,:,3:4) = quantile(sort(irnoise,3),[bound,1-bound],3);

prefs = plotIRF(nan); % default plot preferences

%% Pack the responses for plotIRF
% Pages: 1 = point estimate, 2/3 = inner band, 4/5 = outer band. plotIRF reads
% the second half of the columns, so each block is written twice.
dataplots_tfp       = NaN(size(irtfp,1)-discard,  2*size(irtfp,2),5);
dataplots_noise     = dataplots_tfp;

% Technology
dataplots_tfp(:,:,1) = [irtfp1(discard+1:end,:),irtfp1(discard+1:end,:)];
dataplots_tfp(:,:,4)=  [qstfp(discard+1:end,:,1),qstfp(discard+1:end,:,1)];
dataplots_tfp(:,:,5)=  [qstfp(discard+1:end,:,2),qstfp(discard+1:end,:,2)];
dataplots_tfp(:,:,2)=  [qstfp(discard+1:end,:,3),qstfp(discard+1:end,:,3)];
dataplots_tfp(:,:,3)=  [qstfp(discard+1:end,:,4),qstfp(discard+1:end,:,4)];

% Noise
dataplots_noise(:,:,1) = [irnoise1(discard+1:end,:),irnoise1(discard+1:end,:)];
dataplots_noise(:,:,4)=  [qsnoise(discard+1:end,:,1),qsnoise(discard+1:end,:,1)];
dataplots_noise(:,:,5)=  [qsnoise(discard+1:end,:,2),qsnoise(discard+1:end,:,2)];
dataplots_noise(:,:,2)=  [qsnoise(discard+1:end,:,3),qsnoise(discard+1:end,:,3)];
dataplots_noise(:,:,3)=  [qsnoise(discard+1:end,:,4),qsnoise(discard+1:end,:,4)];
dataplots_noise(:,[1 size(irtfp,2)+1],:) = zeros(41,2,5); % TFP does not respond to noise

%% Figure 2: TFP and expected TFP
% The draft prints each panel pair at half the text width, so the canvas is drawn
% at about that size, with Figure 1's font sizes, to print at the same type size.
prefs.nrow = 1; prefs.ncol = 2;
prefs.position = [1 1 4/3*270 4/3*270/3];
prefs.title_size = 10; prefs.label_size = 8; prefs.tick_size = 8;

% Technology
ftfp = plotIRF(dataplots_tfp,ccdgv_o_.tfp_exp', lab,names{1},[1:2],prefs);

% Noise
prefs.NOISE = 1;
fnoise = plotIRF(dataplots_noise,ccdgv_o_.tfp_exp', lab,names{2},[1,2],prefs);

align_ylabels(ftfp, fnoise);     % same page size for the two panels
exportgraphics(ftfp,  fullfile(outdir, [names{1} '.pdf']));
exportgraphics(fnoise,fullfile(outdir, [names{2} '.pdf']));

%% Figure 3: responses to technology
order_fig2b_resubmit = ccdgv_o_.fig2b_r;

[fout,prefs] = plotIRF(dataplots_tfp,order_fig2b_resubmit', lab,names{3},1:6);
exportgraphics(fout,fullfile(outdir, [names{3} '.pdf']));

%% Figure 4: responses to noise
prefs.NOISE = 1;
fout = plotIRF(dataplots_noise,order_fig2b_resubmit', lab,names{4}, 1:6,prefs);
exportgraphics(fout,fullfile(outdir, [names{4} '.pdf']));

%% Variance shares, printed to the console
% Rows resolved by name.
order_vdec = var_order(vnames, ...
    'Home TFP', 'Home Consumption', 'Foreign Consumption', ...
    'Home Investment', 'Foreign Investment', ...
    'Interest Rate Differential', 'Real Exchange Rate', ...
    'Expected Excess Returns', '$\Delta q_t$');

vdec_m_tfp   = median(vstfp(order_vdec',:,:),3);
vdec_m_noise = median(vsnoise(order_vdec',:,:),3);
vdec_m_comp  =  vdec_m_tfp + vdec_m_noise;


for jj = 1:length(order_vdec)
    disp([pad(lab{order_vdec(jj)},28), ' & ', num2str(vdec_m_comp(jj,1),'% .2f'), ' & ', num2str(vdec_m_tfp(jj,1),'% .2f'),  ' & ', num2str(vdec_m_noise(jj,1),'% .2f'), ' & ', num2str(vdec_m_comp(jj,2),'% .2f'), ' & ', num2str(vdec_m_tfp(jj,2),'% .2f'),  ' & ', num2str(vdec_m_noise(jj,2),'% .2f'), ' & ', num2str(vdec_m_comp(jj,3),'% .2f'), ' & ', num2str(vdec_m_tfp(jj,3),'% .2f'),  ' & ', num2str(vdec_m_noise(jj,3),'% .2f'),' \\']);
end
end
