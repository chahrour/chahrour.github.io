function [dt, dn, vnames] = cj_bands(info)
%CJ_BANDS  One run's responses to technology and to noise, packed for plotIRF.
%
%   [dt, dn, vnames] = cj_bands(info)
%
%   info    run descriptor
%   dt, dn  41 x 2*nrows x 5: the cumulated responses to technology and to
%           noise at horizons -20:20, in PACK_BANDS' layout
%   vnames  the run's row names
%
%   The result is kept in memory, keyed on the run file, its date and its size,
%   so a run that several figures draw is loaded and packed once.
%
%   See also PACK_BANDS, PLOTIRF.

    persistent CACHE
    if isempty(CACHE); CACHE = containers.Map(); end

    [~, f] = data_name(info);
    assert(isfile(f), 'cj_bands:noFile', '%s not found', f);
    d   = dir(f);
    key = sprintf('%s|%.8f|%d', f, d.datenum, d.bytes);
    if isKey(CACHE, key)
        c = CACHE(key);  dt = c.dt;  dn = c.dn;  vnames = c.vnames;
        return
    end

    % Cumulate the stored responses, take horizons -50:20 and discard the first
    % 30, leaving -20:20; pack the median and bands.
    D   = load(f, 'irtfp','irnoise','vnames','point_estimate','bound','bound2');
    h   = (size(D.irtfp,1)-1)/2;
    win = (-50:20) + h + 1;
    dt  = pack_bands(cumsum(D.irtfp),   win, 30, D);
    dn  = pack_bands(cumsum(D.irnoise), win, 30, D);
    vnames = D.vnames;
    CACHE(key) = struct('dt', dt, 'dn', dn, 'vnames', {vnames});
end
