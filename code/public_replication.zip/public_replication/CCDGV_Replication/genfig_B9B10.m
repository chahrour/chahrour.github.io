function fout = genfig_B9B10(country_infos, base_info, dest)
%GENFIG_B9B10  Figures B.9 and B.10 -- technology and noise disturbances by country.
%   fout = GENFIG_B9B10(country_infos, base_info)
%   fout = GENFIG_B9B10(country_infos, base_info, dest)
%
%   country_infos  1x6 cell of run descriptors, one per country (sweep's
%                  `country_info`). Order does NOT matter -- see below.
%   base_info      the G6 run, drawn solid with bands
%   fout           [B.9 figure, B.10 figure]
%
%   Six dashed lines (the individual countries) and one solid (the G6), in six
%   panels. B.9 is the technology response, B.10 the noise response; they differ
%   only in which IRF array is passed and the NOISE flag.
%
%   ⚠ COUNTRY ORDER IS NOT THE CALLER'S. plotIRF_paper_individual:84 hard-codes
%   its legend as GER, ITA, FRA, CAN, JPN, UK, so the 4th dimension of `data`
%   must be in exactly that order. sweep builds country_info by looping
%   Countries = {Canada, France, Germany, Italy, Japan, UK} -- a DIFFERENT order.
%   Handing the cell over as-is puts every dashed line under the wrong label, and
%   the figure looks entirely reasonable. This function maps by NAME, so the
%   caller can build its cell in whatever order it likes.
%
%   ROWS BY NAME TOO. The old appendix_individual used order_fig2b = [1 12 2 15
%   6 11] and literals ocons/oner/orer/odeltaq, all of which address the 25-row
%   layout those *_JAN2024 snapshots had. Under the manifest, 12 is U.S. Net
%   Exports and 15 is Expected Excess Returns -- the same literals silently
%   select different series. Resolved through var_order here.
%
%   REPLACES appendix_individual, which loaded six hard-coded *_JAN2024 files
%   that do not exist in this tree, and computed rerlambda_tfp/rerlambda_noise
%   and vstfp1/vsnoise1 that nothing downstream ever read.
%
%   See also SWEEP, PLOTIRF_PAPER_INDIVIDUAL, DATA_NAME.

    assert(nargin >= 3 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end

    % Legend order is the plotter's, not ours. G6 goes last: the plotter draws
    % pages 1..6 dashed and page 7 solid, and takes its bands from page 7 only.
    PANEL = {'Germany','Italy','France','Canada','Japan','UK'};
    assert(numel(country_infos) == 6, 'genfig_B9B10:count', ...
           'need 6 country runs, got %d', numel(country_infos));
    names = cellfun(@(I) string(I.country), country_infos(:));
    ord_c = zeros(1,6);
    for k = 1:6
        j = find(names == PANEL{k});
        assert(isscalar(j), 'genfig_B9B10:country', ...
            'country_infos has %d entries for %s -- need exactly one of each of %s', ...
            numel(j), PANEL{k}, strjoin(PANEL, ', '));
        ord_c(k) = j;
    end
    runs = [country_infos(ord_c), {base_info}];

    % ---- assemble (nimp x 2*nrows x 5 x 7) ------------------------------
    for jj = 7:-1:1                                   % last first: sizes come from it
        [dt, dn, vn] = local_panel(runs{jj});
        if jj == 7
            vnames = vn;
            individual_tfp   = NaN([size(dt), 7]);
            individual_noise = NaN([size(dn), 7]);
        else
            assert(isequal(vn, vnames), 'genfig_B9B10:rowMismatch', ...
                ['%s has a different row set from the G6 run -- all seven must ' ...
                 'share a manifest layout.'], data_name(runs{jj}));
        end
        individual_tfp(:,:,:,jj)   = dt;
        individual_noise(:,:,:,jj) = dn;
    end

    % TFP does not respond to noise by construction; zero it in both halves of
    % the duplicated column block rather than leaving numerical dust.
    iT = var_order(vnames, 'Home TFP');
    individual_noise(:, [iT, numel(vnames)+iT], :, :) = 0;

    % A country whose response equals the G6's to machine precision did not use
    % that country's data. This was live until cc became derived from
    % info.country (ccdgv_countries): the by-country loop set the name while the
    % loader read a separate stored index, so every run re-estimated G6 and
    % differed only in its filename. The figure that produces looks entirely
    % plausible -- six dashed lines hidden under the solid one -- so the check
    % stays as a backstop against any future path that reintroduces the split.
    d = @(a,b) max(abs(reshape(individual_tfp(:,:,1,a) - individual_tfp(:,:,1,b),[],1)));
    same = arrayfun(@(j) d(j,7) < 1e-10, 1:6);

    % AGAINST EACH OTHER TOO, not only against G6. Comparing to the baseline
    % alone is not enough: sweep pins each country to its own start
    % date, so two runs of the SAME data over different windows differ and the
    % G6 test passes. That is how a whole new-core sweep of six identical G6
    % estimations reached the figure with only Japan -- whose pinned start
    % happened to equal the baseline's -- tripping the check.
    pairs = nchoosek(1:6, 2);
    dup   = arrayfun(@(k) d(pairs(k,1), pairs(k,2)) < 1e-10, 1:size(pairs,1));
    assert(~any(same) && ~any(dup), 'genfig_B9B10:notByCountry', ...
        ['by-country runs are not by country -- %s. The loader ignored the ' ...
         'country and re-estimated the aggregate. datver=''new'' (ryan_data) has ' ...
         'no per-country path: it builds the G6 aggregate only, where the orig ' ...
         'loader indexes fx_ln/idiff_ec/cons_ln/cpi/inv_ln by cc.'], ...
        local_why(same, dup, pairs, PANEL));

    % ---- the six panels, by name ----------------------------------------
    ROWS = {'Home TFP', 'Interest Rate Differential', 'Home Consumption', ...
            'Real Exchange Rate', 'Foreign Consumption', 'Expected Excess Returns'};
    % COLUMN, and not by transposing var_order's output. The plotter reads
    % N = size(order,1) as the panel count and size(order,2) as the number of
    % FIGURES, so a row vector here yields six one-panel figures instead of one
    % six-panel figure -- and gcf then exports the last of them. The old call
    % wrote order_fig2b', which was right only because order_fig2b was a literal
    % row; var_order already returns a column.
    ord = var_order(vnames, ROWS{:});
    ord = ord(:);

    plotIRF_paper_individual(individual_tfp,   ord, vnames, 'Figure2b', 1:6, 1, 0, 0, 1);
    f1 = local_export(gcf, fullfile(dest, 'individual_tfp_new.pdf'));

    plotIRF_paper_individual(individual_noise, ord, vnames, 'Figure3b', 1:6, 1, 1, 0, 1);
    f2 = local_export(gcf, fullfile(dest, 'individual_noise_new.pdf'));

    fout = [f1, f2];
    fprintf('  wrote individual_tfp_new.pdf (B.9), individual_noise_new.pdf (B.10)\n');
    fprintf('    G6       %s\n', data_name(base_info));
    for k = 1:6
        fprintf('    %-8s %s\n', PANEL{k}, data_name(runs{k}));
    end
end

% -------------------------------------------------------------------------
function f = local_export(f, target)
%LOCAL_EXPORT  Write the figure on the DRAFT's terms, not exportgraphics'.
%
%   The draft's individual_tfp.eps / individual_noise.eps are 425x400 points
%   (%%BoundingBox: 0 0 425 400) on a WHITE ground. plotIRF_paper_individual
%   already builds the figure at exactly 425x400, so the geometry was never
%   wrong -- but two defaults of the export call were:
%
%   BACKGROUND. The plotter sets Color = [0.9412 0.9412 0.9412], a grey chosen
%   for slides. The draft is white because it was written with
%   print(...,'-depsc'), and print applies InvertHardcopy='on' by default, which
%   renders the background white whatever the figure's Color says.
%   exportgraphics has no such behaviour: it honours the grey, which is why ours
%   came out shaded. Setting Color explicitly is clearer than relying on an
%   inversion, so the figure is made white and InvertHardcopy turned off.
%
%   CROP. exportgraphics tight-crops to the drawn content, discarding the
%   figure's own margins and changing the effective aspect ratio panel-to-panel.
%   print with an explicit PaperPosition keeps the full 425x400 canvas, so the
%   result overlays the draft.
%
%   Hence print rather than exportgraphics HERE, against the convention in
%   genfig_B11/genfig_B12 -- those figures are built white and full-bleed already,
%   so tight cropping costs them nothing.
    set(f, 'Color', 'w', 'InvertHardcopy', 'off', ...
           'PaperUnits', 'points', 'PaperPosition', [0 0 425 400], ...
           'PaperSize', [425 400]);
    print(f, target, '-dpdf', '-r0');
end

function [dt, dn, vnames] = local_panel(info)
    [~, f] = data_name(info);
    assert(isfile(f), 'genfig_B9B10:noFile', ...
           '%s not found -- has run_sweep''s by-country block been run?', f);
    D = load(f, 'irtfp','irnoise','vnames','point_estimate','bound','bound2');
    h = (size(D.irtfp,1)-1)/2;
    hgrid = -50:20;  discard = 30;      % -> 41 rows, the plotter's CJ axis -20:20
    dt = pack_bands(cumsum(D.irtfp),   hgrid+h+1, discard, D);
    dn = pack_bands(cumsum(D.irnoise), hgrid+h+1, discard, D);
    vnames = D.vnames;
end


% -------------------------------------------------------------------------
function msg = local_why(same, dup, pairs, PANEL)
    m = {};
    if any(same); m{end+1} = sprintf('%s identical to G6', strjoin(PANEL(same),', ')); end
    if any(dup)
        k = find(dup);
        m{end+1} = sprintf('%s identical to each other', strjoin(arrayfun(@(i) ...
            sprintf('%s=%s', PANEL{pairs(i,1)}, PANEL{pairs(i,2)}), k, ...
            'UniformOutput', false), ', '));
    end
    msg = strjoin(m, '; ');
end
