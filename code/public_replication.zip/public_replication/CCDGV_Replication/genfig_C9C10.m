function fout = genfig_C9C10(country_infos, base_info, dest)
%GENFIG_C9C10  Figures C.9 and C.10: responses to technology and noise by country.
%
%   fout = GENFIG_C9C10(country_infos, base_info, dest)
%
%   country_infos  1x6 cell of run descriptors, one per country, in any order
%   base_info      descriptor of the G6 run, drawn solid with bands
%   dest           output directory (required)
%   fout           [Figure C.9 (technology), Figure C.10 (noise)]
%
%   Six panels per figure, each with six dashed lines for the individual
%   countries and one solid line for the G6.
%
%   See also SWEEP, PLOTIRF_PAPER_INDIVIDUAL, DATA_NAME.

    assert(nargin >= 3 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end

    % Put the countries in the plotter's legend order, matching by name. The G6
    % goes last: the plotter draws pages 1..6 dashed and page 7 solid with bands.
    PANEL = {'Germany','Italy','France','Canada','Japan','UK'};
    assert(numel(country_infos) == 6, 'genfig_C9C10:count', ...
           'need 6 country runs, got %d', numel(country_infos));
    names = cellfun(@(I) string(I.country), country_infos(:));
    ord_c = zeros(1,6);
    for k = 1:6
        j = find(names == PANEL{k});
        assert(isscalar(j), 'genfig_C9C10:country', ...
            'country_infos has %d entries for %s -- need exactly one of each of %s', ...
            numel(j), PANEL{k}, strjoin(PANEL, ', '));
        ord_c(k) = j;
    end
    runs = [country_infos(ord_c), {base_info}];

    % Stack the packed responses: nimp x 2*nrows x 5 x 7.
    for jj = 7:-1:1                                   % last first: it sets the sizes
        [dt, dn, vn] = cj_bands(runs{jj});
        if jj == 7
            vnames = vn;
            individual_tfp   = NaN([size(dt), 7]);
            individual_noise = NaN([size(dn), 7]);
        else
            assert(isequal(vn, vnames), 'genfig_C9C10:rowMismatch', ...
                ['%s has a different row set from the G6 run -- all seven must ' ...
                 'share a manifest layout.'], data_name(runs{jj}));
        end
        individual_tfp(:,:,:,jj)   = dt;
        individual_noise(:,:,:,jj) = dn;
    end

    % TFP does not respond to noise by construction: set it to exactly zero.
    iT = var_order(vnames, 'Home TFP');
    individual_noise(:, [iT, numel(vnames)+iT], :, :) = 0;

    % Check that the runs are by country: no country's response may equal the
    % G6's or another country's.
    d = @(a,b) max(abs(reshape(individual_tfp(:,:,1,a) - individual_tfp(:,:,1,b),[],1)));
    same = arrayfun(@(j) d(j,7) < 1e-10, 1:6);

    pairs = nchoosek(1:6, 2);
    dup   = arrayfun(@(k) d(pairs(k,1), pairs(k,2)) < 1e-10, 1:size(pairs,1));
    assert(~any(same) && ~any(dup), 'genfig_C9C10:notByCountry', ...
        ['by-country runs are not by country -- %s. The loader ignored the ' ...
         'country and re-estimated the aggregate. datver=''new'' (ryan_data) has ' ...
         'no per-country path: it builds the G6 aggregate only, where the orig ' ...
         'loader indexes fx_ln/idiff_ec/cons_ln/cpi/inv_ln by cc.'], ...
        local_why(same, dup, pairs, PANEL));

    % The six panels, by name.
    ROWS = {'Home TFP', 'Interest Rate Differential', 'Home Consumption', ...
            'Real Exchange Rate', 'Foreign Consumption', 'Expected Excess Returns'};
    % ord must be a column: the plotter reads its rows as panels and its columns
    % as separate figures.
    ord = var_order(vnames, ROWS{:});
    ord = ord(:);

    plotIRF_paper_individual(individual_tfp,   ord, vnames, 'FigureC9', 1:6, 1, 0, 0, 1);
    f1 = local_export(gcf, fullfile(dest, 'FigureC9.pdf'));

    plotIRF_paper_individual(individual_noise, ord, vnames, 'FigureC10', 1:6, 1, 1, 0, 1);
    f2 = local_export(gcf, fullfile(dest, 'FigureC10.pdf'));

    fout = [f1, f2];
    fprintf('  wrote FigureC9.pdf, FigureC10.pdf\n');
    fprintf('    G6       %s\n', data_name(base_info));
    for k = 1:6
        fprintf('    %-8s %s\n', PANEL{k}, data_name(runs{k}));
    end
end

% -------------------------------------------------------------------------
function f = local_export(f, target)
%   Set a white background and print the whole 425x400 canvas rather than
%   cropping to content.
    set(f, 'Color', 'w', 'InvertHardcopy', 'off', ...
           'PaperUnits', 'points', 'PaperPosition', [0 0 425 400], ...
           'PaperSize', [425 400]);
    print(f, target, '-dpdf', '-r0');
end


% -------------------------------------------------------------------------
function msg = local_why(same, dup, pairs, PANEL)
    m = {};
    if any(same); m{end+1} = sprintf('%s identical to G6', strjoin(PANEL(same),', ')); end
    if any(dup)
        k = find(dup);
        m{end+1} = sprintf('%s identical to each other', strjoin(arrayfun(@(i) ...
            sprintf('%s=%s', PANEL{pairs(i,1)}, PANEL{pairs(i,2)}), k, ...
            'UniformOutput', false), ', '));
    end
    msg = strjoin(m, '; ');
end
