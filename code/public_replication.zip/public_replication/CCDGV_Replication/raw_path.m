function p = raw_path(varargin)
%RAW_PATH  Absolute path to a file under the package's single raw-data folder.
%
%   p = RAW_PATH('USDATA.xlsx')
%   p = RAW_PATH('Fernald','data_quarterly_2026.06.04.xlsx')
%
%   There is ONE raw-data folder, Data_Replication/Raw_Data. The estimation code
%   used to carry a second copy under CCDGV_Replication/Raw_Data -- six files were
%   byte-identical across the two, and nothing said which was authoritative. The
%   files that lived only there are now under Raw_Data/CCDGV.
%
%   Reach it through here rather than by building a relative path: callers sit at
%   different depths, and a bare 'Raw_Data/x' only resolves when the working
%   directory happens to be right.

    here = fileparts(mfilename('fullpath'));          % CCDGV_Replication
    root = fileparts(here);                           % the package
    p    = fullfile(root, 'Data_Replication', 'Raw_Data', varargin{:});
end
