function p = raw_path(varargin)
%RAW_PATH  Absolute path to a file under Data_Replication/Raw_Data.
%
%   p = raw_path('USDATA.xlsx')
%   p = raw_path('Fernald', 'data_quarterly_2026.06.04.xlsx')
%
%   The arguments are path parts below Raw_Data, as for fullfile.

    here = fileparts(mfilename('fullpath'));          % CCDGV_Replication
    root = fileparts(here);                           % the package
    p    = fullfile(root, 'Data_Replication', 'Raw_Data', varargin{:});
end
