function fout = genfig_C7C8(base_info, alts, dest)
%GENFIG_C7C8  Figures C.7 and C.8: responses under alternative specifications.
%
%   fout = GENFIG_C7C8(base_info, alts, dest)
%
%   base_info  descriptor of the baseline run, drawn solid with 16-84 bands
%   alts       n x 2 cell, {legend label, info} per dashed overlay. A row whose
%              info is empty is dropped and reported.
%   dest       output directory (required)
%   fout       [Figure C.7 (technology), Figure C.8 (noise)]
%
%   Six panels per figure. All runs must have the same row names.
%
%   See also GENFIG_C10C11, PLOTIRF_PAPER_INDIVIDUAL, SWEEP.

    assert(nargin >= 3 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end

    % Drop overlays that have no run.
    keep = ~cellfun(@isempty, alts(:,2));
    if any(~keep)
        fprintf('  C.7/C.8: no run for %s -- omitted from the figure\n', ...
                strjoin(alts(~keep,1)', ', '));
    end
    alts = alts(keep,:);
    assert(~isempty(alts), 'genfig_C7C8:noAlts', 'no alternative specs supplied');
    labels = alts(:,1)';
    runs   = [alts(:,2)', {base_info}];      % solid last, as the plotter expects

    % Stack the packed responses: nimp x 2*nrows x 5 x numel(runs).
    n = numel(runs);
    for jj = n:-1:1
        [dt, dn, vn] = cj_bands(runs{jj});
        if jj == n
            vnames = vn;
            individual_tfp   = NaN([size(dt), n]);
            individual_noise = NaN([size(dn), n]);
        else
            assert(isequal(vn, vnames), 'genfig_C7C8:rowMismatch', ...
                ['%s has %d rows against the baseline''s %d -- the runs predate ' ...
                 'different manifest versions and cannot be overlaid. Re-run them ' ...
                 'against the current manifest.'], ...
                data_name(runs{jj}), numel(vn), numel(vnames));
        end
        individual_tfp(:,:,:,jj)   = dt;
        individual_noise(:,:,:,jj) = dn;
    end

    % TFP does not respond to noise by construction: set it to exactly zero.
    iT = var_order(vnames, 'Home TFP');
    individual_noise(:, [iT, numel(vnames)+iT], :, :) = 0;

    ROWS = {'Home TFP', 'Interest Rate Differential', 'Home Consumption', ...
            'Real Exchange Rate', 'Foreign Consumption', 'Expected Excess Returns'};
    ord = var_order(vnames, ROWS{:});  ord = ord(:);


    % Overlay colours in legend order, and a three-column legend. The colours are
    % listed explicitly so that no overlay takes the solid line's colour.
    LEGCOLS = 3;  COFF = 1;
    COLS = [0.850 0.325 0.098     % orange
            0.929 0.694 0.125     % yellow
            0.494 0.184 0.556     % purple
            0.466 0.674 0.188     % green
            0.301 0.745 0.933     % cyan
            0.635 0.078 0.184     % dark red
            0.400 0.400 0.400];   % grey
    COLS = COLS(1:numel(labels),:);
    plotIRF_paper_individual(individual_tfp,   ord, vnames, 'altTFP',   1:6, 1, 0, 0, 1, labels, LEGCOLS, COFF, COLS);
    fout(1) = local_export(gcf, fullfile(dest, 'FigureC7.pdf'));

    plotIRF_paper_individual(individual_noise, ord, vnames, 'altNOISE', 1:6, 1, 1, 0, 1, labels, LEGCOLS, COFF, COLS);
    fout(2) = local_export(gcf, fullfile(dest, 'FigureC8.pdf'));


    fprintf('  wrote FigureC7.pdf, FigureC8.pdf\n');
    fprintf('    baseline %s\n', data_name(base_info));
    for k = 1:numel(labels)
        fprintf('    %-22s %s\n', labels{k}, data_name(alts{k,2}));
    end
end

% -------------------------------------------------------------------------
function f = local_export(f, target)
%   Print the whole 425x400 canvas rather than cropping to content.
    set(f, 'Color','w', 'InvertHardcopy','off', 'PaperUnits','points', ...
           'PaperPosition',[0 0 425 400], 'PaperSize',[425 400]);
    print(f, target, '-dpdf', '-r0');
end

