function fout = genfig_real_yields(base_info, dest)
%GENFIG_REAL_YIELDS  Responses of US and G6 10-year bond yields, nominal and real.
%
%   fout = GENFIG_REAL_YIELDS(base_info, dest)
%
%   base_info  descriptor of the baseline run
%   dest       output directory (required)
%   fout       [technology figure, noise figure]
%
%   Six panels, 2x3, in each figure:
%       Bond Yield Differential        US 10-Y Bond Yield        G6 10-Y Bond Yield
%       Real Bond Yield Differential   US Real 10-Y Bond Yield   G6 Real 10-Y Bond Yield
%   Nominal yields are projected on the VAR's state. A real yield is the nominal
%   yield less the average quarterly inflation the VAR expects over the next 40
%   quarters, with US prices from the projected US CPI and G6 prices US CPI
%   minus CPIDIFF. The differentials are U.S. minus G6, formed draw by draw.
%   Yields are drawn annualized, in percentage points.
%
%   See also GENFIG_RATES, GENFIG_ASSET_PROJ, GEN_AUXVARS, PLOTIRF.

    assert(nargin >= 2 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~isfolder(dest); mkdir(dest); end

    [nm, f] = data_name(base_info);
    assert(isfile(f), 'genfig_real_yields:noFile', '%s not found', f);
    D = load(f, 'irtfp','irnoise','vnames','point_estimate','bound','bound2', ...
                'r2','nobs','info');

    NOM  = {'US 10-Y Bond Yield', 'G6 10-Y Bond Yield'};
    REAL = {'US Real 10-Y Bond Yield', 'G6 Real 10-Y Bond Yield'};
    for r = [NOM, REAL]
        assert(any(strcmp(D.vnames, r{1})), 'genfig_real_yields:noRow', ...
            '%s has no "%s" row -- re-run estimate_one on this branch', nm, r{1});
    end
    for r = [NOM, {'US CPI'}]
        i = var_order(D.vnames, r{1});
        assert(abs(D.r2(i) - 1) >= 1e-8, 'genfig_real_yields:inVAR', ...
            '%s is in the VAR of %s; pass the baseline run', r{1}, nm);
    end

    % Differentials, draw by draw, appended as extra rows.
    in = var_order(D.vnames, NOM{:});
    ir = var_order(D.vnames, REAL{:});
    DIFFNM = {'Bond Yield Differential', 'Real Bond Yield Differential'};
    vn  = [D.vnames, DIFFNM];
    add = @(x) cat(2, x, x(:,in(1),:) - x(:,in(2),:), x(:,ir(1),:) - x(:,ir(2),:));
    irt = add(D.irtfp);
    irn = add(D.irnoise);

    ROWS = [DIFFNM(1), NOM, DIFFNM(2), REAL];
    ord  = var_order(vn, ROWS{:});  ord = ord(:);

    % Cumulate, take horizons -50:20 and discard the first 30, leaving -20:20.
    h   = (size(irt,1)-1)/2;
    win = (-50:20) + h + 1;
    dt  = pack_bands(cumsum(irt), win, 30, D);
    dn  = pack_bands(cumsum(irn), win, 30, D);

    prefs = plotIRF;
    prefs.rates = rate_rows(vn);
    [f1, prefs] = plotIRF(dt, ord, vn, 'FigureRealYields_a', 1:numel(ord), prefs);
    exportgraphics(f1(1), fullfile(dest, 'FigureRealYields_a.pdf'));
    prefs.NOISE = 1;
    f2 = plotIRF(dn, ord, vn, 'FigureRealYields_b', 1:numel(ord), prefs);
    exportgraphics(f2(1), fullfile(dest, 'FigureRealYields_b.pdf'));
    fout = [f1(1), f2(1)];

    fprintf('  wrote FigureRealYields_a.pdf / FigureRealYields_b.pdf\n');
end
