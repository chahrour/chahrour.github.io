function fout = genfig_asset_proj(base_info, dest, opt)
%GENFIG_ASSET_PROJ  Figure 5: responses of equity prices and real bond yields.
%
%   fout = GENFIG_ASSET_PROJ(base_info, dest)
%
%   base_info  descriptor of the baseline run, whose VAR contains none of the
%              four asset series
%   dest       output directory (required)
%   fout       [technology figure, noise figure]; empty if the yield rows are
%              all NaN, in which case nothing is drawn
%
%   Six panels, 2x3, in each figure:
%       Home Equity Prices          Foreign Equity Prices          Equity Price Differential
%       Home Real 10-Y Bond Yield   Foreign Real 10-Y Bond Yield   Real Bond Yield Differential
%   Equity prices and nominal yields are projections on the VAR's state. A real
%   yield is the nominal yield less the average quarterly inflation the VAR
%   expects over the next 40 quarters (GEN_AUXVARS). The differentials are U.S.
%   minus G6 and are formed draw by draw, before medians and bands are taken.
%   Yields are stored in percent per quarter and drawn annualized, in
%   percentage points; equity prices are 100 times the log level.
%
%   See also EXTRA_ASSET_ROWS, PLOTIRF.

    assert(nargin >= 2 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end

    [nm, f] = data_name(base_info);
    assert(isfile(f), 'genfig_asset_proj:noFile', '%s not found', f);
    D = load(f, 'irtfp','irnoise','vnames','point_estimate','bound','bound2', ...
                'r2','nobs','projblocks','info');
    % sfx is a file-name suffix; it is always empty.
    sfx = '';

    BY = extra_asset_rows('yields');
    EQ = extra_asset_rows('equity');

    % The four asset rows must be projected (r2 < 1), not variables of the VAR.
    iby = var_order(D.vnames, BY{:});
    ieq = var_order(D.vnames, EQ{:});
    all4 = [iby; ieq];
    for k = 1:numel(all4)
        i = all4(k);
        assert(i <= numel(D.r2), 'genfig_asset_proj:shortR2', ...
            'r2 has %d entries but %s is row %d of vnames -- re-run estimate_one', ...
            numel(D.r2), D.vnames{i}, i);
        assert(abs(D.r2(i) - 1) >= 1e-8, 'genfig_asset_proj:inVAR', ...
            ['%s has r2 = %.4f in %s -- it is IN that VAR, not projected onto ' ...
             'it. This figure is the externally projected one: pass the ' ...
             'BASELINE run (inclvar = 1), not an augmented spec.'], ...
            D.vnames{i}, D.r2(i), nm);
    end
    % Each pair must be projected on the same state; a different sample only warns.
    local_same(D, iby, 'bond yield');
    local_same(D, ieq, 'equity price');

    % Skip the figure when the bond-yield rows are all NaN.
    if all(isnan(D.irtfp(:, iby(1), 1))) && all(isnan(D.irtfp(:, iby(2), 1)))
        fprintf(['  asset projections skipped: the bond-yield rows are all NaN\n' ...
                 '  (Yields_M.mat was not on the path when %s was built).\n'], nm);
        fout = gobjects(1,0);
        return
    end

    % Real yields: constructed from the projected nominal yields and prices.
    RY  = extra_asset_rows('real_yields');
    assert(all(ismember(RY, D.vnames)), 'genfig_asset_proj:noRealYields', ...
        '%s has no real-yield rows -- re-run estimate_one with the current manifest', nm);
    iry = var_order(D.vnames, RY{:});

    % Differentials, draw by draw.
    DIFFNM = {'Real Bond Yield Differential', 'Equity Price Differential'};
    vn  = [D.vnames, DIFFNM];
    irt = local_adddiff(D.irtfp,   iry, ieq);
    irn = local_adddiff(D.irnoise, iry, ieq);

    ROWS = [EQ, DIFFNM(2), RY, DIFFNM(1)];
    ord  = var_order(vn, ROWS{:});  ord = ord(:);

    % Panel titles say home and foreign, in title case, as in Figures 2-4.
    ttl = vn;
    ttl(var_order(vn, EQ{:}, RY{:})) = {'Home Equity Prices', 'Foreign Equity Prices', ...
        'Home Real 10-Y Bond Yield', 'Foreign Real 10-Y Bond Yield'};

    % Cumulate, take horizons -50:20 and discard the first 30, leaving -20:20.
    h = (size(irt,1)-1)/2;
    win = (-50:20) + h + 1;
    dt = pack_bands(cumsum(irt), win, 30, D);
    dn = pack_bands(cumsum(irn), win, 30, D);

    % Draw on plotIRF's default 2x3 grid and canvas, as Figures 3 and 4.
    n1 = ['Figure5a' sfx];
    n2 = ['Figure5b' sfx];
    % Bond yields are drawn annualized.
    prefs = plotIRF;
    prefs.rates = rate_rows(vn);
    [f1, prefs] = plotIRF(dt, ord, ttl, n1, 1:numel(ord), prefs);
    exportgraphics(f1(1), fullfile(dest,[n1 '.pdf']));

    % prefs is reused so the two figures share a layout; NOISE = 1 draws in red.
    prefs.NOISE = 1;
    f2 = plotIRF(dn, ord, ttl, n2, 1:numel(ord), prefs);
    exportgraphics(f2(1), fullfile(dest,[n2 '.pdf']));
    fout = [f1(1), f2(1)];

    fprintf('  wrote %s.pdf / %s.pdf (externally projected assets)\n', n1, n2);
    fprintf('    %s  (%d-variable VAR, none of the four asset rows in it)\n', ...
            nm, numel(D.info.inclvarnms));
    fprintf('    differentials are U.S. minus G6, formed per draw\n');
    for i = [iby; ieq]'
        fprintf('    %-22s R2 %.3f over %d quarters, %g state blocks\n', ...
                D.vnames{i}, D.r2(i), D.nobs(i), D.projblocks(i));
    end
end

% -------------------------------------------------------------------------
function local_same(D, ii, what)
%LOCAL_SAME  Check that a pair of rows is projected comparably.
%   With the same state (projblocks) and the same sample (nobs), the difference
%   of the two projected rows equals the projection of the difference. A
%   different state is an error; a different sample is a warning.
    assert(numel(D.projblocks) >= max(ii), 'genfig_asset_proj:shortProjblocks', ...
        'projblocks has %d entries but the %s rows go to %d', ...
        numel(D.projblocks), what, max(ii));
    assert(isequaln(D.projblocks(ii(1)), D.projblocks(ii(2))), ...
        'genfig_asset_proj:projblocks', ...
        ['the two %s rows are projected on %g and %g state blocks -- their ' ...
         'difference is not the difference''s projection. Fix projblocks in ' ...
         'ccdgv_manifest.'], what, D.projblocks(ii(1)), D.projblocks(ii(2)));

    assert(numel(D.nobs) >= max(ii), 'genfig_asset_proj:shortNobs', ...
        'nobs has %d entries but the %s rows go to %d', numel(D.nobs), what, max(ii));
    if D.nobs(ii(1)) ~= D.nobs(ii(2))
        warning('genfig_asset_proj:nobs', ...
            ['the two %s rows are projected over %d and %d quarters, so their ' ...
             'differential panel is the difference of two projections rather ' ...
             'than the projection of the differential. Read it with that in ' ...
             'mind, and report the coverage alongside the figure.'], ...
            what, D.nobs(ii(1)), D.nobs(ii(2)));
    end
end

function ir = local_adddiff(ir, iby, ieq)
%LOCAL_ADDDIFF  Append the two U.S.-minus-G6 differentials as extra rows, in the
%   order of DIFFNM.
    ir = cat(2, ir, ir(:,iby(1),:) - ir(:,iby(2),:), ...
                    ir(:,ieq(1),:) - ir(:,ieq(2),:));
end

