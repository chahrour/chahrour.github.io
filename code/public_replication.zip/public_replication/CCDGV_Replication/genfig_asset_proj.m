function fout = genfig_asset_proj(base_info, dest, opt)
%GENFIG_ASSET_PROJ  Externally projected asset responses to the CJ shocks,
%                   including the U.S.-minus-G6 differentials.
%
%   fout = GENFIG_ASSET_PROJ(base_info)
%   fout = GENFIG_ASSET_PROJ(base_info, dest)
%   fout = GENFIG_ASSET_PROJ(base_info, dest, opt)
%   base_info  the BASELINE run (inclvar 1). Not an augmented one -- see below.
%   fout       [technology figure, noise figure], empty if the yield rows are
%              absent or all NaN (the figure says so and draws nothing)
%
%   SIX PANELS, 2x3, row-major:
%       US 10-Y Bond Yield    G6 10-Y Bond Yield    Bond Yield Differential
%       US equity prices      G6 equity prices      Equity Price Differential
%   Two figures with that same layout: one for the technology shock, one for
%   noise.
%
%   EXTERNALLY PROJECTED, WHICH IS THE POINT. The baseline VAR contains none of
%   these four asset series, so their rows of A are the VAR's best linear
%   predictors rather than its own variables -- r2 < 1, and the assert below
%   refuses a run where any of them is inside. The shocks are therefore the
%   PAPER'S shocks, identified on the eight baseline variables and unaffected by
%   the assets, and what the figure shows is how much of each asset series those
%   shocks explain from outside. Assets 3/4 and 8/9 answer the other question --
%   the asset in the VAR, so a different identification each time -- and the two
%   sets are meant to be read against each other.
%
%   THE DIFFERENTIALS ARE FORMED AT THE DRAW LEVEL, before any median or
%   quantile is taken. Quantiles do not subtract: median(x) - median(y) is not
%   median(x-y), and the 16-84 band of a difference is not the difference of the
%   two bands. So two synthetic columns are appended to irtfp/irnoise draw by
%   draw and carried through the same packing as every other row.
%
%   AND THE DIFFERENTIAL OF THE PROJECTIONS IS THE PROJECTION OF THE
%   DIFFERENTIAL. Projection is linear in the dependent variable, so regressing
%   (x - y) on the companion state gives exactly the difference of the two
%   fitted rows -- PROVIDED both are projected on the same state over the same
%   sample. Same state is projblocks, which is asserted; same sample is nobs,
%   which is checked and WARNED about rather than refused, because the GFD yield
%   panel's coverage is genuinely ragged. See LOCAL_SAME for why the two are
%   treated differently. Both are printed below the figure either way.
%
%   SIGN: U.S. MINUS G6, both pairs, matching IDIFF and CPIDIFF.
%
%   UNITS DIFFER BY ROW. The yields are quarterly logs scaled by 100 -- percent
%   per quarter, IDIFF's units -- and the equity prices are log levels scaled by
%   100. The two rows of panels are therefore not on a common scale, and neither
%   are their differentials. plotIRF scales each panel to its own data, as
%   everywhere else.
%
%   NO TFP PANEL, so the noise figure's zero restriction (see
%   GENFIG_EXTRA_EQUITY) has nothing to impose here.
%
%   SKIPS ITSELF, rather than drawing empty panels, when the bond-yield rows are
%   all NaN -- the live case when Yields_M.mat was not on the path at build time.
%   Figure B.6 checks the same thing for the same reason.
%
%   See also EXTRA_ASSET_ROWS, PLOTIRF.

    assert(nargin >= 2 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end

    [nm, f] = data_name(base_info);
    assert(isfile(f), 'genfig_asset_proj:noFile', '%s not found', f);
    D = load(f, 'irtfp','irnoise','vnames','point_estimate','bound','bound2', ...
                'r2','nobs','projblocks','info');
    % One projection stage, so the run file holds the only one there is.
    sfx = '';

    BY = extra_asset_rows('yields');
    EQ = extra_asset_rows('equity');

    % ---- the rows must be PROJECTED, and comparably so ----------------------
    iby = var_order(D.vnames, BY{:});
    ieq = var_order(D.vnames, EQ{:});
    all4 = [iby; ieq];
    for k = 1:numel(all4)
        i = all4(k);
        assert(i <= numel(D.r2), 'genfig_asset_proj:shortR2', ...
            'r2 has %d entries but %s is row %d of vnames -- re-run run_main', ...
            numel(D.r2), D.vnames{i}, i);
        assert(abs(D.r2(i) - 1) >= 1e-8, 'genfig_asset_proj:inVAR', ...
            ['%s has r2 = %.4f in %s -- it is IN that VAR, not projected onto ' ...
             'it. This figure is the externally projected one: pass the ' ...
             'BASELINE run (inclvar = 1), not an augmented spec.'], ...
            D.vnames{i}, D.r2(i), nm);
    end
    local_same(D, iby, 'bond yield');
    local_same(D, ieq, 'equity price');

    % Rows that project onto nothing. Not an error -- the equity half is still
    % drawable -- but half a figure presented as a whole one is worse than none.
    if all(isnan(D.irtfp(:, iby(1), 1))) && all(isnan(D.irtfp(:, iby(2), 1)))
        fprintf(['  asset projections skipped: the bond-yield rows are all NaN\n' ...
                 '  (Yields_M.mat was not on the path when %s was built).\n'], nm);
        fout = gobjects(1,0);
        return
    end

    % ---- the differentials, draw by draw -----------------------------------
    DIFFNM = {'Bond Yield Differential', 'Equity Price Differential'};
    vn  = [D.vnames, DIFFNM];
    irt = local_adddiff(D.irtfp,   iby, ieq);
    irn = local_adddiff(D.irnoise, iby, ieq);

    ROWS = [BY, DIFFNM(1), EQ, DIFFNM(2)];
    ord  = var_order(vn, ROWS{:});  ord = ord(:);

    % The same window and discard as the other asset panels, so these line up
    % with Assets 3 and 4. Parenthesised: -50:20+h+1 is a different range.
    h = (size(irt,1)-1)/2;
    win = (-50:20) + h + 1;
    dt = pack_bands(cumsum(irt), win, 30, D);
    dn = pack_bands(cumsum(irn), win, 30, D);

    % ---- draw ---------------------------------------------------------------
    % plotIRF's default 2x3 grid and default canvas, which is what Figures 3 and 4
    % and the Asset 3/4 pairs use -- these print at the same size beside them.
    n1 = ['asset_proj_tech'  sfx];
    n2 = ['asset_proj_noise' sfx];
    [f1, prefs] = plotIRF(dt, ord, vn, n1, 1:numel(ord));
    exportgraphics(f1(1), fullfile(dest,[n1 '.pdf']));

    % RED FOR NOISE, set explicitly. prefs is reused so the two figures share a
    % layout, and NOISE is one of its fields -- inheriting it unchanged is how
    % the Asset 3/4 noise figures were blue for a year.
    prefs.NOISE = 1;
    f2 = plotIRF(dn, ord, vn, n2, 1:numel(ord), prefs);
    exportgraphics(f2(1), fullfile(dest,[n2 '.pdf']));
    fout = [f1(1), f2(1)];

    fprintf('  wrote %s.pdf / %s.pdf (externally projected assets)\n', n1, n2);
    fprintf('    %s  (%d-variable VAR, none of the four asset rows in it)\n', ...
            nm, numel(D.info.inclvarnms));
    fprintf('    differentials are U.S. minus G6, formed per draw\n');
    for i = [iby; ieq]'
        fprintf('    %-22s R2 %.3f over %d quarters, %g state blocks\n', ...
                D.vnames{i}, D.r2(i), D.nobs(i), D.projblocks(i));
    end
end

% -------------------------------------------------------------------------
function local_same(D, ii, what)
%LOCAL_SAME  Is this differential the differential's own projection?
%   Same companion state (projblocks) and same estimation sample (nobs) are
%   exactly the conditions under which the difference of the two projected rows
%   equals the projection of the difference.
%
%   THE STATE IS AN ASSERT, THE SAMPLE A WARNING, and the asymmetry is
%   deliberate. Two rows of a pair projected on different state widths is a
%   manifest inconsistency -- someone set projblocks on one of a pair -- and
%   nothing downstream can interpret the result. Ragged coverage is not a bug:
%   the GFD yield panel simply reaches where it reaches, and the difference of
%   two projections over overlapping-but-unequal samples is still the object the
%   figure draws. It just is not exactly the differential's own projection, so it
%   is said out loud rather than silently accepted or refused.
    assert(numel(D.projblocks) >= max(ii), 'genfig_asset_proj:shortProjblocks', ...
        'projblocks has %d entries but the %s rows go to %d', ...
        numel(D.projblocks), what, max(ii));
    assert(isequaln(D.projblocks(ii(1)), D.projblocks(ii(2))), ...
        'genfig_asset_proj:projblocks', ...
        ['the two %s rows are projected on %g and %g state blocks -- their ' ...
         'difference is not the difference''s projection. Fix projblocks in ' ...
         'ccdgv_manifest.'], what, D.projblocks(ii(1)), D.projblocks(ii(2)));

    assert(numel(D.nobs) >= max(ii), 'genfig_asset_proj:shortNobs', ...
        'nobs has %d entries but the %s rows go to %d', numel(D.nobs), what, max(ii));
    if D.nobs(ii(1)) ~= D.nobs(ii(2))
        warning('genfig_asset_proj:nobs', ...
            ['the two %s rows are projected over %d and %d quarters, so their ' ...
             'differential panel is the difference of two projections rather ' ...
             'than the projection of the differential. Read it with that in ' ...
             'mind, and report the coverage alongside the figure.'], ...
            what, D.nobs(ii(1)), D.nobs(ii(2)));
    end
end

function ir = local_adddiff(ir, iby, ieq)
%LOCAL_ADDDIFF  Append the two U.S.-minus-G6 differentials as extra ROWS of A.
%   Appended in the order DIFFNM names them, so var_order finds them where the
%   extended vnames says they are.
    ir = cat(2, ir, ir(:,iby(1),:) - ir(:,iby(2),:), ...
                    ir(:,ieq(1),:) - ir(:,ieq(2),:));
end

