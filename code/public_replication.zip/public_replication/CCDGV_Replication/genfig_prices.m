function fout = genfig_prices(base_info, dest)
%GENFIG_PRICES  Responses of the US and G6 price levels and their differential.
%
%   fout = GENFIG_PRICES(base_info, dest)
%
%   base_info  descriptor of the baseline run
%   dest       output directory (required)
%   fout       [technology figure, noise figure]
%
%   Three panels, 1x3, in each figure:
%       Price Differential (CPIDIFF)   US CPI   G6 CPI
%   The US CPI is projected on the VAR's state. The G6 CPI is the US CPI minus
%   CPIDIFF, formed draw by draw before medians and bands are taken, so the
%   three panels add up in every draw. All are 100 times log levels.
%
%   See also GENFIG_RATES, GENFIG_ASSET_PROJ, PLOTIRF.

    assert(nargin >= 2 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~isfolder(dest); mkdir(dest); end

    [nm, f] = data_name(base_info);
    assert(isfile(f), 'genfig_prices:noFile', '%s not found', f);
    D = load(f, 'irtfp','irnoise','vnames','point_estimate','bound','bound2', ...
                'r2','nobs','info');

    assert(any(strcmp(D.vnames, 'US CPI')), 'genfig_prices:noRow', ...
        '%s has no "US CPI" row -- re-run estimate_one on this branch', nm);
    ip = var_order(D.vnames, 'US CPI');
    id = var_order(D.vnames, 'CPIDIFF');
    assert(abs(D.r2(ip) - 1) >= 1e-8, 'genfig_prices:inVAR', ...
        'US CPI is in the VAR of %s; pass the baseline run', nm);

    % G6 CPI = US CPI - CPIDIFF, appended as an extra row.
    vn  = [D.vnames, {'G6 CPI'}];
    vn{id} = 'Price Differential';
    g6  = @(ir) cat(2, ir, ir(:,ip,:) - ir(:,id,:));
    irt = g6(D.irtfp);
    irn = g6(D.irnoise);
    ord = [id; ip; numel(vn)];

    % Cumulate, take horizons -50:20 and discard the first 30, leaving -20:20.
    h   = (size(irt,1)-1)/2;
    win = (-50:20) + h + 1;
    dt  = pack_bands(cumsum(irt), win, 30, D);
    dn  = pack_bands(cumsum(irn), win, 30, D);

    % One row of the rate figures' grid, at the same panel size.
    prefs = plotIRF;
    prefs.nrow = 1;  prefs.ncol = 3;
    prefs.position(4) = prefs.position(4)/2;
    [f1, prefs] = plotIRF(dt, ord, vn, 'FigurePrices_a', 1:numel(ord), prefs);
    exportgraphics(f1(1), fullfile(dest, 'FigurePrices_a.pdf'));
    prefs.NOISE = 1;
    f2 = plotIRF(dn, ord, vn, 'FigurePrices_b', 1:numel(ord), prefs);
    exportgraphics(f2(1), fullfile(dest, 'FigurePrices_b.pdf'));
    fout = [f1(1), f2(1)];

    fprintf('  wrote FigurePrices_a.pdf / FigurePrices_b.pdf\n');
    fprintf('    US CPI R2 %.3f over %d quarters\n', D.r2(ip), D.nobs(ip));
end
