function fout = genfig_R23(base_info, alt_info, alt_label, stem, extra_row, dest)
%GENFIG_R23  Referee figures R2-R5: responses in the baseline and in an asset
%            specification.
%
%   fout = GENFIG_R23(base_info, alt_info, alt_label, stem, extra_row, dest)
%
%   base_info   descriptor of the baseline run, drawn with its grey 16-84 band
%   alt_info    descriptor of the alternative run, drawn lighter with its own band
%   alt_label   legend text for the alternative, e.g. 'w/o FX, w/ Equity Prices'
%   stem        file stem; writes <stem>a.pdf (technology) and <stem>b.pdf (noise)
%   extra_row   name of the row drawn in the sixth panel; '' leaves it empty.
%               If the row is not in the alternative's VAR, its line there is
%               the projection of the row on that VAR's state.
%   dest        output directory (required)
%   fout        [technology figure, noise figure]
%
%   Panels, on a 3x2 grid:
%       Home TFP                    Expected Home TFP
%       Home Consumption            Foreign Consumption
%       Interest Rate Differential  extra_row, or empty
%   R2 and R3 are the equity and bond-yield specifications without the exchange
%   rate; R4 and R5 are the same two with it.
%
%   See also GENFIG_C7C8, GENFIG_R1, PLOTIRF.

    if nargin < 5; extra_row = ''; end
    assert(nargin >= 6 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end

    % The cumulated responses of each run on horizons -20:20, median and bands.
    [dtb, dnb, Db.vnames] = cj_bands(base_info);
    [dta, dna, Da.vnames] = cj_bands(alt_info);
    nb = data_name(base_info);  na = data_name(alt_info);

    % The two runs must have the same rows: plotIRF applies one order vector to
    % both the data and the overlay.
    assert(isequal(Da.vnames, Db.vnames), 'genfig_R23:rowMismatch', ...
        ['%s has %d rows against the baseline''s %d -- the runs predate ' ...
         'different manifest versions and cannot be overlaid. Re-run them ' ...
         'against the current manifest.'], na, numel(Da.vnames), numel(Db.vnames));

    % The two runs must use the same expectation horizon for E[TFP].
    jh = base_info.settings.j_cj_horizon;
    assert(isequal(jh, alt_info.settings.j_cj_horizon), 'genfig_R23:horizon', ...
        'The two specs use different CJ horizons (%d vs %d).', ...
        jh, alt_info.settings.j_cj_horizon);

    ROWS = {'Home TFP',         'E[TFP]', ...
            'Home Consumption', 'Foreign Consumption', ...
            'Interest Rate Differential'};
    % The optional sixth panel goes last.
    if ~isempty(extra_row); ROWS{end+1} = extra_row; end
    ord = var_order(Db.vnames, ROWS{:});  ord = ord(:);

    % Panel titles: a relabelled copy of the full name list, because plotIRF
    % also uses the list's length as the data offset.
    titles = Db.vnames;
    titles{var_order(Db.vnames, 'E[TFP]')} = sprintf('Expected Home TFP', jh);

    % TFP does not respond to noise by construction: zero it in each run's array.
    dnb = local_zero_tfp(dnb, Db.vnames);
    dna = local_zero_tfp(dna, Da.vnames);

    p = plotIRF;
    p.nrow = 3;  p.ncol = 2;
    % Same canvas and grid as Figure C.7, so the panels are the same size.
    p.position = [1 1 425 400];

    % Technology: baseline blue, overlay a lighter blue.
    p.NOISE   = zeros(1, numel(ord));
    p.overlay = struct('data', dta, 'style','-', 'label', alt_label, ...
                       'baselabel', 'Baseline', ...
                       'color', [0.45 0.62 0.90], 'band', true, ...
                       'bandcolor', [0.62 0.75 0.96]);
    fout(1) = local_export(plotIRF(dtb, ord, titles, [stem 'a'], 1:numel(ord), p), ...
                           fullfile(dest, [stem 'a.pdf']));

    % Noise: baseline red, overlay a lighter red.
    p.NOISE   = ones(1, numel(ord));
    p.overlay = struct('data', dna, 'style','-', 'label', alt_label, ...
                       'baselabel', 'Baseline', ...
                       'color', [0.92 0.50 0.50], 'band', true, ...
                       'bandcolor', [0.97 0.72 0.72]);
    fout(2) = local_export(plotIRF(dnb, ord, titles, [stem 'b'], 1:numel(ord), p), ...
                           fullfile(dest, [stem 'b.pdf']));

    fprintf('  wrote %sa.pdf / %sb.pdf (baseline vs %s)\n', stem, stem, alt_label);
    fprintf('    baseline %s (%d rows)\n    alt      %s (%d rows)\n', nb, ...
            numel(Db.vnames), na, numel(Da.vnames));
end

% -------------------------------------------------------------------------
function d = local_zero_tfp(d, vnames)
%   Set TFP's response to zero in both halves of the column block.
    i  = var_order(vnames, 'Home TFP');
    nv = numel(vnames);
    d(:, [i, i+nv], :) = 0;
end

function f = local_export(f, target)
%   Print the whole 425x400 canvas rather than cropping to content.
    f = f(1);
    set(f, 'Color','w', 'InvertHardcopy','off', 'PaperUnits','points', ...
           'PaperPosition',[0 0 425 400], 'PaperSize',[425 400]);
    print(f, target, '-dpdf', '-r0');
end
