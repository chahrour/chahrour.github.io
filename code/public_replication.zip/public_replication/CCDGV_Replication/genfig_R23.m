function fout = genfig_R23(base_info, alt_info, alt_label, stem, extra_row, dest)
%GENFIG_R23  Figures R.2-R.5 -- CJ responses, baseline against an asset spec.
%
%   fout = GENFIG_R23(base_info, alt_info, alt_label, stem)
%   fout = GENFIG_R23(base_info, alt_info, alt_label, stem, extra_row)
%   fout = GENFIG_R23(base_info, alt_info, alt_label, stem, extra_row, dest)
%
%   base_info   the baseline run, drawn solid with its grey 16-84 bands
%   alt_info    the alternative spec, drawn as a lighter line WITH its own band
%   alt_label   legend text for that spec, e.g. 'w/o FX, w/ Equity Prices'
%   stem        filename stem; writes <stem>a.pdf (technology) and <stem>b.pdf
%               (noise)
%   extra_row   '' (default) leaves the sixth panel empty; a manifest row NAME
%               fills it, beside the interest differential. R.4/R.5 pass 'Real
%               Exchange Rate'. On the no-FX specs of R.2/R.3 the exchange rate
%               is not in the VAR, so the alternative's line there is its
%               PROJECTION -- the VAR's best linear predictor of the real
%               exchange rate (projected NER minus CPIDIFF) -- against the
%               baseline's own, under the run's single projection stage.
%               R.2/R.3 now pass it too, so their sixth panel is the exchange
%               rate rather than blank; R2fx/R3fx are therefore the same figure
%               under a label that spells out that the line is a projection.
%   fout        [technology figure, noise figure]
%
%   R.2 is the equity spec without the exchange rate (inclvar 4), R.3 the yield
%   one (inclvar 9); R.4/R.5 the same blocks with the exchange rate kept in
%   (inclvar 3/8). All against the same baseline, so the figures are read
%   against each other as well as against the solid line inside each.
%
%   FIVE OR SIX PANELS ON A 3x2 GRID:
%       Home TFP                    E_t[TFP_{t+j}]
%       Home Consumption            Foreign Consumption
%       Interest Rate Differential  extra_row, or empty
%   j is the CJ horizon, info.settings.j_cj_horizon (20). E[TFP] is a
%   CONSTRUCTED row -- exact algebra on the VAR state, tfp*B^j -- and the other
%   four are VAR variables in every spec here, so nothing in this figure is a
%   projection. The asset rows are deliberately NOT plotted, nor are the
%   investments. An empty slot is plotIRF's own behaviour for N < nrow*ncol.
%
%   TWO BANDED LINES, WHICH plotIRF DID NOT DO. Its overlay was a line only. The
%   overlay struct now takes .band/.bandcolor/.color, and the patch is drawn
%   before the baseline's line rather than with the overlay's, because a 2-D
%   patch always lands on top of what is already there. Inner band only for the
%   overlay: two full two-band stacks in one panel cannot be read.
%
%   BOTH LINES ARE NAMED. plotIRF's legend used to carry the overlay alone,
%   which left the reader to infer that the other line was the baseline. The
%   overlay's .baselabel names it explicitly.
%
%   TFP DOES NOT RESPOND TO NOISE, so the noise figure's TFP panel is an exact
%   zero for BOTH specs -- point estimate and bands -- as in Figures 3/4 and
%   B.3-B.6. Imposed here, by name, on each spec's array separately.
%
%   See also GENFIG_B14, GENFIG_B7B8, PLOTIRF, GENFIG_R1.

    if nargin < 5; extra_row = ''; end
    assert(nargin >= 6 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end

    [Db, nb] = local_load(base_info);
    [Da, na] = local_load(alt_info);

    % ONE ROW LAYOUT FOR BOTH, ASSERTED. vnames is the manifest's full row list,
    % which does not depend on inclvar -- so the two specs agree unless they
    % predate different manifest versions. plotIRF applies ONE order vector to
    % both the data and the overlay, so a mismatch here would draw one spec's row
    % against another's. GENFIG_B7B8 refuses the same situation for the same
    % reason; remapping instead would paper over a real inconsistency.
    assert(isequal(Da.vnames, Db.vnames), 'genfig_R23:rowMismatch', ...
        ['%s has %d rows against the baseline''s %d -- the runs predate ' ...
         'different manifest versions and cannot be overlaid. Re-run them ' ...
         'against the current manifest.'], na, numel(Da.vnames), numel(Db.vnames));

    % The belief horizon is a setting, so the two specs must share it before
    % their E[TFP] rows can be drawn in one panel -- and the title states it.
    jh = base_info.settings.j_cj_horizon;
    assert(isequal(jh, alt_info.settings.j_cj_horizon), 'genfig_R23:horizon', ...
        'The two specs use different CJ horizons (%d vs %d).', ...
        jh, alt_info.settings.j_cj_horizon);

    ROWS = {'Home TFP',         'E[TFP]', ...
            'Home Consumption', 'Foreign Consumption', ...
            'Interest Rate Differential'};
    % The sixth panel, when asked for: the row goes LAST so the first five keep
    % their positions and the figures stay readable against each other.
    if ~isempty(extra_row); ROWS{end+1} = extra_row; end
    ord = var_order(Db.vnames, ROWS{:});  ord = ord(:);

    % Panel titles. plotIRF reads VARS for its LENGTH (the data offset) and for
    % titles, so a relabelled copy of the full list changes the title only.
    titles = Db.vnames;
    titles{var_order(Db.vnames, 'E[TFP]')} = sprintf('Expected Home TFP', jh);

    [dtb, dnb] = local_pack_run(Db);
    [dta, dna] = local_pack_run(Da);

    % The zero restriction, on each spec's own array.
    dnb = local_zero_tfp(dnb, Db.vnames);
    dna = local_zero_tfp(dna, Da.vnames);

    p = plotIRF;
    p.nrow = 3;  p.ncol = 2;
    % FIGURE B.3'S PANELS, not just its canvas. B.3 is ALSO 3x2 at 425x400 --
    % plotIRF_paper_individual does R = round(N/2) and subplot(R,2,n) on six rows
    % -- so matching the canvas and the grid matches the panel size exactly.
    % local_export repeats the numbers because Position sizes the screen figure
    % and PaperPosition/PaperSize the page.
    %
    % That equality only holds since plotIRF stopped subtracting a flat 0.13 of
    % the figure from every panel to seat the legend: on a 3-row grid that took
    % 55% of each panel's height, which is what made these look squeezed beside
    % B.3 despite the numbers already agreeing. See the legend block there.
    p.position = [1 1 425 400];

    % Technology: baseline blue, overlay a lighter blue.
    p.NOISE   = zeros(1, numel(ord));
    p.overlay = struct('data', dta, 'style','-', 'label', alt_label, ...
                       'baselabel', 'Baseline', ...
                       'color', [0.45 0.62 0.90], 'band', true, ...
                       'bandcolor', [0.62 0.75 0.96]);
    fout(1) = local_export(plotIRF(dtb, ord, titles, [stem 'a'], 1:numel(ord), p), ...
                           fullfile(dest, [stem 'a.pdf']));

    % Noise: baseline red, overlay a lighter red.
    p.NOISE   = ones(1, numel(ord));
    p.overlay = struct('data', dna, 'style','-', 'label', alt_label, ...
                       'baselabel', 'Baseline', ...
                       'color', [0.92 0.50 0.50], 'band', true, ...
                       'bandcolor', [0.97 0.72 0.72]);
    fout(2) = local_export(plotIRF(dnb, ord, titles, [stem 'b'], 1:numel(ord), p), ...
                           fullfile(dest, [stem 'b.pdf']));

    fprintf('  wrote %sa.pdf / %sb.pdf (baseline vs %s)\n', stem, stem, alt_label);
    fprintf('    baseline %s (%d rows)\n    alt      %s (%d rows)\n', nb, ...
            numel(Db.vnames), na, numel(Da.vnames));
end

% -------------------------------------------------------------------------
function [D, nm] = local_load(info)
    [nm, f] = data_name(info);
    assert(isfile(f), 'genfig_R23:noFile', '%s not found', f);
    D = load(f, 'irtfp','irnoise','vnames','point_estimate','bound','bound2');
    % One projection stage, so the run file already holds the only one there is.
end

function [dt, dn] = local_pack_run(D)
    h = (size(D.irtfp,1)-1)/2;
    hgrid = -50:20;  discard = 30;
    dt = pack_bands(cumsum(D.irtfp),   hgrid+h+1, discard, D);
    dn = pack_bands(cumsum(D.irnoise), hgrid+h+1, discard, D);
end


function d = local_zero_tfp(d, vnames)
%   TFP's response to noise is a restriction, not an estimate -- see
%   GENPLOTS_PAPER_PIERRE1:97. Both halves, all five pages.
    i  = var_order(vnames, 'Home TFP');
    nv = numel(vnames);
    d(:, [i, i+nv], :) = 0;
end

function f = local_export(f, target)
%   print, not exportgraphics -- see GENFIG_B9B10's local_export.
    f = f(1);
    set(f, 'Color','w', 'InvertHardcopy','off', 'PaperUnits','points', ...
           'PaperPosition',[0 0 425 400], 'PaperSize',[425 400]);
    print(f, target, '-dpdf', '-r0');
end
