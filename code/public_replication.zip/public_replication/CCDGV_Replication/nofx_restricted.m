function R = nofx_restricted(base_info, nofx_info, opt)
%NOFX_RESTRICTED  The paper's no-FX system, built from a BASELINE run.
%
%   R = NOFX_RESTRICTED(base_info, nofx_info)
%   R = NOFX_RESTRICTED(base_info, nofx_info, opt)   .force, .ndraws, .N, .Ng, .T
%
%   R.irtfp/.irnoise  (2*smax+1) x nrows x ndraws, in the FULL manifest row space
%   R.AR_rs/.Sig_rs   the implied restricted VAR, per draw
%   R.idxV/.idxA      subset indices in the VAR's columns / in A's rows
%   R.meta            what it was built from
%
%   WHAT THIS IS, AND WHY IT IS NOT inclvar = 2. Both describe "the VAR without
%   the exchange rate", but they are different objects:
%
%     inclvar = 2        a 7-variable VAR ESTIMATED on the data. Carries its own
%                        sampling error; answers "what does a no-FX VAR say?"
%     nofx_restricted    the VAR the 8-variable system IMPLIES for those seven
%                        (IMPLIED_RESTRICTED_VAR). Answers "if the baseline is
%                        the truth, what would an econometrician without the
%                        exchange rate recover?"
%
%   The paper uses the second. On identical data they give noise-shock
%   correlations of 0.7743 and 0.7370, which is the whole of the Figure B.11 gap
%   -- the data, the full VAR, smax and the recovery algebra are common to both.
%
%   DEVIATION FROM THE ORIGINAL, DELIBERATE. The restricted VAR is computed in
%   closed form rather than by the original's 2e6-draw simulation. Same object;
%   the simulation left enough Monte Carlo error to move the reported correlation
%   over 0.7720-0.7754 with the seed alone, so the paper's 0.7724 and this 0.7743
%   differ by less than that implementation's own noise. See
%   IMPLIED_RESTRICTED_VAR.
%
%   COST. ~3.7 s per draw, so ~6 min at 1000 draws on ten workers. Cheap, but not
%   free, hence the cache: nothing here runs unless Figure B.11 or B.12 is being
%   made.
%
%   REQUIRES ONLY THE BASELINE RUN. nofx_info is read for its variable list --
%   which columns to drop -- and nothing else; no separate no-FX estimation is
%   involved. Passing one keeps the call symmetric with GENFIG_B11/GENFIG_B12 and
%   makes the equity pair (specs 3 and 4) work with no extra code.
%
%   See also NOFX_BUILD_IRFS, INFER_SHOCKS, GENFIG_B11, GENFIG_B12.

    if nargin < 3; opt = struct(); end

    [nm, f] = data_name(base_info);
    assert(isfile(f), 'nofx_restricted:noBase', ...
           'baseline run %s not found -- run run_sweep first.', f);
    cache = fullfile(fileparts(f), ['nofx_' nm]);

    D = load(f, 'ARs','Sigs','Aproj','keys','vnames','smax','info','data');
    nvars_full = size(D.data,2);
    nlags = size(D.ARs{end},2)/nvars_full;
    jh    = D.info.settings.j_cj_horizon;

    % Every draw on the stored window, the point estimate at full length -- the
    % split run_main saves (smax_store in config). B.12 plots the draws;
    % infer_shocks recovers the disturbances from the point estimate's whole MA.
    hs = D.smax;
    if isfield(D.info.settings,'smax_store'); hs = min(D.smax, D.info.settings.smax_store); end

    % ---- the two index spaces, BY NAME ---------------------------------
    % idxV indexes the VAR's columns (for the simulation and for stacking the
    % data); idxA indexes A's rows (for the spectral embedding). Under the
    % manifest these are different maps that happen to agree for the baseline
    % spec, which is exactly how a positional literal survives testing and then
    % fails on the equity specs.
    base_nms = D.info.inclvarnms;
    sub_nms  = nofx_info.inclvarnms;
    [tf, idxV] = ismember(sub_nms, base_nms);
    assert(all(tf), 'nofx_restricted:notASubset', ...
        'nofx spec has %s, which the baseline spec does not', ...
        strjoin(sub_nms(~tf), ', '));
    [tf, idxA] = ismember(sub_nms, D.keys);
    assert(all(tf), 'nofx_restricted:notInManifest', ...
        '%s is not a manifest data row', strjoin(sub_nms(~tf), ', '));
    idxV = idxV(:)';  idxA = idxA(:)';

    ndraws = getdef(opt, 'ndraws', numel(D.ARs));
    assert(ndraws <= numel(D.ARs), 'nofx_restricted:ndraws', ...
           'asked for %d draws, the run has %d', ndraws, numel(D.ARs));

    % meta is the CACHE KEY, and it has to cover all THREE things that determine
    % the answer. Any one of them alone leaves a way for a stale file to be served
    % as if it were current:
    %
    %   request  the fields below -- which spec, how many draws, which grids
    %   code     the source of every function whose output reaches this file, so
    %            editing the math forces a rebuild
    %   inputs   the baseline run's OWN CONTENTS
    %
    % `base` is only a FILENAME, and run_main writes the same filename every time.
    % Re-estimating the baseline -- a different ndraws, another identification
    % pass, new data -- leaves that name untouched, so without `inputs` the cache
    % matched and B.11/B.12 were drawn from restricted VARs derived from a baseline
    % that no longer existed. Storing the inputs themselves rather than a
    % checksum, for the same reason as `code`: isequaln does the work, there is no
    % hash to trust, and a mismatch can be inspected. ARs and Sigs are ~2 MB
    % against a 226 MB cache.
    meta = struct('base', nm, 'nofx_spec', {sub_nms}, 'smax', D.smax, 'smax_store', hs, ...
                  'ndraws', ndraws, 'j_cj_horizon', jh, ...
                  'idxV', idxV, 'idxA', idxA, ...
                  'N', getdef(opt,'N',25000), 'Ng', getdef(opt,'Ng',2^16), ...
                  'code', sources(DEPS), ...
                  'inputs', struct('ARs',{D.ARs(1:ndraws)}, 'Sigs',{D.Sigs(1:ndraws)}, ...
                                   'Aproj',D.Aproj, 'keys',{D.keys}, 'vnames',{D.vnames}));

    % ---- cache ---------------------------------------------------------
    % Load ONLY meta to decide. The full file is 226 MB and reading it to compare
    % a key threw away most of the time the cache was meant to save.
    if isfile(cache) && ~getdef(opt,'force',false)
        K = load(cache, 'meta');
        if isfield(K,'meta') && isequaln(K.meta, meta)
            fprintf('  nofx_restricted: reusing %s\n', cache);
            R = load(cache);
            return
        end
        if ~isfield(K,'meta'); K.meta = struct(); end
        fprintf('  nofx_restricted: rebuilding -- %s\n', why(K.meta, meta));
    end

    % ---- build ---------------------------------------------------------
    nrows = numel(D.vnames);
    irtfp   = nan(2*hs+1, nrows, ndraws);
    irnoise = nan(2*hs+1, nrows, ndraws);
    AR_rs   = cell(1,ndraws);
    Sig_rs  = cell(1,ndraws);

    % Deterministic throughout -- IMPLIED_RESTRICTED_VAR computes the population
    % projection in closed form, so there is no seed, no stream and nothing to
    % keep reproducible across a parfor. The original reached the same object by
    % simulating 2e6 draws per bootstrap replication, which is where this used to
    % carry RandStream plumbing and where the paper's third decimal came from.
    ARs = D.ARs; Sigs = D.Sigs; Aproj = D.Aproj; keys = D.keys;
    smax = hs; last = numel(ARs);
    fprintf('  nofx_restricted: building %d draws (smax=%d, %d rows)...\n', ...
            ndraws, smax, nrows);
    t0 = tic;
    parfor i = 1:ndraws
        j = i; if i == ndraws; j = last; end   % point estimate is the LAST draw
        AR_un = ARs{j}; Sig_un = Sigs{j};
        A_un  = gen_auxvars(AR_un', Aproj, keys, nvars_full, nlags, jh);

        [ar, sg] = implied_restricted_var(AR_un, Sig_un, idxV);
        [it, in] = nofx_build_irfs(AR_un, Sig_un, A_un, ar, sg, idxA, smax, jh, opt);

        irtfp(:,:,i)  = it;
        irnoise(:,:,i) = in;
        AR_rs{i} = ar;  Sig_rs{i} = sg;
    end
    fprintf('  nofx_restricted: %d draws in %.1f min\n', ndraws, toc(t0)/60);

    if hs < D.smax
        A_un = gen_auxvars(ARs{last}', Aproj, keys, nvars_full, nlags, jh);
        [ar, sg] = implied_restricted_var(ARs{last}, Sigs{last}, idxV);
        [irtfp_pe, irnoise_pe] = nofx_build_irfs(ARs{last}, Sigs{last}, A_un, ...
                                                 ar, sg, idxA, D.smax, jh, opt);
    else
        irtfp_pe = irtfp(:,:,end);  irnoise_pe = irnoise(:,:,end);
    end

    R = struct('irtfp',irtfp, 'irnoise',irnoise, ...
               'irtfp_pe',irtfp_pe, 'irnoise_pe',irnoise_pe, 'AR_rs',{AR_rs}, ...
               'Sig_rs',{Sig_rs}, 'idxV',idxV, 'idxA',idxA, ...
               'vnames',{D.vnames}, 'meta',meta);
    save(cache, '-struct', 'R', '-v7.3');
    fprintf('  nofx_restricted: wrote %s\n', cache);
end

function v = getdef(s, f, d)
    if isfield(s,f); v = s.(f); else; v = d; end
end

% -------------------------------------------------------------------------
function d = DEPS()
%   Every function whose output reaches the cache file. Adding a dependency to
%   the build without adding it here reopens exactly the hole this closes.
    d = {'nofx_restricted', 'implied_restricted_var', 'nofx_build_irfs', ...
         'irfs_from_subset', 'tf_sweep', 'cj_wold', 'cj_cepfactor', 'gen_auxvars'};
end

function S = sources(names)
%   Source text of each function, as a struct keyed by name. Stored verbatim
%   rather than hashed: a few tens of KB against a cache of hundreds of MB, and
%   it means a mismatch can name the file and be diffed, instead of reporting
%   that two checksums differ.
    S = struct();
    for k = 1:numel(names)
        f = which(names{k});
        assert(~isempty(f), 'nofx_restricted:missingDep', ...
               '%s is not on the path', names{k});
        S.(names{k}) = fileread(f);
    end
end

function msg = why(old, new)
%   Say what actually changed, so a surprise rebuild is self-explaining.
%   Checked in the order a reader would want: the run it was built from, then
%   the code, then what was asked for.
    if ~isfield(old,'code') || ~isfield(old,'inputs')
        msg = 'cache predates the current key (no code/inputs stamp)'; return
    end

    ch = {};
    for f = fieldnames(new.inputs)'
        if ~isfield(old.inputs, f{1}) || ~isequaln(old.inputs.(f{1}), new.inputs.(f{1}))
            ch{end+1} = f{1}; %#ok<AGROW>
        end
    end
    if ~isempty(ch)
        msg = sprintf(['the baseline run was re-estimated (%s differ) -- the ' ...
                       'filename is unchanged, the contents are not'], ...
                      strjoin(ch, ', ')); return
    end

    ch = {};
    for f = fieldnames(new.code)'
        if ~isfield(old.code, f{1}) || ~strcmp(old.code.(f{1}), new.code.(f{1}))
            ch{end+1} = f{1}; %#ok<AGROW>
        end
    end
    if ~isempty(ch)
        msg = sprintf('code changed: %s', strjoin(ch, ', ')); return
    end

    ch = {};
    for f = setdiff(fieldnames(new), {'code','inputs'})'
        if ~isfield(old,f{1}) || ~isequaln(old.(f{1}), new.(f{1}))
            ch{end+1} = f{1}; %#ok<AGROW>
        end
    end
    msg = sprintf('request changed: %s', strjoin(ch, ', '));
end
