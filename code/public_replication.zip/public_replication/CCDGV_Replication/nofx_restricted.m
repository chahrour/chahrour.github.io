function R = nofx_restricted(base_info, nofx_info, opt)
%NOFX_RESTRICTED  The no-FX system implied by a baseline run.
%
%   R = NOFX_RESTRICTED(base_info, nofx_info)
%   R = NOFX_RESTRICTED(base_info, nofx_info, opt)
%
%   base_info  descriptor of the baseline run
%   nofx_info  descriptor whose inclvarnms lists the variables to keep; its own
%              run file is not read
%   opt        .force           rebuild even if the cache matches (default false)
%              .ndraws          number of draws to use (default all)
%              .N, .Ng, .ridge  passed to NOFX_BUILD_IRFS
%
%   R.irtfp/.irnoise        (2*hs+1) x nrows x ndraws responses in the full
%                           manifest row space, hs = min(smax, smax_store)
%   R.irtfp_pe/.irnoise_pe  the point estimate's responses on +/-smax
%   R.AR_rs/.Sig_rs         the implied restricted VAR, per draw
%   R.idxV/.idxA            subset indices in the VAR's columns / in A's rows
%   R.vnames, R.meta        row names; what it was built from
%
%   This is the VAR that the full system implies for the subset, computed in
%   closed form by IMPLIED_RESTRICTED_VAR. It is not the VAR re-estimated
%   without the exchange rate, which is a separate specification in sweep.
%
%   The result is cached beside the baseline run as nofx_<run file> and rebuilt
%   when the request, the code or the baseline's estimates change.
%
%   See also IMPLIED_RESTRICTED_VAR, NOFX_BUILD_IRFS, INFER_SHOCKS, GENFIG_C11,
%   GENFIG_C12.

    if nargin < 3; opt = struct(); end

    % Load the baseline run.
    [nm, f] = data_name(base_info);
    assert(isfile(f), 'nofx_restricted:noBase', ...
           'baseline run %s not found -- run run_sweep first.', f);
    cache = fullfile(fileparts(f), ['nofx_' nm]);

    D = load(f, 'ARs','Sigs','Aproj','keys','vnames','smax','info','data');
    nvars_full = size(D.data,2);
    nlags = size(D.ARs{end},2)/nvars_full;
    jh    = D.info.settings.j_cj_horizon;

    % Draws are kept on the stored window (smax_store); the point estimate is
    % kept at full length.
    hs = D.smax;
    if isfield(D.info.settings,'smax_store'); hs = min(D.smax, D.info.settings.smax_store); end

    % Subset indices by name: idxV in the VAR's columns, idxA in A's rows.
    base_nms = D.info.inclvarnms;
    sub_nms  = nofx_info.inclvarnms;
    [tf, idxV] = ismember(sub_nms, base_nms);
    assert(all(tf), 'nofx_restricted:notASubset', ...
        'nofx spec has %s, which the baseline spec does not', ...
        strjoin(sub_nms(~tf), ', '));
    [tf, idxA] = ismember(sub_nms, D.keys);
    assert(all(tf), 'nofx_restricted:notInManifest', ...
        '%s is not a manifest data row', strjoin(sub_nms(~tf), ', '));
    idxV = idxV(:)';  idxA = idxA(:)';

    ndraws = getdef(opt, 'ndraws', numel(D.ARs));
    assert(ndraws <= numel(D.ARs), 'nofx_restricted:ndraws', ...
           'asked for %d draws, the run has %d', ndraws, numel(D.ARs));

    % meta is the cache key: the request, the source of every function that
    % feeds the result, and the baseline's own estimates. The estimates are
    % included because the file name does not change when the baseline is
    % re-estimated.
    meta = struct('base', nm, 'nofx_spec', {sub_nms}, 'smax', D.smax, 'smax_store', hs, ...
                  'ndraws', ndraws, 'j_cj_horizon', jh, ...
                  'idxV', idxV, 'idxA', idxA, ...
                  'N', getdef(opt,'N',25000), 'Ng', getdef(opt,'Ng',2^16), ...
                  'code', sources(DEPS), ...
                  'inputs', struct('ARs',{D.ARs(1:ndraws)}, 'Sigs',{D.Sigs(1:ndraws)}, ...
                                   'Aproj',D.Aproj, 'keys',{D.keys}, 'vnames',{D.vnames}));

    % Reuse the cache if its meta matches. Only meta is loaded to decide.
    if isfile(cache) && ~getdef(opt,'force',false)
        K = load(cache, 'meta');
        if isfield(K,'meta') && isequaln(K.meta, meta)
            fprintf('  nofx_restricted: reusing %s\n', cache);
            R = load(cache);
            return
        end
        if ~isfield(K,'meta'); K.meta = struct(); end
        fprintf('  nofx_restricted: rebuilding -- %s\n', why(K.meta, meta));
    end

    % Build the restricted system draw by draw.
    nrows = numel(D.vnames);
    irtfp   = nan(2*hs+1, nrows, ndraws);
    irnoise = nan(2*hs+1, nrows, ndraws);
    AR_rs   = cell(1,ndraws);
    Sig_rs  = cell(1,ndraws);

    % The build is deterministic: it uses no random numbers.
    ARs = D.ARs; Sigs = D.Sigs; Aproj = D.Aproj; keys = D.keys;
    smax = hs; last = numel(ARs);
    fprintf('  nofx_restricted: building %d draws (smax=%d, %d rows)...\n', ...
            ndraws, smax, nrows);
    t0 = tic;
    parfor i = 1:ndraws
        j = i; if i == ndraws; j = last; end   % the point estimate is the last draw
        AR_un = ARs{j}; Sig_un = Sigs{j};
        A_un  = gen_auxvars(AR_un', Aproj, keys, nvars_full, nlags, jh);

        [ar, sg] = implied_restricted_var(AR_un, Sig_un, idxV);
        [it, in] = nofx_build_irfs(AR_un, Sig_un, A_un, ar, sg, idxA, smax, jh, opt);

        irtfp(:,:,i)  = it;
        irnoise(:,:,i) = in;
        AR_rs{i} = ar;  Sig_rs{i} = sg;
    end
    fprintf('  nofx_restricted: %d draws in %.1f min\n', ndraws, toc(t0)/60);

    % The point estimate at full length, when the stored window is shorter.
    if hs < D.smax
        A_un = gen_auxvars(ARs{last}', Aproj, keys, nvars_full, nlags, jh);
        [ar, sg] = implied_restricted_var(ARs{last}, Sigs{last}, idxV);
        [irtfp_pe, irnoise_pe] = nofx_build_irfs(ARs{last}, Sigs{last}, A_un, ...
                                                 ar, sg, idxA, D.smax, jh, opt);
    else
        irtfp_pe = irtfp(:,:,end);  irnoise_pe = irnoise(:,:,end);
    end

    R = struct('irtfp',irtfp, 'irnoise',irnoise, ...
               'irtfp_pe',irtfp_pe, 'irnoise_pe',irnoise_pe, 'AR_rs',{AR_rs}, ...
               'Sig_rs',{Sig_rs}, 'idxV',idxV, 'idxA',idxA, ...
               'vnames',{D.vnames}, 'meta',meta);
    save(cache, '-struct', 'R', '-v7.3', '-nocompression');
    fprintf('  nofx_restricted: wrote %s\n', cache);
end

function v = getdef(s, f, d)
    if isfield(s,f); v = s.(f); else; v = d; end
end

function d = DEPS()
%   Functions whose output reaches the cache file. Their source is part of the
%   cache key.
    d = {'nofx_restricted', 'implied_restricted_var', 'nofx_build_irfs', ...
         'irfs_from_subset', 'tf_sweep', 'cj_wold', 'cj_cepfactor', 'gen_auxvars'};
end

function S = sources(names)
%   Code of each function, as a struct keyed by name. Blank lines and lines
%   that are only a comment are left out, so editing a comment does not
%   invalidate the cache.
    S = struct();
    for k = 1:numel(names)
        f = which(names{k});
        assert(~isempty(f), 'nofx_restricted:missingDep', ...
               '%s is not on the path', names{k});
        L = strtrim(regexp(fileread(f), '\r?\n', 'split'));
        L = L(~cellfun(@isempty, L) & ~startsWith(L, '%'));
        S.(names{k}) = strjoin(L, newline);
    end
end

function msg = why(old, new)
%   Say what changed between two cache keys: the baseline's estimates, then
%   the code, then the request.
    if ~isfield(old,'code') || ~isfield(old,'inputs')
        msg = 'cache predates the current key (no code/inputs stamp)'; return
    end

    ch = {};
    for f = fieldnames(new.inputs)'
        if ~isfield(old.inputs, f{1}) || ~isequaln(old.inputs.(f{1}), new.inputs.(f{1}))
            ch{end+1} = f{1}; %#ok<AGROW>
        end
    end
    if ~isempty(ch)
        msg = sprintf(['the baseline run was re-estimated (%s differ) -- the ' ...
                       'filename is unchanged, the contents are not'], ...
                      strjoin(ch, ', ')); return
    end

    ch = {};
    for f = fieldnames(new.code)'
        if ~isfield(old.code, f{1}) || ~strcmp(old.code.(f{1}), new.code.(f{1}))
            ch{end+1} = f{1}; %#ok<AGROW>
        end
    end
    if ~isempty(ch)
        msg = sprintf('code changed: %s', strjoin(ch, ', ')); return
    end

    ch = {};
    for f = setdiff(fieldnames(new), {'code','inputs'})'
        if ~isfield(old,f{1}) || ~isequaln(old.(f{1}), new.(f{1}))
            ch{end+1} = f{1}; %#ok<AGROW>
        end
    end
    msg = sprintf('request changed: %s', strjoin(ch, ', '));
end
