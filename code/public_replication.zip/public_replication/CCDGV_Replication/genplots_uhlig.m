function genplots_uhlig(datafile, outdir, name)
%GENPLOTS_UHLIG  Figures 1 and C.1: responses to the main exchange rate shock.
%
%   genplots_uhlig(datafile, outdir, name)
%
%   datafile  a run .mat written by estimate_one
%   outdir    where to write the PDF
%   name      file stem: 'Figure1', or 'FigureC1' for the extended sample
%
%   Also prints the shock's variance decomposition to the console.

    assert(nargin == 3, 'genplots_uhlig:args', ...
        'needs a run file, an output directory and a file stem.');
    assert(isfile(datafile), 'genplots_uhlig:noFile', '%s not found.', datafile);
    % This generator adopts the current figure, so start with none open.
    close all
    load(datafile);                                     %#ok<LOAD>

% vnames_short is saved in the run file, with the same length and order as vnames.
if ~exist('vnames_short','var') || numel(vnames_short) ~= numel(vnames)
    error('genplots_uhlig:noShort', ...
          ['this run has no vnames_short (or it is the wrong length). ' ...
           'Re-run estimate_one: it is saved with the data stage.']);
end


% Panel order, resolved by name.
order   = var_order(vnames,...
    'Home Consumption', 'Foreign Consumption', ...
    'Home Investment',  'Foreign Investment', ...
    'Interest Rate Differential','Real Exchange Rate', ...
    'Expected Excess Returns', 'Home TFP');

% Draw the figure and export it.
f = local_plot_uhlig(dataplots, order, vnames_short, nplot, confidence_bands);
  
    exportgraphics(f, fullfile(outdir, [name '.pdf']));

% Rows of the variance decomposition, resolved by name.
order_vdec = var_order(vnames, ...
    'Home TFP', 'Home Consumption', 'Foreign Consumption', ...
    'Home Investment', 'Foreign Investment', ...
    'Interest Rate Differential', 'Real Exchange Rate', ...
    'Expected Excess Returns', '$\Delta q_t$');

% Print the variance decomposition: unconditional shares, then by horizon.
vdec   = dataplots;
vdec_m = vdec(vd_feh,order_vdec,1);
if point_estimate == 0
    vdec_um = median(vardec_fd(order_vdec,:,:),3); % median across draws
elseif point_estimate == 1
    vdec_um = vardec_fd(order_vdec,:,end);
end

for jj = 1:length(order_vdec)
    st = [pad(vnames{order_vdec(jj)},28), ' & ', num2str(vdec_um(jj,:),' %0.2f &'), '    ' num2str(vdec_m(:,jj)',' %0.2f &')];
    disp(st(1:end-2));
end

% =========================================================================
function fout = local_plot_uhlig(data, order, vars, nplot, confidence_bands)
%LOCAL_PLOT_UHLIG  The 2x4 panel grid of Figures 1 and C.1.
%
%   Posterior median in blue over a 68% band, with a 90% band underneath when
%   confidence_bands is 2. The data are read from column nvars+order(n), the
%   second half of the column block. Row 1 is the impact response, drawn at
%   horizon 0.

if nargin<5
    [nplot,~,~]=size(data);
end

[~,nvars]=size(vars);

N = size(order,1);
nfig = size(order,2);
h = (0:nplot-1)';             % horizons

R=2;
fout = gobjects(1,nfig);
for ff = 1:nfig
    fout(ff) = figure;
    set(gcf, 'Position', [1 1 4/3*550 4/3*550/3]);

    gg = zeros(1,N);
    for n=1:N
        gg(n) =  subplot(R,4,n);
        if ndims(data)==3   % bands, if the data have them
            if confidence_bands == 2 % 90% band
                grpyat = [h data(1:nplot,nvars+order(n,ff),4); flipud(h) data(nplot:-1:1,nvars+order(n,ff),5)];
                patch(grpyat(:,1),grpyat(:,2),[0.9 0.9 0.9],'edgecolor',[0.9 0.9 0.9]);
            end
            % 68% band
            grpyat = [h data(1:nplot,nvars+order(n,ff),2); flipud(h) data(nplot:-1:1,nvars+order(n,ff),3)];
            patch(grpyat(:,1),grpyat(:,2),[0.7 0.7 0.7],'edgecolor',[0.7 0.7 0.7]);
        end
        hold on;
        plot(h,data(1:nplot,nvars+order(n,ff),1),'b','LineWidth',2);
        plot(h,zeros(nplot,1),'--k','linewidth',0.5);         % zero line
        title(vars{order(n,ff)},'FontSize',10,'Interpreter','latex')
        if n == 1 || n == 5
            ylabel('percent','FontSize',8,'Interpreter','latex')
        end
        set(gca,'TickLabelInterpreter','latex')
        ax = gca;
        ax.FontSize =   8;        % tick label font size
        axis tight
        hold off; grid on
    end
    if size(order,2) == 3
        pos = get(gg,'Position');
        new = mean(cellfun(@(v)v(1),pos(1:2)));
        set(gg(3),'Position',[new,pos{end}(2:end)])
    end
end
