function genplots_uhlig(datafile, outdir)
%GENPLOTS_UHLIG  Figure 1: impulse responses to the main exchange rate shock.
%
%   genplots_uhlig(datafile, outdir)
%
%   datafile  a run .mat written by estimate_one
%   outdir    where to write uhlig_resubmit.pdf
%
%   Both arguments are required, which is what lets the extended-sample appendix
%   call this a second time with a different run file and a different directory.

    assert(nargin == 2, 'genplots_uhlig:args', ...
        'needs a run file and an output directory.');
    assert(isfile(datafile), 'genplots_uhlig:noFile', '%s not found.', datafile);
    % Start from a clean figure state. This generator adopts whatever figure is
    % current, so without this it draws a different Figure 1 when something else
    % has plotted earlier in the same session.
    close all
    load(datafile);                                     %#ok<LOAD>

% vnames_short comes FROM THE RUN FILE (loaded above): run_main builds it from
% ccdgv_manifest's `short` field, so it is the same length and order as vnames by
% construction. Never rebuild it here -- a hand-kept copy indexed by `order` is
% exactly what mislabelled three panels of Figure 1 when the row count grew.
if ~exist('vnames_short','var') || numel(vnames_short) ~= numel(vnames)
    error('genplots_uhlig:noShort', ...
          ['this run has no vnames_short (or it is the wrong length). ' ...
           'Re-run run_main: it is saved with the data stage.']);
end

% ONE RUN ONLY -- whatever `datafile` names, which is the G6 aggregate.
%
% a `country_median` flag selecting a second branch that
% loaded uhlig_country_1..6.mat, took dataplots(vd_feh,order_vdec,1) from each
% and medianed across the six -- the "typical country" version of the table
% below. Nothing ever set the flag to 1, and the six .mat files it read were
% Apr-2024 orig-core runs predating the manifest, so order_vdec resolved by name
% against the current layout would have indexed their old row set.
%
% THE STATISTIC SURVIVES, correctly: it is Panel C of Tables B.6/B.7
% (write_alt_tables, local_medcat), which reads the live descriptors in
% sweep_infos.country instead of frozen snapshots and so works on either data
% core. Same median-of-medians definition -- each country's own median across
% draws, then the median of those six.

%--command to get variables in the order we want to plot, based on
%vnames list
order   = var_order(vnames,...
    'Home Consumption', 'Foreign Consumption', ...
    'Home Investment',  'Foreign Investment', ...
    'Interest Rate Differential','Real Exchange Rate', ...
    'Expected Excess Returns', 'Home TFP');

%--figure for revised paper
f = local_plot_uhlig(dataplots, order, vnames_short, nplot, confidence_bands);
  
%--save clean pdf of figure
    exportgraphics(f, fullfile(outdir, 'uhlig_resubmit.pdf'));

% Derived by name, like `order` above. run_main used to save
% order_vdec = [1,2,6,3,8,12,15,11,18] -- positions into a 26-row vnames.
% Decoded against that layout they mean the nine names below; against the
% current 28-row layout the same numbers select different variables.
order_vdec = var_order(vnames, ...
    'Home TFP', 'Home Consumption', 'Foreign Consumption', ...
    'Home Investment', 'Foreign Investment', ...
    'Interest Rate Differential', 'Real Exchange Rate', ...
    'Expected Excess Returns', '$\Delta q_t$');

%--variance decomposition table
vdec   = dataplots;
vdec_m = vdec(vd_feh,order_vdec,1);
if point_estimate == 0
    vdec_um = median(vardec_fd(order_vdec,:,:),3); %median unconditional
elseif point_estimate == 1
    vdec_um = vardec_fd(order_vdec,:,end);
end

for jj = 1:length(order_vdec)
    st = [pad(vnames{order_vdec(jj)},28), ' & ', num2str(vdec_um(jj,:),' %0.2f &'), '    ' num2str(vdec_m(:,jj)',' %0.2f &')];
    disp(st(1:end-2));
end

% =========================================================================
function fout = local_plot_uhlig(data, order, vars, nplot, confidence_bands)
%LOCAL_PLOT_UHLIG  The Uhlig panel grid for Figures 1 and B.1.
%
%   Two rows of four panels: the posterior median in blue over a 68% band, and a
%   90% band underneath it when confidence_bands is 2. It reads column
%   nvars+order(n), i.e. the SECOND half of the block, which is why the packing
%   step writes both halves identically.
%
%   PRIVATE TO THIS FILE. It was a top-level plotIRFresubmit with exactly one
%   caller -- this one -- and a header line that read "%plotIRF.m", naming a
%   different function.

if nargin<5
    [nplot,~,~]=size(data);
end

[~,nvars]=size(vars);

N = size(order,1);
nfig = size(order,2);

R=2;
% R=round(N/2);
fout = gobjects(1,nfig);
for ff = 1:nfig
    % h=figure('Color',[0.9412 0.9412 0.9412],'Position',[1 1 550 400],'Name',Title);
    % figure(h);
    fout(ff) = figure;
    set(gcf, 'Position', [1 1 4/3*550 4/3*550/3]); % width=7in, height=3in
    % Removed 2026-08-04: a leftover tiledlayout(2,4) placeholder that drew eight
    % panels of rand(10,1) titled 'Panel 1'..'Panel 8' before the real loop. It
    % never reached the output -- the subplot() calls below destroy both the
    % placeholder axes and the layout object -- but only because the placeholder
    % grid and the real grid are both 2x4. With any other panel count the random
    % panels would have printed into the figure. Verified: figure unchanged
    % pixel-for-pixel after removal.

    gg = zeros(1,N);
    for n=1:N
        gg(n) =  subplot(R,4,n);
        if ndims(data)==3   %if available, plot confidence bands
            if confidence_bands == 2 %- 90% bounds
                grpyat = [(1:nplot)' data(1:nplot,nvars+order(n,ff),4); (nplot:-1:1)' data(nplot:-1:1,nvars+order(n,ff),5)];
                patch(grpyat(:,1),grpyat(:,2),[0.9 0.9 0.9],'edgecolor',[0.9 0.9 0.9]); %[0.85 0.85 0.85]
            end
            %- 68% bounds
            grpyat = [(1:nplot)' data(1:nplot,nvars+order(n,ff),2); (nplot:-1:1)' data(nplot:-1:1,nvars+order(n,ff),3)];
            patch(grpyat(:,1),grpyat(:,2),[0.7 0.7 0.7],'edgecolor',[0.7 0.7 0.7]); %[0.65 0.65 0.65]
        end
        hold on;
        plot(1:nplot,data(1:nplot,nvars+order(n,ff),1),'b','LineWidth',2);
        plot(1:nplot,zeros(1,nplot),'--k','linewidth',0.5);   % 1 x nplot: one line, not nplot
        title(vars{order(n,ff)},'FontSize',10,'Interpreter','latex') %'FontWeight','bold',
        if n == 1 || n == 5
            ylabel('percent','FontSize',8,'Interpreter','latex')
        end
        set(gca,'TickLabelInterpreter','latex')
        ax = gca;                % get current axes
        ax.FontSize =   8;        % change tick label font size
        %xlabel('quarters','FontSize',12,'Interpreter','latex')
        axis tight
        %                                   axis([0 nimp ylow(n) yhigh(n) ]);
        hold off; grid on
    end
    if size(order,2) == 3
        pos = get(gg,'Position');
        new = mean(cellfun(@(v)v(1),pos(1:2)));
        set(gg(3),'Position',[new,pos{end}(2:end)])
    end
end
