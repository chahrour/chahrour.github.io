function fout = genfig_B11(base_info, nofx_info, dest)
%GENFIG_B11  Figure B.11 -- estimated technology and noise disturbance series.
%   fout = GENFIG_B11(base_info, nofx_info)
%   fout = GENFIG_B11(base_info, nofx_info, dest)
%
%   THE DASHED LINE IS THE PAPER'S NO-FX OBJECT: the VAR the baseline IMPLIES for
%   those seven variables (NOFX_RESTRICTED), not the re-estimated no-FX run. Slow
%   the first time, cached after. There is no option for the other construction,
%   because the draft plots only this one.
%
%   Two stacked panels over time: the CJ technology disturbances (top) and noise
%   disturbances (bottom), from the BASELINE run (grey solid) and the NO-FX run
%   (black dashed) -- the draft's "Baseline" / "VAR w/o Exchange Rate".
%
%   Takes INFOS, not filenames, like genfig_B12: the paths come from data_name so
%   changing a spec in sweep propagates with nothing to retype.
%
%   NOT a plotIRF figure. plotIRF draws impulse responses on a -20:20 shock-time
%   axis; this is a calendar-time series, so it is drawn directly. The styling
%   (grey solid / black dashed, legend centred below) matches the other exhibits.
%
%   THE SHOCKS ARE THE CJ DISTURBANCES, recovered by infer_shocks from the
%   two-sided MA of TFP and E_t[TFP_{t+j}] -- NOT genmaxshare_final's max-share
%   shocks, which are a different identification. See infer_shocks.
%
%   REPLACES the manual shock_extract workflow: run it once per dataset with a
%   different `load` uncommented, rename the results in place, load the other
%   over the top, plot. Every save that would have made that reproducible was
%   commented out, so the figure could not be rebuilt from the repository.
%
%   See also INFER_SHOCKS, GENFIG_B12, DATA_NAME.

    assert(nargin >= 3 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end
    B = infer_shocks(base_info);
    % BASE_INFO, not nofx_info. The shock is identified without the exchange rate
    % and the implied restricted system supplies the series -- see NOFX_RESTRICTED.
    N = infer_shocks(base_info, struct('restricted',true, 'nofx_info',nofx_info));

    % Align on shared dates rather than assuming equal length: the two specs can
    % lose different numbers of rows to the VAR-column NaN mask.
    [d, ib, in] = intersect(round(B.dates*4)/4, round(N.dates*4)/4);
    assert(numel(d) > 8, 'genfig_B11:noOverlap', ...
        'the two runs share only %d quarters', numel(d));
    if numel(d) < numel(B.dates) || numel(d) < numel(N.dates)
        fprintf('  B.11: plotting %d shared quarters (base %d, noFX %d)\n', ...
                numel(d), numel(B.dates), numel(N.dates));
    end

    % ---- STYLING TAKEN FROM THE ORIGINAL, not eyeballed --------------------
    % shock_extract.m:265-288 specifies all of it: figure 425x300 on white,
    % subplot(2,1,k) default spacing, grey [0.5 0.5 0.5] solid vs black dashed at
    % linewidth 2, latex ylabels at 12pt, `axis tight` (so the y-range is the
    % data's, NOT symmetric), grid on, and a legend at 12pt with an explicit
    % normalized Position. Reproduced here rather than re-derived.
    %
    % Caveat: the draft was produced on an older MATLAB, so subplot's default
    % spacing and the legend's fitted extent may differ slightly from what that
    % release gave. The numbers below are the original's; any residual gap is a
    % renderer difference, not a choice made here.
    PANEL = {'Technology', B.ehat_tfp(ib),   N.ehat_tfp(in); ...
             'Noise',      B.ehat_noise(ib), N.ehat_noise(in)};

    fout = figure('Color',[1 1 1], 'Position',[1 1 425 300], 'Name','shock_series_new');

    axk = gobjects(1,2);
    for k = 1:2
        axk(k) = subplot(2,1,k);
        plot(d, PANEL{k,2}, '-',  'color',[0.5, 0.5, 0.5], 'linewidth',2);
        ylabel(PANEL{k,1}, 'FontWeight','Normal','Interpreter','latex','Fontsize',12);
        hold on
        plot(d, PANEL{k,3}, '--', 'color',[0, 0, 0], 'linewidth',2);
        zl = plot(d, zeros(numel(d),1), '--k');
        zl.Annotation.LegendInformation.IconDisplayStyle = 'off';
        grid on;
        axis tight;
        set(gca,'TickLabelInterpreter','latex')
    end

    % Close the inter-panel gap. This is the ONE deviation from the original's
    % settings, and it compensates for a renderer change rather than restyling:
    % subplot(2,1,k)'s default vertical spacing is wider in this MATLAB than in
    % the release that produced the draft, so the same code yields panels further
    % apart. Grow each panel downward into the gap, leaving the legend strip.
    GAP = 0.055;                       % target gap, matched to the draft
    top = axk(1).Position;  bot = axk(2).Position;
    cur = top(2) - (bot(2) + bot(4));  % current gap
    if cur > GAP
        grow = (cur - GAP)/2;
        axk(1).Position(2) = top(2) - grow;   axk(1).Position(4) = top(4) + grow;
        axk(2).Position(4) = bot(4) + grow;
    end

    legend('Baseline','VAR w/o Exchange Rate', 'location','southeast', ...
           'interpreter','latex', 'box','off', 'orientation','horizontal', ...
           'fontsize',12, ...
           'Position',[0.313868720190872 0.0100553042892664 ...
                       0.350416994094849 0.0438095240365891]);

    % PRINT, not exportgraphics, and for the same reason as GENFIG_B9B10: the
    % figure is built at 425x300 to match the draft (shock_series.eps has a
    % 359x276 content box inside that canvas), but exportgraphics tight-crops to
    % the drawn content and wrote 276x211. Scaled back up to full width in the
    % inventory that thickens every line, which is what made these look heavy
    % against the draft. Printing the whole canvas keeps the line weight right.
    set(fout, 'InvertHardcopy','off', 'PaperUnits','points', ...
              'PaperPosition',[0 0 425 300], 'PaperSize',[425 300]);
    print(fout, fullfile(dest, 'shock_series_new.pdf'), '-dpdf', '-r0');
    fprintf('  wrote shock_series_new.pdf (Figure B.11)\n');
    fprintf('    baseline %s\n    no-FX    %s [%s]\n', ...
            data_name(base_info), data_name(nofx_info), N.meta.system);
    fprintf('    corr(base,noFX): technology %.4f, noise %.4f\n', ...
            corr(PANEL{1,2},PANEL{1,3}), corr(PANEL{2,2},PANEL{2,3}));
end
