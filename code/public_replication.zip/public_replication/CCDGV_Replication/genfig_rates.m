function fout = genfig_rates(base_info, dest)
%GENFIG_RATES  Figure R6: responses of US and G6 real short-term interest rates.
%
%   fout = GENFIG_RATES(base_info, dest)
%
%   base_info  descriptor of the baseline run
%   dest       output directory (required)
%   fout       [technology figure, noise figure]
%
%   Three panels, 1x3, in each figure:
%       Home Real Interest Rate   Foreign Real Interest Rate   Interest Rate Differential
%   Real rates are ex ante: the nominal 3-month rate less the inflation the VAR
%   expects over the next quarter. The US nominal rate and CPI are projected on
%   the VAR's state. The G6 real rate is the US real rate minus the real
%   differential, so the three panels add up in every draw. Rates are drawn
%   annualized, in percentage points.
%
%   See also GENFIG_ASSET_PROJ, GEN_AUXVARS, PLOTIRF.

    assert(nargin >= 2 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~isfolder(dest); mkdir(dest); end

    [nm, f] = data_name(base_info);
    assert(isfile(f), 'genfig_rates:noFile', '%s not found', f);
    D = load(f, 'irtfp','irnoise','vnames','point_estimate','bound','bound2', ...
                'r2','nobs','info');

    % The two US rows must be projected, not variables of the VAR.
    for nmrow = {'US 3-M Interest Rate', 'US CPI'}
        assert(any(strcmp(D.vnames, nmrow{1})), 'genfig_rates:noRow', ...
            '%s has no "%s" row -- re-run estimate_one on this branch', nm, nmrow{1});
        i = var_order(D.vnames, nmrow{1});
        assert(abs(D.r2(i) - 1) >= 1e-8, 'genfig_rates:inVAR', ...
            '%s is in the VAR of %s; pass the baseline run', nmrow{1}, nm);
    end

    ROWS = {'US Real Interest Rate', 'G6 Real Interest Rate', 'Interest Rate Differential'};
    ord  = var_order(D.vnames, ROWS{:});  ord = ord(:);

    % Panel titles say home and foreign, as in Figures 2-4.
    ttl = D.vnames;
    ttl(ord(1:2)) = {'Home Real Interest Rate', 'Foreign Real Interest Rate'};

    % Cumulate, take horizons -50:20 and discard the first 30, leaving -20:20.
    h   = (size(D.irtfp,1)-1)/2;
    win = (-50:20) + h + 1;
    dt  = pack_bands(cumsum(D.irtfp),   win, 30, D);
    dn  = pack_bands(cumsum(D.irnoise), win, 30, D);

    % One row, at the panel size of the 2x3 figures.
    prefs = plotIRF;
    prefs.rates = rate_rows(D.vnames);
    prefs.nrow = 1;  prefs.ncol = 3;
    prefs.position(4) = prefs.position(4)/2;
    [f1, prefs] = plotIRF(dt, ord, ttl, 'R6a', 1:numel(ord), prefs);
    exportgraphics(f1(1), fullfile(dest, 'R6a.pdf'));
    prefs.NOISE = 1;
    f2 = plotIRF(dn, ord, ttl, 'R6b', 1:numel(ord), prefs);
    exportgraphics(f2(1), fullfile(dest, 'R6b.pdf'));
    fout = [f1(1), f2(1)];

    fprintf('  wrote R6a.pdf / R6b.pdf\n');
    for k = var_order(D.vnames, 'US 3-M Interest Rate', 'US CPI')'
        fprintf('    %-22s R2 %.3f over %d quarters\n', D.vnames{k}, D.r2(k), D.nobs(k));
    end
end
