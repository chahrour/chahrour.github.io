function T = gen_tradingstrategy(data, dates, info)
%GEN_TRADINGSTRATEGY  Out-of-sample VAR-based currency strategy (Table C.9).
%
%   T = GEN_TRADINGSTRATEGY(data, dates, info)
%
%   data   TT x nvars matrix the run's VAR was fit on
%   dates  TT x 1 fractional-year dates; must be consecutive quarters
%   info   the run's descriptor: window lengths in info.trade_windows,
%          estimation settings in info.settings
%
%   For each window length N and each forecast origin t = N..TT-1:
%     1. re-estimate the VAR on rows t-N+1..t with genvars;
%     2. for every posterior draw, form E_t(lambda_{t+1}), the expected excess
%        return on foreign currency, conditional on current and past TFP and
%        E_t TFP_{t+j}, j = j_cj_horizon, using a steady-state Kalman filter
%        over the window;
%     3. hold a position equal to the median across draws of E_t(lambda_{t+1})
%        and earn it times the realised
%        lambda_{t+1} = ner_{t+1} - ner_t - idiff_t.
%   Negative positions are long the dollar. The point estimate that genvars
%   appends (element ndraws+1) is not used.
%
%   T (struct)
%     windows   1 x K  window lengths N, quarters
%     sr        K x 1  annualised Sharpe ratio, 2*mean(pf)/std(pf)
%     ret       K x 1  annualised mean portfolio return, 4*mean(pf)
%     nobs      K x 1  portfolio returns per window length, TT - N
%     origin    1 x K  cell; forecast-origin dates t
%     elam      1 x K  cell; median across draws of E_t(lambda_{t+1})
%     lam       1 x K  cell; realised lambda_{t+1}
%     sample    [first last] date of the data
%     ndraws, j_cj_horizon, nlags
%
%   run_main calls this when info.trade_windows is non-empty and saves the
%   result as `trading`; write_trading_table formats it.
%
%   See also RUN_MAIN, GENVARS, WRITE_TRADING_TABLE.

S       = info.settings;
W       = info.trade_windows(:)';
nlags   = S.nlags;
ndraws  = S.ndraws;
jh      = S.j_cj_horizon;

% Levels specifications only: with a transform, the estimated basis is not `data`.
assert(~S.has_transform, 'gen_tradingstrategy:transform', ...
    'spec %d estimates on a transformed basis; the strategy is defined on levels specs only.', ...
    info.inclvar);

% Columns by name: the filter observes TFP; the return uses NER and IDIFF.
ix = var_order(info.inclvarnms, 'tfp', 'ner', 'idiff');

[TT, nv] = size(data);
dates = dates(:);
assert(numel(dates) == TT, 'gen_tradingstrategy:dates', ...
    '%d dates for %d rows of data.', numel(dates), TT);
% A rolling window needs consecutive quarters.
assert(all(abs(diff(dates) - 0.25) < 1e-6), 'gen_tradingstrategy:gap', ...
    'the sample is not consecutive quarters; a rolling window is undefined over a gap.');
assert(max(W) <= TT - 2, 'gen_tradingstrategy:short', ...
    'window %d leaves fewer than 2 forecasts in a %d-quarter sample.', max(W), TT);

K = numel(W);
T = struct('windows',W, 'sr',NaN(K,1), 'ret',NaN(K,1), 'nobs',NaN(K,1), ...
           'origin',{cell(1,K)}, 'elam',{cell(1,K)}, 'lam',{cell(1,K)}, ...
           'sample',[dates(1) dates(end)], 'ndraws',ndraws, ...
           'j_cj_horizon',jh, 'nlags',nlags);

fprintf('  trading strategy: %d window lengths, %d re-estimations, %d draws each\n', ...
        K, sum(TT - W), ndraws);
t0 = tic;
for k = 1:K
    N  = W(k);
    nw = TT - N;                 % forecast origins t = N..TT-1
    elam = NaN(nw,1);
    lam  = NaN(nw,1);
    parfor w = 1:nw
        % Re-estimate the VAR on the window ending at origin t = w+N-1.
        Yw = data(w:w+N-1, :);
        [ARs, Sigs] = genvars(Yw, info);
        assert(numel(ARs) == ndraws + 1, 'gen_tradingstrategy:draws', ...
            'genvars returned %d elements, expected %d draws + 1.', numel(ARs), ndraws);
        % Expected excess return for each draw; the position is the median.
        e = NaN(ndraws,1);
        for d = 1:ndraws
            e(d) = exret_kf(ARs{d}, Sigs{d}, Yw, ix, nlags, jh);
        end
        elam(w) = median(e);
        % Realised excess return from t to t+1.
        t = w + N - 1;
        lam(w) = data(t+1,ix(2)) - data(t,ix(2)) - data(t,ix(3));
    end
    % Portfolio returns and their annualised Sharpe ratio and mean.
    pf = elam .* lam;
    T.sr(k)     = 2*mean(pf) / std(pf);
    T.ret(k)    = 4*mean(pf);
    T.nobs(k)   = nw;
    T.origin{k} = dates(N:TT-1);
    T.elam{k}   = elam;
    T.lam{k}    = lam;
    fprintf('  N = %3d: %3d forecasts, Sharpe %6.2f, return %6.2f   (%.1f min)\n', ...
            N, nw, T.sr(k), T.ret(k), toc(t0)/60);
end
end

function e = exret_kf(AR, Sig, Y, ix, nlags, jh)
%EXRET_KF  E_t(lambda_{t+1}) at the window's last quarter, for one draw.
%
%   The investor observes z_t = [TFP_t; E_t TFP_{t+jh}], both linear in the
%   companion state, and filters the state with the steady-state Kalman gain.
%   Data are demeaned over the window; the window's mean excess return is added
%   back at the end. ix = [tfp ner idiff] column positions.

nv = size(Y,2);
nx = nv*nlags;
B  = [AR; eye(nx-nv), zeros(nx-nv,nv)];      % companion form
SigC = zeros(nx);  SigC(1:nv,1:nv) = Sig;    % state noise: shocks hit block 1 only

etfp = zeros(1,nx);  etfp(ix(1)) = 1;
M    = [etfp; etfp*B^jh];                    % TFP_t and E_t TFP_{t+jh}

mY    = mean(Y,1);
mexr  = mean(diff(Y(:,ix(2)))) - mY(ix(3));  % window mean of lambda
Yd    = Y - mY;

% Companion state at t = nlags..end: [y_t, y_{t-1}, ..., y_{t-nlags+1}]
Tw = size(Yd,1);
X  = zeros(Tw-nlags+1, nx);
for p = 0:nlags-1
    X(:, p*nv+(1:nv)) = Yd(nlags-p:Tw-p, :);
end
Z = M*X';

Yhat = steady_state_kalman(B, SigC, M, Z(:,2:end));

% E_t(lambda_{t+1}) = E_t ner_{t+1} - ner_t - idiff_t
a = zeros(1,nx);  a(ix(2)) = 1;
c = zeros(1,nx);  c(ix(2)) = 1;  c(ix(3)) = 1;
e = Yhat(:,end)' * (a*B - c)' + mexr;
end

function Yhat = steady_state_kalman(B, Sigma, A, z)
%STEADY_STATE_KALMAN  Fixed-gain filter for Y_t = B Y_{t-1} + U_t, z_t = A Y_t.
%
%   Solves the Riccati equation for the steady-state covariance P of the
%   one-step-ahead state forecast, then filters z from a zero initial state.
%   Returns the filtered states, n x T.

% Solve by doubling, and check the answer in the equation itself. If it does
% not satisfy the equation, solve by plain iteration instead.
P   = riccati_doubling(B, Sigma, A);
K   = P*A' / (A*P*A');
res = norm(P - (B*P*B' + Sigma - B*K*A*P*B'), 'fro') / max(1, norm(P, 'fro'));
if ~(res <= 1e-9)
    P = riccati_iterate(B, Sigma, A);
    K = P*A' / (A*P*A');
end

n = size(B,1);  T = size(z,2);
Yhat = zeros(n, T);
y    = zeros(n, 1);
for t = 1:T
    y = B*y;
    y = y + K*(z(:,t) - A*y);
    Yhat(:,t) = y;
end
end

function P = riccati_doubling(B, Sigma, A)
%RICCATI_DOUBLING  Solve P = B*(P - P*A'*inv(A*P*A')*A*P)*B' + Sigma by doubling.
%
%   The observation z_t = A Y_t has no noise of its own, so the equation is
%   first written for F = P - P*A'*inv(A*P*A')*A*P, the covariance of Y_t given
%   z up to t. Seen from Y_t, z_{t+1} = A*B*Y_t + A*U_{t+1} is an observation
%   with noise A*U_{t+1}, which has covariance R = A*Sigma*A' and covariance
%   S = Sigma*A' with the state shock. Removing that correlation gives a
%   standard Riccati equation in F, which the structure-preserving doubling
%   algorithm solves: each step squares the closed-loop transition, so it takes
%   10 to 20 steps where plain iteration takes hundreds. Then P = B*F*B' + Sigma.
    n  = size(B,1);
    H  = A*B;
    R  = A*Sigma*A';
    S  = Sigma*A';
    Ak = (B - S*(R\H))';
    Gk = H'*(R\H);
    Fk = Sigma - S*(R\S');
    I  = eye(n);
    for it = 1:60
        W  = I + Gk*Fk;
        AW = Ak / W;
        Fn = Fk + Ak'*Fk*(W\Ak);
        Gk = Gk + AW*Gk*Ak';
        Ak = AW*Ak;
        delta = norm(Fn - Fk, 'fro') / max(1, norm(Fk, 'fro'));
        Fk = Fn;
        if delta <= 1e-15; break; end
    end
    P = B*Fk*B' + Sigma;
    P = (P + P')/2;
end

function P = riccati_iterate(B, Sigma, A)
%RICCATI_ITERATE  Solve the same equation by iterating it from P = Sigma.
    P = Sigma;
    for it = 1:100000
        K     = P*A' / (A*P*A');
        Pnew  = B*P*B' + Sigma - B*K*A*P*B';
        delta = norm(Pnew - P, 'fro') / max(1, norm(P, 'fro'));
        P     = Pnew;
        if delta <= 1e-12; break; end
    end
    if delta > 1e-12
        warning('gen_tradingstrategy:riccati', ...
            'Riccati iteration did not converge (relative change %.2e).', delta);
    end
end
