function T = gen_tradingstrategy(data, dates, info)
%GEN_TRADINGSTRATEGY  Table B.6: out-of-sample VAR-based currency strategy.
%
%   T = GEN_TRADINGSTRATEGY(data, dates, info)
%
%   Called by run_main when info.trade_windows is non-empty (the sweeps'
%   baseline cells set it). Stored in the run's .mat as `trading`; formatted by
%   write_trading_table.
%
%   data   TT x nvars matrix the run's VAR was fit on (run_main's dataL)
%   dates  TT x 1 fractional-year dates; must be consecutive quarters
%   info   the run's descriptor. Window lengths from info.trade_windows; every
%          estimation setting genvars needs from info.settings.
%
% THE STRATEGY. For each window length N and each forecast origin t = N..TT-1:
%   1. re-estimate the VAR on rows t-N+1..t (genvars: same prior, same draws,
%      same seed as the run itself);
%   2. for every posterior draw, form E_t(lambda_{t+1}), the expected excess
%      return on foreign currency, conditional on what the CJ identification
%      conditions on -- current and past TFP and E_t TFP_{t+j}, j = j_cj_horizon
%      -- via a steady-state Kalman filter over the window;
%   3. hold a position equal to the median across draws of E_t(lambda_{t+1}),
%      and earn it times the realised lambda_{t+1} = ner_{t+1} - ner_t - idiff_t.
% Negative positions are long the dollar. The point estimate genvars appends
% (element ndraws+1) is not a draw and is not used.
%
% Taking the median of the POSITION is the same as taking the median across
% draws of the portfolio RETURN: lambda_{t+1} is one number per t, and a median
% commutes with multiplication by any scalar, negative ones included.
%
% T (struct)
%   windows   1 x K  window lengths N, quarters
%   sr        K x 1  annualised Sharpe ratio, 2*mean(pf)/std(pf)
%   ret       K x 1  annualised mean portfolio return, 4*mean(pf)
%   nobs      K x 1  portfolio returns per window length, TT - N
%   origin    1 x K  cell; forecast-origin dates t
%   elam      1 x K  cell; median across draws of E_t(lambda_{t+1})
%   lam       1 x K  cell; realised lambda_{t+1}
%   sample    [first last] date of the data handed in
%   ndraws, j_cj_horizon, nlags
%
% Cost: sum over N of (TT - N) full genvars calls. On 1978Q4-2008Q2 (TT = 119)
% with N = 60:4:100 that is 429. The windows within one N run in parallel.
%
% See also RUN_MAIN, GENVARS, WRITE_TRADING_TABLE.

S       = info.settings;
W       = info.trade_windows(:)';
nlags   = S.nlags;
ndraws  = S.ndraws;
jh      = S.j_cj_horizon;

% genvars is handed the ESTIMATED basis; for a spec with a transform that is not
% `data`, and the realised return below would be read off the wrong columns.
assert(~S.has_transform, 'gen_tradingstrategy:transform', ...
    'spec %d estimates on a transformed basis; the strategy is defined on levels specs only.', ...
    info.inclvar);

% Columns BY NAME -- the filter observes TFP, and the return is built from NER
% and IDIFF. Errors if the spec lacks any of them (e.g. a no-FX spec).
ix = var_order(info.inclvarnms, 'tfp', 'ner', 'idiff');

[TT, nv] = size(data);
dates = dates(:);
assert(numel(dates) == TT, 'gen_tradingstrategy:dates', ...
    '%d dates for %d rows of data.', numel(dates), TT);
% A rolling window over a gap would silently pair non-adjacent quarters. The
% NaN mask in run_main can drop interior rows, so check rather than assume.
assert(all(abs(diff(dates) - 0.25) < 1e-6), 'gen_tradingstrategy:gap', ...
    'the sample is not consecutive quarters; a rolling window is undefined over a gap.');
assert(max(W) <= TT - 2, 'gen_tradingstrategy:short', ...
    'window %d leaves fewer than 2 forecasts in a %d-quarter sample.', max(W), TT);

K = numel(W);
T = struct('windows',W, 'sr',NaN(K,1), 'ret',NaN(K,1), 'nobs',NaN(K,1), ...
           'origin',{cell(1,K)}, 'elam',{cell(1,K)}, 'lam',{cell(1,K)}, ...
           'sample',[dates(1) dates(end)], 'ndraws',ndraws, ...
           'j_cj_horizon',jh, 'nlags',nlags);

fprintf('  trading strategy: %d window lengths, %d re-estimations, %d draws each\n', ...
        K, sum(TT - W), ndraws);
t0 = tic;
for k = 1:K
    N  = W(k);
    nw = TT - N;                 % forecast origins t = N..TT-1
    elam = NaN(nw,1);
    lam  = NaN(nw,1);
    parfor w = 1:nw
        Yw = data(w:w+N-1, :);
        [ARs, Sigs] = genvars(Yw, info);
        assert(numel(ARs) == ndraws + 1, 'gen_tradingstrategy:draws', ...
            'genvars returned %d elements, expected %d draws + 1.', numel(ARs), ndraws);
        e = NaN(ndraws,1);
        for d = 1:ndraws
            e(d) = exret_kf(ARs{d}, Sigs{d}, Yw, ix, nlags, jh);
        end
        elam(w) = median(e);
        t = w + N - 1;
        lam(w) = data(t+1,ix(2)) - data(t,ix(2)) - data(t,ix(3));
    end
    pf = elam .* lam;
    T.sr(k)     = 2*mean(pf) / std(pf);
    T.ret(k)    = 4*mean(pf);
    T.nobs(k)   = nw;
    T.origin{k} = dates(N:TT-1);
    T.elam{k}   = elam;
    T.lam{k}    = lam;
    fprintf('  N = %3d: %3d forecasts, Sharpe %6.2f, return %6.2f   (%.1f min)\n', ...
            N, nw, T.sr(k), T.ret(k), toc(t0)/60);
end
end


% -------------------------------------------------------------------------
function e = exret_kf(AR, Sig, Y, ix, nlags, jh)
%EXRET_KF  E_t(lambda_{t+1}) at the window's last quarter, for one draw.
%
%   The investor observes z_t = [TFP_t; E_t TFP_{t+jh}] -- both linear in the
%   companion state -- and filters the state with the steady-state Kalman gain.
%   Data are demeaned over the window; the window's mean excess return is added
%   back at the end. ix = [tfp ner idiff] column positions.

nv = size(Y,2);
nx = nv*nlags;
B  = [AR; eye(nx-nv), zeros(nx-nv,nv)];      % companion form
SigC = zeros(nx);  SigC(1:nv,1:nv) = Sig;    % state noise: shocks hit block 1 only

etfp = zeros(1,nx);  etfp(ix(1)) = 1;
M    = [etfp; etfp*B^jh];                    % TFP_t and E_t TFP_{t+jh}

mY    = mean(Y,1);
mexr  = mean(diff(Y(:,ix(2)))) - mY(ix(3));  % window mean of lambda
Yd    = Y - mY;

% Companion state at t = nlags..end: [y_t, y_{t-1}, ..., y_{t-nlags+1}]
Tw = size(Yd,1);
X  = zeros(Tw-nlags+1, nx);
for p = 0:nlags-1
    X(:, p*nv+(1:nv)) = Yd(nlags-p:Tw-p, :);
end
Z = M*X';

Yhat = steady_state_kalman(B, SigC, M, Z(:,2:end));

% E_t(lambda_{t+1}) = E_t ner_{t+1} - ner_t - idiff_t
a = zeros(1,nx);  a(ix(2)) = 1;
c = zeros(1,nx);  c(ix(2)) = 1;  c(ix(3)) = 1;
e = Yhat(:,end)' * (a*B - c)' + mexr;
end


% -------------------------------------------------------------------------
function Yhat = steady_state_kalman(B, Sigma, A, z)
%STEADY_STATE_KALMAN  Fixed-gain filter for Y_t = B Y_{t-1} + U_t, z_t = A Y_t.
%
%   Solves the Riccati equation by iteration from P = Sigma, then filters z
%   from a zero initial state. Returns the filtered states, n x T.

P = Sigma;
for it = 1:100000
    K     = P*A' / (A*P*A');
    Pnew  = B*P*B' + Sigma - B*K*A*P*B';
    delta = norm(Pnew - P, 'fro') / max(1, norm(P, 'fro'));
    P     = Pnew;
    if delta <= 1e-12; break; end
end
if delta > 1e-12
    warning('gen_tradingstrategy:riccati', ...
        'Riccati iteration did not converge (relative change %.2e).', delta);
end
K = P*A' / (A*P*A');

n = size(B,1);  T = size(z,2);
Yhat = zeros(n, T);
y    = zeros(n, 1);
for t = 1:T
    y = B*y;
    y = y + K*(z(:,t) - A*y);
    Yhat(:,t) = y;
end
end
