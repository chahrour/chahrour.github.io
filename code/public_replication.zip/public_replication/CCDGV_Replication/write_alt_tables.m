function out = write_alt_tables(infos, opt)
%WRITE_ALT_TABLES  Write Tables C.6 and C.7, the alternative specifications.
%
%   out = WRITE_ALT_TABLES(infos)
%   out = WRITE_ALT_TABLES(infos, opt)
%
%   infos  sweep's run descriptors: .country (1x6 cell) and, optionally, .vecm
%   opt    .outdir  required: the directory holding Figures/ and Tables/
%          .echo    print the Table C.6 panels (default true)
%   out    .C6 and .C7, each a cell with one matrix per panel
%
%   The table counterparts of Figures C.7 and C.8. Both tables have the panels
%       Panel A  Bayesian VECM
%       Panel B  Individual countries (Median)
%   Without a VECM run there is one panel, lettered A.
%
%   Table C.6 is Table 1's statistic (share of forecast error variance explained
%   by the FX shock, by horizon). Table C.7 is Table 2's (technology, noise and
%   both, by frequency band), with Table 2's line naming each band above the
%   column heads of every panel.
%
%   The country panel is a median of medians: each country's cell is the median
%   across its own draws, and the panel is the median of the six, cell by cell.
%
%   Rows are found by name through ccdgv_order, so all runs must share one
%   vnames. Each file holds only the tabular environment.
%
%   See also WRITE_UHLIG_TABLES, WRITE_VD_TABLE, GENFIG_C7C8.

    if nargin < 2; opt = struct(); end
    % opt.outdir is the exhibit root; Tables/ is appended here.
    assert(isfield(opt,'outdir') && ~isempty(opt.outdir), 'write_alt_tables:noOutdir', ...
        'opt.outdir is required: the directory holding Figures/ and Tables/.');
    opt.outdir = fullfile(opt.outdir, 'Tables');
    if ~isfield(opt,'echo'); opt.echo = true; end
    if ~isfolder(opt.outdir); mkdir(opt.outdir); end

    % Panels are lettered in the order they appear.
    PANELS = cell(0,2);
    if isfield(infos,'vecm')
        PANELS = [PANELS
                  {'Panel A: Bayesian VECM',  {infos.vecm}}];
    else
        fprintf(['  write_alt_tables: no VECM panel -- sweep_infos has no `vecm`\n' ...
                 '  C.6/C.7 are written with the country panel only.\n']);
    end
    PANELS = [PANELS
              {sprintf('Panel %c: Individual countries (Median)', 'A' + size(PANELS,1)), ...
               infos.country}];

    % Load every run once and check that all share the same rows.
    L = cell(size(PANELS,1),1);  vnames = [];
    for p = 1:size(PANELS,1)
        runs = PANELS{p,2};
        L{p} = cell(1,numel(runs));
        for k = 1:numel(runs)
            [~,f] = data_name(runs{k});
            assert(isfile(f), 'write_alt_tables:noFile', ...
                   '%s not found -- run run_sweep first', f);
            L{p}{k} = load(f, 'dataplots','vstfp','vsnoise','vnames','vd_feh','vd_fr');
            if isempty(vnames); vnames = L{p}{k}.vnames; end
            assert(isequal(L{p}{k}.vnames, vnames), 'write_alt_tables:rowMismatch', ...
                ['%s has %d rows against %d -- the runs predate different manifest ' ...
                 'versions.'], f, numel(L{p}{k}.vnames), numel(vnames));
        end
    end

    o    = ccdgv_order(vnames);
    rows = o.vdec(1:8);                      % the draft's eight rows
    lab  = vnames(rows);
    feh  = L{1}{1}.vd_feh;

    % Table C.6: FEV share by horizon.
    M3 = cell(size(PANELS,1),1);
    for p = 1:size(PANELS,1)
        X = cellfun(@(D) D.dataplots(D.vd_feh, rows, 1)', L{p}, 'UniformOutput', false);
        M3{p} = local_medcat(X);             % median across runs
    end
    f3 = fullfile(opt.outdir, 'TableC6.tex');
    local_write(f3, M3, PANELS(:,1), lab, "Q"+string(feh), {});
    out.C6 = M3;

    % Table C.7: technology/noise decomposition by band.
    bands = [1 3];                           % the two bands of Table 2
    M4 = cell(size(PANELS,1),1);
    for p = 1:size(PANELS,1)
        X = cellfun(@(D) local_vd(D, rows, bands), L{p}, 'UniformOutput', false);
        M4{p} = local_medcat(X);
    end
    hdr4 = strings(1,3*numel(bands));
    lb   = {'Both','Tech','Noise'};   % Both = Tech + Noise
    grp4 = cell(1,numel(bands));      % one label per band, as in Table 2
    fr   = L{1}{1}.vd_fr;
    for b = 1:numel(bands)
        for j = 1:3; hdr4((b-1)*3+j) = lb{j}; end
        grp4{b} = sprintf('Periodicities of %g--%g Quarters', ...
                          round(2*pi/fr(bands(b),2)), round(2*pi/fr(bands(b),1)));
    end
    f4 = fullfile(opt.outdir, 'TableC7.tex');
    local_write(f4, M4, PANELS(:,1), lab, hdr4, grp4);
    out.C7 = M4;

    fprintf('  wrote Tables/TableC6.tex, Tables/TableC7.tex\n');

    if opt.echo
        for p = 1:size(PANELS,1)
            fprintf('\n  %s\n', PANELS{p,1});
            fprintf('    %-28s%s\n', '', sprintf('%8s', "Q"+string(feh)));
            for r = 1:size(M3{p},1)
                fprintf('    %-28s%s\n', lab{r}, sprintf('%8.2f', M3{p}(r,:)));
            end
        end
    end
end

function M = local_medcat(X)
%   Median across runs, cell by cell.
    if numel(X) == 1; M = X{1}; return; end
    M = median(cat(3, X{:}), 3);
end

function M = local_vd(D, rows, bands)
%   Median across draws of vstfp and vsnoise, and their sum, as in write_vd_table.
    t = median(D.vstfp(rows, bands, :),  3);
    n = median(D.vsnoise(rows, bands, :), 3);
    M = zeros(numel(rows), 3*numel(bands));
    for b = 1:numel(bands)
        M(:,(b-1)*3+(1:3)) = [t(:,b)+n(:,b), t(:,b), n(:,b)];   % Both, Tech, Noise
    end
end

function local_write(fn, M, panels, lab, colhdr, grp)
%   One tabular with the panels stacked, each under a spanning header. grp, if
%   not empty, is a line of labels above the column heads, each spanning an
%   equal share of the columns.
    nc  = numel(colhdr);
    fid = fopen(fn,'w');
    c   = onCleanup(@() fclose(fid));
    fprintf(fid, '%% Generated by write_alt_tables.m -- do not edit by hand.\n');
    fprintf(fid, '\\begin{tabular}{l |%s}\n', repmat(' C{1.5cm} ',1,nc));
    for p = 1:numel(panels)
        fprintf(fid, '\t\\hline\n');
        fprintf(fid, '\t\\multicolumn{%d}{c}{%s} \\\\\n', nc+1, panels{p});
        fprintf(fid, '\t\\hline\n');
        if ~isempty(grp)
            fprintf(fid, '\t');
            g = [repmat({nc/numel(grp)}, 1, numel(grp)); grp(:)'];
            fprintf(fid, ' & \\multicolumn{%d}{c}{%s}', g{:});
            fprintf(fid, '\\\\\n\t\\hline\n');
        end
        fprintf(fid, '\t');
        fprintf(fid, ' & %s', colhdr{:});
        fprintf(fid, ' \\\\\n\t\\hline\n');
        for r = 1:size(M{p},1)
            fprintf(fid, '\t%-28s', lab{r});
            fprintf(fid, ' & %.2f', M{p}(r,:));
            fprintf(fid, '\\\\\n');
        end
    end
    fprintf(fid, '\t\\hline\n\\end{tabular}\n');
end
