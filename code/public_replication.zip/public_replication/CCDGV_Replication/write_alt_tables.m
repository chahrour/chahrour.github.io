function out = write_alt_tables(infos, opt)
%WRITE_ALT_TABLES  Tables B.3 and B.4 -- alternative specifications.
%
%   out = WRITE_ALT_TABLES(infos)
%   out = WRITE_ALT_TABLES(infos, opt)
%
%   infos  struct with .vecm and .country (1x6 cell) -- sweep's
%          descriptors, i.e. sweep_infos
%   opt    .outdir  REQUIRED: the directory holding Figures/ and Tables/
%          .echo    print the panels (default true)
%
%   The table counterparts of Figures B.3/B.4, with the same panels in each:
%       Panel B  Vector Error Correction Model
%       Panel C  Individual countries (Median)
%
%   There is no Panel A. It carried the extended sample, which Tables B.1 and B.2
%   now report on their own; B and C keep their letters rather than shifting up,
%   so the gap shows a panel was dropped rather than hiding it.
%
%   B.3 is Table 1's statistic per panel (share of forecast error variance
%   explained by the FX shock, by horizon); B.4 is Table 2's (the CJ
%   decomposition into technology, noise and both, by frequency band). Both
%   extractions are lifted from WRITE_UHLIG_TABLES and WRITE_VD_TABLE rather than
%   rewritten, so a change to how the baseline table is computed reaches these.
%
%   PANEL C IS A MEDIAN OF MEDIANS. Each country's cell is already the median
%   across that country's draws (dataplots page 1, or median over vstfp's third
%   dimension); Panel C takes the median of those six numbers, cell by cell. It
%   is NOT the median of the six countries' draws pooled -- pooling would let a
%   country with a wider posterior dominate, and the six are separate estimations
%   rather than draws from one.
%
%   ROWS BY NAME via ccdgv_order, as the baseline tables do. Every run must carry
%   the same manifest layout; asserted, since a row mismatch would silently take
%   one spec's row against another's.
%
%   Panel B is the Bayesian VECM at cointegrating rank 4 (spec 10).
%
%   See also WRITE_UHLIG_TABLES, WRITE_VD_TABLE, GENFIG_B7B8.

    if nargin < 2; opt = struct(); end
    % opt.outdir is the EXHIBIT ROOT; this function appends Tables/ itself, which
    % is the same convention every generator here uses.
    assert(isfield(opt,'outdir') && ~isempty(opt.outdir), 'write_alt_tables:noOutdir', ...
        'opt.outdir is required: the directory holding Figures/ and Tables/.');
    opt.outdir = fullfile(opt.outdir, 'Tables');
    if ~isfield(opt,'echo'); opt.echo = true; end
    if ~isfolder(opt.outdir); mkdir(opt.outdir); end

    % PANEL A IS NOT WRITTEN. It was the extended sample, and that evidence is
    % now reported on its own in Tables B.1 and B.2 (same statistic, same
    % 1978Q4-2020Q1 span), so repeating it here said nothing new. Removed at the
    % coauthors' request, 2026-10-11.
    %
    % THE REMAINING PANELS KEEP THEIR LETTERS. B stays B and C stays C rather
    % than shifting up, which is this file's existing rule for an absent panel: a
    % gap is the honest signal that one is missing, and renumbering would make a
    % partial run look complete. The same rule already covers a sweep with no
    % VECM, below.
    PANELS = cell(0,2);
    if isfield(infos,'vecm')
        PANELS = [PANELS
                  {'Panel B: Bayesian VECM (cointegrating rank 4)',  {infos.vecm}}];
    else
        fprintf(['  write_alt_tables: no Panel B -- sweep_infos has no `vecm`\n' ...
                 '  B.6/B.7 are written without the VECM panel.\n']);
    end
    PANELS = [PANELS
              {'Panel C: Individual countries (Median)',      infos.country}];

    % ---- load every run once -------------------------------------------
    L = cell(size(PANELS,1),1);  vnames = [];
    for p = 1:size(PANELS,1)
        runs = PANELS{p,2};
        L{p} = cell(1,numel(runs));
        for k = 1:numel(runs)
            [~,f] = data_name(runs{k});
            assert(isfile(f), 'write_alt_tables:noFile', ...
                   '%s not found -- run run_sweep first', f);
            L{p}{k} = load(f, 'dataplots','vstfp','vsnoise','vnames','vd_feh','vd_fr');
            if isempty(vnames); vnames = L{p}{k}.vnames; end
            assert(isequal(L{p}{k}.vnames, vnames), 'write_alt_tables:rowMismatch', ...
                ['%s has %d rows against %d -- the runs predate different manifest ' ...
                 'versions.'], f, numel(L{p}{k}.vnames), numel(vnames));
        end
    end

    o    = ccdgv_order(vnames);
    rows = o.vdec(1:8);                      % the draft's eight rows
    lab  = vnames(rows);
    feh  = L{1}{1}.vd_feh;

    % ---- Table B.6: FEV share, by horizon -------------------------------
    M3 = cell(size(PANELS,1),1);
    for p = 1:size(PANELS,1)
        X = cellfun(@(D) D.dataplots(D.vd_feh, rows, 1)', L{p}, 'UniformOutput', false);
        M3{p} = local_medcat(X);             % median ACROSS runs (identity if one)
    end
    f3 = fullfile(opt.outdir, 'tabB03_alt_uhlig.tex');
    local_write(f3, M3, PANELS(:,1), lab, "Q"+string(feh), ...
        'Share of variance explained by the Main FX shock (Alternative specifications)', ...
        ['Share of the forecast error variance of each variable explained by the ' ...
         'main exchange rate shock, at the horizons shown. Panel C is the median ' ...
         'across the six countries of each country''s own median across draws.']);
    out.B3 = M3;

    % ---- Table B.7: CJ decomposition, by band ---------------------------
    bands = [1 3];                           % the published Table 2's two bands
    M4 = cell(size(PANELS,1),1);
    for p = 1:size(PANELS,1)
        X = cellfun(@(D) local_vd(D, rows, bands), L{p}, 'UniformOutput', false);
        M4{p} = local_medcat(X);
    end
    hdr4 = strings(1,3*numel(bands));
    lb   = {'Both','Tech','Noise'};   % the draft's order; Both = Tech + Noise
    for b = 1:numel(bands)
        for j = 1:3; hdr4((b-1)*3+j) = lb{j}; end
    end
    f4 = fullfile(opt.outdir, 'tabB04_alt_vd.tex');
    local_write(f4, M4, PANELS(:,1), lab, hdr4, ...
        'Variance decomposition (Alternative specifications)', ...
        ['Share of each variable''s variance within a frequency band explained by ' ...
         'technology, by noise, and by both. Bands are periodicities 2--100 and ' ...
         '6--32 quarters. Panel C is the median across the six countries of each ' ...
         'country''s own median across draws.']);
    out.B4 = M4;

    fprintf('  wrote Tables/tabB03_alt_uhlig.tex, Tables/tabB04_alt_vd.tex\n');

    if opt.echo
        for p = 1:size(PANELS,1)
            fprintf('\n  %s\n', PANELS{p,1});
            fprintf('    %-28s%s\n', '', sprintf('%8s', "Q"+string(feh)));
            for r = 1:size(M3{p},1)
                fprintf('    %-28s%s\n', lab{r}, sprintf('%8.2f', M3{p}(r,:)));
            end
        end
    end
end

% -------------------------------------------------------------------------
function s = local_span(I)
%   'yyyy:Qq--yyyy:Qq' from the run's realised sample (requested, if absent).
    sd = I.sd;  ed = I.ed;
    if isfield(I,'sd_realised') && ~isempty(I.sd_realised); sd = I.sd_realised; end
    if isfield(I,'ed_realised') && ~isempty(I.ed_realised); ed = I.ed_realised; end
    q = @(d) sprintf('%d:Q%d', floor(d + 1e-9), round((d - floor(d + 1e-9))*4) + 1);
    s = [q(sd) '--' q(ed)];
end

function M = local_medcat(X)
%   Median across runs, cell by cell. One run -> that run, unchanged.
    if numel(X) == 1; M = X{1}; return; end
    M = median(cat(3, X{:}), 3);
end

function M = local_vd(D, rows, bands)
%   WRITE_VD_TABLE's statistic: median across draws of vstfp/vsnoise, then Both.
    t = median(D.vstfp(rows, bands, :),  3);
    n = median(D.vsnoise(rows, bands, :), 3);
    M = zeros(numel(rows), 3*numel(bands));
    for b = 1:numel(bands)
        M(:,(b-1)*3+(1:3)) = [t(:,b)+n(:,b), t(:,b), n(:,b)];   % Both, Tech, Noise
    end
end

function local_write(fn, M, panels, lab, colhdr, caption, note)
%   Emit a full table environment, matching write_uhlig_tables' output: centred,
%   captioned, \resizebox'd. A bare tabular sits left-aligned and uncaptioned
%   beside its neighbours, and leaves LaTeX's table counter out of step with the
%   surrounding numbering.
    nc  = numel(colhdr);
    fid = fopen(fn,'w');
    c   = onCleanup(@() fclose(fid));
    fprintf(fid, '%% Generated by write_alt_tables.m -- do not edit by hand.\n');
    fprintf(fid, '\\begin{table}[t]\n\t\\centering\n');
    fprintf(fid, '\t\\caption{%s}\n', caption);
    fprintf(fid, '\t\\resizebox{0.975\\columnwidth}{!}{%%\n');
    fprintf(fid, '\t\t\\begin{tabular}{l |%s}\n', repmat(' C{1.5cm} ',1,nc));
    for p = 1:numel(panels)
        fprintf(fid, '\t\t\t\\hline\n');
        fprintf(fid, '\t\t\t\\multicolumn{%d}{c}{%s} \\\\\n', nc+1, panels{p});
        fprintf(fid, '\t\t\t\\hline\n');
        fprintf(fid, '\t\t\t');
        fprintf(fid, ' & %s', colhdr{:});
        fprintf(fid, ' \\\\\n\t\t\t\\hline\n');
        for r = 1:size(M{p},1)
            fprintf(fid, '\t\t\t%-28s', lab{r});
            fprintf(fid, ' & %.2f', M{p}(r,:));
            fprintf(fid, '\\\\\n');
        end
    end
    fprintf(fid, '\t\t\t\\hline\n\t\t\\end{tabular}\n\t}\n');
    fprintf(fid, '\t\\caption*{\\footnotesize \\emph{Notes:} %s}\n', note);
    fprintf(fid, '\\end{table}\n');
end
