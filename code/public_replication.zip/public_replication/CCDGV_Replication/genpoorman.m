function genpoorman(opt)
%GENPOORMAN  Figure 6 and Table C.8: lead-lag regressions of the annual change in
%            the real exchange rate on the annual change in TFP.
%
%   genpoorman(opt)
%
%   opt is a struct. Its fields and their defaults are listed in the options
%   block below. opt.outdir is required: the directory holding Figures/ and
%   Tables/.
%
%   Figure 6   R-squared against the lead-lag horizon, for the aggregate
%   Table C.8  Sims (1972) Granger-causality p-values, 7 countries x 5 horizons
%              x 2 directions
%
%   For horizon h, y is regressed on leads and lags of x at one-year spacing,
%       y_t = a + sum_{k=-h..h} b_k x_{t-4k} + e_t,
%   and the test is that the lead coefficients are jointly zero. The restricted
%   model drops the leads. Figure 6 plots the R-squared of both models.
%
%   The two directions are the loop variable reverse:
%     0   y = d(RER), x = d(TFP)   Panel A of the table, and Figure 6
%     1   y = d(TFP), x = d(RER)   Panel B
%
%   opt.start and opt.end_date each take 'run' (the sample of the run named in
%   opt.datafile), 'paper' (1976Q1 and 2008Q2), 'data' (the widest NaN-free
%   span) or a fractional year.

if nargin < 1 || isempty(opt); opt = struct(); end

%% Options
D = struct( ...
    'vintage',   '2026',  ... % Fernald vintage of the built panel
    'start',     'run', ... % first quarter of the sample:
                          ... %   'run'   first quarter of the run in opt.datafile
                          ... %   'paper' 1976Q1
                          ... %   'data'  earliest NaN-free quarter
                          ... %   numeric fractional year, e.g. 1976
    'end_date',  2008+1/4, ... % last quarter of the sample:
                          ... %   'run'   last quarter of the run, clamped to the data
                          ... %   'paper' 2008Q2
                          ... %   'data'  latest NaN-free quarter
                          ... %   numeric fractional year; the default 2008+1/4
                          ... %           is 2008Q2
    'nymax',     5,       ... % max lead-lag horizon in years
    'ylags',     0,       ... % lags of the dependent variable
    'q',         0.05,    ... % level of the R-squared interval that is drawn
    'q2',        0.05,    ... % level of a second interval, which is not drawn
    'plot_cc',   7,       ... % countries that get a figure; 7 is the aggregate
    'ylim',      [],      ... % y-limits of the figure; [] leaves the axis tight
    'save_fig',  true,    ...
    'save_tab',  true,    ...
    'outdir',    '',      ... % required: holds Figures/ and Tables/
    'echo_tab',  true,   ...
    'datafile',  '');

bad = setdiff(fieldnames(opt), fieldnames(D));
if ~isempty(bad)
    error('genpoorman:unknownOpt','Unknown option(s): %s. Valid: %s.', ...
          strjoin(bad(:)',', '), strjoin(fieldnames(D)',', '));
end
for f = fieldnames(D)'
    if ~isfield(opt,f{1}); opt.(f{1}) = D.(f{1}); end
end
assert(~isempty(opt.outdir), 'genpoorman:noOutdir', ...
    'opt.outdir is required: the directory holding Figures/ and Tables/.');

Countries  = {'CA','FR','GE','IT','JP','UK','G7'};
CountryLng = {'Canada','France','Germany','Italy','Japan','UK','Aggregate'};
nC = numel(Countries);

%% Data
[tfp, rer, dts] = local_load(opt);          % tfp Tx1, rer Tx7, dts Tx1 datetime

% Sample window.
t0 = local_resolve_start(opt, tfp, rer, dts);
t1 = local_resolve_end(opt, tfp, rer, dts);
assert(t0 >= dts(1), 'genpoorman:startUnavailable', ...
    'requested start %s precedes the data, which begins %s.', ...
    datestr(t0,'yyyyQQ'), datestr(dts(1),'yyyyQQ'));
assert(t1 <= dts(end), 'genpoorman:endUnavailable', ...
    'requested end %s exceeds the data, which ends %s.', ...
    datestr(t1,'yyyyQQ'), datestr(dts(end),'yyyyQQ'));
keep = dts >= t0 & dts <= t1;
tfp = tfp(keep,:); rer = rer(keep,:); dts = dts(keep);

fprintf('\n genpoorman | built panel (Fernald %s)', opt.vintage);
fprintf(' | start=%s | end=%s | %s..%s (%d obs)\n', string(opt.start), ...
        string(opt.end_date), ...
        datestr(dts(1),'yyyyQQ'), datestr(dts(end),'yyyyQQ'), numel(dts));
% Note when the sample is not the published 1976Q1-2008Q2.
if ~isequal(datestr(dts(1),'yyyyQQ'),'1976Q1') || ~isequal(datestr(dts(end),'yyyyQQ'),'2008Q2')
    fprintf(['   NOTE: the published Table C.8 and Figure 6 are 1976Q1-2008Q2; ' ...
             'this pass is %s-%s.\n         Use opt.start=''paper'' and ' ...
             'opt.end_date=''paper'' to reproduce them.\n'], ...
             datestr(dts(1),'yyyyQQ'), datestr(dts(end),'yyyyQQ'));
end

%% Estimate
% Results are indexed (horizon, country, direction).
nh       = opt.nymax + 1;
Rsq      = NaN(nh, nC, 2);
Rsq_r    = NaN(nh, nC, 2);
Rsq_lead = NaN(nh, nC, 2);
bounds   = NaN(4, nh, nC, 2);
bounds_r = NaN(4, nh, nC, 2);
p_value  = NaN(nh, nC, 2);
nobs     = NaN(nh, nC, 2);

for reverse = 0:1
    for cc = 1:nC
        d4 = @(v) v(5:end) - v(1:end-4);        % annual change, quarterly obs
        if reverse == 0
            x = d4(tfp);        y = d4(rer(:,cc));   % Panel A
        else
            x = d4(rer(:,cc));  y = d4(tfp);         % Panel B
        end
        R = poorman_leadlag(x, y, opt);
        j = reverse + 1;
        Rsq(:,cc,j)        = R.Rsq(:);
        Rsq_r(:,cc,j)      = R.Rsq_r(:);
        Rsq_lead(:,cc,j)   = R.Rsq_lead(:);
        bounds(:,:,cc,j)   = R.bounds;
        bounds_r(:,:,cc,j) = R.bounds_r;
        p_value(:,cc,j)    = R.pval(:);
        nobs(:,cc,j)       = R.n(:);
    end
end
assert(~any(isnan(p_value(:))), 'genpoorman:incomplete', ...
       'p_value has %d unfilled cells.', nnz(isnan(p_value)));

%% Figure 6
% One figure per country in opt.plot_cc, from the reverse = 0 pass.
for cc = opt.plot_cc(:)'
    h = local_plot_r2(0:opt.nymax, Rsq(:,cc,1), Rsq_r(:,cc,1), ...
                      bounds(:,:,cc,1), bounds_r(:,:,cc,1), opt.ylim);
    if opt.save_fig
        nm = 'Figure6';
        if cc ~= 7;        nm = [nm '_' Countries{cc}]; end
        exportgraphics(h, fullfile(opt.outdir, 'Figures', [nm '.pdf']));
        fprintf('   wrote Figures/%s.pdf\n', nm);
    end
end

%% Table C.8
sel  = 1:opt.nymax;                       % horizons 1..nymax; h = 0 is not tabulated
prov = sprintf(['source=%s%s, start=%s, end=%s, sample %s-%s (%d obs), ' ...
                'test=%s'], 'rebuilt', ...
    sprintf('/f%s', opt.vintage), ...
    string(opt.start), string(opt.end_date), ...
    datestr(dts(1),'yyyyQQ'), datestr(dts(end),'yyyyQQ'), ...
    numel(dts), 'Sims1972 Wald');

if opt.save_tab
    tdir = fullfile(opt.outdir,'Tables');
    if ~exist(tdir,'dir'); mkdir(tdir); end
    fn = fullfile(tdir,'TableC8.tex');
    local_write_table(fn, p_value(sel+1,:,:), sel, CountryLng, prov);
    fprintf('   wrote Tables/TableC8.tex\n');
end
if opt.echo_tab
    local_echo_table(p_value(sel+1,:,:), sel, CountryLng, prov);
end
end


%% Local functions

function R = poorman_leadlag(x, y, opt)
%POORMAN_LEADLAG  Sims (1972) lead-lag regression at horizons h = 0..nymax.
%   y_t = a + sum_{k=-h..h} b_k x_{t-4k} + e_t
%   x supplies the leads and lags; y is the dependent variable. A horizon that
%   is not estimated stays NaN.
    nh = opt.nymax + 1;
    R = struct('Rsq',NaN(1,nh), 'Rsq_r',NaN(1,nh), 'Rsq_lead',NaN(1,nh), ...
               'bounds',NaN(4,nh), 'bounds_r',NaN(4,nh), ...
               'pval',NaN(1,nh), 'n',NaN(1,nh), 'k',NaN(1,nh));

    for ny = 0:opt.nymax
        % Negative shifts in lagmatrix are leads, so the columns run
        % [lead_h ... lead_1, contemporaneous, lag_1 ... lag_h].
        XX  = lagmatrix(x, -ny*4:4:ny*4);
        XX  = [XX, lagmatrix(y, 1:opt.ylags)];            %#ok<AGROW>
        XX  = [ones(size(x,1),1) XX];                      %#ok<AGROW>
        idx = (~isnan(y)) & all(~isnan(XX),2);
        yy  = y(idx,:);
        XX  = XX(idx,:);
        XXr = XX(:, [1 ny+2:end]);       % restricted: drop the ny lead columns

        bet  = XX\yy;      ypred  = XX*bet;
        betr = XXr\yy;     ypredr = XXr*betr;
        sst  = sum((yy - mean(yy)).^2);

        i = ny + 1;
        R.Rsq(i)   = 1 - sum((yy - ypred ).^2)/sst;
        R.Rsq_r(i) = 1 - sum((yy - ypredr).^2)/sst;
        if ny > 0                        % fit from the lead terms alone
            yl = XX(:,1:ny+1)*bet(1:ny+1,:);
            R.Rsq_lead(i) = 1 - sum((yy - yl).^2)/sst;
        end

        n = size(yy,1);
        R.n(i) = n;  R.k(i) = size(XX,2);
        R.bounds(:,i)   = local_r2_ci(R.Rsq(i),   n, size(XX,2),  opt.q, opt.q2);
        R.bounds_r(:,i) = local_r2_ci(R.Rsq_r(i), n, size(XXr,2), opt.q, opt.q2);

        % Sims (1972) Wald test with a Newey-West HAC covariance.
        R.pval(i) = myWald(XX, yy, ny, 0);
    end
end

function b = local_r2_ci(r2, n, k, q, q2)
%LOCAL_R2_CI  Asymptotic confidence interval for R-squared.
%   Rows are [upper_q; lower_q; upper_q2; lower_q2]: tinv(q/2,.) is negative.
%   Formula: https://www.danielsoper.com/statcalc/formulas.aspx?id=28
    se = sqrt((4*r2*(1-r2)^2*(n-k)^2)/((n^2-1)*(n+3)));
    b  = [r2 - tinv(q /2,n-k)*se;  r2 + tinv(q /2,n-k)*se; ...
          r2 - tinv(q2/2,n-k)*se;  r2 + tinv(q2/2,n-k)*se];
end

function [tfp, rer, dts] = local_load(opt)
%LOCAL_LOAD  Return TFP (Tx1), real exchange rates (Tx7, G7 last) and dates.
    DR = fullfile(fileparts(mfilename('fullpath')),'..','Data_Replication');
    f  = fullfile(DR,'Built_Data',sprintf('Y_benchmark_f%s.mat',opt.vintage));
    assert(exist(f,'file')==2, 'genpoorman:noBuilt', ...
        ['%s not found. Run Data_Replication/data_import_and_transform ' ...
         'with fernald_vintage_override="%s".'], f, opt.vintage);
    B = load(f, 'Y','S_fx','P_all','cfg');
    assert(isfield(B,'S_fx') && isfield(B,'P_all'), 'genpoorman:noPanels', ...
        ['%s predates the per-country panels. Re-run the pipeline; the save ' ...
         'must include S_fx and P_all.'], f);

    SY = synchronize(B.S_fx, B.P_all, B.Y(:,{'TFP','q_real'}), 'intersection');
    sn = B.S_fx.Properties.VariableNames;
    pn = B.P_all.Properties.VariableNames;
    % Match columns by country name; the panels' column order is different.
    want = {'Canada','France','Germany','Italy','Japan','UK'};
    for w = want
        assert(any(strcmp(sn,w{1})) && any(strcmp(pn,w{1})), ...
            'genpoorman:missingCountry','%s absent from the rebuilt panels.', w{1});
    end
    assert(any(strcmp(pn,'US')), 'genpoorman:noUS', 'P_all has no US column.');
    sfx  = SY{:, 1:width(B.S_fx)};
    pall = SY{:, width(B.S_fx)+(1:width(B.P_all))};
    rer  = NaN(height(SY), 7);
    for c = 1:6
        rer(:,c) = log(sfx(:,strcmp(sn,want{c}))) ...
                 - (log(pall(:,strcmp(pn,'US'))) - log(pall(:,strcmp(pn,want{c}))));
    end
    rer(:,7) = SY.q_real;            % the built panel's own aggregate
    tfp = SY.TFP;
    dts = SY.Time;

end

function t0 = local_resolve_start(opt, tfp, rer, dts)
%LOCAL_RESOLVE_START  First quarter of the sample, from opt.start.
    if isnumeric(opt.start)
        t0 = local_frac2dt(opt.start); return
    end
    switch lower(char(opt.start))
    case 'paper'
        t0 = datetime(1976,1,1);
    case 'data'
        good = find(all(isfinite([tfp rer]),2), 1);
        assert(~isempty(good),'genpoorman:allNaN','no NaN-free quarter in the data.');
        t0 = dts(good);
    case 'run'
        % The first quarter of the run.
        nm = local_datam('start', opt);
        V = load(nm, 'dates');
        assert(isfield(V,'dates') && ~isempty(V.dates), 'genpoorman:noDates', ...
               '%s has no dates variable to inherit a start from.', nm);
        t0 = local_frac2dt(V.dates(1));
    otherwise
        error('genpoorman:badStart', ...
              'opt.start must be ''run'', ''paper'', ''data'' or a numeric year.');
    end
end

function t1 = local_resolve_end(opt, tfp, rer, dts)
%LOCAL_RESOLVE_END  Last quarter of the sample, from opt.end_date.
%   'run' is clamped to the last quarter in the data, with a printed note. A
%   numeric end past the data is an error, raised by the caller.
    if isnumeric(opt.end_date)
        t1 = local_frac2dt(opt.end_date); return
    end
    switch lower(char(opt.end_date))
    case 'paper'
        t1 = local_frac2dt(2008+1/4);
    case 'data'
        good = find(all(isfinite([tfp rer]),2), 1, 'last');
        assert(~isempty(good),'genpoorman:allNaN','no NaN-free quarter in the data.');
        t1 = dts(good);
    case 'run'
        % The last quarter of the run, clamped to the data.
        nm = local_datam('end_date', opt);
        V = load(nm, 'dates');
        assert(isfield(V,'dates') && ~isempty(V.dates), 'genpoorman:noDates', ...
               '%s has no dates variable to inherit an end from.', nm);
        t1 = local_frac2dt(V.dates(end));
        if t1 > dts(end)
            fprintf(['   NOTE: the run ends %s but source=%s reaches only %s, ' ...
                     'so Figure 6\n         and Table C.8 are CLAMPED to %s. ' ...
                     '\n'], ...
                    datestr(t1,'yyyyQQ'), ...
                    datestr(dts(end),'yyyyQQ'), datestr(dts(end),'yyyyQQ'));
            t1 = dts(end);
        end
    otherwise
        error('genpoorman:badEnd', ...
              'opt.end_date must be ''run'', ''paper'', ''data'' or a numeric year.');
    end
end

function nm = local_datam(field, opt)
%LOCAL_DATAM  The run file a 'run' window is read from: opt.datafile.
    nm = '';
    if isfield(opt,'datafile'); nm = opt.datafile; end
    assert(~isempty(nm), 'genpoorman:noVcase', ...
        ['opt.%s=''run'' inherits the window from a run, so opt.datafile must ' ...
         'name that run file. Otherwise choose ''paper'' (the published ' ...
         '1976Q1-2008Q2 window) or a numeric year.'], field);
end

function d = local_frac2dt(f)
%LOCAL_FRAC2DT  Fractional year (2008.25) -> datetime quarter start (2008Q2).
    if isdatetime(f); d = f; return; end
    yr = floor(f + 1e-9);
    q  = round((f - yr)*4) + 1;
    d  = datetime(yr, 3*(q-1)+1, 1);
end

function h = local_plot_r2(hs, Rsq, Rsq_r, bnd, bnd_r, yl)
%LOCAL_PLOT_R2  Figure 6: unrestricted vs restricted R-squared across horizons.
    Color1 = [172 166 252]/255;     % unrestricted band
    Color2 = [252 166 166]/255;     % restricted band
    h = figure('Color','w','Position',[1 1 400 255]);
    patch([hs(:); flipud(hs(:))], [bnd_r(1,:)'; flipud(bnd_r(2,:)')], ...
          Color2, 'edgecolor', Color2); hold on;
    patch([hs(:); flipud(hs(:))], [bnd(1,:)';   flipud(bnd(2,:)')  ], ...
          Color1, 'edgecolor', Color1);
    a1 = plot(hs, Rsq,   'b', 'Linewidth', 2);
    a2 = plot(hs, Rsq_r, 'r', 'Linewidth', 2);
    plot(hs, zeros(size(hs)), '--k', 'Linewidth', 0.5);
    axis tight; grid on;
    set(gca,'XTick',hs,'TickLabelInterpreter','latex','FontSize',11);
    xlabel('Lead-lag horizon (years)','Fontsize',11,'Interpreter','latex');
    ylabel('R-squared','Fontsize',11,'Interpreter','latex');
    legend([a1 a2], {'Unrestricted','Restricted'}, 'Location','northwest', ...
           'interpreter','latex','Fontsize',12); legend boxoff;
    if ~isempty(yl); ylim(yl); end     % [] keeps axis tight
end

function local_write_table(fn, pv, sel, cols, prov)
%LOCAL_WRITE_TABLE  Write Table C.8 as two tabular panels, without a float,
% caption or notes.
    fid = fopen(fn,'w');  c = onCleanup(@() fclose(fid));
    panel = {'Panel A: P-values testing whether exchange rates Granger-cause TFP', ...
             'Panel B: P-values testing whether TFP Granger-cause exchange rates'};
    fprintf(fid,'%% Generated by genpoorman.m -- do not edit by hand.\n');
    fprintf(fid,'%% %s\n', prov);
    for j = 1:2
        fprintf(fid,'\\begin{tabular}{l}\n\\text{%s} \\\\\n\\end{tabular}\n\n', panel{j});
        fprintf(fid,'\\vspace{2pt}\n\n');
        fprintf(fid,'\\begin{tabular}{ %s}\n\\hline\n', repmat('p{1.5cm} ',1,numel(cols)+1));
        fprintf(fid,'$h$ & %s \\\\ \\hline\n', strjoin(cols,' & '));
        for i = 1:numel(sel)
            cells = arrayfun(@(p) local_pstar(p), pv(i,:,j), 'UniformOutput', false);
            fprintf(fid,'%d & %s \\\\', sel(i), strjoin(cells,' & '));
            if i == numel(sel); fprintf(fid,' \\hline'); end
            fprintf(fid,'\n');
        end
        fprintf(fid,'\\end{tabular}\n');
        if j == 1; fprintf(fid,'\n\\vspace{10pt}\n\n'); end
    end
end

function local_echo_table(pv, sel, cols, prov)
%LOCAL_ECHO_TABLE  Print the table to the console.
    fprintf('\n  %s\n', prov);
    for j = 1:2
        fprintf('\n  Panel %c   %s\n', 'A'+j-1, strjoin(pad(cols,10),' '));
        for i = 1:numel(sel)
            cells = arrayfun(@(p) local_pstar(p), pv(i,:,j), 'UniformOutput', false);
            fprintf('  %-8d %s\n', sel(i), strjoin(pad(cells,10),' '));
        end
    end
    fprintf('\n');
end

function s = local_pstar(p)
%LOCAL_PSTAR  Two decimals plus significance stars. The p-value is rounded
% before the comparison, so the stars agree with the printed number.
    r = round(p,2);
    if     r <= 0.01; st = '***';
    elseif r <= 0.05; st = '**';
    elseif r <= 0.10; st = '*';
    else;             st = '';
    end
    s = [sprintf('%.2f',p) st];
end
