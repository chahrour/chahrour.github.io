function genpoorman(opt)
%GENPOORMAN  Figure 6 and Table B.8, from lead-lag regressions of the
%            annual change in the real exchange rate on the annual change in TFP.
%
% Rsquared confidence bands: https://www.danielsoper.com/statcalc/formulas.aspx?id=28
%
% Both exhibits come from one pass:
%   Figure 6  (fig: poorman)      R-squared vs lead-lag horizon, G7 aggregate
%   Table B.8 (tab:pvaluePMALL)   Sims (1972) Granger-causality p-values,
%                                 7 countries x 5 horizons x 2 directions
%
% THE TEST. For horizon h, regress y on leads AND lags of x at one-year spacing
%   y_t = a + sum_{k=-h..h} b_k x_{t-4k} + e_t
% and test whether the LEAD coefficients are jointly zero. Under Sims, leads of x
% mattering in the y equation means y Granger-causes x. The restricted model
% drops the leads; the gap between the two R-squareds IS that incremental content,
% which is what Figure 6 plots.
%
% `reverse` swaps which series is the dependent variable:
%   reverse = 0 -> y = d(RER), x = d(TFP)  -> Panel A, "do exchange rates
%                                             Granger-cause TFP"
%   reverse = 1 -> y = d(TFP), x = d(RER)  -> Panel B, the other direction
% and is also why the paper's Figure 6 is the reverse=0 pass specifically.
%
% ---------------------------------------------------------------------------
% CHANGED 2026-08-04. Previously this script bypassed the data build entirely,
% discarded most of what it computed, and wrote nothing to disk. Four fixes:
%
%  1. DATA SOURCE is the built panel, matched to the run's Fernald vintage, as
%     before (byte-identical, reproduces the draft); 'rebuilt' reads the
%     Data_Replication panel, so the exhibits finally respond to vintage and
%     sample choices like everything else.
%  2. RESULTS ARE KEPT. Rsq/Rsq_lag/RSQ_bounds were never preallocated and never
%     cleared between countries, so six countries' results were computed and
%     thrown away and the figure rendered whatever cc=7 happened to leave behind
%     -- the right answer, by accident of loop order. Everything now lands in
%     preallocated arrays indexed (h, country, direction).
%  3. THE PRINT IS OUT OF THE reverse LOOP. It used to sit inside it, so
%     enabling it wrote POORMAN_yearly at reverse=0 and then OVERWROTE it at
%     reverse=1 -- i.e. it produced the mirror exercise under the name of the
%     paper's figure. Same overwrite-under-a-shared-filename pattern as Figs 3/4.
%  4. THE COUNTRY MAP IS BY NAME. cfg.countries in the rebuilt panel is
%     {Germany, Japan, France, UK, Italy, Canada} -- a DIFFERENT order from this
%     script's {CA,FR,GE,IT,JP,UK}. Verified: with a positional map the six
%     country columns scramble to corr 0.28-0.97 while the Aggregate column,
%     being order-independent, still reads 0.99998. Never index these by position.
%
% Reproducing the published exhibits requires opt.start='paper' -- the DEFAULT
% inherits the estimation sample, while the draft's table is
% 1976Q1-2008Q2. See the note on opt.start below.
%
% BOTH ENDS OF THE SAMPLE ARE OPTIONS, and they take the same words: 'run'
% (inherit the associated run), 'paper' (the published window), 'data' (the
% widest NaN-free span) or a numeric fractional year. They are set independently,
% and exhibits asks for the paper's START with the run's END -- 1976Q1 is this
% exercise's own left edge, not bound by IDIFF the way the VAR's is, while the
% right edge has no reason to sit in 2008 on a run that goes further.
% ---------------------------------------------------------------------------

if nargin < 1 || isempty(opt); opt = struct(); end

%% ---- options -----------------------------------------------------------
D = struct( ...
    'vintage',   '2026',  ... % rebuilt only: Fernald vintage; '2026' ships
    'start',     'run', ... % 'run' inherit the run's realised start (1978Q4
                          ... %         ) -- DOES NOT match the draft
                          ... % 'paper' 1976Q1, reproduces Table B.8 and Figure 6
                          ... % 'data'  earliest NaN-free quarter available
                          ... % numeric explicit fractional year, e.g. 1976
    'end_date',  2008+1/4, ... % 'run' inherit the run's realised end -- CLAMPED
                          ... %         to what the source can supply, see below
                          ... % 'paper' 2008Q2, reproduces Table B.8 and Figure 6
                          ... % 'data'  latest NaN-free quarter available
                          ... % numeric explicit fractional year; 2008+1/4 =
                          ... %         2008Q2, the default, as published
    'nymax',     5,       ... % max lead-lag horizon in years
    'ylags',     0,       ... % lags of the DEPENDENT variable; 0 = paper result
    'q',         0.05,    ... % outer R-squared CI
    'q2',        0.05,    ... % inner R-squared CI
    'plot_cc',   7,       ... % which countries get a figure; 7 = G7, as the paper
    'ylim',      [],      ... % [] = axis tight, which reproduces the draft.
                          ... % The script previously hard-coded [-0.035 0.465],
                          ... % which CLIPS the top of the unrestricted band --
                          ... % the published POORMAN_yearly.eps runs past 0.5.
    'save_fig',  true,    ...
    'save_tab',  true,    ...
    'outdir',    '',      ... % REQUIRED: holds Figures/ and Tables/
    'echo_tab',  true,   ...
    'datafile',  '');

bad = setdiff(fieldnames(opt), fieldnames(D));
if ~isempty(bad)
    error('genpoorman:unknownOpt','Unknown option(s): %s. Valid: %s.', ...
          strjoin(bad(:)',', '), strjoin(fieldnames(D)',', '));
end
for f = fieldnames(D)'
    if ~isfield(opt,f{1}); opt.(f{1}) = D.(f{1}); end
end
assert(~isempty(opt.outdir), 'genpoorman:noOutdir', ...
    'opt.outdir is required: the directory holding Figures/ and Tables/.');

Countries  = {'CA','FR','GE','IT','JP','UK','G7'};
CountryLng = {'Canada','France','Germany','Italy','Japan','UK','Aggregate'};
nC = numel(Countries);

%% ---- data --------------------------------------------------------------
[tfp, rer, dts] = local_load(opt);          % tfp Tx1, rer Tx7, dts Tx1 datetime

t0 = local_resolve_start(opt, tfp, rer, dts);
t1 = local_resolve_end(opt, tfp, rer, dts);
assert(t0 >= dts(1), 'genpoorman:startUnavailable', ...
    'requested start %s precedes the data, which begins %s.', ...
    datestr(t0,'yyyyQQ'), datestr(dts(1),'yyyyQQ'));
assert(t1 <= dts(end), 'genpoorman:endUnavailable', ...
    'requested end %s exceeds the data, which ends %s.', ...
    datestr(t1,'yyyyQQ'), datestr(dts(end),'yyyyQQ'));
keep = dts >= t0 & dts <= t1;
tfp = tfp(keep,:); rer = rer(keep,:); dts = dts(keep);

fprintf('\n genpoorman | built panel (Fernald %s)', opt.vintage);
fprintf(' | start=%s | end=%s | %s..%s (%d obs)\n', string(opt.start), ...
        string(opt.end_date), ...
        datestr(dts(1),'yyyyQQ'), datestr(dts(end),'yyyyQQ'), numel(dts));
% Says which end is off the published window, since they move independently now.
if ~isequal(datestr(dts(1),'yyyyQQ'),'1976Q1') || ~isequal(datestr(dts(end),'yyyyQQ'),'2008Q2')
    fprintf(['   NOTE: the published Table B.8 and Figure 6 are 1976Q1-2008Q2; ' ...
             'this pass is %s-%s.\n         Use opt.start=''paper'' and ' ...
             'opt.end_date=''paper'' to reproduce them.\n'], ...
             datestr(dts(1),'yyyyQQ'), datestr(dts(end),'yyyyQQ'));
end

%% ---- estimate ----------------------------------------------------------
% Preallocated. The old code wrote these by index without ever clearing them
% between countries, which is how six countries' results went missing.
nh       = opt.nymax + 1;
Rsq      = NaN(nh, nC, 2);
Rsq_r    = NaN(nh, nC, 2);
Rsq_lead = NaN(nh, nC, 2);
bounds   = NaN(4, nh, nC, 2);
bounds_r = NaN(4, nh, nC, 2);
p_value  = NaN(nh, nC, 2);
nobs     = NaN(nh, nC, 2);

for reverse = 0:1
    for cc = 1:nC
        d4 = @(v) v(5:end) - v(1:end-4);        % annual change, quarterly obs
        if reverse == 0
            x = d4(tfp);        y = d4(rer(:,cc));   % Panel A
        else
            x = d4(rer(:,cc));  y = d4(tfp);         % Panel B
        end
        R = poorman_leadlag(x, y, opt);
        j = reverse + 1;
        Rsq(:,cc,j)        = R.Rsq(:);
        Rsq_r(:,cc,j)      = R.Rsq_r(:);
        Rsq_lead(:,cc,j)   = R.Rsq_lead(:);
        bounds(:,:,cc,j)   = R.bounds;
        bounds_r(:,:,cc,j) = R.bounds_r;
        p_value(:,cc,j)    = R.pval(:);
        nobs(:,cc,j)       = R.n(:);
    end
end
assert(~any(isnan(p_value(:))), 'genpoorman:incomplete', ...
       'p_value has %d unfilled cells.', nnz(isnan(p_value)));

%% ---- Figure 6 ----------------------------------------------------------
% One figure per (country, direction). reverse=0 is the paper's Figure 6; the
% reverse=1 mirror gets its own name so it can never overwrite it.
figs = gobjects(0);
for reverse = 0:1
    for cc = opt.plot_cc(:)'
        j = reverse + 1;
        h = local_plot_r2(0:opt.nymax, Rsq(:,cc,j), Rsq_r(:,cc,j), ...
                          bounds(:,:,cc,j), bounds_r(:,:,cc,j), opt.ylim);
        figs(end+1) = h; %#ok<SAGROW>
        if opt.save_fig
            nm = 'POORMAN_yearly';                       % the paper's Figure 6
            if reverse == 1;   nm = [nm '_reverse'];  end
            if cc ~= 7;        nm = [nm '_' Countries{cc}]; end            
            exportgraphics(h, fullfile(opt.outdir, 'Figures', [nm '.pdf']));
            fprintf('   wrote Figures/%s.pdf\n', nm);
        end
    end
end

%% ---- Table B.8 ---------------------------------------------------------
sel  = 1:opt.nymax;                       % horizons 1..nymax; h=0 is not tabulated
prov = sprintf(['source=%s%s, start=%s, end=%s, sample %s-%s (%d obs), ' ...
                'test=%s, generated %s'], 'rebuilt', ...
    sprintf('/f%s', opt.vintage), ...
    string(opt.start), string(opt.end_date), ...
    datestr(dts(1),'yyyyQQ'), datestr(dts(end),'yyyyQQ'), ...
    numel(dts), 'Sims1972 Wald', ...
    datestr(now,'yyyy-mm-dd HH:MM'));

if opt.save_tab
    tdir = fullfile(opt.outdir,'Tables');
    if ~exist(tdir,'dir'); mkdir(tdir); end
    fn = fullfile(tdir,'tabB05_granger.tex');
    local_write_tableB5(fn, p_value(sel+1,:,:), sel, CountryLng, prov);
    fprintf('   wrote Tables/tabB05_granger.tex\n');
end
if opt.echo_tab
    local_echo_tableB5(p_value(sel+1,:,:), sel, CountryLng, prov);
end
end


%% ========================================================================
%  Local functions
%  ========================================================================

function R = poorman_leadlag(x, y, opt)
%POORMAN_LEADLAG  Sims (1972) lead-lag regression at horizons h = 0..nymax.
%   y_t = a + sum_{k=-h..h} b_k x_{t-4k} + e_t
%   x supplies the leads and lags; y is the dependent variable.
%   Every field is preallocated over h, so a skipped horizon shows as NaN
%   instead of silently inheriting the previous country's value.
    nh = opt.nymax + 1;
    R = struct('Rsq',NaN(1,nh), 'Rsq_r',NaN(1,nh), 'Rsq_lead',NaN(1,nh), ...
               'bounds',NaN(4,nh), 'bounds_r',NaN(4,nh), ...
               'pval',NaN(1,nh), 'n',NaN(1,nh), 'k',NaN(1,nh));

    for ny = 0:opt.nymax
        % lagmatrix with NEGATIVE shifts gives leads, so columns run
        % [lead_h ... lead_1, contemporaneous, lag_1 ... lag_h].
        XX  = lagmatrix(x, -ny*4:4:ny*4);
        XX  = [XX, lagmatrix(y, 1:opt.ylags)];            %#ok<AGROW>
        XX  = [ones(size(x,1),1) XX];                      %#ok<AGROW>
        idx = (~isnan(y)) & all(~isnan(XX),2);
        yy  = y(idx,:);
        XX  = XX(idx,:);
        XXr = XX(:, [1 ny+2:end]);       % restricted: drop the ny lead columns

        bet  = XX\yy;      ypred  = XX*bet;
        betr = XXr\yy;     ypredr = XXr*betr;
        sst  = sum((yy - mean(yy)).^2);

        i = ny + 1;
        R.Rsq(i)   = 1 - sum((yy - ypred ).^2)/sst;
        R.Rsq_r(i) = 1 - sum((yy - ypredr).^2)/sst;
        if ny > 0                        % leads-only fit; computed historically,
            yl = XX(:,1:ny+1)*bet(1:ny+1,:);   % not plotted or tabulated anywhere
            R.Rsq_lead(i) = 1 - sum((yy - yl).^2)/sst;
        end

        n = size(yy,1);
        R.n(i) = n;  R.k(i) = size(XX,2);
        R.bounds(:,i)   = local_r2_ci(R.Rsq(i),   n, size(XX,2),  opt.q, opt.q2);
        R.bounds_r(:,i) = local_r2_ci(R.Rsq_r(i), n, size(XXr,2), opt.q, opt.q2);

        % Sims (1972) Wald with Newey-West HAC, which is what the paper reports.
        % An F-test arm sat beside this under opt.test_stat == 1 and was never
        % selected: the only caller leaves the default, and the table's own
        % provenance line names the Wald test.
        R.pval(i) = myWald(XX, yy, ny, 0);
    end
end

function b = local_r2_ci(r2, n, k, q, q2)
%LOCAL_R2_CI  Asymptotic CI on R-squared. Rows [lo_q; hi_q; lo_q2; hi_q2].
% tinv(q/2,..) is negative, hence the sign pattern -- preserved from the original.
    se = sqrt((4*r2*(1-r2)^2*(n-k)^2)/((n^2-1)*(n+3)));
    b  = [r2 - tinv(q /2,n-k)*se;  r2 + tinv(q /2,n-k)*se; ...
          r2 - tinv(q2/2,n-k)*se;  r2 + tinv(q2/2,n-k)*se];
end

function [tfp, rer, dts] = local_load(opt)
%LOCAL_LOAD  Return TFP (Tx1), real exchange rates (Tx7, G7 last) and dates.
    DR = fullfile(fileparts(mfilename('fullpath')),'..','Data_Replication');
    f  = fullfile(DR,'Built_Data',sprintf('Y_benchmark_f%s.mat',opt.vintage));
    assert(exist(f,'file')==2, 'genpoorman:noBuilt', ...
        ['%s not found. Run Data_Replication/data_import_and_transform ' ...
         'with fernald_vintage_override="%s".'], f, opt.vintage);
    B = load(f, 'Y','S_fx','P_all','cfg');
    assert(isfield(B,'S_fx') && isfield(B,'P_all'), 'genpoorman:noPanels', ...
        ['%s predates the per-country panels. Re-run the pipeline; the save ' ...
         'must include S_fx and P_all.'], f);

    SY = synchronize(B.S_fx, B.P_all, B.Y(:,{'TFP','q_real'}), 'intersection');
    sn = B.S_fx.Properties.VariableNames;
    pn = B.P_all.Properties.VariableNames;
    % BY NAME. cfg.countries is {Germany, Japan, France, UK, Italy, Canada},
    % which is NOT this script's order -- see the header note.
    want = {'Canada','France','Germany','Italy','Japan','UK'};
    for w = want
        assert(any(strcmp(sn,w{1})) && any(strcmp(pn,w{1})), ...
            'genpoorman:missingCountry','%s absent from the rebuilt panels.', w{1});
    end
    assert(any(strcmp(pn,'US')), 'genpoorman:noUS', 'P_all has no US column.');
    sfx  = SY{:, 1:width(B.S_fx)};
    pall = SY{:, width(B.S_fx)+(1:width(B.P_all))};
    rer  = NaN(height(SY), 7);
    for c = 1:6
        rer(:,c) = log(sfx(:,strcmp(sn,want{c}))) ...
                 - (log(pall(:,strcmp(pn,'US'))) - log(pall(:,strcmp(pn,want{c}))));
    end
    rer(:,7) = SY.q_real;            % the pipeline's own G6 aggregate
    tfp = SY.TFP;
    dts = SY.Time;

end

function t0 = local_resolve_start(opt, tfp, rer, dts)
%LOCAL_RESOLVE_START  See the opt.start documentation at the top.
    if isnumeric(opt.start)
        t0 = local_frac2dt(opt.start); return
    end
    switch lower(char(opt.start))
    case 'paper'
        t0 = datetime(1976,1,1);
    case 'data'
        good = find(all(isfinite([tfp rer]),2), 1);
        assert(~isempty(good),'genpoorman:allNaN','no NaN-free quarter in the data.');
        t0 = dts(good);
    case 'run'
        % Inherit the realised start of the associated run. Deliberately errors
        % rather than falling back: a silent default would make the sample of a
        % written exhibit unknowable after the fact.
        nm = local_datam('start', opt);
        V = load(nm, 'dates');
        assert(isfield(V,'dates') && ~isempty(V.dates), 'genpoorman:noDates', ...
               '%s has no dates variable to inherit a start from.', nm);
        t0 = local_frac2dt(V.dates(1));
    otherwise
        error('genpoorman:badStart', ...
              'opt.start must be ''run'', ''paper'', ''data'' or a numeric year.');
    end
end

% -------------------------------------------------------------------------
function t1 = local_resolve_end(opt, tfp, rer, dts)
%LOCAL_RESOLVE_END  See the opt.end_date documentation at the top.
%
%   Mirrors LOCAL_RESOLVE_START word for word, with one deliberate asymmetry:
%   'run' CLAMPS to the last quarter the source can supply instead of
%   erroring.
%   later would otherwise abort the exhibit build two thirds of the
%   way through a sweep, over an exhibit that cannot reach that far by
%   construction. The clamp is printed here AND lands in the provenance line of
%   both exhibits, so the realised sample is never in doubt afterwards. To
%   actually go past 2018Q4.
%
%   An explicit numeric end past the data still errors, in the caller: asking
%   for a quarter that does not exist is a mistake, not a case being itself.
    if isnumeric(opt.end_date)
        t1 = local_frac2dt(opt.end_date); return
    end
    switch lower(char(opt.end_date))
    case 'paper'
        t1 = local_frac2dt(2008+1/4);
    case 'data'
        good = find(all(isfinite([tfp rer]),2), 1, 'last');
        assert(~isempty(good),'genpoorman:allNaN','no NaN-free quarter in the data.');
        t1 = dts(good);
    case 'run'
        % Same inheritance as opt.start='run', same refusal to guess.
        nm = local_datam('end_date', opt);
        V = load(nm, 'dates');
        assert(isfield(V,'dates') && ~isempty(V.dates), 'genpoorman:noDates', ...
               '%s has no dates variable to inherit an end from.', nm);
        t1 = local_frac2dt(V.dates(end));
        if t1 > dts(end)
            fprintf(['   NOTE: the run ends %s but source=%s reaches only %s, ' ...
                     'so Figure 6\n         and Table B.8 are CLAMPED to %s. ' ...
                     '\n'], ...
                    datestr(t1,'yyyyQQ'), ...
                    datestr(dts(end),'yyyyQQ'), datestr(dts(end),'yyyyQQ'));
            t1 = dts(end);
        end
    otherwise
        error('genpoorman:badEnd', ...
              'opt.end_date must be ''run'', ''paper'', ''data'' or a numeric year.');
    end
end

function nm = local_datam(field, opt)
%LOCAL_DATAM  The run file that a 'run' window inherits from.
%
%   A local function cannot see the caller's workspace, so opt is passed in.
%
    nm = '';
    if isfield(opt,'datafile'); nm = opt.datafile; end
    assert(~isempty(nm), 'genpoorman:noVcase', ...
        ['opt.%s=''run'' inherits the window from a run, so opt.datafile must ' ...
         'name that run file. Otherwise choose ''paper'' (the published ' ...
         '1976Q1-2008Q2 window) or a numeric year.'], field);
end

% -------------------------------------------------------------------------
function d = local_frac2dt(f)
%LOCAL_FRAC2DT  Fractional year (2008.25) -> datetime quarter start (2008Q2).
    if isdatetime(f); d = f; return; end
    yr = floor(f + 1e-9);
    q  = round((f - yr)*4) + 1;
    d  = datetime(yr, 3*(q-1)+1, 1);
end

function h = local_plot_r2(hs, Rsq, Rsq_r, bnd, bnd_r, yl)
%LOCAL_PLOT_R2  Figure 6: unrestricted vs restricted R-squared across horizons.
    Color1 = [172 166 252]/255;     % unrestricted band
    Color2 = [252 166 166]/255;     % restricted band
    h = figure('Color','w','Position',[1 1 400 255]);
    patch([hs(:); flipud(hs(:))], [bnd_r(1,:)'; flipud(bnd_r(2,:)')], ...
          Color2, 'edgecolor', Color2); hold on;
    patch([hs(:); flipud(hs(:))], [bnd(1,:)';   flipud(bnd(2,:)')  ], ...
          Color1, 'edgecolor', Color1);
    a1 = plot(hs, Rsq,   'b', 'Linewidth', 2);
    a2 = plot(hs, Rsq_r, 'r', 'Linewidth', 2);
    plot(hs, zeros(size(hs)), '--k', 'Linewidth', 0.5);
    axis tight; grid on;
    set(gca,'XTick',hs,'TickLabelInterpreter','latex','FontSize',11);
    xlabel('Lead-lag horizon (years)','Fontsize',11,'Interpreter','latex');
    ylabel('R-squared','Fontsize',11,'Interpreter','latex');
    legend([a1 a2], {'Unrestricted','Restricted'}, 'Location','northwest', ...
           'interpreter','latex','Fontsize',12); legend boxoff;
    if ~isempty(yl); ylim(yl); end     % [] keeps axis tight -- matches the draft
end

function local_write_tableB5(fn, pv, sel, cols, prov)
%LOCAL_WRITE_TABLEB5  Emit Table B.8 in the DRAFT's shape, so it can be \input.
% The old console output was a single |c| tabular labelled tab:pvalue with
% columns "United Kingdom"/"G7"; the draft uses two p{1.5cm} tabulars labelled
% tab:pvaluePMALL with "UK"/"Aggregate", which is why it was hand-typeset.
    fid = fopen(fn,'w');  c = onCleanup(@() fclose(fid));
    panel = {'Panel A: P-values testing whether exchange rates Granger-cause TFP', ...
             'Panel B: P-values testing whether TFP Granger-cause exchange rates'};
    fprintf(fid,'%% Generated by genpoorman.m -- do not edit by hand.\n');
    fprintf(fid,'%% %s\n', prov);
    fprintf(fid,'\\begin{table}[t]\n\\centering\n');
    fprintf(fid,'\\caption{Granger causality: exchange rates and TFP}\n');
    fprintf(fid,'\\label{tab:pvaluePMALL}\n');
    for j = 1:2
        fprintf(fid,'\\begin{tabular}{l}\n\\text{%s} \\\\\n\\end{tabular}\n\n', panel{j});
        fprintf(fid,'\\vspace{2pt}\n\n');
        fprintf(fid,'\\begin{tabular}{ %s}\n\\hline\n', repmat('p{1.5cm} ',1,numel(cols)+1));
        fprintf(fid,'$h$ & %s \\\\ \\hline\n', strjoin(cols,' & '));
        for i = 1:numel(sel)
            cells = arrayfun(@(p) local_pstar(p), pv(i,:,j), 'UniformOutput', false);
            fprintf(fid,'%d & %s \\\\', sel(i), strjoin(cells,' & '));
            if i == numel(sel); fprintf(fid,' \\hline'); end
            fprintf(fid,'\n');
        end
        fprintf(fid,'\\end{tabular}\n\n');
        if j == 1; fprintf(fid,'\\vspace{10pt}\n\n'); end
    end
    fprintf(fid,['\\caption*{\\footnotesize \\textit{Notes:} P-values from a Wald ' ...
        'test of Granger causality as in \\cite{sims1972money}. %s}\n'], prov);
    fprintf(fid,'\\end{table}\n');
end

function local_echo_tableB5(pv, sel, cols, prov)
    fprintf('\n  %s\n', prov);
    for j = 1:2
        fprintf('\n  Panel %c   %s\n', 'A'+j-1, strjoin(pad(cols,10),' '));
        for i = 1:numel(sel)
            cells = arrayfun(@(p) local_pstar(p), pv(i,:,j), 'UniformOutput', false);
            fprintf('  %-8d %s\n', sel(i), strjoin(pad(cells,10),' '));
        end
    end
    fprintf('\n');
end

function s = local_pstar(p)
%LOCAL_PSTAR  Two decimals plus significance stars, rounded before comparison
% so a printed "0.05" is starred consistently with what the reader sees.
    r = round(p,2);
    if     r <= 0.01; st = '***';
    elseif r <= 0.05; st = '**';
    elseif r <= 0.10; st = '*';
    else;             st = '';
    end
    s = [sprintf('%.2f',p) st];
end

function s = ternchar(c,a,b)
    if c; s = a; else; s = b; end
end
