function [pvalue1, pvalue2] = ew_granger(T, countries, NH, hac, opt)
%EW_GRANGER  Engel-West bivariate Granger tests, for Figures 7 and C.13.
%
%   [p1, p2] = ew_granger(T, countries, NH, hac, opt)
%
%   T          table or timetable with, for each country <c> in countries:
%                EX_<c>            exchange rate, in logs
%                USEURO_<c>        interest differential, US minus foreign
%                CPI_<c>, CPI_US   price levels
%                GDP_<c>, GDP_US   output, in logs
%                M1_<c>,  M1_US    money levels
%   countries  cell of country short names, in the data's column order
%   NH         maximum lag; tests run for lags 4..NH
%   hac        name-value cell passed to granger_cause_Waldtest
%   opt        .compress   true (default) drops NaN rows before lagging; false
%                          leaves them for the test to drop after lagging
%              .clip_var3  true drops the first row of fundamental 3 and of the
%                          exchange rate (default false)
%   p1         6 x nc x NH p-values: the exchange rate Granger-causing the
%              fundamental, the direction both figures count
%   p2         6 x nc x NH p-values for the reverse direction
%
%   The six fundamentals, the rows of p1 and p2: relative money, relative
%   prices, the interest differential, its change, relative money less relative
%   output, and relative output.
%
%   A test needs at least 4*lag + 3 observations. Shorter cells are skipped and
%   stay NaN.
%
%   See also GENPLOTS_EW, GRANGER_CAUSE_WALDTEST, BUILD_EW_PANEL.

    if nargin < 5; opt = struct(); end
    if ~isfield(opt,'compress');  opt.compress  = true;  end
    if ~isfield(opt,'clip_var3'); opt.clip_var3 = false; end
    nc = numel(countries);
    pvalue1 = NaN(6, nc, NH);
    pvalue2 = NaN(6, nc, NH);

    for cc = 1:nc
        nm = countries{cc};
        % Exchange-rate change, in percent.
        y0 = [NaN; 100*diff(T.(['EX_' nm]))];
        for vv = 1:6
            % The fundamental.
            switch vv
                case 1
                    x = [NaN; 100*diff(log(T.M1_US) - log(T.(['M1_' nm])))];
                case 2
                    x = [NaN; 100*diff(log(T.CPI_US) - log(T.(['CPI_' nm])))];
                case 3
                    x = T.(['USEURO_' nm]);
                case 4
                    x = [NaN; diff(T.(['USEURO_' nm]))];
                case 5
                    x = [NaN; 100*diff(log(T.M1_US) - log(T.(['M1_' nm]))) ...
                            - 100*diff(T.GDP_US - T.(['GDP_' nm]))];
                case 6
                    x = [NaN; 100*diff(T.GDP_US - T.(['GDP_' nm]))];
            end
            y = y0;
            if vv == 3 && opt.clip_var3
                x = x(2:end);  y = y(2:end);
            end
            if opt.compress
                keep = isfinite(x) & isfinite(y);
                x = x(keep);  y = y(keep);
            end
            for L = 4:NH
                % Skip cells with too few observations. They stay NaN, which the
                % figures count as not significant.
                n = sum(isfinite(x) & isfinite(y));
                if n < 4*L + 3
                    continue      % too few observations
                end
                pvalue1(vv,cc,L) = granger_cause_Waldtest(x, y, L, hac{:});
                pvalue2(vv,cc,L) = granger_cause_Waldtest(y, x, L, hac{:});
            end
        end
    end
end
