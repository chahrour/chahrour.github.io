function [pvalue1, pvalue2] = ew_granger(T, countries, NH, hac, opt)
%EW_GRANGER  The Engel-West bivariate Granger tests, for both Figure 7 and B.13.
%
%   [p1, p2] = EW_GRANGER(T, countries, NH, hac, opt)
%
%   T          a table or timetable carrying, for each country <c> in countries
%              plus the US where applicable:
%                EX_<c>      the exchange rate, as a LOG
%                USEURO_<c>  the interest differential, US MINUS FOREIGN, already
%                            formed (whatever units that figure uses)
%                CPI_<c>, CPI_US   price LEVELS
%                GDP_<c>, GDP_US   output, as LOGS
%                M1_<c>,  M1_US    money LEVELS
%                US_TFP      US TFP, as a log level
%   countries  cell of six short names, in the data's column order
%   NH         maximum lag; tests run for lags 4..NH
%   hac        name-value cell passed through to GRANGER_CAUSE_WALDTEST
%   opt        .compress   true  -> drop NaN rows BEFORE lagging (Figure B.13)
%                          false -> pass whole, let the test drop them after
%                                   lagging (Figure 7)
%              .clip_var3  true  -> drop the first row of variable 3 and of y
%                                   (Figure 7 only)
%   p1         7 x 6 x NH, the exchange rate Granger-causing the fundamental --
%              THE DIRECTION BOTH FIGURES COUNT
%   p2         7 x 6 x NH, the reverse. Computed at double the cost and plotted
%              by neither figure; returned because it is cheap to keep.
%
%   SIX COUNTRIES, NOT SEVEN. GC_RUN sizes its arrays
%   NaN(7, length(Countries) + (Engel_West == 0), NH) and loops to the same
%   bound, so the G6 aggregate is never tested even though every loader goes to
%   the trouble of building a *_G6 column. Testing it as a seventh column
%   inflates every count in panel (a) and every total in panel (b).
%
%   THE TWO FIGURES REALLY DO DIFFER IN TWO WAYS, and both are preserved here
%   rather than quietly unified:
%     1. NaN HANDLING. GC_RUN's Engel_West==2 branch compresses NaN rows before
%        testing (:207-209), which CONCATENATES ACROSS GAPS -- lags straddle
%        missing quarters. The Engel_West==1 branch does not, so its NaNs are
%        dropped inside GRANGER_CAUSE_WALDTEST:49, after lagging. The two give
%        different answers wherever a series has interior or leading holes, which
%        France's and Italy's money do. opt.compress selects.
%     2. VARIABLE 3's ROW CLIP. Engel_West==1 drops the first row of the
%        un-differenced differential and of y (GC_RUN:132-134), so that one test
%        runs on one fewer observation. Engel_West==2 does not. opt.clip_var3
%        selects.
%
%   RANK. GRANGER_CAUSE_WALDTEST regresses x on its own lags and the lags of y,
%   so k = 1 + 2*max_lag parameters. The binding constraint is not the Wald
%   block's chol -- that has a ridge fallback -- but the prewhitening VAR inside
%   MYHAC -> MYVAR, whose chol has none and throws. It needs
%   T_eff >= 4*max_lag + 3. The guard below skips rather than throws, so one
%   short country cannot abort a whole figure.
%
%   See also GENPLOTS_EW, GRANGER_CAUSE_WALDTEST, BUILD_EW_PANEL.

    if nargin < 5; opt = struct(); end
    if ~isfield(opt,'compress');  opt.compress  = true;  end
    if ~isfield(opt,'clip_var3'); opt.clip_var3 = false; end
    nc = numel(countries);
    pvalue1 = NaN(7, nc, NH);
    pvalue2 = NaN(7, nc, NH);

    for cc = 1:nc
        nm = countries{cc};
        y0 = [NaN; 100*diff(T.(['EX_' nm]))];
        for vv = 1:7
            switch vv
                case 1
                    x = [NaN; 100*diff(log(T.M1_US) - log(T.(['M1_' nm])))];
                case 2
                    x = [NaN; 100*diff(log(T.CPI_US) - log(T.(['CPI_' nm])))];
                case 3
                    x = T.(['USEURO_' nm]);
                case 4
                    x = [NaN; diff(T.(['USEURO_' nm]))];
                case 5
                    x = [NaN; 100*diff(log(T.M1_US) - log(T.(['M1_' nm]))) ...
                            - 100*diff(T.GDP_US - T.(['GDP_' nm]))];
                case 6
                    x = [NaN; 100*diff(T.GDP_US - T.(['GDP_' nm]))];
                case 7
                    x = [NaN; 100*diff(T.US_TFP)];
            end
            y = y0;
            if vv == 3 && opt.clip_var3
                x = x(2:end);  y = y(2:end);
            end
            if opt.compress
                keep = isfinite(x) & isfinite(y);
                x = x(keep);  y = y(keep);
            end
            for L = 4:NH
                % A SKIPPED CELL IS DROPPED SILENTLY. It stays NaN, and the
                % counting step (genplots_ew's local_counts, p <= 0.1) reads NaN
                % as "not significant", so a short country lowers a figure's
                % counts with no warning and no mark in the output. Check
                % sum(isnan(p1(:,:,4:NH)),'all') whenever a sample or NH changes.
                % The guard is also approximate: n counts finite (x,y) pairs
                % BEFORE lagging, while the binding T_eff is after it -- and with
                % compress = false, rows next to an interior NaN are lost too --
                % so a cell near the bound can pass here and still throw in MYVAR.
                n = sum(isfinite(x) & isfinite(y));
                if n < 4*L + 3
                    continue      % MYVAR's chol would throw; skip this cell
                end
                pvalue1(vv,cc,L) = granger_cause_Waldtest(x, y, L, hac{:});
                pvalue2(vv,cc,L) = granger_cause_Waldtest(y, x, L, hac{:});
            end
        end
    end
end
