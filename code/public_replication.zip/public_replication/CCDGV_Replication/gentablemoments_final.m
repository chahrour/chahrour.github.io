function R = gentablemoments_final(datam, opt)
%GENTABLEMOMENTS_FINAL  Table 3 moments: exchange-rate puzzles and TFP expectations.
%
%   R = GENTABLEMOMENTS_FINAL(DATAM, OPT)
%
%   DATAM  struct holding ARs, Sigs, irtfp, irnoise, j_cj_horizon, vnames, Aproj
%          and keys, or the path of a .mat with those variables. irtfp and
%          irnoise must span the full +/-smax quarters.
%   OPT    .want_rlzd         also compute the realised-return moments (default false)
%          .engel_rlzd_limit  number of lags in those sums (default 2500)
%          .pp                percentile for the reported bounds (default 16)
%
%   R.m        struct of moment arrays, each 1 x ndraws+1, named <moment>_<cond>
%              with cond = var (unconditional), tfp, noise or comp (both)
%   R.stats    the table statistics, each with .tfp/.noise/.comp/.var
%   R.skipped  cell array of {moment_block, missing_variable} pairs
%   R.ix       the variable positions used
%   R.meta     ndraws, nvars, nlags, case name, panelA, panelB
%
%   Variables are found by name through ccdgv_moment_vars. If the layout lacks
%   a variable a panel needs, the panel is listed in R.skipped.
%
%   The unconditional variance is a truncated sum of B^i*Sig*B^i', not a
%   Lyapunov solution. Some draws are at or near a unit root, where the
%   unconditional variance does not exist, so the horizon is finite by design.
%
%   See also CCDGV_MOMENT_VARS, WRITE_MOMENTS_TABLE, GENTABLEFILTEREDMOMENTS_FINAL.

    if nargin < 2; opt = struct(); end
    if ~isfield(opt,'engel_rlzd_limit'); opt.engel_rlzd_limit = 2500; end
    if ~isfield(opt,'pp');               opt.pp               = 16;   end
    if ~isfield(opt,'want_rlzd');        opt.want_rlzd        = false; end

    if isstruct(datam)
        D = datam;  cname = 'struct';
    else
        D = load(datam);  cname = datam;
        % The moments need responses on the full +/-smax quarters. A saved run
        % stores a shorter window; run_main computes these moments in memory
        % and saves them as moments.
        if isfield(D,'info') && isfield(D,'irtfp')
            assert(size(D.irtfp,1) == 2*D.info.settings.smax+1, 'gentablemoments_final:window', ...
                ['%s stores responses on +/-%d quarters, short of smax = %d; the ' ...
                 'moments need the full length. Re-run run_main for this case.'], ...
                datam, (size(D.irtfp,1)-1)/2, D.info.settings.smax);
        end
    end
    for f = {'ARs','Sigs','irtfp','irnoise','j_cj_horizon','vnames','Aproj','keys'}
        assert(isfield(D,f{1}), 'gentablemoments_final:missing', ...
            '%s not in the case file.', f{1});
    end

    ix = ccdgv_moment_vars(D.vnames);

    % Panel A (forward premium) and Panel B (Backus-Smith) need different
    % variables, so each is checked separately.
    NEED_A = {'exret','rrdiff','deltaq','cumeret'};
    NEED_B = {'cons','consf','deltaq','consdiff','rer','qlambda','quip'};
    skipped = {};

    % vnames lists every label, but irtfp has only the columns gen_auxvars
    % built. A position beyond those columns counts as absent.
    ncol = size(D.irtfp,2);
    for f = fieldnames(ix)'
        if strcmp(f{1},'names_'); continue; end
        if ~isnan(ix.(f{1})) && ix.(f{1}) > ncol
            ix.(f{1}) = NaN;
        end
    end
    okA = true; okB = true;
    for f = NEED_A
        if isnan(ix.(f{1})); okA = false; skipped(end+1,:) = {'Panel A', f{1}}; end %#ok<AGROW>
    end
    for f = NEED_B
        if isnan(ix.(f{1})); okB = false; skipped(end+1,:) = {'Panel B', f{1}}; end %#ok<AGROW>
    end
    if ~okA || ~okB
        warning('gentablemoments_final:skipped', ...
            ['%d moment block(s) skipped -- this VAR layout lacks: %s. ' ...
             'Those rows will be NaN; see R.skipped.'], ...
            (~okA)+(~okB), strjoin(unique(skipped(:,2))', ', '));
    end

    Aproj = D.Aproj; keys = D.keys;   % projections and their names, from the run
    ARs = D.ARs; Sigs = D.Sigs;
    irtfp_all = D.irtfp; irnoise_all = D.irnoise;
    j_cj = D.j_cj_horizon;
    NN = numel(ARs);
    [k, nxx] = size(ARs{1});  nlags = nxx/k;
    erl = opt.engel_rlzd_limit;
    want_rlzd = opt.want_rlzd;

    % Copy the indices to plain variables for the parfor.
    i_cons=ix.cons; i_consf=ix.consf; i_exret=ix.exret; i_rrdiff=ix.rrdiff;
    i_rer=ix.rer; i_deltaq=ix.deltaq; i_cumeret=ix.cumeret; i_consdiff=ix.consdiff;
    i_quip=ix.quip; i_qlambda=ix.qlambda;

    % Every moment starts as NaN.
    nm = { 'covfama','covfama_rlzd','covengel','var_rrdiff','var_deltaq','rho_rdiff', ...
           'var_dqlambda','corr_dq_dcdiff','cov_dq_dcdiff','var_dcdiff','var_deltac', ...
           'var_dq','rho_deltaq','rho_qt','rho_dqlambda','cov_dquip_dcdiff', ...
           'cov_dqlambda_dcdiff','var_q' };
    sfx = {'var','tfp','noise','comp'};
    M = struct();
    for a = nm, for b = sfx, M.([a{1} '_' b{1}]) = NaN(1,NN); end, end

    if okA || okB
        % Per-draw accumulators, sliced in the parfor.
        cf_v=NaN(1,NN); cf_t=NaN(1,NN); cf_n=NaN(1,NN);
        cr_v=NaN(1,NN); cr_t=NaN(1,NN); cr_n=NaN(1,NN);
        ce_v=NaN(1,NN); ce_t=NaN(1,NN); ce_n=NaN(1,NN);
        vr_v=NaN(1,NN); vr_t=NaN(1,NN); vr_n=NaN(1,NN);
        vq_v=NaN(1,NN); vq_t=NaN(1,NN); vq_n=NaN(1,NN); vq_c=NaN(1,NN);
        rr_v=NaN(1,NN); rr_t=NaN(1,NN); rr_n=NaN(1,NN); rr_c=NaN(1,NN);
        vl_v=NaN(1,NN); vl_t=NaN(1,NN); vl_n=NaN(1,NN); vl_c=NaN(1,NN);
        cq_v=NaN(1,NN); cq_t=NaN(1,NN); cq_n=NaN(1,NN); cq_c=NaN(1,NN);
        kq_v=NaN(1,NN); kq_t=NaN(1,NN); kq_n=NaN(1,NN); kq_c=NaN(1,NN);
        vd_v=NaN(1,NN); vd_t=NaN(1,NN); vd_n=NaN(1,NN); vd_c=NaN(1,NN);
        vc_v=NaN(1,NN); vc_t=NaN(1,NN); vc_n=NaN(1,NN); vc_c=NaN(1,NN);
        dq_v=NaN(1,NN); dq_t=NaN(1,NN); dq_n=NaN(1,NN); dq_c=NaN(1,NN);
        rd_v=NaN(1,NN); rd_t=NaN(1,NN); rd_n=NaN(1,NN); rd_c=NaN(1,NN);
        rq_v=NaN(1,NN); rq_t=NaN(1,NN); rq_n=NaN(1,NN); rq_c=NaN(1,NN);
        rl_t=NaN(1,NN); rl_n=NaN(1,NN); rl_c=NaN(1,NN);
        pu_t=NaN(1,NN); pu_n=NaN(1,NN);
        pl_t=NaN(1,NN); pl_n=NaN(1,NN); pl_v=NaN(1,NN);
        vQ_v=NaN(1,NN);
        cev=NaN(1,NN); cet=NaN(1,NN); cen=NaN(1,NN);   % sums over lags

        parfor bb = 1:NN
            % Companion form, impact matrix and auxiliary-variable loadings.
            AR  = ARs{bb};
            Sig = Sigs{bb};
            nx  = size(AR,2);
            B   = [AR;[eye(nx-k),zeros(nx-k,k)]];
            Atilde = chol(Sig)';
            U   = [Atilde;zeros(k*(nlags-1),k)];
            [A,~,~,~,~,~] = gen_auxvars(AR',Aproj,keys,k,nlags,j_cj);

            % Unconditional variance: truncated sum of B^i*Sig*B^i'.
            VarYY = zeros(size(B));
            Sig_aug = U*U';
            Bii = eye(nx);
            % Number of terms: enough for the largest root to decay to 1%,
            % but at least 1000 and at most 10000.
            sum_cutoff = min(max([log(0.01)/log(max(abs(eig(B)))),1000]), 10000);
            for ii = 0:sum_cutoff
                VarYY = VarYY + Bii*Sig_aug*(Bii)';
                Bii = Bii*B;
            end

            % Cumulated impulse responses, in reversed row order.
            irtfp   = flip(cumsum(irtfp_all(:,:,bb)));
            irnoise = flip(cumsum(irnoise_all(:,:,bb)));

            % Delta(c - c*) along each conditional response.
            dcd_t = dif(irtfp,i_cons)   - dif(irtfp,i_consf);
            dcd_n = dif(irnoise,i_cons) - dif(irnoise,i_consf);

            % Rows of A for the consumption functionals.
            A_dcdiff = A(i_consdiff,:);          % consumption differential, modified
            A_dcdiff(i_cons  + k) = -1;
            A_dcdiff(i_consf + k) =  1;
            A_consdiff = A(i_consdiff,:);        % consumption differential, unmodified
            A_dc = zeros(1,nx);                  % first difference of home consumption
            A_dc([i_cons, i_cons + k]) = [1,-1];

            % Panel A primitives.
            cf_v(bb) = A(i_exret,:)*VarYY*A(i_rrdiff,:)';
            cf_t(bb) = sum(irtfp(:,i_exret).*irtfp(:,i_rrdiff));
            cf_n(bb) = sum(irnoise(:,i_exret).*irnoise(:,i_rrdiff));

            cr_v(bb) = A(i_deltaq,:)*B*VarYY*A(i_rrdiff,:)' - A(i_rrdiff,:)*VarYY*A(i_rrdiff,:)';
            cr_t(bb) = sum(irtfp(1:end-1,i_deltaq).*irtfp(2:end,i_rrdiff))     - sum(irtfp(:,i_rrdiff).*irtfp(:,i_rrdiff));
            cr_n(bb) = sum(irnoise(1:end-1,i_deltaq).*irnoise(2:end,i_rrdiff)) - sum(irnoise(:,i_rrdiff).*irnoise(:,i_rrdiff));

            vr_v(bb) = A(i_rrdiff,:)*VarYY*A(i_rrdiff,:)';
            vr_t(bb) = sum(irtfp(:,i_rrdiff).^2);
            vr_n(bb) = sum(irnoise(:,i_rrdiff).^2);

            ce_v(bb) = -A(i_cumeret,:)*VarYY*A(i_rrdiff,:)';
            ce_t(bb) = -sum(irtfp(:,i_cumeret).*irtfp(:,i_rrdiff));
            ce_n(bb) = -sum(irnoise(:,i_cumeret).*irnoise(:,i_rrdiff));

            if want_rlzd
                Bii2 = eye(nx);
                tv = NaN(erl,1); tt = NaN(erl,1); tn = NaN(erl,1);
                for ii = 1:erl
                    tv(ii) = A(i_deltaq,:)*Bii2*B*VarYY*A(i_rrdiff,:)' - A(i_rrdiff,:)*Bii2*VarYY*A(i_rrdiff,:)';
                    tt(ii) = sum(irtfp(1:end-ii,i_deltaq).*irtfp(1+ii:end,i_rrdiff))     - sum(irtfp(1:end-ii+1,i_rrdiff).*irtfp(ii:end,i_rrdiff));
                    tn(ii) = sum(irnoise(1:end-ii,i_deltaq).*irnoise(1+ii:end,i_rrdiff)) - sum(irnoise(1:end-ii+1,i_rrdiff).*irnoise(ii:end,i_rrdiff));
                    Bii2 = Bii2*B;
                end
                % Only the sums over lags are kept.
                cev(bb) = sum(tv); cet(bb) = sum(tt); cen(bb) = sum(tn);
            end

            vq_v(bb) = A(i_deltaq,:)*VarYY*A(i_deltaq,:)';
            vq_t(bb) = sum(irtfp(:,i_deltaq).^2);
            vq_n(bb) = sum(irnoise(:,i_deltaq).^2);
            vq_c(bb) = vq_t(bb) + vq_n(bb);

            rr_v(bb) = (A(i_rrdiff,:)*B*VarYY*A(i_rrdiff,:)')/vr_v(bb);
            rr_t(bb) = sum(irtfp(1:end-1,i_rrdiff).*irtfp(2:end,i_rrdiff))/vr_t(bb);
            rr_n(bb) = sum(irnoise(1:end-1,i_rrdiff).*irnoise(2:end,i_rrdiff))/vr_n(bb);
            rr_c(bb) = (sum(irnoise(1:end-1,i_rrdiff).*irnoise(2:end,i_rrdiff)) + sum(irtfp(1:end-1,i_rrdiff).*irtfp(2:end,i_rrdiff)))/(vr_n(bb) + vr_t(bb));

            % Panel B primitives.
            vl_t(bb) = sum(dif(irtfp,i_qlambda).^2);
            vl_n(bb) = sum(dif(irnoise,i_qlambda).^2);
            vl_c(bb) = vl_t(bb) + vl_n(bb);
            vl_v(bb) = 2*A(i_qlambda,:)*VarYY*A(i_qlambda,:)' - A(i_qlambda,:)*B*VarYY*A(i_qlambda,:)' - A(i_qlambda,:)*VarYY*(A(i_qlambda,:)*B)';

            cq_v(bb) = (A(i_deltaq,:)*VarYY*A_dcdiff')/(sqrt(A(i_deltaq,:)*VarYY*A(i_deltaq,:)')*sqrt(A_dcdiff*VarYY*A_dcdiff'));
            cq_t(bb) = sum(irtfp(1:end-1,i_deltaq).*dcd_t)/(sqrt(vq_t(bb))*sqrt(sum(dcd_t.^2)));
            cq_n(bb) = sum(irnoise(1:end-1,i_deltaq).*dcd_n)/(sqrt(vq_n(bb))*sqrt(sum(dcd_n.^2)));
            cq_c(bb) = (sum(irtfp(1:end-1,i_deltaq).*dcd_t) + sum(irnoise(1:end-1,i_deltaq).*dcd_n))/(sqrt(vq_n(bb)+vq_t(bb))*sqrt(sum(dcd_t.^2)+sum(dcd_n.^2)));

            kq_v(bb) = A(i_deltaq,:)*VarYY*A_dcdiff';
            kq_t(bb) = sum(irtfp(1:end-1,i_deltaq).*dcd_t);
            kq_n(bb) = sum(irnoise(1:end-1,i_deltaq).*dcd_n);
            kq_c(bb) = kq_t(bb) + kq_n(bb);

            vd_v(bb) = A_dcdiff*VarYY*A_dcdiff';
            vd_t(bb) = sum(dcd_t.^2);
            vd_n(bb) = sum(dcd_n.^2);
            vd_c(bb) = vd_t(bb) + vd_n(bb);

            pu_t(bb) = sum(dif(irtfp,i_quip).*dcd_t);
            pu_n(bb) = sum(dif(irnoise,i_quip).*dcd_n);
            pl_t(bb) = sum(dif(irtfp,i_qlambda).*dcd_t);
            pl_n(bb) = sum(dif(irnoise,i_qlambda).*dcd_n);
            pl_v(bb) = 2*A(i_qlambda,:)*VarYY*A_consdiff' - A(i_qlambda,:)*B*VarYY*A_consdiff' - A(i_qlambda,:)*VarYY*(A_consdiff*B)';

            rd_v(bb) = (A(i_deltaq,:)*B*VarYY*A(i_deltaq,:)')/vq_v(bb);
            rq_v(bb) = (A(i_rer,:)*B*VarYY*A(i_rer,:)')/(A(i_rer,:)*VarYY*A(i_rer,:)');

            rl_t(bb) = sum(dif2(irtfp,i_qlambda,1).*dif2(irtfp,i_qlambda,2))/sum(dif2(irtfp,i_qlambda,1).^2);
            rl_n(bb) = sum(dif2(irnoise,i_qlambda,1).*dif2(irnoise,i_qlambda,2))/sum(dif2(irnoise,i_qlambda,1).^2);
            rl_c(bb) = (sum(dif2(irnoise,i_qlambda,1).*dif2(irnoise,i_qlambda,2)) + sum(dif2(irtfp,i_qlambda,1).*dif2(irtfp,i_qlambda,2)))/sum(dif2(irnoise,i_qlambda,1).^2 + dif2(irtfp,i_qlambda,1).^2);

            rd_t(bb) = sum(irtfp(1:end-1,i_deltaq).*irtfp(2:end,i_deltaq))/vq_t(bb);
            rq_t(bb) = sum(irtfp(1:end-1,i_rer).*irtfp(2:end,i_rer))/sum(irtfp(:,i_rer).^2);
            rd_n(bb) = sum(irnoise(1:end-1,i_deltaq).*irnoise(2:end,i_deltaq))/vq_n(bb);
            rq_n(bb) = sum(irnoise(1:end-1,i_rer).*irnoise(2:end,i_rer))/sum(irnoise(:,i_rer).^2);
            rd_c(bb) = (sum(irtfp(1:end-1,i_deltaq).*irtfp(2:end,i_deltaq)) + sum(irnoise(1:end-1,i_deltaq).*irnoise(2:end,i_deltaq)))/(vq_n(bb)+vq_t(bb));
            rq_c(bb) = (sum(irtfp(1:end-1,i_rer).*irtfp(2:end,i_rer)) + sum(irnoise(1:end-1,i_rer).*irnoise(2:end,i_rer)))/(sum(irnoise(:,i_rer).^2)+sum(irtfp(:,i_rer).^2));

            vc_v(bb) = A_dc*VarYY*A_dc';
            vc_t(bb) = sum(dif(irtfp,i_cons).^2);
            vc_n(bb) = sum(dif(irnoise,i_cons).^2);
            vc_c(bb) = vc_t(bb) + vc_n(bb);

            dq_v(bb) = A(i_deltaq,:)*VarYY*A(i_deltaq,:)';
            dq_t(bb) = sum(irtfp(:,i_deltaq).^2);
            dq_n(bb) = sum(irnoise(:,i_deltaq).^2);
            dq_c(bb) = dq_t(bb) + dq_n(bb);
            vQ_v(bb) = A(i_rer,:)*VarYY*A(i_rer,:)';
        end

        % Store the accumulators under their moment names.
        M.covfama_var=cf_v;  M.covfama_tfp=cf_t;  M.covfama_noise=cf_n;  M.covfama_comp=cf_t+cf_n;
        M.covfama_rlzd_var=cr_v; M.covfama_rlzd_tfp=cr_t; M.covfama_rlzd_noise=cr_n; M.covfama_rlzd_comp=cr_t+cr_n;
        M.covengel_var=ce_v; M.covengel_tfp=ce_t; M.covengel_noise=ce_n; M.covengel_comp=ce_t+ce_n;
        M.var_rrdiff_var=vr_v; M.var_rrdiff_tfp=vr_t; M.var_rrdiff_noise=vr_n; M.var_rrdiff_comp=vr_t+vr_n;
        M.var_deltaq_var=vq_v; M.var_deltaq_tfp=vq_t; M.var_deltaq_noise=vq_n; M.var_deltaq_comp=vq_c;
        M.rho_rdiff_var=rr_v; M.rho_rdiff_tfp=rr_t; M.rho_rdiff_noise=rr_n; M.rho_rdiff_comp=rr_c;
        M.var_dqlambda_var=vl_v; M.var_dqlambda_tfp=vl_t; M.var_dqlambda_noise=vl_n; M.var_dqlambda_comp=vl_c;
        M.corr_dq_dcdiff_var=cq_v; M.corr_dq_dcdiff_tfp=cq_t; M.corr_dq_dcdiff_noise=cq_n; M.corr_dq_dcdiff_comp=cq_c;
        M.cov_dq_dcdiff_var=kq_v; M.cov_dq_dcdiff_tfp=kq_t; M.cov_dq_dcdiff_noise=kq_n; M.cov_dq_dcdiff_comp=kq_c;
        M.var_dcdiff_var=vd_v; M.var_dcdiff_tfp=vd_t; M.var_dcdiff_noise=vd_n; M.var_dcdiff_comp=vd_c;
        M.var_deltac_var=vc_v; M.var_deltac_tfp=vc_t; M.var_deltac_noise=vc_n; M.var_deltac_comp=vc_c;
        M.var_dq_var=dq_v; M.var_dq_tfp=dq_t; M.var_dq_noise=dq_n; M.var_dq_comp=dq_c;
        M.rho_deltaq_var=rd_v; M.rho_deltaq_tfp=rd_t; M.rho_deltaq_noise=rd_n; M.rho_deltaq_comp=rd_c;
        M.rho_qt_var=rq_v; M.rho_qt_tfp=rq_t; M.rho_qt_noise=rq_n; M.rho_qt_comp=rq_c;
        M.rho_dqlambda_tfp=rl_t; M.rho_dqlambda_noise=rl_n; M.rho_dqlambda_comp=rl_c;
        M.cov_dquip_dcdiff_tfp=pu_t; M.cov_dquip_dcdiff_noise=pu_n;
        M.cov_dqlambda_dcdiff_tfp=pl_t; M.cov_dqlambda_dcdiff_noise=pl_n; M.cov_dqlambda_dcdiff_var=pl_v;
        M.var_q_var=vQ_v;
        if want_rlzd
            M.covengel_rlzd_var=cev; M.covengel_rlzd_tfp=cet; M.covengel_rlzd_noise=cen;
            M.covengel_rlzd_comp=cet+cen;
        end
    end

    % Table statistics. The last element of each array is the point estimate;
    % consumers drop it before taking medians and percentiles.
    trim1 = @(x) x(1:end-1); %#ok<NASGU>  (documented convention; applied by consumers)
    S = struct();
    S.beta_fama   = ratio(M,'covfama','var_rrdiff');
    S.cov_fama    = pick(M,'covfama');
    S.beta_engel  = ratio(M,'covengel','var_rrdiff');
    S.cov_engel   = pick(M,'covengel');
    S.sig_ratio   = sqrtratio(M,'var_rrdiff','var_deltaq');
    S.rho_rdiff   = pick(M,'rho_rdiff');
    S.corr_dq_dcd = pick(M,'corr_dq_dcdiff');
    S.cov_dq_dcd  = pick(M,'cov_dq_dcdiff');
    S.rho_deltaq  = pick(M,'rho_deltaq');
    S.rho_qt      = pick(M,'rho_qt');
    S.sig_dq_dc   = sqrtratio(M,'var_dq','var_deltac');
    if opt.want_rlzd
        S.beta_fama_rlzd  = ratio(M,'covfama_rlzd','var_rrdiff');
        S.beta_engel_rlzd = ratio(M,'covengel_rlzd','var_rrdiff');
    end

    R = struct('m',M, 'stats',S, 'skipped',{skipped}, 'ix',ix, 'pp',opt.pp, ...
               'meta',struct('ndraws',NN-1,'nvars',k,'nlags',nlags,'case',cname, ...
                             'panelA',okA,'panelB',okB));
    % R holds no function handle, so it can be saved in the run file.
end

% Helpers
function d = dif(x, c)
% First difference down a column: x(1:end-1,c) - x(2:end,c).
    d = x(1:end-1,c) - x(2:end,c);
end

function d = dif2(x, c, which)
% The two staggered first differences used by rho_dqlambda: which=1 gives
% x(1:end-2)-x(2:end-1), which=2 gives x(2:end-1)-x(3:end).
    if which == 1
        d = x(1:end-2,c) - x(2:end-1,c);
    else
        d = x(2:end-1,c) - x(3:end,c);
    end
end

function s = pick(M, base)
    for f = {'tfp','noise','comp','var'}
        k = [base '_' f{1}];
        if isfield(M,k); s.(f{1}) = M.(k); else; s.(f{1}) = NaN(size(M.covfama_var)); end
    end
end

function s = ratio(M, num, den)
    for f = {'tfp','noise','comp','var'}
        s.(f{1}) = M.([num '_' f{1}]) ./ M.([den '_' f{1}]);
    end
end

function s = sqrtratio(M, num, den)
    for f = {'tfp','noise','comp','var'}
        s.(f{1}) = sqrt(M.([num '_' f{1}]) ./ M.([den '_' f{1}]));
    end
end
