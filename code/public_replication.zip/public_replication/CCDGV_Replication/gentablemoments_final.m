function R = gentablemoments_final(datam, opt)
%GENTABLEMOMENTS_FINAL  Table 3 moments: exchange-rate puzzles and TFP expectations.
%
%   R = GENTABLEMOMENTS_FINAL(DATAM, OPT)
%
%   Function rewrite of gentablemoments_v6.m, which stays on disk as the
%   regression reference. EVERY EXPRESSION'S ARITHMETIC IS UNCHANGED -- the only
%   substantive difference is that variable positions are resolved BY NAME.
%
%   WHAT CHANGED AND WHY
%
%   1. NAME RESOLUTION (the reason this exists). v6 hard-codes sixteen positions
%      at :31-46 -- ocons=2, orrdiff=12, odeltaq=18, oquip=26 ... -- and uses
%      them 120+ times. Correct only for the 8-variable baseline. On an equity
%      layout, US/G6 equity are inserted at 9-10 and everything
%      from E[TFP] shifts +2, so v6 silently computes:
%          orrdiff  = 12  -> ENER                (not Interest Rate Differential)
%          odeltaq  = 18  -> BS Wedge            (not $\Delta q_t$)
%          ocumeret = 19  -> $\Delta$BS Wedge    (not RER(Ex. Ret))
%      Every Table 3 moment is built from those. Nothing errors; the table is
%      simply computed on the wrong series. ccdgv_moment_vars resolves by name.
%
%   2. NO `Country` STRUCT. v6:55-56 built a 1x7 struct array under `for jj = 7`,
%      so elements 1-6 were empty and only element 7 held anything. It existed to
%      carry one load() result, was unpacked into six plain variables 15 lines
%      later, and never referenced again -- a vestige of a loop over seven
%      per-country snapshots, six of which no longer exist (COUNTRIES_IRF still
%      names them; only element 7 ever passed through sweep_datam).
%
%   3. RETURNS ITS RESULTS. v6 is a script: everything died with the workspace,
%      and the table was two hand-concatenated disp blocks. Presentation now
%      lives in write_moments_table.
%
%   4. MISSING VARIABLES ARE SKIPPED, NOT SUBSTITUTED. Moments are gated per
%      panel on the variables they need. A layout lacking one (a noFX spec has no
%      NER, hence no Delta q or excess returns) yields NaN for that panel and an
%      entry in R.skipped naming the moment and the missing variable -- never a
%      silent stand-in.
%
%   DO NOT "OPTIMISE" VarYY. The unconditional variance is accumulated as
%   sum_i B^i Sig B^i' over at least 1001 terms (:166-171 in v6, preserved here).
%   Smith doubling would converge in ~20 iterations and is tempting, because this
%   is the dominant per-draw cost. It would be WRONG: several posterior draws sit
%   at or very near a unit root, where the unconditional variance does not exist.
%   The truncation is a deliberate FINITE-HORIZON variance, not an approximation
%   error, and doubling would drive it toward a limit that is singular for exactly
%   those draws. (dlyap is unavailable here anyway -- no Control System Toolbox.)
%
%   INPUT
%     DATAM  case .mat name from run_main (resolved through sweep_datam) or a
%            struct. Needs ARs, Sigs, irtfp, irnoise, j_cj_horizon, vnames.
%     OPT    .engel_rlzd_limit  default 2500 (as v6)
%            .pp                percentile for the reported bounds, default 16
%
%   OUTPUT R
%     R.m        struct of moment arrays, each 1 x ndraws+1, named as in v6
%                (covfama_tfp, var_rrdiff_var, rho_qt_comp, ...)
%     R.stats    the derived table statistics, each with .tfp/.noise/.comp/.var
%     R.skipped  cell array of {moment_block, missing_variable} pairs
%     R.ix       the resolved indices, for auditing
%     R.meta     ndraws, nvars, nlags, case name
%
%   See also CCDGV_MOMENT_VARS, WRITE_MOMENTS_TABLE.

    if nargin < 2; opt = struct(); end
    if ~isfield(opt,'engel_rlzd_limit'); opt.engel_rlzd_limit = 2500; end
    if ~isfield(opt,'pp');               opt.pp               = 16;   end
    % The engel_rlzd loop runs engel_rlzd_limit (2500) iterations PER DRAW and is
    % the single largest cost in this file. Its only consumers in v6 are
    % beta_fama_rlzd / beta_engel_rlzd / covengel_rlzd (:290-311), and grep shows
    % NONE of those reaches a disp -- they are computed and discarded. Off by
    % default; set want_rlzd=true to get them back.
    if ~isfield(opt,'want_rlzd');        opt.want_rlzd        = false; end

    if isstruct(datam)
        D = datam;  cname = 'struct';
    else
        % datam is the path itself -- callers pass data_name(info). The old
        % sweep_datam indirection (an env var read inside the function) is gone.
        D = load(datam);  cname = datam;
        % run_main SAVES irtfp/irnoise on +/-smax_store only; these moments need
        % the full +/-smax, which exists only in memory there. It computes them
        % and saves them as `moments`/`filtered_moments` -- read those instead.
        if isfield(D,'info') && isfield(D,'irtfp')
            assert(size(D.irtfp,1) == 2*D.info.settings.smax+1, 'gentablemoments_final:window', ...
                ['%s stores responses on +/-%d quarters, short of smax = %d; the ' ...
                 'moments need the full length. Re-run run_main for this case.'], ...
                datam, (size(D.irtfp,1)-1)/2, D.info.settings.smax);
        end
    end
    for f = {'ARs','Sigs','irtfp','irnoise','j_cj_horizon','vnames','Aproj','keys'}
        assert(isfield(D,f{1}), 'gentablemoments_final:missing', ...
            '%s not in the case file.', f{1});
    end

    ix = ccdgv_moment_vars(D.vnames);

    % ---- per-panel gating ------------------------------------------------
    % Panel A (forward-premium moments) and Panel B (Backus-Smith) need
    % different variables, so a layout can support one and not the other.
    NEED_A = {'exret','rrdiff','deltaq','cumeret'};
    NEED_B = {'cons','consf','deltaq','consdiff','rer','qlambda','quip'};
    skipped = {};

    % A name can resolve to a position the DATA does not have -- vnames is the
    % full 26/28-entry label list while irtfp carries only the auxiliary-variable
    % columns gen_auxvars actually built. Treat out-of-range exactly like absent,
    % so it is recorded and skipped rather than blowing up inside the parfor with
    % "Index in position 2 exceeds array bounds".
    ncol = size(D.irtfp,2);
    for f = fieldnames(ix)'
        if strcmp(f{1},'names_'); continue; end
        if ~isnan(ix.(f{1})) && ix.(f{1}) > ncol
            ix.(f{1}) = NaN;
        end
    end
    okA = true; okB = true;
    for f = NEED_A
        if isnan(ix.(f{1})); okA = false; skipped(end+1,:) = {'Panel A', f{1}}; end %#ok<AGROW>
    end
    for f = NEED_B
        if isnan(ix.(f{1})); okB = false; skipped(end+1,:) = {'Panel B', f{1}}; end %#ok<AGROW>
    end
    if ~okA || ~okB
        warning('gentablemoments_final:skipped', ...
            ['%d moment block(s) skipped -- this VAR layout lacks: %s. ' ...
             'Those rows will be NaN; see R.skipped.'], ...
            (~okA)+(~okB), strjoin(unique(skipped(:,2))', ', '));
    end

    Aproj = D.Aproj; keys = D.keys;   % projections + their names, from the run
    ARs = D.ARs; Sigs = D.Sigs;
    irtfp_all = D.irtfp; irnoise_all = D.irnoise;
    j_cj = D.j_cj_horizon;
    NN = numel(ARs);
    [k, nxx] = size(ARs{1});  nlags = nxx/k;
    erl = opt.engel_rlzd_limit;
    want_rlzd = opt.want_rlzd;

    % index locals: parfor cannot see struct field references cleanly
    i_cons=ix.cons; i_consf=ix.consf; i_exret=ix.exret; i_rrdiff=ix.rrdiff;
    i_rer=ix.rer; i_deltaq=ix.deltaq; i_cumeret=ix.cumeret; i_consdiff=ix.consdiff;
    i_quip=ix.quip; i_qlambda=ix.qlambda;

    nm = { 'covfama','covfama_rlzd','covengel','var_rrdiff','var_deltaq','rho_rdiff', ...
           'var_dqlambda','corr_dq_dcdiff','cov_dq_dcdiff','var_dcdiff','var_deltac', ...
           'var_dq','rho_deltaq','rho_qt','rho_dqlambda','cov_dquip_dcdiff', ...
           'cov_dqlambda_dcdiff','var_q' };
    sfx = {'var','tfp','noise','comp'};
    M = struct();
    for a = nm, for b = sfx, M.([a{1} '_' b{1}]) = NaN(1,NN); end, end

    if okA || okB
        % local slices for parfor
        cf_v=NaN(1,NN); cf_t=NaN(1,NN); cf_n=NaN(1,NN);
        cr_v=NaN(1,NN); cr_t=NaN(1,NN); cr_n=NaN(1,NN);
        ce_v=NaN(1,NN); ce_t=NaN(1,NN); ce_n=NaN(1,NN);
        vr_v=NaN(1,NN); vr_t=NaN(1,NN); vr_n=NaN(1,NN);
        vq_v=NaN(1,NN); vq_t=NaN(1,NN); vq_n=NaN(1,NN); vq_c=NaN(1,NN);
        rr_v=NaN(1,NN); rr_t=NaN(1,NN); rr_n=NaN(1,NN); rr_c=NaN(1,NN);
        vl_v=NaN(1,NN); vl_t=NaN(1,NN); vl_n=NaN(1,NN); vl_c=NaN(1,NN);
        cq_v=NaN(1,NN); cq_t=NaN(1,NN); cq_n=NaN(1,NN); cq_c=NaN(1,NN);
        kq_v=NaN(1,NN); kq_t=NaN(1,NN); kq_n=NaN(1,NN); kq_c=NaN(1,NN);
        vd_v=NaN(1,NN); vd_t=NaN(1,NN); vd_n=NaN(1,NN); vd_c=NaN(1,NN);
        vc_v=NaN(1,NN); vc_t=NaN(1,NN); vc_n=NaN(1,NN); vc_c=NaN(1,NN);
        dq_v=NaN(1,NN); dq_t=NaN(1,NN); dq_n=NaN(1,NN); dq_c=NaN(1,NN);
        rd_v=NaN(1,NN); rd_t=NaN(1,NN); rd_n=NaN(1,NN); rd_c=NaN(1,NN);
        rq_v=NaN(1,NN); rq_t=NaN(1,NN); rq_n=NaN(1,NN); rq_c=NaN(1,NN);
        rl_t=NaN(1,NN); rl_n=NaN(1,NN); rl_c=NaN(1,NN);
        pu_t=NaN(1,NN); pu_n=NaN(1,NN);
        pl_t=NaN(1,NN); pl_n=NaN(1,NN); pl_v=NaN(1,NN);
        vQ_v=NaN(1,NN);
        cev=NaN(1,NN); cet=NaN(1,NN); cen=NaN(1,NN);   % column sums only

        parfor bb = 1:NN
            AR  = ARs{bb};
            Sig = Sigs{bb};
            nx  = size(AR,2);
            B   = [AR;[eye(nx-k),zeros(nx-k,k)]];
            Atilde = chol(Sig)';
            U   = [Atilde;zeros(k*(nlags-1),k)];
            [A,~,~,~,~,~] = gen_auxvars(AR',Aproj,keys,k,nlags,j_cj);

            % --- unconditional variance: TRUNCATED sum, deliberately. See header.
            VarYY = zeros(size(B));
            Sig_aug = U*U';
            Bii = eye(nx);
            % CAPPED AT 10000. The horizon is deliberately finite (see the header
            % note), but its draw-dependent length was UNBOUNDED as max|eig| -> 1.
            % Spec 7 asked for up to 3.2e8 terms per draw -- 121x the baseline's
            % TOTAL -- which was 15 of that run's 29 minutes. Every draw still gets
            % at least the 1000 terms it always had.
            %
            % ON A TRANSFORMED SPEC THE RESULT IS NOT MEANINGFUL AT ANY HORIZON.
            % Spec 7 carries a VECM basis stored in levels, so unit roots are
            % structural, not incidental: all 1001 draws sit above 0.9999 and the
            % median max|eig| is 1.0000029. The unconditional variance does not
            % exist there, so this sum is not converging to anything -- the cap
            % bounds the cost of a number that should not be read. Table 3 is built
            % from the BASELINE, which is why nothing downstream consumes it.
            %
            % Effect on the baseline, measured over 1001 draws: 54 hit the cap, no
            % reported Table 3 median moves at the table's 2 decimals, and 4 of 44
            % cells shift one band edge by 0.01 (worst cell 0.39% in full precision).
            sum_cutoff = min(max([log(0.01)/log(max(abs(eig(B)))),1000]), 10000);
            for ii = 0:sum_cutoff
                VarYY = VarYY + Bii*Sig_aug*(Bii)';
                Bii = Bii*B;
            end

            irtfp   = flip(cumsum(irtfp_all(:,:,bb)));
            irnoise = flip(cumsum(irnoise_all(:,:,bb)));

            % Delta(c - c*) along each conditional IRF. In v6 this 100-character
            % subexpression is written out ten times; here once per draw.
            dcd_t = dif(irtfp,i_cons)   - dif(irtfp,i_consf);
            dcd_n = dif(irnoise,i_cons) - dif(irnoise,i_consf);

            % A-rows. v6 reuses one variable `Atemp` for THREE different
            % functionals (:225-227, :244, :264-265); named separately here.
            A_dcdiff = A(i_consdiff,:);          % consumption differential, modified
            A_dcdiff(i_cons  + k) = -1;
            A_dcdiff(i_consf + k) =  1;
            A_consdiff = A(i_consdiff,:);        % plain, as v6 re-assigns at :244
            A_dc = zeros(1,nx);                  % first difference of home consumption
            A_dc([i_cons, i_cons + k]) = [1,-1];

            % ---- Panel A primitives ---------------------------------------
            cf_v(bb) = A(i_exret,:)*VarYY*A(i_rrdiff,:)';
            cf_t(bb) = sum(irtfp(:,i_exret).*irtfp(:,i_rrdiff));
            cf_n(bb) = sum(irnoise(:,i_exret).*irnoise(:,i_rrdiff));

            cr_v(bb) = A(i_deltaq,:)*B*VarYY*A(i_rrdiff,:)' - A(i_rrdiff,:)*VarYY*A(i_rrdiff,:)';
            cr_t(bb) = sum(irtfp(1:end-1,i_deltaq).*irtfp(2:end,i_rrdiff))     - sum(irtfp(:,i_rrdiff).*irtfp(:,i_rrdiff));
            cr_n(bb) = sum(irnoise(1:end-1,i_deltaq).*irnoise(2:end,i_rrdiff)) - sum(irnoise(:,i_rrdiff).*irnoise(:,i_rrdiff));

            vr_v(bb) = A(i_rrdiff,:)*VarYY*A(i_rrdiff,:)';
            vr_t(bb) = sum(irtfp(:,i_rrdiff).^2);
            vr_n(bb) = sum(irnoise(:,i_rrdiff).^2);

            ce_v(bb) = -A(i_cumeret,:)*VarYY*A(i_rrdiff,:)';
            ce_t(bb) = -sum(irtfp(:,i_cumeret).*irtfp(:,i_rrdiff));
            ce_n(bb) = -sum(irnoise(:,i_cumeret).*irnoise(:,i_rrdiff));

            if want_rlzd
                Bii2 = eye(nx);
                tv = NaN(erl,1); tt = NaN(erl,1); tn = NaN(erl,1);
                for ii = 1:erl
                    tv(ii) = A(i_deltaq,:)*Bii2*B*VarYY*A(i_rrdiff,:)' - A(i_rrdiff,:)*Bii2*VarYY*A(i_rrdiff,:)';
                    tt(ii) = sum(irtfp(1:end-ii,i_deltaq).*irtfp(1+ii:end,i_rrdiff))     - sum(irtfp(1:end-ii+1,i_rrdiff).*irtfp(ii:end,i_rrdiff));
                    tn(ii) = sum(irnoise(1:end-ii,i_deltaq).*irnoise(1+ii:end,i_rrdiff)) - sum(irnoise(1:end-ii+1,i_rrdiff).*irnoise(ii:end,i_rrdiff));
                    Bii2 = Bii2*B;
                end
                % v6 keeps the whole erl x NN matrix but only ever uses sum(.,1)
                % (:307-311, :291-303). Sum here; the matrix is never needed.
                cev(bb) = sum(tv); cet(bb) = sum(tt); cen(bb) = sum(tn);
            end

            vq_v(bb) = A(i_deltaq,:)*VarYY*A(i_deltaq,:)';
            vq_t(bb) = sum(irtfp(:,i_deltaq).^2);
            vq_n(bb) = sum(irnoise(:,i_deltaq).^2);
            vq_c(bb) = vq_t(bb) + vq_n(bb);

            rr_v(bb) = (A(i_rrdiff,:)*B*VarYY*A(i_rrdiff,:)')/vr_v(bb);
            rr_t(bb) = sum(irtfp(1:end-1,i_rrdiff).*irtfp(2:end,i_rrdiff))/vr_t(bb);
            rr_n(bb) = sum(irnoise(1:end-1,i_rrdiff).*irnoise(2:end,i_rrdiff))/vr_n(bb);
            rr_c(bb) = (sum(irnoise(1:end-1,i_rrdiff).*irnoise(2:end,i_rrdiff)) + sum(irtfp(1:end-1,i_rrdiff).*irtfp(2:end,i_rrdiff)))/(vr_n(bb) + vr_t(bb));

            % ---- Panel B primitives ---------------------------------------
            vl_t(bb) = sum(dif(irtfp,i_qlambda).^2);
            vl_n(bb) = sum(dif(irnoise,i_qlambda).^2);
            vl_c(bb) = vl_t(bb) + vl_n(bb);
            vl_v(bb) = 2*A(i_qlambda,:)*VarYY*A(i_qlambda,:)' - A(i_qlambda,:)*B*VarYY*A(i_qlambda,:)' - A(i_qlambda,:)*VarYY*(A(i_qlambda,:)*B)';

            cq_v(bb) = (A(i_deltaq,:)*VarYY*A_dcdiff')/(sqrt(A(i_deltaq,:)*VarYY*A(i_deltaq,:)')*sqrt(A_dcdiff*VarYY*A_dcdiff'));
            cq_t(bb) = sum(irtfp(1:end-1,i_deltaq).*dcd_t)/(sqrt(vq_t(bb))*sqrt(sum(dcd_t.^2)));
            cq_n(bb) = sum(irnoise(1:end-1,i_deltaq).*dcd_n)/(sqrt(vq_n(bb))*sqrt(sum(dcd_n.^2)));
            cq_c(bb) = (sum(irtfp(1:end-1,i_deltaq).*dcd_t) + sum(irnoise(1:end-1,i_deltaq).*dcd_n))/(sqrt(vq_n(bb)+vq_t(bb))*sqrt(sum(dcd_t.^2)+sum(dcd_n.^2)));

            kq_v(bb) = A(i_deltaq,:)*VarYY*A_dcdiff';
            kq_t(bb) = sum(irtfp(1:end-1,i_deltaq).*dcd_t);
            kq_n(bb) = sum(irnoise(1:end-1,i_deltaq).*dcd_n);
            kq_c(bb) = kq_t(bb) + kq_n(bb);

            vd_v(bb) = A_dcdiff*VarYY*A_dcdiff';
            vd_t(bb) = sum(dcd_t.^2);
            vd_n(bb) = sum(dcd_n.^2);
            vd_c(bb) = vd_t(bb) + vd_n(bb);

            pu_t(bb) = sum(dif(irtfp,i_quip).*dcd_t);
            pu_n(bb) = sum(dif(irnoise,i_quip).*dcd_n);
            pl_t(bb) = sum(dif(irtfp,i_qlambda).*dcd_t);
            pl_n(bb) = sum(dif(irnoise,i_qlambda).*dcd_n);
            pl_v(bb) = 2*A(i_qlambda,:)*VarYY*A_consdiff' - A(i_qlambda,:)*B*VarYY*A_consdiff' - A(i_qlambda,:)*VarYY*(A_consdiff*B)';

            rd_v(bb) = (A(i_deltaq,:)*B*VarYY*A(i_deltaq,:)')/vq_v(bb);
            rq_v(bb) = (A(i_rer,:)*B*VarYY*A(i_rer,:)')/(A(i_rer,:)*VarYY*A(i_rer,:)');

            rl_t(bb) = sum(dif2(irtfp,i_qlambda,1).*dif2(irtfp,i_qlambda,2))/sum(dif2(irtfp,i_qlambda,1).^2);
            rl_n(bb) = sum(dif2(irnoise,i_qlambda,1).*dif2(irnoise,i_qlambda,2))/sum(dif2(irnoise,i_qlambda,1).^2);
            rl_c(bb) = (sum(dif2(irnoise,i_qlambda,1).*dif2(irnoise,i_qlambda,2)) + sum(dif2(irtfp,i_qlambda,1).*dif2(irtfp,i_qlambda,2)))/sum(dif2(irnoise,i_qlambda,1).^2 + dif2(irtfp,i_qlambda,1).^2);

            rd_t(bb) = sum(irtfp(1:end-1,i_deltaq).*irtfp(2:end,i_deltaq))/vq_t(bb);
            rq_t(bb) = sum(irtfp(1:end-1,i_rer).*irtfp(2:end,i_rer))/sum(irtfp(:,i_rer).^2);
            rd_n(bb) = sum(irnoise(1:end-1,i_deltaq).*irnoise(2:end,i_deltaq))/vq_n(bb);
            rq_n(bb) = sum(irnoise(1:end-1,i_rer).*irnoise(2:end,i_rer))/sum(irnoise(:,i_rer).^2);
            rd_c(bb) = (sum(irtfp(1:end-1,i_deltaq).*irtfp(2:end,i_deltaq)) + sum(irnoise(1:end-1,i_deltaq).*irnoise(2:end,i_deltaq)))/(vq_n(bb)+vq_t(bb));
            rq_c(bb) = (sum(irtfp(1:end-1,i_rer).*irtfp(2:end,i_rer)) + sum(irnoise(1:end-1,i_rer).*irnoise(2:end,i_rer)))/(sum(irnoise(:,i_rer).^2)+sum(irtfp(:,i_rer).^2));

            vc_v(bb) = A_dc*VarYY*A_dc';
            vc_t(bb) = sum(dif(irtfp,i_cons).^2);
            vc_n(bb) = sum(dif(irnoise,i_cons).^2);
            vc_c(bb) = vc_t(bb) + vc_n(bb);

            dq_v(bb) = A(i_deltaq,:)*VarYY*A(i_deltaq,:)';
            dq_t(bb) = sum(irtfp(:,i_deltaq).^2);
            dq_n(bb) = sum(irnoise(:,i_deltaq).^2);
            dq_c(bb) = dq_t(bb) + dq_n(bb);
            vQ_v(bb) = A(i_rer,:)*VarYY*A(i_rer,:)';
        end

        M.covfama_var=cf_v;  M.covfama_tfp=cf_t;  M.covfama_noise=cf_n;  M.covfama_comp=cf_t+cf_n;
        M.covfama_rlzd_var=cr_v; M.covfama_rlzd_tfp=cr_t; M.covfama_rlzd_noise=cr_n; M.covfama_rlzd_comp=cr_t+cr_n;
        M.covengel_var=ce_v; M.covengel_tfp=ce_t; M.covengel_noise=ce_n; M.covengel_comp=ce_t+ce_n;
        M.var_rrdiff_var=vr_v; M.var_rrdiff_tfp=vr_t; M.var_rrdiff_noise=vr_n; M.var_rrdiff_comp=vr_t+vr_n;
        M.var_deltaq_var=vq_v; M.var_deltaq_tfp=vq_t; M.var_deltaq_noise=vq_n; M.var_deltaq_comp=vq_c;
        M.rho_rdiff_var=rr_v; M.rho_rdiff_tfp=rr_t; M.rho_rdiff_noise=rr_n; M.rho_rdiff_comp=rr_c;
        M.var_dqlambda_var=vl_v; M.var_dqlambda_tfp=vl_t; M.var_dqlambda_noise=vl_n; M.var_dqlambda_comp=vl_c;
        M.corr_dq_dcdiff_var=cq_v; M.corr_dq_dcdiff_tfp=cq_t; M.corr_dq_dcdiff_noise=cq_n; M.corr_dq_dcdiff_comp=cq_c;
        M.cov_dq_dcdiff_var=kq_v; M.cov_dq_dcdiff_tfp=kq_t; M.cov_dq_dcdiff_noise=kq_n; M.cov_dq_dcdiff_comp=kq_c;
        M.var_dcdiff_var=vd_v; M.var_dcdiff_tfp=vd_t; M.var_dcdiff_noise=vd_n; M.var_dcdiff_comp=vd_c;
        M.var_deltac_var=vc_v; M.var_deltac_tfp=vc_t; M.var_deltac_noise=vc_n; M.var_deltac_comp=vc_c;
        M.var_dq_var=dq_v; M.var_dq_tfp=dq_t; M.var_dq_noise=dq_n; M.var_dq_comp=dq_c;
        M.rho_deltaq_var=rd_v; M.rho_deltaq_tfp=rd_t; M.rho_deltaq_noise=rd_n; M.rho_deltaq_comp=rd_c;
        M.rho_qt_var=rq_v; M.rho_qt_tfp=rq_t; M.rho_qt_noise=rq_n; M.rho_qt_comp=rq_c;
        M.rho_dqlambda_tfp=rl_t; M.rho_dqlambda_noise=rl_n; M.rho_dqlambda_comp=rl_c;
        M.cov_dquip_dcdiff_tfp=pu_t; M.cov_dquip_dcdiff_noise=pu_n;
        M.cov_dqlambda_dcdiff_tfp=pl_t; M.cov_dqlambda_dcdiff_noise=pl_n; M.cov_dqlambda_dcdiff_var=pl_v;
        M.var_q_var=vQ_v;
        if want_rlzd
            M.covengel_rlzd_var=cev; M.covengel_rlzd_tfp=cet; M.covengel_rlzd_noise=cen;
            M.covengel_rlzd_comp=cet+cen;
        end
    end

    % ---- derived statistics ---------------------------------------------
    % (1:end-1) throughout: the last draw is the point estimate, excluded from
    % every median and percentile, exactly as v6 does.
    trim1 = @(x) x(1:end-1); %#ok<NASGU>  (documented convention; applied by consumers)
    S = struct();
    S.beta_fama   = ratio(M,'covfama','var_rrdiff');
    S.cov_fama    = pick(M,'covfama');
    S.beta_engel  = ratio(M,'covengel','var_rrdiff');
    S.cov_engel   = pick(M,'covengel');
    S.sig_ratio   = sqrtratio(M,'var_rrdiff','var_deltaq');
    S.rho_rdiff   = pick(M,'rho_rdiff');
    S.corr_dq_dcd = pick(M,'corr_dq_dcdiff');
    S.cov_dq_dcd  = pick(M,'cov_dq_dcdiff');
    S.rho_deltaq  = pick(M,'rho_deltaq');
    S.rho_qt      = pick(M,'rho_qt');
    S.sig_dq_dc   = sqrtratio(M,'var_dq','var_deltac');
    if opt.want_rlzd
        S.beta_fama_rlzd  = ratio(M,'covfama_rlzd','var_rrdiff');
        S.beta_engel_rlzd = ratio(M,'covengel_rlzd','var_rrdiff');
    end

    R = struct('m',M, 'stats',S, 'skipped',{skipped}, 'ix',ix, 'pp',opt.pp, ...
               'meta',struct('ndraws',NN-1,'nvars',k,'nlags',nlags,'case',cname, ...
                             'panelA',okA,'panelB',okB));
    % NB no function handle in R: it has to survive save() into the case .mat.
end

% ---- helpers -------------------------------------------------------------
function d = dif(x, c)
% First difference along an IRF column, in the flipped/cumulated orientation
% v6 uses: x(1:end-1,c) - x(2:end,c).
    d = x(1:end-1,c) - x(2:end,c);
end

function d = dif2(x, c, which)
% The two staggered first differences used by rho_dqlambda: which=1 gives
% x(1:end-2)-x(2:end-1), which=2 gives x(2:end-1)-x(3:end).
    if which == 1
        d = x(1:end-2,c) - x(2:end-1,c);
    else
        d = x(2:end-1,c) - x(3:end,c);
    end
end

function s = pick(M, base)
    for f = {'tfp','noise','comp','var'}
        k = [base '_' f{1}];
        if isfield(M,k); s.(f{1}) = M.(k); else; s.(f{1}) = NaN(size(M.covfama_var)); end
    end
end

function s = ratio(M, num, den)
    for f = {'tfp','noise','comp','var'}
        s.(f{1}) = M.([num '_' f{1}]) ./ M.([den '_' f{1}]);
    end
end

function s = sqrtratio(M, num, den)
    for f = {'tfp','noise','comp','var'}
        s.(f{1}) = sqrt(M.([num '_' f{1}]) ./ M.([den '_' f{1}]));
    end
end
