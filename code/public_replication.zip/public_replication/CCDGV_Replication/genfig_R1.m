function fout = genfig_R1(base_info, alts, dest, opt)
%GENFIG_R1  Figure R.1 -- CJ disturbance series, baseline against the no-FX
%           asset specifications.
%
%   fout = GENFIG_R1(base_info, alts)
%   fout = GENFIG_R1(base_info, alts, dest)
%   fout = GENFIG_R1(base_info, alts, dest, opt)
%
%   base_info  the baseline run, grey solid -- as in Figure B.11
%   alts       n x 2 cell, {legend label, info} per additional series. A row
%              whose info is empty is DROPPED and reported, so a sweep missing
%              one spec still draws the figure rather than failing.
%   opt.name   output stem; default 'shock_series_R1'
%
%   B.11 WITH ITS COMPARISON SWAPPED, not replaced. B.11 plots the baseline against
%   the VAR without the exchange rate. This plots the baseline against the two
%   specs that drop the exchange rate AND add an asset block -- equity (inclvar
%   4) and 10-year yields (inclvar 9). The plain no-FX line is deliberately
%   absent: the question here is what the asset rows add once FX is gone, and a
%   third reference line would only crowd the panel. B.11 is untouched and still
%   carries it.
%
%   READABILITY, WITH THREE SERIES ON ONE AXIS. B.11's two-series scheme (grey
%   solid vs black dashed) does not extend, so the series are separated on BOTH
%   colour and dash pattern rather than colour alone:
%       baseline   grey solid,  width 2   (B.11's own styling, unchanged)
%       equity     blue dashed, width 1.6
%       yields     red dash-dot, width 1.6
%   Dash patterns carry the distinction in greyscale print; the colours carry it
%   on screen. The overlays are slightly thinner so the baseline stays the
%   reference line where all three coincide, which over most of the sample they
%   do.
%
%   THE SHOCKS ARE THE CJ DISTURBANCES, from infer_shocks -- the two-sided MA of
%   TFP and E_t[TFP_{t+j}], not the max-share shocks. Same object as B.11.
%
%   See also GENFIG_B11, INFER_SHOCKS, GENFIG_R23.

    assert(nargin >= 3 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end
    if nargin < 4; opt = struct(); end
    name = 'shock_series_R1';
    if isfield(opt,'name') && ~isempty(opt.name); name = opt.name; end

    keep = ~cellfun(@isempty, alts(:,2));
    if any(~keep)
        fprintf('  R.1: no run for %s -- omitted from the figure\n', ...
                strjoin(alts(~keep,1)', ', '));
    end
    alts = alts(keep,:);
    assert(~isempty(alts), 'genfig_R1:noAlts', 'no alternative specs supplied');

    % ---- shocks, then a common calendar ------------------------------------
    S = cell(1, size(alts,1)+1);
    S{1} = infer_shocks(base_info);
    for j = 1:size(alts,1); S{j+1} = infer_shocks(alts{j,2}); end

    q = @(x) round(x*4)/4;
    d = q(S{1}.dates);
    for j = 2:numel(S); d = intersect(d, q(S{j}.dates)); end
    assert(numel(d) > 8, 'genfig_R1:noOverlap', ...
        'the runs share only %d quarters', numel(d));
    if any(cellfun(@(s) numel(s.dates), S) ~= numel(d))
        fprintf('  R.1: plotting %d shared quarters (%s)\n', numel(d), ...
                strjoin(arrayfun(@(s) sprintf('%d', numel(S{s}.dates)), ...
                                 1:numel(S), 'UniformOutput', false), ', '));
    end
    pick = @(s, fld) s.(fld)(ismember(q(s.dates), d));

    % ---- styling ------------------------------------------------------------
    % Row 1 reproduces B.11's baseline exactly; the rest are this figure's.
    STY = { [0.5 0.5 0.5], '-',  2.0
            [0.00 0.30 0.75], '--', 1.6
            [0.75 0.10 0.10], '-.', 1.6 };
    assert(numel(S) <= size(STY,1), 'genfig_R1:tooManySeries', ...
        ['%d series but only %d line styles are defined -- add one rather than ' ...
         'letting two series share a style.'], numel(S), size(STY,1));

    labels = [{'Baseline'}, alts(:,1)'];
    FLD    = {'ehat_tfp', 'ehat_noise'};
    YLAB   = {'Technology', 'Noise'};

    % ---- draw, on B.11's canvas ---------------------------------------------
    fout = figure('Color',[1 1 1], 'Position',[1 1 425 300], 'Name',name);
    axk  = gobjects(1,2);
    for k = 1:2
        axk(k) = subplot(2,1,k);
        hold on
        for j = 1:numel(S)
            plot(d, pick(S{j}, FLD{k}), STY{j,2}, 'color',STY{j,1}, ...
                 'linewidth',STY{j,3});
        end
        ylabel(YLAB{k}, 'FontWeight','Normal','Interpreter','latex','Fontsize',12);
        zl = plot(d, zeros(numel(d),1), '--k');
        % The key below is drawn by hand, so nothing auto-adopts this line --
        % kept so that it stays out of any legend() a later edit adds.
        zl.Annotation.LegendInformation.IconDisplayStyle = 'off';
        grid on;  axis tight;
        set(gca,'TickLabelInterpreter','latex')
    end

    % ---- legend, laid out by hand ------------------------------------------
    % NOT legend(). MATLAB sizes a multi-column legend's columns from the raw
    % label STRING, before the LaTeX interpreter typesets it, so labels of this
    % length collide with each other at 425pt -- which is what the two-column
    % version did. Drawing the key into an invisible strip puts the geometry
    % here, where the widths can be computed and the rows chosen to fit.
    %
    % CHARW is a mean glyph advance at 10pt as a fraction of the canvas width,
    % deliberately generous: overestimating it costs a little whitespace,
    % underestimating it is the bug being fixed.
    CHARW = 5.6/425;
    SEG   = 26/425;       % length of the line sample
    TGAP  =  6/425;       % sample-to-text gap
    EGAP  = 16/425;       % gap between entries
    wid   = SEG + TGAP + CHARW*cellfun(@numel, labels);

    % As many rows as it takes, never a layout that assumes one. Greedy fill at
    % 0.96 of the width, so adding a fourth series later wraps rather than
    % overflows.
    rows = {};  cur = [];  acc = 0;
    for j = 1:numel(labels)
        if ~isempty(cur) && acc + EGAP + wid(j) > 0.96
            rows{end+1} = cur;  cur = [];  acc = 0;              %#ok<AGROW>
        end
        if ~isempty(cur); acc = acc + EGAP; end
        cur(end+1) = j;  acc = acc + wid(j);                      %#ok<AGROW>
    end
    rows{end+1} = cur;
    STRIP = 0.042*numel(rows) + 0.012;

    % Explicit vertical layout, replacing B.11's gap correction. Same 0.055 gap
    % between the panels and the same reason for setting it -- subplot's default
    % spacing is wider in this MATLAB than in the release the draft was made on
    % -- but stating the whole layout also guarantees the legend strip clears the
    % date labels, which a correction that only moves the panels' tops cannot.
    GAP = 0.055;  TICK = 0.075;  TOPM = 0.045;
    hgt = (1 - STRIP - TICK - TOPM - GAP)/2;
    assert(hgt > 0.15, 'genfig_R1:noRoom', ...
        ['%d legend rows leave %.2f of the canvas per panel -- shorten the ' ...
         'labels or raise the figure height.'], numel(rows), hgt);
    for k = 1:2
        axk(k).Position(2) = STRIP + TICK + (2-k)*(hgt + GAP);
        axk(k).Position(4) = hgt;
    end

    lga = axes('Position',[0 0 1 STRIP]);
    hold(lga,'on');  xlim(lga,[0 1]);  ylim(lga,[0 1]);  axis(lga,'off');
    for r = 1:numel(rows)
        idx = rows{r};
        x   = (1 - (sum(wid(idx)) + EGAP*(numel(idx)-1)))/2;   % centred
        y   = 1 - (r - 0.5)/numel(rows);
        for j = idx
            plot(lga, [x x+SEG], [y y], STY{j,2}, 'color',STY{j,1}, ...
                 'linewidth',STY{j,3});
            text(lga, x+SEG+TGAP, y, labels{j}, 'interpreter','latex', ...
                 'fontsize',10, 'VerticalAlignment','middle');
            x = x + wid(j) + EGAP;
        end
    end

    % print, not exportgraphics -- see GENFIG_B11.
    set(fout, 'InvertHardcopy','off', 'PaperUnits','points', ...
              'PaperPosition',[0 0 425 300], 'PaperSize',[425 300]);
    print(fout, fullfile(dest, [name '.pdf']), '-dpdf', '-r0');
    fprintf('  wrote %s.pdf (Figure R.1)\n', name);
    fprintf('    %s\n', strjoin(cellfun(@(a) data_name(a), alts(:,2)', ...
                                        'UniformOutput', false), '\n    '));
end
