function fout = genfig_R1(base_info, alts, dest, opt)
%GENFIG_R1  Referee figure R1: disturbance series, baseline against the no-FX
%           asset specifications.
%
%   fout = GENFIG_R1(base_info, alts, dest)
%   fout = GENFIG_R1(base_info, alts, dest, opt)
%
%   base_info  descriptor of the baseline run, drawn grey solid as in Figure C.11
%   alts       n x 2 cell, {legend label, info} per additional series. A row
%              whose info is empty is dropped and reported.
%   dest       output directory (required)
%   opt.name   output file stem; default 'shock_series_R1'
%   fout       the figure handle
%
%   Two stacked panels over calendar time, technology and noise, as in Figure
%   C.11. The disturbances come from INFER_SHOCKS, one call per run. The series
%   differ in both colour and dash pattern.
%
%   See also GENFIG_C11, INFER_SHOCKS, GENFIG_R23.

    assert(nargin >= 3 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end
    if nargin < 4; opt = struct(); end
    name = 'shock_series_R1';
    if isfield(opt,'name') && ~isempty(opt.name); name = opt.name; end

    % Drop series that have no run.
    keep = ~cellfun(@isempty, alts(:,2));
    if any(~keep)
        fprintf('  R.1: no run for %s -- omitted from the figure\n', ...
                strjoin(alts(~keep,1)', ', '));
    end
    alts = alts(keep,:);
    assert(~isempty(alts), 'genfig_R1:noAlts', 'no alternative specs supplied');

    % Disturbance series of each run, then the quarters they share.
    S = cell(1, size(alts,1)+1);
    S{1} = infer_shocks(base_info);
    for j = 1:size(alts,1); S{j+1} = infer_shocks(alts{j,2}); end

    q = @(x) round(x*4)/4;
    d = q(S{1}.dates);
    for j = 2:numel(S); d = intersect(d, q(S{j}.dates)); end
    assert(numel(d) > 8, 'genfig_R1:noOverlap', ...
        'the runs share only %d quarters', numel(d));
    if any(cellfun(@(s) numel(s.dates), S) ~= numel(d))
        fprintf('  R.1: plotting %d shared quarters (%s)\n', numel(d), ...
                strjoin(arrayfun(@(s) sprintf('%d', numel(S{s}.dates)), ...
                                 1:numel(S), 'UniformOutput', false), ', '));
    end
    pick = @(s, fld) s.(fld)(ismember(q(s.dates), d));

    % Line styles: colour, dash pattern, width. Row 1 is the baseline.
    STY = { [0.5 0.5 0.5], '-',  2.0
            [0.00 0.30 0.75], '--', 1.6
            [0.75 0.10 0.10], '-.', 1.6 };
    assert(numel(S) <= size(STY,1), 'genfig_R1:tooManySeries', ...
        ['%d series but only %d line styles are defined -- add one rather than ' ...
         'letting two series share a style.'], numel(S), size(STY,1));

    labels = [{'Baseline'}, alts(:,1)'];
    FLD    = {'ehat_tfp', 'ehat_noise'};
    YLAB   = {'Technology', 'Noise'};

    % Draw the two panels.
    fout = figure('Color',[1 1 1], 'Position',[1 1 425 300], 'Name',name);
    axk  = gobjects(1,2);
    for k = 1:2
        axk(k) = subplot(2,1,k);
        hold on
        for j = 1:numel(S)
            plot(d, pick(S{j}, FLD{k}), STY{j,2}, 'color',STY{j,1}, ...
                 'linewidth',STY{j,3});
        end
        ylabel(YLAB{k}, 'FontWeight','Normal','Interpreter','latex','Fontsize',12);
        zl = plot(d, zeros(numel(d),1), '--k');
        % Keep the zero line out of any legend.
        zl.Annotation.LegendInformation.IconDisplayStyle = 'off';
        grid on;  axis tight;
        set(gca,'TickLabelInterpreter','latex')
    end

    % The legend is drawn by hand in a strip of invisible axes at the bottom,
    % because legend() sizes its columns from the raw label strings and long
    % latex labels collide. Widths are fractions of the canvas width; CHARW is a
    % generous mean character width at 10pt.
    CHARW = 5.6/425;
    SEG   = 26/425;       % length of the line sample
    TGAP  =  6/425;       % sample-to-text gap
    EGAP  = 16/425;       % gap between entries
    wid   = SEG + TGAP + CHARW*cellfun(@numel, labels);

    % Fill legend rows greedily, up to 0.96 of the width.
    rows = {};  cur = [];  acc = 0;
    for j = 1:numel(labels)
        if ~isempty(cur) && acc + EGAP + wid(j) > 0.96
            rows{end+1} = cur;  cur = [];  acc = 0;              %#ok<AGROW>
        end
        if ~isempty(cur); acc = acc + EGAP; end
        cur(end+1) = j;  acc = acc + wid(j);                      %#ok<AGROW>
    end
    rows{end+1} = cur;
    STRIP = 0.042*numel(rows) + 0.012;

    % Vertical layout, from the bottom: legend strip, tick labels, then the two
    % panels separated by GAP.
    GAP = 0.055;  TICK = 0.075;  TOPM = 0.045;
    hgt = (1 - STRIP - TICK - TOPM - GAP)/2;
    assert(hgt > 0.15, 'genfig_R1:noRoom', ...
        ['%d legend rows leave %.2f of the canvas per panel -- shorten the ' ...
         'labels or raise the figure height.'], numel(rows), hgt);
    for k = 1:2
        axk(k).Position(2) = STRIP + TICK + (2-k)*(hgt + GAP);
        axk(k).Position(4) = hgt;
    end

    % Draw the legend entries, each row centred.
    lga = axes('Position',[0 0 1 STRIP]);
    hold(lga,'on');  xlim(lga,[0 1]);  ylim(lga,[0 1]);  axis(lga,'off');
    for r = 1:numel(rows)
        idx = rows{r};
        x   = (1 - (sum(wid(idx)) + EGAP*(numel(idx)-1)))/2;   % centred
        y   = 1 - (r - 0.5)/numel(rows);
        for j = idx
            plot(lga, [x x+SEG], [y y], STY{j,2}, 'color',STY{j,1}, ...
                 'linewidth',STY{j,3});
            text(lga, x+SEG+TGAP, y, labels{j}, 'interpreter','latex', ...
                 'fontsize',10, 'VerticalAlignment','middle');
            x = x + wid(j) + EGAP;
        end
    end

    % Print the whole 425x300 canvas rather than cropping to content.
    set(fout, 'InvertHardcopy','off', 'PaperUnits','points', ...
              'PaperPosition',[0 0 425 300], 'PaperSize',[425 300]);
    print(fout, fullfile(dest, [name '.pdf']), '-dpdf', '-r0');
    fprintf('  wrote %s.pdf (Figure R.1)\n', name);
    fprintf('    %s\n', strjoin(cellfun(@(a) data_name(a), alts(:,2)', ...
                                        'UniformOutput', false), '\n    '));
end
