function fout = genfig_C11(base_info, nofx_info, dest)
%GENFIG_C11  Figure C.11: estimated technology and noise disturbance series.
%
%   fout = GENFIG_C11(base_info, nofx_info, dest)
%
%   base_info  descriptor of the baseline run
%   nofx_info  descriptor of the run without the exchange rate
%   dest       output directory (required)
%   fout       the figure handle
%
%   Two stacked panels over calendar time: the technology disturbances (top) and
%   the noise disturbances (bottom). Grey solid is the baseline. Black dashed is
%   the VAR the baseline implies for the seven variables other than NER (see
%   NOFX_RESTRICTED). The disturbances come from INFER_SHOCKS.
%
%   See also INFER_SHOCKS, NOFX_RESTRICTED, GENFIG_C12, DATA_NAME.

    assert(nargin >= 3 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end
    B = infer_shocks(base_info);
    % Shocks identified without the exchange rate, from the implied restricted system.
    N = infer_shocks(base_info, struct('restricted',true, 'nofx_info',nofx_info));

    % Align on shared dates: the two series can differ in length.
    [d, ib, in] = intersect(round(B.dates*4)/4, round(N.dates*4)/4);
    assert(numel(d) > 8, 'genfig_C11:noOverlap', ...
        'the two runs share only %d quarters', numel(d));
    if numel(d) < numel(B.dates) || numel(d) < numel(N.dates)
        fprintf('  C.11: plotting %d shared quarters (base %d, noFX %d)\n', ...
                numel(d), numel(B.dates), numel(N.dates));
    end

    % Rows: panel label, baseline series, no-FX series.
    PANEL = {'Technology', B.ehat_tfp(ib),   N.ehat_tfp(in); ...
             'Noise',      B.ehat_noise(ib), N.ehat_noise(in)};

    fout = figure('Color',[1 1 1], 'Position',[1 1 425 300], 'Name','FigureC11');

    axk = gobjects(1,2);
    for k = 1:2
        axk(k) = subplot(2,1,k);
        plot(d, PANEL{k,2}, '-',  'color',[0.5, 0.5, 0.5], 'linewidth',2);
        ylabel(PANEL{k,1}, 'FontWeight','Normal','Interpreter','latex','Fontsize',12);
        hold on
        plot(d, PANEL{k,3}, '--', 'color',[0, 0, 0], 'linewidth',2);
        zl = plot(d, zeros(numel(d),1), '--k');
        zl.Annotation.LegendInformation.IconDisplayStyle = 'off';
        grid on;
        axis tight;
        set(gca,'TickLabelInterpreter','latex')
    end

    % Narrow the gap between the panels to GAP by growing each panel into it.
    GAP = 0.055;                       % target gap
    top = axk(1).Position;  bot = axk(2).Position;
    cur = top(2) - (bot(2) + bot(4));  % current gap
    if cur > GAP
        grow = (cur - GAP)/2;
        axk(1).Position(2) = top(2) - grow;   axk(1).Position(4) = top(4) + grow;
        axk(2).Position(4) = bot(4) + grow;
    end

    legend('Baseline','VAR w/o Exchange Rate', 'location','southeast', ...
           'interpreter','latex', 'box','off', 'orientation','horizontal', ...
           'fontsize',12, ...
           'Position',[0.313868720190872 0.0100553042892664 ...
                       0.350416994094849 0.0438095240365891]);

    % Print the whole 425x300 canvas; exportgraphics would crop to content.
    set(fout, 'InvertHardcopy','off', 'PaperUnits','points', ...
              'PaperPosition',[0 0 425 300], 'PaperSize',[425 300]);
    print(fout, fullfile(dest, 'FigureC11.pdf'), '-dpdf', '-r0');
    fprintf('  wrote FigureC11.pdf\n');
    fprintf('    baseline %s\n    no-FX    %s [%s]\n', ...
            data_name(base_info), data_name(nofx_info), N.meta.system);
    fprintf('    corr(base,noFX): technology %.4f, noise %.4f\n', ...
            corr(PANEL{1,2},PANEL{1,3}), corr(PANEL{2,2},PANEL{2,3}));
end
