function fout = genfig_C6(base_info, dest, opt)
%GENFIG_C6  Figure C.6: responses of asset returns to technology and noise.
%
%   fout = GENFIG_C6(base_info, dest)
%
%   base_info  descriptor of the baseline run
%   dest       output directory (required)
%   fout       [technology figure, noise figure]
%
%   Three panels, 1x3:
%       Expected Excess Equity Return Diff.     projected   (exret_eq_lead)
%       Expected Excess 10-Y Bond Return Diff.  projected   (exret_bond_lead)
%       Expected Excess Returns                 constructed (expexret)
%   The two projected rows are leads: they hold the t+1 return at row t.
%
%   See also GENFIG_C15, CCDGV_MANIFEST, PLOTIRF.

    assert(nargin >= 2 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end

    [~, f] = data_name(base_info);
    assert(isfile(f), 'genfig_C6:noFile', '%s not found', f);
    D = load(f, 'vnames', 'r2');

    ROWS = {'Expected Excess Equity Return Diff.', ...
            'Expected Excess 10-Y Bond Return Diff.', ...
            'Expected Excess Returns'};
    ord = var_order(D.vnames, ROWS{:});  ord = ord(:);

    % Two-line panel titles. lab stays full length because numel(lab) sets
    % plotIRF's offset into the data.
    lab = D.vnames;
    lab{ord(1)} = {'Expected Excess';'Equity Return Diff.'};
    lab{ord(2)} = {'Expected Excess';'10-Y Bond Return Diff.'};
    lab{ord(3)} = {'Expected Excess';'Currency Returns'};

    % The cumulated responses on horizons -20:20, median and bands.
    [dt, dn] = cj_bands(base_info);

    p = plotIRF;
    p.nrow = 1;  p.ncol = 3;
    p.rates = rate_rows(D.vnames);       % all three panels are drawn annualized
    % A wide strip; the export crops it to content.
    p.position = [1 1 680 170 ];

    p.NOISE = zeros(1,numel(ord));
    ft = plotIRF(dt, ord, lab, 'FigureC6a', 1:numel(ord), p);
    p.NOISE = ones(1,numel(ord));
    fn = plotIRF(dn, ord, lab, 'FigureC6b', 1:numel(ord), p);
    align_ylabels(ft, fn);               % same page size for the two panels
    fout(1) = local_export(ft, fullfile(dest,'FigureC6a.pdf'));
    fout(2) = local_export(fn, fullfile(dest,'FigureC6b.pdf'));

    fprintf('  wrote FigureC6a.pdf / FigureC6b.pdf\n');
    fprintf('    %s\n', data_name(base_info));
    % Print the projection R2 of each panel. A constructed row has none.
    for k = 1:numel(ord)
        if isfield(D,'r2') && ord(k) <= numel(D.r2)
            fprintf('    r2 %.4f  %s\n', D.r2(ord(k)), D.vnames{ord(k)});
        else
            fprintf('    r2    --   %s (constructed, exact)\n', D.vnames{ord(k)});
        end
    end
end

% -------------------------------------------------------------------------
function f = local_export(f, target)
%   Crop to content: on a 1x3 strip most of the canvas is whitespace.
    f = f(1);
    set(f, 'Color','w', 'InvertHardcopy','off');
    exportgraphics(f, target, 'ContentType','vector', 'BackgroundColor','white');
end

