% GEN_CJ_IRFS_TFSWEEP  Technology and noise impulse responses and variance shares.
%
% Script, run by estimate_one and by the model chain. One pass over the draws, all
% on one frequency grid of 2^16 points:
%   * one tf_sweep per draw for the responses of every series, A(I - zB)^{-1} C
%   * Wold factors from the cepstrum of the log spectrum, evaluated on the same
%     grid by FFT
%   * impulse responses by ifft of the first-difference responses; the plotting
%     code cumulates them. The grid's period must far exceed the decay time of
%     the responses.
%   * band variance shares of the levels spectra (no band contains frequency 0)
%
% Reads from the workspace: ARs, Sigs, Aproj, datakeys, vnames, smax, vd_fr,
% j_cj_horizon and, optionally, cj_auxfun.
%
% Leaves in the workspace:
%   irtfp, irnoise     (2*smax+1) x nv x ndraws  responses of first differences,
%                      lags -smax..smax
%   vstfp, vsnoise     nv x nbands x ndraws      levels variance shares
%   vstfp_real         nv x ndraws               band-1 share due to current and
%                                                past technology shocks only
%   warntfp, warnnoise 1 x ndraws                warning flags

% Builder of the auxiliary-variable rows. The default is gen_auxvars; the model
% chain sets cj_auxfun to its own. Only the tfp and exp_tfp_j rows are needed
% for the identification.
if ~exist('cj_auxfun','var') || isempty(cj_auxfun)
    cj_auxfun = @gen_auxvars;
end

ndraws = length(ARs);
nvars  = size(ARs{1},1);
nv     = length(vnames);

% Frequency grid.
Ng    = 2^16;
lamg  = 2*pi*(0:Ng-1)/Ng;
zgrid = exp(-1i*lamg);
zr    = reshape(zgrid,1,1,Ng);

% Outputs.
irtfp     = nan(2*smax+1,nv,ndraws);
vstfp     = nan(nv,size(vd_fr,1),ndraws);
warntfp   = nan(1,ndraws);
vstfp_real = nan(nv,ndraws);
vsreal_chk = nan(nv,ndraws);
irnoise  = nan(2*smax+1,nv,ndraws);
vsnoise   = nan(nv,size(vd_fr,1),ndraws);
warnnoise = nan(1,ndraws);

% One page of Aproj per draw, so that parfor slices it. A 2-D Aproj is repeated
% for every draw.
if ndims(Aproj) == 3
    assert(size(Aproj,3) == ndraws, 'gen_cj:projPages', ...
        ['Aproj has %d pages for %d draws (ndraws+1 incl. the point estimate). ' ...
         'A different page convention would be silently truncated.'], ...
        size(Aproj,3), ndraws);
    Apage = Aproj;
else
    Apage = repmat(Aproj, 1, 1, ndraws);
end

parfor i = 1:ndraws

    % Companion form, TFP row and expectations row.
    AR    = ARs{i};
    nlags = size(AR,2)/nvars;
    nx    = nvars*nlags;
    C     = [chol(Sigs{i},'lower'); zeros(nx-nvars,nvars)];
    % Page i of Apage is the projection paired with VAR draw i.
    [A,B,~,~,~,~,~,rowkeys] = cj_auxfun(AR',Apage(:,:,i),datakeys,nvars,nlags,j_cj_horizon);
    ny  = size(A,1);
    ita = find(strcmp(rowkeys,'tfp'));          % TFP row of A
    iq  = find(strcmp(rowkeys,'exp_tfp_j'));    % expectations row of A: tfp*B^j

    % Responses and spectra.
    lastwarn('');
    AH   = tf_sweep(A, B, C, zgrid);                          % responses of all series; ny x nvars x Ng
    HXa  = AH(ita,:,:);                                       % TFP response; 1 x nvars x Ng
    QH   = AH(iq,:,:);                                        % Expected TFP response; 1 x nvars x Ng
    gaa  = sum(abs(HXa).^2, 2);                               % TFP spectrum; 1 x 1 x Ng
    hv   = QH - (pagemtimes(QH,'none',HXa,'ctranspose')./gaa).*HXa;   % Noise = Expected TFP - Expected TFP|TFP
    gvv  = sum(abs(hv).^2,2);                                 % Noise spectrum; 1 x 1 x Ng

    % Wold factors: cepstrum from the log spectrum, evaluated back on the same
    % grid by FFT, sum_n cep(n+1) z_k^n with z_k = exp(-i*lamg(k)).
    cw_a = cj_cepfactor(reshape(real(gaa),1,Ng));
    cw_v = cj_cepfactor(reshape(real(gvv),1,Ng));
    wa   = reshape(exp(fft(cw_a,Ng)),1,1,Ng);
    wv   = reshape(exp(fft(cw_v,Ng)),1,1,Ng);

    % Technology responses and shares.
    alpha = pagemtimes(AH,'none',HXa,'ctranspose') ./ gaa;  % projection of all vars on TFP
    ir2   = real(ifft((1 - zr) .* alpha .* wa, [], 3));   % responses of first differences, safer for ifft
    ir    = zeros(2*smax+1,ny);
    ir(smax+1:end,:) = squeeze(ir2(:,:,1:smax+1))';       % truncate to lags -smax..smax
    ir(1:smax,:)     = squeeze(ir2(:,:,end-smax+1:end))';
    irtfp(:,:,i)     = ir;

    % Total variances.
    den = reshape(sum(abs(AH).^2,2), ny, Ng)/(2*pi); Vd  = cj_bandint(lamg, den, vd_fr);

    % Variances due to technology.
    num = reshape(abs(alpha).^2.*gaa, ny, Ng)/(2*pi);  Vn_a = cj_bandint(lamg, num , vd_fr);

    % Variance of the band-1-filtered variable due to current and past
    % technology shocks: (i) band-pass the technology MA over both halves of
    % the band (a one-sided mask halves real(ifft)), (ii) ifft, (iii) drop the
    % future terms, (iv) variance = sum of squared coefficients (Parseval).
    inband   = @(l) l >= vd_fr(1,1) & l <= vd_fr(1,2);
    mask     = reshape(inband(lamg) | inband(2*pi - lamg), 1, 1, Ng);
    ir_ma    = real(ifft(alpha .* wa .* mask, [], 3));      % two-sided filtered MA; ny x 1 x Ng
    Vn_areal = sum(ir_ma(:,:,1:Ng/2).^2, 3)/2;              % /2: Vd integrates over (0,pi) only

    % Variance shares.
    vs = Vn_a./Vd;
    vstfp(:,:,i) = vs;
    vstfp_real(:,i) = Vn_areal./Vd(:,1);
    vsreal_chk(:,i) = sum(ir_ma.^2, 3)/2./Vd(:,1) - vs(:,1);  % untruncated: should be ~0

    if ~isempty(lastwarn); warntfp(i) = 1; end

    % Noise responses and shares.
    lastwarn('');
    an   = pagemtimes(AH,'none', hv./wv, 'ctranspose');     % projection of all vars on noise x Wold
    ir2n = real(ifft((1 - zr) .* an, [], 3));
    irn  = zeros(2*smax+1,ny);
    irn(smax+1:end,:) = squeeze(ir2n(:,:,1:smax+1))';
    irn(1:smax,:)     = squeeze(ir2n(:,:,end-smax+1:end))';
    irnoise(:,:,i) = irn;

    % Variance due to noise.
    num = reshape(abs(an).^2, ny, Ng)/(2*pi); Vn_n = cj_bandint(lamg, num , vd_fr);

    % Variance share.
    vsnoise(:,:,i) =  Vn_n./Vd;

    if ~isempty(lastwarn); warnnoise(i) = 1; end
end
clear Apage                 % not needed after the loop
disp('finished (CJ identification)');

% Checks on vstfp_real: the untruncated filtered MA must reproduce the band-1
% technology share, and dropping future terms can only lower it.
fprintf('vstfp_real checks: max |untruncated - vstfp band 1| = %.2e; draws with vstfp_real > vstfp = %d\n', ...
        max(abs(vsreal_chk(:))), nnz(any(vstfp_real > squeeze(vstfp(:,1,:)) + 1e-10, 1)));
