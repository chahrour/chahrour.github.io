function fout = genfig_C13(base_info, nofx_info, dest)
%GENFIG_C13  Figure C.13: the exchange rate response with and without NER in the VAR.
%
%   fout = GENFIG_C13(base_info, nofx_info, dest)
%
%   base_info  descriptor of the baseline run
%   nofx_info  descriptor of the run without the exchange rate
%   dest       output directory (required)
%   fout       the figure handle
%
%   Two panels (technology, noise) of the real exchange rate response: the
%   baseline run with bands, and a dashed line labelled "VAR w/o Exchange Rate".
%   The dashed line is the baseline system's real exchange rate responding to
%   the shock identified from the seven variables other than NER (see
%   NOFX_RESTRICTED). It is not the projected row of the re-estimated no-FX run.
%
%   See also NOFX_RESTRICTED, PLOTIRF, DATA_NAME.

    assert(nargin >= 3 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end

    B = local_load(base_info, 'baseline');
    % N holds the restricted system's draws with the baseline's band settings.
    R = nofx_restricted(base_info, nofx_info, struct());
    N = B;
    N.irtfp = R.irtfp;  N.irnoise = R.irnoise;  N.vnames = R.vnames;
    src = 'paper construction';

    assert(isequal(B.vnames, N.vnames), 'genfig_C13:rowMismatch', ...
        ['the two runs have different row sets (%d vs %d names) -- they must ' ...
         'share a manifest layout to be overlaid.'], numel(B.vnames), numel(N.vnames));

    i = var_order(B.vnames, 'Real Exchange Rate');

    % Cumulate, take horizons -50:20 and discard the first 30, leaving -20:20.
    [db_t, db_n] = local_bands(B, i);
    [dn_t, dn_n] = local_bands(N, i);

    % Lay the two shocks out as two "variables", duplicated into columns 3:4.
    nimp = size(db_t,1);
    main = NaN(nimp,4,5);  over = NaN(nimp,4,5);
    main(:,1,:) = db_t;  main(:,3,:) = db_t;
    main(:,2,:) = db_n;  main(:,4,:) = db_n;
    over(:,1,:) = dn_t;  over(:,3,:) = dn_t;
    over(:,2,:) = dn_n;  over(:,4,:) = dn_n;

    p = plotIRF;
    p.nrow = 1;  p.ncol = 2;
    p.NOISE = [0 1];                                  % technology blue, noise red
    p.position = [1 1 4/3*425 4/3*425/3];
    p.ylab = {'Real Exchange Rate', ''};
    p.overlay = struct('data', over, 'style','--k', ...
                       'label','VAR w/o Exchange Rate');

    % Two names, not four: numel(VARS) sets plotIRF's offset into the data.
    fout = plotIRF(main, [1;2], {'Technology','Noise'}, 'FigureC13', [1 2], p);
    exportgraphics(fout(1), fullfile(dest, 'FigureC13.pdf'));
    fprintf('  wrote FigureC13.pdf\n');
    fprintf('    baseline %s\n    no-FX    %s [%s]\n', ...
            data_name(base_info), data_name(nofx_info), src);
end

% -------------------------------------------------------------------------
function D = local_load(info, what)
    [~, f] = data_name(info);
    assert(isfile(f), 'genfig_C13:noFile', ...
           '%s run: %s not found -- run run_sweep first.', what, f);
    D = load(f, 'irtfp','irnoise','vnames','point_estimate','bound','bound2');
end

function [dt, dn] = local_bands(D, i)
%LOCAL_BANDS  Median and percentile bands for row i, on horizons -50:20.
    h = (size(D.irtfp,1)-1)/2;
    hgrid = -50:20;  discard = 30;
    it = cumsum(D.irtfp);   in = cumsum(D.irnoise);
    it = squeeze(it(hgrid+h+1, i, :));      % nimp x ndraws
    in = squeeze(in(hgrid+h+1, i, :));
    dt = local_pack_one_column(it, D, discard);
    dn = local_pack_one_column(in, D, discard);
end

function d = local_pack_one_column(x, D, discard)
% One-column version of PACK_BANDS.
% Pages: 1 = point estimate, 2/3 = inner band, 4/5 = outer band.
    if D.point_estimate; m = x(:,end); else; m = median(x(:,1:end-1), 2); end
    q  = prctile(x(:,1:end-1), 100*[D.bound 1-D.bound D.bound2 1-D.bound2], 2);
    d  = NaN(size(x,1)-discard, 1, 5);
    d(:,1,1) = m(discard+1:end);
    d(:,1,2) = q(discard+1:end,1);   d(:,1,3) = q(discard+1:end,2);
    d(:,1,4) = q(discard+1:end,3);   d(:,1,5) = q(discard+1:end,4);
end
