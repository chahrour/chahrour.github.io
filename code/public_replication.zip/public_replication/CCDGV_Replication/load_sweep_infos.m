function S = load_sweep_infos(cfg)
%LOAD_SWEEP_INFOS  The run descriptors SWEEP saved, pointed at cfg.resultdir.
%
%   S = load_sweep_infos(cfg)
%
%   Each descriptor records the folder its run was estimated in. The run files
%   may have been moved or copied since, so every descriptor's outdir is set to
%   cfg.resultdir, the folder sweep_infos.mat is read from.
%
%   See also SWEEP, DATA_NAME.

    f = fullfile(cfg.resultdir, 'sweep_infos.mat');
    assert(isfile(f), 'load_sweep_infos:noFile', ...
        '%s not found -- run sweep(cfg) first.', f);
    L = load(f, 'sweep_infos');
    S = L.sweep_infos;
    for k = fieldnames(S)'
        v = S.(k{1});
        if iscell(v)                          % the by-country set
            for j = 1:numel(v); v{j}.outdir = cfg.resultdir; end
        else
            v.outdir = cfg.resultdir;
        end
        S.(k{1}) = v;
    end
end
