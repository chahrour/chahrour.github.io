function S = sweep(cfg, only)
%SWEEP  Estimate every specification the paper's exhibits need.
%
%   sweep(cfg)          all 16 specifications
%   sweep(cfg, 'base')  just one, by key -- useful for checking the plumbing
%   sweep(cfg, {'base','vecm'})
%
%   Returns S, a struct of the finished info descriptors keyed by spec name, and
%   saves the same struct to cfg.resultdir/sweep_infos.mat. exhibits(cfg, S) takes
%   it directly. The research code passed this between stages through an
%   SWEEP environment variable, because several generators call `clear`; the
%   package passes it as an argument.
%
%   Writes one file per specification into cfg.resultdir, named by key.
%
%   THE SPEC TABLE IS THE WHOLE DESIGN. Each row is one estimation run. Only
%   four things vary across the paper's exhibits -- which variables enter the
%   VAR, which country, and the sample -- so those are the columns, and
%   everything else comes from cfg.
%
%   START DATES ARE PER SPEC, AND THEY REPRODUCE THE PAPER. The window is
%   BINDING in the sense that run_main errors on a NaN inside it -- but that
%   check will not object to an earlier start, because the loader does not leave
%   a NaN there. geo_aggregate_spliced renormalises over the countries present
%   and chains through entry, so the built panel carries a value for every
%   baseline VAR column from 1976Q1, including IDIFF.
%
%   The underlying data are not complete that early. Italy's eurocurrency
%   deposit rate begins 1978-06-09 and Japan's 1978-08-01, so a G6 aggregate
%   before 1978Q4 rests on fewer countries than the one the paper reports, with
%   the interpolation standing in for the rest. These starts are therefore a
%   judgement about what the data support, not a constraint the code enforces:
%   the specification starts when it starts even though the loader would hand it
%   earlier quarters.
%
%   The VECM specification starts one quarter later still, at 1979Q1, and that is
%   a choice too. It does NOT difference the data: CCDGV_BVECM takes the levels
%   panel and returns levels VAR draws, with the nlags-1 lagged differences
%   internal to the estimator, so it loses no more sample than any other spec at
%   the same lag order. Running it from 1978Q4 works and gives the same 119
%   quarters as the rest; the paper reports the later start.

    if nargin < 2; only = {}; end
    if ischar(only) || isstring(only); only = cellstr(only); end

    %   key        inclvar  country    start     end
    %
    %   THE INCLVAR NUMBERS ARE NOT IN KEY ORDER, and the keys are what the
    %   exhibits select by, so a wrong pairing here draws the wrong specification
    %   under the right label. local_check_specs verifies each one against what is
    %   actually in its VAR.
    SPECS = { ...
      'base',      1,  'G6',      1978.75,  []
      'nofx',      2,  'G6',      1978.75,  []
      'eq',        3,  'G6',      1978.75,  []
      'eqnofx',    4,  'G6',      1978.75,  []
      'tb',        5,  'G6',      1978.75,  []
      'forTFP',    6,  'G6',      1978.75,  []
      'by',        8,  'G6',      1978.75,  []
      'bynofx',    9,  'G6',      1978.75,  []
      'vecm',     10,  'G6',      1979.00,  []
      'extend',    1,  'G6',      1978.75,  2020.00
      'Canada',    1,  'Canada',  1976.00,  []
      'France',    1,  'France',  1976.00,  []
      'Germany',   1,  'Germany', 1976.00,  []
      'Italy',     1,  'Italy',   1978.50,  []
      'Japan',     1,  'Japan',   1978.75,  []
      'UK',        1,  'UK',      1976.00,  []
    };

    if ~isempty(only)
        keep = ismember(SPECS(:,1), only);
        missing = setdiff(only, SPECS(:,1));
        assert(isempty(missing), 'sweep:unknownKey', ...
            'no such specification: %s', strjoin(missing, ', '));
        SPECS = SPECS(keep, :);
    end

    S = struct();
    T = tic;
    for k = 1:size(SPECS,1)
        key = SPECS{k,1};
        fprintf('\n--- %s (%d of %d) ---\n', key, k, size(SPECS,1));
        t0 = tic;
        S.(key) = estimate_one(cfg, key, SPECS{k,2}, SPECS{k,3}, SPECS{k,4}, SPECS{k,5});
        fprintf('    %s: %d obs %g..%g in %.0f s\n', key, S.(key).nobs_realised, ...
                S.(key).sd_realised, S.(key).ed_realised, toc(t0));
    end

    % The six by-country runs are collected under one field, because the
    % generators that use them (Figures B.9/B.10, Tables B.6/B.7) take the set.
    CTRY = {'Canada','France','Germany','Italy','Japan','UK'};

    check_specs(cfg, S);

    % MERGE, DO NOT REPLACE. With `only`, S holds just those keys, and the
    % exhibits need the whole set -- so a partial sweep updates the saved
    % descriptors in place rather than truncating them to what it just ran.
    f = fullfile(cfg.resultdir, 'sweep_infos.mat');
    if ~isempty(only) && isfile(f)
        L = load(f, 'sweep_infos');
        sweep_infos = L.sweep_infos;
        for k = fieldnames(S)'; sweep_infos.(k{1}) = S.(k{1}); end
        fprintf('  merged %d key(s) into the existing %d-key descriptor set.\n', ...
                numel(fieldnames(S)), numel(fieldnames(sweep_infos)));
    else
        sweep_infos = S;
    end

    % S.country IS BUILT AFTER THE MERGE, NOT BEFORE. It is a cell of the six
    % by-country descriptors, and the generators that use it (Figures B.9/B.10,
    % Tables B.6/B.7) take the set. Building it before the merge meant a partial
    % sweep that re-ran one country updated that country's own field and left the
    % saved S.country pointing at the OLD descriptor for all six -- so the figures
    % drew the stale one. Rebuilt from the merged fields, it cannot disagree with
    % them.
    if all(isfield(sweep_infos, CTRY))
        sweep_infos.country = cellfun(@(c) sweep_infos.(c), CTRY, 'UniformOutput', false);
    end
    save(f, 'sweep_infos');
    fprintf('\n%d specification(s) in %.1f min; descriptors in %s\n', ...
            size(SPECS,1), toc(T)/60, fullfile(cfg.resultdir,'sweep_infos.mat'));
end
