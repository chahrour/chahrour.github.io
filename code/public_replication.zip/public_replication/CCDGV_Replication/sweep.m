function S = sweep(cfg, only)
%SWEEP  Estimate every specification the paper's exhibits need.
%
%   S = sweep(cfg)                    all 16 specifications
%   S = sweep(cfg, 'base')            one, by key
%   S = sweep(cfg, {'base','vecm'})   several
%
%   cfg   settings struct from config().
%   only  key, or cell of keys, to run (default: all).
%   S     struct of run descriptors keyed by specification. It is also saved to
%         cfg.resultdir/sweep_infos.mat; with `only`, the saved copy is updated
%         for those keys and keeps the rest.
%
%   Writes one results file per specification into cfg.resultdir.
%
%   See also ESTIMATE_ONE, EXHIBITS.

    if nargin < 2; only = {}; end
    if ischar(only) || isstring(only); only = cellstr(only); end

    % One row per estimation run. inclvar selects the VAR specification in
    % ccdgv_manifest; start and end are fractional years (2008.25 = 2008Q2).
    % check_specs verifies each inclvar against its VAR.
    %
    % 1978.75 start date used for most VAR due to missing data in Japan and
    % Italy.
    %
    %   key        inclvar  country    start     end
    SPECS = { ...
      'base',      1,  'G6',      1978.75,  2008.25
      'nofx',      2,  'G6',      1978.75,  2008.25
      'eq',        3,  'G6',      1978.75,  2008.25
      'eqnofx',    4,  'G6',      1978.75,  2008.25
      'tb',        5,  'G6',      1978.75,  2008.25
      'forTFP',    6,  'G6',      1978.75,  2008.25
      'by',        8,  'G6',      1978.75,  2008.25
      'bynofx',    9,  'G6',      1978.75,  2008.25
      'vecm',     10,  'G6',      1979.00,  2008.25
      'extend',    1,  'G6',      1978.75,  2020.00
      'Canada',    1,  'Canada',  1976.00,  2008.25
      'France',    1,  'France',  1976.00,  2008.25
      'Germany',   1,  'Germany', 1976.00,  2008.25
      'Italy',     1,  'Italy',   1978.50,  2008.25
      'Japan',     1,  'Japan',   1978.75,  2008.25
      'UK',        1,  'UK',      1976.00,  2008.25
    };

    if ~isempty(only)
        keep = ismember(SPECS(:,1), only);
        missing = setdiff(only, SPECS(:,1));
        assert(isempty(missing), 'sweep:unknownKey', ...
            'no such specification: %s', strjoin(missing, ', '));
        SPECS = SPECS(keep, :);
    end

    S = struct();
    T = tic;
    for k = 1:size(SPECS,1)
        key = SPECS{k,1};
        fprintf('\n--- %s (%d of %d) ---\n', key, k, size(SPECS,1));
        t0 = tic;
        S.(key) = estimate_one(cfg, key, SPECS{k,2}, SPECS{k,3}, SPECS{k,4}, SPECS{k,5});
        fprintf('    %s: %d obs %g..%g in %.0f s\n', key, S.(key).nobs_realised, ...
                S.(key).sd_realised, S.(key).ed_realised, toc(t0));
    end

    % The six by-country runs, collected under one field below.
    CTRY = {'Canada','France','Germany','Italy','Japan','UK'};

    check_specs(cfg, S);

    % With `only`, merge the new descriptors into the saved set.
    f = fullfile(cfg.resultdir, 'sweep_infos.mat');
    if ~isempty(only) && isfile(f)
        sweep_infos = load_sweep_infos(cfg);
        for k = fieldnames(S)'; sweep_infos.(k{1}) = S.(k{1}); end
        fprintf('  merged %d key(s) into the existing %d-key descriptor set.\n', ...
                numel(fieldnames(S)), numel(fieldnames(sweep_infos)));
    else
        sweep_infos = S;
    end

    % Collect the six by-country descriptors, after the merge so they match it.
    if all(isfield(sweep_infos, CTRY))
        sweep_infos.country = cellfun(@(c) sweep_infos.(c), CTRY, 'UniformOutput', false);
    end
    save(f, 'sweep_infos');
    fprintf('\n%d specification(s) in %.1f min; descriptors in %s\n', ...
            size(SPECS,1), toc(T)/60, fullfile(cfg.resultdir,'sweep_infos.mat'));
end
