function out = write_moments_table(datam, opt)
%WRITE_MOMENTS_TABLE  Emit Table 3 (tab: emp puzzles) as LaTeX.
%
%   out = WRITE_MOMENTS_TABLE(DATAM, OPT)
%
%   "Exchange Rate Related Puzzles and TFP Expectations" -- ten moments in three
%   panels, each conditioned four ways:
%
%       Technology | Noise | Both | Unconditional
%
%   Panel A  Forward Premium Puzzle          6 rows
%   Panel B  Backus-Smith Puzzle             2 rows
%   Panel C  Excess Volatility & Persistence 2 rows
%
%   Each point estimate is the MEDIAN across draws, with a \scriptsize
%   [lo, hi] row beneath it from prctile at [pp, 100-pp] (pp = 16, i.e. the
%   16-84 band the draft's note describes). The last draw is the point-estimate
%   draw and is excluded throughout -- the `(1:end-1)` convention from
%   gentablemoments_v6.
%
%   DATAM  case .mat name, a struct, or an R already returned by
%          gentablemoments_final (detected by its .stats field, so an expensive
%          computation can be reused).
%   OPT    .outdir  REQUIRED: the directory holding Figures/ and Tables/
%          .echo    print the rows (default true)
%
%   Rows whose moment block was skipped for this VAR layout render `--` and are
%   named in the table's note, rather than being silently dropped. See
%   gentablemoments_final's R.skipped.
%
%   ⚠ CAVEAT ON EXACT REPRODUCTION. The draft's own note says three of these
%   moments -- Engel beta_Lambda, cov(sum E_t lambda, r-r*), and rho(q_t) -- are
%   "computed on the data filtered over [2--100] quarter periodicities". This
%   generator computes them UNFILTERED; the filtered versions come from
%   gentablefilteredmoments.m. So the published Table 3 appears to be a
%   composite of two generators, and those three rows may not match here. The
%   comparison is reported rather than asserted.
%
%   See also GENTABLEMOMENTS_FINAL, WRITE_UHLIG_TABLES, WRITE_VD_TABLE.

    if nargin < 2; opt = struct(); end
    if ~isfield(opt,'echo'); opt.echo = true; end
    % opt.outdir is the EXHIBIT ROOT; this function appends Tables/ itself, which
    % is the same convention every generator here uses.
    assert(isfield(opt,'outdir') && ~isempty(opt.outdir), 'write_moments_table:noOutdir', ...
        'opt.outdir is required: the directory holding Figures/ and Tables/.');
    opt.outdir = fullfile(opt.outdir, 'Tables');
    if ~isfolder(opt.outdir); mkdir(opt.outdir); end

    if isstruct(datam) && isfield(datam,'stats')
        R = datam;                                  % an R passed straight in
    else
        if ~isstruct(datam)
            % datam is the path itself -- callers pass data_name(info). The old
        % sweep_datam indirection (an env var read inside the function) is gone.
            W = who('-file', datam);
            if any(strcmp(W,'moments'))
                % run_main computed these during the estimation -- read, do not
                % re-run a parfor over 1000 draws just to typeset a table.
                L = load(datam,'moments');  R = L.moments;
                fprintf('  moments: read from the case file (precomputed)\n');
                if any(strcmp(W,'info'))
                    lab = ccdgv_prov_label(load(datam,'info'));
                    if ~isempty(lab); R.meta.case = lab; end
                end
                if any(strcmp(W,'filtered_moments'))
                    LF = load(datam,'filtered_moments');  Rf = LF.filtered_moments;
                end
            else
                fprintf('  moments: not in the case file, computing (~15 s)\n');
                R = gentablemoments_final(datam);
            end
        else
            R = gentablemoments_final(datam);
        end
    end

    % label, field in R.stats, panel
    ROWS = { ...
      '\citeauthor{Fama1984} $\beta_{\lambda}$',                                'beta_fama',   'A'
      'cov$(\lambda_{t+1}, r_t - r_t^{\star})$',                                'cov_fama',    'A'
      '\citeauthor{Engel2016} $\beta_{\Lambda}$',                               'beta_engel',  'A'
      'cov$\!\left(\sum_{k=0}^{\infty}\mathbb{E}_t(\lambda_{t+k+1}), r_t - r_t^{\star}\right)$', 'cov_engel', 'A'
      '$\sigma(r_t - r_t^{\star}) / \sigma(\Delta q_t)$',                       'sig_ratio',   'A'
      '$\rho(r_t - r_t^{\star})$',                                              'rho_rdiff',   'A'
      '$\corr(\Delta q_t, \Delta (c_t - c_t^{\star}))$',                        'corr_dq_dcd', 'B'
      'cov$(\Delta q_t, \Delta (c_t - c_t^{\star}))$',                          'cov_dq_dcd',  'B'
      '$\rho(q_t)$',                                                            'rho_qt',      'C'
      '$\sigma(\Delta q_t) / \sigma(\Delta c_t)$',                              'sig_dq_dc',   'C' };

    PANEL = { 'A', 'Panel A: Forward Premium Puzzle Moments'
              'B', 'Panel B: \citetalias{Backus1993consumption} Puzzle Moments'
              'C', 'Panel C: Excess Volatility and Persistence' };

    % THE THREE FILTERED ROWS. The draft's note: Engel beta_Lambda,
    % cov(sum E_t lambda, r-r*) and rho(q_t) are "computed on the data filtered
    % over [2--100] quarter periodicities". Substitute them from the filtered
    % generator when it is available; otherwise leave the unfiltered values and
    % say so in the note, rather than silently mixing conventions.
    FILT = {'beta_engel','cov_engel','rho_qt'};
    used_filtered = false;
    if exist('Rf','var') && isstruct(Rf) && isfield(Rf,'stats')
        for f = FILT
            if isfield(Rf.stats,f{1}); R.stats.(f{1}) = Rf.stats.(f{1}); end
        end
        used_filtered = true;
        fprintf('  filtered rows spliced in: %s\n', strjoin(FILT,', '));
    end

    COLS = {'tfp','noise','comp','var'};      % Technology | Noise | Both | Uncond.
    pp   = R.pp;
    trim = @(x) x(1:end-1);                   % drop the point-estimate draw

    M  = NaN(size(ROWS,1), 4);
    LO = M;  HI = M;
    for r = 1:size(ROWS,1)
        s = R.stats.(ROWS{r,2});
        for c = 1:4
            v = trim(s.(COLS{c}));
            v = v(isfinite(v));
            if isempty(v); continue; end
            M(r,c) = median(v);
            b = prctile(v,[pp, 100-pp]);
            LO(r,c) = b(1);  HI(r,c) = b(2);
        end
    end

    prov = local_prov(R);
    if used_filtered
        prov = [prov ', Engel/rho(q) rows band-filtered over [2,100] quarters'];
    else
        prov = [prov ', WARNING: Engel/rho(q) rows are UNFILTERED (the draft filters them)'];
    end
    fn = fullfile(opt.outdir,'tab03_moments.tex');
    local_write(fn, M, LO, HI, ROWS, PANEL, prov);
    fprintf('  wrote Tables/tab03_moments.tex\n');
    out = struct('M',M,'LO',LO,'HI',HI,'rows',{ROWS(:,2)'},'skipped',{R.skipped});

    if opt.echo
        fprintf('\n  Table 3  %28s%9s%9s%9s\n','Technology','Noise','Both','Uncond');
        for r = 1:size(ROWS,1)
            fprintf('    %-34s%9s%9s%9s%9s\n', ROWS{r,2}, ...
                num2str(M(r,1),'%.2f'), num2str(M(r,2),'%.2f'), ...
                num2str(M(r,3),'%.2f'), num2str(M(r,4),'%.2f'));
        end
    end
end

function local_write(fn, M, LO, HI, ROWS, PANEL, prov)
    fid = fopen(fn,'w'); c = onCleanup(@() fclose(fid));
    provTX = tex_escape(prov);
    fprintf(fid,'%% Generated by write_moments_table.m -- do not edit by hand.\n%% %s\n', prov);
    fprintf(fid,'\\begin{table}[!t]\n\\centering\n');
    fprintf(fid,'\\caption{Exchange Rate Related Puzzles and TFP Expectations}\n');
    fprintf(fid,'\\label{tab: emp puzzles}\n');
    fprintf(fid,'\\begin{tabular}{l | C{2.1cm} C{2.1cm} C{2.1cm} | C{2.7cm}}\n');

    for p = 1:size(PANEL,1)
        idx = find(strcmp(ROWS(:,3), PANEL{p,1}));
        if isempty(idx); continue; end
        if p > 1
            fprintf(fid,'\n\\multicolumn{5}{c}{ } \\\\\n');
        end
        fprintf(fid,'\\multicolumn{5}{c}{%s} \\\\ \\hline\n', PANEL{p,2});
        fprintf(fid,' & Technology & Noise & Both & Unconditional \\\\ \\hline\n');
        % Value row, then band row, then a small gap before the next label.
        % The value row used to open with \vspace{-8pt}, meant to tuck the band
        % under its estimate. Inside C{} columns (m-type, vertically centred) a
        % negative vspace shifts the whole row instead, so each estimate landed on
        % top of the band above it -- the numbers were unreadable. \addlinespace
        % separates the PAIRS, which is what the -8pt was reaching for.
        for r = idx(:)'
            fprintf(fid,'%s & %s \\\\\n', ROWS{r,1}, ...
                strjoin(arrayfun(@(v) fmt(v), M(r,:), 'UniformOutput',false), ' & '));
            fprintf(fid,'\\scriptsize & %s \\\\[2pt]\n', ...
                strjoin(arrayfun(@(k) sprintf('\\scriptsize %s', ...
                    band(LO(r,k),HI(r,k))), 1:4, 'UniformOutput',false), ' & '));
        end
        fprintf(fid,'\\hline\n');
    end

    fprintf(fid,'\\end{tabular}\n');
    fprintf(fid,['\\caption*{\\footnotesize \\emph{Notes:} Moments conditional on ' ...
        'technological disturbances (Technology), expectational disturbances (Noise), ' ...
        'and the sum of both, alongside the moments implied by the estimated VAR ' ...
        '(Unconditional). Bracketed values are the 16--84 percentile bands across ' ...
        'posterior draws. %s}\n'], provTX);
    fprintf(fid,'\\end{table}\n');
end

function s = fmt(v)
    if ~isfinite(v); s = '--'; else; s = sprintf('$%.2f$', v); end
end

function s = band(lo, hi)
    if ~isfinite(lo) || ~isfinite(hi); s = '--';
    else; s = sprintf('$[%.2f, %.2f]$', lo, hi);
    end
end

function s = local_prov(R)
    p = {};
    if isfield(R.meta,'case');   p{end+1} = R.meta.case;                       end
    if isfield(R.meta,'ndraws'); p{end+1} = sprintf('ndraws=%d', R.meta.ndraws); end
    p{end+1} = sprintf('%d--%d percentile bands', R.pp, 100-R.pp);
    if ~isempty(R.skipped)
        p{end+1} = sprintf('SKIPPED (layout lacks %s)', ...
                           strjoin(unique(R.skipped(:,2))', ', '));
    end
    s = strjoin(p, ', ');
end
