function out = write_moments_table(datam, opt)
%WRITE_MOMENTS_TABLE  Write the exchange-rate puzzle moments (Tables 3, C.3).
%
%   out = WRITE_MOMENTS_TABLE(DATAM, OPT)
%
%   Ten moments in three panels, each conditioned four ways:
%
%       Technology | Noise | Both | Unconditional
%
%   Panel A  Forward Premium Puzzle          6 rows
%   Panel B  Backus-Smith Puzzle             2 rows
%   Panel C  Excess Volatility & Persistence 2 rows
%
%   Each estimate is the median across draws, with a [lo, hi] row beneath it at
%   the [pp, 100-pp] percentiles (pp = 16). The last element of each array is
%   the point-estimate draw and is excluded.
%
%   DATAM  path of a run .mat, a struct of run variables, or the result of
%          gentablemoments_final (recognised by its .stats field)
%   OPT    .outdir  required: the directory holding Figures/ and Tables/
%          .name    required: the file stem, 'Table3' or 'TableC3'
%          .echo    print the rows (default true)
%   out    struct with M, LO, HI (10 x 4), rows and skipped
%
%   Three rows, the Engel beta, cov(sum E_t lambda, r-r*) and rho(q_t), are
%   computed on data filtered over 2-100 quarter periodicities. They are taken
%   from the run's filtered_moments when the file has them.
%
%   Rows whose moment block was skipped for this VAR layout show `--` and are
%   named in the file's provenance comment. The file holds only the tabular
%   environment.
%
%   See also GENTABLEMOMENTS_FINAL, GENTABLEFILTEREDMOMENTS_FINAL.

    if nargin < 2; opt = struct(); end
    if ~isfield(opt,'echo'); opt.echo = true; end
    % opt.outdir is the exhibit root; Tables/ is appended here.
    assert(isfield(opt,'outdir') && ~isempty(opt.outdir), 'write_moments_table:noOutdir', ...
        'opt.outdir is required: the directory holding Figures/ and Tables/.');
    assert(isfield(opt,'name') && ~isempty(opt.name), 'write_moments_table:noName', ...
        'opt.name is required: the file stem, e.g. ''Table3''.');
    opt.outdir = fullfile(opt.outdir, 'Tables');
    if ~isfolder(opt.outdir); mkdir(opt.outdir); end

    % Get the moments: passed in, read from the run file, or computed.
    if isstruct(datam) && isfield(datam,'stats')
        R = datam;                                  % the result of gentablemoments_final
    else
        if ~isstruct(datam)
            W = who('-file', datam);
            if any(strcmp(W,'moments'))
                % Read the moments run_main saved, and the filtered ones if present.
                L = load(datam,'moments');  R = L.moments;
                fprintf('  moments: read from the case file (precomputed)\n');
                if any(strcmp(W,'info'))
                    lab = ccdgv_prov_label(load(datam,'info'));
                    if ~isempty(lab); R.meta.case = lab; end
                end
                if any(strcmp(W,'filtered_moments'))
                    LF = load(datam,'filtered_moments');  Rf = LF.filtered_moments;
                end
            else
                fprintf('  moments: not in the case file, computing (~15 s)\n');
                R = gentablemoments_final(datam);
            end
        else
            R = gentablemoments_final(datam);
        end
    end

    % Rows: label, field in R.stats, panel.
    ROWS = { ...
      '\citeauthor{Fama1984} $\beta_{\lambda}$',                                'beta_fama',   'A'
      'cov$(\lambda_{t+1}, r_t - r_t^{\star})$',                                'cov_fama',    'A'
      '\citeauthor{Engel2016} $\beta_{\Lambda}$',                               'beta_engel',  'A'
      'cov$\!\left(\sum_{k=0}^{\infty}\mathbb{E}_t(\lambda_{t+k+1}), r_t - r_t^{\star}\right)$', 'cov_engel', 'A'
      '$\sigma(r_t - r_t^{\star}) / \sigma(\Delta q_t)$',                       'sig_ratio',   'A'
      '$\rho(r_t - r_t^{\star})$',                                              'rho_rdiff',   'A'
      '$\corr(\Delta q_t, \Delta (c_t - c_t^{\star}))$',                        'corr_dq_dcd', 'B'
      'cov$(\Delta q_t, \Delta (c_t - c_t^{\star}))$',                          'cov_dq_dcd',  'B'
      '$\rho(q_t)$',                                                            'rho_qt',      'C'
      '$\sigma(\Delta q_t) / \sigma(\Delta c_t)$',                              'sig_dq_dc',   'C' };

    PANEL = { 'A', 'Panel A: Forward Premium Puzzle Moments'
              'B', 'Panel B: \citetalias{Backus1993consumption} Puzzle Moments'
              'C', 'Panel C: Excess Volatility and Persistence' };

    % Take the three band-filtered rows from the filtered moments when available.
    FILT = {'beta_engel','cov_engel','rho_qt'};
    used_filtered = false;
    if exist('Rf','var') && isstruct(Rf) && isfield(Rf,'stats')
        for f = FILT
            if isfield(Rf.stats,f{1}); R.stats.(f{1}) = Rf.stats.(f{1}); end
        end
        used_filtered = true;
        fprintf('  filtered rows spliced in: %s\n', strjoin(FILT,', '));
    end

    COLS = {'tfp','noise','comp','var'};      % Technology | Noise | Both | Uncond.
    pp   = R.pp;
    trim = @(x) x(1:end-1);                   % drop the point-estimate draw

    % Median and percentile band of each cell.
    M  = NaN(size(ROWS,1), 4);
    LO = M;  HI = M;
    for r = 1:size(ROWS,1)
        s = R.stats.(ROWS{r,2});
        for c = 1:4
            v = trim(s.(COLS{c}));
            v = v(isfinite(v));
            if isempty(v); continue; end
            M(r,c) = median(v);
            b = prctile(v,[pp, 100-pp]);
            LO(r,c) = b(1);  HI(r,c) = b(2);
        end
    end

    % Provenance line, saying whether the filtered rows were used.
    prov = local_prov(R);
    if used_filtered
        prov = [prov ', Engel/rho(q) rows band-filtered over [2,100] quarters'];
    else
        prov = [prov ', WARNING: Engel/rho(q) rows are UNFILTERED (the draft filters them)'];
    end
    fn = fullfile(opt.outdir, [opt.name '.tex']);
    local_write(fn, M, LO, HI, ROWS, PANEL, prov);
    fprintf('  wrote Tables/%s.tex\n', opt.name);
    out = struct('M',M,'LO',LO,'HI',HI,'rows',{ROWS(:,2)'},'skipped',{R.skipped});

    if opt.echo
        fprintf('\n  %-8s %28s%9s%9s%9s\n',opt.name,'Technology','Noise','Both','Uncond');
        for r = 1:size(ROWS,1)
            fprintf('    %-34s%9s%9s%9s%9s\n', ROWS{r,2}, ...
                num2str(M(r,1),'%.2f'), num2str(M(r,2),'%.2f'), ...
                num2str(M(r,3),'%.2f'), num2str(M(r,4),'%.2f'));
        end
    end
end

function local_write(fn, M, LO, HI, ROWS, PANEL, prov)
    fid = fopen(fn,'w'); c = onCleanup(@() fclose(fid));
    fprintf(fid,'%% Generated by write_moments_table.m -- do not edit by hand.\n%% %s\n', prov);
    fprintf(fid,'\\begin{tabular}{l | C{2.1cm} C{2.1cm} C{2.1cm} | C{2.7cm}}\n');

    for p = 1:size(PANEL,1)
        idx = find(strcmp(ROWS(:,3), PANEL{p,1}));
        if isempty(idx); continue; end
        if p > 1
            fprintf(fid,'\n\\multicolumn{5}{c}{ } \\\\\n');
        end
        fprintf(fid,'\\multicolumn{5}{c}{%s} \\\\ \\hline\n', PANEL{p,2});
        fprintf(fid,' & Technology & Noise & Both & Unconditional \\\\ \\hline\n');
        % Value row, then band row with a small gap after it.
        for r = idx(:)'
            fprintf(fid,'%s & %s \\\\\n', ROWS{r,1}, ...
                strjoin(arrayfun(@(v) fmt(v), M(r,:), 'UniformOutput',false), ' & '));
            fprintf(fid,'\\scriptsize & %s \\\\[2pt]\n', ...
                strjoin(arrayfun(@(k) sprintf('\\scriptsize %s', ...
                    band(LO(r,k),HI(r,k))), 1:4, 'UniformOutput',false), ' & '));
        end
        fprintf(fid,'\\hline\n');
    end

    fprintf(fid,'\\end{tabular}\n');
end

function s = fmt(v)
    if ~isfinite(v); s = '--'; else; s = sprintf('$%.2f$', v); end
end

function s = band(lo, hi)
    if ~isfinite(lo) || ~isfinite(hi); s = '--';
    else; s = sprintf('$[%.2f, %.2f]$', lo, hi);
    end
end

function s = local_prov(R)
    p = {};
    if isfield(R.meta,'case');   p{end+1} = R.meta.case;                       end
    if isfield(R.meta,'ndraws'); p{end+1} = sprintf('ndraws=%d', R.meta.ndraws); end
    p{end+1} = sprintf('%d--%d percentile bands', R.pp, 100-R.pp);
    if ~isempty(R.skipped)
        p{end+1} = sprintf('SKIPPED (layout lacks %s)', ...
                           strjoin(unique(R.skipped(:,2))', ', '));
    end
    s = strjoin(p, ', ');
end
