function [ARs, Sigs, Res, Xtra] = genvars(data, info)
%GENVARS  Estimate the reduced-form VAR and draw from its posterior.
%
%   [ARs, Sigs, Res, Xtra] = GENVARS(data, info)
%
%   data   T x nvars matrix of the series entering the VAR, already selected
%          and ordered by the caller.
%   info   run descriptor; the fields read are listed at the top of the code.
%
%   ARs    1 x (ndraws+1) cell, each nvars x nvars*nlags AR coefficients
%   Sigs   1 x (ndraws+1) cell, each nvars x nvars innovation covariance
%   Res    1 x (ndraws+1) cell, each T x nvars residual matrix
%   Xtra   estimator records: Xtra.bvecm for method 6, empty otherwise
%
%   Element ndraws+1 of each cell is the point estimate.
%
%   Pierre De Leo (2019), RAC (2021).

% Settings read from info.
S = info.settings;

est_method            = info.method;   % 1 = Minnesota Bayesian VAR, 6 = Bayesian VECM (Villani)

nlags                 = S.nlags;
ndraws                = S.ndraws;
nconst                = S.nconst;                  % 1 = constant in the VAR
prior                 = S.prior;                   % Minnesota tightness; inf = flat
prior_norm            = S.prior_norm;              % normalize prior var by residual s.d.
indiv_coeff_priorvar  = S.indiv_coeff_priorvar;    % (nlags*nvars+1)*nvars x 1 scaling
indiv_coeff_priormean = S.indiv_coeff_priormean;   % nvars x 1
maxeig_cutoff         = S.maxeig_cutoff;           % reject draws with larger max |eig|

% Seed the legacy random generators, so the draws are reproducible. The legacy
% stream stays selected after this function returns.
randn('state',0);
rand('state',0);

% Lag matrix, (T-nlags) x nvars*nlags: the first lag of all variables, then the
% second, and so on.
[TT,nvars]=size(data);
x = zeros(TT-nlags,1);
for p=1:nlags
    x(:,1+(p-1)*nvars:p*nvars)=data((nlags+1-p):(TT-p),:);
end

% Left-hand side: the data after the first nlags observations.
y=data((nlags+1):TT,:);

[T,nvars]=size(y);

% Regressors, with the constant in the last column.
ncoeffs = nvars*nlags;
if nconst==1
    xx = [x ones(T,1)];
    ncoeffs = ncoeffs+1;
end

Xtra = struct();

% OLS coefficients (ncoeffs x nvars), residuals and residual covariance.
b      = xx\y;
AR     = b;             % OLS point estimate
res    = y - xx*b;       % T x nvars residuals
vmat   = (1/T)*(res'*res);
Sig    = vmat;          % OLS covariance
stds   = sqrt(diag(vmat));
ARs    = cell(1,ndraws);
Sigs   = cell(1,ndraws);
Res    = cell(1,ndraws);
Bols   = companion_form(b(1:end-1,:)');
eiglist= NaN(1,3*ndraws);

% Method 1: Bayesian VAR with a Minnesota prior.
if est_method==1

    [hm,bm] = minneprc(y,xx,nlags,1,nconst,prior,prior_norm,indiv_coeff_priorvar,indiv_coeff_priormean); % Minnesota prior

    xxx  = (kron(eye(nvars),xx'*xx) + diagrv(eye(size(hm,1)),hm))\eye(length(hm));
    bb   = xxx * (vec(xx'*y) + bm);    % posterior mean: vec(b) = inv[inv(H) + kron(I,X'X)] * (vec(X'Y) + inv(H)*bprior)
    b    = reshape(bb,ncoeffs,nvars); % posterior coefficient matrix
    res  = y - xx*b;                   % T x nvars residuals
    vmat = (1/T)*(res'*res);

    sxx=chol(xxx)';
    sinv=chol(vmat\eye(size(vmat,1)));
    j  = 1;     % accepted draws
    jj = 1;     % draws tried
    while j<=ndraws

        randmatrix =randn(nvars,T,1); randvec    =randn(nvars*ncoeffs,1);
        [bbdraw,vmatdraw] = niw(b,sxx,sinv,T,randmatrix,randvec); % posterior draw
        bdraw       =reshape(bbdraw,ncoeffs,nvars);
        resdraw         = y - xx*bdraw;
        Bmat        = companion_form(bdraw(1:end-1,:)');
        maxeig      = max(abs(eig(Bmat))); eiglist(jj) = maxeig;  % largest eigenvalue modulus of the draw

        % Keep the draw if its largest eigenvalue is within the cutoff.
        if maxeig <= maxeig_cutoff
            % The constant is the last row of bdraw; the AR block is the rest.
            ARs{j}  = bdraw(1:nvars*nlags,:)';
            Sigs{j} = vmatdraw;
            Res{j}  = resdraw;
            j = j+1;
        end
        jj = jj+1;
    end

    % Append the point estimate.
    ARs{j}  = b(1:nvars*nlags,:)';
    Sigs{j} = vmat;
    Res{j}  = res;

    % Method 6: Bayesian VECM.
elseif est_method==6
    assert(isfield(S,'bvecm_rule'), 'genvars:method6NoRule', ...
        'est_method 6 needs a spec with a Bayesian VECM rule in ccdgv_manifest.');
    [ARs, Sigs, Res, Xtra.bvecm] = ccdgv_bvecm(data, info.inclvarnms, nlags, ...
                                              S.bvecm_rule, ndraws, maxeig_cutoff);

else
    error('genvars:badMethod', 'est_method %d is not implemented -- this package estimates 1 or 6.', est_method);
end


