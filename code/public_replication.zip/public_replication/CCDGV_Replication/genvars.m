function [ARs, Sigs, Res, Xtra] = genvars(data, info)
%GENVARS  Estimate the reduced-form VAR and draw from its posterior.
%
%   [ARs, Sigs, Res, Xtra] = GENVARS(data, info)
%
%   Xtra   estimator records; Xtra.bvecm for est_method 6, empty otherwise.
%
%   data   T x nvars matrix of the series entering the VAR (already
%          selected and ordered by the caller).
%   info   run descriptor; see the unpack block below for exactly which
%          fields are read.
%
%   ARs    1 x (ndraws+1) cell, each nvars x nvars*nlags companion AR block
%   Sigs   1 x (ndraws+1) cell, each nvars x nvars innovation covariance
%   Res    1 x (ndraws+1) cell, each T x nvars residual matrix
%
%   Element ndraws+1 of each is the point estimate, appended after the
%   draws. Nothing is written to disk -- the caller stores these through
%   run_stage.
%
%- Pierre De Leo (October 5, 2019)
%
% RAC updated on 12/10/21
% Converted from script to function, 2026-08-05.

% -------------------------------------------------------------------------
% Unpack from info everything this function needs.
%
% One name per line, and every setting used below appears here: as a
% script this file read a dozen variables straight out of run_main's
% workspace, which is what made it impossible to call from anywhere else.
% Keep this list exhaustive -- if a new setting is needed, add it here
% rather than reaching for a caller's variable.
% -------------------------------------------------------------------------
S = info.settings;

est_method            = info.method;   % 1 Minnesota Bayesian VAR, 6 Villani Bayesian VECM w/ fixed cointegration
fdvar                 = info.fdvar;    % columns entered in first differences ([] = none)

nlags                 = S.nlags;
ndraws                = S.ndraws;
nconst                = S.nconst;                  % 1 = constant in the VAR
prior                 = S.prior;                   % Minnesota tightness; inf = flat
prior_norm            = S.prior_norm;              % normalize prior var by residual s.d.
indiv_coeff_priorvar  = S.indiv_coeff_priorvar;    % (nlags*nvars+1)*nvars x 1 scaling
indiv_coeff_priormean = S.indiv_coeff_priormean;   % nvars x 1
maxeig_cutoff         = S.maxeig_cutoff;           % reject draws with larger max |eig|
param                 = S.vecm;                    % VECM options (est_method 3)
trP                   = S.trP;                     % basis map: y_t = P z_t - Q z_{t-1}
trQ                   = S.trQ;                     % identity/zero when no transform
has_transform         = S.has_transform;           % false => every branch below no-ops

% -------------------------------------------------------------------------
% Estimate VARs
% -------------------------------------------------------------------------

% SEEDS THE LEGACY GENERATORS, AND LEAVES THEM SELECTED. 'state' selects
% MATLAB's pre-2008 generators and seeds them at 0, which is what makes the VAR
% draws below reproducible run to run. It is deliberate and must not be removed:
% dropping it changes every draw, and so every number in the paper.
%
% THE SIDE EFFECT IS GLOBAL. The stream is still Legacy when this function
% returns -- a session is on 'twister' before sweep and on 'Legacy' after -- so
% anything that draws later in the same session without seeding itself inherits
% it. Nothing in the package does: ccdgv_project_draw seeds explicitly with rng(),
% and the identification and figure code draws no random numbers at all. Restoring
% the previous generator here would be tidier and is NOT done, because it would
% change the stream any such caller sees and no test in the package would catch it.
randn('state',0);
rand('state',0);
%-------------------------------------------------------------
% Step 0: parameter settings
%-------------------------------------------------------------


%- compute nlags lags
[TT,nvars]=size(data);
x = zeros(TT-nlags,1);
for p=1:nlags
    x(:,1+(p-1)*nvars:p*nvars)=data((nlags+1-p):(TT-p),:);
    %gives (T-nlags) x nvars*nlags matrix of lags for all variables
    %first lag of all variables first, then second lag of all variables
    %and so on...
end

%rescaling variables since we lose nlags observations through the lagging
y=data((nlags+1):TT,:);

[T,nvars]=size(y);

%- PRIOR MEAN ON OWN FIRST LAG -- NOT DECIDED HERE. This used to be
%     lev = ones(coly,1); lev(fdvar) = 0;
% i.e. "anything not differenced is a level, give it the unit-root prior".
% Right for every untransformed spec, backwards for the VECM, whose
% undifferenced rows are the cointegrating relations the spec assumes
% STATIONARY. genvars cannot get it right either: it sees fdvar, not the
% transform table that says what those rows MEAN. Declared per row in
% ccdgv_manifest, it arrives here as indiv_coeff_priormean.
param.nrank   = nvars-param.nrank;    %Rank of cointegration (nvar == levels)


%---------------------------------------------------------------------
% Step 3: Estimate VAR, extract shocks, FEV shares explained, and IRFs
%---------------------------------------------------------------------
ncoeffs = nvars*nlags;
if nconst==1
    xx = [x ones(T,1)];
    ncoeffs = ncoeffs+1;
end

Xtra = struct();

%ncoeffs + 1 x nvars matrix of regression coefficients
b      = xx\y;           % OLS coefficients: ncoeffs x nvars (** more efficient way of computing least squares; i.e. b=inv(x'*x)*x'*y;
AR     = b;             % point estimate to store
res    = y - xx*b;       % T x nvar matrix of residuals
vmat   = (1/T)*(res'*res);
Sig    = vmat;          % point estimate to store
stds   = sqrt(diag(vmat));
ARs    = cell(1,ndraws);
Sigs   = cell(1,ndraws);
Res    = cell(1,ndraws);
Bols   = companion_form(b(1:end-1,:)');
eiglist= NaN(1,3*ndraws);

%- Bayesian estimation with Minnesota prior
if est_method==1

    [hm,bm] = minneprc(y,xx,nlags,1,nconst,prior,prior_norm,indiv_coeff_priorvar,indiv_coeff_priormean); % Minnesota prior

    xxx  = (kron(eye(nvars),xx'*xx) + diagrv(eye(size(hm,1)),hm))\eye(length(hm));
    bb   = xxx * (vec(xx'*y) + bm);    % stacked posterior means of regression coeffs: vec(bpost) = inv[inv(H) + kron(I,X'X)] * [vec[X'Y] + inv(H)*bprior]
    b    = reshape(bb,ncoeffs,nvars); % posterior coefficient matrix
    res  = y - xx*b;                   % T x nvar matrix of residuals
    vmat = (1/T)*(res'*res);

    sxx=chol(xxx)';
    sinv=chol(vmat\eye(size(vmat,1)));
    j  = 1;     %Count the keepers
    jj = 1;     %Total draws tried
    while j<=ndraws

        randmatrix =randn(nvars,T,1); randvec    =randn(nvars*ncoeffs,1);
        [bbdraw,vmatdraw] = niw(b,sxx,sinv,T,randmatrix,randvec); %drawing from posterior coefficient matrix
        bdraw       =reshape(bbdraw,ncoeffs,nvars);
        resdraw         = y - xx*bdraw;
        Bmat        = companion_form(bdraw(1:end-1,:)');
        maxeig      = max(abs(eig(Bmat))); eiglist(jj) = maxeig;  %Store list of all eigs

        % THE FILTER RUNS ON THE ESTIMATED SYSTEM, DELIBERATELY. Bmat above is
        % built from bdraw BEFORE the round trip below, so draws are accepted on
        % the stationarity of the DIFFERENCED system and only then rewritten in
        % levels. The original did exactly this. Testing the levels system
        % instead would reject nearly every draw: it carries a unit root by
        % construction, which is the point of a VECM.

        %Only store those with eigs <= 1
        if maxeig <= maxeig_cutoff
            % bdraw is ncoeffs x nvars with the CONSTANT as its last row
            % (xx = [x ones(T,1)]), so this slice takes the AR block and drops
            % it -- make_gam takes the AR block only.
            if has_transform
                % Back to the LEVELS basis. Everything downstream -- Aproj,
                % gen_auxvars, the moment lookups -- addresses the spec's own
                % variables, so the stored system has to be in them.
                [Bl, Pm] = make_gam(bdraw(1:end-1,:)', trP, trQ, nvars, nlags);
                bl       = Bl(1:nvars,:)';
                ARs{j}   = bl(1:nvars*nlags,:)';
                Sigs{j}  = (Pm\vmatdraw)/Pm';   % rotate the covariance...
                Res{j}   = (Pm\resdraw')';      % ...and the residuals, with it
            else
                ARs{j}  = bdraw(1:nvars*nlags,:)'; % store ARs for Ryan
                Sigs{j} = vmatdraw;
                Res{j}  = resdraw;
            end
            j = j+1;
        end
        jj = jj+1;
    end

    %Append "point estimates" to end
    if has_transform
        [Bl, Pm] = make_gam(b(1:end-1,:)', trP, trQ, nvars, nlags);
        bl       = Bl(1:nvars,:)';
        ARs{j}   = bl(1:nvars*nlags,:)';
        Sigs{j}  = (Pm\vmat)/Pm';
        Res{j}   = (Pm\res')';
    else
        ARs{j}  = b(1:nvars*nlags,:)'; % store ARs for Ryan
        Sigs{j} = vmat;
        Res{j}  = res;
    end

    if has_transform
        fprintf(['  VECM: estimated on the transformed basis, stored in ' ...
                 'LEVELS via make_gam (%d of %d variables differenced).\n'], ...
                numel(fdvar), nvars);
    end

    %- OLS and classical bootstrap for CIs
elseif est_method==6
    assert(isfield(S,'bvecm_rule'), 'genvars:method6NoRule', ...
        'est_method 6 needs a spec with a Bayesian VECM rule in ccdgv_manifest.');
    [ARs, Sigs, Res, Xtra.bvecm] = ccdgv_bvecm(data, info.inclvarnms, nlags, ...
                                              S.bvecm_rule, ndraws, maxeig_cutoff);

else
    error('genvars:badMethod', 'est_method %d is not implemented -- this package estimates 1 or 6.', est_method);
end

% ARs/Sigs/Res are returned to the caller; the former
% save('Dataset_Output/vars',...) is gone -- run_stage owns persistence now.

