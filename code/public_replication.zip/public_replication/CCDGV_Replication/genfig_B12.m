function fout = genfig_B12(base_info, nofx_info, dest)
%GENFIG_B12  Figure B.12 -- the exchange rate response, with and without NER in the VAR.
%   fout = GENFIG_B12(base_info, nofx_info)
%   fout = GENFIG_B12(base_info, nofx_info, dest)     dest is required
%
%   Two panels (Technology, Noise) showing the Real Exchange Rate response from
%   the BASELINE run, with bands, overlaid with the same row from the NO-FX run
%   as a dashed line -- the draft's "VAR w/o Exchange Rate".
%
%   TAKES INFOS, NOT FILENAMES. The paths come from data_name(info), so changing
%   a spec in sweep propagates here with nothing to retype and no stale
%   hard-coded path. This is also why it needs no sweep_datam: the two runs are
%   named explicitly rather than one being smuggled through an environment
%   variable.
%
%   WHY THE TWO RUNS COMBINE SO EASILY. Both carry the SAME 30 manifest rows in
%   the same order -- 'Real Exchange Rate' is row 19 in each -- because the row
%   set comes from the manifest, not from which variables happen to be in the
%   VAR. Under the old positional scheme this figure needed a mapping table.
%
%   WHAT THE DASHED LINE IS. Not a projection. The shock is identified from the
%   seven variables, then the FULL system's own spectrum gives the RER response to
%   it (IRFS_FROM_SUBSET). So the dashed line is the baseline system's real
%   exchange rate reacting to a shock recovered without it -- which is why it
%   tracks the solid line closely under technology and departs from it under
%   noise. It is not the same object as the solid line.
%
%   WHAT IT IS NOT, because this is the natural assumption: the real exchange rate
%   of the re-estimated no-FX run. NER is not in that VAR, so its row there is a
%   PROJECTION on the companion state (R2 ~ 0.78 on the paper sample) -- that
%   VAR's best linear predictor of the real exchange rate, not the real exchange
%   rate. The draft does not plot it, so this function does not build it.
%
%   See also PLOTIRF, DATA_NAME, SWEEP.

    assert(nargin >= 3 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end

    B = local_load(base_info, 'baseline');
    % Bands come from the baseline run's settings; the draws are the restricted
    % build's.
    R = nofx_restricted(base_info, nofx_info, struct());
    N = B;
    N.irtfp = R.irtfp;  N.irnoise = R.irnoise;  N.vnames = R.vnames;
    src = 'paper construction';

    assert(isequal(B.vnames, N.vnames), 'genfig_B12:rowMismatch', ...
        ['the two runs have different row sets (%d vs %d names) -- they must ' ...
         'share a manifest layout to be overlaid.'], numel(B.vnames), numel(N.vnames));

    i = var_order(B.vnames, 'Real Exchange Rate');

    % Same band construction as genplots_paper_pierre1: cumulate, take -50:20,
    % discard 30 -> the -20:20 window the draft plots.
    [db_t, db_n] = local_bands(B, i);
    [dn_t, dn_n] = local_bands(N, i);

    nimp = size(db_t,1);
    main = NaN(nimp,4,5);  over = NaN(nimp,4,5);
    main(:,1,:) = db_t;  main(:,3,:) = db_t;
    main(:,2,:) = db_n;  main(:,4,:) = db_n;
    over(:,1,:) = dn_t;  over(:,3,:) = dn_t;
    over(:,2,:) = dn_n;  over(:,4,:) = dn_n;

    p = plotIRF;
    p.nrow = 1;  p.ncol = 2;
    p.NOISE = [0 1];                                  % blue technology, red noise
    p.position = [1 1 4/3*425 4/3*425/3];
    p.ylab = {'Real Exchange Rate', ''};
    p.overlay = struct('data', over, 'style','--k', ...
                       'label','VAR w/o Exchange Rate');

    % TWO names, not four: numel(VARS) sets plotIRF's offset into DATA, and DATA
    % here is nimp x 2*2 x 5 -- the two shocks ARE the two "variables".
    fout = plotIRF(main, [1;2], {'Technology','Noise'}, 'irrer_r_new', [1 2], p);
    exportgraphics(fout(1), fullfile(dest, 'irrer_r_new.pdf'));
    fprintf('  wrote irrer_r_new.pdf (Figure B.12)\n');
    fprintf('    baseline %s\n    no-FX    %s [%s]\n', ...
            data_name(base_info), data_name(nofx_info), src);
end

% -------------------------------------------------------------------------
function D = local_load(info, what)
    [~, f] = data_name(info);
    assert(isfile(f), 'genfig_B12:noFile', ...
           '%s run: %s not found -- run run_sweep first.', what, f);
    D = load(f, 'irtfp','irnoise','vnames','point_estimate','bound','bound2');
end

function [dt, dn] = local_bands(D, i)
%LOCAL_BANDS  Median and percentile bands for row i, on the -20:20 CJ window.
    h = (size(D.irtfp,1)-1)/2;
    hgrid = -50:20;  discard = 30;
    it = cumsum(D.irtfp);   in = cumsum(D.irnoise);
    it = squeeze(it(hgrid+h+1, i, :));      % nimp x ndraws
    in = squeeze(in(hgrid+h+1, i, :));
    dt = local_pack_one_column(it, D, discard);
    dn = local_pack_one_column(in, D, discard);
end

function d = local_pack_one_column(x, D, discard)
% pages: 1 = point estimate, 2/3 = inner band, 4/5 = outer band.
% NOT PACK_BANDS, which the other generators share. This figure draws a single
% series, so there is one column and no duplication, and the quantiles come from
% prctile on a 2-D array rather than quantile along the third dimension.
    if D.point_estimate; m = x(:,end); else; m = median(x(:,1:end-1), 2); end
    q  = prctile(x(:,1:end-1), 100*[D.bound 1-D.bound D.bound2 1-D.bound2], 2);
    d  = NaN(size(x,1)-discard, 1, 5);
    d(:,1,1) = m(discard+1:end);
    d(:,1,2) = q(discard+1:end,1);   d(:,1,3) = q(discard+1:end,2);
    d(:,1,4) = q(discard+1:end,3);   d(:,1,5) = q(discard+1:end,4);
end
