function nmiss = compile_exhibits(root)
%COMPILE_EXHIBITS  Rebuild paper_exhibits.pdf from the figures and tables on disk.
%
%   nmiss = compile_exhibits(root)
%
%   root   the exhibit directory (cfg.exhibitdir); it holds paper_exhibits.tex
%          beside Figures/, Tables/ and Hand/.
%   nmiss  number of exhibit slots that came out empty; NaN if nothing was
%          compiled.
%
%   A missing figure or table does not fail the build: the document draws a
%   "not found" box and writes a marker line to the log, which is counted here.
%
%   See also EXHIBITS, RUN_ALL.

    nmiss = NaN;
    tex = fullfile(root, 'paper_exhibits.tex');
    if ~isfile(tex)
        fprintf('  no paper_exhibits.tex in %s; nothing to compile\n', root);
        return
    end
    if system('which pdflatex > /dev/null 2>&1') ~= 0
        fprintf(['  pdflatex not on PATH: paper_exhibits.pdf NOT rebuilt and is\n' ...
                 '  now older than the figures above. Compile it by hand.\n']);
        return
    end

    here = cd(root);
    back = onCleanup(@() cd(here));
    % Two passes, so that cross-references resolve.
    for k = 1:2
        [st, ~] = system('pdflatex -interaction=nonstopmode -halt-on-error paper_exhibits.tex');
    end
    if st ~= 0 || ~isfile('paper_exhibits.pdf')
        fprintf(2, '  pdflatex failed; see %s\n', fullfile(root,'paper_exhibits.log'));
        return
    end

    % One marker line in the log per empty slot, written by \missing.
    miss  = regexp(fileread('paper_exhibits.log'), 'CCDGV-MISSING ([^\r\n]*)', 'tokens');
    miss  = unique(cellfun(@(c) strtrim(c{1}), miss, 'UniformOutput', false), 'stable');
    nmiss = numel(miss);
    if nmiss > 0
        fprintf(2, ['  paper_exhibits.pdf rebuilt, but %d exhibit slot(s) are empty:\n' ...
                    '    %s\n  Those figures or tables were not produced by this run.\n'], ...
                nmiss, strjoin(miss, ', '));
    else
        fprintf('  paper_exhibits.pdf rebuilt, every slot filled\n');
    end
end
