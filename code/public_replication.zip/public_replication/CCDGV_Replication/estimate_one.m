function info = estimate_one(cfg, key, inclvar, country, sd, ed)
%ESTIMATE_ONE  Estimate one specification and save it.
%
%   info = estimate_one(cfg, key, inclvar, country, sd, ed)
%
%   cfg      settings struct from config().
%   key      short name for the run; labels it in sweep_infos. The file name
%            comes from data_name.
%   inclvar  VAR specification number (see ccdgv_manifest).
%   country  'G6' or one of the six country names.
%   sd, ed   sample start and end as fractional years. sd is required; an empty
%            ed takes cfg.end_date.
%   info     the run descriptor, with the realised sample recorded on it.
%
%   The sample window is binding: run_main errors if a VAR column is NaN inside it.

    assert(nargin >= 5 && ~isempty(sd), 'estimate_one:noStart', ...
        ['%s has no start date. Every row of sweep''s SPECS table carries one; ' ...
         'there is no package-level default.'], key);
    if nargin < 6 || isempty(ed); ed = cfg.end_date;   end

    % Estimator: 6 (Bayesian VECM) if the specification declares one, else 1.
    [~, ~, ~, TR] = ccdgv_manifest();
    est_method = 1;
    if numel(TR) >= inclvar && isstruct(TR{inclvar}) && isfield(TR{inclvar}, 'bayes')
        est_method = 6;        % Bayesian VECM
    end

    % The run descriptor.
    info = struct('country', country, 'datver', 'new', 'method', est_method, ...
                  'inclvar', inclvar, 'ed', ed, 'fdvar', [], ...
                  'sd', sd, 'outdir', cfg.resultdir, 'key', key);

    info.settings = struct( ...
        'nlags',        cfg.nlags, ...
        'ndraws',       cfg.ndraws, ...
        'smax',         cfg.smax, ...
        'smax_store',   cfg.smax_store, ...
        'shock_extract', 1, ...
        'proj_prior',   cfg.proj, ...
        'proj_seed_base', cfg.proj_seed_base, ...
        'point_estimate', 0, ...
        'j_cj_horizon', cfg.j_cj_horizon, ...
        'nimp',         cfg.nimp, ...
        'vd_fr',        cfg.vd_fr, ...
        'vd_feh',       cfg.vd_feh, ...
        'bound',        cfg.bound, ...
        'bound2',       cfg.bound2, ...
        'nplot',        cfg.nplot, ...
        'confidence_bands', 1, ...
        'fv_requested', cfg.vintage);

    % Settings genvars reads from info.
    info.settings.nconst        = 1;
    info.settings.prior         = 1;
    info.settings.prior_norm    = 0;
    info.settings.maxeig_cutoff = 1;
    info.settings.vecm = struct('nlag', 3, 'nrank', 0, 'det_var', 1, ...
                                'ttrend', 0, 'det_ec', 0, 'nper', 32, ...
                                'check_rank', false);

    % Identification passes. shock_extract 1 maximises forecast-error variance, so
    % KLbar/KUbar are horizons; 2 uses a frequency band, so they are frequencies
    % (omega = 2*pi/period). want_vardec_fd says whether to keep the band variance
    % shares, which only Table 1 shows.
    %        label              se  KLbar       KUbar      vardec_fd
    IDENTS = { ...
        {'baseline_FEV100', 1,  100,        100,       true }, ...
        {'AF_2_1000',       2,  2*pi/1000,  2*pi/2,    false}, ...
        {'HF_6_32',         2,  2*pi/32,    2*pi/6,    false}};
    info.ident = struct('label',{},'shock_extract',{},'KLbar',{},'KUbar',{}, ...
                        'want_vardec_fd',{});
    for k = 1:numel(IDENTS)
        info.ident(k) = struct('label', IDENTS{k}{1}, 'shock_extract', IDENTS{k}{2}, ...
                               'KLbar', IDENTS{k}{3}, 'KUbar', IDENTS{k}{4}, ...
                               'want_vardec_fd', IDENTS{k}{5});
    end

    % Only the baseline run needs the two appendix identification passes
    % (Tables C.4/C.5) and the rolling-window trading strategy (Table C.9).
    if strcmp(key, 'base')
        info.idrun        = 1:3;
        info.trade_windows = 60:4:100;
    else
        info.idrun        = 1;
        info.trade_windows = [];
    end
    % The moments block is read only from base and extend (Tables 3 and C.3, and
    % the text numbers).
    info.want_moments = ismember(key, {'base','extend'});

    % Validate before the run (the requested specification) and after it (the
    % realised sample).
    validate_info(info);
    info = run_spec(info);
    validate_info(info);
end

function info = run_spec(info)
% run_main is a script: it reads `info` from the calling workspace and writes
% its results there. This wrapper keeps its variables out of estimate_one.
    run_main;
    info.nobs_realised = size(data, 1);
end
