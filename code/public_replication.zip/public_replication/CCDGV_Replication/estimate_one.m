function info = estimate_one(cfg, key, inclvar, country, sd, ed)
%ESTIMATE_ONE  Estimate one specification and save it.
%
%   info = estimate_one(cfg, key, inclvar, country, sd, ed)
%
%   key      short name for the run. It selects the spec and labels it in
%            sweep_infos; it does NOT name the file. data_name builds that from
%            country, method, variable set and sample -- see C6.
%   inclvar  which VAR specification (see ccdgv_manifest)
%   country  'G6' or one of the six names
%   sd, ed   sample start and end as fractional years; [] takes cfg's value
%
%   Returns info with the realised sample recorded on it.
%
%   THE ESTIMATOR IS DERIVED FROM THE SPECIFICATION, not chosen. A spec that
%   declares a Bayesian VECM rule needs est_method 6 and everything else needs 1;
%   unpack_info asserts the pairing, so there is nothing for a caller to get
%   wrong and no reason for it to be a setting.
%
%   THE SAMPLE WINDOW IS BINDING. run_main errors if any VAR column is NaN inside
%   [sd, ed] rather than dropping the row, so a start date that the data cannot
%   support fails loudly instead of quietly estimating a shorter sample.

    assert(nargin >= 5 && ~isempty(sd), 'estimate_one:noStart', ...
        ['%s has no start date. Every row of sweep''s SPECS table carries one; ' ...
         'there is no package-level default.'], key);
    if nargin < 6 || isempty(ed); ed = cfg.end_date;   end

    % ---- the estimator, derived from the spec ------------------------------
    [~, ~, ~, TR] = ccdgv_manifest();
    est_method = 1;
    if numel(TR) >= inclvar && isstruct(TR{inclvar}) && isfield(TR{inclvar}, 'bayes')
        est_method = 6;        % Bayesian VECM; unpack_info asserts this pairing
    end

    % ONE PROJECTION STAGE: drawn, AR(2) errors, no shrinkage except where the
    % manifest asks for it per row.

    % ---- info, as the run expects it ---------------------------------------
    info = struct('country', country, 'datver', 'new', 'method', est_method, ...
                  'inclvar', inclvar, 'ed', ed, 'fdvar', [], ...
                  'sd', sd, 'outdir', cfg.resultdir, 'key', key);

    info.settings = struct( ...
        'nlags',        cfg.nlags, ...
        'ndraws',       cfg.ndraws, ...
        'smax',         cfg.smax, ...
        'smax_store',   cfg.smax_store, ...
        'shock_extract', 1, ...
        'proj_prior',   cfg.proj, ...
        'proj_seed_base', cfg.proj_seed_base, ...
        'point_estimate', 0, ...
        'j_cj_horizon', cfg.j_cj_horizon, ...
        'nimp',         cfg.nimp, ...
        'vd_fr',        cfg.vd_fr, ...
        'vd_feh',       cfg.vd_feh, ...
        'bound',        cfg.bound, ...
        'bound2',       cfg.bound2, ...
        'nplot',        cfg.nplot, ...
        'confidence_bands', 1, ...
        'fv_requested', cfg.vintage);

    % genvars reads these out of info, so they travel with it.
    info.settings.nconst        = 1;
    info.settings.prior         = 1;
    info.settings.prior_norm    = 0;
    info.settings.maxeig_cutoff = 1;
    info.settings.vecm = struct('nlag', 3, 'nrank', 0, 'det_var', 1, ...
                                'ttrend', 0, 'det_ec', 0, 'nper', 32, ...
                                'check_rank', false);

    % ---- identification passes ---------------------------------------------
    % shock_extract 1 = forecast-error variance over a horizon band, so
    % KLbar/KUbar are HORIZONS; 2 = a frequency band, so they are frequencies
    % (omega = 2*pi/period). want_vardec_fd decides whether the band variance
    % shares, which only Table 1 displays, are KEPT -- not whether they are
    % computed. maxshr runs that loop whenever cfg.vd_fr is non-empty, with no
    % nargout guard, so the two appendix passes save storage and not time.
    %        label              se  KLbar       KUbar      vardec_fd
    IDENTS = { ...
        {'baseline_FEV100', 1,  100,        100,       true }, ...
        {'AF_2_1000',       2,  2*pi/1000,  2*pi/2,    false}, ...
        {'HF_6_32',         2,  2*pi/32,    2*pi/6,    false}};
    info.ident = struct('label',{},'shock_extract',{},'KLbar',{},'KUbar',{}, ...
                        'want_vardec_fd',{});
    for k = 1:numel(IDENTS)
        info.ident(k) = struct('label', IDENTS{k}{1}, 'shock_extract', IDENTS{k}{2}, ...
                               'KLbar', IDENTS{k}{3}, 'KUbar', IDENTS{k}{4}, ...
                               'want_vardec_fd', IDENTS{k}{5});
    end

    % Only the baseline run needs the two appendix identification passes
    % (Tables B.4/B.5) and the rolling-window trading strategy (Table B.9).
    if strcmp(key, 'base')
        info.idrun        = 1:3;
        info.trade_windows = 60:4:100;
    else
        info.idrun        = 1;
        info.trade_windows = [];
    end
    % Table 3 and the text numbers are the only readers of the moments block, and
    % they read `base` and `extend`. Every other spec would compute them unread.
    info.want_moments = ismember(key, {'base','extend'});

    % ---- run ----------------------------------------------------------------
    % VALIDATED TWICE, BEFORE AND AFTER, because the two halves of validate_info
    % need different moments. The contradiction checks want the requested spec and
    % must fire before an hour of estimation; the realised-sample checks compare
    % sd/ed against sd_realised/ed_realised, which run_spec is what sets. Calling
    % it once before the run left those three blocks permanently skipped -- their
    % isfield guards were simply never true.
    validate_info(info);
    info = run_spec(info);
    validate_info(info);
end

% =========================================================================
function info = run_spec(info)
% run_main is a script: it reads `info` from the caller's workspace and writes
% its results there. Calling it inside this helper keeps its many intermediate
% variables out of estimate_one's workspace, and out of the caller's.
    run_main;
    info.nobs_realised = size(data, 1);
end
