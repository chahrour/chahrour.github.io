function info = estimate_one(cfg, key, inclvar, country, sd, ed)
%ESTIMATE_ONE  Estimate one specification and save it.
%
%   info = estimate_one(cfg, key, inclvar, country, sd, ed)
%
%   cfg      settings struct from config().
%   key      short name for the run; labels it in sweep_infos. The file name
%            comes from data_name.
%   inclvar  VAR specification number (see ccdgv_manifest).
%   country  'G6' or one of the six country names.
%   sd, ed   sample start and end as fractional years.
%   info     the run descriptor, with the realised sample recorded on it.
%
%   The stages are data and projections, VAR estimation, identification, the
%   technology and noise decomposition, moments, and the trading strategy.
%   run_stage saves each one to the run file. A NaN in a VAR column inside the
%   sample window is an error.
%
%   See also SWEEP, UNPACK_INFO, RUN_STAGE, CCDGV_PROJECT_DRAWS.

    % Estimator: 6 (Bayesian VECM) if the specification declares one, else 1.
    [manifest, constructed, ~, TR] = ccdgv_manifest();
    est_method = 1;
    if numel(TR) >= inclvar && isstruct(TR{inclvar}) && isfield(TR{inclvar}, 'bayes')
        est_method = 6;        % Bayesian VECM
    end

    % The run descriptor.
    info = struct('country', country, 'datver', 'new', 'method', est_method, ...
                  'inclvar', inclvar, 'ed', ed, ...
                  'sd', sd, 'outdir', cfg.resultdir, 'key', key);

    info.settings = struct( ...
        'nlags',        cfg.nlags, ...
        'ndraws',       cfg.ndraws, ...
        'smax',         cfg.smax, ...
        'smax_store',   cfg.smax_store, ...
        'shock_extract', 1, ...
        'proj_prior',   cfg.proj, ...
        'proj_seed_base', cfg.proj_seed_base, ...
        'point_estimate', 0, ...
        'j_cj_horizon', cfg.j_cj_horizon, ...
        'nimp',         cfg.nimp, ...
        'vd_fr',        cfg.vd_fr, ...
        'vd_feh',       cfg.vd_feh, ...
        'bound',        cfg.bound, ...
        'bound2',       cfg.bound2, ...
        'nplot',        cfg.nplot, ...
        'confidence_bands', 1);

    % Settings genvars reads from info.
    info.settings.nconst        = 1;
    info.settings.prior         = 1;
    info.settings.prior_norm    = 0;
    info.settings.maxeig_cutoff = 1;

    % Identification passes. shock_extract 1 maximises forecast-error variance, so
    % KLbar/KUbar are horizons; 2 uses a frequency band, so they are frequencies
    % (omega = 2*pi/period). want_vardec_fd says whether to keep the band variance
    % shares, which only Table 1 shows.
    %        label              se  KLbar       KUbar      vardec_fd
    IDENTS = { ...
        {'baseline_FEV100', 1,  100,        100,       true }, ...
        {'AF_2_1000',       2,  2*pi/1000,  2*pi/2,    false}, ...
        {'HF_6_32',         2,  2*pi/32,    2*pi/6,    false}};
    info.ident = struct('label',{},'shock_extract',{},'KLbar',{},'KUbar',{}, ...
                        'want_vardec_fd',{});
    for k = 1:numel(IDENTS)
        info.ident(k) = struct('label', IDENTS{k}{1}, 'shock_extract', IDENTS{k}{2}, ...
                               'KLbar', IDENTS{k}{3}, 'KUbar', IDENTS{k}{4}, ...
                               'want_vardec_fd', IDENTS{k}{5});
    end

    % Only the baseline run needs the two appendix identification passes
    % (Tables C.4/C.5) and the rolling-window trading strategy (Table C.9).
    if strcmp(key, 'base')
        info.idrun        = 1:3;
        info.trade_windows = 60:4:100;
    else
        info.idrun        = 1;
        info.trade_windows = [];
    end
    % The moments block is read only from base and extend (Tables 3 and C.3, and
    % the text numbers).
    info.want_moments = ismember(key, {'base','extend'});

    % Validate the requested specification, then derive what follows from it:
    % inclvarnms and the prior arrays.
    validate_info(info);
    info = unpack_info(info);
    S = info.settings;            % read from here on; results go to info.settings
    nvars = S.nvars;  nlags = S.nlags;  ndraws = S.ndraws;
    vkey  = {manifest.key};

    %% Data stage
    % Settings that readers of the run file take as top-level variables.
    Sc = struct('bound',S.bound, 'bound2',S.bound2, 'vd_fr',S.vd_fr, 'vd_feh',S.vd_feh, ...
                'nplot',S.nplot, 'confidence_bands',S.confidence_bands, ...
                'point_estimate',S.point_estimate, 'nvars',nvars, 'nlags',nlags, ...
                'ndraws',ndraws, 'smax',S.smax, 'j_cj_horizon',S.j_cj_horizon, ...
                'end_date',ed, 'country',country);
    info = run_stage(info,'config',Sc);

    % All series, one column per manifest row, from the panels in
    % Data_Replication/Built_Data.
    [yall, dates, info.settings.tfp_vintage, info.settings.tfp_source] = ryan_data(country, sd, ed);
    nvall = size(yall, 2);
    assert(nvall == numel(manifest), ...
        ['loader returned %d columns but the manifest declares %d. They must match ' ...
         'one-for-one and in order.'], nvall, numel(manifest));
    vnames       = [{manifest.name},  {constructed.name}];
    vnames_short = [{manifest.short}, {constructed.short}];

    % The sample window is binding: a NaN in a VAR column inside it is an error
    % that names the series and the quarters. Only the VAR columns are checked.
    yidx   = var_order(vkey, info.inclvarnms{:})';
    nanrow = ~all(isfinite(yall(:,yidx)), 2);
    if any(nanrow)
        dstr  = @(k) sprintf('%.2f', dates(k));
        lines = {};
        for jj = yidx(:)'
            q = find(~isfinite(yall(:,jj)));
            if isempty(q); continue; end
            if numel(q) <= 6
                when = strjoin(cellfun(dstr, num2cell(q), 'UniformOutput', false), ', ');
            else
                when = sprintf('%s .. %s (%d quarters)', dstr(q(1)), dstr(q(end)), numel(q));
            end
            lines{end+1} = sprintf('    %-16s %s', manifest(jj).name, when);   %#ok<AGROW>
        end
        error('estimate_one:nanInWindow', ...
            ['%d of %d quarters in the window %s..%s have a NaN in a VAR column.\n%s\n' ...
             'The window is binding: give %s a start and end in sweep''s SPECS table ' ...
             'that these series cover.'], sum(nanrow), numel(dates), dstr(1), ...
            dstr(numel(dates)), strjoin(lines, newline), key);
    end
    data = yall(:,yidx);           % the VAR, in levels

    % Project every series on the VAR state, in levels. projblocks: number of
    % state blocks each series is projected on; an empty manifest entry means
    % nlags, the full companion state. Ures: projection residuals, one column
    % per series, NaN where a row was unused.
    r2 = NaN(1,nvall);  nobs = NaN(1,nvall);  projblocks = NaN(1,nvall);
    Aproj = NaN(nvall, nvars*nlags);  Ures = NaN(size(yall,1), nvall);
    for jj = 1:nvall
        pb = manifest(jj).projblocks;
        if isempty(pb); pb = nlags; end
        projblocks(jj) = pb;
        [Aproj(jj,:), r2(jj), nobs(jj), Ures(:,jj)] = ccdgv_project(yall(:,jj), data, nlags, pb);
    end
    for jj = find(projblocks ~= nlags)
        fprintf('  %-16s projected on %d of %d state blocks (R2 %.4f)\n', ...
                vkey{jj}, projblocks(jj), nlags, r2(jj));
    end
    % Rows with fewer usable quarters than others projected on the same number
    % of state blocks.
    for b = unique(projblocks(isfinite(nobs)))
        g = find(projblocks == b & isfinite(nobs));
        for jj = g(nobs(g) < max(nobs(g)))
            fprintf('  %-9s projected on %d of %d quarters (R2 %.4f) -- short for its block\n', ...
                    vkey{jj}, nobs(jj), max(nobs(g)), r2(jj));
        end
    end

    % Draw the first stage: page j of Aproj_draw pairs with VAR draw j, the last
    % page is the posterior mean.
    [Aproj_draw, proj_draw_rec, proj_s2draw, proj_phi, r2_pm, info.settings.proj_draw_summary] = ...
        ccdgv_project_draws(yall, data, Aproj, r2, projblocks, manifest, S);

    info.sd_realised = dates(1);  info.ed_realised = dates(end);
    St = struct('data',data, 'dates',dates, ...
                'vnames',{vnames}, 'vnames_short',{vnames_short}, ...
                'Aproj',Aproj, 'r2',r2, 'nobs',nobs, 'projblocks',projblocks, ...
                'Ures',Ures, 'keys',{vkey}, 'Aproj_draw',Aproj_draw, ...
                'proj_draw_rec',{{proj_draw_rec}}, 'proj_s2draw',proj_s2draw, ...
                'proj_phi',{{proj_phi}}, 'r2_pm',r2_pm);
    info = run_stage(info,'data',St);

    %% Estimation stage: the reduced-form VAR
    [ARs, Sigs, Res, Xtra] = genvars(data, info);
    St = struct('ARs',{ARs}, 'Sigs',{Sigs}, 'Res',{Res});
    if isfield(Xtra,'bvecm'); St.bvecm = Xtra.bvecm;  info.settings.bvecm = Xtra.bvecm; end
    info = run_stage(info,'estimation',St);

    %% Identification stage
    % One max-share pass per entry of info.idrun, as info.ident describes them.
    % genmaxshare_final reads page j of Aproj_draw for draw j and the last page
    % for the point estimate.
    idx  = struct('Aproj',Aproj_draw, 'keys',{vkey}, 'nvnames',numel(vnames));
    Rall = cell(1, numel(info.ident));
    for k = info.idrun
        Rall{k} = genmaxshare_final(ARs, Sigs, Res, id_cfg(info, k, idx));
        fprintf('  identification %d/%d: %s\n', k, numel(info.ident), info.ident(k).label);
    end

    %% Technology and noise decomposition
    [irtfp, irnoise, vstfp, vsnoise, vstfp_real, warntfp, warnnoise] = ...
        cj_decomposition(ARs, Sigs, Aproj_draw, vkey, vnames, S.smax, S.vd_fr, S.j_cj_horizon);
    % Every draw on the window +/-smax_store, and the point estimate at full
    % length. The in-memory irtfp/irnoise keep +/-smax for the moments below.
    hs = min(S.smax, S.smax_store);  w = S.smax+1-hs : S.smax+1+hs;
    St = struct('irtfp',irtfp(w,:,:), 'irnoise',irnoise(w,:,:), ...
                'irtfp_pe',irtfp(:,:,end), 'irnoise_pe',irnoise(:,:,end), ...
                'vstfp',vstfp, 'vsnoise',vsnoise, 'vstfp_real',vstfp_real, ...
                'warntfp',warntfp, 'warnnoise',warnnoise);   % warn*: per-draw factorisation flags
    % Pass 1 goes under the unsuffixed names (Table 1); the appendix passes 2
    % and 3 (Tables C.4/C.5) under _AF and _HF, present only if they ran.
    St.dataplots = Rall{1}.dataplots;  St.vardec_fd = Rall{1}.vardec_fd;
    if ismember(2, info.idrun); St.dataplots_AF = Rall{2}.dataplots;  St.vardec_fd_AF = Rall{2}.vardec_fd; end
    if ismember(3, info.idrun); St.dataplots_HF = Rall{3}.dataplots;  St.vardec_fd_HF = Rall{3}.vardec_fd; end
    % id_meta: the cfg of each pass that ran, keyed by label.
    St.id_meta = struct('note', ['dataplots/vardec_fd = pass 1 (Table 1). Suffixed ' ...
        '_AF/_HF are passes 2/3 (Tables C.4/C.5). vardec_fd is empty for any pass ' ...
        'with want_vardec_fd=false -- see genmaxshare_final.']);
    for k = info.idrun
        St.id_meta.(matlab.lang.makeValidName(info.ident(k).label)) = Rall{k}.cfg;
    end
    info = run_stage(info,'identification',St);

    %% Moments (Tables 3 and C.3) and the trading strategy (Table C.9), where
    % the sweep asks for them
    if info.want_moments
        Dm = struct('ARs',{ARs}, 'Sigs',{Sigs}, 'irtfp',irtfp, 'irnoise',irnoise, ...
                    'j_cj_horizon',S.j_cj_horizon, 'vnames',{vnames}, 'Aproj',Aproj, ...
                    'keys',{vkey});
        moments = gentablemoments_final(Dm);
        fprintf('  moments: %d block(s) skipped\n', size(moments.skipped,1));
        % Three rows of Table 3 (Engel beta_Lambda, cov(sum E_t lambda, r-r*) and
        % rho(q_t)) use data band-filtered over periodicities of 2 to 100 quarters.
        filtered_moments = gentablefilteredmoments_final(Dm);
        fprintf('  filtered moments: %d block(s) skipped\n', size(filtered_moments.skipped,1));
        info = run_stage(info,'moments', ...
                         struct('moments',moments, 'filtered_moments',filtered_moments));

        % The rolling-window strategy runs on the data the VAR was fit on.
        if ~isempty(info.trade_windows)
            trading = gen_tradingstrategy(data, dates, info);
            info = run_stage(info,'trading',struct('trading',trading));
        end
        info = run_stage(info,'complete',[]);
    end

    info.nobs_realised = size(data, 1);
    validate_info(info);           % the realised sample
end
