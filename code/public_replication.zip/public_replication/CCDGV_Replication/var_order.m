%Convert variables list to index list from list of names variables
function out = var_order(vnames, varargin)
%VAR_ORDER  Positions of named variables in vnames, in the order asked for.
%
%   out = VAR_ORDER(vnames, 'Name1', 'Name2', ...)  ->  numel(varargin) x 1
%
%   ERRORS if any name is absent, naming all the missing ones at once. It does
%   NOT go through find_one, which warns and returns index 1 -- that fallback
%   turns a missing variable into a silently mislabelled panel (Home TFP plotted
%   as whatever was asked for), which is the failure this function exists to
%   prevent. find_one is left as it is for its other callers.
%
%   Callers that legitimately tolerate an absent variable -- an optional figure,
%   say -- should test membership FIRST and skip, rather than relying on a
%   lenient lookup here.

    out  = zeros(numel(varargin), 1);
    miss = {};
    for jj = 1:numel(varargin)
        nm = varargin{jj};
        i  = find(strcmp(vnames, nm));
        if isempty(i)
            miss{end+1} = nm; %#ok<AGROW>
        elseif numel(i) > 1
            error('var_order:ambiguous', ...
                  '"%s" appears %d times in vnames', nm, numel(i));
        else
            out(jj) = i;
        end
    end
    if ~isempty(miss)
        error('var_order:notFound', ...
              'not in vnames: %s', strjoin(miss, ', '));
    end
end
