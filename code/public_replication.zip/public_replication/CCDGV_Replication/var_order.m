function out = var_order(vnames, varargin)
%VAR_ORDER  Positions of named variables in vnames, in the order asked for.
%
%   out = var_order(vnames, 'Name1', 'Name2', ...)
%
%   out is numel(varargin) x 1. Errors if a name is absent or appears more than
%   once; the absent-name error lists every missing name.

    out  = zeros(numel(varargin), 1);
    miss = {};
    for jj = 1:numel(varargin)
        nm = varargin{jj};
        i  = find(strcmp(vnames, nm));
        if isempty(i)
            miss{end+1} = nm; %#ok<AGROW>
        elseif numel(i) > 1
            error('var_order:ambiguous', ...
                  '"%s" appears %d times in vnames', nm, numel(i));
        else
            out(jj) = i;
        end
    end
    if ~isempty(miss)
        error('var_order:notFound', ...
              'not in vnames: %s', strjoin(miss, ', '));
    end
end
