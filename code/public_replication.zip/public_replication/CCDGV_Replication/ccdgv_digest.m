function D = ccdgv_digest(src, opt)
%CCDGV_DIGEST  Fingerprint every number an exhibit reads out of a run file.
%
%   D = CCDGV_DIGEST(file)          one run .mat
%   D = CCDGV_DIGEST(dir)           every results_*.mat in a directory
%   D = CCDGV_DIGEST(src, opt)      opt.quiet suppresses the progress line
%
%   Returns a struct (or struct array, one element per run) whose fields are the
%   run's name plus one summary per quantity. CCDGV_DIGEST_CMP compares two.
%
%   TWO KINDS OF COMPARISON, AND THEY USE DIFFERENT FIELDS.
%
%   `spot`, `sum`, `min`, `max` cover every element, draws included. They are the
%   strict check, valid when both runs share a random stream: the same
%   specification at the same draw count, before and after a code change. Use
%   them to prove a change moved nothing.
%
%   `medspot`, `medsum`, `medmin`, `medmax` are the posterior median over draws,
%   recorded for the arrays that have a draw dimension. Use them to compare runs
%   that do NOT share a stream -- a different draw count, a different manifest,
%   another machine, or this package against the published reference. Draw-level
%   fields will differ there for no reason worth reporting.
%
%   WHY A DIGEST AND NOT THE FILES. A run .mat is ~340 MB, 96% of it irtfp and
%   irnoise at [501 x nvall x ndraws+1]. Comparing files is slow, tells you
%   nothing about WHERE a difference is, and breaks on any harmless change to a
%   setting that is saved alongside. A digest reduces each quantity to a few
%   numbers at full precision, so two runs compare in milliseconds and a
%   difference names the array it is in.
%
%   WHAT IT COVERS. Everything the generators read, grouped as:
%     spectra     dataplots, dataplots_AF, dataplots_HF      (Figures 1, B.1; Tables 1, B.1, B.4, B.5)
%     vardec      vardec_fd, vstfp, vsnoise, vstfp_real      (Tables 2, B.2, B.7)
%     irfs        irtfp, irnoise, irtfp_pe, irnoise_pe       (Figures 2-4, B.2-B.4, B.7-B.10, B.12)
%     moments     moments, filtered_moments, trading         (Tables 3, B.3, B.9)
%     proj        Aproj, Aproj_draw, proj_phi, proj_s2draw
%                                                            (Figures 5, B.5, B.6, B.14; the text numbers)
%     shocks      Ures, ARs, Sigs                            (Figure B.11)
%     sample      dates, nobs, sd_realised, data, r2, r2_pm    (every exhibit's x-axis)
%
%   HOW EACH ARRAY IS REDUCED. For a numeric array: the number of finite and
%   non-finite entries, the sum, the sum of squares, the min, the max, and the
%   values at a fixed set of linear indices. The index set is derived from the
%   array's own size, so it is stable across runs of the same shape and the
%   stored values are exact doubles, not a hash. A changed element moves at
%   least the sum and the sum of squares; the spot values localise it. Hashing
%   was rejected: it answers "differs" without answering "where", which is the
%   only question that matters when a gate fails.
%
%   SHAPE IS PART OF THE DIGEST. A run with a different ndraws, nvall or sample
%   length is reported as a shape difference rather than compared element-wise,
%   because the comparison would be meaningless and the shape is the finding.
%
%   See also CCDGV_DIGEST_CMP.

    if nargin < 2; opt = struct(); end
    if ~isfield(opt,'quiet'); opt.quiet = false; end

    if isfolder(src)
        f = dir(fullfile(src, 'results_*.mat'));
        assert(~isempty(f), 'ccdgv_digest:noRuns', ...
            'no results_*.mat in %s', src);
        [~, k] = sort({f.name});
        f = f(k);
        C = cell(1, numel(f));
        for i = 1:numel(f)
            C{i} = ccdgv_digest(fullfile(f(i).folder, f(i).name), opt);
        end
        ref = fieldnames(local_empty());
        for i = 1:numel(C)
            C{i} = orderfields(C{i}, ref);
        end
        D = [C{:}];
        return
    end

    assert(isfile(src), 'ccdgv_digest:noFile', '%s not found', src);
    [~, stem] = fileparts(src);
    if ~opt.quiet; fprintf('  digest %s\n', stem); end

    D       = local_empty();
    D.run   = stem;
    D.file  = src;

    % Load only what is digested. Loading the whole file costs ~340 MB and most
    % of it is never read here.
    WANT = local_want();
    have = {whos('-file', src).name};
    R = load(src, WANT{intersect_idx(WANT, have)});

    % --- sample: the x-axis every exhibit shares -----------------------------
    if isfield(R,'dates')
        d = R.dates(:);
        D.sample = struct('n', numel(d), 'first', d(1), 'last', d(end), ...
                          'sum', sum(d));
    end
    % sd_realised/ed_realised live on info; r2, r2_pm and nobs are top-level
    % variables of the .mat, not info fields.
    if isfield(R,'info')
        D.sd_realised = local_get(R.info, 'sd_realised');
        D.ed_realised = local_get(R.info, 'ed_realised');
    end
    if isfield(R,'vnames'); D.nvall = numel(R.vnames); end

    % --- the arrays ----------------------------------------------------------
    for v = WANT
        n = v{1};
        if any(strcmp(n, {'info','vnames','dates'})); continue; end
        if ~isfield(R, n); D.(n) = 'absent'; continue; end
        D.(n) = local_reduce(R.(n));
    end
end

% =========================================================================
function s = local_reduce(x)
% Reduce one quantity to a comparable summary. Structs (moments,
% filtered_moments, trading) are reduced field by field so a difference names the
% field, and cells (ARs, Sigs, proj_phi) through their contents.
    if isstruct(x)
        s = struct('kind','struct');
        for f = fieldnames(x)'
            s.(f{1}) = local_reduce(x.(f{1}));
        end
        return
    end
    if iscell(x)
        % A CELL IS REDUCED THROUGH ITS CONTENTS, not to its element count. ARs
        % and Sigs are 1 x (ndraws+1) cells of VAR coefficient and covariance
        % matrices -- reducing them to numel() meant the gate would pass a change
        % that moved every coefficient in the file, which is the opposite of what
        % this function is for.
        s = struct('kind','cell', 'n', numel(x));
        if isempty(x); return; end
        if all(cellfun(@isnumeric, x(:))) || all(cellfun(@islogical, x(:)))
            % One summary over every element of every cell. Flattened rather than
            % stacked so cells whose elements differ in size still reduce; the
            % spot indices are stable because the sizes are.
            v = cell2mat(cellfun(@(e) double(e(:)), x(:), 'UniformOutput', false));
            s.sizes = local_sizesig(x);
            s.all   = local_reduce(v);
        elseif numel(x) <= 16
            for k = 1:numel(x)
                s.(sprintf('e%d', k)) = local_reduce(x{k});
            end
        else
            % Too many to name individually, and not numeric: record the shape
            % signature so a structural change is still caught.
            s.sizes = local_sizesig(x);
        end
        return
    end
    if ischar(x) || isstring(x)
        s = struct('kind','text', 'value', char(string(x)));
        return
    end
    if islogical(x); x = double(x); end
    if ~isnumeric(x)
        s = struct('kind','other', 'class', class(x));
        return
    end

    s.kind = 'numeric';
    s.size = size(x);
    f      = isfinite(x);
    s.nfin = sum(f(:));
    s.nnan = sum(isnan(x(:)));
    s.ninf = sum(isinf(x(:)));
    if s.nfin == 0
        s.sum = 0; s.sumsq = 0; s.min = NaN; s.max = NaN; s.spot = [];
        return
    end
    xf      = double(x(f));
    s.sum   = sum(xf);
    s.sumsq = sum(xf.^2);
    s.min   = min(xf);
    s.max   = max(xf);
    s.spot  = x(local_spots(numel(x)));   % exact values, not a hash

    % POSTERIOR MEDIAN, for the arrays that carry a draw dimension. s.spot lands
    % on individual draws, which is the strict check and the right one when the
    % two runs share a random stream -- the same setup before and after a change.
    % Across setups it is not: draw i of one run and draw i of another are
    % different draws, because the stream depends on the draw count and on how
    % many values each stage consumes before it. Measured on vars5: NER at h=18
    % differs by 3.4e-2 draw-by-draw while the two medians agree at 0.15346.
    % Every exhibit plots a posterior summary, so the median is what decides
    % whether two runs say the same thing.
    if ndims(x) == 3 && size(x,3) > 1
        m         = median(double(x), 3, 'omitnan');
        s.medsum  = sum(m(isfinite(m)));
        s.medmin  = min(m(isfinite(m)));
        s.medmax  = max(m(isfinite(m)));
        s.medspot = m(local_spots(numel(m)));
    else
        s.medsum = []; s.medmin = []; s.medmax = []; s.medspot = [];
    end
end

function idx = local_spots(n)
% A fixed, size-derived set of linear indices: the ends plus up to 15 interior
% points. Deterministic for a given n, so the same array always reports the same
% positions and two runs of the same shape are directly comparable.
    if n <= 17
        idx = 1:n;
    else
        idx = unique([1, round(linspace(2, n-1, 15)), n]);
    end
end

function W = local_want()
% Everything the digest reads. Shared by the reader and by local_empty, so every
% digest carries the same field set and a struct array of them concatenates.
    W = {'dataplots','dataplots_AF','dataplots_HF', ...
         'vardec_fd','vstfp','vsnoise','vstfp_real', ...
         'irtfp','irnoise','irtfp_pe','irnoise_pe', ...
         'moments','filtered_moments','trading', ...
         'Aproj','Aproj_draw','proj_phi','proj_s2draw', ...
         'Ures','ARs','Sigs', ...
         'r2','r2_pm','nobs', ...
         'dates','data','info','vnames'};
end

function D = local_empty()
% Every field present up front. Without this, digesting a directory fails with
% "Subscripted assignment between dissimilar structures" the moment one run
% carries a variable another does not.
    D = struct('run', '', 'file', '', 'sample', [], ...
               'sd_realised', [], 'ed_realised', [], 'nvall', []);
    for n = local_want()
        if any(strcmp(n{1}, {'info','vnames','dates'})); continue; end
        D.(n{1}) = 'absent';
    end
end

function v = local_get(s, f)
% info carries some fields at the top level and some under .settings.
    v = [];
    if ~isstruct(s); return; end
    if isfield(s, f); v = s.(f); return; end
    if isfield(s, 'settings') && isstruct(s.settings) && isfield(s.settings, f)
        v = s.settings.(f);
    end
end

function k = intersect_idx(want, have)
    k = find(ismember(want, have));
end

function sig = local_sizesig(x)
% A compact signature of a cell's element shapes: enough to catch a structural
% change without one row per element.
    sz  = cellfun(@(e) size(e), x(:), 'UniformOutput', false);
    m   = max(cellfun(@numel, sz));
    pad = cell2mat(cellfun(@(v) [v, ones(1, m - numel(v))], sz, 'UniformOutput', false));
    sig = [size(pad, 1), sum(pad, 1), min(pad, [], 1), max(pad, [], 1)];
end
