function D = ccdgv_digest(src, opt)
%CCDGV_DIGEST  Reduce a run file to a summary of every number an exhibit reads.
%
%   D = ccdgv_digest(file)       one run .mat
%   D = ccdgv_digest(dir)        every results_*.mat in a directory
%   D = ccdgv_digest(src, opt)   opt.quiet suppresses the progress line
%
%   D is a struct, or a struct array with one element per run. Its fields are the
%   run's name, the sample, and one summary per saved quantity:
%     dataplots, dataplots_AF, dataplots_HF       max-share responses
%     vardec_fd, vstfp, vsnoise, vstfp_real       variance shares
%     irtfp, irnoise, irtfp_pe, irnoise_pe        technology and noise responses
%     moments, filtered_moments, trading          moments and the trading strategy
%     Aproj, Aproj_draw, proj_phi, proj_s2draw    projections
%     Ures, ARs, Sigs, r2, r2_pm, nobs, data      residuals, VAR, fit and data
%
%   A numeric array is reduced to its size, the counts of finite, NaN and Inf
%   entries, the sum, the sum of squares, the min, the max, and the values at a
%   fixed set of linear indices (spot). These cover every element, draws
%   included, so they are comparable only between runs that share a random
%   stream. An array with a draw dimension also gets medsum, medmin, medmax and
%   medspot, taken from the median over draws, for comparing runs that do not.
%
%   See also CCDGV_DIGEST_CMP.

    if nargin < 2; opt = struct(); end
    if ~isfield(opt,'quiet'); opt.quiet = false; end

    if isfolder(src)
        f = dir(fullfile(src, 'results_*.mat'));
        assert(~isempty(f), 'ccdgv_digest:noRuns', ...
            'no results_*.mat in %s', src);
        [~, k] = sort({f.name});
        f = f(k);
        C = cell(1, numel(f));
        for i = 1:numel(f)
            C{i} = ccdgv_digest(fullfile(f(i).folder, f(i).name), opt);
        end
        ref = fieldnames(local_empty());
        for i = 1:numel(C)
            C{i} = orderfields(C{i}, ref);
        end
        D = [C{:}];
        return
    end

    assert(isfile(src), 'ccdgv_digest:noFile', '%s not found', src);
    [~, stem] = fileparts(src);
    if ~opt.quiet; fprintf('  digest %s\n', stem); end

    D       = local_empty();
    D.run   = stem;
    D.file  = src;

    % Load only the variables that are digested.
    WANT = local_want();
    have = {whos('-file', src).name};
    R = load(src, WANT{intersect_idx(WANT, have)});

    % Sample.
    if isfield(R,'dates')
        d = R.dates(:);
        D.sample = struct('n', numel(d), 'first', d(1), 'last', d(end), ...
                          'sum', sum(d));
    end
    % The realised sample is on info.
    if isfield(R,'info')
        D.sd_realised = local_get(R.info, 'sd_realised');
        D.ed_realised = local_get(R.info, 'ed_realised');
    end
    if isfield(R,'vnames'); D.nvall = numel(R.vnames); end

    % The arrays.
    for v = WANT
        n = v{1};
        if any(strcmp(n, {'info','vnames','dates'})); continue; end
        if ~isfield(R, n); D.(n) = 'absent'; continue; end
        D.(n) = local_reduce(R.(n));
    end
end

function s = local_reduce(x)
% Reduce one quantity to a summary. Structs are reduced field by field and cells
% through their contents.
    if isstruct(x)
        s = struct('kind','struct');
        for f = fieldnames(x)'
            s.(f{1}) = local_reduce(x.(f{1}));
        end
        return
    end
    if iscell(x)
        s = struct('kind','cell', 'n', numel(x));
        if isempty(x); return; end
        if all(cellfun(@isnumeric, x(:))) || all(cellfun(@islogical, x(:)))
            % Numeric cells: one summary over all elements, flattened.
            v = cell2mat(cellfun(@(e) double(e(:)), x(:), 'UniformOutput', false));
            s.sizes = local_sizesig(x);
            s.all   = local_reduce(v);
        elseif numel(x) <= 16
            for k = 1:numel(x)
                s.(sprintf('e%d', k)) = local_reduce(x{k});
            end
        else
            % Many non-numeric elements: record only the shapes.
            s.sizes = local_sizesig(x);
        end
        return
    end
    if ischar(x) || isstring(x)
        s = struct('kind','text', 'value', char(string(x)));
        return
    end
    if islogical(x); x = double(x); end
    if ~isnumeric(x)
        s = struct('kind','other', 'class', class(x));
        return
    end

    s.kind = 'numeric';
    s.size = size(x);
    f      = isfinite(x);
    s.nfin = sum(f(:));
    s.nnan = sum(isnan(x(:)));
    s.ninf = sum(isinf(x(:)));
    if s.nfin == 0
        s.sum = 0; s.sumsq = 0; s.min = NaN; s.max = NaN; s.spot = [];
        return
    end
    xf      = double(x(f));
    s.sum   = sum(xf);
    s.sumsq = sum(xf.^2);
    s.min   = min(xf);
    s.max   = max(xf);
    s.spot  = x(local_spots(numel(x)));   % exact values at fixed indices

    % Median over draws, for arrays with a draw dimension.
    if ndims(x) == 3 && size(x,3) > 1
        m         = median(double(x), 3, 'omitnan');
        s.medsum  = sum(m(isfinite(m)));
        s.medmin  = min(m(isfinite(m)));
        s.medmax  = max(m(isfinite(m)));
        s.medspot = m(local_spots(numel(m)));
    else
        s.medsum = []; s.medmin = []; s.medmax = []; s.medspot = [];
    end
end

function idx = local_spots(n)
% Fixed linear indices for an array of n elements: the ends plus up to 15
% interior points.
    if n <= 17
        idx = 1:n;
    else
        idx = unique([1, round(linspace(2, n-1, 15)), n]);
    end
end

function W = local_want()
% The variables the digest reads.
    W = {'dataplots','dataplots_AF','dataplots_HF', ...
         'vardec_fd','vstfp','vsnoise','vstfp_real', ...
         'irtfp','irnoise','irtfp_pe','irnoise_pe', ...
         'moments','filtered_moments','trading', ...
         'Aproj','Aproj_draw','proj_phi','proj_s2draw', ...
         'Ures','ARs','Sigs', ...
         'r2','r2_pm','nobs', ...
         'dates','data','info','vnames'};
end

function D = local_empty()
% A digest with every field present, so digests of different runs concatenate.
    D = struct('run', '', 'file', '', 'sample', [], ...
               'sd_realised', [], 'ed_realised', [], 'nvall', []);
    for n = local_want()
        if any(strcmp(n{1}, {'info','vnames','dates'})); continue; end
        D.(n{1}) = 'absent';
    end
end

function v = local_get(s, f)
% info carries some fields at the top level and some under .settings.
    v = [];
    if ~isstruct(s); return; end
    if isfield(s, f); v = s.(f); return; end
    if isfield(s, 'settings') && isstruct(s.settings) && isfield(s.settings, f)
        v = s.settings.(f);
    end
end

function k = intersect_idx(want, have)
    k = find(ismember(want, have));
end

function sig = local_sizesig(x)
% A compact signature of a cell's element shapes.
    sz  = cellfun(@(e) size(e), x(:), 'UniformOutput', false);
    m   = max(cellfun(@numel, sz));
    pad = cell2mat(cellfun(@(v) [v, ones(1, m - numel(v))], sz, 'UniformOutput', false));
    sig = [size(pad, 1), sum(pad, 1), min(pad, [], 1), max(pad, [], 1)];
end
