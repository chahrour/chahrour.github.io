% RUN_PATHSETUP  Set the MATLAB path for the package without running anything.
%
%   A script. It clears the calling workspace, closes all figures, resets the
%   path and changes to this folder, so call it before building cfg.
clear;
close all

% Reset the path. Only code folders are added below.
restoredefaultpath;

% The root is this file's folder.
RM_ROOT = fileparts(mfilename('fullpath'));

% Move to this file's folder.
cd(RM_ROOT);

% Add the code folders.
addpath(fullfile(RM_ROOT,'Auxiliary_Functions'));
addpath(fullfile(RM_ROOT,'DSGE_tools'));
addpath(fullfile(RM_ROOT,'Load_Data'));
addpath(RM_ROOT);
% The Villani (2005) library goes last, so its names cannot shadow the package's.
addpath(fullfile(RM_ROOT,'Bayesian_VECM'),'-end');
