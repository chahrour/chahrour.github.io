
%Get a clean path for the run
% THIS CLEARS THE CALLER'S WORKSPACE AND CLOSES ITS FIGURES. It is written for a
% fresh session, and a script run from the base workspace loses its variables
% here -- including any cfg built before the call. Set up the path first, then
% build cfg.
clear;
close all

%Get rid of any old path buildup
restoredefaultpath;
% CODE DIRECTORIES ONLY. saved_results used to be added here; nothing loads from
% it by bare name -- every run file is opened with fullfile(cfg.resultdir, ...) --
% and a data folder on the path only creates the chance for a file to shadow a
% function or to be found by a name the code does not spell out.

% The root is run_pathsetup's folder, wherever it is located
RM_ROOT = fileparts(mfilename('fullpath'));

% Move to this files folder
cd(RM_ROOT);

%Now we add the directories relative to RM_ROOT
addpath(fullfile(RM_ROOT,'Auxiliary_Functions'));
addpath(fullfile(RM_ROOT,'DSGE_tools'));
addpath(fullfile(RM_ROOT,'Load_Data'));
addpath(RM_ROOT);
% LAST ON THE PATH, deliberately: the Villani (2005) library (est_method 6) is
% third-party code carrying common names, and -end keeps anything it defines from
% shadowing this package's own functions.
addpath(fullfile(RM_ROOT,'Bayesian_VECM'),'-end');
