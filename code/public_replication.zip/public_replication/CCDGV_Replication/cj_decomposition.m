function [irtfp, irnoise, vstfp, vsnoise, vstfp_real, warntfp, warnnoise] = ...
        cj_decomposition(ARs, Sigs, Aproj, datakeys, vnames, smax, vd_fr, j_cj_horizon) %#ok<INUSD,STOUT>
%CJ_DECOMPOSITION  Technology and noise responses and variance shares of a run.
%
%   [irtfp, irnoise, vstfp, vsnoise, vstfp_real, warntfp, warnnoise] = ...
%       cj_decomposition(ARs, Sigs, Aproj, datakeys, vnames, smax, vd_fr, j_cj_horizon)
%
%   ARs, Sigs     the VAR draws, the point estimate last
%   Aproj         projection rows, one page per draw
%   datakeys      keys of the data rows; vnames, the names of every row
%   smax          responses are returned at lags -smax..smax
%   vd_fr         frequency bands of the variance shares
%   j_cj_horizon  horizon j of the expected-TFP target, E_t[TFP_{t+j}]
%
%   The outputs are GEN_CJ_IRFS_TFSWEEP's. That file is a script shared with the
%   model code: it reads its inputs from the workspace and leaves its results
%   there. This function gives it a workspace that holds exactly those.
%
%   See also GEN_CJ_IRFS_TFSWEEP, ESTIMATE_ONE, GENFIG_C9.
    gen_cj_irfs_tfsweep;
end
