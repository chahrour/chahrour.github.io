function [name, fpath] = data_name(info)

%Name for file based on all the info
%   fpath (optional) is name under info.outdir, default Dataset_Output.
name = 'results';
try name = [name '_' info.country];catch; error('Invalid country entry');end
try name = [name '_' info.datver];catch; error('Invalid data version entry');end
try name = [name '_meth' num2str(info.method)];catch; error('Invalid method entry');end
try name = [name '_vars' num2str(info.inclvar)]; catch; error('Invalid variables included entry');end
% The REQUESTED start, deliberately -- not sd_realised. The name must be fixed
% before the run (run_stage names the file at the config stage, before the data
% loads), and using the realised value meant renaming the file mid-run. What the
% data actually delivered is recorded in info.sd_realised and reported by
% report_info; the filename states what was ASKED for.
try name = [name '_sd' num2str(info.sd)];    catch; error('Invalid start date entry');end
try name = [name '_ed' num2str(info.ed)];    catch; error('Invalid end date entry');end

name = [name '.mat'];

if nargout > 1
    root = 'Dataset_Output';
    if isfield(info,'outdir') && ~isempty(info.outdir); root = info.outdir; end

    % THE STORED ROOT IS WHERE THE RUN WAS ESTIMATED, which is not necessarily
    % where it is now. info.outdir is an absolute path baked in at estimation
    % time, and thirteen call sites open this fpath directly -- so a set of run
    % files copied from another machine, or moved on this one, sent every one of
    % them looking in a directory that does not exist. That is what sharing
    % saved_results between co-authors means, so it has to work.
    %
    % If the stored root is not here, fall back to the configured one. The
    % filename itself is machine-independent, so the basename is all that needs
    % to carry over.
    if ~isfolder(root)
        try
            here = config();
            if isfolder(here.resultdir); root = here.resultdir; end
        catch
            % config() unavailable (data_name is called from places that have
            % not set the path up); leave root as stored and let the caller's
            % own isfile assert report it.
        end
    end
    fpath = fullfile(root, name);
end
