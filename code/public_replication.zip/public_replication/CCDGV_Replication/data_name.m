function [name, fpath] = data_name(info)
%DATA_NAME  File name of a run, built from its descriptor.
%
%   [name, fpath] = data_name(info)
%
%   name   'results_<country>_<datver>_meth<method>_vars<inclvar>_sd<sd>_ed<ed>.mat'
%   fpath  name under info.outdir. LOAD_SWEEP_INFOS points info.outdir at
%          cfg.resultdir when the descriptors are read back from disk.
name = 'results';
try name = [name '_' info.country];catch; error('Invalid country entry');end
try name = [name '_' info.datver];catch; error('Invalid data version entry');end
try name = [name '_meth' num2str(info.method)];catch; error('Invalid method entry');end
try name = [name '_vars' num2str(info.inclvar)]; catch; error('Invalid variables included entry');end
% The requested start, info.sd, not the realised one.
try name = [name '_sd' num2str(info.sd)];    catch; error('Invalid start date entry');end
try name = [name '_ed' num2str(info.ed)];    catch; error('Invalid end date entry');end

name = [name '.mat'];

if nargout > 1
    assert(isfield(info,'outdir') && ~isempty(info.outdir), 'data_name:noOutdir', ...
        'the descriptor has no outdir, so the run file cannot be located.');
    fpath = fullfile(info.outdir, name);
end
