function info = run_stage(info, stage, S, err)
%RUN_STAGE  Append one stage of a run to its single .mat and stamp progress.
%
%   info = RUN_STAGE(info, stage, S)        record success, write S's fields
%   info = RUN_STAGE(info, 'config', [])    start a fresh run (deletes any old file)
%   info = RUN_STAGE(info, stage, [], err)  record failure
%   info = RUN_STAGE(info, 'complete', [])  mark the run finished
%
%   S is a struct whose fields become variables in the file. info (carrying
%   info.progress) is rewritten every call, so the file always describes itself
%   as of the last successful write.
%
%   info.progress.<stage> = done | timestamp | elapsed | error
%   elapsed is time since the previous stage finished; the helper keeps the
%   clock, so callers do not have to.
%
%   Timestamps are the point: a stage whose timestamp predates a stage it
%   depends on is stale, which makes staleness derivable rather than assumed.
%   Consumers should check progress before trusting a stage's output.

    if nargin < 3; S = []; end
    if nargin < 4; err = ''; end

    [~, f] = data_name(info);

    d = fileparts(f);
    if ~isempty(d) && ~isfolder(d); mkdir(d); end

    if ~isfield(info,'progress'); info.progress = struct(); end
    tprev = getfield_default(info, 'stage_tic', []);

    ok = isempty(err);
    ent = struct('done', ok, 'timestamp', datestr(now,'yyyy-mm-dd HH:MM:SS'), ...
                 'elapsed', NaN, 'error', '');
    if ~isempty(tprev); ent.elapsed = toc(tprev); end
    if ~ok
        if isa(err,'MException'); ent.error = err.message; else; ent.error = char(err); end
    end
    info.progress.(stage) = ent;
    % 'complete' is a real stage: the fact that a run finished is worth
    % timestamping, and consumers gate on it.
    info.complete = strcmp(stage,'complete') && ok;

    % 'config' starts a run: drop any previous file so a re-run cannot inherit
    % variables from a different specification (an -append leaves non-matching
    % names in place, which is how a stale dataplots_AF would look current).
    if strcmp(stage,'config') && isfile(f); delete(f); end

    if isfile(f)
        save(f, 'info', '-append');
    else
        save(f, 'info');
    end
    if ~isempty(S) && isstruct(S) && ~isempty(fieldnames(S))
        save(f, '-struct', 'S', '-append');
        % save() does not fail on a variable it cannot write -- past 2 GB in a v7
        % file it WARNS, skips it and saves the rest. Check every field landed.
        miss = setdiff(fieldnames(S), who('-file', f));
        assert(isempty(miss), 'run_stage:notSaved', ...
            ['[%s] %s not written to %s -- most likely over the 2 GB a v7 .mat ' ...
             'can hold per variable (see smax_store in run_setup).'], ...
            stage, strjoin(miss, ', '), f);
    end

    fprintf('  [%s] %s%s\n', stage, ternchar(ok,'ok','FAILED: '), ternchar(ok,'',ent.error));
    info.stage_tic = tic;   % next stage's elapsed measures from here
end

function v = getfield_default(s, f, d)
    if isfield(s,f); v = s.(f); else; v = d; end
end

function s = ternchar(c,a,b)
    if c; s = a; else; s = b; end
end
