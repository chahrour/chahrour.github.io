function info = run_stage(info, stage, S, err)
%RUN_STAGE  Append one stage of a run to its .mat file and record progress.
%
%   info = run_stage(info, stage, S)        record success and write S's fields
%   info = run_stage(info, 'config', S)     start a run; deletes any old file
%   info = run_stage(info, stage, [], err)  record failure
%   info = run_stage(info, 'complete', [])  mark the run finished
%
%   info   the run descriptor; data_name(info) gives the file. It is rewritten
%          to the file on every call.
%   stage  stage name. info.progress.(stage) gets the fields done, timestamp,
%          elapsed (seconds since the previous stage) and error.
%   S      struct whose fields become variables in the file, or [].
%   err    error message or MException, when the stage failed.

    if nargin < 3; S = []; end
    if nargin < 4; err = ''; end

    [~, f] = data_name(info);

    d = fileparts(f);
    if ~isempty(d) && ~isfolder(d); mkdir(d); end

    if ~isfield(info,'progress'); info.progress = struct(); end
    tprev = getfield_default(info, 'stage_tic', []);

    ok = isempty(err);
    ent = struct('done', ok, 'timestamp', datestr(now,'yyyy-mm-dd HH:MM:SS'), ...
                 'elapsed', NaN, 'error', '');
    if ~isempty(tprev); ent.elapsed = toc(tprev); end
    if ~ok
        if isa(err,'MException'); ent.error = err.message; else; ent.error = char(err); end
    end
    info.progress.(stage) = ent;
    % info.complete is true only after the 'complete' stage.
    info.complete = strcmp(stage,'complete') && ok;

    % 'config' starts a run: delete any previous file so no variable carries over.
    if strcmp(stage,'config') && isfile(f); delete(f); end

    % Version 7.3 without compression: the response draws are nearly all of the
    % file and do not compress, so compressing costs time to write and to load
    % and saves almost no space.
    if isfile(f)
        save(f, 'info', '-append', '-nocompression');
    else
        save(f, 'info', '-v7.3', '-nocompression');
    end
    if ~isempty(S) && isstruct(S) && ~isempty(fieldnames(S))
        save(f, '-struct', 'S', '-append', '-nocompression');
        % save() only warns when it cannot write a variable, so check that
        % every field is in the file.
        miss = setdiff(fieldnames(S), who('-file', f));
        assert(isempty(miss), 'run_stage:notSaved', ...
            '[%s] %s not written to %s.', stage, strjoin(miss, ', '), f);
    end

    fprintf('  [%s] %s%s\n', stage, ternchar(ok,'ok','FAILED: '), ternchar(ok,'',ent.error));
    info.stage_tic = tic;   % the next stage's elapsed time starts here
end

function v = getfield_default(s, f, d)
    if isfield(s,f); v = s.(f); else; v = d; end
end

function s = ternchar(c,a,b)
    if c; s = a; else; s = b; end
end
