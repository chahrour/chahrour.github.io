function [pair, stem, specs] = extra_asset_rows(asset)
%EXTRA_ASSET_ROWS  Which two manifest rows an "extra" asset figure is about.
%
%   [pair, stem, specs] = EXTRA_ASSET_ROWS(asset)
%
%   asset  'equity' | 'yields' | 'returns'
%   pair   1x2 cell of manifest DISPLAY names, US then G6, for var_order
%   stem   filename stem: 'equity' | 'yields'
%   specs  the inclvar values that put those rows in the VAR, for error text
%
%   ONE PLACE, TWO CALLERS. genfig_extra_equity and genfig_extra_uhlig both need
%   the same mapping, and the whole point of the yield exhibits is that they
%   differ from the equity ones ONLY in these two row names. Splitting the table
%   across the two files is how they would come to disagree.
%
%   NAMES, NOT KEYS. var_order matches against vnames, which holds the manifest's
%   display names ('US equity prices'), not its keys ('eq_us'). Changing a display
%   name in ccdgv_manifest therefore breaks these figures loudly -- var_order
%   errors naming the missing row -- which is the intended failure.
%
%   See also CCDGV_MANIFEST, VAR_ORDER.

    switch lower(char(asset))
        case 'equity'
            pair  = {'US equity prices', 'G6 equity prices'};
            stem  = 'equity';
            specs = '3 with FX, 4 without';
        case {'yields','bonds','by'}
            pair  = {'US 10-Y Bond Yield', 'G6 10-Y Bond Yield'};
            stem  = 'yields';
            specs = '8 with FX, 9 without';
        case {'returns','exret'}
            % The EXPECTED excess returns. They are projected like the two
            % pairs above, but no specification puts them in the VAR, so
            % there is no spec list for them.
            pair  = {'Expected Excess Equity Return Diff.', ...
                     'Expected Excess 10-Y Bond Return Diff.'};
            stem  = 'returns';
            specs = 'none -- these rows are always projected';
        otherwise
            error('extra_asset_rows:badAsset', ...
                  'asset must be ''equity'', ''yields'' or ''returns'', got ''%s''', char(asset));
    end
end
