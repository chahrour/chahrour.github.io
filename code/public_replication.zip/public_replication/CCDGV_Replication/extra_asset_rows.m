function [pair, stem, specs] = extra_asset_rows(asset)
%EXTRA_ASSET_ROWS  The two manifest rows of an asset pair.
%
%   [pair, stem, specs] = EXTRA_ASSET_ROWS(asset)
%
%   asset  'equity' | 'yields' | 'real_yields' | 'returns'
%   pair   1x2 cell of manifest display names, for var_order
%   stem   filename stem: 'equity' | 'yields' | 'real_yields' | 'returns'
%   specs  the inclvar values that put those rows in the VAR, for error text
%
%   The names are the manifest's display names, which is what vnames holds.
%
%   See also CCDGV_MANIFEST, VAR_ORDER.

    switch lower(char(asset))
        case 'equity'
            pair  = {'US equity prices', 'G6 equity prices'};
            stem  = 'equity';
            specs = '3 with FX, 4 without';
        case {'yields','bonds','by'}
            pair  = {'US 10-Y Bond Yield', 'G6 10-Y Bond Yield'};
            stem  = 'yields';
            specs = '8 with FX, 9 without';
        case 'real_yields'
            % Constructed: the nominal yield less VAR-expected inflation.
            pair  = {'US Real 10-Y Bond Yield', 'G6 Real 10-Y Bond Yield'};
            stem  = 'real_yields';
            specs = 'none -- these rows are constructed from the projected yields';
        case {'returns','exret'}
            % Expected excess returns: always projected, never in the VAR.
            pair  = {'Expected Excess Equity Return Diff.', ...
                     'Expected Excess 10-Y Bond Return Diff.'};
            stem  = 'returns';
            specs = 'none -- these rows are always projected';
        otherwise
            error('extra_asset_rows:badAsset', ...
                  'asset must be ''equity'', ''yields'', ''real_yields'' or ''returns'', got ''%s''', char(asset));
    end
end
