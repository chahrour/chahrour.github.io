function out = genplots_ew(dest, opt)
%GENPLOTS_EW  Figures 7 and B.13: Granger causality tests a la Engel-West (2005).
%
%   out = GENPLOTS_EW(dest)
%   out = GENPLOTS_EW(dest, opt)
%
%   dest   output directory. Default CCDGV_DESTDIR().
%   opt    .fig7     struct('range',[1974.00 2001.50], 'NH',16)
%          .b13      struct('range',[1976.00 2020.00], 'NH',20)
%          .vintage  Fernald vintage for US TFP; '2026' is the one that ships. Default '2026'.
%          .panel    path to the B.13 panel. Default Built_Data/Y_ew_f<vintage>.mat.
%   out    struct with .p1_fig7 .p1_b13 .counts and .files
%
%   writes  Figures/GC_ALL_EWSAMPLEa.pdf, GC_ALL_EWSAMPLEb.pdf   Figure 7
%           Figures/GC_ALLa.pdf, GC_ALLb.pdf                      Figure B.13
%           Figures/TFP_EWpA.pdf                                  not a draft exhibit
%
%   EACH FIGURE DECLARES ITS OWN SAMPLE, in `range`, as a fractional year pair.
%   Neither is tied to the estimation sample any more. This used to be impossible:
%   the boundary used to be replicated across the loaders, so it now comes22
%   (`for yy = 1976:2018`, written twice independently), CPI_data.m:5
%   (`cpi_data(21:end,:)`), GDP_data.m:3+11, M1_data.m:83-84, and USDATA.xlsx's own
%   row span -- so a date declared here could not reach the data. B.13 now reads a
%   DATE-INDEXED panel instead and selects rows, which removes all six.
%
%   THE TWO FIGURES ARE DIFFERENT OBJECTS AND USE DIFFERENT DATA.
%     Figure 7   is a replication of Engel and West's test on THEIR data. It reads
%                EW_DATA_ALL.xlsx directly, over their window, and should not be
%                re-sourced -- that is the point of it.
%     Figure B.13 runs the same test on OUR data, on their END-OF-PERIOD sampling
%                convention, from Data_Replication/Built_Data/Y_ew_f<vintage>.mat.
%                The published version used EW data for exactly three columns
%                (M1_FR/GE/IT, M1_data.m:21,25,29) and ours for everything else;
%                the panel keeps that one forced dependency and nothing more.
%
%   WHY B.13 CAN NOW EXCEED 2018Q4. Four of the original inputs stop there --
%   OECD_CPI.xlsx, OECD_GDP.xlsx, USDATA.xlsx, and DATASTREAM_FX.xlsx, which ends
%   2019-09-05. The panel reaches ~2026Q1. Measured 2026-10-09: re-sourcing moves
%   B.13 by -18 cases (42 of 612 cells, median |dp| 0.028) and extending to 2020Q1
%   by a further +2 (24 cells, median |dp| 0.013), with the horizon profile
%   essentially unchanged.
%
%   NH DIFFERS BY FIGURE, AND NOT ARBITRARILY. The prewhitening VAR inside MYHAC
%   needs T_eff >= 4*max_lag + 3 or its chol throws. Figure 7 has 111
%   observations, so NH=20 would leave a margin of 7 with no slack for an
%   interior NaN -- hence 16, as the original comment said. B.13 at 177
%   observations has T_eff = 156 against a bound of 83 and could take NH up to
%   ~34; it uses 20.
%
%   See also EW_GRANGER, BUILD_EW_PANEL
%   this is gated against), GRANGER_CAUSE_WALDTEST.

    assert(nargin >= 1 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end
    if nargin < 2; opt = struct(); end
    if ~isfield(opt,'vintage'); opt.vintage = '2026'; end
    if ~isfield(opt,'fig7'); opt.fig7 = struct('range',[1974.00 2001.50],'NH',16); end
    if ~isfield(opt,'b13');  opt.b13  = struct('range',[1976.00 2020.00],'NH',20); end
    root = fileparts(mfilename('fullpath'));
    if ~isfield(opt,'panel')
        opt.panel = fullfile(fileparts(root),'Data_Replication','Built_Data', ...
                             sprintf('Y_ew_f%s.mat', opt.vintage));
    end
    if ~isfolder(dest); mkdir(dest); end

    C   = {'CA','FR','GE','IT','JP','UK'};
    HAC = {'Differencing','Quarterly','HAC','NW','CriticalValues','Standard'};
    CLAB = {'CAN','FRA','GER','ITA','JPN','UK'};
    VLAB = {'$\Delta(m-m^\star)$','$\Delta(p-p^\star)$','$i-i^\star$', ...
            '$\Delta(i-i^\star)$','$\Delta(m-m^\star) - \Delta(y-y^\star)$', ...
            '$\Delta(y-y^\star)$','$\Delta$U.S. TFP'};
    % SET ON GROOT, AND RESTORED ON THE WAY OUT. groot defaults are global and
    % persist for the whole session, so leaving them set made every figure drawn
    % after this one -- most of the appendix, since this runs early -- inherit
    % latex interpreters depending only on whether this generator had run. That
    % is the same trap GENFIG_MODEL's local_axes documents and avoids by styling
    % per-axes. onCleanup puts them back however this function exits.
    GK = {'defaultTextInterpreter','defaultAxesTickLabelInterpreter', ...
          'defaultLegendInterpreter'};
    g0 = get(groot, GK);
    grestore = onCleanup(@() set(groot, GK, g0));   %#ok<NASGU>
    set(groot, GK, {'latex','latex','latex'});
    files = {};

    % =================== Figure 7: Engel-West's own data ===================
    fprintf('genplots_ew: Figure 7, %.2f-%.2f, NH=%d (Engel-West data)\n', ...
            opt.fig7.range(1), opt.fig7.range(2), opt.fig7.NH);
    T7 = local_ew_table(root, C, opt.fig7.range, opt.vintage);
    % Engel_West==1 conventions: pass NaN through, and clip variable 3 by a row.
    [p7, ~] = ew_granger(T7, C, opt.fig7.NH, HAC, ...
                         struct('compress',false, 'clip_var3',true));
    [a7, b7] = local_counts(p7, opt.fig7.NH);
    local_plot(a7, CLAB);  files{end+1} = fullfile(dest,'GC_ALL_EWSAMPLEa.pdf');
    exportgraphics(gcf, files{end});
    local_plot(b7, VLAB);  files{end+1} = fullfile(dest,'GC_ALL_EWSAMPLEb.pdf');
    exportgraphics(gcf, files{end});
    fprintf('  wrote GC_ALL_EWSAMPLEa/b.pdf (Figure 7), %d cases\n', sum(a7(end,:)));
    % Variable 7 alone -- US TFP. Not a draft exhibit; ylim is 6, not 36, because
    % it counts one variable across six countries rather than six across six.
    t7 = squeeze(sum(p7(7,:,4:opt.fig7.NH) <= 0.1, 1));
    t7(end+1,:) = sum(t7,1);
    local_plot(t7, CLAB, 6);
    files{end+1} = fullfile(dest,'TFP_EWpA.pdf'); exportgraphics(gcf, files{end});

    % =================== Figure B.13: our data, their convention ===========
    fprintf('genplots_ew: Figure B.13, %.2f-%.2f, NH=%d (panel %s)\n', ...
            opt.b13.range(1), opt.b13.range(2), opt.b13.NH, ...
            sprintf('Y_ew_f%s', opt.vintage));
    T13 = local_panel_table(opt.panel, opt.b13.range);
    % Engel_West==2 conventions: compress NaN rows, no variable-3 clip.
    [p13, ~] = ew_granger(T13, C, opt.b13.NH, HAC, ...
                          struct('compress',true, 'clip_var3',false));
    [a13, b13] = local_counts(p13, opt.b13.NH);
    local_plot(a13, CLAB);  files{end+1} = fullfile(dest,'GC_ALLa.pdf');
    exportgraphics(gcf, files{end});
    local_plot(b13, VLAB);  files{end+1} = fullfile(dest,'GC_ALLb.pdf');
    exportgraphics(gcf, files{end});
    fprintf('  wrote GC_ALLa/b.pdf (Figure B.13), %d cases\n', sum(a13(end,:)));

    out = struct('p1_fig7',p7, 'p1_b13',p13, ...
                 'counts',struct('fig7_bycountry',a7, 'fig7_byvar',b7, ...
                                 'b13_bycountry',a13, 'b13_byvar',b13), ...
                 'files',{files});
end

% =========================================================================
function T = local_ew_table(root, C, range, vintage)
%   EW_DATA_ALL.xlsx into EW_GRANGER's shape, over `range`. Read BY NAME: the
%   sheet has a stray #N/A in row 1 beside CPI_US and positional indexing
%   silently offsets. EW's EX and GDP are LEVELS, so both are logged here; their
%   EURO_* are annualized percent and the differential is formed raw, which is
%   what Engel_West==1 did.
    f = fullfile(fileparts(root),'Data_Replication','Raw_Data','EW','EW_DATA_ALL.xlsx');
    if ~isfile(f)
    end
    assert(isfile(f), 'genplots_ew:noEW', 'EW_DATA_ALL.xlsx not found.');
    R = readtable(f,'Sheet','A','VariableNamingRule','preserve');
    lab = string(R{:,1}); k = ~ismissing(lab) & contains(lab,':');
    R = R(k,:); lab = lab(k);
    pr = split(lab,':');
    yr = str2double(pr(:,1)); qt = str2double(pr(:,2));
    tt = yr + (qt-1)/4;
    sel = tt >= range(1) - 1e-9 & tt <= range(2) + 1e-9;
    R = R(sel,:); tt = tt(sel);
    num = @(v) local_num(v);
    T = table();
    for i = 1:numel(C)
        c = C{i};
        T.(['EX_'     c]) = log(num(R.(['EX_'  c])));
        T.(['CPI_'    c]) = num(R.(['CPI_' c]));
        T.(['GDP_'    c]) = log(num(R.(['GDP_' c])));
        T.(['M1_'     c]) = num(R.(['M1_'  c]));
        T.(['USEURO_' c]) = num(R.EURO_US) - num(R.(['EURO_' c]));
    end
    T.CPI_US = num(R.CPI_US);
    T.GDP_US = log(num(R.GDP_US));
    T.M1_US  = num(R.M1_US);
    T.US_TFP = local_fernald_on(root, tt, vintage);
end

% =========================================================================
function T = local_panel_table(panelfile, range)
%   The B.13 panel, sliced to `range`. It is already in EW_GRANGER's shape --
%   EX and GDP stored as logs, CPI and M1 as levels, USEURO_* already formed as
%   US minus foreign in quarterly log gross units like idiff_ec -- so this only
%   selects rows.
    assert(isfile(panelfile), 'genplots_ew:noPanel', ...
        ['%s not found. Build it with ' ...
         'Data_Replication/build_ew_panel.m (or build_all_vintages).'], panelfile);
    L = load(panelfile,'Y');
    Y = L.Y;
    tt = year(Y.Time) + (quarter(Y.Time)-1)/4;
    sel = tt >= range(1) - 1e-9 & tt <= range(2) + 1e-9;
    assert(any(sel), 'genplots_ew:emptyWindow', ...
        'the panel has no quarters in %.2f-%.2f (it spans %.2f-%.2f).', ...
        range(1), range(2), tt(1), tt(end));
    if tt(end) < range(2) - 1e-9
        warning('genplots_ew:shortPanel', ...
            ['the window asks for %.2f but the panel ends %.2f -- the figure ' ...
             'will be %d quarters short.'], range(2), tt(end), ...
            round(4*(range(2)-tt(end))));
    end
    T = timetable2table(Y(sel,:), 'ConvertRowTimes', false);
end

% =========================================================================
function v = local_fernald_on(root, tt, vintage)
%   US TFP as a log level on the quarters in tt, from the Fernald sheet --
%   cumulated as GC_RUN:59 does, dropping the first quarter so the level starts
%   one in. Figure 7 and Figure B.13 therefore share one TFP source.
    switch vintage
        case '2026'; f = 'data_quarterly_2026.06.04.xlsx';
    end
    p = fullfile(fileparts(root),'Data_Replication','Raw_Data','Fernald',f);
    assert(isfile(p), 'genplots_ew:noFernald', '%s not found.', p);
    R = readtable(p,'Sheet','quarterly','Range','A2','VariableNamingRule','preserve');
    lab = string(R{:,1});
    ok = ~cellfun(@isempty, regexp(cellstr(lab),'^\d{4}:Q?\d$','once'));
    R = R(ok,:); lab = lab(ok);
    pr = regexp(cellstr(lab),'^(\d{4}):Q?(\d)$','tokens','once');
    yr = cellfun(@(c) str2double(c{1}), pr);
    qt = cellfun(@(c) str2double(c{2}), pr);
    d  = local_num(R.dtfp_util);
    ft = yr(2:end) + (qt(2:end)-1)/4;
    lv = cumsum(d(2:end)/400);
    v = NaN(numel(tt),1);
    [tf, loc] = ismember(round(tt*4), round(ft*4));
    v(tf) = lv(loc(tf));
    assert(all(isfinite(v)), 'genplots_ew:tfpCoverage', ...
        'Fernald %s does not cover the requested window (%.2f-%.2f).', ...
        vintage, tt(1), tt(end));
end

function v = local_num(v)
    if ~isnumeric(v); v = str2double(string(v)); end    % '#N/A' -> NaN
end

% =========================================================================
function [bycountry, byvar] = local_counts(p, NH)
%   Rows 1:6 only -- variable 7 (US TFP) is NOT in either figure; it drives
%   TFP_EWpA alone. Horizons 4:NH, threshold p <= 0.1, total row appended.
%   A NaN p-value -- a cell EW_GRANGER skipped for too few observations --
%   counts as NOT significant here, silently. See the note at EW_GRANGER's guard.
    bycountry = squeeze(sum(p(1:6,:,4:NH) <= 0.1, 1));
    bycountry(end+1,:) = sum(bycountry,1);
    byvar = squeeze(sum(p(1:6,:,4:NH) <= 0.1, 2));
    byvar(end+1,:) = sum(byvar,1);
end

% =========================================================================
function local_plot(pcount, labels, ymax)
%   The original plot_pvcount. ylim 36 is a SATURATION axis -- 6 variables x 6
%   countries -- so a reader can see "22 of a possible 36". It is passed in for
%   TFP_EWpA, which counts one variable across six countries and so saturates
%   at 6.
    if nargin < 3; ymax = 36; end
    horizon = 4:(size(pcount,2)+3);
    fig = figure('Name',' ','Color','w');
    fig.Units = 'inches'; fig.Position = [1 1 5 3];
    hold on;
    bar(horizon, pcount(1:end-1,:)', 'stacked');
    plot(horizon, pcount(end,:), 'k-o', 'LineWidth', 2, 'DisplayName','Total');
    xlabel({'Horizon (quarter)';' ';' ';' '});
    ylabel({'number of cases with'; '$p$-value $\leq0.1$'}, 'Interpreter','latex');
    n = min(6, numel(labels));
    legend(labels{1:n}, 'box','off', 'NumColumns',3, ...
           'Position',[0.1076 0.0396 0.8269 0.1]);
    grid on; xticks(horizon); ylim([0 ymax]);
end
