function out = genplots_ew(dest, opt)
%GENPLOTS_EW  Figures 7 and C.13: Granger causality tests as in Engel and West (2005).
%
%   out = GENPLOTS_EW(dest)
%   out = GENPLOTS_EW(dest, opt)
%
%   dest   output directory (required)
%   opt    .fig7   struct('range',[1974.00 2001.50], 'NH',16)
%          .c13    struct('range',[1976.00 2020.00], 'NH',20)
%                  range is the sample as a pair of fractional years; NH is the
%                  maximum lag
%          .panel  path to the Figure C.13 panel; default Built_Data/Y_ew.mat
%   out    struct with .p1_fig7 and .p1_c13 (p-values), .counts and .files
%
%   Writes Figure7a.pdf and Figure7b.pdf (counts by country and by variable)
%   and FigureC13a.pdf and FigureC13b.pdf (the same).
%
%   Figure 7 runs the test on Engel and West's own data (EW_DATA_ALL.xlsx).
%   Figure C.13 runs it on this package's data, sampled at end of period
%   (Built_Data/Y_ew.mat). NH is smaller for Figure 7 because the prewhitening
%   VAR inside MYHAC needs at least 4*NH + 3 observations and Figure 7 has 111.
%
%   See also EW_GRANGER, BUILD_EW_PANEL, GRANGER_CAUSE_WALDTEST.

    assert(nargin >= 1 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end
    if nargin < 2; opt = struct(); end
    if ~isfield(opt,'fig7'); opt.fig7 = struct('range',[1974.00 2001.50],'NH',16); end
    if ~isfield(opt,'c13');  opt.c13  = struct('range',[1976.00 2020.00],'NH',20); end
    root = fileparts(mfilename('fullpath'));
    if ~isfield(opt,'panel')
        opt.panel = fullfile(fileparts(root),'Data_Replication','Built_Data','Y_ew.mat');
    end
    if ~isfolder(dest); mkdir(dest); end

    C   = {'CA','FR','GE','IT','JP','UK'};
    HAC = {'Differencing','Quarterly','HAC','NW','CriticalValues','Standard'};
    CLAB = {'CAN','FRA','GER','ITA','JPN','UK'};
    VLAB = {'$\Delta(m-m^\star)$','$\Delta(p-p^\star)$','$i-i^\star$', ...
            '$\Delta(i-i^\star)$','$\Delta(m-m^\star) - \Delta(y-y^\star)$', ...
            '$\Delta(y-y^\star)$'};
    % Set latex interpreters on groot for the duration of this function;
    % onCleanup restores the previous defaults on exit.
    GK = {'defaultTextInterpreter','defaultAxesTickLabelInterpreter', ...
          'defaultLegendInterpreter'};
    g0 = get(groot, GK);
    grestore = onCleanup(@() set(groot, GK, g0));   %#ok<NASGU>
    set(groot, GK, {'latex','latex','latex'});
    files = {};

    % Figure 7: Engel and West's data.
    fprintf('genplots_ew: Figure 7, %.2f-%.2f, NH=%d (Engel-West data)\n', ...
            opt.fig7.range(1), opt.fig7.range(2), opt.fig7.NH);
    T7 = local_ew_table(root, C, opt.fig7.range);
    % Pass NaN rows through to the test, and drop the first row of variable 3.
    [p7, ~] = ew_granger(T7, C, opt.fig7.NH, HAC, ...
                         struct('compress',false, 'clip_var3',true));
    [a7, b7] = local_counts(p7, opt.fig7.NH);
    fa = local_plot(a7, CLAB);  fb = local_plot(b7, VLAB);
    local_match_legends(fa, fb);
    files{end+1} = fullfile(dest,'Figure7a.pdf');  exportgraphics(fa, files{end});
    files{end+1} = fullfile(dest,'Figure7b.pdf');  exportgraphics(fb, files{end});
    fprintf('  wrote Figure7a/b.pdf, %d cases\n', sum(a7(end,:)));

    % Figure C.13: this package's data, end-of-period sampling.
    [~, pname] = fileparts(opt.panel);
    fprintf('genplots_ew: Figure C.13, %.2f-%.2f, NH=%d (panel %s)\n', ...
            opt.c13.range(1), opt.c13.range(2), opt.c13.NH, pname);
    T13 = local_panel_table(opt.panel, opt.c13.range);
    % Drop NaN rows before lagging; variable 3 is not clipped.
    [p13, ~] = ew_granger(T13, C, opt.c13.NH, HAC, ...
                          struct('compress',true, 'clip_var3',false));
    [a13, b13] = local_counts(p13, opt.c13.NH);
    fa = local_plot(a13, CLAB);  fb = local_plot(b13, VLAB);
    local_match_legends(fa, fb);
    files{end+1} = fullfile(dest,'FigureC13a.pdf');  exportgraphics(fa, files{end});
    files{end+1} = fullfile(dest,'FigureC13b.pdf');  exportgraphics(fb, files{end});
    fprintf('  wrote FigureC13a/b.pdf, %d cases\n', sum(a13(end,:)));

    out = struct('p1_fig7',p7, 'p1_c13',p13, ...
                 'counts',struct('fig7_bycountry',a7, 'fig7_byvar',b7, ...
                                 'c13_bycountry',a13, 'c13_byvar',b13), ...
                 'files',{files});
end

% =========================================================================
function T = local_ew_table(root, C, range)
%   Read EW_DATA_ALL.xlsx over range into the table EW_GRANGER expects. Columns
%   are read by name. EX and GDP are levels in the sheet and are logged here.
%   The interest differential is U.S. minus foreign, in annualized percent.
    f = fullfile(fileparts(root),'Data_Replication','Raw_Data','EW','EW_DATA_ALL.xlsx');
    assert(isfile(f), 'genplots_ew:noEW', 'EW_DATA_ALL.xlsx not found.');
    R = readtable(f,'Sheet','A','VariableNamingRule','preserve');
    lab = string(R{:,1}); k = ~ismissing(lab) & contains(lab,':');
    R = R(k,:); lab = lab(k);
    pr = split(lab,':');
    yr = str2double(pr(:,1)); qt = str2double(pr(:,2));
    tt = yr + (qt-1)/4;
    sel = tt >= range(1) - 1e-9 & tt <= range(2) + 1e-9;
    R = R(sel,:); tt = tt(sel);
    num = @(v) local_num(v);
    T = table();
    for i = 1:numel(C)
        c = C{i};
        T.(['EX_'     c]) = log(num(R.(['EX_'  c])));
        T.(['CPI_'    c]) = num(R.(['CPI_' c]));
        T.(['GDP_'    c]) = log(num(R.(['GDP_' c])));
        T.(['M1_'     c]) = num(R.(['M1_'  c]));
        T.(['USEURO_' c]) = num(R.EURO_US) - num(R.(['EURO_' c]));
    end
    T.CPI_US = num(R.CPI_US);
    T.GDP_US = log(num(R.GDP_US));
    T.M1_US  = num(R.M1_US);
end

% =========================================================================
function T = local_panel_table(panelfile, range)
%   The Figure C.13 panel over range. It is already in the form EW_GRANGER
%   expects, so this only selects rows.
    assert(isfile(panelfile), 'genplots_ew:noPanel', ...
        ['%s not found. Build it with ' ...
         'Data_Replication/build_ew_panel.m (or build_all_vintages).'], panelfile);
    L = load(panelfile,'Y');
    Y = L.Y;
    tt = year(Y.Time) + (quarter(Y.Time)-1)/4;
    sel = tt >= range(1) - 1e-9 & tt <= range(2) + 1e-9;
    assert(any(sel), 'genplots_ew:emptyWindow', ...
        'the panel has no quarters in %.2f-%.2f (it spans %.2f-%.2f).', ...
        range(1), range(2), tt(1), tt(end));
    if tt(end) < range(2) - 1e-9
        warning('genplots_ew:shortPanel', ...
            ['the window asks for %.2f but the panel ends %.2f -- the figure ' ...
             'will be %d quarters short.'], range(2), tt(end), ...
            round(4*(range(2)-tt(end))));
    end
    T = timetable2table(Y(sel,:), 'ConvertRowTimes', false);
end

function v = local_num(v)
    if ~isnumeric(v); v = str2double(string(v)); end    % '#N/A' -> NaN
end

% =========================================================================
function [bycountry, byvar] = local_counts(p, NH)
%   Count the cells with p <= 0.1 at horizons 4:NH, by country and by variable,
%   and append a total row. A NaN p-value counts as not significant.
    bycountry = squeeze(sum(p(:,:,4:NH) <= 0.1, 1));
    bycountry(end+1,:) = sum(bycountry,1);
    byvar = squeeze(sum(p(:,:,4:NH) <= 0.1, 2));
    byvar(end+1,:) = sum(byvar,1);
end

% =========================================================================
function fig = local_plot(pcount, labels)
%   Stacked bars of the counts, with the total as a line. The y-axis runs to
%   36, the number of variable-country pairs.
    horizon = 4:(size(pcount,2)+3);
    fig = figure('Name',' ','Color','w');
    fig.Units = 'inches'; fig.Position = [1 1 5 3];
    hold on;
    bar(horizon, pcount(1:end-1,:)', 'stacked');
    plot(horizon, pcount(end,:), 'k-o', 'LineWidth', 2, 'DisplayName','Total');
    xlabel({'Horizon (quarter)';' ';' ';' '});
    ylabel({'number of cases with'; '$p$-value $\leq0.1$'}, 'Interpreter','latex');
    legend(labels{:}, 'box','off', 'NumColumns',3, ...
           'Position',[0.1076 0.0396 0.8269 0.1]);
    grid on; xticks(horizon); ylim([0 36]);
end

% =========================================================================
function local_match_legends(fa, fb)
%   Give the two panels' legends the same box, so that exportgraphics crops
%   both pages to the same size.
    drawnow                                   % legend sizes are set at layout
    la = findobj(fa, 'Type', 'legend');
    lb = findobj(fb, 'Type', 'legend');
    if la.Position(4) < lb.Position(4); la.Position = lb.Position;
    else;                               lb.Position = la.Position;
    end
end
