function fout = genfig_C15(base_info, dest, opt)
%GENFIG_C15  Figure C.15: responses of the technology proxy series.
%
%   fout = GENFIG_C15(base_info, dest)
%
%   base_info  descriptor of the baseline run
%   dest       output directory (required)
%   fout       [technology figure, noise figure]
%
%   Six panels, 3x2: the four technology proxies, then TFP and E[TFP]. The
%   proxies are projected rows. patent_app and patent_val cover a shorter sample
%   than the others (see TECH_PROXY_SERIES).
%
%   See also GENFIG_C7C8, GENFIG_C10C11, PLOTIRF, TECH_PROXY_SERIES.

    assert(nargin >= 2 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end

    % The cumulated responses on horizons -20:20, median and bands.
    [dt, dn, D.vnames] = cj_bands(base_info);
    % sfx is a file-name suffix; it is always empty.
    sfx = '';

    % Panel order: the four proxies, then TFP and its expectation.
    ROWS = {'Real R\&D Expenditure', 'Tech Standards', ...
            'Patent Applications',   'Patent Value', ...
            'Home TFP',              'E[TFP]'};
    ord = var_order(D.vnames, ROWS{:});  ord = ord(:);

    % TFP does not respond to noise by construction: set it to exactly zero in
    % both halves of the column block.
    iT = var_order(D.vnames, 'Home TFP');  nv = numel(D.vnames);
    dn(:, [iT, iT+nv], :) = 0;

    p = plotIRF;
    p.nrow = 3;  p.ncol = 2;
    p.position = [1 1 425 425];

    p.NOISE = zeros(1, numel(ord));      % technology: blue
    fout(1) = local_export(plotIRF(dt, ord, D.vnames, ['FigureC15a' sfx], 1:numel(ord), p), ...
                           fullfile(dest,['FigureC15a' sfx '.pdf']));

    p.NOISE = ones(1, numel(ord));       % noise: red
    fout(2) = local_export(plotIRF(dn, ord, D.vnames, ['FigureC15b' sfx], 1:numel(ord), p), ...
                           fullfile(dest,['FigureC15b' sfx '.pdf']));

    fprintf('  wrote FigureC15a%s.pdf / FigureC15b%s.pdf\n', sfx, sfx);
    fprintf('    %s\n    rows %s of %d\n', data_name(base_info), mat2str(ord'), numel(D.vnames));
end

% -------------------------------------------------------------------------
function f = local_export(f, target)
%   Print the whole 425x425 canvas rather than cropping to content.
    f = f(1);
    set(f, 'Color','w', 'InvertHardcopy','off', 'PaperUnits','points', ...
           'PaperPosition',[0 0 425 425], 'PaperSize',[425 425]);
    print(f, target, '-dpdf', '-r0');
end

