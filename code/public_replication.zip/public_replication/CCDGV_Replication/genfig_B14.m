function fout = genfig_B14(base_info, dest, opt)
%GENFIG_B14  Figure B.14 -- responses of the technology proxy series.
%   fout = GENFIG_B14(base_info)
%   fout = GENFIG_B14(base_info, dest)
%   fout = GENFIG_B14(base_info, dest, opt)
%   fout  [technology figure, noise figure]
%
%   Six panels, 3x2, matching the draft's Patents_IRFs_tfp.eps /
%   Patents_IRFs_noise.eps: the four technology proxies plus TFP and E[TFP].
%
%   A PLAIN PLOTIRF CALL, which is the point. This used to require a second pass
%   through the original auxiliary-variable script -- restore a commented-out var_ind, bypass a
%   `return`, uncomment three blocks -- because the proxies were assembled
%   per-figure by ir_auxvar rather than carried by the run. They are manifest
%   data rows now (rd, tech_std, patent_app, patent_val), so every run already
%   contains their IRFs and this reads them out like B.1 or B.2.
%
%   That also retires the collision the old route had (numbers here are the
%   DRAFT'S OLD ONES, which is what the bug was in): B.1 and B.10 shared one
%   var_ind and one print target, and setting it for B.10 silently wrote a Patent
%   Value figure out as TB_IRFs.eps with B.1's caption.
%
%   The noise figure's TFP panel is an exact zero, point estimate and bands,
%   as in every CJ noise figure.
%
%   COVERAGE IS RAGGED and the panels do not say so. patent_app starts 1981Q1 and
%   patent_val ends 2010Q4, so those rows are projected on a shorter sample than
%   the others; their r2 is the thing to read alongside. See TECH_PROXY_SERIES.
%
%   See also GENFIG_B7B8, GENFIG_B9B10, PLOTIRF, TECH_PROXY_SERIES.

    assert(nargin >= 2 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end

    [~, f] = data_name(base_info);
    assert(isfile(f), 'genfig_B14:noFile', '%s not found', f);
    D = load(f, 'irtfp','irnoise','vnames','point_estimate','bound','bound2');
    % One projection stage, so the run file holds the only one there is.
    sfx = '';

    % Draft panel order: the four proxies, then TFP and its expectation.
    ROWS = {'Real R\&D Expenditure', 'Tech Standards', ...
            'Patent Applications',   'Patent Value', ...
            'Home TFP',              'E[TFP]'};
    ord = var_order(D.vnames, ROWS{:});  ord = ord(:);

    h = (size(D.irtfp,1)-1)/2;
    hgrid = -50:20;  discard = 30;
    dt = pack_bands(cumsum(D.irtfp),   hgrid+h+1, discard, D);
    dn = pack_bands(cumsum(D.irnoise), hgrid+h+1, discard, D);

    % TFP does not respond to noise: CJ defines noise as orthogonal to
    % technology, so the response is a restriction, not an estimate. Exact zero,
    % both halves and all five pages, by name -- as in GENFIG_B7B8/B56.
    iT = var_order(D.vnames, 'Home TFP');  nv = numel(D.vnames);
    dn(:, [iT, iT+nv], :) = 0;

    p = plotIRF;
    p.nrow = 3;  p.ncol = 2;
    p.position = [1 1 425 425];          % draft content box is 362x362 plus margins

    p.NOISE = zeros(1, numel(ord));      % all technology -> blue
    fout(1) = local_export(plotIRF(dt, ord, D.vnames, ['Patents_IRFs_tfp_new' sfx], 1:numel(ord), p), ...
                           fullfile(dest,['Patents_IRFs_tfp_new' sfx '.pdf']));

    p.NOISE = ones(1, numel(ord));       % all noise -> red
    fout(2) = local_export(plotIRF(dn, ord, D.vnames, ['Patents_IRFs_noise_new' sfx], 1:numel(ord), p), ...
                           fullfile(dest,['Patents_IRFs_noise_new' sfx '.pdf']));

    fprintf('  wrote Patents_IRFs_tfp_new%s.pdf / _noise_new%s.pdf\n', sfx, sfx);
    fprintf('    %s\n    rows %s of %d\n', data_name(base_info), mat2str(ord'), numel(D.vnames));
end

% -------------------------------------------------------------------------
function f = local_export(f, target)
%   print, not exportgraphics -- see GENFIG_B9B10's local_export.
    f = f(1);
    set(f, 'Color','w', 'InvertHardcopy','off', 'PaperUnits','points', ...
           'PaperPosition',[0 0 425 425], 'PaperSize',[425 425]);
    print(f, target, '-dpdf', '-r0');
end

