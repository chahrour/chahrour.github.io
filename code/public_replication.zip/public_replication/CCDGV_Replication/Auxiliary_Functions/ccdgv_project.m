function [a, r2, n, res] = ccdgv_project(x, Y, nlags, blocks, lambda)
%CCDGV_PROJECT  Project a data series on the companion state; returns a row of A.
%
%   [a, r2, n, res] = ccdgv_project(x, Y, nlags)
%   [a, r2, n, res] = ccdgv_project(x, Y, nlags, blocks)
%   [a, r2, n, res] = ccdgv_project(x, Y, nlags, blocks, lambda)
%
%   x       the series, one value per row of Y.
%   Y       T x nvars data the VAR is estimated on.
%   nlags   VAR lag order.
%   blocks  number of companion-state blocks [Y_t, ..., Y_{t-blocks+1}] to
%           project on, from 1 (contemporaneous only) to nlags (default nlags).
%   lambda  ridge penalty on standardised regressors (default 0, OLS). The
%           intercept is not penalised. Do not use it for a series in the VAR.
%
%   a    1 x nvars*nlags coefficient row in raw companion-state units, zero
%        beyond the blocks used. The constant is fitted but not returned,
%        because A acts on the demeaned state.
%   r2   R-squared of the projection; 1 for a series that is in the VAR.
%   n    number of observations used.
%   res  numel(x) x 1 projection residual, NaN on rows not used.
%
%   With no more observations than regressors, a is zero and r2 is NaN.
%
%   See also GEN_AUXVARS, CCDGV_MANIFEST, CCDGV_PROJECT_DRAW.

    if nargin < 4 || isempty(blocks); blocks = nlags; end
    if nargin < 5 || isempty(lambda); lambda = 0; end
    assert(lambda >= 0, 'ccdgv_project:lambda', 'lambda = %g must be >= 0', lambda);
    assert(blocks >= 1 && blocks <= nlags && blocks == fix(blocks), ...
        'ccdgv_project:blocks', ...
        'blocks = %g; must be an integer in 1..nlags (=%d)', blocks, nlags);

    % Regressors: the first `blocks` blocks of the companion state.
    x  = x(:);
    nv = size(Y, 2);
    W  = nv*nlags;                      % full row width
    Yl = lagmatrix(Y, 0:blocks-1);
    ok = all(isfinite(Yl), 2) & isfinite(x);
    n  = sum(ok);
    nb = size(Yl, 2);

    res = NaN(numel(x), 1);             % NaN on rows not used

    % Too few observations to fit.
    if n <= nb
        a = zeros(1, W); r2 = NaN;
        return
    end

    z = x(ok);
    a = zeros(1, W);                    % unused blocks stay zero
    if lambda == 0
        % OLS with a constant.
        X = [Yl(ok,:), ones(n,1)];
        b = X \ z;
        a(1:nv*blocks) = b(1:end-1)';
        e = z - X*b;
    else
        % Ridge on standardised regressors, mapped back to raw units.
        Xo = Yl(ok,:);
        mu = mean(Xo, 1);  sd = std(Xo, 0, 1);
        assert(all(sd > 0), 'ccdgv_project:constantColumn', ...
               'a state column is constant over the sample; cannot standardise it');
        Z  = (Xo - mu) ./ sd;
        zc = z - mean(z);
        bs = (Z'*Z/n + lambda*eye(nb)) \ (Z'*zc/n);
        a(1:nv*blocks) = (bs ./ sd')';
        e = zc - Z*bs;
    end
    res(ok) = e;
    sst = sum((z - mean(z)).^2);
    if sst > 0; r2 = 1 - sum(e.^2)/sst; else; r2 = NaN; end
end
