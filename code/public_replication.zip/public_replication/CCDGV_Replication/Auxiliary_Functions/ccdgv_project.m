function [a, r2, n, res] = ccdgv_project(x, Y, nlags, blocks, lambda)
%CCDGV_PROJECT  Express a data series as a row of the auxvar matrix A.
%
%   [a, r2, n]      = CCDGV_PROJECT(x, Y, nlags)
%   [a, r2, n]      = CCDGV_PROJECT(x, Y, nlags, blocks)
%   [a, r2, n, res] = CCDGV_PROJECT(...)
%   [...]           = CCDGV_PROJECT(x, Y, nlags, blocks, lambda)
%
%   Projects x on the first `blocks` blocks of the companion state
%   [Y_t, Y_{t-1}, ..., Y_{t-blocks+1}] by OLS and returns the coefficient row a
%   (always 1 x nvars*nlags), its R2, and the number of observations used.
%
%   res is the PROJECTION RESIDUAL, numel(x) x 1, NaN on the rows OLS could not
%   use -- so it lines up with Y's rows and with `dates`, and a caller can stack
%   the columns into one T x nseries matrix without tracking each row's own mask.
%
%   WHY THE RESIDUAL IS WORTH KEEPING WHEN R2 ALREADY SUMMARISES IT. R2 is a
%   ratio of UNCONDITIONAL SAMPLE variances. Every variance share this repository
%   reports has a different denominator -- a forecast-error variance at horizon h,
%   or a spectral band -- and turning a share of the PROJECTED series into a share
%   of the ACTUAL one needs the residual's variance measured the same way. For a
%   levels VAR whose roots sit against the unit circle those are very different
%   numbers: an R2 near 1 mostly records a shared trend, which is exactly the
%   power a business-cycle band throws away. The residual SERIES carries its own
%   spectrum and its own FEV path, so neither has to be assumed. See
%   CCDGV_EXTSHARE, which falls back to a white-noise residual when this output
%   was not stored, and says so.
%
%   BLOCKS COUNTS BLOCKS, NOT LAGS. blocks = 1 is the CONTEMPORANEOUS state only,
%   equivalent to the old aux_lags = 0. Default is nlags, the full companion
%   state. The two conventions sit one apart -- ir_auxvar's aux_lags counts
%   EXTRA lags -- which is why this one is named for what it counts.
%
%   The returned row is ZERO-padded to the full width, never NaN: a row of A
%   multiplies the companion state, so an omitted block must contribute zero. A
%   NaN there would propagate into the variance-decomposition quadrature and cost
%   the run, as the unbuilt-TB_G6 columns did on the 2026-08-06 new-core sweep.
%
%   THE BASIS MUST BE THE COMPANION STATE, not an arbitrary lag window. A row of
%   A is applied to the companion state, so a projection using more lags than the
%   companion carries cannot be written as a row of A at all, and one using fewer
%   silently constrains the omitted blocks to zero. ir_auxvar's aux_lags=3 default
%   happens to give 4 blocks = nlags, which is why it works; that is a coincidence
%   of the baseline, not an invariant. Here it is derived from nlags.
%
%   WHY THIS MAKES MEMBERSHIP DERIVED RATHER THAN DECLARED. If x is itself a
%   column of Y, the basis contains it and OLS returns the corresponding unit
%   vector with R2 = 1 to machine precision. So a variable in the VAR recovers its
%   exact VAR response through the same code path as an external variable, and
%   nothing has to branch on whether it is "in" or "out". R2 < 1 is then the
%   honest signal that a series is external.
%
%   The constant is fit but dropped: A acts on the demeaned companion state.
%
%   LAMBDA > 0 IS A RIDGE on standardised regressors: each column of the state
%   is scaled to unit standard deviation over the estimation sample, x is
%   centred, and b minimises mean((x - xbar - Z*b).^2) + lambda*sum(b.^2). The
%   intercept is not penalised. The coefficients are mapped back to the raw
%   state, so the returned row multiplies the same companion state as an OLS
%   row. Penalising standardised coefficients is what makes one lambda mean the
%   same thing across regressors in percent, percent per quarter and log points.
%   Never use it for a series inside the VAR: OLS recovers its unit vector
%   exactly, a ridge shrinks it.
%
%   See also GEN_AUXVARS, CCDGV_MANIFEST.

    if nargin < 4 || isempty(blocks); blocks = nlags; end
    if nargin < 5 || isempty(lambda); lambda = 0; end
    assert(lambda >= 0, 'ccdgv_project:lambda', 'lambda = %g must be >= 0', lambda);
    assert(blocks >= 1 && blocks <= nlags && blocks == fix(blocks), ...
        'ccdgv_project:blocks', ...
        'blocks = %g; must be an integer in 1..nlags (=%d)', blocks, nlags);

    x  = x(:);
    nv = size(Y, 2);
    W  = nv*nlags;                      % full row width, whatever `blocks` is
    Yl = lagmatrix(Y, 0:blocks-1);
    ok = all(isfinite(Yl), 2) & isfinite(x);
    n  = sum(ok);
    nb = size(Yl, 2);

    res = NaN(numel(x), 1);             % full length, masked rows left NaN

    if n <= nb
        a = zeros(1, W); r2 = NaN;
        return
    end

    z = x(ok);
    a = zeros(1, W);                    % trailing blocks stay exactly zero
    if lambda == 0
        X = [Yl(ok,:), ones(n,1)];
        b = X \ z;
        a(1:nv*blocks) = b(1:end-1)';
        e = z - X*b;
    else
        Xo = Yl(ok,:);
        mu = mean(Xo, 1);  sd = std(Xo, 0, 1);
        assert(all(sd > 0), 'ccdgv_project:constantColumn', ...
               'a state column is constant over the sample; cannot standardise it');
        Z  = (Xo - mu) ./ sd;
        zc = z - mean(z);
        bs = (Z'*Z/n + lambda*eye(nb)) \ (Z'*zc/n);
        a(1:nv*blocks) = (bs ./ sd')';
        e = zc - Z*bs;
    end
    res(ok) = e;
    sst = sum((z - mean(z)).^2);
    if sst > 0; r2 = 1 - sum(e.^2)/sst; else; r2 = NaN; end
end
