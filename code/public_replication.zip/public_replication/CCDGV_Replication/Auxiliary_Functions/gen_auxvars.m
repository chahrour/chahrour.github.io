function [A, B, term_rer, term_deltaq, term_expexret, ia1, exp_tfp_j, rowkeys] = ...
         gen_auxvars(b, Aproj, keys, nvars, nlags, j_cj)
%GEN_AUXVARS  Append the constructed rows to the projected series.
%
%   [A, B, term_rer, term_deltaq, term_expexret, ia1, exp_tfp_j, rowkeys] = ...
%       gen_auxvars(b, Aproj, keys, nvars, nlags, j_cj)
%
%   b      (nvars*nlags + nconst) x nvars AR block of this draw (AR').
%   Aproj  nseries x nvars*nlags, every data series projected on the companion
%          state.
%   keys   1 x nseries keys of Aproj's rows.
%   nvars, nlags  VAR dimensions.
%   j_cj   horizon of the expected-TFP row exp_tfp_j.
%
%   A          [Aproj; constructed rows], the constructed rows in the order
%              CCDGV_MANIFEST declares them.
%   B          companion matrix.
%   term_rer, term_deltaq, term_expexret   the rer, deltaq and expexret rows.
%   ia1        the tfp row, as a column.
%   exp_tfp_j  the row tfp*B^j_cj.
%   rowkeys    a key for every row of A.
%
%   Each constructed row is a linear function of the projected rows, so it
%   inherits their projection error when an input is outside the VAR.
%
%   See also CCDGV_PROJECT, CCDGV_MANIFEST.

    % The manifest is read, and checked against the rows computed below, once
    % per session.
    persistent C checked
    if isempty(C); [~, C] = ccdgv_manifest(); end

    % Guard against a call with the wrong argument list.
    assert(~isscalar(Aproj), 'gen_auxvars:oldSignature', ...
        ['gen_auxvars now takes (b, Aproj, keys, nvars, nlags, j_cj). ' ...
         'Caller is using the old (b, nvars, nlags, j_cj, vcase, ext) form.']);

    B  = companion_form(b(1:nvars*nlags,:)');
    nb = nvars*nlags;
    assert(size(Aproj,2) == nb, 'gen_auxvars:width', ...
        'Aproj is %d wide, companion state is %d', size(Aproj,2), nb);

    % Rows of Aproj that the constructed rows are built from.
    tfp     = pick(Aproj, keys, 'tfp');
    cons    = pick(Aproj, keys, 'cons');
    invst   = pick(Aproj, keys, 'inv');
    ner     = pick(Aproj, keys, 'ner');
    idiff   = pick(Aproj, keys, 'idiff');
    consf   = pick(Aproj, keys, 'consf');
    cpidiff = pick(Aproj, keys, 'cpidiff');
    invf    = pick(Aproj, keys, 'invf');

    lag = @(r) [zeros(1,nvars), r(1:end-nvars)];   % x_t -> x_{t-1}
    cum = @(r) trunc_sum(r, B, 100);               % sum_{j=0..100} r*B^j

    % Expectations.
    exp_tfp_j = tfp*B^j_cj;
    exp_tfp_1 = tfp*B;
    exp_tfp_5 = tfp*B^5;
    expner    = ner*B;
    expcpi    = cpidiff*B;

    % Rates and returns.
    expexret  = expner - (ner + idiff);
    realrate  = (cpidiff + idiff) - expcpi;
    exret     = ner - lag(ner + idiff);

    % Exchange rates.
    rer       = ner - cpidiff;
    exprer    = expner - expcpi;
    deltaq    = rer - lag(rer);
    cumeret   = cum(-expexret);
    cum_rlzd  = cum(-exret);
    quip      = cum(-realrate);

    % Differentials and wedges.
    cdiff     = cons  - consf;
    invdiff   = invst - invf;
    bs_level  = rer - cdiff;
    bs_diff   = bs_level - lag(bs_level);

    % Bind each result to its manifest key.
    V = struct( ...
        'exp_tfp_j',exp_tfp_j, 'expner',expner,     'expexret',expexret, ...
        'realrate', realrate,  'expcpi',expcpi,     'exprer',  exprer,   ...
        'rer',      rer,       'bs_level',bs_level, 'bs_diff', bs_diff,  ...
        'deltaq',   deltaq,    'cumeret',cumeret,   'cdiff',   cdiff,    ...
        'invdiff',  invdiff,   'exp_tfp_1',exp_tfp_1, 'exp_tfp_5',exp_tfp_5, ...
        'exret',    exret,     'cum_rlzd',cum_rlzd, 'quip',    quip);

    % The computed rows must be exactly those the manifest declares.
    if isempty(checked)
        have = fieldnames(V)';
        missing = setdiff({C.key}, have);
        extra   = setdiff(have, {C.key});
        assert(isempty(missing), 'gen_auxvars:notComputed', ...
            'manifest declares but gen_auxvars does not compute: %s', ...
            strjoin(missing, ', '));
        assert(isempty(extra), 'gen_auxvars:notDeclared', ...
            'gen_auxvars computes but the manifest does not declare: %s', ...
            strjoin(extra, ', '));
        checked = true;
    end

    % Assemble A in manifest order.
    no = size(Aproj,1);
    A  = [Aproj; zeros(numel(C), nb)];
    for i = 1:numel(C)
        A(no+i, :) = V.(C(i).key);
    end
    rowkeys = [keys(:)', {C.key}];

    % Individual rows, returned separately.
    term_rer      = rer;
    term_deltaq   = deltaq;
    term_expexret = expexret;
    ia1           = tfp(:);      % the tfp row; a unit vector when TFP is in the VAR
end

function r = pick(Aproj, keys, k)
%PICK  One row of Aproj by key. Errors if the key is absent or repeated.
    i = find(strcmp(keys, k));
    assert(isscalar(i), 'gen_auxvars:missingSeries', ...
           '"%s" is not among the projected series', k);
    r = Aproj(i,:);
end

function s = trunc_sum(row, B, H)
%TRUNC_SUM  sum_{j=0}^{H} row*B^j.
%   Truncated at H because the closed form row/(I-B) blows up for
%   near-unit-root draws.
    s = row; t = row;
    for j = 1:H
        t = t*B;
        s = s + t;
    end
end
