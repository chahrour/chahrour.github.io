function [A, B, term_rer, term_deltaq, term_expexret, ia1, exp_tfp_j, rowkeys] = ...
         gen_auxvars(b, Aproj, keys, nvars, nlags, j_cj)
%GEN_AUXVARS  Append the constructed (functional) rows to the projected series.
%
%   [A, B, term_rer, term_deltaq, term_expexret, ia1, exp_tfp_j, rowkeys] =
%       GEN_AUXVARS(b, Aproj, keys, nvars, nlags, j_cj)
%
%   rowkeys is a name for every row of A: [keys, the constructed keys].
%
%   b      (nvars*nlags + nconst) x nvars AR block of this draw (i.e. AR')
%   Aproj  nseries x nvars*nlags -- EVERY data series projected on the companion
%          state, built once by the caller (draw-independent).
%   keys   1 x nseries names for Aproj's rows
%
%   A = [Aproj ; the constructed rows], so A's first block is the data and the
%   rest is algebra. ROW ORDER COMES FROM CCDGV_MANIFEST, not from the order the
%   algebra happens to be written in: each result is bound to its key in V below
%   and the assembly loop reads them back in manifest order. The two are checked
%   against each other in both directions, so a row declared but not computed --
%   or computed but not declared -- is a named error, not a misaligned A.
%
%   MEMBERSHIP IS NOT A SPECIAL CASE. Aproj holds a row for every series whether
%   or not it is in the VAR. A series in the VAR projects onto itself exactly
%   (R2 = 1, the row is a unit vector); one outside gets its best linear
%   projection (R2 < 1). Either way the algebra below is the same line of code.
%   This is what replaced the old positional scheme, where a no-FX layout set
%   oner = oidiff and every exchange-rate row was silently built from IDIFF.
%
%   The constructed rows inherit their inputs' projection error: with NER
%   outside the VAR, `rer` is the VAR's best linear predictor of the real
%   exchange rate, not the real exchange rate. Read r2 alongside A.
%
%   See also CCDGV_PROJECT, CCDGV_MANIFEST.

    % Manifest and the declared/computed cross-check are fixed for a given version
    % of this file, so both are done once per session rather than per draw.
    persistent C checked
    if isempty(C); [~, C] = ccdgv_manifest(); end

    % A caller passing the wrong number of arguments
    % would otherwise pass nvars where Aproj belongs and fail somewhere obscure.
    assert(~isscalar(Aproj), 'gen_auxvars:oldSignature', ...
        ['gen_auxvars now takes (b, Aproj, keys, nvars, nlags, j_cj). ' ...
         'Caller is using the old (b, nvars, nlags, j_cj, vcase, ext) form.']);

    B  = companion_form(b(1:nvars*nlags,:)');
    nb = nvars*nlags;
    assert(size(Aproj,2) == nb, 'gen_auxvars:width', ...
        'Aproj is %d wide, companion state is %d', size(Aproj,2), nb);

    % --- the series this algebra needs, by name ---------------------------
    tfp     = pick(Aproj, keys, 'tfp');
    cons    = pick(Aproj, keys, 'cons');
    invst   = pick(Aproj, keys, 'inv');
    ner     = pick(Aproj, keys, 'ner');
    idiff   = pick(Aproj, keys, 'idiff');
    consf   = pick(Aproj, keys, 'consf');
    cpidiff = pick(Aproj, keys, 'cpidiff');
    invf    = pick(Aproj, keys, 'invf');

    lag = @(r) [zeros(1,nvars), r(1:end-nvars)];   % x_t -> x_{t-1}
    cum = @(r) trunc_sum(r, B, 100);               % sum_{j=0..100} r*B^j

    % --- expectations ------------------------------------------------------
    exp_tfp_j = tfp*B^j_cj;
    exp_tfp_1 = tfp*B;
    exp_tfp_5 = tfp*B^5;
    expner    = ner*B;
    expcpi    = cpidiff*B;

    % --- rates and returns -------------------------------------------------
    expexret  = expner - (ner + idiff);
    realrate  = (cpidiff + idiff) - expcpi;
    exret     = ner - lag(ner + idiff);

    % --- exchange rates ----------------------------------------------------
    rer       = ner - cpidiff;
    exprer    = expner - expcpi;
    deltaq    = rer - lag(rer);
    cumeret   = cum(-expexret);
    cum_rlzd  = cum(-exret);
    quip      = cum(-realrate);

    % --- differentials and wedges ------------------------------------------
    cdiff     = cons  - consf;
    invdiff   = invst - invf;
    bs_level  = rer - cdiff;
    bs_diff   = bs_level - lag(bs_level);

    % Bind each result to its manifest key. This is the ONLY place the two lists
    % meet; the assembly below reads them back in manifest order.
    V = struct( ...
        'exp_tfp_j',exp_tfp_j, 'expner',expner,     'expexret',expexret, ...
        'realrate', realrate,  'expcpi',expcpi,     'exprer',  exprer,   ...
        'rer',      rer,       'bs_level',bs_level, 'bs_diff', bs_diff,  ...
        'deltaq',   deltaq,    'cumeret',cumeret,   'cdiff',   cdiff,    ...
        'invdiff',  invdiff,   'exp_tfp_1',exp_tfp_1, 'exp_tfp_5',exp_tfp_5, ...
        'exret',    exret,     'cum_rlzd',cum_rlzd, 'quip',    quip);

    if isempty(checked)
        have = fieldnames(V)';
        missing = setdiff({C.key}, have);
        extra   = setdiff(have, {C.key});
        assert(isempty(missing), 'gen_auxvars:notComputed', ...
            'manifest declares but gen_auxvars does not compute: %s', ...
            strjoin(missing, ', '));
        assert(isempty(extra), 'gen_auxvars:notDeclared', ...
            'gen_auxvars computes but the manifest does not declare: %s', ...
            strjoin(extra, ', '));
        checked = true;
    end

    no = size(Aproj,1);
    A  = [Aproj; zeros(numel(C), nb)];
    for i = 1:numel(C)
        A(no+i, :) = V.(C(i).key);
    end
    rowkeys = [keys(:)', {C.key}];

    % legacy outputs, unchanged in meaning and position
    term_rer      = rer;
    term_deltaq   = deltaq;
    term_expexret = expexret;
    ia1           = tfp(:);      % TFP selector; the unit vector when TFP is in the VAR
end

% -------------------------------------------------------------------------
function r = pick(Aproj, keys, k)
%PICK  One row of Aproj by name. Asserts rather than returning empty: an empty
%   row would vertcat as ZERO rows and silently shorten A.
    i = find(strcmp(keys, k));
    assert(isscalar(i), 'gen_auxvars:missingSeries', ...
           '"%s" is not among the projected series', k);
    r = Aproj(i,:);
end

function s = trunc_sum(row, B, H)
%TRUNC_SUM  sum_{j=0}^{H} row*B^j.
%   TRUNCATED ON PURPOSE at H=100. Near-unit-root draws make the closed form
%   row/(I-B) blow up, so the published moments use a deliberate finite horizon.
%   Do not "fix" this into an exact inverse.
    s = row; t = row;
    for j = 1:H
        t = t*B;
        s = s + t;
    end
end
