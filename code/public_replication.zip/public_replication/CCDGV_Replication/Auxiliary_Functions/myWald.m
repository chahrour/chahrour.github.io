function pValue = myWald(XX,yy,ny,quarterlyleads)

[cov_beta,~,bet] = myhac(XX,yy,'Intercept',false,'Display','off', 'Bandwidth','AR1OLS','Whiten',1);

if quarterlyleads == 1
    ind = 2:ny*4+1;
else
    ind = 2:ny+1;
end
cov_cut = cov_beta(ind,ind);
coeff_cut = bet(ind);

df1 = numel(coeff_cut);

% Prepare for statistics
[CovARChol,flag] = chol(cov_cut,'lower');
if flag > 0
    cov_cut = cov_cut + 1e-8 * eye(size(cov_cut),'like',cov_cut);
    CovARChol = chol(cov_cut,'lower');
end
normalRV = CovARChol \ coeff_cut;
normalRV2 = normalRV.' * normalRV;

pValue = 1- chi2cdf(normalRV2,df1);

end


