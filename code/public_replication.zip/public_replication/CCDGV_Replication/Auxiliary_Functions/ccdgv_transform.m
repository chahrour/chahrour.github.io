function [P, Q, fdvar, names, pmean, pin] = ccdgv_transform(tr, vkeys)
%CCDGV_TRANSFORM  Build the (P, Q) basis map for a specification.
%
%   [P, Q, fdvar, names, pmean, pin] = ccdgv_transform(tr, vkeys)
%
%   tr     the specification's transform table from CCDGV_MANIFEST ([] = none).
%   vkeys  the specification's variable keys, in spec order.
%
%   P, Q   nvars x nvars. The estimated system is y_t = P*z_t - Q*z_{t-1}, with
%          z the levels data: row i is an estimated variable, column j a levels
%          variable.
%   fdvar  rows of y that are first differences.
%   names  display names of the estimated variables.
%   pmean  nvars x 1 prior mean on each row's own first lag (1 = unit root,
%          0 = stationary).
%   pin    row indices whose last-lag coefficients are fixed at zero.
%
%   With tr = [] the transform is the identity: P = I, Q = 0, fdvar = [],
%   pmean = 1 for every row and pin = [].
%
%   See also CCDGV_MANIFEST, MAKE_GAM.

    nvars = numel(vkeys);

    if isempty(tr)
        P = eye(nvars);
        Q = zeros(nvars);
        fdvar = [];
        names = vkeys(:)';
        % No transform: every row is a level with the unit-root prior, and
        % nothing is pinned.
        pmean = ones(nvars,1);
        pin   = [];
        return
    end

    assert(numel(tr) == nvars, 'ccdgv_transform:width', ...
        'transform has %d rows but the spec has %d variables.', numel(tr), nvars);

    P = zeros(nvars);
    Q = zeros(nvars);
    names = cell(1, nvars);

    % Fill P and Q row by row, resolving each term's key against vkeys.
    for i = 1:nvars
        names{i} = tr(i).name;
        terms    = tr(i).terms;
        for k = 1:size(terms,1)
            j = find(strcmp(vkeys, terms{k,1}), 1);
            assert(~isempty(j), 'ccdgv_transform:noKey', ...
                'transform row %d (%s) references ''%s'', which is not in the spec.', ...
                i, tr(i).name, terms{k,1});
            P(i,j) = P(i,j) + terms{k,2};
            if tr(i).diff
                Q(i,j) = Q(i,j) + terms{k,2};
            end
        end
    end

    fdvar = find([tr.diff]);
    pmean = [tr.pmean]';
    pin   = find([tr.pin]);

    % A differenced row must be pinned: its last-lag coefficient multiplies the
    % z_{t-nlags-1} term that make_gam drops.
    assert(all(ismember(fdvar, pin)), 'ccdgv_transform:pin', ...
        'rows %s are differenced but not pinned -- make_gam''s dropped lag would be lossy.', ...
        mat2str(setdiff(fdvar, pin)));

    % make_gam solves with P, so P must be invertible.
    assert(abs(det(P)) > 1e-10, 'ccdgv_transform:singular', ...
        ['P is singular (det = %.3g). The transform cannot be inverted, so ' ...
         'the levels system is not recoverable. Check for duplicate rows.'], det(P));
end
