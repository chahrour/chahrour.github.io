function [P, Q, fdvar, names, pmean, pin] = ccdgv_transform(tr, vkeys)
%CCDGV_TRANSFORM  Build the (P,Q) basis map for a spec, resolved BY NAME.
%
%   [P, Q, fdvar, names, pmean, pin] = CCDGV_TRANSFORM(tr, vkeys)
%
%   tr     the spec's transform table from CCDGV_MANIFEST ([] = no transform)
%   vkeys  the spec's variable keys, in spec order (info.inclvarnms' keys)
%
%   P,Q    nvars x nvars, defining the estimated system in terms of the levels
%          system:   y_t = P*z_t - Q*z_{t-1}
%   fdvar  rows of y that are first differences -- DERIVED from tr, never
%          declared separately, so the two cannot disagree
%   names  display names for the estimated variables, for reporting
%   pmean  nvars x 1 prior mean on each row's own FIRST lag (1 = unit-root
%          prior, 0 = stationary). From the table's pmean field.
%   pin    1 x k row indices whose LAST-lag coefficients are pinned to zero --
%          the cointegration restriction. From the table's pin field.
%
%   pmean AND pin COME FROM THE SAME TABLE AS THE BASIS. They used to be built
%   two files apart -- the variance array in unpack_info, the mean switch
%   re-derived inside genvars from fdvar alone -- and genvars' rule ("not
%   differenced -> unit-root prior") is right for an untransformed spec and
%   wrong for a transformed one, because there the undifferenced rows are the
%   cointegrating relations. Deriving all three from one declaration is what
%   stops the basis and its prior disagreeing.
%
%   With tr = [] this returns P = I, Q = 0, fdvar = [] -- an exact identity
%   transform. Callers rely on that: it is what makes every non-VECM spec take
%   the untouched path.
%
% -------------------------------------------------------------------------
% WHY BY NAME
%
% P and Q are maps between two bases: row i indexes the ESTIMATED variable,
% column j the LEVELS variable. The old make_gam wrote them as literal indices
% inside a case switch --
%
%     P(2,[4,7]) = [1,-1];  %q = s-p_diff
%
% -- which is correct only while the spec's variable order never changes. Rows
% resolved by key survive a reordering; literal 4 and 7 do not. Same reason
% gen_auxvars resolves Aproj rows by key.
%
% NOT A DIAGONAL Q. The first VECM attempt built Q as
% diag(ismember(1:nvars,fdvar)), which cannot represent the original at all:
% its Q has entries at (4,7), (5,6), (6,8), (7,2), (8,3), because the estimated
% and levels orderings differ. A list of indices cannot encode a map between two
% bases -- that is the whole reason this function takes a table.
%
%   See also CCDGV_MANIFEST, MAKE_GAM.

    nvars = numel(vkeys);

    if isempty(tr)
        P = eye(nvars);
        Q = zeros(nvars);
        fdvar = [];
        names = vkeys(:)';
        % No transform: y IS z, every row an I(1) level, so every row takes the
        % unit-root prior and nothing is pinned. Exactly the behaviour every
        % non-VECM spec had before this was declarable.
        pmean = ones(nvars,1);
        pin   = [];
        return
    end

    assert(numel(tr) == nvars, 'ccdgv_transform:width', ...
        'transform has %d rows but the spec has %d variables.', numel(tr), nvars);

    P = zeros(nvars);
    Q = zeros(nvars);
    names = cell(1, nvars);

    for i = 1:nvars
        names{i} = tr(i).name;
        terms    = tr(i).terms;
        for k = 1:size(terms,1)
            j = find(strcmp(vkeys, terms{k,1}), 1);
            assert(~isempty(j), 'ccdgv_transform:noKey', ...
                'transform row %d (%s) references ''%s'', which is not in the spec.', ...
                i, tr(i).name, terms{k,1});
            P(i,j) = P(i,j) + terms{k,2};
            if tr(i).diff
                Q(i,j) = Q(i,j) + terms{k,2};
            end
        end
    end

    fdvar = find([tr.diff]);
    pmean = [tr.pmean]';
    pin   = find([tr.pin]);

    % A differenced row must be pinned: its last-lag coefficient is exactly the
    % z_{t-nlags-1} term make_gam drops, so leaving it free makes that truncation
    % lossy. Declared separately for readability, checked here for consistency.
    assert(all(ismember(fdvar, pin)), 'ccdgv_transform:pin', ...
        'rows %s are differenced but not pinned -- make_gam''s dropped lag would be lossy.', ...
        mat2str(setdiff(fdvar, pin)));

    % P must be invertible: make_gam forms P\(...) throughout. A singular P
    % means the transform destroys information -- two estimated variables that
    % are the same combination of levels, say -- and the levels system could not
    % be recovered. Caught here, where the table is readable, rather than as a
    % rank warning several files away.
    assert(abs(det(P)) > 1e-10, 'ccdgv_transform:singular', ...
        ['P is singular (det = %.3g). The transform cannot be inverted, so ' ...
         'the levels system is not recoverable. Check for duplicate rows.'], det(P));
end
