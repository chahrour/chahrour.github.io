function i = find_one(vnames, nm)
%FIND_ONE  Index of nm in vnames. Warns and returns 1 if nm is absent.
i = find(strcmp(vnames, nm), 1);
if isempty(i)
    warning('ccdgv_order:notFound', ...
        'variable "%s" is not in vnames -- returning index = 1.', nm);
    i = 1;
end
end
