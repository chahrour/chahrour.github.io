function i = find_one(vnames, nm)
i = find(strcmp(vnames, nm), 1);
if isempty(i)
    warning('ccdgv_order:notFound', ...
        'variable "%s" is not in vnames -- returning index = 1.', nm);
    i = 1;
end
end
