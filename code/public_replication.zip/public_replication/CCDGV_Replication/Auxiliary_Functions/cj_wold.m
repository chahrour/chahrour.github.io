function w = cj_wold(z, cep)
%CJ_WOLD  Evaluate the minimum-phase (Wold) spectral factor from its cepstrum.
%
%   w = cj_wold(z, cep)
%
%   z    scalar or array of evaluation points, typically on the unit circle.
%   cep  real vector of causal cepstrum coefficients from CJ_CEPFACTOR, in
%        ascending order: cep(1) is order 0.
%   w    wold(z) = exp( sum_{n>=0} cep(n+1) z^n ), the same size as z.
%
%   See also CJ_CEPFACTOR.

    % polyval takes coefficients in descending powers.
    w = exp( polyval(cep(end:-1:1), z) );
end
