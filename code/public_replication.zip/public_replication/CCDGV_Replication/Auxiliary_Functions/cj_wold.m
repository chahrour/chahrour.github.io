function w = cj_wold(z, cep)
% CJ_WOLD  Evaluate the minimum-phase (Wold) spectral factor from its cepstrum.
%
%   w = cj_wold(z, cep)
%
% The Chahrour-Jurado procedure needs the minimum-phase factor wold(z) of a
% scalar rational spectral density S(z), i.e. wold(z) wold(1/z) = S(z) on the
% unit circle, with wold analytic and zero-free inside the disk.  The original
% code represented it as  sig*prod(1-rn z)/prod(1-rd z)  and extracted the
% roots rn, rd symbolically (slow, and ill-conditioned for the near-unit-root
% bootstrap draws that occur in this data).
%
% Here wold is represented instead by its CEPSTRUM -- the Taylor coefficients
% of log wold:
%
%       log wold(z) = sum_{n>=0} cep(n+1) * z^n   =>   wold(z) = exp( ... ).
%
% This is the Kolmogorov/cepstral spectral factorization.  It is exact (no
% root extraction), numerically robust even when a pole and zero nearly cancel
% near the unit circle, and evaluates at ANY z (grid points or quadrature
% nodes).  cep is real; cep(1) = log(sig), so wold(0) = exp(cep(1)) = sig.
%
% INPUTS
%   z   : scalar or array of evaluation points (typically on the unit circle).
%   cep : real vector of causal cepstrum coefficients (ascending: cep(1)=order 0).
%         Produced by gentfp_gennoisecoeffs_fast.m and stored in
%         tfpcoeffs.mat / noisecoeffs.mat.
%
% OUTPUT
%   w   : wold(z), same size as z (complex on the unit circle).

    % Horner evaluation of the cepstrum polynomial sum_n cep(n+1) z^n,
    % then exponentiate.  polyval wants descending powers.
    w = exp( polyval(cep(end:-1:1), z) );
end
