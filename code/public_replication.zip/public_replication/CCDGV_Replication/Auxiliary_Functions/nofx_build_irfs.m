function [irtfp, irnoise] = nofx_build_irfs(AR_un, Sig_un, A_un, AR_r, Sig_r, idxA, smax, jh, opt)
%NOFX_BUILD_IRFS  One draw of the paper's no-FX construction.
%
%   [irtfp, irnoise] = NOFX_BUILD_IRFS(AR_un, Sig_un, A_un, AR_r, Sig_r, ...
%                                      idxA, smax, jh, opt)
%
%   AR_un/Sig_un   the FULL VAR for this draw
%   A_un           the full manifest basis for this draw (nrows x nvars*nlags)
%   AR_r/Sig_r     the restricted VAR, from IMPLIED_RESTRICTED_VAR
%   idxA           rows of A_un holding the subset's variables
%   smax           MA truncation; the returned IRFs are (2*smax+1) x nrows
%   jh             j_cj_horizon
%   opt            .N (25000) FFT length, .Ng (2^16) cepstral grid, .ridge (0)
%
%   Collapses run_nofx_main's first three scripts to a single draw:
%
%     cj_cepfactor        minimum-phase factors of the TFP and noise spectra
%     integrands + ifft   the subset system's two-sided CJ responses
%     irfs_from_subset    embed and re-expand through the full spectrum
%
%   THE RESTRICTED VAR IS AN ARGUMENT, not built here. It is a different kind of
%   object -- a property of the full system, with no CJ identification in it --
%   and keeping it outside lets VERIFY_NOFX_PORT feed this function the ORIGINAL
%   implementation's own AR_r and check the rest against their saved output to
%   1e-14. Fused, that test could not distinguish "our spectral algebra is right"
%   from "our restricted VAR matches theirs".
%
%   PURE. Takes matrices, returns matrices, touches no files.
%
%   GRID OFFSET, PRESERVED DELIBERATELY. The TFP leg evaluates on
%   w + 1e-6 and the noise leg on w. That asymmetry is in the original
%   (nofx_gentfp_freq_baseline_fast.m:86 against nofx_gennoise_baseline_fast.m:80)
%   and it is not cosmetic: the TFP integrand divides by gx(1,1), which is
%   singular at z = 1 when the system has a unit root. Removing it changes the
%   answer. It is reproduced rather than tidied.
%
%   See also NOFX_RESTRICTED, IRFS_FROM_SUBSET.

    if nargin < 9; opt = struct(); end
    N     = getdef(opt,'N',     25000);
    Ng    = getdef(opt,'Ng',    2^16);
    ridge = getdef(opt,'ridge', 0);

    nvars = size(AR_r,1);
    nlags = size(AR_r,2)/nvars;
    nx    = nvars*nlags;

    B_r = [AR_r; [eye(nx-nvars), zeros(nx-nvars,nvars)]];
    C_r = [chol(Sig_r,'lower'); zeros(nx-nvars,nvars)];
    ia  = [1; zeros(nx-1,1)];
    term = ia'*B_r^jh;                              % E_t[TFP_{t+j}] in the subset state
    A_r  = [eye(nvars), zeros(nvars, nx-nvars)];

    % ---- spectra of TFP and of the noise transfer function ----------------
    % One batched resolvent for the whole grid (TF_SWEEP) plus PAGEMTIMES,
    % exactly the rewrite GEN_CJ_IRFS_TFSWEEP applies to the full system. The
    % companion matrix here diagonalizes well (rcond(V) ~ 3e-4), so tf_sweep
    % takes its vectorized path and there is no z-loop left anywhere below.
    iar = ia.';                                              % 1 x nx
    Aq  = [A_r; term];                                       % rows we need back
    HXf  = tf_sweep(eye(nx), B_r, C_r, exp(-1i*2*pi*(0:Ng-1)/Ng));
    g11f = sum(abs(HXf(1,:,:)).^2, 2);                       % gx(1,1)
    gclf = pagemtimes(HXf,'none',HXf(1,:,:),'ctranspose');   % gx(:,1)
    hvf  = pagemtimes(term - (pagemtimes(term,gclf)./g11f).*iar, HXf);
    cep_a = cj_cepfactor(reshape(real(g11f), 1, Ng));
    cep_v = cj_cepfactor(reshape(sum(abs(hvf).^2, 2), 1, Ng));

    % ---- subset-system responses ------------------------------------------
    % cj_wold is evaluated ONCE on the whole grid. Calling it per point costs
    % 5 s of polyval per draw and was by far the largest avoidable term.
    zt = exp(-1i*(2*pi*(0:N-1)/N + 1e-6));
    HX   = tf_sweep(eye(nx), B_r, C_r, zt);
    g11  = sum(abs(HX(1,:,:)).^2, 2);
    gcol = pagemtimes(HX,'none',HX(1,:,:),'ctranspose');
    fz   = (1 - reshape(zt,1,1,N)) .* (pagemtimes(Aq,gcol)./g11) ...
           .* reshape(cj_wold(zt,cep_a), 1, 1, N);
    irtfp = rewrap(real(ifft(fz,[],3)), smax, nvars);

    zn = exp(-1i*(2*pi*(0:N-1)/N));
    HXn   = tf_sweep(eye(nx), B_r, C_r, zn);
    g11n  = sum(abs(HXn(1,:,:)).^2, 2);
    gcoln = pagemtimes(HXn,'none',HXn(1,:,:),'ctranspose');
    hv    = pagemtimes(term - (pagemtimes(term,gcoln)./g11n).*iar, HXn);
    fzn   = (1 - reshape(zn,1,1,N)) .* pagemtimes(Aq, ...
                pagemtimes(HXn,'none', hv./reshape(cj_wold(zn,cep_v),1,1,N), 'ctranspose'));
    irnoise = rewrap(real(ifft(fzn,[],3)), smax, nvars);

    % ---- embed and re-expand through the full spectrum --------------------
    H = 2*smax;
    irtfp   = irfs_from_subset(AR_un,Sig_un,AR_r,Sig_r,idxA,irtfp,  H,N,A_un,A_r,ridge);
    irnoise = irfs_from_subset(AR_un,Sig_un,AR_r,Sig_r,idxA,irnoise,H,N,A_un,A_r,ridge);
end

% -------------------------------------------------------------------------
function ir = rewrap(ir2, smax, nvars)
%   ifft output -> two-sided -smax:smax, negative lags first. The trailing
%   E[TFP] row is carried through the algebra but not used downstream.
    ir = zeros(2*smax+1, size(ir2,1));
    ir(smax+1:end,:) = squeeze(ir2(:,:,1:smax+1)).';
    ir(1:smax,:)     = squeeze(ir2(:,:,end-smax+1:end)).';
    ir = ir(:,1:nvars);
end

function v = getdef(s, f, d)
    if isfield(s,f); v = s.(f); else; v = d; end
end
