function [irtfp, irnoise] = nofx_build_irfs(AR_un, Sig_un, A_un, AR_r, Sig_r, idxA, smax, jh, opt)
%NOFX_BUILD_IRFS  Technology and noise IRFs of the no-FX construction, for one draw.
%
%   [irtfp, irnoise] = nofx_build_irfs(AR_un, Sig_un, A_un, AR_r, Sig_r, ...
%                                      idxA, smax, jh, opt)
%
%   AR_un, Sig_un  the full VAR for this draw.
%   A_un           the rows of A for the full system (nrows x nvars*nlags).
%   AR_r, Sig_r    the restricted VAR, from IMPLIED_RESTRICTED_VAR. TFP is its
%                  first variable.
%   idxA           rows of A_un that hold the subset's variables.
%   smax           MA truncation; the IRFs are (2*smax+1) x nrows, lags
%                  -smax..smax.
%   jh             horizon of the TFP expectation (j_cj_horizon).
%   opt            .N FFT length (25000), .Ng cepstral grid (2^16), .ridge (0).
%
%   Steps: the minimum-phase factors of the TFP and noise spectra
%   (CJ_CEPFACTOR); the subset system's two-sided responses by inverse FFT;
%   then IRFS_FROM_SUBSET for the full system's responses.
%
%   The technology response is evaluated on a grid shifted by 1e-6, because its
%   integrand divides by gx(1,1), which is singular at z = 1 under a unit root.
%   The noise response uses the unshifted grid.
%
%   See also NOFX_RESTRICTED, IRFS_FROM_SUBSET.

    if nargin < 9; opt = struct(); end
    N     = getdef(opt,'N',     25000);
    Ng    = getdef(opt,'Ng',    2^16);
    ridge = getdef(opt,'ridge', 0);

    % Companion form of the restricted VAR.
    nvars = size(AR_r,1);
    nlags = size(AR_r,2)/nvars;
    nx    = nvars*nlags;

    B_r = [AR_r; [eye(nx-nvars), zeros(nx-nvars,nvars)]];
    C_r = [chol(Sig_r,'lower'); zeros(nx-nvars,nvars)];
    ia  = [1; zeros(nx-1,1)];
    term = ia'*B_r^jh;                              % E_t[TFP_{t+j}] in the subset state
    A_r  = [eye(nvars), zeros(nvars, nx-nvars)];

    % Spectra of TFP and of the noise transfer function on the cepstral grid,
    % and their minimum-phase factors.
    iar = ia.';                                              % 1 x nx
    Aq  = [A_r; term];                                       % rows to return
    HXf  = tf_sweep(eye(nx), B_r, C_r, exp(-1i*2*pi*(0:Ng-1)/Ng));
    g11f = sum(abs(HXf(1,:,:)).^2, 2);                       % gx(1,1)
    gclf = pagemtimes(HXf,'none',HXf(1,:,:),'ctranspose');   % gx(:,1)
    hvf  = pagemtimes(term - (pagemtimes(term,gclf)./g11f).*iar, HXf);
    cep_a = cj_cepfactor(reshape(real(g11f), 1, Ng));
    cep_v = cj_cepfactor(reshape(sum(abs(hvf).^2, 2), 1, Ng));

    % Subset-system response to technology, on the shifted grid.
    zt = exp(-1i*(2*pi*(0:N-1)/N + 1e-6));
    HX   = tf_sweep(eye(nx), B_r, C_r, zt);
    g11  = sum(abs(HX(1,:,:)).^2, 2);
    gcol = pagemtimes(HX,'none',HX(1,:,:),'ctranspose');
    fz   = (1 - reshape(zt,1,1,N)) .* (pagemtimes(Aq,gcol)./g11) ...
           .* reshape(cj_wold(zt,cep_a), 1, 1, N);
    irtfp = rewrap(real(ifft(fz,[],3)), smax, nvars);

    % Subset-system response to noise, on the unshifted grid.
    zn = exp(-1i*(2*pi*(0:N-1)/N));
    HXn   = tf_sweep(eye(nx), B_r, C_r, zn);
    g11n  = sum(abs(HXn(1,:,:)).^2, 2);
    gcoln = pagemtimes(HXn,'none',HXn(1,:,:),'ctranspose');
    hv    = pagemtimes(term - (pagemtimes(term,gcoln)./g11n).*iar, HXn);
    fzn   = (1 - reshape(zn,1,1,N)) .* pagemtimes(Aq, ...
                pagemtimes(HXn,'none', hv./reshape(cj_wold(zn,cep_v),1,1,N), 'ctranspose'));
    irnoise = rewrap(real(ifft(fzn,[],3)), smax, nvars);

    % Full-system responses to the shocks identified from the subset.
    H = 2*smax;
    irtfp   = irfs_from_subset(AR_un,Sig_un,AR_r,Sig_r,idxA,irtfp,  H,N,A_un,A_r,ridge);
    irnoise = irfs_from_subset(AR_un,Sig_un,AR_r,Sig_r,idxA,irnoise,H,N,A_un,A_r,ridge);
end

function ir = rewrap(ir2, smax, nvars)
%   Reorder ifft output to two-sided lags -smax..smax, negative lags first,
%   and keep the first nvars columns (the E[TFP] row is dropped).
    ir = zeros(2*smax+1, size(ir2,1));
    ir(smax+1:end,:) = squeeze(ir2(:,:,1:smax+1)).';
    ir(1:smax,:)     = squeeze(ir2(:,:,end-smax+1:end)).';
    ir = ir(:,1:nvars);
end

function v = getdef(s, f, d)
%   Field f of s, or the default d.
    if isfield(s,f); v = s.(f); else; v = d; end
end
