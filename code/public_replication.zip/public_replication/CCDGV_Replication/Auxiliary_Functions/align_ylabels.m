function align_ylabels(fa, fb)
%ALIGN_YLABELS  Give two figures drawn on the same canvas the same page size.
%
%   align_ylabels(fa, fb)
%
%   fa, fb  handles of two PLOTIRF figures that form the two panels of one exhibit.
%
%   exportgraphics crops each page to its ink, whose left edge is the first
%   panel's y-label. The label nearer its axes is moved out to match the other,
%   so the two pages come out the same size. Positions are compared in data
%   units, so the two figures must share an x-axis.
%
%   See also PLOTIRF.

    drawnow                                   % label positions are set at layout
    la = local_first_ylabel(fa);
    lb = local_first_ylabel(fb);
    x  = min(la.Position(1), lb.Position(1));
    if la.Position(1) > x; la.Position(1) = x; end
    if lb.Position(1) > x; lb.Position(1) = x; end
end

function h = local_first_ylabel(f)
%   The y-label of the first panel. findobj lists axes newest first.
    ax = findobj(f(1), 'Type', 'axes');
    h  = ax(end).YLabel;
end
