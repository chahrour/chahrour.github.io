function [Bvecm, P, Bdrop] = make_gam(b, P, Q, nvars, nlags)
%MAKE_GAM  Rewrite a VAR estimated in a transformed basis back in LEVELS.
%
%   [Bvecm, P, Bdrop] = MAKE_GAM(b, P, Q, nvars, nlags)
%
%   b       nvars x nvars*nlags AR block of the ESTIMATED VAR (constant removed)
%   P,Q     the basis map, from CCDGV_TRANSFORM:  y_t = P*z_t - Q*z_{t-1}
%   Bvecm   companion matrix of the LEVELS system, in z
%   P       returned unchanged, because callers rotate the residual covariance
%           and the residuals by it
%   Bdrop   the lag-(nlags+1) block this function DISCARDS. See "DROPPED LAG".
%
%   THE ALGEBRA. Estimated system in y, levels system in z, with
%
%       y_t = (P - Q L) z_t
%
%   Substituting into (I - b1 L - ... - bn L^n) y_t = e_t gives
%
%       inv(P)*( P - (b1 P + Q)L - (b2 P - b1 Q)L^2 - ...
%                  - (bn P - b(n-1) Q)L^n - (-bn Q)L^(n+1) ) z_t = inv(P) e_t
%
%   so the LEVELS system has nlags+1 lags, one more than the estimated one.
%
% -------------------------------------------------------------------------
% TAKES P AND Q, NOT fdvar
%
% An earlier version derived them as P = eye(nvars) and
% Q = diag(ismember(1:nvars,fdvar)). That cannot represent the transform this
% function exists to invert. The original's type == 1 has
%
%     P(2,[4,7]) = [1,-1];   % q = s - p_diff
%     Q entries at (1,1) (4,7) (5,6) (6,8) (7,2) (8,3)
%
% -- P is not the identity, and Q is not diagonal, because the estimated and
% levels orderings differ. A list of indices cannot encode a map between two
% bases. P and Q now come from CCDGV_TRANSFORM, which builds them by name from
% the manifest's table.
%
% P NOT BEING THE IDENTITY IS THE POINT. It is what returns the system in the
% SPEC's variables -- for the VECM, the same eight as the baseline -- rather
% than in the transformed ones. That is what makes the B.3/B.4 overlay
% like-for-like and lets every downstream by-name lookup work unchanged.
%
%   See also CCDGV_TRANSFORM, VECM_QUICK, COMPANION_FORM.

    if nargin < 2 || isempty(P); P = eye(nvars); end
    if nargin < 3 || isempty(Q); Q = zeros(nvars); end

    assert(isequal(size(P), [nvars nvars]) && isequal(size(Q), [nvars nvars]), ...
        'make_gam:pqSize', 'P and Q must both be %dx%d.', nvars, nvars);

    B = zeros(nvars,nvars,nlags+2);
    B(:,:,1)         = eye(nvars);
    B(:,:,2:nlags+1) = reshape(b,[nvars,nvars,nlags]);

    Bnew = zeros(nvars,nvars,nlags+2);
    Bnew(:,:,1) = eye(nvars);
    Bnew(:,:,2) = P\(B(:,:,2)*P + Q);
    for jj = 3:nlags+2
        Bnew(:,:,jj) = P\(B(:,:,jj)*P - B(:,:,jj-1)*Q);
    end

    % ---- DROPPED LAG -- deliberate, and made near-lossless by the prior -----
    % The loop above fills nlags+1 coefficient blocks (indices 2..nlags+2). The
    % reshape below keeps only 2..nlags+1, so the last is discarded and the
    % returned companion is order nlags, not the nlags+1 the algebra implies.
    %
    %   Bnew(:,:,nlags+2) = P\(B(:,:,nlags+2)*P - B(:,:,nlags+1)*Q)
    %                     = -inv(P) * b_nlags * Q   (B(:,:,nlags+2) never filled)
    %
    % A previous comment here called this a suspected BUG. It is not, and the
    % reason is in unpack_info:
    %
    %     bidx(end-1-nvars+fdvar, :) = 1e-9
    %
    % which pins the prior VARIANCE of the lag-nlags coefficients ON THE fdvar
    % VARIABLES to ~0, i.e. onto a prior mean of 0. Those are exactly the
    % columns Q keeps. So the discarded block is zero twice over: EXACTLY zero
    % in the columns Q kills, and ~1e-5 in the rest, killed by the prior. The
    % truncation is therefore near-lossless BY CONSTRUCTION, not by luck.
    %
    % VECM_QUICK (est_method 4) imposes the same restriction EXACTLY, by
    % restricted OLS with the identical row selector and c = 0, which is what
    % unpack_info means about methods 1 and 4 coinciding at the point estimate.
    % Under method 4 this block is exactly zero.
    %
    % Two consequences worth stating, since a reader will wonder:
    %   * The unit root SURVIVES. Summing the kept blocks gives
    %     I - sum A_k = (I - B(1))(I - Q) + inv(P)*b_nlags*Q, and the second
    %     term is the discarded block, ~0. So the exact singularity that an I(1)
    %     variable requires holds to ~1e-5 rather than exactly.
    %   * Bdrop is the diagnostic. If it is NOT small, the bidx pin is not doing
    %     its job -- check that fdvar reached unpack_info -- and the truncation
    %     has become lossy.
    Bdrop = Bnew(:,:,nlags+2);

    Bnew  = reshape(Bnew(:,:,2:nlags+1),[nvars,nvars*nlags]);
    Bvecm = companion_form(Bnew);
end
