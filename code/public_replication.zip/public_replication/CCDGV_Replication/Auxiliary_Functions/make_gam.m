function [Bvecm, P, Bdrop] = make_gam(b, P, Q, nvars, nlags)
%MAKE_GAM  Rewrite a VAR estimated in a transformed basis as a VAR in levels.
%
%   [Bvecm, P, Bdrop] = make_gam(b, P, Q, nvars, nlags)
%
%   b       nvars x nvars*nlags AR block of the estimated VAR, without the
%           constant.
%   P, Q    the basis map from CCDGV_TRANSFORM: y_t = P*z_t - Q*z_{t-1}.
%           Defaults: P = I, Q = 0.
%   Bvecm   companion matrix of the levels system, in z, with nlags lags.
%   P       returned unchanged; callers rotate the residuals and their
%           covariance by it.
%   Bdrop   the lag-(nlags+1) coefficient block, which is dropped.
%
%   Substituting y_t = (P - Q L) z_t into (I - b1 L - ... - bn L^n) y_t = e_t
%   gives
%
%       inv(P)*( P - (b1 P + Q)L - (b2 P - b1 Q)L^2 - ...
%                  - (bn P - b(n-1) Q)L^n - (-bn Q)L^(n+1) ) z_t = inv(P) e_t
%
%   so the levels system has nlags+1 lags. The last block, -inv(P)*bn*Q, is
%   dropped. It is close to zero because the prior holds the lag-nlags
%   coefficients on the differenced rows at zero (the pin field of the
%   transform). A Bdrop that is not small means that restriction is not in force.
%
%   See also CCDGV_TRANSFORM, COMPANION_FORM.

    if nargin < 2 || isempty(P); P = eye(nvars); end
    if nargin < 3 || isempty(Q); Q = zeros(nvars); end

    assert(isequal(size(P), [nvars nvars]) && isequal(size(Q), [nvars nvars]), ...
        'make_gam:pqSize', 'P and Q must both be %dx%d.', nvars, nvars);

    % Lag polynomial of the estimated system: I, then b1..bn. The last page
    % stays zero.
    B = zeros(nvars,nvars,nlags+2);
    B(:,:,1)         = eye(nvars);
    B(:,:,2:nlags+1) = reshape(b,[nvars,nvars,nlags]);

    % Coefficient blocks of the levels system, lags 1..nlags+1.
    Bnew = zeros(nvars,nvars,nlags+2);
    Bnew(:,:,1) = eye(nvars);
    Bnew(:,:,2) = P\(B(:,:,2)*P + Q);
    for jj = 3:nlags+2
        Bnew(:,:,jj) = P\(B(:,:,jj)*P - B(:,:,jj-1)*Q);
    end

    % The lag-(nlags+1) block is returned separately and left out of the
    % companion matrix.
    Bdrop = Bnew(:,:,nlags+2);

    Bnew  = reshape(Bnew(:,:,2:nlags+1),[nvars,nvars*nlags]);
    Bvecm = companion_form(Bnew);
end
