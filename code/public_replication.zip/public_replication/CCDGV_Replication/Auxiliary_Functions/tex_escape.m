function s = tex_escape(s)
%TEX_ESCAPE  Make a plain string safe to drop into LaTeX text mode.
%
%   Written 2026-08-05 after the generated tables failed to compile: the
%   provenance note embeds case_name (e.g. origcore_baseline_fx2008), and its
%   underscores are subscript operators in text mode -- pdflatex stops with
%   "! Missing $ inserted." The numbers were right; the file simply would not
%   typeset, which is the sort of thing that only shows up when someone tries to
%   \input it.
%
%   Escapes the ten characters that are special in text mode. Order matters:
%   backslash must go first, or it would re-escape the backslashes introduced by
%   the later substitutions.

    s = char(s);
    s = strrep(s, '\', '\textbackslash{}');
    for c = {'&','%','$','#','_','{','}'}
        s = strrep(s, c{1}, ['\' c{1}]);
    end
    s = strrep(s, '~', '\textasciitilde{}');
    s = strrep(s, '^', '\textasciicircum{}');
end
