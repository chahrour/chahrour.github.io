function s = tex_escape(s)
%TEX_ESCAPE  Escape a string for LaTeX text mode.
%
%   s = tex_escape(s)
%
%   Escapes the ten characters that are special in text mode. The backslash is
%   replaced first, so that the backslashes added afterwards are left alone.

    s = char(s);
    s = strrep(s, '\', '\textbackslash{}');
    for c = {'&','%','$','#','_','{','}'}
        s = strrep(s, c{1}, ['\' c{1}]);
    end
    s = strrep(s, '~', '\textasciitilde{}');
    s = strrep(s, '^', '\textasciicircum{}');
end
