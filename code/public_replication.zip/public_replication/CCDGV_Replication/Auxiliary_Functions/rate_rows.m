function [tf, lab] = rate_rows(names)
%RATE_ROWS  Rows that figures draw as annualized rates: interest rates, bond
%           yields and expected excess returns.
%
%   [tf, lab] = RATE_ROWS(names)
%
%   names  cell array of variable names: vnames, or model panel names. Not
%          relabelled panel titles.
%   tf     logical, true for a rate row
%   lab    y-axis label of a rate panel
%
%   The data hold these rows as 100 times a quarterly log rate, i.e. percent
%   per quarter. Figures multiply them by 4 (ANNUALIZE_IRF) to show percentage
%   points at an annual rate. Estimation, tables and the numbers in the text
%   keep the quarterly units.
%
%   See also ANNUALIZE_IRF, PLOTIRF.

    RATES = {'Interest Rate Differential', 'Expected Excess Returns', ...
             'US 10-Y Bond Yield', 'G6 10-Y Bond Yield', 'Bond Yield Differential', ...
             'Expected Excess Equity Return Diff.', 'Expected Excess 10-Y Bond Return Diff.', ...
             'IDIFF', 'US 3-M Interest Rate', 'G6 3-M Interest Rate', ...
             'US Real Interest Rate', 'G6 Real Interest Rate', ...
             'US Real 10-Y Bond Yield', 'G6 Real 10-Y Bond Yield', 'Real Bond Yield Differential'};
    tf  = cellfun(@(s) (ischar(s) || isstring(s)) && any(strcmp(s, RATES)), names);
    lab = 'p.p.~(annualized)';
end
