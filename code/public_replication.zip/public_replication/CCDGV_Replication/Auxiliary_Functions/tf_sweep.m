function D = tf_sweep(G, H, ETAz, Z, tol)
%TF_SWEEP  Swept transfer function of a linear state-space system.
%
%   D = TF_SWEEP(G, H, ETAz, Z) returns, for each evaluation point Z(i),
%   i = 1..n,
%
%       D(:,:,i) = G * (I - Z(i)*H)^{-1} * ETAz(:,:,i)
%
%   the response of the system with state-transition map H and output map G,
%   driven by the (possibly point-dependent) input loading ETAz, at the
%   complex points Z(i).  Fold any radial damping into H (e.g. H = scl*hx).
%
%   D = TF_SWEEP(..., tol) sets the near-singularity tolerance (default 1e-8).
%
%   Combine with ifft over the 3rd dimension to recover time-domain IRFs.
%
%   Inputs
%     G     ny x nx          output map           (constant across points)
%     H     nx x nx          state-transition map (constant across points)
%     ETAz  nx x ncol x n    input loading at each point.  A 2-D nx x ncol
%                            input is treated as constant across all n points.
%     Z     n-vector         complex evaluation points (e.g. unit-circle grid)
%     tol   scalar           min |1 - Z(i)*lambda| below which point i is
%                            solved by the robust dense path (default 1e-8).
%
%   Output
%     D     ny x ncol x n
%
%   Speed (two stable fast paths -- no dense O(nx^3) solve in the common case):
%     * V well-conditioned : diagonalize H once, whole sweep is two batched
%       matmuls + a broadcast divide (pagemtimes).  No loop.
%     * V ill-conditioned  : Schur (U unitary, always well-conditioned),
%       precompute GU = G*U and U'*ETAz, then a TRIANGULAR solve per point
%       (O(nx^2), not O(nx^3)).  This is the case for systems with clustered
%       near-unit roots (e.g. frozen capital + bonds), whose eigenvectors are
%       nearly parallel.
%
%   Robustness.  The split-mode forms are fragile when the resolvent is
%   (near-)singular ON the contour -- a unit/marginal root of H at Z(i)~1/lambda
%   with no radial damping.  If that root is uncontrollable/unobservable the
%   TRUE transfer is finite there (pole/zero cancellation), but the split form
%   computes (rounding)/(~0) or 0*Inf = NaN.  So any point with
%   min_k |1 - Z(i)*lam_k| <= tol is recomputed with the COUPLED dense solve
%   G*((I - Z(i)*H)\ETAz(:,:,i)), which preserves the cancellation (this is the
%   original per-point \-solve).  Damped sweeps (e.g. H = scl*hx) have no such
%   points, so they never pay this cost.
%
%   Requires pagemtimes (R2020b+).

    if nargin < 5 || isempty(tol), tol = 1e-8; end

    nx   = size(H, 1);
    ny   = size(G, 1);
    Z    = reshape(Z, 1, 1, []);          % 1 x 1 x n
    n    = size(Z, 3);
    is2d = ismatrix(ETAz);
    ncol = size(ETAz, 2);
    if is2d, Bget = @(i) ETAz; else, Bget = @(i) ETAz(:,:,i); end

    [V, Lam] = eig(H);
    lam = diag(Lam);
    den = 1 - Z .* lam;                              % nx x 1 x n  (broadcast)

    % frequencies whose resolvent sits on/near a pole (need the coupled solve)
    pole = find(squeeze(min(abs(den), [], 1)) <= tol).';

    if rcond(V) > 1e-10
        % ---- fast path A: diagonalize H, fully vectorized over points ----
        GV = G * V;                                  % ny x nx
        if is2d
            VE = V \ ETAz;                           % nx x ncol
        else
            VE = reshape(V \ reshape(ETAz, nx, []), nx, ncol, n);
        end
        D = pagemtimes(GV, VE ./ den);               % ny x ncol x n (pole pts garbage)
    else
        % ---- fast path B: Schur + triangular solve (stable, O(nx^2)/point) ----
        [U, T] = schur(H, 'complex');                % H = U*T*U'
        GU  = G * U;
        Inx = eye(nx);
        D   = zeros(ny, ncol, n);
        if is2d, UE = U' * ETAz; UEget = @(i) UE; else, UE = pagemtimes(U', ETAz); UEget = @(i) UE(:,:,i); end
        for i = setdiff(1:n, pole)                   % skip pole pts (done below)
            D(:,:,i) = GU * ((Inx - Z(i)*T) \ UEget(i));
        end
    end

    % ---- coupled dense solve at the near-pole points (keeps cancellation) ----
    if ~isempty(pole)
        Inx = eye(nx);
        for i = pole
            D(:,:,i) = G * ((Inx - Z(i)*H) \ Bget(i));
        end
    end
end
