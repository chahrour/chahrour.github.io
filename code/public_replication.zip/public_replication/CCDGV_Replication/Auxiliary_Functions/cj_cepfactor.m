function cep = cj_cepfactor(S)
% CJ_CEPFACTOR  Cepstrum of the minimum-phase factor of a scalar spectrum.
%
%   cep = cj_cepfactor(S)
%
% Given samples S(lam_k) of a (real, strictly positive) rational spectral
% density on the uniform grid lam_k = 2*pi*(k-1)/Ng, k = 1..Ng (Ng even),
% returns the causal cepstrum coefficients cep such that
%
%       wold(z) = exp( sum_{n>=0} cep(n+1) z^n )
%
% is the minimum-phase (Kolmogorov) spectral factor, i.e.
% wold(z) wold(1/z) = S(z) on the unit circle, wold analytic and zero-free
% inside the disk.  Evaluate wold at any z with cj_wold(z, cep).
%
% Method (the standard cepstral / Kolmogorov factorization):
%   c   = ifft(log S)                         % full cepstrum (real, symmetric)
%   keep the causal half, halving the 0th (and Nyquist) terms, so that
%   2*Re(log wold) = log S  =>  |wold|^2 = S.
% This needs no root-finding and is robust even when a pole and a zero nearly
% cancel near the unit circle (the case that forced digits(500) in the
% symbolic version).  cep(1) = log(sig), so sig = wold(0) = exp(cep(1)).
%
% The coefficients decay geometrically (at the rate of the pole/zero nearest
% the unit circle); we drop the negligible tail.  If the spectrum has a pole
% extremely close to the circle the cepstrum is long -- pass a finer grid
% (larger Ng) for full accuracy (the caller chooses Ng).

    Ng = numel(S);
    c  = real(ifft(log(S(:).')));          % cepstrum of log-spectrum (row)

    % Causal projection -> cepstrum of the minimum-phase factor
    m              = zeros(1, Ng);
    m(1)           = c(1)/2;               % 0th coefficient = log(sig)
    m(2:Ng/2)      = c(2:Ng/2);            % positive lags kept as-is
    m(Ng/2+1)      = c(Ng/2+1)/2;          % Nyquist term

    % Trim the negligible tail (geometric decay) for compact storage
    K   = max([1, find(abs(m(1:Ng/2)) > 1e-13)]);
    cep = m(1:K);
end
