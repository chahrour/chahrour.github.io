function cep = cj_cepfactor(S)
%CJ_CEPFACTOR  Cepstrum of the minimum-phase factor of a scalar spectrum.
%
%   cep = cj_cepfactor(S)
%
%   S    samples of a real, strictly positive spectral density on the uniform
%        grid lam_k = 2*pi*(k-1)/Ng, k = 1..Ng, with Ng even.
%   cep  causal cepstrum coefficients such that
%
%            wold(z) = exp( sum_{n>=0} cep(n+1) z^n )
%
%        is the minimum-phase spectral factor: wold(z) wold(1/z) = S(z) on the
%        unit circle. cep(1) = log(wold(0)). Evaluate with CJ_WOLD.
%
%   Method: c = ifft(log S) is the full cepstrum; keep the causal half and halve
%   the zeroth and Nyquist terms. The coefficients decay geometrically and the
%   negligible tail is dropped. A pole very close to the unit circle needs a
%   finer grid.
%
%   See also CJ_WOLD.

    Ng = numel(S);
    c  = real(ifft(log(S(:).')));          % cepstrum of the log spectrum (row)

    % Causal half of the cepstrum.
    m              = zeros(1, Ng);
    m(1)           = c(1)/2;               % zeroth coefficient, log(sig)
    m(2:Ng/2)      = c(2:Ng/2);            % positive lags
    m(Ng/2+1)      = c(Ng/2+1)/2;          % Nyquist term

    % Drop the negligible tail.
    K   = max([1, find(abs(m(1:Ng/2)) > 1e-13)]);
    cep = m(1:K);
end
