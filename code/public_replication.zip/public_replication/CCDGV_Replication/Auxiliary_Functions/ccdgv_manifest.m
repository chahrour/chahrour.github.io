function [D, C, V, TR] = ccdgv_manifest()
%CCDGV_MANIFEST  The rows of A: data series, then constructed series.
%
%   [D, C, V, TR] = CCDGV_MANIFEST()
%
%   TR  per-spec basis transform -- [] for every spec but the VECM. See the TR
%       block below. It lives here beside V because a spec and the basis it is
%       estimated in are meaningless apart: one without the other is how the
%       first VECM attempt came to declare variables in first differences and
%       then estimate them in levels.
%
%   D  DATA series      -- order must match the LOADER's columns EXACTLY, one
%                          entry per emitted column. run_main asserts equality;
%                          an entry here that no loader emits shifts every later
%                          column's label with no error (bond yields and Real
%                          SP500 were exactly that, and were removed).
%                          (ryan_data: [TFP C I NER IDIFF Cs PId Is EQ_US EQ_G6])
%   C  CONSTRUCTED rows -- order must match GEN_AUXVARS' assembly
%
%   Both have fields key, name and short (the figure-panel label). Together they give the row
%   order of A: [D(1:nloaded); C]. APPENDING IS SAFE. REORDERING invalidates every
%   saved .mat, figure and table, because row i is addressed by position there.
%
%   The formulas for C live in GEN_AUXVARS, not here -- this file declares only
%   identity and order. gen_auxvars checks the two against each other in both
%   directions, so a row declared here but not computed (or computed but not
%   declared) is a named error rather than a silently misaligned A.
%
%   A series stays in D whether or not it enters the VAR. Membership is declared
%   by the spec in run_main and shows up only in R2 -- 1 for a series in the VAR,
%   less than 1 for one projected onto it.
%
%   aliases: legacy vnames spellings meaning the same row. Needed because the
%   same series appears as 'US equity prices' / 'US equity' / 'US equity growth',
%   and as both 'US bond yield' and 'US bond yields'; the last carries a stray
%   backtick in the old files.
%
%   Keys are used as struct field names in gen_auxvars, so they must be valid
%   MATLAB identifiers.
%
%   See also GEN_AUXVARS, CCDGV_PROJECT.

    % short = the abbreviated label used on figure panels. Leave '' to mean
    % "same as name"; filled in below. It lives HERE so plotting functions never
    % rebuild it -- a hand-kept vnames_short indexed by position is exactly what
    % mislabelled three panels of Figure 1.
    % projlambda: shrinkage for this row's drawn first stage, [] = the run's
    % cfg.proj.lambda. Set per row only where the series needs it; see the two
    % expected-return rows.
    % projblocks: how many blocks of the companion state this series is projected
    % on. [] = the run's nlags, i.e. the full state, which is what every row used
    % before 2026-08-07 and what all but two still use. 1 = contemporaneous only.
    % It counts BLOCKS: 1 here equals the old ir_auxvar aux_lags = 0.
    o = @(k,n,sh,varargin) struct('key',k, 'name',n, 'short',sh, ...
                                  'projblocks', pbdef(varargin{:}), ...
                                  'projlambda', pldef(varargin{:}), 'seed', 0);

    D = [ ...
        o('tfp',     'Home TFP',            '') ...
        o('cons',    'Home Consumption',    '') ...
        o('inv',     'Home Investment',     '') ...
        o('ner',     'NER',                 '') ...
        o('idiff',   'IDIFF',               '') ...
        o('consf',   'Foreign Consumption', '') ...
        o('cpidiff', 'CPIDIFF',             '') ...
        o('invf',    'Foreign Investment',  '') ...
        o('eq_us',   'US equity prices',    '') ...
        o('eq_g6',   'G6 equity prices',    '') ...
        o('tb_g6',   'U.S./G6 Trade Balance', '') ...
        o('solow_g6','Foreign Solow Residual','') ...
        o('rd',        'Real R\&D Expenditure', '') ...
        o('tech_std',  'Tech Standards',       '') ...
        o('patent_app','Patent Applications',  '') ...
        o('patent_val','Patent Value',         '') ...
        o('exret_eq_lead',  'Expected Excess Equity Return Diff.',   'Exp. Ex. Equity Ret.', [], 0.05) ...
        o('exret_bond_lead','Expected Excess 10-Y Bond Return Diff.','Exp. Ex. Bond Ret.',   [], 0.05) ...
        o('by_us',   'US 10-Y Bond Yield',  'US Bond Yield') ...
        o('by_g6',   'G6 10-Y Bond Yield',  'G6 Bond Yield') ...
        o('dtb_g6',  'U.S./G6 Trade Balance (change)', 'Change in TB') ...
    ];

    % SEED OFFSETS ARE FROZEN BY POSITION, ONCE, HERE. run_main seeds each
    % projected row with rng(proj_seed_base + manifest(jj).seed), so a row's draws
    % depend on its LABEL and not on where it sits in this list. Before this, the
    % seed was the loop index, which made row order a numerical contract: removing
    % one row shifted every later row's draws, changing figures that had nothing to
    % do with the removal.
    %
    % The offsets are assigned in list order, so they match the old loop indices
    % exactly and nothing moves today. Append new rows at the END and give them the
    % next unused offset; never renumber an existing one.
    % nx_gdp was row 12 and was removed. Its offset, 12, is retired and left
    % unused rather than reassigned: the rows after it keep the offsets they
    % already had, so their draws are untouched by the removal. That is the whole
    % point of freezing them.
    for ii = 1:numel(D); D(ii).seed = ii + (ii >= 12); end

    % dtb_g6 is the quarterly CHANGE in tb_g6 (percentage points of GDP), the
    % series the paper's Figure B.5 projects: its response is cumulated from
    % h = -20 to give the trade-balance level (GENFIG_TB). Appended last, so
    % both loaders append it last.
    % by_us / by_g6 APPENDED 2026-08-12 for the bond-yield counterpart of Figure
    % B.2. They are the GFD 10-year yields from LOAD_BONDS, in QUARTERLY LOG
    % units like idiff -- `data = 100*data` in the loaders turns them into
    % percent per quarter, so they are directly comparable to IDIFF on a plot.
    %
    % ROWS OF THIS NAME EXISTED BEFORE AND WERE REMOVED. The header above records
    % why: they were DECLARED here while no loader emitted them, which shifted
    % every later column's label with no error. Both loaders now emit them, and
    % run_main's exact-equality assert (nvall == numel(manifest)) is what makes
    % that check rather than an intention. Do not add a row here without adding
    % the column in ryan_data.
    %
    % Coverage is ragged: Yields_M.mat is optional, and where it is absent these
    % come back all-NaN. Read r2/nobs before using them -- an all-NaN row still
    % projects, it just projects onto nothing.
    % tb_g6 / nx_gdp are both PERCENT OF GDP (the loaders store fractions and
    % apply data = 100*data). Appended last, after sp500, to match the loader
    % column order in ryan_data.
    %
    % solow_g6 is the trade-
    % weighted G6 Solow residual from G6SolowResiduals.xlsx (G6_SOLOW_SERIES) --
    % NOT the Huo-Levchenko-Pandalai-Nayar utilization-adjusted foreign TFP,
    % which is annual, ends 2006/07, and entered through ir_auxvar rather than
    % the VAR. Two different series with two different loaders; only this one has
    % quarterly coverage over the paper sample. Read G6_SOLOW_SERIES before using
    % it: the aggregate silently drops to four countries before 1991.
    %
    % rd / tech_std / patent_app / patent_val APPENDED 2026-08-07: the technology
    % proxies of Figure B.10, from USDATA.xlsx via TECH_PROXY_SERIES. Carried as
    % ALWAYS-PRESENT data rows rather than assembled per-figure, so their IRFs
    % come out of every run and B.10 becomes a plotIRF call like B.1/B.2 instead
    % of a second pass. They are projections only --
    % none is in any spec's VAR -- and their coverage is ragged (patent_app
    % starts 1981Q1, patent_val ends 2010Q4), so read their r2 before use.
    %
    % exret_eq_lead / exret_bond_lead hold the EXPECTED excess return, from
    % ASSET_PRICE_data, and reach only Figure B.6. THE _lead SUFFIX IS
    % LOAD-BEARING: row t holds the value at t+1, because the figure is about
    % expected returns and the generator leads the series by one quarter before
    % regressing. Every other data row is the series at t. The final quarter is
    % NaN (the generator pads with 0, which puts a fabricated observation into the
    % first stage).
    %   exret_bond_lead  1976Q1 to roughly 2015Q4, NaN after -- see below
    %   exret_eq_lead    starts 1978Q3
    %
    % PROJECTED LIKE EVERY OTHER ROW, ON THE FULL COMPANION STATE, WITH SHRINKAGE.
    % These two are forecasting future returns, so the first stage is shrunk
    % (projlambda 0.05) to avoid overfitting. They were briefly restricted to one
    % state block, which cut the fit to 0.14 and 0.16 against 0.46 and 0.38 on the
    % full state; no reason for the restriction was ever recorded, and GENFIG_B6's
    % own docstring still quotes the full-state figures.
    %
    % exret_bond_lead WAS recorded here as "1976Q1-2018Q4 complete". It is not,
    % and never was. The GFD bond total-return panel behind it ends 2015:12
    % (Lustig-Stathopoulos-Verdelhan's sample; see Load_Data/readme bond data),
    % and the old ASSET_PRICE_data bond block reached 2018Q4 by appending
    % ones(11,8) to the price panel -- log(1) = 0, so eleven quarters of exactly
    % zero returns were entering as data. LOAD_BONDS pads with NaN instead, so
    % the row is now honestly short at the end. Read its nobs/r2 before use.
    % Figure 5's realized-return panels need no new rows: they are eq_us / eq_g6,
    % rows 9 and 10, unled.

    % Constructed rows are exact algebra on the state, not projections, so
    % projblocks is meaningless for them -- carried only so D and C stack.
    c = @(k,n,sh) struct('key',k, 'name',n, 'short',sh, 'projblocks', [], ...
                         'projlambda', []);

    C = [ ...
        c('exp_tfp_j', 'E[TFP]','') ...
        c('expner',    'ENER','') ...
        c('expexret',  'Expected Excess Returns','Exp. Ex. Returns') ...
        c('realrate',  'Interest Rate Differential','Interest Rate Diff.') ...
        c('expcpi',    'ECPIDIFF','') ...
        c('exprer',    'ERER','') ...
        c('rer',       'Real Exchange Rate','') ...
        c('bs_level',  'BS Wedge','') ...
        c('bs_diff',   '$\Delta$BS Wedge','') ...
        c('deltaq',    '$\Delta q_t$','') ...
        c('cumeret',   'RER(Ex. Ret)','') ...
        c('cdiff',     'Consumption Differential','') ...
        c('invdiff',   'Investment Differential','') ...
        c('exp_tfp_1', 'E($TFP_{t+1}$)','') ...
        c('exp_tfp_5', 'E($TFP_{t+5}$)','') ...
        c('exret',     'Rlzd Excess Returns','') ...
        c('cum_rlzd',  'Rlzd Cum Excess Ret','') ...
        c('quip',      'RER(UIP)','') ...
    ];


    %List of VAR variable specs
    BASE_FX   = {'tfp','cons','inv','ner','idiff','consf','cpidiff','invf'};
    BASE_NOFX = {'tfp','cons','inv',      'idiff','consf','cpidiff','invf'};
    EQ_FX     = {'tfp','cons','inv','ner','idiff','consf','cpidiff','invf','eq_us','eq_g6'};
    EQ_NOFX   = {'tfp','cons','inv',      'idiff','consf','cpidiff','invf','eq_us','eq_g6'};
    TB_FX     = {'tfp','cons','inv','ner','idiff','consf','cpidiff','invf','tb_g6'};
    SOLOW_FX  = {'tfp','cons','inv','ner','idiff','consf','cpidiff','invf','solow_g6'};

    % VECM. The SAME eight variables as the baseline -- see the TR note below
    % for why it does not need a spec of its own in V beyond this.
    VECM_FX   = BASE_FX;

    % BOND YIELDS APPENDED 2026-08-19, the exact counterpart of the equity pair:
    % BY_FX is EQ_FX with by_us/by_g6 in place of eq_us/eq_g6, BY_NOFX is EQ_NOFX
    % the same way. Deliberately parallel so the equity and yield exhibits differ
    % only in which two rows are in the VAR, and every generator that takes the
    % row names as an argument covers both with no new code.
    %
    % APPENDED, NOT INSERTED. inclvar is stored on info and embedded in the
    % results filename by data_name, so renumbering an existing spec would make
    % every .mat on disk mean something else while still loading cleanly.
    %
    % COVERAGE IS SHORTER THAN EQUITY'S. by_us/by_g6 come from load_bonds and the
    % GFD panel behind them ends 2015:12, which is past the paper's 2008Q2 but
    % NOT past the extended sample -- and they are NaN before the panel starts.
    % A run of these specs will report a later sd_realised than the baseline if
    % the yields start late; read report_info rather than assuming the samples
    % match. This is also why the shock-correlation table reports shared quarters.
    BY_FX     = {'tfp','cons','inv','ner','idiff','consf','cpidiff','invf','by_us','by_g6'};
    BY_NOFX   = {'tfp','cons','inv',      'idiff','consf','cpidiff','invf','by_us','by_g6'};

    % BAYESIAN VECMs (est_method 6): the baseline variables at cointegrating
    % rank 4 (spec 10, the paper's VECM) and rank 3 (spec 11, shown alongside).
    BVECM4_FX = BASE_FX;  BVECM3_FX = BASE_FX;

    % NOT ALL OF THESE ARE SWEPT. The package runs specs 1-5, 8, 9 and 10, which
    % is what sweep's SPECS table lists; 6, 7 and 11 are defined here, valid, and
    % not part of a default run. Spec 11 is the rank-3 VECM the paper shows
    % alongside the rank-4 one, so it is the likeliest of the three to be wanted:
    % sweep(cfg, ...) will not reach it without a row in that table.
    V = {BASE_FX,BASE_NOFX,EQ_FX,EQ_NOFX,TB_FX,SOLOW_FX,VECM_FX,BY_FX,BY_NOFX, ...
         BVECM4_FX,BVECM3_FX};

    % ---- TR: per-spec basis transform --------------------------------------
    %
    % [] means "estimate the spec's variables as they are", which is every spec
    % but the VECM. A non-empty entry declares that the VAR is estimated on a
    % TRANSFORM of the spec's variables:
    %
    %     y_t = P*z_t - Q*z_{t-1}
    %
    % where z is the spec's data in levels and y is what genvars estimates on.
    % make_gam inverts it afterwards, so everything downstream sees a system in
    % z -- i.e. in the SPEC's OWN variables, not the transformed ones. That is
    % what makes the VECM's IRFs directly comparable to the baseline's, and why
    % VECM_FX is BASE_FX rather than a separate variable list.
    %
    % Each row is {display name, terms, differenced?} where terms is an n x 2
    % cell of {spec variable key, coefficient}. Rows are resolved BY NAME
    % against the spec's variable list, so a spec reordering cannot silently
    % remap them -- the failure mode this project keeps finding.
    %
    % PORTED from the old make_gam type == 1, whose comment reads
    %   [dTFP,Q,idiff,dp_diff,dC*,dI*,dC,dI] = (P-QL)*[TFP,C,I,S,idiff,C*,p_diff,I*]
    % Verified row by row against that file: row 2 gives P(2,[4,7]) = [1,-1],
    % row 5 gives P(5,6) = Q(5,6) = 1, row 7 gives P(7,2) = Q(7,2) = 1.
    %
    % q = ner - cpidiff is the real exchange rate: with cpidiff = ln P - ln P*
    % and ner = ln S, that is ln S + ln P* - ln P. It is BUILT here from two
    % baseline columns rather than loaded, which is why the VECM needs no data
    % row of its own.
    % t(name, terms, diff, pmean, pin) -- the row's basis AND its prior treatment,
    % declared together. The prior used to be split: unpack_info owned the
    % variance array while genvars re-derived the mean switch from fdvar, and the
    % rule it used ("not differenced -> unit-root prior") is wrong under a
    % transform, where the undifferenced rows are the COINTEGRATING relations and
    % are assumed stationary. Both now come from here.
    %
    %   pmean  prior mean on this row's OWN FIRST lag. 1 = random walk, the
    %          Minnesota unit-root prior appropriate to an I(1) level; 0 = the
    %          stationary treatment.
    %
    %          q AND idiff CARRY 1, AND THAT IS A DELIBERATE CHOICE, NOT AN
    %          OVERSIGHT. It is arguably the wrong prior: those two rows are the
    %          COINTEGRATING RELATIONS this spec exists to assume STATIONARY, so
    %          a unit-root prior mean pulls the two error-correction terms toward
    %          random walks -- the opposite of the restriction being imposed.
    %          Every other row of a transformed system is a first difference and
    %          takes 0, so these two are the only ones in question.
    %
    %          It is kept at 1 because that is what every published result was
    %          produced with, and because the alternative was measured and buys
    %          nothing. Measured on spec 7 at 100 draws -- a transform spec defined
%          above but not swept -- flipping pmean 1 -> 0 on q and idiff:
    %
    %            own first-lag coef   q 1.065 -> 0.945     idiff 0.914 -> 0.773
    %            median IRFs          technology 3.3%%, noise 9.9%% different
    %            corr with baseline   tech  +0.005 -> +0.008
    %                                 noise -0.115 -> -0.142
    %
    %          So it moves the IRFs a little and leaves the shock-correlation
    %          anomaly (every other spec sits at +0.99) exactly where it was:
    %          the anomaly is NOT this prior. Changing it would put the appendix
    %          out of step with the published version for no gain. Revisit if the
    %          real cause is found -- the 0 treatment is one character away, and
    %          info.settings.priormean_override reproduces either arm without
    %          editing this table.
    %   pin    pin this row's LAST-lag coefficients to zero. This is the
    %          cointegration restriction itself: it kills the z_{t-nlags-1} term
    %          make_gam has to drop, so the transformed VAR(nlags) maps onto a
    %          levels VAR(nlags) with Pi = alpha*beta' and beta given. Always
    %          true for a differenced row; declared rather than derived so the
    %          restriction is readable beside the basis it belongs to.
    t = @(nm,terms,isdiff,pmean,pin) struct('name',nm, 'terms',{terms}, ...
                                            'diff',isdiff, 'pmean',pmean, 'pin',pin);

    %                                              diff  pmean  pin
    VECM_TR = [ ...
        t('dTFP',        {'tfp',1},                 true,   0,   true ) ...
        t('q',           {'ner',1; 'cpidiff',-1},   false,  1,   false) ...
        t('idiff',       {'idiff',1},               false,  1,   false) ...
        t('d(cpidiff)',  {'cpidiff',1},             true,   0,   true ) ...
        t('dC*',         {'consf',1},               true,   0,   true ) ...
        t('dI*',         {'invf',1},                true,   0,   true ) ...
        t('dC',          {'cons',1},                true,   0,   true ) ...
        t('dI',          {'inv',1},                 true,   0,   true ) ...
    ];

    % Order matches V exactly; the assert below is what enforces that. The two
    % bond-yield specs estimate their variables as they are, like every spec but
    % the VECM, so they take [].
    % ---- Bayesian VECM rules (est_method 6) --------------------------------
    % Not a basis transform: Villani's (2005) estimator works on the levels
    % data, so unpack_info turns one of these into an identity transform plus
    % info.settings.bvecm_rule. Everything the estimator needs is here, so a
    % saved run records the prior that produced it. See CCDGV_BVECM and
    % Notes/bvecm_hyperparameters.md.
    %   rank    declared, not inferred: the rank posterior is unreliable at this T
    %   order   estimation order, by name. beta = [I_r; B] is normalised on the
    %           first r variables, so those must plausibly enter the relations.
    %   rho     damping A_j -> rho^j A_j, placing the p-r unit roots at rho
    %   s       prior scale on alpha (v = 1/s^2)
    %   lambda, decay   Minnesota tightness and lag decay on the Gammas
    %   q_extra IW degrees of freedom above p
    %   ngibbs, nburn   collapsed Gibbs draws for (alpha, B)
    bv = @(rank) struct('bayes',true, 'rank',rank, 'rho',0.9999, ...
            'order',{{'ner','idiff','cons','consf','inv','invf','tfp','cpidiff'}}, ...
            's',0.25, 'lambda',0.2, 'decay',1, 'q_extra',2, 'ngibbs',20000, 'nburn',2000);

    TR = {[], [], [], [], [], [], VECM_TR, [], [], bv(4), bv(3)};

    assert(numel(TR) == numel(V), 'ccdgv_manifest:trLength', ...
        'TR has %d entries but V has %d -- every spec needs a transform entry.', ...
        numel(TR), numel(V));
    for i = 1:numel(V)
        if isempty(TR{i}); continue; end
        if isfield(TR{i},'bayes')
            assert(isempty(setxor(TR{i}.order, V{i})), 'ccdgv_manifest:bvOrder', ...
                'spec %d: `order` is not a permutation of the spec''s variables.', i);
            continue
        end
        assert(numel(TR{i}) == numel(V{i}), 'ccdgv_manifest:trWidth', ...
            'spec %d: transform has %d rows but the spec has %d variables.', ...
            i, numel(TR{i}), numel(V{i}));
        for r = 1:numel(TR{i})
            keys_r = TR{i}(r).terms(:,1);
            bad = keys_r(~ismember(keys_r, V{i}));
            assert(isempty(bad), 'ccdgv_manifest:trKey', ...
                'spec %d, transform row %d (%s): %s not in the spec.', ...
                i, r, TR{i}(r).name, strjoin(bad', ', '));
        end
    end

    % '' short means "same as name".
    for i = 1:numel(D); if isempty(D(i).short); D(i).short = D(i).name; end; end
    for i = 1:numel(C); if isempty(C(i).short); C(i).short = C(i).name; end; end
end

% -------------------------------------------------------------------------
function b = pbdef(varargin)
%   projblocks argument, or [] meaning "the run's nlags".
    if isempty(varargin) || isempty(varargin{1}); b = []; else; b = varargin{1}; end
end

function l = pldef(varargin)
%   projlambda argument, or [] meaning "the run's cfg.proj.lambda".
    if numel(varargin) < 2 || isempty(varargin{2}); l = []; else; l = varargin{2}; end
end
