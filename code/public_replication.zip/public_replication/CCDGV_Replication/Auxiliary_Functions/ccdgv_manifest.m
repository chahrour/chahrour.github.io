function [D, C, V, TR] = ccdgv_manifest()
%CCDGV_MANIFEST  The VAR system: data rows, constructed rows, specifications.
%
%   [D, C, V, TR] = ccdgv_manifest()
%
%   D   data rows, one per column of RYAN_DATA and in its column order.
%   C   constructed rows, linear functions of the data rows (GEN_AUXVARS).
%   V   V{n} lists the keys of D that are the VAR of specification n.
%   TR  TR{n} is the estimator of specification n: [] for the Minnesota VAR in
%       levels, or a Bayesian VECM rule.
%
%   Every run carries all the rows [D; C], whatever its VAR. A data row in the
%   VAR is itself; one outside it is projected on the VAR's state.
%
%   Saved results depend on four things here, so none of them may change:
%     row order     results address rows by position. Append; never reorder.
%     name          figures and tables find a row by its name.
%     seed          the draws of a projected row start from proj_seed_base + seed.
%     spec number   n is info.inclvar and part of the results file name.
%
%   See also GEN_AUXVARS, CCDGV_PROJECT, SWEEP.

    %% 1. Data rows
    % The loader multiplies every series by 100. Coverage differs by row;
    % estimate_one reports the rows that are short.
    %   seed    fixed per row. A new row takes a number no row has (12 is free).
    %   short   figure-panel label; '' means the same as name.
    %   lambda  shrinkage of the row's first stage; [] means cfg.proj.lambda.
    %
    %  seed  key                name                                      short                   lambda
    DATA = { ...
      % The baseline VAR, in VAR order. Home is the US; foreign is the trade-weighted G6.
         1  'tfp'              'Home TFP'                                ''                      []    % log level, Fernald utilisation-adjusted
         2  'cons'             'Home Consumption'                        ''                      []    % log
         3  'inv'              'Home Investment'                         ''                      []    % log
         4  'ner'              'NER'                                     ''                      []    % log nominal exchange rate, USD per foreign currency
         5  'idiff'            'IDIFF'                                   ''                      []    % 3-month rate differential ln((1+i)/(1+i*)), per quarter
         6  'consf'            'Foreign Consumption'                     ''                      []    % log
         7  'cpidiff'          'CPIDIFF'                                 ''                      []    % log price differential ln(P/P*)
         8  'invf'             'Foreign Investment'                      ''                      []    % log
      % Equity prices: in the VAR of specifications 3 and 4; projected for Figure 5.
         9  'eq_us'            'US equity prices'                        ''                      []    % log real MSCI total-return index
        10  'eq_g6'            'G6 equity prices'                        ''                      []
      % Trade balance: in the VAR of specification 5; projected for Figure C.5.
        11  'tb_g6'            'U.S./G6 Trade Balance'                   ''                      []    % percent of GDP
      % Foreign technology: in the VAR of specification 6.
        13  'solow_g6'         'Foreign Solow Residual'                  ''                      []    % trade-weighted G6, OECD EO 119; France from 1980, Germany from 1991
      % Technology proxies of Figure C.15: never in a VAR.
        14  'rd'               'Real R\&D Expenditure'                   ''                      []    % log
        15  'tech_std'         'Tech Standards'                          ''                      []    % log
        16  'patent_app'       'Patent Applications'                     ''                      []    % log; starts 1981Q1
        17  'patent_val'       'Patent Value'                            ''                      []    % log of value relative to GDP (log in the sheet); ends 2010Q4
      % Expected excess returns of Figure C.6: never in a VAR. Row t holds the
      % return realised over t+1, foreign minus home, so the last quarter is NaN.
        18  'exret_eq_lead'    'Expected Excess Equity Return Diff.'     'Exp. Ex. Equity Ret.'  0.05  % MSCI total return less the short rate
        19  'exret_bond_lead'  'Expected Excess 10-Y Bond Return Diff.'  'Exp. Ex. Bond Ret.'    0.05  % 10-year bond return less the short rate
      % Bond yields: in the VAR of specifications 8 and 9; projected for Figure 5.
        20  'by_us'            'US 10-Y Bond Yield'                      'US Bond Yield'         []    % percent per quarter, like idiff
        21  'by_g6'            'G6 10-Y Bond Yield'                      'G6 Bond Yield'         []
      % US short rate and price level: never in a VAR. The foreign levels are
      % constructed rows (US minus the differential), so levels and differential
      % add up in every draw.
        22  'i_us'             'US 3-M Interest Rate'                    'US 3-M Rate'           []    % ln(1+i)/4, per quarter, like idiff
        23  'p_us'             'US CPI'                                  ''                      []    % log, the CPI of cpidiff
    };
    % projblocks: state blocks the row is projected on; [] is all nlags of them.
    D = struct('key',DATA(:,2)', 'name',DATA(:,3)', 'short',DATA(:,4)', ...
               'projblocks',[], 'projlambda',DATA(:,5)', 'seed',DATA(:,1)');
    D = default_short(D);

    %% 2. Constructed rows
    % Exact linear functions of the VAR's state, not projections, so they carry
    % no projection settings. GEN_AUXVARS computes them; the formulas are repeated
    % here to read beside the names. E is the expectation the VAR implies at t,
    % L the lag, q = ner - cpidiff the real exchange rate. Sums run over
    % j = 0..100.
    %
    %   key          name                          short                   formula
    CONS = { ...
        'exp_tfp_j'  'E[TFP]'                      ''                      % E tfp(t+j), j = cfg.j_cj_horizon
        'expner'     'ENER'                        ''                      % E ner(t+1)
        'expexret'   'Expected Excess Returns'     'Exp. Ex. Returns'      % E ner(t+1) - ner - idiff
        'realrate'   'Interest Rate Differential'  'Interest Rate Diff.'   % idiff - (E cpidiff(t+1) - cpidiff): the real rate differential
        'expcpi'     'ECPIDIFF'                    ''                      % E cpidiff(t+1)
        'exprer'     'ERER'                        ''                      % E q(t+1)
        'rer'        'Real Exchange Rate'          ''                      % q
        'bs_level'   'BS Wedge'                    ''                      % q - (cons - consf)
        'bs_diff'    '$\Delta$BS Wedge'            ''                      % (1-L) bs_level
        'deltaq'     '$\Delta q_t$'                ''                      % (1-L) q
        'cumeret'    'RER(Ex. Ret)'                ''                      % -sum_j E expexret(t+j)
        'cdiff'      'Consumption Differential'    ''                      % cons - consf
        'invdiff'    'Investment Differential'     ''                      % inv - invf
        'exp_tfp_1'  'E($TFP_{t+1}$)'              ''                      % E tfp(t+1)
        'exp_tfp_5'  'E($TFP_{t+5}$)'              ''                      % E tfp(t+5)
        'exret'      'Rlzd Excess Returns'         ''                      % ner - L(ner + idiff)
        'cum_rlzd'   'Rlzd Cum Excess Ret'         ''                      % -sum_j E exret(t+j)
        'quip'       'RER(UIP)'                    ''                      % -sum_j E realrate(t+j)
        'i_g6'       'G6 3-M Interest Rate'        'G6 3-M Rate'           % i_us - idiff
        'rr_us'      'US Real Interest Rate'       'US Real Rate'          % i_us - (E p_us(t+1) - p_us)
        'rr_g6'      'G6 Real Interest Rate'       'G6 Real Rate'          % rr_us - realrate
        'ry_us'      'US Real 10-Y Bond Yield'     'US Real Bond Yield'    % by_us - (E p_us(t+40) - p_us)/40
        'ry_g6'      'G6 Real 10-Y Bond Yield'     'G6 Real Bond Yield'    % by_g6 - (E p_g6(t+40) - p_g6)/40, p_g6 = p_us - cpidiff
    };
    C = struct('key',CONS(:,1)', 'name',CONS(:,2)', 'short',CONS(:,3)', ...
               'projblocks',[], 'projlambda',[]);
    C = default_short(C);

    %% 3. Specifications
    % n is the specification's number: info.inclvar, and `vars<n>` in the results
    % file name. sweep runs the ones its own table lists.
    BASE = {'tfp','cons','inv','ner','idiff','consf','cpidiff','invf'};
    EQ   = [BASE {'eq_us','eq_g6'}];
    BY   = [BASE {'by_us','by_g6'}];
    noFX = @(v) v(~strcmp(v,'ner'));

    %   n   VAR                      estimator         run by sweep as
    SPEC = { ...
        1   BASE                     []              % base, extend and the six countries
        2   noFX(BASE)               []              % nofx
        3   EQ                       []              % eq
        4   noFX(EQ)                 []              % eqnofx
        5   [BASE {'tb_g6'}]         []              % tb
        6   [BASE {'solow_g6'}]      []              % forTFP
        7   {}                       []              % retired; the slot keeps 8-11 numbered
        8   BY                       []              % by
        9   noFX(BY)                 []              % bynofx
       10   BASE                     bvecm_rule(4)   % vecm
       11   BASE                     bvecm_rule(3)   % not run
    };
    assert(isequal([SPEC{:,1}], 1:size(SPEC,1)))      % a row's n is its position
    V  = SPEC(:,2)';
    TR = SPEC(:,3)';
end

function R = default_short(R)
%   '' short means "same as name".
    for i = find(cellfun(@isempty, {R.short})); R(i).short = R(i).name; end
end

function R = bvecm_rule(rank)
%BVECM_RULE  Villani's (2005) Bayesian VECM at a given cointegrating rank.
%   Estimated on the levels data by CCDGV_BVECM.
    R = struct( ...
        'bayes',   true, ...     % marks the entry as a Bayesian VECM rule
        'rank',    rank, ...     % cointegrating rank
        'rho',     0.9999, ...   % damping A_j -> rho^j A_j: puts the unit roots at rho
        'order',   {{'ner','idiff','cons','consf','inv','invf','tfp','cpidiff'}}, ...
        ...                      % estimation order; beta = [I_r; B] is normalised on the first r
        's',       0.25, ...     % prior scale on alpha (v = 1/s^2)
        'lambda',  0.2, ...      % Minnesota tightness on the Gammas
        'decay',   1, ...        % Minnesota lag decay on the Gammas
        'q_extra', 2, ...        % inverse-Wishart degrees of freedom above p
        'ngibbs',  20000, ...    % collapsed Gibbs draws for (alpha, B)
        'nburn',   2000);        % of which burn-in
end
