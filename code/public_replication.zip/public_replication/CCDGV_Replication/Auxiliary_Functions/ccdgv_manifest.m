function [D, C, V, TR] = ccdgv_manifest()
%CCDGV_MANIFEST  Declare the data rows, the constructed rows, and the VAR specifications.
%
%   [D, C, V, TR] = ccdgv_manifest()
%
%   D   data series, one entry per column the loader (ryan_data) emits, in the
%       loader's column order. run_main asserts that the counts match.
%   C   constructed series, in the order GEN_AUXVARS assembles them.
%   V   cell array of VAR specifications, each a list of keys from D.
%   TR  one entry per specification: [] to estimate the variables as they are,
%       a basis transform (the VECM), or a Bayesian VECM rule.
%
%   D and C have fields key, name and short (the figure-panel label). The rows
%   of the IRF array A are [D; C] in this order. Saved results address rows by
%   position, so append new rows rather than reordering. Keys are used as
%   struct field names and must be valid MATLAB identifiers.
%
%   A series stays in D whether or not it enters a VAR; one outside the VAR is
%   projected onto it. The formulas for C are in GEN_AUXVARS.
%
%   See also GEN_AUXVARS, CCDGV_PROJECT.

    % Data-row constructor: o(key, name, short, projblocks, projlambda).
    %   short       figure-panel label; '' means the same as name.
    %   projblocks  number of companion-state blocks the series is projected on;
    %               [] means the run's nlags, the full state.
    %   projlambda  shrinkage for the row's first stage; [] means the run's
    %               cfg.proj.lambda.
    o = @(k,n,sh,varargin) struct('key',k, 'name',n, 'short',sh, ...
                                  'projblocks', pbdef(varargin{:}), ...
                                  'projlambda', pldef(varargin{:}), 'seed', 0);

    % Notes on the data rows.
    %   tb_g6      percent of GDP.
    %   solow_g6   trade-weighted G6 Solow residual from G6SolowResiduals.xlsx;
    %              the aggregate has four countries before 1991.
    %   rd, tech_std, patent_app, patent_val
    %              the technology proxies of Figure C.14, from TECH_PROXY_SERIES.
    %              patent_app starts 1981Q1 and patent_val ends 2010Q4.
    %   exret_eq_lead, exret_bond_lead
    %              expected excess returns from ASSET_PRICE_data, for Figure C.6.
    %              Row t holds the value at t+1, so the last quarter is NaN.
    %              exret_eq_lead starts 1978Q3; exret_bond_lead runs 1976Q1 to
    %              about 2015Q4. Their first stage is shrunk (projlambda 0.05).
    %   by_us, by_g6
    %              10-year bond yields from LOAD_BONDS, in percent per quarter
    %              like idiff, for Figure 5. NaN outside the bond panel's coverage.

    D = [ ...
        o('tfp',     'Home TFP',            '') ...
        o('cons',    'Home Consumption',    '') ...
        o('inv',     'Home Investment',     '') ...
        o('ner',     'NER',                 '') ...
        o('idiff',   'IDIFF',               '') ...
        o('consf',   'Foreign Consumption', '') ...
        o('cpidiff', 'CPIDIFF',             '') ...
        o('invf',    'Foreign Investment',  '') ...
        o('eq_us',   'US equity prices',    '') ...
        o('eq_g6',   'G6 equity prices',    '') ...
        o('tb_g6',   'U.S./G6 Trade Balance', '') ...
        o('solow_g6','Foreign Solow Residual','') ...
        o('rd',        'Real R\&D Expenditure', '') ...
        o('tech_std',  'Tech Standards',       '') ...
        o('patent_app','Patent Applications',  '') ...
        o('patent_val','Patent Value',         '') ...
        o('exret_eq_lead',  'Expected Excess Equity Return Diff.',   'Exp. Ex. Equity Ret.', [], 0.05) ...
        o('exret_bond_lead','Expected Excess 10-Y Bond Return Diff.','Exp. Ex. Bond Ret.',   [], 0.05) ...
        o('by_us',   'US 10-Y Bond Yield',  'US Bond Yield') ...
        o('by_g6',   'G6 10-Y Bond Yield',  'G6 Bond Yield') ...
    ];

    % Seed offsets, fixed per row. run_main seeds each projected row with
    % rng(proj_seed_base + seed), so a row's draws do not depend on its position
    % in D. Offset 12 is unused. Give an appended row the next unused offset and
    % never renumber an existing one.
    for ii = 1:numel(D); D(ii).seed = ii + (ii >= 12); end

    % Constructed-row constructor. These rows are exact functions of the state,
    % not projections, so the projection fields are empty.
    c = @(k,n,sh) struct('key',k, 'name',n, 'short',sh, 'projblocks', [], ...
                         'projlambda', []);

    C = [ ...
        c('exp_tfp_j', 'E[TFP]','') ...
        c('expner',    'ENER','') ...
        c('expexret',  'Expected Excess Returns','Exp. Ex. Returns') ...
        c('realrate',  'Interest Rate Differential','Interest Rate Diff.') ...
        c('expcpi',    'ECPIDIFF','') ...
        c('exprer',    'ERER','') ...
        c('rer',       'Real Exchange Rate','') ...
        c('bs_level',  'BS Wedge','') ...
        c('bs_diff',   '$\Delta$BS Wedge','') ...
        c('deltaq',    '$\Delta q_t$','') ...
        c('cumeret',   'RER(Ex. Ret)','') ...
        c('cdiff',     'Consumption Differential','') ...
        c('invdiff',   'Investment Differential','') ...
        c('exp_tfp_1', 'E($TFP_{t+1}$)','') ...
        c('exp_tfp_5', 'E($TFP_{t+5}$)','') ...
        c('exret',     'Rlzd Excess Returns','') ...
        c('cum_rlzd',  'Rlzd Cum Excess Ret','') ...
        c('quip',      'RER(UIP)','') ...
    ];

    % VAR specifications, as lists of data-row keys. A specification's position
    % in V is its number (info.inclvar), which is part of the results filename,
    % so append rather than renumber.
    BASE_FX   = {'tfp','cons','inv','ner','idiff','consf','cpidiff','invf'};
    BASE_NOFX = {'tfp','cons','inv',      'idiff','consf','cpidiff','invf'};
    EQ_FX     = {'tfp','cons','inv','ner','idiff','consf','cpidiff','invf','eq_us','eq_g6'};
    EQ_NOFX   = {'tfp','cons','inv',      'idiff','consf','cpidiff','invf','eq_us','eq_g6'};
    TB_FX     = {'tfp','cons','inv','ner','idiff','consf','cpidiff','invf','tb_g6'};
    SOLOW_FX  = {'tfp','cons','inv','ner','idiff','consf','cpidiff','invf','solow_g6'};

    % The VECM uses the baseline variables; its basis transform is in TR below.
    VECM_FX   = BASE_FX;

    % Bond-yield specifications: the equity specifications with by_us/by_g6 in
    % place of eq_us/eq_g6. The yields cover a shorter sample than equity prices.
    BY_FX     = {'tfp','cons','inv','ner','idiff','consf','cpidiff','invf','by_us','by_g6'};
    BY_NOFX   = {'tfp','cons','inv',      'idiff','consf','cpidiff','invf','by_us','by_g6'};

    % Bayesian VECMs (est_method 6): the baseline variables at cointegrating
    % rank 4 and rank 3.
    BVECM4_FX = BASE_FX;  BVECM3_FX = BASE_FX;

    % sweep runs only the specifications listed in its own table.
    V = {BASE_FX,BASE_NOFX,EQ_FX,EQ_NOFX,TB_FX,SOLOW_FX,VECM_FX,BY_FX,BY_NOFX, ...
         BVECM4_FX,BVECM3_FX};

    % Basis transforms.
    % [] means the VAR is estimated on the specification's variables as they
    % are. A transform means it is estimated on
    %
    %     y_t = P*z_t - Q*z_{t-1}
    %
    % where z is the specification's data in levels. make_gam inverts the
    % transform, so everything downstream sees a system in z.
    %
    % Each row is t(name, terms, diff, pmean, pin):
    %   terms  n x 2 cell of {variable key, coefficient}, resolved by name.
    %   diff   true if the row is a first difference.
    %   pmean  prior mean on the row's own first lag: 1 = random walk,
    %          0 = stationary.
    %   pin    fix the row's last-lag coefficients at zero, so that the
    %          transformed VAR(nlags) maps onto a levels VAR(nlags). True for
    %          every differenced row.
    %
    % q = ner - cpidiff is the real exchange rate. q and idiff are the
    % cointegrating relations and carry pmean = 1;
    % info.settings.priormean_override changes that without editing this table.
    t = @(nm,terms,isdiff,pmean,pin) struct('name',nm, 'terms',{terms}, ...
                                            'diff',isdiff, 'pmean',pmean, 'pin',pin);

    %                                              diff  pmean  pin
    VECM_TR = [ ...
        t('dTFP',        {'tfp',1},                 true,   0,   true ) ...
        t('q',           {'ner',1; 'cpidiff',-1},   false,  1,   false) ...
        t('idiff',       {'idiff',1},               false,  1,   false) ...
        t('d(cpidiff)',  {'cpidiff',1},             true,   0,   true ) ...
        t('dC*',         {'consf',1},               true,   0,   true ) ...
        t('dI*',         {'invf',1},                true,   0,   true ) ...
        t('dC',          {'cons',1},                true,   0,   true ) ...
        t('dI',          {'inv',1},                 true,   0,   true ) ...
    ];

    % Bayesian VECM rules (est_method 6). Villani's (2005) estimator works on the
    % levels data, so unpack_info turns a rule into an identity transform plus
    % info.settings.bvecm_rule. See CCDGV_BVECM.
    %   rank    cointegrating rank, declared rather than inferred.
    %   order   estimation order, by name. beta = [I_r; B] is normalised on the
    %           first r variables.
    %   rho     damping A_j -> rho^j A_j, which puts the p-r unit roots at rho.
    %   s       prior scale on alpha (v = 1/s^2).
    %   lambda, decay   Minnesota tightness and lag decay on the Gammas.
    %   q_extra inverse-Wishart degrees of freedom above p.
    %   ngibbs, nburn   collapsed Gibbs draws for (alpha, B).
    bv = @(rank) struct('bayes',true, 'rank',rank, 'rho',0.9999, ...
            'order',{{'ner','idiff','cons','consf','inv','invf','tfp','cpidiff'}}, ...
            's',0.25, 'lambda',0.2, 'decay',1, 'q_extra',2, 'ngibbs',20000, 'nburn',2000);

    % One entry per specification, in the order of V.
    TR = {[], [], [], [], [], [], VECM_TR, [], [], bv(4), bv(3)};

    % Check each entry against its specification.
    assert(numel(TR) == numel(V), 'ccdgv_manifest:trLength', ...
        'TR has %d entries but V has %d -- every spec needs a transform entry.', ...
        numel(TR), numel(V));
    for i = 1:numel(V)
        if isempty(TR{i}); continue; end
        if isfield(TR{i},'bayes')
            assert(isempty(setxor(TR{i}.order, V{i})), 'ccdgv_manifest:bvOrder', ...
                'spec %d: `order` is not a permutation of the spec''s variables.', i);
            continue
        end
        assert(numel(TR{i}) == numel(V{i}), 'ccdgv_manifest:trWidth', ...
            'spec %d: transform has %d rows but the spec has %d variables.', ...
            i, numel(TR{i}), numel(V{i}));
        for r = 1:numel(TR{i})
            keys_r = TR{i}(r).terms(:,1);
            bad = keys_r(~ismember(keys_r, V{i}));
            assert(isempty(bad), 'ccdgv_manifest:trKey', ...
                'spec %d, transform row %d (%s): %s not in the spec.', ...
                i, r, TR{i}(r).name, strjoin(bad', ', '));
        end
    end

    % '' short means "same as name".
    for i = 1:numel(D); if isempty(D(i).short); D(i).short = D(i).name; end; end
    for i = 1:numel(C); if isempty(C(i).short); C(i).short = C(i).name; end; end
end

function b = pbdef(varargin)
%   projblocks argument, or [] meaning "the run's nlags".
    if isempty(varargin) || isempty(varargin{1}); b = []; else; b = varargin{1}; end
end

function l = pldef(varargin)
%   projlambda argument, or [] meaning "the run's cfg.proj.lambda".
    if numel(varargin) < 2 || isempty(varargin{2}); l = []; else; l = varargin{2}; end
end
