function d = pack_bands(x, win, discard, D)
%PACK_BANDS  Posterior median and two credible bands, in plotIRF's page layout.
%
%   d = PACK_BANDS(x, win, discard, D)
%
%   x        nimp x nrows x (ndraws+1): the draws, with the point estimate last
%   win      row indices to keep -- the horizon window, usually hgrid+h+1
%   discard  rows to drop from the FRONT of that window, after windowing
%   D        needs .point_estimate, .bound and .bound2
%
%   RETURNS nimp x 2*nrows x 5. The five pages are what plotIRF expects:
%
%       1      central estimate: the posterior median, or the stored point
%              estimate when D.point_estimate is set
%       2, 3   the D.bound band, lower and upper
%       4, 5   the D.bound2 band, lower and upper
%
%   THE COLUMNS ARE DUPLICATED, and that is not redundancy. plotIRF indexes its
%   panels as nvars+order(n), where nvars is the number of rows in the FULL
%   variable list -- it reads the second half of the block. Both halves are
%   written identically so the figure finds its series wherever it looks.
%
%   ONE COPY FOR SIX GENERATORS. GENFIG_B6, B7B8, B9B10, B14, R23 and TB each
%   carried a private local_pack with this body; they had drifted apart in their
%   comments while the code stayed the same, so a fix in one reached none of the
%   others. GENFIG_B12 is deliberately NOT a caller: it packs a single column
%   with no duplication and uses prctile, which is a different function that
%   happened to share the name.
%
%   See also PLOTIRF, GENFIG_B6, GENFIG_B9B10.

    x = x(win,:,:);
    if D.point_estimate; m = x(:,:,end); else; m = median(x,3); end
    q1 = quantile(x, [D.bound  1-D.bound ], 3);
    q2 = quantile(x, [D.bound2 1-D.bound2], 3);
    k  = discard+1:size(x,1);
    dup = @(A) [A, A];
    d = NaN(numel(k), 2*size(x,2), 5);
    d(:,:,1) = dup(m(k,:));
    d(:,:,2) = dup(q1(k,:,1));   d(:,:,3) = dup(q1(k,:,2));
    d(:,:,4) = dup(q2(k,:,1));   d(:,:,5) = dup(q2(k,:,2));
end
