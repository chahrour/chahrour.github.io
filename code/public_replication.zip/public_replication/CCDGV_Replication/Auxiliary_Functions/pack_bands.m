function d = pack_bands(x, win, discard, D)
%PACK_BANDS  Posterior median and two credible bands, in plotIRF's page layout.
%
%   d = pack_bands(x, win, discard, D)
%
%   x        nimp x nrows x (ndraws+1): the draws, with the point estimate last.
%   win      row indices to keep (the horizon window).
%   discard  number of rows to drop from the front of the window.
%   D        struct with point_estimate, bound and bound2.
%
%   d        (numel(win)-discard) x 2*nrows x 5, the pages plotIRF expects:
%              1      the median across pages, or the stored point estimate
%                     when D.point_estimate is set
%              2, 3   the D.bound band, lower and upper
%              4, 5   the D.bound2 band, lower and upper
%            The columns are duplicated, [x x], because plotIRF reads its
%            panels from the second half of the block.
%
%   See also PLOTIRF.

    x = x(win,:,:);
    if D.point_estimate; m = x(:,:,end); else; m = median(x,3); end
    q1 = quantile(x, [D.bound  1-D.bound ], 3);
    q2 = quantile(x, [D.bound2 1-D.bound2], 3);
    k  = discard+1:size(x,1);
    dup = @(A) [A, A];
    d = NaN(numel(k), 2*size(x,2), 5);
    d(:,:,1) = dup(m(k,:));
    d(:,:,2) = dup(q1(k,:,1));   d(:,:,3) = dup(q1(k,:,2));
    d(:,:,4) = dup(q2(k,:,1));   d(:,:,5) = dup(q2(k,:,2));
end
