function [output, V, vardec_unc]=maxshr(b,vmat,nvars,nlags,KLbar,KUbar,nimp,vd_fr,j_cj_horizon,shock_extract,Aproj,keys)
%MAXSHR  Max-share identification.
%
%   SERIES ARE ADDRESSED BY NAME. The spec's variable list and the manifest's row
%   list both move with info.inclvar, so a row number is only ever right for the
%   layout it was written against. Everything here goes through gen_auxvars:
%   term_rer for the real exchange rate, ia1 for the TFP selector, and rowkeys to
%   name the rows of A.
%
%   targ(1,1)=1 in the frequency-domain block is NOT an exception: vdfilter's
%   targ selects a SHOCK (it forms C*targ'), and the identified shock is the
%   first column of U by construction, in every spec.
% Aproj/keys: every data series projected on the companion state, built once by
% the caller. Membership is no longer a case.

% B = Companion form and A = aux vars
[A,B,term_rer,term_deltaq,term_expexret,ia1,~,rowkeys] = gen_auxvars(b,Aproj,keys,nvars,nlags,j_cj_horizon);

%- Lower triangular matrix s.t. vcv of fundamental shocks is I matrix = Cholesky decomp of vmat
Atilde = chol(vmat)';

C = zeros(size(B,1),nvars);
C(1:nvars, 1:nvars) = Atilde;

if shock_extract == 1  %FEV target

    %- compute Rtildes for each l
    Rtilde=zeros(1,nvars,KUbar+1);
    for l=0:KUbar
        B_l=B^l;
        %Rtilde(:,:,l+1)=ia1(1:nvars)'*B_l(1:nvars,1:nvars)*C;   %Max TFP
        Rtilde(:,:,l+1)=term_rer*B_l*C;  %Max RER
        %Rtilde(:,:,l+1)=term_deltaq(1,1:2*nvars)*C_l(1:2*nvars,1:nvars)*C;
        %Rtilde(:,:,l+1)=term_expexret*B_l*C;
    end

    %compute S
    S=zeros(nvars,nvars);
    for l=0:KUbar
        S=S+(KUbar+1-max(KLbar,l))*Rtilde(:,:,l+1)'*Rtilde(:,:,l+1); %It is transpose because the first row of Rtilde is the response of the first variable to all shocks
    end

    [V,D]=eig(S);
    lambda=[diag(D) seqa(1,1,nvars)];

    order=sortrows(lambda,-1);      %sort eigenvalues in descending order
    Vord=[];
    for i=1:nvars
        Vord=[Vord V(:,order(i,2))];    %reorder eigenvector according to ordered
    end                                 %eigenvalues
    V=Vord;


elseif shock_extract==2  %Freq. domain target


    freq_uc  = [KLbar, KUbar]  ; %unconditional variances  %Rosen edit to standardize notation

    %Do PCA on S
    [tmp1,S] = vdfilter_rp(B,C,term_rer,freq_uc);
    %[tmp1,S] = vdfilter_rp(B,C,term_deltaq,freq_uc);
    %[tmp1,S] = vdfilter_rp(B,C,term_expexret,freq_uc);
    [q1,D]  = eig(S(1:end,1:end));                                          %Get eigenstuffs
    [~,idx] = sort(diag(D), 'descend');                                     %Get order of eigenvalues
    V      = q1(:,idx);                    %Re-order eigenvectors in descending order of eigenvalues

elseif shock_extract==3    %News shock ID

    % compute VMA coeffs Bi
    ei = zeros(nvars*nlags,1);
    ei(1) = 1;      %selection matrix; TFP needs to be ordered first in VAR

    Rtilde = zeros(1,nvars,KUbar+1);
    for l=0:KUbar
        B_l=B^l;
        Rtilde(:,:,l+1) = ei'*B_l*C; % Bi are VMA coeffs on how ith variable responds to different shocks l+1 periods back
    end

    %compute V
    S = zeros(nvars,nvars);
    for l=0:KUbar
        S = S + (KUbar+1-max(KLbar,l))*Rtilde(:,:,l+1)'*Rtilde(:,:,l+1);
    end
    [V,D]=eig(S(2:nvars,2:nvars));               %eigenvectors have norm=1
    lambda=[diag(D) seqa(1,1,nvars-1)];
    order=sortrows(lambda,-1);     %sort eigenvalues in descending order
    Vord=[];
    for i=1:nvars-1
        Vord=[Vord V(:,order(i,2))];    %reorder eigenvector according to ordered
    end                                 %eigenvalues
    Vord  = [1,zeros(1,nvars-1);[zeros(nvars-1,1),Vord]]; %Right now surprise is first, news is second

    V = [Vord(:,2),Vord(:,[1,3:end])];  %Put news first

elseif shock_extract == 4   %%% Cholesky shock to TFP
    V = eye(nvars);
else
    error('Invalid ID selection.')
end

% Compute impulse responses with correct rotation
%----------------------------------------------------------------------  
U = [Atilde*V;zeros(nvars*(nlags-1),nvars)];

% Zk1/Tk1 columns are A's rows -- every manifest series, data then constructed --
% NOT the spec's VAR variables, and NOT the order in any legacy comment. Address
% them through the row terms gen_auxvars returns, never by number.
Zk1 = NaN(nimp,size(A,1));
Tk1 = NaN(nimp,nvars,size(A,1));
for k=1:nimp
    Zk1(k,:)  =(A*B^(k-1)*U(:,1))';
    Tk1(k,:,:)=(A*B^(k-1)*U     )';
end

impulse1=Zk1;   %nimp x nvars impulse response matrix to 1st shock
%impulse1(:,18) =-cumsum(Zk1(:,18),1); %this is used to compute cumsum of excess returns

%- Rotation condition. The eigenvector fixes the shock only up to sign, so pin it
%  by requiring the NOMINAL exchange rate to depreciate on impact.
%
%  NOMINAL, DELIBERATELY. The objective above maximises the variance share of the
%  REAL exchange rate, so pinning on term_rer would be the tidier-looking choice
%  -- but it is a different convention and would move every published max-share
%  exhibit, not just the augmented ones. The rule is the paper's; only its
%  addressing is fixed here.
%
%  BY NAME. This was Zk1(1,4). Column 4 of Zk1 is the 4th row of A, which is the
%  4th manifest row, which is ner today -- correct by coincidence of ordering,
%  and silently wrong the moment the manifest gains a row before it. rowkeys
%  names every row of A, so this selects ner whatever the layout, and says so if
%  it ever disappears.
iNER = find(strcmp(rowkeys, 'ner'));
assert(isscalar(iNER), 'maxshr:noNER', ...
    ['the rotation condition needs the nominal exchange rate; ' ...
     '''ner'' matches %d rows of A.'], numel(iNER));
if Zk1(1,iNER) > 0
    impulse1 = -impulse1;
end

%-----------------------------------------------------------------------
% Compute fraction of VD explained at different horizons
%-----------------------------------------------------------------------
vardec= cumsum(Zk1(:,:).^2)./cumsum(squeeze(sum(Tk1.^2,2)));
output=[vardec impulse1];

%-----------------------------------------------------------------------
% Compute fraction over frequency range
%-----------------------------------------------------------------------
targ = zeros(1,nvars); targ(1,1) = 1;
vardec_unc = NaN(size(A,1),size(vd_fr,1));
for i = 1:size(vd_fr,1)
    [Vy,Ve] = vdfilter(B,U,targ,vd_fr(i,:),A);
    vardec_unc(:,i) = diag(Ve)./diag(Vy);
end



