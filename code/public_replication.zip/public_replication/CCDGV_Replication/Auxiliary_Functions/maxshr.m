function [output, V, vardec_unc]=maxshr(b,vmat,nvars,nlags,KLbar,KUbar,nimp,vd_fr,j_cj_horizon,shock_extract,Aproj,keys)
%MAXSHR  Max-share identification for one VAR draw.
%
%   [output, V, vardec_unc] = maxshr(b, vmat, nvars, nlags, KLbar, KUbar, nimp, ...
%                                    vd_fr, j_cj_horizon, shock_extract, Aproj, keys)
%
%   b, vmat       AR block (AR') and innovation covariance of the draw.
%   nvars, nlags  VAR dimensions.
%   KLbar, KUbar  bounds of the target: horizons for shock_extract = 1 and 3,
%                 angular frequencies for shock_extract = 2.
%   nimp          impulse-response horizon.
%   vd_fr         frequency bands for vardec_unc, one row [lo hi] each.
%   j_cj_horizon  passed to GEN_AUXVARS.
%   shock_extract 1 = maximise the FEV share of the real exchange rate,
%                 2 = maximise its variance share over a frequency band,
%                 3 = news shock to TFP, 4 = Cholesky shock to TFP.
%   Aproj, keys   the projected data series and their keys (see GEN_AUXVARS).
%
%   output      nimp x 2*nrows: [FEV shares of the first shock, its impulse
%               responses], one column per row of A.
%   V           rotation matrix; the identified shock is its first column.
%   vardec_unc  nrows x size(vd_fr,1), the first shock's variance share in each
%               frequency band.
%
%   Rows of A are addressed by key, through the outputs of GEN_AUXVARS.
%
%   See also GEN_AUXVARS, VDFILTER, VDFILTER_RP, GENMAXSHARE_FINAL.

% Companion matrix B and the rows A of every series.
[A,B,term_rer,term_deltaq,term_expexret,ia1,~,rowkeys] = gen_auxvars(b,Aproj,keys,nvars,nlags,j_cj_horizon);

% Lower-triangular Cholesky factor of vmat.
Atilde = chol(vmat)';

% Impact matrix of the companion system.
C = zeros(size(B,1),nvars);
C(1:nvars, 1:nvars) = Atilde;

if shock_extract == 1  % FEV target

    % Response of the real exchange rate to each shock at each horizon l.
    Rtilde=zeros(1,nvars,KUbar+1);
    for l=0:KUbar
        B_l=B^l;
        Rtilde(:,:,l+1)=term_rer*B_l*C;
    end

    % Weighted sum of outer products.
    S=zeros(nvars,nvars);
    for l=0:KUbar
        S=S+(KUbar+1-max(KLbar,l))*Rtilde(:,:,l+1)'*Rtilde(:,:,l+1);
    end

    [V,D]=eig(S);
    lambda=[diag(D) seqa(1,1,nvars)];

    order=sortrows(lambda,-1);      % sort eigenvalues in descending order
    Vord=[];
    for i=1:nvars
        Vord=[Vord V(:,order(i,2))];    % reorder the eigenvectors to match
    end
    V=Vord;


elseif shock_extract==2  % frequency-domain target


    freq_uc  = [KLbar, KUbar]  ; % target band

    % Eigenvectors of the real exchange rate's band covariance, by descending
    % eigenvalue.
    [tmp1,S] = vdfilter_rp(B,C,term_rer,freq_uc);
    [q1,D]  = eig(S(1:end,1:end));
    [~,idx] = sort(diag(D), 'descend');
    V      = q1(:,idx);

elseif shock_extract==3    % news shock

    % Response of TFP to each shock at each horizon l.
    ei = zeros(nvars*nlags,1);
    ei(1) = 1;      % selects TFP, which must be first in the VAR

    Rtilde = zeros(1,nvars,KUbar+1);
    for l=0:KUbar
        B_l=B^l;
        Rtilde(:,:,l+1) = ei'*B_l*C;
    end

    % Weighted sum of outer products; eigenvectors of the block that excludes
    % the first shock.
    S = zeros(nvars,nvars);
    for l=0:KUbar
        S = S + (KUbar+1-max(KLbar,l))*Rtilde(:,:,l+1)'*Rtilde(:,:,l+1);
    end
    [V,D]=eig(S(2:nvars,2:nvars));
    lambda=[diag(D) seqa(1,1,nvars-1)];
    order=sortrows(lambda,-1);     % sort eigenvalues in descending order
    Vord=[];
    for i=1:nvars-1
        Vord=[Vord V(:,order(i,2))];    % reorder the eigenvectors to match
    end
    Vord  = [1,zeros(1,nvars-1);[zeros(nvars-1,1),Vord]]; % surprise shock first, news second

    V = [Vord(:,2),Vord(:,[1,3:end])];  % put news first

elseif shock_extract == 4   % Cholesky shock to TFP
    V = eye(nvars);
else
    error('Invalid ID selection.')
end

% Impulse responses under the rotation V.
U = [Atilde*V;zeros(nvars*(nlags-1),nvars)];

% Columns of Zk1 and Tk1 are the rows of A: every manifest series, data then
% constructed. Zk1 is the response to the first shock, Tk1 to every shock.
Zk1 = NaN(nimp,size(A,1));
Tk1 = NaN(nimp,nvars,size(A,1));
for k=1:nimp
    Zk1(k,:)  =(A*B^(k-1)*U(:,1))';
    Tk1(k,:,:)=(A*B^(k-1)*U     )';
end

impulse1=Zk1;   % responses to the first shock

% Sign. The eigenvector is determined only up to sign; flip the responses so
% that the nominal exchange rate (ner) does not rise on impact.
iNER = find(strcmp(rowkeys, 'ner'));
assert(isscalar(iNER), 'maxshr:noNER', ...
    ['the rotation condition needs the nominal exchange rate; ' ...
     '''ner'' matches %d rows of A.'], numel(iNER));
if Zk1(1,iNER) > 0
    impulse1 = -impulse1;
end

% Share of each row's forecast-error variance due to the first shock, by horizon.
vardec= cumsum(Zk1(:,:).^2)./cumsum(squeeze(sum(Tk1.^2,2)));
output=[vardec impulse1];

% Share of each row's variance due to the first shock, over each frequency band.
targ = zeros(1,nvars); targ(1,1) = 1;  % vdfilter's targ selects the first shock
vardec_unc = NaN(size(A,1),size(vd_fr,1));
for i = 1:size(vd_fr,1)
    [Vy,Ve] = vdfilter(B,U,targ,vd_fr(i,:),A);
    vardec_unc(:,i) = diag(Ve)./diag(Vy);
end



