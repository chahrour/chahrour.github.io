function R = genmaxshare_final(ARs, Sigs, Res, cfg)
%GENMAXSHARE_FINAL  Max-share identification of the main exchange rate shock,
%                   applied to a set of posterior VAR draws.
%
%   R = GENMAXSHARE_FINAL(ARs, Sigs, Res, CFG)
%
%   Same arithmetic as the script it replaced, with no dead code and callable more
%   than once per run -- which is the point: Tables 1, B.4 and B.5 are the SAME
%   draws under three identification targets.
%
%     Table 1    shock_extract=1, KLbar=KUbar=100        FEV at horizon 100
%     Table B.4  shock_extract=2, [2*pi/1000, 2*pi/2]    2-1000 quarter periods
%     Table B.5  shock_extract=2, [2*pi/32,   2*pi/6]    6-32 quarter periods
%
%   Nothing in the repository had ever set shock_extract=2 -- run_main:83
%   hard-codes 1 -- so B.1/B.2 were unreachable despite the machinery for them
%   being present in maxshr:42-48. It was a missing caller, not a missing
%   generator.
%
%   INPUTS
%     ARs, Sigs, Res  cell arrays of posterior draws from genvars. Element
%                     ndraws+1 is the point estimate. Previously read via a
%                     hard-coded `load vars` -- scratch that every run_main
%                     overwrites; now passed in, so the caller controls (and can
%                     prove) which draws were used.
%     CFG             struct, see below.
%
%   CFG FIELDS
%     shock_extract   1 FEV target | 2 frequency-domain target (see maxshr)
%     KLbar, KUbar    the target bounds. For shock_extract=2 these are ANGULAR
%                     FREQUENCIES (2*pi/period), not horizons.
%     nimp            impulse horizon computed (600)
%     vd_fr           frequency bands for the REPORTED decomposition. Distinct
%                     from KLbar/KUbar, which set the identification target --
%                     an easy pair to conflate.
%     j_cj_horizon          passed through to maxshr/gen_auxvars
%     Aproj, keys           the projected series and their names
%     bound, bound2   band quantiles (0.16 -> 68%, 0.10 -> 80%)
%     point_estimate  0 median across draws | 1 use draw ndraws+1
%     nvnames         numel(vnames); sizes the two-block output
%     want_vardec_fd  default TRUE. Decides whether the frequency-band shares are
%                     RETURNED, not whether they are computed: maxshr runs its
%                     vdfilter loop for every row of cfg.vd_fr with no nargout
%                     guard, so an appendix pass that sets this false still pays
%                     for them and simply drops the result. Tables 1/B.1/B.2 show
%                     only the Q1-Q100 FEV columns, which come from the OTHER
%                     output block. Skipping the cost would mean passing vd_fr
%                     empty, which no caller does.
%     want_shocks     default FALSE. The historical shock series. The original
%                     computed this for every draw -- a chol plus an explicit
%                     inv() per draw -- and then saved and used neither. It is
%                     what Figure B.11 plots, so it is preserved as an option
%                     rather than deleted.
%     label           free-text tag echoed into R.cfg for provenance.
%
%   OUTPUT R
%     dataplots   nimp x 2*nvnames x 5. Columns 1..nvnames are FEV shares by
%                 horizon, nvnames+1..2*nvnames are impulse responses -- the
%                 two-block convention, set at maxshr:115 (`output = [vardec
%                 impulse1]`). Pages: 1 point estimate, 2/3 inner band, 4/5 outer.
%     vardec_fd   nvnames x size(vd_fr,1) x ndraws, or [] if not requested.
%     ndraws, nvars, nlags   DERIVED here and RETURNED. The original overwrote
%                 the caller's copies of all three (and confidence_bands) in
%                 place, so run_main's ndraws silently became whatever vars.mat
%                 happened to hold.
%     shocks, shock_med   present only when want_shocks.
%     cfg         the resolved config, echoed.
%
%   See also MAXSHR.

    D = struct('shock_extract',1, 'KLbar',100, 'KUbar',100, 'nimp',600, ...
               'vd_fr',[], 'j_cj_horizon',20, ...
               'bound',0.16, 'bound2',0.10, 'point_estimate',0, ...
               'nvnames',[], 'want_vardec_fd',true, 'want_shocks',false, ...
               'want_draws',false, 'label','', 'Aproj',[], 'keys',{{}});

    bad = setdiff(fieldnames(cfg), fieldnames(D));
    if ~isempty(bad)
        error('genmaxshare_final:unknownCfg','Unknown cfg field(s): %s. Valid: %s.', ...
              strjoin(bad(:)',', '), strjoin(fieldnames(D)',', '));
    end
    for f = fieldnames(D)'
        if ~isfield(cfg,f{1}) || isempty(cfg.(f{1}))
            if isempty(D.(f{1})) && ismember(f{1},{'vd_fr','nvnames'})
                error('genmaxshare_final:missingCfg','cfg.%s is required.', f{1});
            end
            cfg.(f{1}) = D.(f{1});
        end
    end

    ndraws = numel(ARs) - 1;          % element ndraws+1 is the point estimate
    nvars  = size(ARs{1},1);
    nlags  = size(ARs{1},2)/nvars;
    nv     = cfg.nvnames;

    dataplots = NaN(cfg.nimp, 2*nv, 5);
    if cfg.want_vardec_fd
        vardec_fd = NaN(nv, size(cfg.vd_fr,1), ndraws);
    else
        vardec_fd = [];
    end
    % cfg.Aproj may be 3-D (run_main's Aproj_draw: one page per draw, the last
    % page the posterior mean) or 2-D (the point-estimate first stage). min(j,end)
    % reads the right page either way -- and NO alias is kept, because cfg is
    % saved into id_meta and a second copy of the pages costs ~5.6 MB per pass.
    datadraws = NaN(cfg.nimp, 2*nv, ndraws);
    if cfg.want_shocks
        shocks = NaN(size(Res{1},1), ndraws);
    else
        shocks = [];
    end

    % PARFOR OVER DRAWS. Each iteration reads ARs{j}, Sigs{j} and Res{j} and writes
    % only page j of datadraws, vardec_fd and shocks, so there is no state carried
    % between iterations. Nothing in maxshr's call tree draws a random number --
    % maxshr, gen_auxvars, vdfilter, vdfilter_rp and companion_form are all
    % RNG-free -- so the result does not depend on the order iterations finish in.
    % Verified bit-for-bit against the serial loop before the change was kept:
    % at 200 draws on four workers, every output field identical to the last bit
    % (dataplots, vardec_fd, shocks, shock_med), 11.9 s serial against 4.7 s.
    %
    % The two outputs are allocated and assigned UNCONDITIONALLY, and nulled after
    % the loop if unwanted. parfor cannot classify a sliced variable that only some
    % iterations assign, and the arrays are small -- under 1 MB each at 1000 draws.
    % Asking maxshr for its third output costs nothing: it computes the band shares
    % whether or not they are requested.
    vardec_all = NaN(nv, size(cfg.vd_fr,1), ndraws);
    shocks_all = NaN(size(Res{1},1), ndraws);
    KL = cfg.KLbar;  KU = cfg.KUbar;  nimp = cfg.nimp;  vdfr = cfg.vd_fr;
    jcj = cfg.j_cj_horizon;  sx = cfg.shock_extract;  Ap = cfg.Aproj;  ky = cfg.keys;

    parfor j = 1:ndraws
        bdraw    = ARs{j}';
        vmatdraw = Sigs{j};

        [dd, V, vd] = maxshr(bdraw, vmatdraw, nvars, nlags, KL, KU, nimp, vdfr, ...
                             jcj, sx, Ap(:,:,min(j,end)), ky);

        datadraws(:,:,j) = dd;
        vardec_all(:,:,j) = vd;

        % Atilde\ rather than inv(Atilde)* -- same answer, no explicit inverse.
        Atilde = chol(vmatdraw)';
        shocks_all(:,j) = ((V(:,1)' / Atilde) * Res{j}')';
    end

    if cfg.want_vardec_fd; vardec_fd(:,:,1:ndraws) = vardec_all; end
    if cfg.want_shocks;    shocks = shocks_all;                  end
    clear vardec_all shocks_all

    % want_draws keeps the per-draw shares BEFORE the sort below, which destroys
    % the draw identity (it sorts each cell independently). Only a caller that
    % needs to pair a draw's share with something else of that same draw wants
    % this; it is nimp x 2*nv x ndraws, so it is off by default.
    if cfg.want_draws; draws_out = datadraws; end

    % Bands. Quantiles are taken by SORTING and indexing, exactly as the original
    % did -- not via quantile() -- so the regression test can be exact.
    datadraws = sort(datadraws, 3);
    low   = max(round(ndraws*cfg.bound),1);    high  = round(ndraws*(1-cfg.bound));
    low2  = max(round(ndraws*cfg.bound2),1);   high2 = round(ndraws*(1-cfg.bound2));

    if cfg.point_estimate == 0
        dataplots(:,:,1) = median(datadraws, 3);
    else
        if cfg.want_vardec_fd
            [dp_pt, ~, vardec_fd(:,:,ndraws+1)] = maxshr(ARs{ndraws+1}', ...
                Sigs{ndraws+1}, nvars, nlags, cfg.KLbar, cfg.KUbar, cfg.nimp, ...
                cfg.vd_fr, cfg.j_cj_horizon, cfg.shock_extract, cfg.Aproj(:,:,end), cfg.keys);
        else
            dp_pt = maxshr(ARs{ndraws+1}', Sigs{ndraws+1}, nvars, nlags, ...
                cfg.KLbar, cfg.KUbar, cfg.nimp, cfg.vd_fr, cfg.j_cj_horizon, ...
                cfg.shock_extract, cfg.Aproj(:,:,end), cfg.keys);
        end
        dataplots(:,:,1) = dp_pt;
    end

    dataplots(:,:,2) = datadraws(:,:,low);
    dataplots(:,:,3) = datadraws(:,:,high);
    dataplots(:,:,4) = datadraws(:,:,low2);
    dataplots(:,:,5) = datadraws(:,:,high2);

    R = struct('dataplots',dataplots, 'vardec_fd',vardec_fd, ...
               'ndraws',ndraws, 'nvars',nvars, 'nlags',nlags, 'cfg',cfg_light(cfg));
    if cfg.want_draws; R.datadraws = draws_out; end
    if cfg.want_shocks
        R.shocks    = shocks;
        R.shock_med = median(shocks, 2);
    end
end

function c = cfg_light(cfg)
%CFG_LIGHT  cfg as saved provenance: ext replaced by the keys it projected.
%   ext carries the whole data matrix, and cfg is stored three times in
%   id_meta. Keep the fact of the projection, drop the payload.
    c = cfg;
    % Aproj is 3-D when the first stage is drawn (one page per draw), ~5.6 MB at
    % 1000 draws, and cfg is stored three times in id_meta. Keep its shape, drop
    % the payload -- same reasoning as ext below.
    if isfield(c,'Aproj') && ndims(c.Aproj) == 3
        c.Aproj = sprintf('%s (drawn first stage, not stored)', mat2str(size(c.Aproj)));
    end
    if isfield(c,'ext')
        if isstruct(c.ext) && isfield(c.ext,'series')
            c.ext = strjoin(fieldnames(c.ext.series)', ',');
        else
            c.ext = '';
        end
    end
end
