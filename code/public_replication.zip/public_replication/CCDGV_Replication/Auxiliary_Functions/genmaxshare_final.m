function R = genmaxshare_final(ARs, Sigs, Res, cfg)
%GENMAXSHARE_FINAL  Max-share identification of the main exchange-rate shock,
%                   applied to a set of posterior VAR draws.
%
%   R = genmaxshare_final(ARs, Sigs, Res, cfg)
%
%   ARs, Sigs, Res  cell arrays of posterior draws from GENVARS; element
%                   ndraws+1 is the point estimate.
%   cfg             struct of settings, built by ID_CFG:
%     shock_extract   1 = forecast-error-variance target, 2 = frequency-domain
%                     target (see MAXSHR). Default 1.
%     KLbar, KUbar    bounds of the target: horizons for shock_extract = 1,
%                     angular frequencies (2*pi/period) for shock_extract = 2.
%     nimp            impulse-response horizon (default 600).
%     vd_fr           frequency bands of the reported decomposition, one row
%                     [lo hi] each. Required.
%     j_cj_horizon    passed to MAXSHR and GEN_AUXVARS.
%     Aproj, keys     the projected series and their keys. Aproj is 2-D, or
%                     3-D with one page per draw and the posterior mean last.
%     bound, bound2   band quantiles (0.16 gives a 68% band, 0.10 an 80% band).
%     point_estimate  0 = median across draws, 1 = draw ndraws+1.
%     nvnames         number of rows of A. Required.
%     want_vardec_fd  return the frequency-band shares (default true). MAXSHR
%                     computes them either way.
%     want_shocks     return each draw's shock series (default false).
%     want_draws      return the unsorted per-draw output (default false).
%     label           free-text tag stored in R.cfg.
%
%   R.dataplots   nimp x 2*nvnames x 5. Columns 1..nvnames are FEV shares by
%                 horizon and nvnames+1..2*nvnames are impulse responses.
%                 Pages: 1 point estimate, 2/3 inner band, 4/5 outer band.
%   R.vardec_fd   nvnames x size(vd_fr,1) x ndraws, or [].
%   R.ndraws, R.nvars, R.nlags   dimensions, read off ARs.
%   R.shocks, R.shock_med   only with want_shocks.
%   R.datadraws   only with want_draws.
%   R.cfg         the settings used, without the Aproj pages.
%
%   The three identification passes of a run are
%     Table 1    shock_extract=1, KLbar=KUbar=100        FEV at horizon 100
%     Table C.4  shock_extract=2, [2*pi/1000, 2*pi/2]    2-1000 quarter periods
%     Table C.5  shock_extract=2, [2*pi/32,   2*pi/6]    6-32 quarter periods
%
%   See also MAXSHR, ID_CFG.

    % Defaults. Unknown fields are an error; vd_fr and nvnames are required.
    D = struct('shock_extract',1, 'KLbar',100, 'KUbar',100, 'nimp',600, ...
               'vd_fr',[], 'j_cj_horizon',20, ...
               'bound',0.16, 'bound2',0.10, 'point_estimate',0, ...
               'nvnames',[], 'want_vardec_fd',true, 'want_shocks',false, ...
               'want_draws',false, 'label','', 'Aproj',[], 'keys',{{}});

    bad = setdiff(fieldnames(cfg), fieldnames(D));
    if ~isempty(bad)
        error('genmaxshare_final:unknownCfg','Unknown cfg field(s): %s. Valid: %s.', ...
              strjoin(bad(:)',', '), strjoin(fieldnames(D)',', '));
    end
    for f = fieldnames(D)'
        if ~isfield(cfg,f{1}) || isempty(cfg.(f{1}))
            if isempty(D.(f{1})) && ismember(f{1},{'vd_fr','nvnames'})
                error('genmaxshare_final:missingCfg','cfg.%s is required.', f{1});
            end
            cfg.(f{1}) = D.(f{1});
        end
    end

    ndraws = numel(ARs) - 1;          % element ndraws+1 is the point estimate
    nvars  = size(ARs{1},1);
    nlags  = size(ARs{1},2)/nvars;
    nv     = cfg.nvnames;

    % Output arrays.
    dataplots = NaN(cfg.nimp, 2*nv, 5);
    if cfg.want_vardec_fd
        vardec_fd = NaN(nv, size(cfg.vd_fr,1), ndraws);
    else
        vardec_fd = [];
    end
    datadraws = NaN(cfg.nimp, 2*nv, ndraws);
    if cfg.want_shocks
        shocks = NaN(size(Res{1},1), ndraws);
    else
        shocks = [];
    end

    % Identify each draw. Iterations are independent and use no random numbers.
    % vardec_all and shocks_all are assigned on every iteration, as parfor
    % requires of sliced outputs, and kept or dropped after the loop.
    % cfg.Aproj may be 2-D or 3-D; Ap(:,:,min(j,end)) reads the right page.
    vardec_all = NaN(nv, size(cfg.vd_fr,1), ndraws);
    shocks_all = NaN(size(Res{1},1), ndraws);
    KL = cfg.KLbar;  KU = cfg.KUbar;  nimp = cfg.nimp;  vdfr = cfg.vd_fr;
    jcj = cfg.j_cj_horizon;  sx = cfg.shock_extract;  Ap = cfg.Aproj;  ky = cfg.keys;

    parfor j = 1:ndraws
        bdraw    = ARs{j}';
        vmatdraw = Sigs{j};

        [dd, V, vd] = maxshr(bdraw, vmatdraw, nvars, nlags, KL, KU, nimp, vdfr, ...
                             jcj, sx, Ap(:,:,min(j,end)), ky);

        datadraws(:,:,j) = dd;
        vardec_all(:,:,j) = vd;

        % Shock series of this draw: the first rotated innovation.
        Atilde = chol(vmatdraw)';
        shocks_all(:,j) = ((V(:,1)' / Atilde) * Res{j}')';
    end

    if cfg.want_vardec_fd; vardec_fd(:,:,1:ndraws) = vardec_all; end
    if cfg.want_shocks;    shocks = shocks_all;                  end
    clear vardec_all shocks_all

    % Keep the per-draw output before the sort below, which sorts each cell
    % independently and so loses the draw identity.
    if cfg.want_draws; draws_out = datadraws; end

    % Bands: sort across draws and index the quantiles.
    datadraws = sort(datadraws, 3);
    low   = max(round(ndraws*cfg.bound),1);    high  = round(ndraws*(1-cfg.bound));
    low2  = max(round(ndraws*cfg.bound2),1);   high2 = round(ndraws*(1-cfg.bound2));

    % Point estimate: the median, or the identification at draw ndraws+1.
    if cfg.point_estimate == 0
        dataplots(:,:,1) = median(datadraws, 3);
    else
        if cfg.want_vardec_fd
            [dp_pt, ~, vardec_fd(:,:,ndraws+1)] = maxshr(ARs{ndraws+1}', ...
                Sigs{ndraws+1}, nvars, nlags, cfg.KLbar, cfg.KUbar, cfg.nimp, ...
                cfg.vd_fr, cfg.j_cj_horizon, cfg.shock_extract, cfg.Aproj(:,:,end), cfg.keys);
        else
            dp_pt = maxshr(ARs{ndraws+1}', Sigs{ndraws+1}, nvars, nlags, ...
                cfg.KLbar, cfg.KUbar, cfg.nimp, cfg.vd_fr, cfg.j_cj_horizon, ...
                cfg.shock_extract, cfg.Aproj(:,:,end), cfg.keys);
        end
        dataplots(:,:,1) = dp_pt;
    end

    dataplots(:,:,2) = datadraws(:,:,low);
    dataplots(:,:,3) = datadraws(:,:,high);
    dataplots(:,:,4) = datadraws(:,:,low2);
    dataplots(:,:,5) = datadraws(:,:,high2);

    R = struct('dataplots',dataplots, 'vardec_fd',vardec_fd, ...
               'ndraws',ndraws, 'nvars',nvars, 'nlags',nlags, 'cfg',cfg_light(cfg));
    if cfg.want_draws; R.datadraws = draws_out; end
    if cfg.want_shocks
        R.shocks    = shocks;
        R.shock_med = median(shocks, 2);
    end
end

function c = cfg_light(cfg)
%CFG_LIGHT  cfg for storage, with large payloads replaced by a description.
    c = cfg;
    % A 3-D Aproj is replaced by its size.
    if isfield(c,'Aproj') && ndims(c.Aproj) == 3
        c.Aproj = sprintf('%s (drawn first stage, not stored)', mat2str(size(c.Aproj)));
    end
    % ext is replaced by the names of its series.
    if isfield(c,'ext')
        if isstruct(c.ext) && isfield(c.ext,'series')
            c.ext = strjoin(fieldnames(c.ext.series)', ',');
        else
            c.ext = '';
        end
    end
end
