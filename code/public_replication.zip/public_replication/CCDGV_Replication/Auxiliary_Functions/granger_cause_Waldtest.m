function [pValue, stat] = granger_cause_Waldtest(x,y,max_lag,varargin)
%GRANGER_CAUSE_WALDTEST  Wald test of whether y Granger-causes x.
%
%   [pValue, stat] = granger_cause_Waldtest(x, y, max_lag, Name, Value, ...)
%
%   x, y     series of equal length.
%   max_lag  number of lags of each series in the regression for x.
%   'Differencing'    'Quarterly' (lags 1..max_lag, the default) or 'Annual'
%                     (lags 4, 8, ..., 4*max_lag).
%   'HAC'             'NW' (HAC covariance from MYHAC, the default) or
%                     'Classic' (homoskedastic OLS covariance).
%   'CriticalValues'  'Standard' (chi-squared, the default) or 'KVB' (Kiefer,
%                     Vogelsang and Bunzel (2000) fixed-b critical values, with
%                     bandwidth equal to the sample size).
%
%   pValue   p-value of the hypothesis that every lag of y has a zero coefficient.
%   stat     the Wald statistic.
%
%   See also MYHAC.

ip = inputParser;
addRequired(ip, 'x', @isnumeric);
addRequired(ip, 'y', @isnumeric);
addRequired(ip, 'max_lag', @isnumeric);

addParameter(ip, 'Differencing', 'Quarterly', ...
    @(s) any(validatestring(s, {'Annual', 'Quarterly'})));
addParameter(ip, 'HAC', 'NW', ...
    @(s) any(validatestring(s, {'NW', 'Classic'})));
addParameter(ip, 'CriticalValues', 'Standard', ...
    @(s) any(validatestring(s, {'Standard', 'KVB'})));

parse(ip,x,y,max_lag,varargin{:});

differencingOption = ip.Results.Differencing;
estimatorOption = ip.Results.HAC;
cvalueOption = ip.Results.CriticalValues;

% Check the inputs.
if (length(x) ~= length(y))
    error('x and y must be the same length');
end

% Column vectors.
x = x(:);
y = y(:);

if max_lag < 1
    error('max_lag must be greater than or equal to one');
end

% Lags of x and y.
if strcmp(differencingOption, 'Annual')
    X_lags = lagmatrix(x,4:4:max_lag*4);
    Y_lags = lagmatrix(y,4:4:max_lag*4);

elseif strcmp(differencingOption, 'Quarterly')
    X_lags = lagmatrix(x,1:max_lag);
    Y_lags = lagmatrix(y,1:max_lag);
end

% Keep the rows where x and every lag are observed.
valid_rows = all(~isnan(X_lags), 2) & all(~isnan(Y_lags), 2) & all(~isnan(x), 2);
X_lags = X_lags(valid_rows, :);
Y_lags = Y_lags(valid_rows, :);
Y = x(valid_rows);

% Regressors: constant, lags of x, lags of y.
XX = [ones(size(X_lags,1),1), X_lags, Y_lags];

% Coefficients and their covariance matrix.
if strcmp(estimatorOption, 'NW')
    if strcmp(cvalueOption, 'Standard')
        [cov_beta,~,b] = myhac(XX,Y,'Intercept',false,'Display','off', 'Bandwidth','AR1OLS','Whiten',1);
        
    elseif strcmp(cvalueOption,'KVB')
        [cov_beta,~,b] = myhac(XX,Y,'Intercept',false,'Type', 'HAC','Display','off', 'Bandwidth',size(Y,1),'Whiten',0); % fixed-b: bandwidth equal to the sample size
    end
elseif strcmp(estimatorOption, 'Classic')
    b = XX\Y;
    sigma2_hat = (Y-XX*b)'*(Y-XX*b)/(size(Y,1) - size(XX,2));
    cov_beta = sigma2_hat * inv(XX' * XX);
end


% Coefficients on the lags of y, and their covariance block.
ind = size(X_lags,2) + 2:size(XX,2);
cov_cut = cov_beta(ind,ind);
coeff_cut = b(ind);

df1 = numel(coeff_cut);

% Wald statistic, using the Cholesky factor of the covariance block.
[CovARChol,flag] = chol(cov_cut,'lower');
if flag > 0
    cov_cut = cov_cut + 1e-8 * eye(size(cov_cut),'like',cov_cut);
    CovARChol = chol(cov_cut,'lower');
end
normalRV = CovARChol \ coeff_cut;
normalRV2 = normalRV.' * normalRV;

stat = normalRV2;
if strcmp(cvalueOption,'Standard')
    pValue = 1- chi2cdf(normalRV2,df1);
elseif strcmp(cvalueOption,'KVB')
    Fstar = (1 / df1) * normalRV2; 
    pValue = fixedb_critical_value(Fstar, df1);
end

    function p_value = fixedb_critical_value(Fstar, q)
        % Approximate p-value of F* under Kiefer-Vogelsang-Bunzel (2000) fixed-b
        % asymptotics, by interpolation in their Table II.
        %   Fstar  the Wald statistic divided by q
        %   q      number of restrictions, 1 to 30

        % Critical values from Table II of Kiefer, Vogelsang and Bunzel (2000).
        % Rows: q = 1 to 30. Columns: 90%, 95%, 97.5%, 99%.
        crit_table = [...
            28.88, 46.39, 65.94, 101.2;
            35.68, 51.41, 69.76, 96.82;
            42.39, 58.17, 76.07, 100.7;
            48.79, 65.33, 83.35, 108.4;
            55.02, 71.69, 89.65, 114.2;
            61.18, 78.70, 96.53, 121.2;
            67.37, 84.63, 102.7, 126.9;
            73.10, 90.89, 109.8, 134.4;
            78.52, 96.38, 114.2, 139.6;
            83.84, 101.8, 120.0, 144.9;
            89.39, 107.7, 127.2, 152.6;
            94.47, 113.6, 132.9, 157.8;
            100.1, 119.9, 138.8, 163.8;
            105.3, 125.5, 145.2, 169.7;
            110.3, 131.5, 151.0, 174.7;
            115.5, 136.6, 155.9, 181.6;
            121.2, 141.4, 161.1, 188.8;
            126.6, 147.1, 167.6, 194.8;
            131.5, 152.9, 174.0, 203.2;
            136.5, 158.0, 179.8, 208.5;
            141.9, 163.6, 186.0, 214.0;
            146.6, 169.3, 191.2, 219.3;
            152.1, 174.7, 197.0, 224.6;
            157.0, 180.3, 202.3, 230.1;
            161.8, 184.9, 207.5, 236.3;
            167.2, 190.7, 213.3, 242.4;
            171.6, 196.0, 218.9, 246.9;
            177.0, 201.5, 224.4, 252.9;
            181.6, 206.4, 229.1, 259.8;
            187.0, 211.4, 236.0, 266.3
            ];

        % Significance levels of the columns.
        p_levels = [0.10, 0.05, 0.025, 0.01];

        % q must be in the tabulated range.
        if q < 1 || q > 30
            error('Currently only 1 <= q <= 30 supported. Extend the crit_table manually if needed.');
        end

        crit_vals = crit_table(q, :);

        % Interpolate between the tabulated critical values.
        cv = crit_vals;
       
        if Fstar < cv(1)
            p_value = 1.0;
        elseif Fstar > cv(end)
            p_value = 0.005; % below the smallest tabulated level
        else
            p_value = interp1(cv, p_levels, Fstar, 'linear', 'extrap');
        end

    end

end