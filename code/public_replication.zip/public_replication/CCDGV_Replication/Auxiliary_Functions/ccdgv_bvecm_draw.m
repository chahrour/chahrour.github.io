function [AR, Sig, res, maxeig] = ccdgv_bvecm_draw(J, D, iperm, rho)
%CCDGV_BVECM_DRAW  Convert one Villani posterior draw to a levels VAR in spec order.
%
%   [AR, Sig, res, maxeig] = ccdgv_bvecm_draw(J, D, iperm, rho)
%
%   J      one joint draw from draw_joint (alpha, beta, Gammas, Sigma, Psi), in
%          estimation order.
%   D      data struct from vecm_data, without dummy rows; used for the residuals.
%   iperm  iperm(j) is the estimation-order position of spec variable j.
%   rho    damping: A_j -> rho^j A_j, which puts the p - r unit roots at rho.
%
%   AR     p x p*k levels AR block in spec order, damped.
%   Sig    p x p innovation covariance in spec order.
%   res    T x p residuals, columns in spec order.
%   maxeig largest eigenvalue modulus of the damped companion matrix.
%
%   See also CCDGV_BVECM.

    p = size(J.alpha, 1);  k = numel(J.Gammas) + 1;
    F = companion(J.alpha, J.beta, J.Gammas);        % levels VAR(k), estimation order
    AR = zeros(p, p*k);
    for j = 1:k
        AR(:, (j-1)*p + (1:p)) = rho^j * F(iperm, (j-1)*p + iperm);
    end
    Sig = J.Sigma(iperm, iperm);
    E   = D.Y - D.X*J.beta*J.alpha' - D.Z*J.Psi;
    res = E(:, iperm);
    maxeig = max(abs(eig(companion_form(AR))));
end
