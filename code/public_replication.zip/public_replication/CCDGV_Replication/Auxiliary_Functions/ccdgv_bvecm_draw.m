function [AR, Sig, res, maxeig] = ccdgv_bvecm_draw(J, D, iperm, rho)
%CCDGV_BVECM_DRAW  One Villani posterior draw -> (AR, Sigma, residuals) in SPEC order.
%
%   [AR, Sig, res, maxeig] = CCDGV_BVECM_DRAW(J, D, iperm, rho)
%
%   J      one joint draw from draw_joint: alpha, beta, Gammas, Sigma, Psi, all
%          in ESTIMATION order
%   D      the CLEAN data struct (vecm_data), for the residuals
%   iperm  iperm(j) is the estimation-order position of spec variable j
%   rho    A_j -> rho^j A_j, so the p - r unit roots sit at rho
%
%   AR     p x p*k levels AR block in spec order, damped
%   Sig    p x p innovation covariance in spec order
%   res    T x p residuals, columns in spec order
%   maxeig max |eig| of the damped companion
%
%   See also CCDGV_BVECM.

    p = size(J.alpha, 1);  k = numel(J.Gammas) + 1;
    F = companion(J.alpha, J.beta, J.Gammas);        % levels VAR(k), estimation order
    AR = zeros(p, p*k);
    for j = 1:k
        AR(:, (j-1)*p + (1:p)) = rho^j * F(iperm, (j-1)*p + iperm);
    end
    Sig = J.Sigma(iperm, iperm);
    E   = D.Y - D.X*J.beta*J.alpha' - D.Z*J.Psi;
    res = E(:, iperm);
    maxeig = max(abs(eig(companion_form(AR))));
end
