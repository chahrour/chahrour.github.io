%plotIRF.m
function plotIRF_paper_individual(data,order,vars,Title,select_vars,CJ,NOISE,SLIDE, confidence_bands, labels, legcols, coff, cols)
% labels (optional): legend text for the DASHED overlays, one per entry. The
% number of overlays follows from it, and the SOLID line plus every confidence
% band is taken from page numel(labels)+1 of the 4th dimension. Omitted, it is
% the six countries of Figures B.5/B.6, which is what this file used to hard-code
% -- so existing callers are unaffected. Figures B.3/B.4 pass alternative
% SPECIFICATIONS instead, which is the only reason this is a parameter.
if nargin < 10 || isempty(labels)
    labels = {'GER','ITA','FRA','CAN','JPN','UK'};
end
nover  = numel(labels);      % dashed overlays
nsolid = nover + 1;          % the run drawn solid, with bands
% legcols: legend columns. Default = one row, which is what the six country
% labels of B.5/B.6 want. B.3/B.4 pass 3, matching the draft's two rows of
% three -- its spec labels are far longer than 'GER' and do not fit on one line.
if nargin < 11 || isempty(legcols); legcols = nover; end
legrows = ceil(nover/legcols);
% coff: shift the overlay colours down the default order. B.5/B.6 want 0 -- their
% first country is blue, matching the draft, and the collision with the blue
% solid line is in the draft too. B.3/B.4 want 1: their first overlay is the VECM
% and the draft draws it orange, because a blue VECM would vanish under the blue
% baseline exactly as ours did.
if nargin < 12 || isempty(coff); coff = 0; end
% cols (optional): nover x 3 overlay palette. The default ColorOrder has 7
% entries, so a 7th overlay would wrap onto the solid line's colour.
if nargin < 13; cols = []; end

if NOISE ==1 
LINE = '-r';
else
LINE = '-b';
end
%if slide ==1 
%end
[nimp,~,~,~]=size(data);
[~,nvars]=size(vars);

if CJ == 1
XX2 = 0:20;
XX2reverse = 20:-1:0;
XX = -20:20;
XXreverse = 20:-1:-20;
else
XX = 1:nimp;
XXreverse = nimp:-1:1;
    
end
N = size(order,1);
nfig = size(order,2);

R=round(N/2);
for ff = 1:nfig
    if R ==1
    h=figure('Color',[0.9412 0.9412 0.9412],'Position',[1 1 425 150],'Name',Title);
    else
    h=figure('Color',[0.9412 0.9412 0.9412],'Position',[1 1 425 400],'Name',Title);
    end
    figure(h);
    for n= 1:N
      gg(n) =  subplot(R,2,n);
        hold on;
        if sum(n == select_vars)==1
            if ndims(data)>=3   %if available, plot confidence bands
                if SLIDE == 1
                    if confidence_bands == 2                %- 90% bounds  
                 grpyat = [(XX2)' data(21:end,nvars+order(n,ff),4,nsolid); (XX2reverse)' data(nimp:-1:21,nvars+order(n,ff),5,nsolid)];
                 patch(grpyat(:,1),grpyat(:,2),[0.9 0.9 0.9],'edgecolor',[0.9 0.9 0.9]); %[0.85 0.85 0.85]
                    end
                    %- 68% bounds
                grpyat = [(XX2)' data(21:end,nvars+order(n,ff),2,nsolid); (XX2reverse)' data(nimp:-1:21,nvars+order(n,ff),3,nsolid)];
                patch(grpyat(:,1),grpyat(:,2),[0.7 0.7 0.7],'edgecolor',[0.7 0.7 0.7]); %[0.65 0.65 0.65]
                else
                if confidence_bands == 2                %- 90% bounds  
                 grpyat = [(XX)' data(1:end,nvars+order(n,ff),4,nsolid); (XXreverse)' data(nimp:-1:1,nvars+order(n,ff),5,nsolid)];
                 patch(grpyat(:,1),grpyat(:,2),[0.9 0.9 0.9],'edgecolor',[0.9 0.9 0.9]); %[0.85 0.85 0.85]
                end
                %- 68% bounds
                grpyat = [(XX)' data(1:end,nvars+order(n,ff),2,nsolid); (XXreverse)' data(nimp:-1:1,nvars+order(n,ff),3,nsolid)];
                patch(grpyat(:,1),grpyat(:,2),[0.7 0.7 0.7],'edgecolor',[0.7 0.7 0.7]); %[0.65 0.65 0.65]
            
                end
                end
            CC = cols;
            if isempty(CC)
                CO_ = get(gca,'ColorOrder');
                CC  = CO_(mod((0:nover-1)+coff,size(CO_,1))+1,:);
            end
            for jj = 1:nover
                hh(jj) = plot(XX,data(:,nvars+order(n,ff),1,jj),'--','LineWidth',1.5, ...
                              'Color',CC(jj,:)); hold on;
            end
            hh(nsolid) = plot(XX,data(:,nvars+order(n,ff),1,nsolid),LINE,'LineWidth',2); hold on;
            
        end
        
        plot(XX,zeros(nimp,1),'--k','linewidth',0.5);
        title(vars{order(n,ff)},'FontSize',11,'Interpreter','latex') %'FontWeight','bold',
        ylabel('percent','FontSize',10,'Interpreter','latex')
        set(gca,'TickLabelInterpreter','latex')
        ax = gca;
        %ax.FontSize = 7; 
        %xlabel('quarters','FontSize',12,'Interpreter','latex')
        axis tight
        %                                   axis([0 nimp ylow(n) yhigh(n) ]);
        hold off; grid on; box off
        
    end
    if size(order,2) == 3
        pos = get(gg,'Position');
        new = mean(cellfun(@(v)v(1),pos(1:2)));
        set(gg(3),'Position',[new,pos{end}(2:end)])
    end
 %    print([pwd, '/Figures/',Title],'-depsc','-r0')
 % MATLAB fills a multi-column legend COLUMN-major; the draft reads row-major
 % (left to right, then down). Permute the entries so the drawn order matches
 % reading order. Identity when there is only one row.
 P_ = legperm(nover, legcols, legrows);
 lg_ = legend(hh(P_), labels{P_}, 'NumColumns',legcols, ...
     'box','off','interpreter','latex','fontsize',10);
 % Centre on the FIGURE and sit just above the bottom edge. Height grows with the
 % row count; the hard-coded single-row box used before clipped a second row.
 lg_.Units = 'normalized';
 lg_.Position = [0.5 - lg_.Position(3)/2, 0.0147, lg_.Position(3), 0.04*legrows];
end

% -------------------------------------------------------------------------
function P = legperm(n, c, r)
%   Order to hand legend() so a COLUMN-major fill reads ROW-major on the page.
%   Grid slot (i,j) should show entry (i-1)*c+j; its column-major index is
%   (j-1)*r+i. Slots past n are simply never assigned.
    P = zeros(1,n);
    for i = 1:r
        for j = 1:c
            k = (j-1)*r + i;          % column-major slot index
            e = (i-1)*c + j;          % entry that should sit there
            if k <= n && e <= n; P(k) = e; end
        end
    end
    if any(P == 0); P = 1:n; end      % ragged case -> leave it alone
