function plotIRF_paper_individual(data,order,vars,Title,select_vars,CJ,NOISE,SLIDE, confidence_bands, labels, legcols, coff, cols)
%PLOTIRF_PAPER_INDIVIDUAL  IRF panels for one run with bands, with dashed
%                          overlays from other runs.
%
%   plotIRF_paper_individual(data, order, vars, Title, select_vars, CJ, NOISE, ...
%       SLIDE, confidence_bands, labels, legcols, coff, cols)
%
%   data     nimp x 2*nvars x 5 x (nover+1). The first three dimensions are as
%            in PLOTIRF. Pages 1..nover of the fourth are the overlays; page
%            nover+1 is the run drawn solid, with bands.
%   order    N x nfig rows of data to plot; each column makes one figure.
%   vars     cell array of panel titles, as long as the full variable list.
%   Title    figure Name.
%   select_vars  panel positions that get lines and bands; the rest get only
%            the zero line.
%   CJ       1 = x-axis -20:20 with the shock at 0; 0 = 1:nimp.
%   NOISE    1 = red solid line; 0 = blue.
%   SLIDE    1 = draw the bands from the shock onward only.
%   confidence_bands  1 = inner band; 2 = also the outer band.
%   labels   legend text for the overlays, one each. Default: the six
%            countries of Figures C.10 and C.11.
%   legcols  legend columns. Default: one row.
%   coff     offset of the overlay colours in the default colour order
%            (default 0).
%   cols     nover x 3 overlay colours, in place of the default colour order,
%            which has only 7 entries.
%
%   See also PLOTIRF.

% Defaults for the optional arguments.
if nargin < 10 || isempty(labels)
    labels = {'GER','ITA','FRA','CAN','JPN','UK'};
end
nover  = numel(labels);      % dashed overlays
nsolid = nover + 1;          % the run drawn solid, with bands
if nargin < 11 || isempty(legcols); legcols = nover; end
legrows = ceil(nover/legcols);
if nargin < 12 || isempty(coff); coff = 0; end
if nargin < 13; cols = []; end

% Colour of the solid line.
if NOISE ==1 
LINE = '-r';
else
LINE = '-b';
end
[nimp,~,~,~]=size(data);
[~,nvars]=size(vars);

% x-axis.
if CJ == 1
XX2 = 0:20;
XX2reverse = 20:-1:0;
XX = -20:20;
XXreverse = 20:-1:-20;
else
XX = 1:nimp;
XXreverse = nimp:-1:1;
    
end
% Panels per figure, and number of figures.
N = size(order,1);
nfig = size(order,2);

R=round(N/2);
for ff = 1:nfig
    if R ==1
    h=figure('Color',[0.9412 0.9412 0.9412],'Position',[1 1 425 150],'Name',Title);
    else
    h=figure('Color',[0.9412 0.9412 0.9412],'Position',[1 1 425 400],'Name',Title);
    end
    for n= 1:N
      gg(n) =  subplot(R,2,n);
        hold on;
        if sum(n == select_vars)==1
            if ndims(data)>=3   % confidence bands
                if SLIDE == 1
                    if confidence_bands == 2                % outer band
                 grpyat = [(XX2)' data(21:end,nvars+order(n,ff),4,nsolid); (XX2reverse)' data(nimp:-1:21,nvars+order(n,ff),5,nsolid)];
                 patch(grpyat(:,1),grpyat(:,2),[0.9 0.9 0.9],'edgecolor',[0.9 0.9 0.9]);
                    end
                    % inner band
                grpyat = [(XX2)' data(21:end,nvars+order(n,ff),2,nsolid); (XX2reverse)' data(nimp:-1:21,nvars+order(n,ff),3,nsolid)];
                patch(grpyat(:,1),grpyat(:,2),[0.7 0.7 0.7],'edgecolor',[0.7 0.7 0.7]);
                else
                if confidence_bands == 2                % outer band
                 grpyat = [(XX)' data(1:end,nvars+order(n,ff),4,nsolid); (XXreverse)' data(nimp:-1:1,nvars+order(n,ff),5,nsolid)];
                 patch(grpyat(:,1),grpyat(:,2),[0.9 0.9 0.9],'edgecolor',[0.9 0.9 0.9]);
                end
                % inner band
                grpyat = [(XX)' data(1:end,nvars+order(n,ff),2,nsolid); (XXreverse)' data(nimp:-1:1,nvars+order(n,ff),3,nsolid)];
                patch(grpyat(:,1),grpyat(:,2),[0.7 0.7 0.7],'edgecolor',[0.7 0.7 0.7]);
            
                end
                end
            % Overlay colours.
            CC = cols;
            if isempty(CC)
                CO_ = get(gca,'ColorOrder');
                CC  = CO_(mod((0:nover-1)+coff,size(CO_,1))+1,:);
            end
            % Dashed overlays, then the solid line.
            for jj = 1:nover
                hh(jj) = plot(XX,data(:,nvars+order(n,ff),1,jj),'--','LineWidth',1.5, ...
                              'Color',CC(jj,:)); hold on;
            end
            hh(nsolid) = plot(XX,data(:,nvars+order(n,ff),1,nsolid),LINE,'LineWidth',2); hold on;
            
        end
        
        plot(XX,zeros(nimp,1),'--k','linewidth',0.5);
        title(vars{order(n,ff)},'FontSize',11,'Interpreter','latex')
        ylabel('percent','FontSize',10,'Interpreter','latex')
        set(gca,'TickLabelInterpreter','latex')
        ax = gca;
        axis tight
        hold off; grid on; box off
        
    end
    % When order has three columns, centre the third panel.
    if size(order,2) == 3
        pos = get(gg,'Position');
        new = mean(cellfun(@(v)v(1),pos(1:2)));
        set(gg(3),'Position',[new,pos{end}(2:end)])
    end
 % MATLAB fills a multi-column legend by column. Permute the entries so that
 % they read by row.
 P_ = legperm(nover, legcols, legrows);
 lg_ = legend(hh(P_), labels{P_}, 'NumColumns',legcols, ...
     'box','off','interpreter','latex','fontsize',10);
 % Centre the legend on the figure, just above the bottom edge. Its height
 % grows with the number of rows.
 lg_.Units = 'normalized';
 lg_.Position = [0.5 - lg_.Position(3)/2, 0.0147, lg_.Position(3), 0.04*legrows];
end

function P = legperm(n, c, r)
%   Order to pass to legend() so that a column-major fill reads row-major.
%   Grid slot (i,j) should show entry (i-1)*c+j; its column-major index is
%   (j-1)*r+i.
    P = zeros(1,n);
    for i = 1:r
        for j = 1:c
            k = (j-1)*r + i;          % column-major slot index
            e = (i-1)*c + j;          % entry that should sit there
            if k <= n && e <= n; P(k) = e; end
        end
    end
    if any(P == 0); P = 1:n; end      % ragged grid: leave the order alone
