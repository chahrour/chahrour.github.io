function ix = ccdgv_moment_vars(vnames)
%CCDGV_MOMENT_VARS  Indices of the moment-table variables in a list of names.
%
%   ix = ccdgv_moment_vars(vnames)
%
%   vnames  cell array of variable display names (the rows of A).
%   ix      struct with one field per variable the moment calculations use,
%           holding its index in vnames, or NaN when vnames lacks it. Callers
%           must check for NaN. ix.names_ is the field-to-name table.
%
%   qlambda and cumeret are the same variable, 'RER(Ex. Ret)', under two names.

    % Field name, display name.
    NAMES = { ...
        'cons',       'Home Consumption'
        'inv',        'Home Investment'
        'ner',        'NER'
        'idiff',      'IDIFF'
        'consf',      'Foreign Consumption'
        'cpidiff',    'CPIDIFF'
        'exret',      'Expected Excess Returns'
        'rrdiff',     'Interest Rate Differential'
        'rer',        'Real Exchange Rate'
        'deltaq',     '$\Delta q_t$'
        'cumeret',    'RER(Ex. Ret)'
        'consdiff',   'Consumption Differential'
        'rlzdret',    'Rlzd Excess Returns'
        'cumrlzdret', 'Rlzd Cum Excess Ret'
        'quip',       'RER(UIP)'
        'qlambda',    'RER(Ex. Ret)' };

    % Resolve each name; NaN if absent.
    ix = struct();
    for r = 1:size(NAMES,1)
        k = find(strcmp(vnames, NAMES{r,2}), 1);
        if isempty(k); k = NaN; end
        ix.(NAMES{r,1}) = k;
    end
    ix.names_ = NAMES;      % lets callers report which variable was absent

    % Self-check for a layout of eight data rows followed by the constructed
    % rows: each index must equal its listed position. It does not run on the
    % current manifest, whose ninth row is 'US equity prices'.
    if numel(vnames) >= 9 && strcmp(vnames{9}, 'E[TFP]')
        LIT = {'cons',2; 'inv',3; 'ner',4; 'idiff',5; 'consf',6; 'cpidiff',7; ...
               'exret',11; 'rrdiff',12; 'rer',15; 'deltaq',18; 'cumeret',19; ...
               'consdiff',20; 'rlzdret',24; 'cumrlzdret',25; 'quip',26; 'qlambda',19};
        for r = 1:size(LIT,1)
            assert(isequaln(ix.(LIT{r,1}), LIT{r,2}), 'ccdgv_moment_vars:mismatch', ...
                'baseline layout: %s resolved to %s, expected %d (gentablemoments_v6:31-46).', ...
                LIT{r,1}, mat2str(ix.(LIT{r,1})), LIT{r,2});
        end
    end
end
