function ix = ccdgv_moment_vars(vnames)
%CCDGV_MOMENT_VARS  The Table 3 moment variables, resolved BY NAME.
%
%   ix = CCDGV_MOMENT_VARS(vnames) returns a struct of indices into `vnames`,
%   one field per variable the moment calculations need. A variable that is not
%   in this layout gets **NaN**, not an error and not a substitute.
%
%   WHY THIS EXISTS. gentablemoments_v6.m:31-46 hard-codes sixteen positions
%   (ocons=2, orrdiff=12, odeltaq=18, ... oquip=26) and uses them 120+ times.
%   They are correct ONLY for the 8-variable baseline layout. The equity
%   specifications insert 'US equity' and 'G6 equity' at 9-10 and
%   shift everything from 'E[TFP]' onward by +2, so the same literals silently
%   select the wrong series:
%
%       index 12  base: Interest Rate Differential   equity: ENER
%       index 18  base: $\Delta q_t$                 equity: BS Wedge
%       index 19  base: RER(Ex. Ret)                 equity: $\Delta$BS Wedge
%
%   Nothing errors -- the moments are simply computed on different variables.
%   Same failure that ccdgv_order fixed for the figures; this file is its
%   counterpart for the moments.
%
%   NaN RATHER THAN A FALLBACK. Note that ccdgv_order's helper find_one() warns
%   and returns index 1 when a name is missing, i.e. it silently substitutes
%   'Home TFP'. That is not safe here: the whole point is to run these moments on
%   VAR layouts that genuinely lack some variables (a noFX spec has no NER, so
%   the exchange-rate moments are undefined for it). Callers are expected to
%   check for NaN and record a skip -- see gentablemoments_final's R.skipped.
%
%   FIELDS (with the historical literal for the baseline layout)
%       cons 2, inv 3, ner 4, idiff 5, consf 6, cpidiff 7, exret 11,
%       rrdiff 12, rer 15, deltaq 18, cumeret 19, consdiff 20,
%       rlzdret 24, cumrlzdret 25, quip 26, qlambda 19
%
%   qlambda and cumeret are BOTH 19 in the original ('RER(Ex. Ret)') -- one
%   variable under two names. Preserved deliberately rather than merged, so the
%   moment spec can keep using whichever name reads better at each call site.
%
%   SELF-CHECK below asserts the baseline layout reproduces those literals, so a
%   typo in a name here fails loudly instead of quietly moving a published number.
%

    NAMES = { ...
        'cons',       'Home Consumption'
        'inv',        'Home Investment'
        'ner',        'NER'
        'idiff',      'IDIFF'
        'consf',      'Foreign Consumption'
        'cpidiff',    'CPIDIFF'
        'exret',      'Expected Excess Returns'
        'rrdiff',     'Interest Rate Differential'
        'rer',        'Real Exchange Rate'
        'deltaq',     '$\Delta q_t$'
        'cumeret',    'RER(Ex. Ret)'
        'consdiff',   'Consumption Differential'
        'rlzdret',    'Rlzd Excess Returns'
        'cumrlzdret', 'Rlzd Cum Excess Ret'
        'quip',       'RER(UIP)'
        'qlambda',    'RER(Ex. Ret)' };

    ix = struct();
    for r = 1:size(NAMES,1)
        k = find(strcmp(vnames, NAMES{r,2}), 1);
        if isempty(k); k = NaN; end
        ix.(NAMES{r,1}) = k;
    end
    ix.names_ = NAMES;      % kept so callers can report WHICH variable was absent

    % ---- self-check against the historical literals ------------------------
    %
    % THIS BLOCK IS DEAD CODE. It has not run in a long time. Established by
    % audit 2026-08-12; the note below is the finding, not a caveat.
    %
    % The guard asks whether vnames{9} is 'E[TFP]', i.e. whether the FIRST
    % constructed row sits at position 9 -- true only when the label list is
    % [8 data rows; 18 constructed]. That was the layout when these literals
    % were written, and they agree with it exactly:
    %
    %     rer        15 = 8 + 7   (7th constructed row)
    %     rlzdret    24 = 8 + 16
    %     quip       26 = 8 + 18  (last constructed row)
    %
    % But run_main builds vnames as
    %
    %     vnames = [{manifest(1:nvall).name}, {constructed.name}]
    %
    % over ALL data rows, and the manifest has grown well past 8 -- eq_us,
    % eq_g6, tb_g6, nx_gdp, solow_g6, the four tech rows, two return rows. So
    % vnames{9} is 'US equity prices', the guard is false, and the assertions
    % never execute. Both callers -- gentablemoments_final:87 and
    % gentablefilteredmoments_final:73 -- pass that same full-width list.
    % CCDGV_ORDER:54 carries an identical guard and is dead for the same reason.
    %
    % Nothing is mis-resolving because of this: the lookup above is by name and
    % the name list and A's rows are built from the same manifest, in the same
    % order, so they grow together. What was lost is the check that would catch
    % a TYPO in the NAMES table -- a misspelling silently yields NaN, and NaN is
    % a legitimate value here (it means "this layout lacks that variable"), so
    % the failure is indistinguishable from a spec that genuinely lacks the row.
    %
    % TO REVIVE IT the literals need rebasing off the manifest rather than off
    % the number 8: a constructed key's expected index is nvall + its position
    % in C, and a data key's is its position in D. That derivation goes through
    % KEYS while the lookup goes through display NAMES, so it is not circular
    % and would restore exactly the typo-catching the block was written for.
    % Not done here -- see TODO.md item 7.
    if numel(vnames) >= 9 && strcmp(vnames{9}, 'E[TFP]')
        LIT = {'cons',2; 'inv',3; 'ner',4; 'idiff',5; 'consf',6; 'cpidiff',7; ...
               'exret',11; 'rrdiff',12; 'rer',15; 'deltaq',18; 'cumeret',19; ...
               'consdiff',20; 'rlzdret',24; 'cumrlzdret',25; 'quip',26; 'qlambda',19};
        for r = 1:size(LIT,1)
            assert(isequaln(ix.(LIT{r,1}), LIT{r,2}), 'ccdgv_moment_vars:mismatch', ...
                'baseline layout: %s resolved to %s, expected %d (gentablemoments_v6:31-46).', ...
                LIT{r,1}, mat2str(ix.(LIT{r,1})), LIT{r,2});
        end
    end
end
