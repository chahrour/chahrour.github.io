function V = cj_bandint(lam, F, bands)
%CJ_BANDINT  Integrate sampled integrands over frequency bands.
%
%   V = CJ_BANDINT(lam, F, bands)
%
%   lam    1 x N   uniform ascending frequency grid (the CJ grid)
%   F      nrow x N  integrand samples on that grid, one row per variable
%   bands  nb x 2  [lo hi] per band, as vd_fr
%   V      nrow x nb  the integral of each row over each band
%
%   WHY THIS EXISTS. The CJ band variance shares used to come from MATLAB's
%   adaptive INTEGRAL, which rebuilds the whole transfer function at every node
%   it chooses. That is the wrong tool twice over:
%
%   1. The integrands are already sampled on this grid -- the IRFs in
%      GEN_CJ_IRFS_TFSWEEP are computed from exactly these points by ifft. Using
%      a different discretization for the shares made two outputs of the same
%      run disagree about how the spectrum was discretized.
%
%   2. Adaptive refinement assumes it can reach its tolerance. When the spectrum
%      has a pole ON the unit circle -- which the VECM spec imposes exactly --
%      the noise Wold cepstrum never decays, cj_wold becomes a degree-32768
%      Horner evaluation, and the integrand is noise-limited. INTEGRAL then
%      subdivides until it gives up: 37080 evaluations against 210 for the same
%      band on the baseline, and 18.9 s against 0.02 s. It does not achieve the
%      1e-6 it reports in that regime.
%
%   METHOD. Composite Simpson over the grid nodes inside the band (O(h^4)), plus
%   a linearly interpolated partial cell at each edge so the limits are the
%   REQUESTED ones. The edge caps matter: without them the effective limits are
%   the nearest nodes, worth up to h*f(edge), which on these bands is a ~1e-4
%   relative error -- far bigger than the interior rule's own error.
%
%   See also GEN_CJ_IRFS_TFSWEEP, CJ_WOLD, CJ_CEPFACTOR.

    lam = lam(:).';
    N   = numel(lam);
    h   = lam(2) - lam(1);
    assert(N > 2 && h > 0, 'cj_bandint:grid', 'lam must be ascending with N > 2');

    nb = size(bands,1);
    V  = zeros(size(F,1), nb);

    for j = 1:nb
        a = bands(j,1);  b = bands(j,2);
        i1 = find(lam >= a, 1, 'first');
        i2 = find(lam <= b, 1, 'last');
        assert(~isempty(i1) && ~isempty(i2) && i2 > i1, 'cj_bandint:band', ...
               'band [%g %g] spans no grid cell of a grid running [%g %g]', ...
               a, b, lam(1), lam(end));

        v = simpson(F(:,i1:i2), h);

        % Partial cell at the left edge, [a, lam(i1)].
        if i1 > 1 && lam(i1) > a
            fa = F(:,i1-1) + (F(:,i1) - F(:,i1-1)) .* ((a - lam(i1-1))/h);
            v  = v + (lam(i1) - a)/2 .* (fa + F(:,i1));
        end
        % Partial cell at the right edge, [lam(i2), b].
        if i2 < N && b > lam(i2)
            fb = F(:,i2) + (F(:,i2+1) - F(:,i2)) .* ((b - lam(i2))/h);
            v  = v + (b - lam(i2))/2 .* (F(:,i2) + fb);
        end

        V(:,j) = v;
    end
end

% -------------------------------------------------------------------------
function v = simpson(F, h)
%SIMPSON  Composite Simpson over the columns of F, spacing h.
%   An odd number of intervals cannot be covered by Simpson alone, so the last
%   one falls back to the trapezoid rule -- an O(h^3) local term on a single
%   cell, which is negligible beside the band's own width.
    n = size(F,2) - 1;                       % intervals
    if n < 1; v = zeros(size(F,1),1); return; end
    if n == 1; v = h/2 .* (F(:,1) + F(:,2)); return; end
    if mod(n,2) == 1
        v = simpson(F(:,1:end-1), h) + h/2 .* (F(:,end-1) + F(:,end));
        return
    end
    m = n + 1;                               % points, odd
    w = ones(1,m);  w(2:2:m-1) = 4;  w(3:2:m-2) = 2;
    v = (h/3) .* (F * w.');
end
