function [Zd, sig] = ccdgv_bvecm_minn(D, lambda, decay)
%CCDGV_BVECM_MINN  Minnesota dummy rows for the short-run block of a Villani VECM.
%
%   [Zd, sig] = ccdgv_bvecm_minn(D, lambda, decay)
%
%   D       struct from vecm_data(x, k, 'const').
%   lambda  overall tightness: the prior s.d. of the coefficient on lag i of dx_j
%           is lambda / (i^decay * sig_j), in the equation's own residual units.
%   decay   lag decay exponent (1 is harmonic decay).
%
%   Zd      (p*(k-1)) x d rows to append to Z, one per Gamma coefficient, so that
%           Zd'Zd = Omega0^{-1} for the Gamma rows of Psi. The constant gets no
%           dummy row and stays flat.
%   sig     p x 1 residual s.d. of a univariate AR(k-1) on each dx_j.
%
%   The prior is vec Psi ~ N(0, Sigma (x) Omega0) with Omega0 diagonal and shared
%   across equations, so one lambda serves own and cross lags. The prior mean of
%   zero on every Gamma is a random walk in levels.
%
%   See also CCDGV_BVECM_DATA.

    p = D.p;  k = D.k;  d = D.d;  T = D.T;
    nG = p*(k-1);
    assert(strcmp(D.det, 'const') && d == nG + 1, 'ccdgv_bvecm_minn:det', ...
        'expects det = ''const'' (d = p*(k-1) + 1), got d = %d.', d);

    % Scale factors: residual s.d. of an AR(k-1) with constant on each dx_j.
    sig = zeros(p, 1);
    for j = 1:p
        Xj = [D.Z(:, j:p:nG), ones(T, 1)];
        e  = D.Y(:, j) - Xj*(Xj\D.Y(:, j));
        sig(j) = sqrt(e'*e/T);
    end

    % One dummy row per Gamma coefficient, on the diagonal.
    Zd = zeros(nG, d);
    for i = 1:k-1
        for j = 1:p
            c = (i-1)*p + j;
            Zd(c, c) = i^decay * sig(j) / lambda;
        end
    end
end
