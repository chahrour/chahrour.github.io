function [Zd, sig] = ccdgv_bvecm_minn(D, lambda, decay)
%CCDGV_BVECM_MINN  Minnesota dummy rows for the short-run block of a Villani VECM.
%
%   [Zd, sig] = CCDGV_BVECM_MINN(D, lambda, decay)
%
%   D       clean struct from vecm_data(x, k, 'const')
%   lambda  overall tightness: prior s.d. of the coefficient on lag i of dx_j
%           is lambda / (i^decay * sig_j), in the equation's own residual units
%   decay   lag decay exponent (1 = Litterman's harmonic decay)
%
%   Zd      (p*(k-1)) x d rows to append to Z, one per Gamma coefficient, so
%           that Zd'Zd = Omega0^{-1} for the Gamma rows of Psi. The CONSTANT
%           row of Psi gets no dummy and stays flat, as in the repo's own
%           Minnesota prior (minneprc's lambda4 = 1e5).
%   sig     p x 1 residual s.d. of univariate AR(k-1) regressions on dx_j,
%           the usual Minnesota scale factors
%
%   The prior is vec Psi ~ N(0, Sigma (x) Omega0) with Omega0 DIAGONAL and
%   shared across equations -- the Kronecker structure the library's collapsed
%   sampler needs. Equation-specific scale comes from Sigma, so Omega0 carries
%   only the 1/sig_j^2 regressor scale and the lag decay. That is the
%   Banbura-Giannone-Reichlin construction; it cannot distinguish own from
%   cross lags (that would break Kronecker), so one lambda serves both.
%
%   Prior mean zero on every Gamma is a random walk in the LEVELS, matching the
%   baseline VAR's unit-root Minnesota prior. Nothing here touches alpha or
%   beta; their prior is Villani's.
%
%   See also CCDGV_BVECM_DATA.

    p = D.p;  k = D.k;  d = D.d;  T = D.T;
    nG = p*(k-1);
    assert(strcmp(D.det, 'const') && d == nG + 1, 'ccdgv_bvecm_minn:det', ...
        'expects det = ''const'' (d = p*(k-1) + 1), got d = %d.', d);

    sig = zeros(p, 1);
    for j = 1:p
        Xj = [D.Z(:, j:p:nG), ones(T, 1)];
        e  = D.Y(:, j) - Xj*(Xj\D.Y(:, j));
        sig(j) = sqrt(e'*e/T);
    end

    Zd = zeros(nG, d);
    for i = 1:k-1
        for j = 1:p
            c = (i-1)*p + j;
            Zd(c, c) = i^decay * sig(j) / lambda;
        end
    end
end
