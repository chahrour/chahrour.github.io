function E = ccdgv_extshare(D, names, opt)
%CCDGV_EXTSHARE  Turn a variance share of a PROJECTED series into a variance
%                share of the ACTUAL series.
%
%   E = CCDGV_EXTSHARE(D, names)
%   E = CCDGV_EXTSHARE(D, names, opt)
%
%   D      a loaded run: needs ARs, Sigs, Aproj, keys, r2, data, vnames, vd_feh,
%          vd_fr. Uses Ures if the run stored it (see below).
%   names  cell of manifest DISPLAY names, as they appear in D.vnames
%   opt    .horizons  FEV horizons; default D.vd_feh
%          .bands     which rows of D.vd_fr; default all of them
%          .M         vdfilter grid points per band; default 500
%          .arlags    AR order fitted to the residual; default 4
%          .draws     which draws to use; default 1:ndraws (the point estimate,
%                     element ndraws+1, is excluded -- pass it explicitly to use
%                     it alone)
%
%   RETURNS, for each named row, the FACTOR the reported share must be multiplied
%   by. The caller multiplies; this function does not know which identification
%   produced the share, and does not need to.
%       E.fac_fev    nrows x numel(horizons) x ndraws
%       E.fac_band   nrows x numel(bands)    x ndraws
%
%   WHAT THE FACTOR IS. Write x = xhat + u, xhat the projection on the companion
%   state and u the residual. u is orthogonal to the state by construction, hence
%   to every VAR shock, hence the shock's contribution to the variance of x is
%   IDENTICAL to its contribution to the variance of xhat. Only the denominator
%   changes. So
%
%       share of x = share of xhat  x  V(xhat) / [V(xhat) + V(u)]
%
%   with V(.) measured the SAME WAY as the share's own denominator.
%
%   WHY THIS IS NOT r2, WHICH IS THE OBVIOUS GUESS. r2 is that ratio for the
%   UNCONDITIONAL SAMPLE variance. Neither reported share has that denominator:
%   the max-share tables report a forecast-error variance at horizon h
%   (MAXSHR:143) and the CJ tables a spectral band (SDENSITY via
%   GENTFP_FREQ_BASELINE_FAST). This VAR is estimated on LOG LEVELS -- see
%   Y_benchmark, where C is 29.0 and I is 27.6, and fdvar is empty -- with
%   maxeig_cutoff = 1, so retained draws have roots against the unit circle. An
%   r2 of 0.985 on such a series mostly records a shared trend, and that is
%   precisely the low-frequency power a 6-32 quarter band discards. Multiplying a
%   band share by r2 therefore OVERSTATES it, and most at business-cycle
%   frequencies, which is the number one would most want to quote. Both correct
%   denominators are computed here instead.
%
%   NO RE-RUN IS NEEDED FOR THE MODEL SIDE, because both denominators are
%   ROTATION-FREE. maxshr's total FEV is cumsum(sum(Tk1.^2,2)) with
%   Tk1 = A*B^(k-1)*U, which depends on U only through U*U'; U = [Atilde*V;0]
%   with V orthonormal, so U*U' is the innovation covariance whatever the
%   rotation. vdfilter's Vy is the same. So FEV_h(xhat) and V_band(xhat) follow
%   from ARs/Sigs/Aproj alone, all of which the results file already holds -- the
%   identification code is untouched.
%
%   THE RESIDUAL IS THE ONE THING THAT MAY BE MISSING. Runs from 2026-09-13 on
%   store Ures and this uses the residual's own AR representation, which gives
%   its FEV path and its spectral density with nothing assumed. On an older run
%   Ures is absent; then V(u) is recovered exactly in sample as
%   Var(xhat)*(1/r2 - 1) but has to be spread across horizons and bands AS WHITE
%   NOISE. E.source says which held for each row, and E.note spells it out for a
%   table footnote. Where both are available the two are cross-checked.
%
%   A ROW WITH r2 = 1 IS IN THE VAR, so its factor is exactly 1 and no residual
%   is fitted. That is not an error -- it makes the function safe to point at a
%   full row list, and at an augmented spec.
%
%   ONLY DATA ROWS. The constructed rows of A are exact algebra on the state, not
%   projections; they have no residual of their own and inherit their inputs'.
%   Asking for one is an error rather than a factor of 1.
%
%   See also CCDGV_PROJECT, MAXSHR, VDFILTER, WRITE_ASSET_PROJ_VD_TABLE.

    if nargin < 3; opt = struct(); end
    dflt = struct('horizons',[], 'bands',[], 'M',500, 'arlags',4, 'draws',[]);
    bad  = setdiff(fieldnames(opt), fieldnames(dflt));
    assert(isempty(bad), 'ccdgv_extshare:unknownOpt', ...
        'Unknown opt field(s): %s. Valid: %s.', ...
        strjoin(bad(:)',', '), strjoin(fieldnames(dflt)',', '));
    for f = fieldnames(dflt)'
        if ~isfield(opt,f{1}) || isempty(opt.(f{1})); opt.(f{1}) = dflt.(f{1}); end
    end
    if isempty(opt.horizons); opt.horizons = D.vd_feh; end
    if isempty(opt.bands);    opt.bands    = 1:size(D.vd_fr,1); end

    for fl = {'ARs','Sigs','Aproj','keys','r2','data','vnames','vd_fr'}
        assert(isfield(D, fl{1}), 'ccdgv_extshare:missing', ...
            '%s not in this run -- it needs the data and estimation stages.', fl{1});
    end

    nvars  = size(D.data, 2);
    nb     = size(D.Aproj, 2);
    nlags  = nb / nvars;
    assert(nlags == fix(nlags), 'ccdgv_extshare:width', ...
        'Aproj is %d wide but the VAR has %d variables', nb, nvars);
    ndall  = numel(D.ARs);                       % ndraws + 1
    if isempty(opt.draws); opt.draws = 1:(ndall-1); end
    ndr = numel(opt.draws);

    % ---- rows -------------------------------------------------------------
    idx = var_order(D.vnames, names{:});  idx = idx(:)';
    nr  = numel(idx);
    assert(all(idx <= size(D.Aproj,1)), 'ccdgv_extshare:constructedRow', ...
        ['%s is a CONSTRUCTED row of A, not a projected data series. Those are ' ...
         'exact algebra on the state and have no residual of their own -- they ' ...
         'inherit their inputs''. Name the data rows instead.'], ...
        strjoin(names(idx > size(D.Aproj,1)), ', '));
    % PER-DRAW FIRST STAGE. A run that drew its projection stores Aproj_draw
    % (one page per draw, the last page the posterior mean); then the numerator,
    % the denominator and the residual model all move with the draw, which is
    % what keeps the ratio a share. Without it every page is the same row and
    % this is exactly the old behaviour.
    hasD = isfield(D,'Aproj_draw') && ~isempty(D.Aproj_draw) && ndims(D.Aproj_draw) == 3;
    Asel = D.Aproj(idx, :);
    if hasD; Apg = D.Aproj_draw(idx,:,:); else; Apg = repmat(Asel, 1, 1, 1); end

    % ---- the residual, per row --------------------------------------------
    % One AR(p) per row does both jobs: its FEV path and its spectral density.
    % p = 0 reproduces white noise exactly, which is the fallback, so there is a
    % single code path rather than two.
    hasU = isfield(D,'Ures') && ~isempty(D.Ures) && size(D.Ures,2) >= max(idx);
    Yl   = local_state(D.data, nlags);
    U    = repmat(struct('source','', 'phi',[], 's2e',0, 'varu',0, 'n',0, ...
                         'varu_r2',NaN), 1, nr);
    for k = 1:nr
        i  = idx(k);
        % V(xhat) ON THE PROJECTION'S OWN SAMPLE, and built from the blocks the
        % row actually uses. Taking every finite state row instead made this
        % 7.3% too large for a ragged row (patent_app starts 1981) and tripped
        % the 5% check below; and for a projblocks = 1 row, 0*NaN in the unused
        % blocks dropped the first nlags-1 observations the projection HAD used.
        nzb = find(any(reshape(D.Aproj(i,:), nvars, nlags) ~= 0, 1), 1, 'last');
        if isempty(nzb); nzb = nlags; end
        xh = Yl(:,1:nvars*nzb) * D.Aproj(i,1:nvars*nzb)';
        if isfield(D,'Ures') && size(D.Ures,2) >= i
            msk = isfinite(xh) & isfinite(D.Ures(:,i));
        else
            msk = isfinite(xh);
        end
        vh = var(xh(msk));

        if abs(D.r2(i) - 1) < 1e-8
            U(k).source = 'inVAR';  U(k).phi = [];  U(k).s2e = 0;  U(k).varu = 0;
            continue
        end
        % Exact in sample: r2 = Var(xhat)/Var(x) for OLS with a constant.
        U(k).varu_r2 = vh * (1/D.r2(i) - 1);

        u = [];
        if hasU; u = local_longest(D.Ures(:,i)); end
        if numel(u) > 4*opt.arlags + 10
            [U(k).phi, U(k).s2e] = local_arfit(u, opt.arlags);
            U(k).varu   = var(u);
            U(k).n      = numel(u);
            U(k).source = 'residual';
            % The two routes to Var(u) must agree; if they do not, the stored
            % residual is not the residual behind this r2.
            if isfinite(U(k).varu_r2) && U(k).varu_r2 > 0
                rel = abs(U(k).varu - U(k).varu_r2) / U(k).varu_r2;
                if rel > 0.05
                    warning('ccdgv_extshare:resMismatch', ...
                        ['%s: Var(u) is %.4g from the stored residual but %.4g ' ...
                         'from r2 and Var(xhat) (%.1f%% apart). Ures may be ' ...
                         'from a different run than r2.'], ...
                        D.vnames{i}, U(k).varu, U(k).varu_r2, 100*rel);
                end
            end
        else
            U(k).phi = zeros(0,1);  U(k).varu = U(k).varu_r2;
            U(k).s2e = U(k).varu_r2;  U(k).source = 'r2';
        end
    end

    % ---- residual variance, measured each way -----------------------------
    % WHEN THE RUN DREW ITS FIRST STAGE, the residual process comes from the
    % MODEL that produced the draws: proj_phi (the AR fitted to the posterior
    % mean's own residual) and proj_s2draw (the draw of the innovation variance,
    % from its marginal posterior). Both are stored by run_main.
    %
    % The obvious surrogate -- rescaling by var(x - Yl*a_j)/var(u) -- is wrong
    % twice over. That variance is sigma_u^2 PLUS the estimation error
    % (a_j - a)'S(a_j - a), so it is inflated on every draw and never below 1;
    % measured, it ran 1.1x to 3.4x across rows. And the increment Yl*(a_j - a)
    % is a combination of near-unit-root levels, so it is not spectrally
    % proportional to u: it puts only ~30% of its variance in the 6-32 quarter
    % band against ~60-70% for u, so scaling the band integral uniformly
    % overstates the residual exactly where the paper reads it.
    nh  = numel(opt.horizons);
    nbd = numel(opt.bands);
    fev_u  = NaN(nr, nh, ndr);
    band_u = NaN(nr, nbd, ndr);
    hasS = hasD && isfield(D,'proj_s2draw') && ~isempty(D.proj_s2draw) ...
                && isfield(D,'proj_phi') && ~isempty(D.proj_phi);
    PH = {};
    if hasS; PH = D.proj_phi; if iscell(PH) && numel(PH) == 1 && iscell(PH{1}); PH = PH{1}; end; end
    for k = 1:nr
        i = idx(k);
        phik = U(k).phi;  s2k = U(k).s2e * ones(1, ndr);
        if hasS && i <= size(D.proj_s2draw,1) && any(isfinite(D.proj_s2draw(i,:)))
            if i <= numel(PH) && ~isempty(PH{i}); phik = PH{i}; end
            sj = D.proj_s2draw(i, :);
            s2k = sj(min(opt.draws, numel(sj)));
            U(k).source = 'drawn';
        end
        f0 = local_fev_ar(phik, 1, opt.horizons);          % unit innovation variance
        b0 = zeros(1, nbd);
        for m = 1:nbd
            b0(m) = local_band_ar(phik, 1, D.vd_fr(opt.bands(m),:), opt.M);
        end
        fev_u(k,:,:)  = f0(:) * s2k;                       % both are linear in s2e
        band_u(k,:,:) = b0(:) * s2k;
    end

    % ---- the model side, per draw -----------------------------------------
    fev_x  = NaN(nr, nh,  ndr);
    band_x = NaN(nr, nbd, ndr);
    targ   = zeros(1, nvars);            % Ve is unused here; only diag(Vy) is
    for q = 1:ndr
        j  = opt.draws(q);
        B  = companion_form(D.ARs{j});
        C  = zeros(nb, nvars);
        C(1:nvars, 1:nvars) = chol(D.Sigs{j})';
        Aq = Apg(:,:,min(j, size(Apg,3)));
        fev_x(:,:,q)  = local_fev_model(Aq, B, C, opt.horizons);
        for m = 1:nbd
            Vy = vdfilter(B, C, targ, D.vd_fr(opt.bands(m),:), Aq, opt.M);
            band_x(:,m,q) = diag(Vy);
        end
    end

    % ---- factors ----------------------------------------------------------
    E = struct();
    E.names     = names(:)';
    E.keys      = D.keys(idx);
    E.idx       = idx;
    E.r2        = D.r2(idx);
    E.horizons  = opt.horizons;
    E.bands     = opt.bands;
    E.band_lam  = D.vd_fr(opt.bands, :);
    E.fev_xhat  = fev_x;    E.fev_u  = fev_u;
    E.band_xhat = band_x;   E.band_u = band_u;
    E.fac_fev   = fev_x  ./ (fev_x  + fev_u);
    E.fac_band  = band_x ./ (band_x + band_u);
    E.drawn     = hasD;
    E.source    = {U.source};
    E.varu      = [U.varu];
    E.arlags    = cellfun(@numel, {U.phi});
    E.ndraws    = ndr;

    src = unique(E.source(~strcmp(E.source,'inVAR')));
    if isempty(src)
        E.note = 'every row is in the VAR; the factor is 1 by construction.';
    elseif isequal(src, {'residual'})
        E.note = sprintf(['the residual''s own AR(%d) spectrum and FEV path; ' ...
                          'nothing assumed about its serial correlation.'], opt.arlags);
    elseif isequal(src, {'r2'})
        E.note = ['this run did not store the projection residual, so Var(u) ' ...
                  'is recovered from r2 and spread across horizons and bands ' ...
                  'AS WHITE NOISE. Re-run to drop that assumption.'];
    else
        E.note = ['mixed: some rows use the stored residual''s own spectrum, ' ...
                  'others a white-noise residual recovered from r2 (see .source).'];
    end
end

% =========================================================================
function Yl = local_state(Y, nlags)
%LOCAL_STATE  The companion state, column order as CCDGV_PROJECT builds it.
    Yl = lagmatrix(Y, 0:nlags-1);
end

function u = local_longest(col)
%LOCAL_LONGEST  The longest run of consecutive finite values.
%   An AR fit needs contiguous observations, and coverage here is ragged: the
%   GFD yield panel is NaN before it starts and after it ends, and a row can be
%   masked in the middle. Taking the longest run is explicit about which stretch
%   was used rather than silently splicing across a hole.
    ok = isfinite(col(:))';
    if ~any(ok); u = []; return; end
    d  = diff([0 ok 0]);
    s  = find(d == 1);  e = find(d == -1) - 1;
    [~, w] = max(e - s);
    u = col(s(w):e(w));
end

function [phi, s2e] = local_arfit(u, p)
%LOCAL_ARFIT  OLS AR(p) with a constant; returns the AR coefficients and the
%   innovation variance. p is reduced if the sample cannot support it.
    u = u(:);
    p = min(p, floor((numel(u) - 10)/4));
    if p < 1; phi = zeros(0,1); s2e = var(u); return; end
    T = numel(u);
    X = ones(T-p, p+1);
    for l = 1:p; X(:,l) = u(p+1-l : T-l); end
    y = u(p+1:T);
    b = X \ y;
    phi = b(1:p);
    e   = y - X*b;
    s2e = sum(e.^2) / (numel(e) - p - 1);
end

function f = local_fev_ar(phi, s2e, horizons)
%LOCAL_FEV_AR  FEV of an AR(p) at each horizon: s2e * sum_{k<h} theta_k^2.
%   theta are the MA coefficients of 1/phi(L), built by the recursion
%   theta_k = sum_j phi_j theta_{k-j}. With p = 0 every FEV equals s2e, which is
%   the white-noise case, so the fallback needs no branch of its own.
%
%   NO CROSS TERM WITH THE MODEL'S FEV. The h-step error in x is the error in
%   xhat plus the error in u, and u_{t+h} is orthogonal to the state at t+h and
%   so to the VAR innovations dated t+1..t+h. The two add.
    hmax = max(horizons);
    th   = zeros(hmax, 1);  th(1) = 1;
    p    = numel(phi);
    for k = 2:hmax
        for j = 1:min(p, k-1)
            th(k) = th(k) + phi(j)*th(k-j);
        end
    end
    c = cumsum(th.^2);
    f = s2e * c(horizons)';
end

function v = local_band_ar(phi, s2e, lam, M)
%LOCAL_BAND_AR  The AR(p) residual's variance over [lam(1), lam(2)], on
%   VDFILTER's normalisation: Vy = 2*Re int_{lam1}^{lam2} g(w) dw with
%   g = (1/2pi)|T(w)|^2, so v = (1/pi) int s2e/|phi(e^{-iw})|^2 dw.
%
%   SAME QUADRATURE AS VDFILTER -- log-spaced nodes, trapezoid weights -- so the
%   numerator and denominator of the factor are integrated the same way and the
%   grid cancels to first order. Over [0, pi] this returns Var(u) for any p,
%   which is the check LOCAL_BAND_AR_SELFTEST makes.
    if isempty(phi)
        v = s2e * (lam(2) - lam(1)) / pi;     % white noise, in closed form
        return
    end
    g = logspace(log10(lam(1)), log10(lam(2)), M);
    w        = zeros(1, M);
    w(2:M-1) = (g(3:M) - g(1:M-2))/2;
    w(1)     = (g(2) - g(1))/2;
    w(M)     = (g(M) - g(M-1))/2;
    z  = exp(-1i*g(:));
    ph = ones(M, 1);
    for j = 1:numel(phi); ph = ph - phi(j)*z.^j; end
    v = (1/pi) * sum(w(:) .* (s2e ./ abs(ph).^2));
end

function F = local_fev_model(Asel, B, C, horizons)
%LOCAL_FEV_MODEL  Total FEV of each row of Asel at each horizon.
%   MAXSHR:143's denominator, cumsum(sum(Tk1.^2,2)), with Tk1(k,:,:) =
%   (A*B^(k-1)*U)'. Rotation-free: it depends on U only through U*U'. Psi is
%   accumulated by Psi <- B*Psi rather than forming B^(k-1), which at 100
%   horizons and a 32-wide companion is the difference between one matrix
%   product per step and a fresh power each step.
    hmax = max(horizons);
    Psi  = C;
    acc  = zeros(size(Asel,1), 1);
    F    = NaN(size(Asel,1), numel(horizons));
    for k = 1:hmax
        acc = acc + sum((Asel*Psi).^2, 2);
        hit = find(horizons == k);
        for q = hit(:)'; F(:,q) = acc; end
        Psi = B*Psi;
    end
    assert(~any(isnan(F(:))), 'ccdgv_extshare:horizon', ...
        'a requested horizon exceeds %d', hmax);
end
