function E = ccdgv_extshare(D, names, opt)
%CCDGV_EXTSHARE  Factors that convert a variance share of a projected series
%                into a share of the actual series.
%
%   E = ccdgv_extshare(D, names)
%   E = ccdgv_extshare(D, names, opt)
%
%   D      a loaded run file; needs ARs, Sigs, Aproj, keys, r2, data, vnames,
%          vd_feh and vd_fr. Uses Ures, Aproj_draw, proj_phi and proj_s2draw
%          when the run stored them.
%   names  cell of display names of data rows, as they appear in D.vnames.
%          Naming a constructed row is an error.
%   opt    .horizons  FEV horizons (default D.vd_feh)
%          .bands     rows of D.vd_fr to use (default all)
%          .M         vdfilter grid points per band (default 500)
%          .arlags    AR order fitted to the residual (default 4)
%          .draws     draws to use (default 1:ndraws, which leaves out the
%                     point estimate stored last)
%
%   E.fac_fev    nrows x numel(horizons) x ndraws
%   E.fac_band   nrows x numel(bands)    x ndraws
%   are the factors; the caller multiplies its share by them. E also holds the
%   pieces (fev_xhat, fev_u, band_xhat, band_u), the source of each row's
%   residual model (E.source) and a sentence describing it (E.note).
%
%   Write x = xhat + u, with xhat the projection on the companion state and u
%   the residual. u is orthogonal to the state, so a shock contributes the same
%   variance to x as to xhat, and
%
%       share of x = share of xhat * V(xhat) / [V(xhat) + V(u)]
%
%   where V is measured as the share's own denominator is: a forecast-error
%   variance at horizon h, or a variance over a frequency band. Neither depends
%   on the identification, so both follow from ARs, Sigs and Aproj.
%
%   V(u) comes from an AR model of the residual. E.source says which:
%     'drawn'     the run drew its first stage: proj_phi and proj_s2draw
%     'residual'  an AR(arlags) fitted to the stored residual Ures
%     'r2'        no residual stored: Var(u) from r2, treated as white noise
%     'inVAR'     r2 = 1, so the factor is 1
%
%   See also CCDGV_PROJECT, MAXSHR, VDFILTER, WRITE_ASSET_PROJ_VD_TABLE.

    % Options and defaults.
    if nargin < 3; opt = struct(); end
    dflt = struct('horizons',[], 'bands',[], 'M',500, 'arlags',4, 'draws',[]);
    bad  = setdiff(fieldnames(opt), fieldnames(dflt));
    assert(isempty(bad), 'ccdgv_extshare:unknownOpt', ...
        'Unknown opt field(s): %s. Valid: %s.', ...
        strjoin(bad(:)',', '), strjoin(fieldnames(dflt)',', '));
    for f = fieldnames(dflt)'
        if ~isfield(opt,f{1}) || isempty(opt.(f{1})); opt.(f{1}) = dflt.(f{1}); end
    end
    if isempty(opt.horizons); opt.horizons = D.vd_feh; end
    if isempty(opt.bands);    opt.bands    = 1:size(D.vd_fr,1); end

    % Fields the run must hold.
    for fl = {'ARs','Sigs','Aproj','keys','r2','data','vnames','vd_fr'}
        assert(isfield(D, fl{1}), 'ccdgv_extshare:missing', ...
            '%s not in this run -- it needs the data and estimation stages.', fl{1});
    end

    nvars  = size(D.data, 2);
    nb     = size(D.Aproj, 2);
    nlags  = nb / nvars;
    assert(nlags == fix(nlags), 'ccdgv_extshare:width', ...
        'Aproj is %d wide but the VAR has %d variables', nb, nvars);
    ndall  = numel(D.ARs);                       % ndraws + 1
    if isempty(opt.draws); opt.draws = 1:(ndall-1); end
    ndr = numel(opt.draws);

    % Rows requested; they must be data rows.
    idx = var_order(D.vnames, names{:});  idx = idx(:)';
    nr  = numel(idx);
    assert(all(idx <= size(D.Aproj,1)), 'ccdgv_extshare:constructedRow', ...
        ['%s is a CONSTRUCTED row of A, not a projected data series. Those are ' ...
         'exact algebra on the state and have no residual of their own -- they ' ...
         'inherit their inputs''. Name the data rows instead.'], ...
        strjoin(names(idx > size(D.Aproj,1)), ', '));
    % Projection rows per draw. A run that drew its first stage stores
    % Aproj_draw, one page per draw with the posterior mean last; otherwise
    % there is a single page.
    hasD = isfield(D,'Aproj_draw') && ~isempty(D.Aproj_draw) && ndims(D.Aproj_draw) == 3;
    Asel = D.Aproj(idx, :);
    if hasD; Apg = D.Aproj_draw(idx,:,:); else; Apg = repmat(Asel, 1, 1, 1); end

    % Residual model, per row. One AR(p) gives both the FEV path and the
    % spectral density; p = 0 is white noise.
    hasU = isfield(D,'Ures') && ~isempty(D.Ures) && size(D.Ures,2) >= max(idx);
    Yl   = local_state(D.data, nlags);
    U    = repmat(struct('source','', 'phi',[], 's2e',0, 'varu',0, 'n',0, ...
                         'varu_r2',NaN), 1, nr);
    for k = 1:nr
        i  = idx(k);
        % V(xhat) on the projection's own sample, from the blocks the row uses.
        nzb = find(any(reshape(D.Aproj(i,:), nvars, nlags) ~= 0, 1), 1, 'last');
        if isempty(nzb); nzb = nlags; end
        xh = Yl(:,1:nvars*nzb) * D.Aproj(i,1:nvars*nzb)';
        if isfield(D,'Ures') && size(D.Ures,2) >= i
            msk = isfinite(xh) & isfinite(D.Ures(:,i));
        else
            msk = isfinite(xh);
        end
        vh = var(xh(msk));

        if abs(D.r2(i) - 1) < 1e-8
            U(k).source = 'inVAR';  U(k).phi = [];  U(k).s2e = 0;  U(k).varu = 0;
            continue
        end
        % Var(u) implied by r2: r2 = Var(xhat)/Var(x) for OLS with a constant.
        U(k).varu_r2 = vh * (1/D.r2(i) - 1);

        % Fit an AR to the longest run of the stored residual, if there is one.
        u = [];
        if hasU; u = local_longest(D.Ures(:,i)); end
        if numel(u) > 4*opt.arlags + 10
            [U(k).phi, U(k).s2e] = local_arfit(u, opt.arlags);
            U(k).varu   = var(u);
            U(k).n      = numel(u);
            U(k).source = 'residual';
            % Warn if the two measures of Var(u) are more than 5% apart.
            if isfinite(U(k).varu_r2) && U(k).varu_r2 > 0
                rel = abs(U(k).varu - U(k).varu_r2) / U(k).varu_r2;
                if rel > 0.05
                    warning('ccdgv_extshare:resMismatch', ...
                        ['%s: Var(u) is %.4g from the stored residual but %.4g ' ...
                         'from r2 and Var(xhat) (%.1f%% apart). Ures may be ' ...
                         'from a different run than r2.'], ...
                        D.vnames{i}, U(k).varu, U(k).varu_r2, 100*rel);
                end
            end
        else
            % No usable residual: white noise with the variance implied by r2.
            U(k).phi = zeros(0,1);  U(k).varu = U(k).varu_r2;
            U(k).s2e = U(k).varu_r2;  U(k).source = 'r2';
        end
    end

    % Residual variance at each horizon and over each band, per draw. A run that
    % drew its first stage supplies the AR coefficients (proj_phi) and the draws
    % of the innovation variance (proj_s2draw).
    nh  = numel(opt.horizons);
    nbd = numel(opt.bands);
    fev_u  = NaN(nr, nh, ndr);
    band_u = NaN(nr, nbd, ndr);
    hasS = hasD && isfield(D,'proj_s2draw') && ~isempty(D.proj_s2draw) ...
                && isfield(D,'proj_phi') && ~isempty(D.proj_phi);
    PH = {};
    if hasS; PH = D.proj_phi; if iscell(PH) && numel(PH) == 1 && iscell(PH{1}); PH = PH{1}; end; end
    for k = 1:nr
        i = idx(k);
        phik = U(k).phi;  s2k = U(k).s2e * ones(1, ndr);
        if hasS && i <= size(D.proj_s2draw,1) && any(isfinite(D.proj_s2draw(i,:)))
            if i <= numel(PH) && ~isempty(PH{i}); phik = PH{i}; end
            sj = D.proj_s2draw(i, :);
            s2k = sj(min(opt.draws, numel(sj)));
            U(k).source = 'drawn';
        end
        f0 = local_fev_ar(phik, 1, opt.horizons);          % unit innovation variance
        b0 = zeros(1, nbd);
        for m = 1:nbd
            b0(m) = local_band_ar(phik, 1, D.vd_fr(opt.bands(m),:), opt.M);
        end
        fev_u(k,:,:)  = f0(:) * s2k;                       % both are linear in s2e
        band_u(k,:,:) = b0(:) * s2k;
    end

    % Variance of the projected series at each horizon and over each band, per draw.
    fev_x  = NaN(nr, nh,  ndr);
    band_x = NaN(nr, nbd, ndr);
    targ   = zeros(1, nvars);            % vdfilter's target; Ve is not used here, only diag(Vy)
    for q = 1:ndr
        j  = opt.draws(q);
        B  = companion_form(D.ARs{j});
        C  = zeros(nb, nvars);
        C(1:nvars, 1:nvars) = chol(D.Sigs{j})';
        Aq = Apg(:,:,min(j, size(Apg,3)));
        fev_x(:,:,q)  = local_fev_model(Aq, B, C, opt.horizons);
        for m = 1:nbd
            Vy = vdfilter(B, C, targ, D.vd_fr(opt.bands(m),:), Aq, opt.M);
            band_x(:,m,q) = diag(Vy);
        end
    end

    % Factors, and a record of how they were computed.
    E = struct();
    E.names     = names(:)';
    E.keys      = D.keys(idx);
    E.idx       = idx;
    E.r2        = D.r2(idx);
    E.horizons  = opt.horizons;
    E.bands     = opt.bands;
    E.band_lam  = D.vd_fr(opt.bands, :);
    E.fev_xhat  = fev_x;    E.fev_u  = fev_u;
    E.band_xhat = band_x;   E.band_u = band_u;
    E.fac_fev   = fev_x  ./ (fev_x  + fev_u);
    E.fac_band  = band_x ./ (band_x + band_u);
    E.drawn     = hasD;
    E.source    = {U.source};
    E.varu      = [U.varu];
    E.arlags    = cellfun(@numel, {U.phi});
    E.ndraws    = ndr;

    % A sentence describing the residual model, for a table note.
    src = unique(E.source(~strcmp(E.source,'inVAR')));
    if isempty(src)
        E.note = 'every row is in the VAR; the factor is 1 by construction.';
    elseif isequal(src, {'residual'})
        E.note = sprintf(['the residual''s own AR(%d) spectrum and FEV path; ' ...
                          'nothing assumed about its serial correlation.'], opt.arlags);
    elseif isequal(src, {'r2'})
        E.note = ['this run did not store the projection residual, so Var(u) ' ...
                  'is recovered from r2 and spread across horizons and bands ' ...
                  'AS WHITE NOISE. Re-run to drop that assumption.'];
    else
        E.note = ['mixed: some rows use the stored residual''s own spectrum, ' ...
                  'others a white-noise residual recovered from r2 (see .source).'];
    end
end

function Yl = local_state(Y, nlags)
%LOCAL_STATE  The companion state, column order as CCDGV_PROJECT builds it.
    Yl = lagmatrix(Y, 0:nlags-1);
end

function u = local_longest(col)
%LOCAL_LONGEST  The longest run of consecutive finite values.
%   An AR fit needs contiguous observations.
    ok = isfinite(col(:))';
    if ~any(ok); u = []; return; end
    d  = diff([0 ok 0]);
    s  = find(d == 1);  e = find(d == -1) - 1;
    [~, w] = max(e - s);
    u = col(s(w):e(w));
end

function [phi, s2e] = local_arfit(u, p)
%LOCAL_ARFIT  OLS AR(p) with a constant; returns the AR coefficients and the
%   innovation variance. p is reduced if the sample cannot support it.
    u = u(:);
    p = min(p, floor((numel(u) - 10)/4));
    if p < 1; phi = zeros(0,1); s2e = var(u); return; end
    T = numel(u);
    X = ones(T-p, p+1);
    for l = 1:p; X(:,l) = u(p+1-l : T-l); end
    y = u(p+1:T);
    b = X \ y;
    phi = b(1:p);
    e   = y - X*b;
    s2e = sum(e.^2) / (numel(e) - p - 1);
end

function f = local_fev_ar(phi, s2e, horizons)
%LOCAL_FEV_AR  FEV of an AR(p) at each horizon: s2e * sum_{k<h} theta_k^2.
%   theta are the MA coefficients of 1/phi(L), from the recursion
%   theta_k = sum_j phi_j theta_{k-j}. With p = 0 every FEV equals s2e.
    hmax = max(horizons);
    th   = zeros(hmax, 1);  th(1) = 1;
    p    = numel(phi);
    for k = 2:hmax
        for j = 1:min(p, k-1)
            th(k) = th(k) + phi(j)*th(k-j);
        end
    end
    c = cumsum(th.^2);
    f = s2e * c(horizons)';
end

function v = local_band_ar(phi, s2e, lam, M)
%LOCAL_BAND_AR  Variance of an AR(p) over the band [lam(1), lam(2)], on
%   VDFILTER's normalisation: v = (1/pi) int s2e/|phi(e^{-iw})|^2 dw.
%   Uses VDFILTER's quadrature: log-spaced nodes with trapezoid weights.
    if isempty(phi)
        v = s2e * (lam(2) - lam(1)) / pi;     % white noise, in closed form
        return
    end
    g = logspace(log10(lam(1)), log10(lam(2)), M);
    w        = zeros(1, M);
    w(2:M-1) = (g(3:M) - g(1:M-2))/2;
    w(1)     = (g(2) - g(1))/2;
    w(M)     = (g(M) - g(M-1))/2;
    z  = exp(-1i*g(:));
    ph = ones(M, 1);
    for j = 1:numel(phi); ph = ph - phi(j)*z.^j; end
    v = (1/pi) * sum(w(:) .* (s2e ./ abs(ph).^2));
end

function F = local_fev_model(Asel, B, C, horizons)
%LOCAL_FEV_MODEL  Total FEV of each row of Asel at each horizon: the sum over
%   k = 1..h of sum((Asel*B^(k-1)*C).^2, 2), the denominator MAXSHR uses.
    hmax = max(horizons);
    Psi  = C;
    acc  = zeros(size(Asel,1), 1);
    F    = NaN(size(Asel,1), numel(horizons));
    for k = 1:hmax
        acc = acc + sum((Asel*Psi).^2, 2);
        hit = find(horizons == k);
        for q = hit(:)'; F(:,q) = acc; end
        Psi = B*Psi;
    end
    assert(~any(isnan(F(:))), 'ccdgv_extshare:horizon', ...
        'a requested horizon exceeds %d', hmax);
end
