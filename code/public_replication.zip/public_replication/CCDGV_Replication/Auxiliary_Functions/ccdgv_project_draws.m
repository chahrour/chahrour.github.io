function [Aproj_draw, rec, s2draw, phi, r2_pm, summary] = ...
        ccdgv_project_draws(yall, dataL, Aproj, r2, projblocks, manifest, S)
%CCDGV_PROJECT_DRAWS  Draw the first stage: posterior draws of every projected row.
%
%   [Aproj_draw, rec, s2draw, phi, r2_pm, summary] = ...
%       ccdgv_project_draws(yall, dataL, Aproj, r2, projblocks, manifest, S)
%
%   yall        T x nvall data, one column per manifest row.
%   dataL       T x nvars levels of the VAR, the basis the state is built from.
%   Aproj       nvall x nvars*nlags point-estimate rows from CCDGV_PROJECT.
%   r2          1 x nvall R-squared of those rows; 1 marks a series in the VAR.
%   projblocks  1 x nvall state blocks each row is projected on.
%   manifest    data rows of CCDGV_MANIFEST: key, seed and projlambda per row.
%   S           run settings: nlags, ndraws, proj_prior and proj_seed_base.
%
%   Aproj_draw  nvall x nvars*nlags x (ndraws+1). Page j pairs with VAR draw j;
%               the last page is the posterior mean. Rows in the VAR are not
%               drawn and keep their unit vector. With proj_prior.draw false,
%               every page is a copy of Aproj.
%   rec         1 x nvall cell of CCDGV_PROJECT_DRAW's fit records.
%   s2draw      nvall x ndraws innovation variance per draw, and
%   phi         1 x nvall cell of AR coefficients: the residual process of each
%               drawn row, which CCDGV_EXTSHARE uses.
%   r2_pm       1 x nvall R-squared at the posterior mean. It differs from r2,
%               the OLS fit: the draw is GLS under AR errors, on the longest
%               contiguous run of usable rows.
%   summary     '%d of %d projected rows', for info.settings.proj_draw_summary.
%
%   Each row is seeded with rng(proj_seed_base + manifest(j).seed), so adding or
%   removing a row does not shift the draws of the others. The draws are
%   independent of the VAR draws.
%
%   See also CCDGV_PROJECT_DRAW, CCDGV_PROJECT, ESTIMATE_ONE.

    PP = S.proj_prior;  nlags = S.nlags;  ndraws = S.ndraws;
    nvall = size(yall, 2);

    Aproj_draw = repmat(Aproj, 1, 1, ndraws+1);
    rec     = cell(1, nvall);
    s2draw  = NaN(nvall, ndraws);
    phi     = cell(1, nvall);
    r2_pm   = NaN(1, nvall);
    summary = '';
    if ~PP.draw; return; end

    todraw = r2 < 1 - 1e-8;              % rows in the VAR are never drawn
    Yl     = lagmatrix(dataL, 0:nlags-1);
    ndrawn = 0;
    for jj = find(todraw)
        rng(S.proj_seed_base + manifest(jj).seed, 'twister');
        % Row-specific shrinkage, where the manifest sets it.
        PPj = PP;
        if ~isempty(manifest(jj).projlambda); PPj.lambda = manifest(jj).projlambda; end
        [Adj, amj, recj, s2j] = ccdgv_project_draw(yall(:,jj), dataL, nlags, ...
                                                   projblocks(jj), PPj, ndraws);
        if ~recj.ok
            fprintf('  %-16s too short to draw (%d obs); kept at the point estimate\n', ...
                    manifest(jj).key, recj.n);
            continue
        end
        Aproj_draw(jj,:,1:ndraws) = permute(Adj, [3 2 1]);
        Aproj_draw(jj,:,end)      = amj;
        s2draw(jj,:) = s2j(:)';  phi{jj} = recj.phi;  rec{jj} = recj;
        % R-squared of the posterior-mean fit.
        xj = yall(:,jj);
        mj = all(isfinite(Yl),2) & isfinite(xj);
        uj = xj(mj) - Yl(mj,:)*amj';
        r2_pm(jj) = 1 - sum((uj - mean(uj)).^2) / sum((xj(mj) - mean(xj(mj))).^2);
        ndrawn = ndrawn + 1;
    end
    summary = sprintf('%d of %d projected rows', ndrawn, sum(todraw));

    for jj = find(arrayfun(@(m) ~isempty(m.projlambda), manifest))
        fprintf('  %-16s first stage shrunk at lambda %g (row setting)\n', ...
                manifest(jj).key, manifest(jj).projlambda);
    end
    if PP.free_block0; b0 = 'free'; else; b0 = 'penalised'; end
    if isempty(PP.phi_sd); ph = 'fixed'; else; ph = sprintf('sampled, prior sd %g', PP.phi_sd); end
    fprintf('  first stage DRAWN for %d of %d rows (lambda %g, decay %g, AR(%d) errors with phi %s, block 0 %s)\n', ...
            ndrawn, sum(todraw), PP.lambda, PP.decay, PP.arlags, ph, b0);
end
