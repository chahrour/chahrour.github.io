function [Adraw, amean, rec, s2draw] = ccdgv_project_draw(x, Y, nlags, blocks, prior, ndraws)
%CCDGV_PROJECT_DRAW  Posterior draws of a projection row.
%
%   [Adraw, amean, rec, s2draw] = ccdgv_project_draw(x, Y, nlags, blocks, prior, ndraws)
%
%   x       the series, as CCDGV_PROJECT takes it.
%   Y       the levels data the companion state is built from.
%   nlags   VAR lag order.
%   blocks  number of companion-state blocks to project on (default nlags).
%   prior   struct with lambda, decay, free_block0 and arlags (cfg.proj in CONFIG).
%   ndraws  number of posterior draws.
%
%   Adraw   ndraws x nvars*nlags, each row a draw of the projection coefficients
%           in the raw companion-state units CCDGV_PROJECT returns.
%   amean   1 x nvars*nlags posterior mean.
%   rec     record of the fit: lambda, decay, phi, s2, effective lag degrees of
%           freedom, sample size, and ok. ok is false when the sample is too
%           short, in which case Adraw and amean are zero.
%   s2draw  ndraws x 1 draws of the residual innovation variance.
%
%   The series is regressed on the standardised state with AR(arlags) errors.
%   The AR coefficients phi are estimated from the residual and plugged in, and
%   the draws are GLS given phi. Block i (i = 1 is the contemporaneous block)
%   has penalty weight lambda * i^(2*decay); with free_block0 the
%   contemporaneous block is unpenalised and block k+1 has weight
%   lambda * k^(2*decay).
%
%   The draws are independent of the VAR draws. RUN_MAIN calls this only for
%   rows outside the VAR (r2 < 1).
%
%   See also CCDGV_PROJECT, RUN_MAIN, CCDGV_EXTSHARE.

    if nargin < 4 || isempty(blocks); blocks = nlags; end
    p = prior.arlags;
    assert(prior.lambda >= 0 && prior.decay >= 0, 'ccdgv_project_draw:prior', ...
        'lambda = %g, decay = %g; both must be >= 0', prior.lambda, prior.decay);

    % Regressors: the first `blocks` blocks of the companion state.
    x  = x(:);
    nv = size(Y, 2);
    W  = nv*nlags;                       % full row width, as ccdgv_project
    Yl = lagmatrix(Y, 0:blocks-1);
    nb = size(Yl, 2);

    % Estimation sample: the longest contiguous run of complete rows, because
    % the AR error model needs consecutive observations.
    ok = all(isfinite(Yl), 2) & isfinite(x);
    d  = diff([0 ok(:)' 0]);  s = find(d == 1);  e = find(d == -1) - 1;
    [~, w] = max(e - s);
    rows = s(w):e(w);
    n = numel(rows);
    Adraw = zeros(ndraws, W);  amean = zeros(1, W);
    rec = struct('lambda',prior.lambda, 'decay',prior.decay, ...
                 'free_block0',prior.free_block0, 'arlags',p, 'n',n, ...
                 'phi',zeros(p,1), 's2',NaN, 'edf_lag',NaN, 'ok',false);
    if n <= nb + 4*p + 10; return; end   % too short: leave zeros, rec.ok false

    % Standardise the regressors and centre x.
    S  = Yl(rows,:);  xs = x(rows);
    mu = mean(S,1);  sd = std(S,0,1);
    assert(all(sd > 0), 'ccdgv_project_draw:constantColumn', ...
           'a state column is constant over the sample; cannot standardise it');
    Z  = (S - mu) ./ sd;  xc = xs - mean(xs);

    % Penalty weights, by block.
    wgt = zeros(1, nb);
    for k = 0:blocks-1
        cols = k*nv + (1:nv);
        if prior.free_block0
            if k > 0; wgt(cols) = prior.lambda * k^(2*prior.decay); end
        else
            wgt(cols) = prior.lambda * (k+1)^(2*prior.decay);
        end
    end
    Lam = diag(wgt);

    % Plug-in AR(p), then GLS, in two passes: phi is fitted first to the
    % unpenalised residual, then to the residual of the penalised fit.
    bo  = (Z'*Z + 1e-10*eye(nb)) \ (Z'*xc);
    phi = local_ar(xc - Z*bo, p);
    for pass = 1:2
        [Zt, xt] = local_qd(Z, xc, phi);
        nt = size(Zt,1);
        % The prior precision scales with nt, the rows left after
        % quasi-differencing.
        M  = Zt'*Zt + nt*Lam;
        M  = (M + M')/2;
        bm = M \ (Zt'*xt);
        if pass == 1; phi = local_ar(xc - Z*bm, p); end
    end
    ee = xt - Zt*bm;

    % Marginal posterior of sigma^2 with b integrated out:
    %     s2 | x ~ InvGamma(df/2, S/2),  S = ee'ee + bm'(nt*Lam)bm,
    %     df = nt - (number of unpenalised coefficients).
    nfree = sum(diag(Lam) == 0);
    dfk   = max(nt - nfree, 1);
    Ssq   = ee'*ee + bm'*(nt*Lam)*bm;
    s2    = Ssq / dfk;

    % Draws: s2 from its marginal, then b | s2 ~ N(bm, s2 M^{-1}).
    s2draw = Ssq ./ chi2rnd(dfk, ndraws, 1);
    Minv = M \ eye(nb);  Minv = (Minv + Minv')/2;
    L = chol(Minv, 'lower');
    bd = bm' + sqrt(s2draw) .* (randn(ndraws, nb) * L');

    % Back to raw companion-state units, zero-padded as in ccdgv_project.
    Adraw(:, 1:nb) = bd ./ sd;
    amean(1:nb)    = (bm ./ sd')';
    rec.phi = phi;  rec.s2 = s2;  rec.df = dfk;  rec.ok = true;
    % Effective degrees of freedom of the penalised coefficients, with the
    % unpenalised block projected off.
    pen = wgt > 0;  fre = ~pen;
    if any(pen)
        Zp = Zt(:,pen);
        if any(fre)
            Z0 = Zt(:,fre);
            Zp = Zp - Z0*((Z0'*Z0) \ (Z0'*Zp));
        end
        rec.edf_lag = sum(sum(Zp .* (M(pen,pen) \ Zp')'));
    else
        rec.edf_lag = 0;
    end
end

function phi = local_ar(u, p)
%LOCAL_AR  OLS AR(p) on a contiguous residual, no constant (u is demeaned).
    u = u(:);  T = numel(u);
    U = zeros(T-p, p);
    for l = 1:p; U(:,l) = u(p+1-l : T-l); end
    phi = U \ u(p+1:T);
end

function [Zt, xt] = local_qd(Z, x, phi)
%LOCAL_QD  Quasi-difference by the AR polynomial: w_t - sum_l phi_l w_{t-l}.
    p = numel(phi);  n = size(Z,1);
    Zt = Z(p+1:n,:);  xt = x(p+1:n);
    for l = 1:p
        Zt = Zt - phi(l)*Z(p+1-l:n-l,:);
        xt = xt - phi(l)*x(p+1-l:n-l);
    end
end
