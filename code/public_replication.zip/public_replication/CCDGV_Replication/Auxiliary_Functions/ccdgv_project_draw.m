function [Adraw, amean, rec, s2draw] = ccdgv_project_draw(x, Y, nlags, blocks, prior, ndraws)
%CCDGV_PROJECT_DRAW  Posterior draws of a projection row, for first-stage bands.
%
%   [Adraw, amean, rec] = CCDGV_PROJECT_DRAW(x, Y, nlags, blocks, prior, ndraws)
%
%   x       the series, as CCDGV_PROJECT takes it
%   Y       the LEVELS data the companion state is built from
%   blocks  companion-state blocks, as CCDGV_PROJECT (the row's projblocks)
%   prior   .lambda, .decay, .free_block0, .arlags  (see CONFIG's proj_prior)
%   ndraws  number of posterior draws
%
%   Adraw   ndraws x nvars*nlags, each row a draw of the projection coefficients
%           in the RAW companion-state units CCDGV_PROJECT returns
%   amean   1 x nvars*nlags, the posterior mean -- the point estimate that goes
%           on the appended page, so the stored system is a rank-consistent
%           object and not an average of draws
%   rec     what the run should record: lambda, decay, phi, s2, effective lag
%           degrees of freedom, the estimation sample size
%   s2draw  ndraws x 1 draws of the residual innovation variance. CCDGV_EXTSHARE
%           needs these: the residual's contribution to a forecast-error or band
%           variance must come from the MODEL's own sigma^2, not from the
%           in-sample variance of x - Yl*a_j, which adds the estimation error
%           (a_j - a)'S(a_j - a) and is one-sided by construction.
%
% WHY DRAW AT ALL. The VAR side of every auxiliary IRF is drawn and the
% projection is not, so the reported bands contain no first-stage uncertainty --
% and the first stage is where the estimate is weakest (32 collinear regressors
% on ~116 observations). Conditioning on the state factorises the likelihood, so
% these draws are INDEPENDENT of the VAR's: draw j of a pairs with draw j of the
% VAR and the two sources of uncertainty combine by convolution. No covariance
% term, and nothing is re-estimated.
%
% THE PRIOR. On STANDARDISED regressors, the coefficient on block i (i = 1 for
% the contemporaneous block) has prior sd proportional to 1/i^decay:
%
%     penalty weight  w_i = lambda * i^(2*decay),   b ~ N(0, s2/(n*w_i))
%
% decay = 1 is Litterman's harmonic decay, matching MINNEPRC's lambda3.
%
% THE LIMITS ARE GLS, NOT OLS. With free_block0, lambda -> 0 gives GLS on all
% four blocks and lambda -> inf gives GLS on the contemporaneous block alone.
% Those are the GLS analogues of CONFIG's `ols4` and `ols1`, not those
% variants themselves: the quasi-differencing by phi is always on, and with
% residual autocorrelation up to 0.73 the two differ by 18-71% in coefficient
% norm. So this is a continuum BETWEEN GLS ANALOGUES of the four variants, and
% the variants remain a separate, point-estimate exhibit.
%
% THE RESIDUAL. u is serially correlated (first autocorrelation up to 0.73 on
% these rows), so the draws use GLS under an AR(p) error model. phi is PLUGGED
% IN from the OLS residual rather than sampled: sampling it jointly drifts to
% the stationarity boundary (sum phi 0.95-0.99 against an OLS 0.47-0.67), the
% quasi-differencing then removes the level relationship, and the response
% collapses. That is a modelling choice, not a detail -- see
% Notes/projection_step.md.
%
% A ROW IN THE VAR IS NEVER DRAWN. OLS returns its exact unit vector; a prior
% would shrink it. RUN_MAIN calls this only for rows with r2 < 1.
%
%   See also CCDGV_PROJECT, RUN_MAIN, CCDGV_EXTSHARE.

    if nargin < 4 || isempty(blocks); blocks = nlags; end
    p = prior.arlags;
    % lambda only binds the LAG blocks when free_block0 is set, and a row
    % projected on the contemporaneous block alone has no penalised coefficient
    % at all -- there the posterior is plain GLS and is proper because nt > nb.
    assert(prior.lambda >= 0 && prior.decay >= 0, 'ccdgv_project_draw:prior', ...
        'lambda = %g, decay = %g; both must be >= 0', prior.lambda, prior.decay);

    x  = x(:);
    nv = size(Y, 2);
    W  = nv*nlags;                       % full row width, as ccdgv_project
    Yl = lagmatrix(Y, 0:blocks-1);
    nb = size(Yl, 2);

    % ---- estimation sample: the LONGEST CONTIGUOUS run ---------------------
    % The AR error model needs consecutive observations, and coverage is ragged
    % (patent_app starts 1981, the GFD yields stop short). Taking the longest
    % run is explicit about which stretch was used; ccdgv_extshare does the same
    % for the residual it fits.
    ok = all(isfinite(Yl), 2) & isfinite(x);
    d  = diff([0 ok(:)' 0]);  s = find(d == 1);  e = find(d == -1) - 1;
    [~, w] = max(e - s);
    rows = s(w):e(w);
    n = numel(rows);
    Adraw = zeros(ndraws, W);  amean = zeros(1, W);
    rec = struct('lambda',prior.lambda, 'decay',prior.decay, ...
                 'free_block0',prior.free_block0, 'arlags',p, 'n',n, ...
                 'phi',zeros(p,1), 's2',NaN, 'edf_lag',NaN, 'ok',false);
    if n <= nb + 4*p + 10; return; end   % too short: leave zeros, rec.ok false

    S  = Yl(rows,:);  xs = x(rows);
    mu = mean(S,1);  sd = std(S,0,1);
    assert(all(sd > 0), 'ccdgv_project_draw:constantColumn', ...
           'a state column is constant over the sample; cannot standardise it');
    Z  = (S - mu) ./ sd;  xc = xs - mean(xs);

    % ---- penalty weights, by block ----------------------------------------
    wgt = zeros(1, nb);
    for k = 0:blocks-1
        cols = k*nv + (1:nv);
        if prior.free_block0
            if k > 0; wgt(cols) = prior.lambda * k^(2*prior.decay); end
        else
            wgt(cols) = prior.lambda * (k+1)^(2*prior.decay);
        end
    end
    Lam = diag(wgt);

    % ---- plug-in AR(p), then GLS -------------------------------------------
    % TWO PASSES. The first phi comes from the unpenalised OLS residual, which
    % overfits 32 collinear regressors on ~116 observations and so understates
    % the persistence the PENALISED fit actually leaves behind (sum phi 0.19-0.67
    % against 0.48-0.88 once refitted). The second pass refits phi on the
    % posterior mean's own residual, which is the process the draws assume. The
    % prototype did this; production dropped it.
    bo  = (Z'*Z + 1e-10*eye(nb)) \ (Z'*xc);
    phi = local_ar(xc - Z*bo, p);
    for pass = 1:2
        [Zt, xt] = local_qd(Z, xc, phi);
        nt = size(Zt,1);
        % lambda is a shrinkage FRACTION: ccdgv_project's ridge solves
        % (Z'Z/n + lambda I), so the prior precision scales with the number of
        % rows in the regression -- which after quasi-differencing is nt, not n.
        M  = Zt'*Zt + nt*Lam;
        M  = (M + M')/2;
        bm = M \ (Zt'*xt);
        if pass == 1; phi = local_ar(xc - Z*bm, p); end
    end
    ee = xt - Zt*bm;

    % ---- the marginal posterior of sigma^2 ---------------------------------
    % b | s2 ~ N(0, s2 (nt*Lam)^{-1}) on the PENALISED block and flat on the
    % free one, Jeffreys on s2. Integrating b out:
    %     s2 | x ~ InvGamma(df/2, S/2),  S = xt'xt - bm'M bm = ee'ee + bm'(nt*Lam)bm
    %     df = nt - (number of UNPENALISED coefficients)
    % Not ee'ee and nt - nb: a proper prior on a coefficient buys back a degree
    % of freedom, and the penalty term belongs in the sum of squares. Using the
    % OLS pair made every draw of a 4-block row about 12% too wide.
    nfree = sum(diag(Lam) == 0);
    dfk   = max(nt - nfree, 1);
    Ssq   = ee'*ee + bm'*(nt*Lam)*bm;
    s2    = Ssq / dfk;

    % ---- draws: s2 from its marginal, then a | s2 ~ N(bm, s2 M^{-1}) -------
    s2draw = Ssq ./ chi2rnd(dfk, ndraws, 1);
    Minv = M \ eye(nb);  Minv = (Minv + Minv')/2;
    L = chol(Minv, 'lower');
    bd = bm' + sqrt(s2draw) .* (randn(ndraws, nb) * L');

    % ---- back to the raw companion state, zero-padded as ccdgv_project ------
    Adraw(:, 1:nb) = bd ./ sd;
    amean(1:nb)    = (bm ./ sd')';
    rec.phi = phi;  rec.s2 = s2;  rec.df = dfk;  rec.ok = true;
    % effective lag df, with the free block projected off -- the quantity
    % Notes/projection_step.md tabulates, and without forming an nt x nt matrix
    pen = wgt > 0;  fre = ~pen;
    if any(pen)
        Zp = Zt(:,pen);
        if any(fre)
            Z0 = Zt(:,fre);
            Zp = Zp - Z0*((Z0'*Z0) \ (Z0'*Zp));
        end
        rec.edf_lag = sum(sum(Zp .* (M(pen,pen) \ Zp')'));
    else
        rec.edf_lag = 0;
    end
end

% -------------------------------------------------------------------------
function phi = local_ar(u, p)
%LOCAL_AR  OLS AR(p) on a contiguous residual, no constant (u is demeaned).
    u = u(:);  T = numel(u);
    U = zeros(T-p, p);
    for l = 1:p; U(:,l) = u(p+1-l : T-l); end
    phi = U \ u(p+1:T);
end

function [Zt, xt] = local_qd(Z, x, phi)
%LOCAL_QD  Quasi-difference by the AR polynomial: w_t - sum_l phi_l w_{t-l}.
    p = numel(phi);  n = size(Z,1);
    Zt = Z(p+1:n,:);  xt = x(p+1:n);
    for l = 1:p
        Zt = Zt - phi(l)*Z(p+1-l:n-l,:);
        xt = xt - phi(l)*x(p+1-l:n-l);
    end
end
