function m = ccdgv_id_meta(D, k)
%CCDGV_ID_META  Identification pass k's cfg out of a saved run. Resolved BY LABEL.
%
%   m = CCDGV_ID_META(D, k)
%
%   D  a loaded case .mat (or any struct carrying id_meta and, ideally, info)
%   k  which identification pass: 1 = Table 1, 2 = Table B.4, 3 = Table B.5
%   m  that pass's cfg struct (shock_extract, KLbar, KUbar, ...), or [] if the
%      run does not carry it
%
%   WHY THIS EXISTS. run_main writes
%
%       id_meta.(matlab.lang.makeValidName(info.ident(k).label)) = Rall{k}.cfg
%
%   so the FIELD NAMES ARE THE LABELS -- 'baseline_FEV100', 'AF_2_1000',
%   'HF_6_32' -- and they change whenever config's `idents` list is edited.
%   Both table writers were asking for 'main', 'AF' and 'HF', the names of their
%   own SPEC keys, which have never been id_meta's field names.
%
%   THE LOOKUPS WERE isfield-GUARDED, so this failed silently: no error, no
%   warning, the provenance line simply came out without the identification
%   target. Tables 1, B.1 and B.2 are the SAME statistic under three different
%   targets, and the target was the one thing their notes did not state -- so the
%   three were indistinguishable from their provenance alone. Caught 2026-08-19
%   by reading generated tables in Figures_Tables_temp, not by any test.
%
%   ORDER, NOT NAME, IS THE STABLE THING. A pass's position in info.ident is
%   what the writers mean by "pass 1"; its label is free text. So the index is
%   the argument and the label is looked up from info.ident(k), with a fallback
%   to the k-th non-'note' field for runs saved before info carried ident.
%
%   RETURNS [] RATHER THAN ERRORING. A caller uses this for a provenance note,
%   never for a number, and a run legitimately may not have run pass k -- see
%   info.idrun. Callers should test isempty and omit the note.
%
%   See also WRITE_UHLIG_TABLES, RUN_MAIN, ID_CFG.

    m = [];
    if nargin < 2 || isempty(k); k = 1; end
    if ~isfield(D,'id_meta') || ~isstruct(D.id_meta); return; end

    f = setdiff(fieldnames(D.id_meta)', {'note'}, 'stable');
    if isempty(f); return; end

    if isfield(D,'info') && isfield(D.info,'ident') && numel(D.info.ident) >= k
        want = matlab.lang.makeValidName(D.info.ident(k).label);
        if ismember(want, f); m = D.id_meta.(want); end
    end
    if isempty(m) && k <= numel(f)
        % Pre-ident runs, or a label that no longer matches what was saved.
        % Positional, so it is right only when every pass ran: with idrun = [1 3]
        % the second surviving field is pass 3, not pass 2. Hence the label
        % lookup above is the primary path and this is the fallback.
        m = D.id_meta.(f{k});
    end
    if ~isstruct(m) || ~isfield(m,'shock_extract'); m = []; end
end
