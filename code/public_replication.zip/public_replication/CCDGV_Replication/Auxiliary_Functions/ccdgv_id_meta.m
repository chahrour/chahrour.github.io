function m = ccdgv_id_meta(D, k)
%CCDGV_ID_META  Settings of identification pass k from a saved run.
%
%   m = ccdgv_id_meta(D, k)
%
%   D  a loaded run file (a struct with id_meta and, usually, info).
%   k  identification pass: 1 = Table 1, 2 = Table C.4, 3 = Table C.5 (default 1).
%   m  that pass's cfg struct (shock_extract, KLbar, KUbar, ...), or [] if the
%      run does not carry it.
%
%   The fields of id_meta are named by the pass labels, so the label is looked
%   up from info.ident(k). Callers use the result for a provenance note only and
%   should omit the note when m is empty.
%
%   See also WRITE_UHLIG_TABLES, RUN_MAIN, ID_CFG.

    m = [];
    if nargin < 2 || isempty(k); k = 1; end
    if ~isfield(D,'id_meta') || ~isstruct(D.id_meta); return; end

    f = setdiff(fieldnames(D.id_meta)', {'note'}, 'stable');
    if isempty(f); return; end

    if isfield(D,'info') && isfield(D.info,'ident') && numel(D.info.ident) >= k
        want = matlab.lang.makeValidName(D.info.ident(k).label);
        if ismember(want, f); m = D.id_meta.(want); end
    end
    if isempty(m) && k <= numel(f)
        % Fallback when info has no matching label: the k-th field. This is
        % right only when every pass ran.
        m = D.id_meta.(f{k});
    end
    if ~isstruct(m) || ~isfield(m,'shock_extract'); m = []; end
end
