function Da = ccdgv_bvecm_data(D, Zd)
%CCDGV_BVECM_DATA  Villani data struct with a conjugate prior on Psi via dummy rows.
%
%   Da = CCDGV_BVECM_DATA(D, Zd)
%
%   D    a CLEAN struct from the library's vecm_data(x, k, 'const')
%   Zd   m x d dummy rows for Z. Y and X get m rows of ZEROS, so the prior is
%        vec Psi ~ N(0, Sigma (x) Omega0) with Omega0^{-1} = Zd'Zd. Built by
%        CCDGV_BVECM_MINN.
%
%   Da   the same struct with the moment matrices rebuilt from the AUGMENTED
%        (Y~, X~, Z~), the Johansen eigenproblem redone on them (gibbs_marginal
%        initialises from it), and
%
%            Da.T = D.T + m
%
%        Raw Y, X, Z are left UNTOUCHED (nothing on the Bayesian path reads
%        them); D.m_dummy and D.Zd record what was added.
%
% -------------------------------------------------------------------------
% WHY T CHANGES -- THIS CONTRADICTS Bayesian_VECM/HANDOFF.md:70, DELIBERATELY.
%
% The handoff says to change Z'Z, Z'Y, Z'X only and keep T at the real sample
% size. Under Villani's FLAT prior on Psi, integrating Psi out of the likelihood
% contributes |Sigma|^{+d/2}, which is why the library's rank_setup has
% nu0 = T + q - d. Under the PROPER prior N(0, Sigma (x) Omega0) the prior
% density itself carries |Sigma|^{-m/2} (one factor per shrunk row), which
% cancels m of those d. The |Sigma| exponent is therefore T + m - d + q, not
% T - d + q, and the dummy-observation trick with T -> T + m reproduces it
% exactly: the augmented likelihood has T + m rows and a flat prior, and its
% Psi-integral gives |Sigma|^{-(T+m-d)/2}.
%
% Leaving T alone is equivalent to keeping the proper prior on Psi and putting
% an improper |Sigma|^{+m/2} on top of IW(A, q) -- i.e. IW with q - m degrees
% of freedom, NEGATIVE at m = 24, q = 10. That is not a prior anyone chose,
% and because the factor multiplies |S_r|, which depends on r, it distorts
% p(r|D) rather than shifting every rank by the same constant. Verified by
% experiment (bvecm_hyperparameters.md §2): an independent uncollapsed
% Gibbs sampler and an independent conjugate Normal-IW marginal likelihood
% both agree with T + m and disagree with T.
%
% The |Omega0|^{-p/2} the proper prior also carries IS a constant across
% ranks and across (alpha, beta, Sigma), so dropping it -- which the trick
% does -- is harmless. Same for the |Z'Z|^{-p/2} the library drops already.
%
% With m < d (the constant left flat, as CCDGV_BVECM_MINN does) the library's
% arithmetic is already general: nu0 = T + m + q - d charges one degree of
% freedom for each direction still flat.
%
% Anything that reads raw Y, X, Z against T (the residuals in
% CCDGV_BVECM_DRAW) must be given the clean D.
%
%   See also CCDGV_BVECM_MINN, CCDGV_BVECM.

    [m, d] = size(Zd);
    assert(d == D.d, 'ccdgv_bvecm_data:width', ...
        'Zd has %d columns but D.Z has %d.', d, D.d);
    p = D.p;

    Y = [D.Y; zeros(m, p)];
    X = [D.X; zeros(m, p)];
    Z = [D.Z; Zd];
    T = D.T + m;

    Da = D;
    Da.T = T;  Da.m_dummy = m;  Da.Zd = Zd;

    % Exactly vecm_data's arithmetic on the augmented matrices. Forming the
    % partialled moments through the explicit projector is what makes the
    % cross terms right: Y'Y - Y'Z G^{-1} Z'Y is NOT (Y - Z G^{-1} Z'Y)'(...)
    % once G = Z'Z + Omega0^{-1} differs from Z'Z, but on the stacked matrices
    % the projector is exact.
    Da.ZZ = Z'*Z;  Da.ZZinv = inv(Da.ZZ);  Da.ZY = Z'*Y;  Da.ZX = Z'*X;
    My = Y - Z*(Da.ZZinv*Da.ZY);
    Mx = X - Z*(Da.ZZinv*Da.ZX);
    Da.YY = My'*My;  Da.XX = Mx'*Mx;  Da.XY = Mx'*My;

    S00 = Da.YY/T;  S11 = Da.XX/T;  S01 = Da.XY'/T;  S10 = S01';
    L11 = chol(S11, 'lower');  Li = inv(L11);
    M = Li*S10*(S00\S01)*Li';
    [V, lam] = eig((M + M')/2, 'vector');
    [lam, ord] = sort(lam, 'descend');
    Da.lam = lam;  Da.V = Li'*V(:, ord);
end
