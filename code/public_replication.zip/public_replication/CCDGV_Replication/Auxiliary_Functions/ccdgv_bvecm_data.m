function Da = ccdgv_bvecm_data(D, Zd)
%CCDGV_BVECM_DATA  Villani data struct with a conjugate prior on Psi via dummy rows.
%
%   Da = ccdgv_bvecm_data(D, Zd)
%
%   D    struct from the library's vecm_data(x, k, 'const').
%   Zd   m x d dummy rows for Z, built by CCDGV_BVECM_MINN. Y and X get m rows of
%        zeros, so the prior is vec Psi ~ N(0, Sigma (x) Omega0) with
%        Omega0^{-1} = Zd'Zd.
%
%   Da   D with the moment matrices and the Johansen eigenproblem rebuilt from
%        the augmented (Y, X, Z), and Da.T = D.T + m. The raw Y, X, Z are
%        unchanged; Da.m_dummy and Da.Zd record what was added.
%
%   T counts the dummy rows because the proper prior on Psi carries
%   |Sigma|^{-m/2}, which makes the |Sigma| exponent T + m - d + q. Code that
%   reads the raw Y, X, Z against T (the residuals in CCDGV_BVECM_DRAW) must be
%   given D, not Da.
%
%   See also CCDGV_BVECM_MINN, CCDGV_BVECM.

    [m, d] = size(Zd);
    assert(d == D.d, 'ccdgv_bvecm_data:width', ...
        'Zd has %d columns but D.Z has %d.', d, D.d);
    p = D.p;

    Y = [D.Y; zeros(m, p)];
    X = [D.X; zeros(m, p)];
    Z = [D.Z; Zd];
    T = D.T + m;

    Da = D;
    Da.T = T;  Da.m_dummy = m;  Da.Zd = Zd;

    % Moment matrices with Z partialled out, as vecm_data computes them, on the
    % augmented matrices.
    Da.ZZ = Z'*Z;  Da.ZZinv = inv(Da.ZZ);  Da.ZY = Z'*Y;  Da.ZX = Z'*X;
    My = Y - Z*(Da.ZZinv*Da.ZY);
    Mx = X - Z*(Da.ZZinv*Da.ZX);
    Da.YY = My'*My;  Da.XX = Mx'*Mx;  Da.XY = Mx'*My;

    % Johansen eigenproblem on the augmented moments.
    S00 = Da.YY/T;  S11 = Da.XX/T;  S01 = Da.XY'/T;  S10 = S01';
    L11 = chol(S11, 'lower');  Li = inv(L11);
    M = Li*S10*(S00\S01)*Li';
    [V, lam] = eig((M + M')/2, 'vector');
    [lam, ord] = sort(lam, 'descend');
    Da.lam = lam;  Da.V = Li'*V(:, ord);
end
