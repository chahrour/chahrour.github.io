function varargout = myhac(Data,varargin)
%HAC Heteroscedasticity and autocorrelation consistent covariance estimators
%
% Syntax:
%
%   [EstCoeffCov,se,coeff] = hac(X,y)
%   [EstCoeffCov,se,coeff] = hac(Mdl)
%   [CovTbl,CoeffTbl] = hac(Tbl)
%   [...] = hac(...,param,val,...)
%
% Description:
%
%   HAC computes robust covariance estimates for ordinary least squares
%   (OLS) coefficient estimates of multiple linear regression models
%
%   y = X*coeff + e
%
%   under general forms of heteroscedasticity and autocorrelation in the
%   innovations process e. Estimates are of the form
%               
%   PhiHat = X'*OmegaHat*X
%   EstCoeffCov = c*inv(X'*X)*PhiHat*inv(X'*X)
%
%   where OmegaHat is an estimate of the innovations covariance and c is an
%   optional small-sample correction.
%
% Input Arguments:  
%
%   X - Predictor data, specified as a numObs-by-numPreds matrix.
%
%   y - Response data, specified as a numObs-by-1 vector.
%
%   Mdl - Regression data, specified as a linear model of the form 
%       Mdl = LinearModel.fit(X,y).
%
%   Tbl - Regression data, specified as a table or timetable. The test
%       regresses the variable specified by the 'ResponseVariable'
%       parameter on the variables specified by the 'PredictorVariables'
%       parameter.
%
%   The function removes NaN values indicating missing observations.
%
% Optional Input Parameter Name/Value Arguments:
%
%   NAME        VALUE
%
%   'VarNames'  String vector or cell vector of character vectors of
%               length numPreds of unique variable names to be used in
%               displays of the results. Names should include the intercept
%               term (e.g., 'Const') and higher-order terms (e.g, 'x1^2' or
%               'x1:x2'), if present. The default for matrix X is
%               {'x1','x2',...}. The default for tabular array Tbl is
%               Tbl.Properties.VariableNames. The default for linear models
%               Mdl is Mdl.CoefficientNames.
%
%   'Intercept' Logical value indicating whether or not to add an intercept
%               when fitting the model. The default is true. When the input
%               is already a fitted model, Mdl, 'Intercept' is ignored.
%
%   'Type' 		Type of estimator. Values are 'HC' and 'HAC'. 'HC' computes
%               heteroscedasticity-consistent estimates, as described in
%               [9], [7], and [3]. 'HAC' computes heteroscedasticity-and-
%               autocorrelation-consistent estimates, as described in [8],
%               [5], [2], and [1]. The default is 'HAC'.
%
%   'Weights' 	Weights used to compute PhiHat = X'*OmegaHat*X. Values are
%               a numerical vector w of length numObs or a string or
%               character vector indicating a method for computing w from
%               the data.
%
%               When 'Type' is 'HC', OmegaHat = diag(w). Elements w(i)
%               estimate the innovations variance at each observation i.
%               Data-driven w are computed from model residuals u(i), their
%               leverages h(i), and their number of degrees of freedom dfe.
%               Values are:
%
%               o 'CLM' w(i) = (1/dfe)*sum(u(i)^2). This is the Classical
%                       Linear Model estimator, used in the absence of
%                       heteroscedasticity.
%
%               o 'HC0' w(i) = u(i)^2. This is the White estimator in [9].
%                       This is the default when 'type' is 'HC'.
%
%               o 'HC1' w(i) = (numObs/dfe)*u(i)^2. This is the HC1
%                       estimator in [7].
%
%               o 'HC2' w(i) = (u(i)^2)/(1-h(i)). This is the HC2
%                       estimator in [7].
%
%               o 'HC3' w(i) = (u(i)^2)/((1-h(i))^2). This is the HC3
%                       estimator in [7].
%
%               o 'HC4' w(i) = (u(i)^2)/((1-h(i))^d(i)), where d(i) is
%                       min(4,h(i)/mean(h)). This is the estimator in [3].
%
%               o w     Vector of user-specified weights, of length numObs.
%                       If data contain a missing value at observation i,
%                       w(i) is removed during estimation.
%
%               When 'Type' is 'HAC', component products forming PhiHat,
%               X(i,:)'*(u(i)*u(j))*X(j,:), are weighted by w(l), where 
%               l = abs(i-j) is the lag length between observations.
%               Elements w(l) represent the strength of autocorrelations at
%               each lag length. Data-driven w(l) = k(l/b) are computed by
%               a kernel density estimator k, with b specified by the
%               'Bandwidth' parameter. Values are:
%
%               o 'TR' Truncated kernel:
%
%                             | 1  for abs(x) <= 1
%                      k(x) = |
%                             | 0  otherwise
%
%                      This produces the White estimator in [10, p. 152].
%
%               o 'BT' Bartlett kernel:
%
%                             | 1-abs(x)  for abs(x) <= 1
%                      k(x) = |
%                             | 0         otherwise
%
%                      This produces the Newey-West estimator in [8]. This
%                      is the default when 'type' is 'HAC'.
%
%               o 'PZ' Parzen kernel:
%
%                             | 1-6*x^2+6*abs(x)^3  for 0 <= abs(x) <= 1/2
%                      k(x) = | 2*(1-abs(x))^3      for 1/2 <= abs(x) <= 1
%                             | 0                   otherwise
%
%                      This produces the Gallant estimator in [5, p. 533].
%
%               o 'TH' Tukey-Hanning kernel:
%
%                             | (1+cos(pi*x))/2  for abs(x) <= 1
%                      k(x) = |
%                             | 0                otherwise
%
%                      This estimator was introduced by Andrews in [1].
%
%               o 'QS' Quadratic spectral kernel:
%
%                      k(x) = [25/(12*pi^2*x^2)]*...
%                             [sin(6*pi*x/5)/(6*pi*x/5)-cos(6*pi*x/5)]
%
%                      This estimator was introduced by Andrews in [1].
%
%               o w    Vector of user-specified weights, of length numObs.
%                      If data contain a missing value at observation i,
%                      w(i) is removed during estimation.
%
%   'Bandwidth' Scalar bandwidth parameter b used by the kernel estimator
%               in 'Weights' when 'Type' is 'HAC'. If 'Type' is 'HC',
%               'bandwidth' is ignored. The default is data-driven, as in
%               [1]. Values of 'AR1' or 'ARMA11' specify the model used for
%               data-driven bandwidth selection. The default model is
%               'AR1'. The method used to estimate the 'AR1' model can be
%               specified by values of 'AR1OLS', to use OLS, or 'AR1MLE',
%               to use maximum likelihood. The default method is 'AR1MLE'.
%
%   'SmallT'    Logical flag indicating whether or not to apply the small-
%               sample correction c = T/dfe, where T is the effective
%               sample size and dfe is the number of degrees of freedom of
%               the model residuals. Values are true and false. The default
%               is false when 'Type' is 'HC' and true when 'Type' is 'HAC'.
%
%   'Whiten'    Nonnegative integer specifying the lag order of a vector
%               autoregressive model used as a prewhitening filter when
%               'Type' is 'HAC', as in [2]. If 'Type' is 'HC', 'Whiten' is
%               ignored. The default is 0, which bypasses the filter.
%
%   'Display'   String or character vector to control the display of
%               results to the command window. The display shows outputs in
%               tabular form. Values are 'cov' to display only EstCoeffCov,
%               'full' to display all of coeff, se, and EstCoeffCov, or
%               'off' to turn off the display. The default is 'cov'.
%
%   'ResponseVariable' Variable in Tbl to use for the regression response,
%               specified as a name in Tbl.Properties.VariableNames.
%               Variable names are character vectors, string scalars,
%               integers or logical vectors. The default is the last
%               variable in Tbl.
%
%   'PredictorVariables' Variables in Tbl to use for regression predictors,
%               specified as names in Tbl.Properties.VariableNames.
%               Variable names are cell vectors of character vectors,
%               string vectors, integer vectors or logical vectors. The
%               default is all variables in Tbl other than 'ResponseVariable'.
% 
% Output Arguments:
%
%   EstCoeffCov - numPreds-by-numPreds matrix of coefficient covariance
%                 estimates.
%
%   se - numPreds-by-1 vector of coefficient standard error estimates. This
%        is sqrt(diag(EstCoeffCov)).
%
%   coeff - numPreds-by-1 vector of OLS coefficient estimates.
%
%   CovTbl - When input is Tbl, output EstCoeffCov is returned in table
%       CovTbl.
%
%   CoeffTbl - When input is Tbl, outputs coeff and se are returned in
%       table CoeffTbl.
%
% Notes:
%
%   o Estimates formed by HAC are often called "sandwich estimates," with
%     X'*OmegaHat*X the "filling" and inv(X'*X) the "bread."
%
%   o For kernels with unit-interval support, the bandwidth parameter b is
%     often called the "lag-truncation parameter," since w(l) = k(l/b) = 0
%     for lags l > b.
%
%   o HAC with default settings computes a Newey-West estimator using a
%     Bartlett kernel with a data-driven bandwidth. To obtain the standard
%     Newey-West estimate described in [8], set 'Bandwidth' to maxLag+1,
%     with maxLag = floor(4*(T/100)^(2/9)).
%
%   o The original White HC estimator, HC0, is justified asymptotically.
%     HC1, HC2, HC3, and HC4 are meant to improve small-sample performance.
%     [6] and [3] recommend HC3 and HC4, respectively, in the presence of
%     influential observations.
%
%   o HAC estimators formed with the truncated kernel are not guaranteed to
%     be positive semidefinite in finite samples. [8] proposes the Bartlett
%     kernel as a remedy, but the resulting estimator is suboptimal in
%     terms of its rate of consistency. The quadratic spectral kernel
%     achieves an optimal rate of consistency.
%
%   o The default estimation method for HAC bandwidth selection, 'AR1MLE',
%     is generally more accurate, but slower, than the 'AR1' alternative,
%     'AR1OLS'. The 'ARMA11' model must be estimated by maximum likelihood.
%     Bandwidth-selection models may exhibit sensitivity to the relative
%     scale of the predictors in X.
%
%   o [2] recommends prewhitening for HAC estimators to reduce bias. The
%     procedure tends to increase estimator variance and mean-squared
%     error, but can improve confidence interval coverage probabilities and
%     reduce the over-rejection of t statistics.
%
% Example:
%
%   % Compute OLS coefficients and Newey-West standard errors for a
%   % regression of nominal GNP (GNPN) on the consumer price index (CPI),
%   % real wages (WR), and the money stock (MS):
%
%   load Data_NelsonPlosser
%   Tbl = DataTable(:,[8,10,11,2]);
%   T = sum(~any(ismissing(Tbl),2));
%   maxLag = floor(4*(T/100)^(2/9));
%   EstCoeffCov = hac(Tbl,'bandwidth',maxLag+1,'display','full');
%
% References:
% 
%   [1] Andrews, D. W. K. "Heteroskedasticity and Autocorrelation
%       Consistent Covariance Matrix Estimation." Econometrica. v. 59,
%       1991, pp. 817-858.
%
%   [2] Andrews, D. W. K., and J. C. Monohan. "An Improved
%       Heteroskedasticity and Autocorrelation Consistent Covariance Matrix
%       Estimator." Econometrica. v. 60, 1992, pp. 953-966.
%
%   [3] Cribari-Neto, F. "Asymptotic Inference Under Heteroskedasticity of
%       Unknown Form." Computational Statistics & Data Analysis. v. 45,
%       2004, pp. 215-233.
%
%   [4] den Haan, W. J., and A. Levin. "A Practitioner's Guide to Robust
%       Covariance Matrix Estimation." In Handbook of Statistics. Edited by
%       G. S. Maddala and C. R. Rao. Amsterdam: Elsevier, 1997.
%
%   [5] Gallant, A. R. Nonlinear Statistical Models. Hoboken, NJ: John
%       Wiley & Sons, Inc., 1987.
%
%   [6] Long, J. S., and L. H. Ervin. "Using Heteroscedasticity-Consistent
%       Standard Errors in the Linear Regression Model." The American
%       Statistician. v. 54, 2000, pp. 217-224.
%
%   [7] MacKinnon, J. G., and H. White. "Some Heteroskedasticity-Consistent
%       Covariance Matrix Estimators with Improved Finite Sample
%       Properties." Journal of Econometrics. v. 29, 1985, pp. 305-325.
%
%   [8] Newey, W. K., and K. D. West. "A Simple, Positive-Definite,
%       Heteroskedasticity and Autocorrelation Consistent Covariance
%       Matrix." Econometrica. v. 55, 1987, pp. 703-708.
%
%   [9] White, H. "A Heteroskedasticity-Consistent Covariance Matrix and a
%       Direct Test for Heteroskedasticity." Econometrica. v. 48, 1980, pp.
%       817-838.
%
%  [10] White, H. Asymptotic Theory for Econometricians. New York: Academic
%       Press, 1984.
%

% Copyright 2023 The MathWorks, Inc.

isTabular = istable(Data) || istimetable(Data);
isLinearModel = isa(Data,'LinearModel');
isNumeric = (~isTabular && ~isLinearModel);

% Parse inputs and set defaults:

parseObj = inputParser;

parseObj.addRequired('Data',...
                     @(x)validateattributes(x,{'double','table','timetable','LinearModel'},{'nonempty','2d'}));

if isNumeric
    
    parseObj.addRequired('y',...
                         @(x)validateattributes(x,{'double'},{'nonempty','vector'}))
    
end

parseObj.addParameter('VarNames',{},@varNamesCheck);
parseObj.addParameter('Intercept',true,@interceptCheck);
parseObj.addParameter('Type','HAC',@typeCheck);
parseObj.addParameter('Weights',[],@weightsCheck);
parseObj.addParameter('Bandwidth',[],@bandwidthCheck);
parseObj.addParameter('SmallT',[],@smallTCheck);
parseObj.addParameter('Whiten',0,@whitenCheck);
parseObj.addParameter('Display','cov',@displayCheck);
parseObj.addParameter('ResponseVariable',[],...
             @(x)validateattributes(x,{'double','logical','char','string'},{'vector'}));
parseObj.addParameter('PredictorVariables',[],...
             @(x)validateattributes(x,{'double','logical','cell','string'},{'vector'}'));

parseObj.parse(Data,varargin{:});

Data = parseObj.Results.Data;

if isNumeric
    
    y = parseObj.Results.y;
    
end

varNames = parseObj.Results.VarNames;

if length(varNames) ~= length(unique(varNames))

    error(message('econ:hac:NonUniqueVariableNames'))

end

varNames = cellstr(varNames);

iFlag = parseObj.Results.Intercept;
estType = validatestring(parseObj.Results.Type,{'HC','HAC'});

weights = parseObj.Results.Weights;
if ~isnumeric(weights)
    if strcmp(estType,'HC')
        weights = validatestring(weights,{'CLM','HC0','HC1','HC2','HC3','HC4'});
    else
        weights = validatestring(weights,{'TR','BT','PZ','TH','QS'});
    end
end

b = parseObj.Results.Bandwidth;
if ~isnumeric(b)
    b = validatestring(b,{'AR1','ARMA11','AR1OLS','AR1MLE'});
end

ssFlag = parseObj.Results.SmallT;
p = parseObj.Results.Whiten;
dispStr = validatestring(parseObj.Results.Display,{'cov','full','off'});
YVarSpec = parseObj.Results.ResponseVariable;
XVarSpec = parseObj.Results.PredictorVariables;

% Select response Y with 'ResponseVariable':

if isNumeric
    
    Y = y;
    
    if ~isempty(YVarSpec)
        
        warning(message('econ:hac:ResponseVariableUnused'))
        
    end
    
elseif isTabular

    if ~isempty(YVarSpec)

        try

            Y = Data(:,YVarSpec);

        catch ME

            throwAsCaller(ME)

        end

    else

        Y = Data(:,end); % Default

    end
    
    try

        internal.econ.TableAndTimeTableUtilities.isTabularFormatValid(Y,'Y')
        internal.econ.TableAndTimeTableUtilities.isTabularDataSinglePath(Y,'Y')

    catch ME

        throwAsCaller(ME)

    end

    YNames = Y.Properties.VariableNames;
    Y = table2array(Y);
    Y = double(Y);
    
    if ~isvector(Y)

        error(message('econ:hac:ResponseVariableNonVector'))

    end

end

% Select predictors X with 'PredictorVariables':

if isNumeric
    
    X = Data;
    
    if length(y) ~= size(X,1)
        
        error(message('econ:hac:ResponseWrongSize'))
        
    end
    
   	if ~isempty(XVarSpec)
        
        warning(message('econ:hac:PredictorVariablesUnused'))
        
    end
    
elseif isTabular

    if ~isempty(XVarSpec)

        try

            X = Data(:,XVarSpec);

        catch ME

            throwAsCaller(ME)

        end

    else

        X = Data;
        X(:,YNames) = []; % Default
        
        if isempty(X)
    
            error(message('econ:hac:TooFewSeries'))
    
        end

    end
    
    try

        internal.econ.TableAndTimeTableUtilities.isTabularFormatValid(X,'X')
        internal.econ.TableAndTimeTableUtilities.isTabularDataSinglePath(X,'X')

    catch ME

        throwAsCaller(ME)

    end

    XNames = X.Properties.VariableNames;
    X = table2array(X);
    X = double(X);
    
    if ismember(YNames,XNames)

        error(message('econ:hac:IndistinctResponse'))

    end

end

% Ensure real, finite data:

if ~isLinearModel

    D = [X,Y];
    
    if any(~isreal(D(:))) || any(~isfinite(D(:)) & ~isnan(D(:)))
    
        error(message('econ:hac:DataError'))
    
    end

end


%I am going to assume the model has no missing data and data X includes the
%constant
missingData = isnan(Y);
T = length(Y);
coeff = X\Y;
numPreds = size(X,2); %includes constant
u = Y - X*coeff;
dfe = T - numPreds;


% Specify default weights:

if isempty(weights)
    if strcmp(estType,'HC')
        weights = 'HC0';
    else
        weights = 'BT';
    end
end

% Check user-specified weights:

userWeights = isnumeric(weights);

if userWeights
    
    try
        w = userWeightsCheck(weights,T,missingData);
    catch exception
        throw(exception)
    end
    
end

% Compute PhiHat:
        
switch estType

    case 'HC'
        
        if ~userWeights

            u2 = u.^2;
            h = M.Diagnostics.Leverage;
            h(missingData) = [];

            switch weights

                case 'CLM'

                    sse = sum(u2);
                    w = repmat(sse/dfe,size(u));

                case 'HC0'

                    w = u2;

                case 'HC1'

                    w = (T/dfe)*u2;

                case 'HC2'

                    w = u2./(1-h);

                case 'HC3'

                    w = u2./((1-h).^2);

                case 'HC4'

                    d = min(4,h/mean(h));
                    w = u2./((1-h).^d);

            end
        
        end
        
        PhiHat = X'*spdiags(w,0,T,T)*X;

    case 'HAC'

        % Scores matrix:

        V = bsxfun(@times,X,u);

        % Prewhiten scores:

        if p > 0

            if p > T-1

                error(message('econ:hac:WhiteningOrderTooBig'))

            end
  
            % VAR = varm(numPreds,p); 
            % VAR.Constant = 0; 
            % [VAR,~,~,V] = estimate(VAR,V); 
            % VARcoeffs = VAR.AR;
            [VARcoeffs, ~, V] = myvar(V,p);
            VARcoeffs = VARcoeffs';

        end
        
        if ~userWeights

            % Compute bandwidth, if unspecified:

            if isempty(b) || ischar(b)

                % Specify method:
                if isempty(b)
                    model = 'AR1MLE';
                elseif ischar(b)                
                    model = b;  
                end

                try
                    b = getBW(V,weights,model,iFlag);
                catch exception
                    throw(exception)
                end

            end

            % Compute kernel weights:

            lags = 0:T-1;
            w = zeros(T,1);
            x = lags/b;           

            switch weights

                case 'TR'

                    TR = (abs(x) <= 1);
                    w(TR) = 1;

                case 'BT'

                    BT = (abs(x) <= 1);                
                    w(BT) = 1-abs(x(BT));

                case 'PZ'

                    PZ1 = (abs(x) >= 0) & (abs(x) <= 1/2);
                    PZ2 = (abs(x) >= 1/2) & (abs(x) <= 1);  
                    w(PZ1) = 1-6*x(PZ1).^2+6*abs(x(PZ1)).^3;
                    w(PZ2) = 2*(1-abs(x(PZ2))).^3;

                case 'TH'

                    TH = (abs(x) <= 1);
                    w(TH) = (1+cos(pi*x(TH)))/2;

                case 'QS'

                    argQS = 6*pi*x/5;
                    w1 = 3./(argQS.^2);
                    w2 = (sin(argQS)./argQS)-cos(argQS);
                    w = w1.*w2;
                    w(x == 0) = 1;

            end
        
        end
        
        PhiHat = w(1)*(V'*V);
        for i = 1:T-p-1
            LagCov = (V(1+i:T-p,:)'*V(1:T-p-i,:));
            PhiHat = PhiHat+w(i+1)*(LagCov+LagCov');
        end

end

% Recolor prewhitened PhiHat:

if strcmp(estType,'HAC') && (p > 0)

    C = eye(numPreds)-sum(reshape([VARcoeffs],numPreds,numPreds,p),3);
    PhiHat = (C\PhiHat)/C';

end

% Compute the sandwich estimate:

% EstCoeffCov = inv(X'*X)*PhiHat*inv(X'*X)  
%             = inv(R'*Q'*Q*R)*Z'*Z*inv(R'*Q'*Q*R)
%             = ((R'*R)\Z')*(Z/(R'*R))
%             = (S\Z')*(Z/S)

try    
    Z = chol(PhiHat);    
catch exception % 'TR' or w fails to produce a positive definite matrix   
    throw(exception)    
end

[~,R] = qr(X,0);
S = R'*R;
EstCoeffCov = (S\Z')*(Z/S);

% Specify the default small-sample correction:

if isempty(ssFlag)
    if strcmp(estType,'HC')
        ssFlag = false;
    else
        ssFlag = true;
    end
end

% Apply the small-sample correction:

if ssFlag
    EstCoeffCov = (T/dfe)*EstCoeffCov;
end

% Compute standard errors:

se = sqrt(diag(EstCoeffCov));

% Create variable names:

if ~strcmp(dispStr,'off') || isTabular
  
    if isempty(varNames)
        
        if isTabular
            
            varNames = XNames;
            
        else
        
            varNames = M.CoefficientNames;
            
        end
        
        if iFlag
            
            if isTabular
                
                varNames = ['Const',varNames];
                
            else
            
                varNames{1} = 'Const';
                
            end
            
        end
        
    else
        
        if length(varNames) < numPreds

            error(message('econ:hac:VarNamesTooFew'))

        elseif length(varNames) > numPreds

            error(message('econ:hac:VarNamesTooMany'))

        end
        
    end
    
end

% Display output:

if ~strcmp(dispStr,'off')
    
    fprintf('\nEstimator type: %s',estType)
    if userWeights        
        fprintf('\nEstimation method: user-defined weights')        
    else        
        fprintf('\nEstimation method: %s',weights)
        if strcmp(estType,'HAC')
            fprintf('\nBandwidth: %.4f',b)
            fprintf('\nWhitening order: %u',p)
        end        
    end
    fprintf('\nEffective sample size: %u',T)
    if ssFlag
        fprintf('\nSmall sample correction: on\n')
    else
        fprintf('\nSmall sample correction: off\n')
    end

    if strcmp(dispStr,'full')        
        fprintf('\nCoefficient Estimates:\n\n')
        internal.econ.tableprint([coeff,se],...
                                 'colNames',{'Coeff','SE'},...
                                 'rowNames',varNames)
    end
    
    fprintf('\nCoefficient Covariances:\n\n')
    internal.econ.tableprint(EstCoeffCov,...
                             'colNames',varNames,...
                             'rowNames',varNames)
    
end

% Create output tables:

if isTabular
    
    CoeffTbl = table(coeff,se,'RowNames',varNames,...
                              'VariableNames',{'Coeff','SE'});
                          
    CovTbl = array2table(EstCoeffCov,'RowNames',varNames,...
                                     'VariableNames',varNames);
    
end

% Assign outputs to varargout:

if isTabular
    
    nargoutchk(0,2)

    varargout = {CovTbl,CoeffTbl};
    
else

    nargoutchk(0,3)

    varargout = {EstCoeffCov,se,coeff};

end

%-------------------------------------------------------------------------
% Check value of 'varNames' parameter
function OK = varNamesCheck(varNames)

if ischar(varNames) || ~isvector(varNames) || ...
   isnumeric(varNames) || (iscell(varNames) && any(cellfun(@isnumeric,varNames)))

    error(message('econ:hac:VarNamesInvalid'))

end

OK = true;

%-------------------------------------------------------------------------
% Check value of 'intercept' parameter
function OK = interceptCheck(iFlag)

if ~islogical(iFlag) || ~isscalar(iFlag)
    
    error(message('econ:hac:InterceptNonLogicalScalar'))

end

OK = true;

%-------------------------------------------------------------------------
% Check value of 'type' parameter
function OK = typeCheck(estType)
    
if isnumeric(estType) || ~isvector(estType)

    error(message('econ:hac:EstTypeNonString'))

end

OK = true;

%-------------------------------------------------------------------------
% Check value of 'weights' parameter
function OK = weightsCheck(weights)
    
if ~isvector(weights)

    error(message('econ:hac:WeightsNonVector'))

end

OK = true;

%-------------------------------------------------------------------------
% Check value of 'bandwidth' parameter
function OK = bandwidthCheck(b)

if ~isvector(b)

    error(message('econ:hac:BandwidthNonVector'))
      
elseif isnumeric(b) && ~isscalar(b)

    error(message('econ:hac:BandwidthValueNonScalar'))

end

OK = true;

%-------------------------------------------------------------------------
% Check value of 'smallT' parameter
function OK = smallTCheck(ssFlag)
    
if ~islogical(ssFlag)

    error(message('econ:hac:SmallSampleFlagInvalid'))

end

OK = true;

%-------------------------------------------------------------------------
% Check value of 'whiten' parameter
function OK = whitenCheck(p)

if ~isnumeric(p) || ~isscalar(p) || mod(p,1) ~= 0 || p < 0

    error(message('econ:hac:WhiteningOrderInvalid'))

end

OK = true;
    
%-------------------------------------------------------------------------
% Check value of 'display' parameter
function OK = displayCheck(dispFlag)
    
if isnumeric(dispFlag) || ~isvector(dispFlag)

    error(message('econ:hac:DisplayFlagNonString'))

end

OK = true;
    
%-------------------------------------------------------------------------
% Check user-defined weights
function w = userWeightsCheck(weights,numObs,missingData)

if length(weights) ~= numObs

    error(message('econ:hac:UserWeightsDimensionMismatch'))

else

    weights(missingData) = [];
    w = weights;

end

%-------------------------------------------------------------------------
% Compute data-driven bandwidth
function b = getBW(V,weights,model,iFlag)

[T,n] = size(V);

% Use the scale-invariant alpha weights in [1]. See [4] for alternatives.

wAlpha = ones(n,1); % Unit weight for slope coefficients
if iFlag
    wAlpha(1) = 0; % Zero weight for intercept coefficient
end

% Set MLE options:

% options = optimoptions(@fmincon,'Display','off','Diagnostics','off',...
%                                 'Algorithm','sqp','ConstraintTolerance',1e-7);
% 
% switch model
% 
%     case {'AR1','AR1OLS','AR1MLE'}

        rho = zeros(n,1);     % AR coefficient estimates
        sigmaSq = zeros(n,1); % Residual variances
        
        % switch model
        % 
        %     case {'AR1','AR1MLE'}
        % 
        %         AR1 = arima(1,0,0); % AR(1) model
        % 
        %         for j = 1:n
        % 
        %             ARfit = estimate(AR1,V(:,j),'display','off','options',options);
        %             rho(j) = ARfit.AR{1};
        %             sigmaSq(j) = ARfit.Variance;
        % 
        %         end

            % case 'AR1OLS'

                for j = 1:n
                    
                    v = V(:,j);
                    vt = v(2:T);
                    vtLag1 = v(1:T-1);
                    rhoj = vtLag1\vt;
                    res = vt-rhoj*vtLag1;
                    rho(j) = rhoj;
                    sigmaSq(j) = res'*res/(T-1);
                
                end

        % end

        num0 = 4*(rho.^2).*(sigmaSq.^2);
        den = (sigmaSq.^2)./((1-rho).^4);
        
    % case 'ARMA11'
    % 
    %     rho = zeros(n,1);      % AR coefficient estimates
    %     psi = zeros(n,1);      % MA coefficient estimates
    %     sigmaSq = zeros(n,1);  % Residual variances
    % 
    %     ARMA11 = arima(1,0,1); % ARMA(1,1) model
    % 
    %     for j = 1:n
    % 
    %         v = V(:,j);
    %         ARMAfit = estimate(ARMA11,v,'display','off','options',options);
    %         rho(j) = ARMAfit.AR{1};
    %         psi(j) = ARMAfit.MA{1};
    %         sigmaSq(j) = ARMAfit.Variance;
    % 
    %     end
    % 
    %     num0 = 4*((1+rho.*psi).^2).*((rho+psi).^2).*(sigmaSq.^2);
    %     den = (((1+psi).^4).*(sigmaSq.^2))./((1-rho).^4);
        
%end

% Compute alphas:

num1 = ((1-rho).^6).*((1+rho).^2);
num2 = (1-rho).^8;
denSum = sum(wAlpha.*den);
alpha1 = sum(wAlpha.*(num0./num1))/denSum;
alpha2 = sum(wAlpha.*(num0./num2))/denSum;

% Compute optimal bandwidth:

switch weights
    
    case 'TR'
        
       b = (0.6611)*(alpha2*T)^(1/5); 
        
    case 'BT'
        
        b = (1.1447)*(alpha1*T)^(1/3);
                
    case 'PZ'
        
        b = (2.6614)*(alpha2*T)^(1/5);
                
    case 'TH'
        
        b = (1.7462)*(alpha2*T)^(1/5);
                
    case 'QS'
      
        b = (1.3221)*(alpha2*T)^(1/5);
        
end

function [beta, c, mu, omega] = myvar(Y,nlag)

%Number of Variables
nvar = size(Y,2);
T = length(Y)-nlag;
const = 0;

%*****************
% Arrange Data
%*****************

%Stack lagged X
X = zeros(T, nlag*nvar);
for j =1:nlag
    X(:, (j-1)*nvar+1:j*nvar) = Y(nlag+1-j:end-j,:);
end

%Include a constant in VAR
X = [X, ones(length(X),const)];

%Exclude lags from DY
YY = Y(nlag+1:end,:);

%*********************************************
% Regress, get covariance matrix and cholesky
%*********************************************

%VAR coefficients, stderrs, etc
beta = X\YY;
mu = YY - X*beta;
omega = (mu'*mu)/(T-1);
c = chol(omega)';
beta = beta(1:end-const,:);