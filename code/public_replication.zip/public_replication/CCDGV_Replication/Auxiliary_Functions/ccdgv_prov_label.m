function s = ccdgv_prov_label(D)
%CCDGV_PROV_LABEL  Run identifier for a table's provenance line.
%
%   Prefers info, the staged save's specification record, over the legacy
%   case_name that staged files no longer carry. info is the better source: it
%   names the specification, so two runs cannot collide on one label.
%
%   A run whose info.complete is false gets flagged in the label. A table built
%   from a half-finished file is exactly the failure this refactor exists to
%   make visible, so it says so in the typeset output rather than only on disk.

    s = '';
    if isfield(D,'info') && isstruct(D.info)
        s = data_name(D.info);
        if ~isfield(D.info,'complete') || ~D.info.complete
            s = [s ' (INCOMPLETE RUN)'];
        end
    elseif isfield(D,'case_name')
        s = D.case_name;
    end
end
