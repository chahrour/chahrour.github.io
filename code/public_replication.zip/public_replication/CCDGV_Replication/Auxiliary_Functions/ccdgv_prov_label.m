function s = ccdgv_prov_label(D)
%CCDGV_PROV_LABEL  Run identifier for a table's provenance line.
%
%   s = ccdgv_prov_label(D)
%
%   D  a loaded run file. The label is data_name(D.info), flagged when
%      info.complete is false; without info it is D.case_name, or ''.

    s = '';
    if isfield(D,'info') && isstruct(D.info)
        s = data_name(D.info);
        if ~isfield(D.info,'complete') || ~D.info.complete
            s = [s ' (INCOMPLETE RUN)'];
        end
    elseif isfield(D,'case_name')
        s = D.case_name;
    end
end
