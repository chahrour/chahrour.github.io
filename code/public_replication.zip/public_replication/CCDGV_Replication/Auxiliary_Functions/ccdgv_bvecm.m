function [ARs, Sigs, Res, rec] = ccdgv_bvecm(data, names, nlags, rule, ndraws, maxeig_cutoff)
%CCDGV_BVECM  Villani (2005) Bayesian VECM at a given rank, returned as levels VAR draws.
%
%   [ARs, Sigs, Res, rec] = ccdgv_bvecm(data, names, nlags, rule, ndraws, maxeig_cutoff)
%
%   data    T x p data in levels, columns in spec order (names).
%   names   variable names in spec order; 'tfp' must be first.
%   nlags   lag order in levels (the VECM has nlags-1 lagged differences).
%   rule    the manifest's bv entry: rank, order, rho, s, lambda, decay, q_extra,
%           ngibbs, nburn.
%   ndraws  number of posterior draws.
%   maxeig_cutoff  draws whose damped companion matrix has a larger eigenvalue
%           modulus are rejected and replaced.
%
%   ARs, Sigs, Res   1 x (ndraws+1) cells in spec order: the posterior draws,
%           then the posterior-median system last (the format GENVARS returns).
%   rec     hyperparameters and rejection counts to store with the run.
%
%   Prior:  beta = [I_r; B] with B matrix-Cauchy;
%           alpha | beta, Sigma ~ N(0, (beta'beta)^-1 (x) s^2 Sigma);
%           Sigma ~ IW(A, p + q_extra); Gammas Minnesota (CCDGV_BVECM_MINN).
%   (alpha, B) come from the collapsed Gibbs sampler; (Sigma, Gammas) are then
%   drawn exactly given each.
%
%   The library normalises beta on the first r variables, so estimation uses
%   rule.order and the result is permuted back to spec order. Each draw has
%   p - r unit roots; the levels VAR is damped A_j -> rho^j A_j so they sit at rho.
%
%   See also CCDGV_BVECM_MINN, CCDGV_BVECM_DATA, CCDGV_BVECM_DRAW.

    % Permutation between spec order and estimation order.
    p = numel(names);  r = rule.rank;  k = nlags;
    perm  = cellfun(@(nm) find(strcmp(names, nm)), rule.order);
    iperm = zeros(1, p);  iperm(perm) = 1:p;
    assert(isequal(rule.order(iperm), names(:)') && strcmp(names{1}, 'tfp'), ...
        'ccdgv_bvecm:order', 'estimation order does not round-trip to the spec order with tfp first');

    % Data struct, Minnesota dummy rows, and the augmented moments.
    rng(0, 'twister');
    D  = vecm_data(data(:, perm), k, 'const');
    [Zd, sig] = ccdgv_bvecm_minn(D, rule.lambda, rule.decay);
    Da = ccdgv_bvecm_data(D, Zd);

    % A: residual covariance of the full-rank regression under the Minnesota
    % dummies, computed on the real rows and divided by the real T.
    W = [[D.X; zeros(Da.m_dummy, p)], [D.Z; Zd]];
    C = W \ [D.Y; zeros(Da.m_dummy, p)];
    E = D.Y - [D.X, D.Z]*C;
    A = (E'*E)/D.T;  A = (A + A')/2;
    q = p + rule.q_extra;  v = 1/rule.s^2;

    % Gibbs sampler for (alpha, B) at rank r.
    R = rank_setup(Da, r, A, q, v);
    [Ad, Bd] = gibbs_marginal(R, rule.ngibbs, rule.nburn);
    pool = struct('alpha', Ad, 'B', Bd);

    % Posterior draws. Explosive draws are rejected.
    ARs = cell(1, ndraws);  Sigs = ARs;  Res = ARs;
    J = draw_joint(R, pool, ndraws);
    j = 1;  ntried = 0;
    while j <= ndraws
        if isempty(J)   % top up by resampling the pool
            idx = randi(rule.ngibbs, 1, max(20, ndraws - j + 1));
            J = draw_joint(R, struct('alpha', Ad(:,:,idx), 'B', Bd(:,:,idx)), numel(idx));
        end
        ntried = ntried + 1;
        [AR, Sg, res, me] = ccdgv_bvecm_draw(J(1), D, iperm, rule.rho);  J(1) = [];
        if me <= maxeig_cutoff + 1e-10
            ARs{j} = AR;  Sigs{j} = Sg;  Res{j} = res;  j = j + 1;
        end
        assert(ntried < 50*ndraws, 'ccdgv_bvecm:explosive', ...
            'rank %d: %d of %d draws explosive', r, ntried - j + 1, ntried);
    end

    % Posterior-median system, stored last: elementwise medians of (alpha, B),
    % with (Sigma, Psi) at their conditional posterior means.
    a  = median(Ad, 3);  bt = [eye(r); median(Bd, 3)];  Pi = a*bt';
    WW = Da.YY - Pi*Da.XY - Da.XY'*Pi' + Pi*Da.XX*Pi';
    Jm.alpha = a;  Jm.beta = bt;
    Jm.Sigma = (A + v*(a*(bt'*bt)*a') + WW)/(R.T - R.d + q + r - p - 1);
    Jm.Psi   = Da.ZZinv*(Da.ZY - Da.ZX*Pi');
    Jm.Gammas = split_psi(Jm.Psi, p, k);
    [ARs{end+1}, Sigs{end+1}, Res{end+1}] = ccdgv_bvecm_draw(Jm, D, iperm, rule.rho);

    rec = struct('rank', r, 'order', {rule.order}, 'iperm', iperm, 'rho', rule.rho, ...
        's', rule.s, 'lambda', rule.lambda, 'decay', rule.decay, 'q', q, 'A', A, ...
        'sig_minn', sig, 'T', D.T, 'm_dummy', Da.m_dummy, 'ngibbs', rule.ngibbs, ...
        'nburn', rule.nburn, 'ntried', ntried, 'nreject', ntried - ndraws);
    fprintf('Bayesian VECM, rank %d: %d draws kept, %d explosive rejected\n', r, ndraws, ntried - ndraws);
end
