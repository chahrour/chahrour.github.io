function [ARs, Sigs, Res, rec] = ccdgv_bvecm(data, names, nlags, rule, ndraws, maxeig_cutoff)
%CCDGV_BVECM  Villani (2005) Bayesian VECM at a declared rank -> levels VAR draws.
%
%   [ARs, Sigs, Res, rec] = CCDGV_BVECM(data, names, nlags, rule, ndraws, maxeig_cutoff)
%
%   data    T x p LEVELS data, columns in spec order (names)
%   nlags   levels lag order (the VECM has nlags-1 lagged differences)
%   rule    the manifest's `bv` entry: rank, order, rho, s, lambda, decay,
%           q_extra, ngibbs, nburn
%   ARs, Sigs, Res   1 x (ndraws+1) cells in SPEC order, the GENVARS contract:
%           ndraws posterior draws, then the posterior-median system last
%   rec     what the run should record (hyperparameters, rejections)
%
% The estimator (library in Bayesian_VECM/):
%   beta = [I_r; B], B matrix-Cauchy     alpha | beta, Sigma ~ N(0, (beta'beta)^-1 (x) s^2 Sigma)
%   Sigma ~ IW(A, p + q_extra)           Gammas: Minnesota prior via dummy rows (CCDGV_BVECM_MINN)
% A is the residual covariance of the full-rank VAR under the same Minnesota
% shrinkage. (alpha, B) come from the collapsed Gibbs sampler, then
% (Sigma, Gammas) exactly given each. Hyperparameter reasoning:
% Notes/bvecm_hyperparameters.md.
%
% ORDER. The library normalises beta on the FIRST r variables, so estimation
% uses rule.order and the stored system is permuted back, by name, to the
% spec order (TFP in row 1, which the CJ identification assumes).
%
% UNIT ROOTS. Every draw has exactly p - r unit roots; each levels VAR is damped
% A_j -> rho^j A_j so they sit at rho, which the cepstral factorisation in
% GEN_CJ_IRFS_TFSWEEP needs. Draws whose damped companion exceeds
% maxeig_cutoff are rejected and replaced from the Gibbs pool.

    p = numel(names);  r = rule.rank;  k = nlags;
    perm  = cellfun(@(nm) find(strcmp(names, nm)), rule.order);
    iperm = zeros(1, p);  iperm(perm) = 1:p;
    assert(isequal(rule.order(iperm), names(:)') && strcmp(names{1}, 'tfp'), ...
        'ccdgv_bvecm:order', 'estimation order does not round-trip to the spec order with tfp first');

    rng(0, 'twister');
    D  = vecm_data(data(:, perm), k, 'const');
    [Zd, sig] = ccdgv_bvecm_minn(D, rule.lambda, rule.decay);
    Da = ccdgv_bvecm_data(D, Zd);

    % A: full-rank residual covariance under the Minnesota-shrunk regression,
    % real rows only, divided by the real T
    W = [[D.X; zeros(Da.m_dummy, p)], [D.Z; Zd]];
    C = W \ [D.Y; zeros(Da.m_dummy, p)];
    E = D.Y - [D.X, D.Z]*C;
    A = (E'*E)/D.T;  A = (A + A')/2;
    q = p + rule.q_extra;  v = 1/rule.s^2;

    R = rank_setup(Da, r, A, q, v);
    [Ad, Bd] = gibbs_marginal(R, rule.ngibbs, rule.nburn);
    pool = struct('alpha', Ad, 'B', Bd);

    % ---- posterior draws, explosive ones rejected ---------------------------
    ARs = cell(1, ndraws);  Sigs = ARs;  Res = ARs;
    J = draw_joint(R, pool, ndraws);
    j = 1;  ntried = 0;
    while j <= ndraws
        if isempty(J)   % top up by resampling the pool
            idx = randi(rule.ngibbs, 1, max(20, ndraws - j + 1));
            J = draw_joint(R, struct('alpha', Ad(:,:,idx), 'B', Bd(:,:,idx)), numel(idx));
        end
        ntried = ntried + 1;
        [AR, Sg, res, me] = ccdgv_bvecm_draw(J(1), D, iperm, rule.rho);  J(1) = [];
        if me <= maxeig_cutoff + 1e-10
            ARs{j} = AR;  Sigs{j} = Sg;  Res{j} = res;  j = j + 1;
        end
        assert(ntried < 50*ndraws, 'ccdgv_bvecm:explosive', ...
            'rank %d: %d of %d draws explosive', r, ntried - j + 1, ntried);
    end

    % ---- appended point estimate: the posterior-median system ---------------
    % elementwise medians of (alpha, B), with (Sigma, Psi) at their conditional
    % posterior means -- a rank-r system, unlike a median of the AR draws
    a  = median(Ad, 3);  bt = [eye(r); median(Bd, 3)];  Pi = a*bt';
    WW = Da.YY - Pi*Da.XY - Da.XY'*Pi' + Pi*Da.XX*Pi';
    Jm.alpha = a;  Jm.beta = bt;
    Jm.Sigma = (A + v*(a*(bt'*bt)*a') + WW)/(R.T - R.d + q + r - p - 1);
    Jm.Psi   = Da.ZZinv*(Da.ZY - Da.ZX*Pi');
    Jm.Gammas = split_psi(Jm.Psi, p, k);
    [ARs{end+1}, Sigs{end+1}, Res{end+1}] = ccdgv_bvecm_draw(Jm, D, iperm, rule.rho);

    rec = struct('rank', r, 'order', {rule.order}, 'iperm', iperm, 'rho', rule.rho, ...
        's', rule.s, 'lambda', rule.lambda, 'decay', rule.decay, 'q', q, 'A', A, ...
        'sig_minn', sig, 'T', D.T, 'm_dummy', Da.m_dummy, 'ngibbs', rule.ngibbs, ...
        'nburn', rule.nburn, 'ntried', ntried, 'nreject', ntried - ndraws);
    fprintf('Bayesian VECM, rank %d: %d draws kept, %d explosive rejected\n', r, ndraws, ntried - ndraws);
end
