function d = annualize_irf(d, tf)
%ANNUALIZE_IRF  Multiply the rate rows of a packed response array by 4.
%
%   d = ANNUALIZE_IRF(d, tf)
%
%   d   nimp x 2*nv x pages [x overlays], the layout PLOTIRF reads: column k and
%       column nv+k both hold row k.
%   tf  1 x nv logical from RATE_ROWS.
%
%   Medians and percentile bands scale exactly, since the map is linear.
%
%   See also RATE_ROWS.

    nv = numel(tf);
    assert(size(d,2) >= 2*nv, 'annualize_irf:width', ...
        'd has %d columns; %d rows need %d.', size(d,2), nv, 2*nv);
    k = find(tf(:)');
    d(:, [k, nv+k], :, :) = 4 * d(:, [k, nv+k], :, :);
end
