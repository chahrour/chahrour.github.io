function [fout, prefs] = plotIRF(data, order, vars, Title, select_vars, prefs)
%PLOTIRF  Impulse-response panel figure, configured by a preferences struct.
%
%   Rewrite of plotIRF_paper_resubmit. Same plotting, same data indexing, same
%   output file. The four trailing flags (CJ, NOISE, SLIDE, confidence_bands)
%   and the previously hard-coded layout are now fields of one struct.
%
%   [F, P] = PLOTIRF(DATA, ORDER, VARS, TITLE)
%   [F, P] = PLOTIRF(DATA, ORDER, VARS, TITLE, SELECT_VARS)
%   [F, P] = PLOTIRF(DATA, ORDER, VARS, TITLE, SELECT_VARS, PREFS)
%       F  handles of the figures created (one per column of ORDER), as a
%          gobjects array -- real handles, so F(1).Position works.
%       P  the preferences actually used, after defaults are filled in and the
%          grid is resolved. Pass P back in to reproduce the figure exactly.
%
%   P = PLOTIRF()  or  P = PLOTIRF(anything)
%       With one argument or none, returns the DEFAULT preferences as the first
%       output and does nothing else. Nothing is drawn, no file is written.
%       Use it to see the fields, edit a few, and pass the struct back:
%           p = plotIRF;  p.nrow = 3;  plotIRF(data,order,vars,'MyFig',[],p)
%
%   POSITIONAL ARGUMENTS (unchanged from plotIRF_paper_resubmit)
%     DATA         nimp x 2*nvars x 5. Columns 1..nvars are variance shares,
%                  columns nvars+1..2*nvars are impulse responses -- this
%                  function reads the SECOND half. Pages of dim 3 are:
%                  1 = point estimate, 2/3 = inner band, 4/5 = outer band.
%     ORDER        N x nfig. Rows are which variables to plot, in order.
%                  Each COLUMN produces a separate figure.
%     VARS         cell array of panel titles. Its LENGTH sets the offset into
%                  DATA, so it must be as long as the full variable list, not
%                  just the panels being drawn.
%     TITLE        figure Name. Nothing is written -- PLOTIRF returns the handle
%                  and the caller saves it (exportgraphics into dest_dir).
%     SELECT_VARS  which panel positions get a line and bands drawn; the rest
%                  get only the zero line. Default 1:N (all of them).
%
%   PREFERENCES  (defaults reproduce plotIRF_paper_resubmit's OUTPUT; see the
%   note on 'color' for the one place the source line differs)
%     CJ                1    1 = CJ x-axis, -20:20 with the shock at 0.
%                            0 = 1:nimp.
%     NOISE             0    0 = blue line, 1 = red. Scalar applies to the
%                            whole figure; a vector of length N sets it per panel.
%     SLIDE             0    1 = plot only from the shock onward (0:20).
%     confidence_bands  1    1 = inner band only; 2 = also the outer band.
%     nrow              2    rows of panels.
%     ncol              3    columns of panels.
%     position    [1 1 550 550*2/4.5]   figure Position, in pixels.
%     xtick    [-20 -10 0 10 20]  forced x ticks; [] for automatic. The default
%                            suits CJ=1; with CJ=0 the x-axis is 1:nimp and you
%                            almost certainly want [].
%     color           'w'    figure background.
%     overlay          []    a SECOND line per panel, for comparing runs.
%                            Struct with fields:
%                              .data   nimp x 2*nvars x 5, same shape as DATA
%                              .style  linespec, default '--k'
%                              .label  legend text; a legend is added if present
%                              .baselabel  legend text for the MAIN line. Set it
%                                      and the legend carries two entries, the
%                                      main line first; leave it out and the
%                                      legend names the overlay alone, as it
%                                      always did.
%                              .color  RGB for the line, overriding .style's
%                                      colour while keeping its dash pattern
%                              .band   true to draw the overlay's INNER band
%                                      (pages 2/3) as a semi-transparent patch
%                              .bandcolor  RGB for that patch; default light blue
%                            Bands are off unless .band is set, so an overlay
%                            written before this option behaves as it always did.
%                            Indexed by the SAME order/nvars as DATA, so the two
%                            must share a row layout -- which the fixed manifest
%                            basis guarantees across specifications.
%     ylab       'percent'   y-axis label on the first panel of each row. A char
%                            applies to every labelled panel; a CELL of length N
%                            gives one entry per panel (entries may themselves be
%                            cells for a multi-line label). Interpreter is latex,
%                            so escape %% as \%%.
%                            plotIRF_paper_resubmit hard-codes [0.9412 0.9412
%                            0.9412], but that gray never reached a published
%                            figure: those helpers saved via print, whose
%                            InvertHardcopy='on' whitens the background whatever
%                            Color says. Saving with exportgraphics does NOT --
%                            its BackgroundColor='current' honours a Color you
%                            set explicitly (though it whitens the factory
%                            default). From R2025b on that yields a gray page;
%                            R2023b whitened both paths, which is why the sweep
%                            never showed it. Default 'w' therefore matches
%                            every published figure. Set
%                            [0.9412 0.9412 0.9412] for literal parity with the
%                            old source line.
%
%   GRID RESOLUTION -- nrow dominates.
%     Set nrow alone and ncol is derived as ceil(N/nrow).
%     Set ncol alone and nrow is derived as ceil(N/ncol).
%     Set both and if they cannot hold N panels, NROW IS KEPT and ncol is
%     raised to ceil(N/nrow), with a warning. nrow never changes silently.
%     The 'percent' ylabel follows the grid: it goes on the first panel of
%     every row, which at the default ncol=3 is panels 1 and 4, as before.
%
%   See also PLOTIRF_PAPER_INDIVIDUAL.

    % ---- defaults ---------------------------------------------------------
    % Chosen to match plotIRF_paper_resubmit's OUTPUT, so a call with no prefs
    % reproduces the paper's Figures 3 and 4. The one deliberate divergence from
    % its source is 'color' -- see the help text above.
    D = struct( ...
        'CJ',               1, ...
        'NOISE',            0, ...
        'SLIDE',            0, ...
        'confidence_bands', 1, ...
        'nrow',             2, ...
        'ncol',             3, ...
        'position',         [1 1 4/3*550 4/3*550*2/4.5], ...
        'xtick',            [-20, -10, 0, 10, 20], ...
        'color',            'w', ...
        'ylab',             'percent', ...
        'overlay',          []);

    % One argument (or none): hand back the defaults and stop.
    if nargin <= 1
        fout = D;
        return
    end

    if nargin < 5 || isempty(select_vars); select_vars = 1:size(order,1); end
    if nargin < 6;                         prefs       = struct();       end

    % ---- merge user preferences over the defaults -------------------------
    % Unknown fields are an error rather than a silent no-op: a typo'd 'nrows'
    % would otherwise leave the layout at its default with no indication why.
    u   = prefs;
    bad = setdiff(fieldnames(u), fieldnames(D));
    if ~isempty(bad)
        error('plotIRF:unknownPref', 'Unknown preference(s): %s. Valid: %s.', ...
              strjoin(bad(:)', ', '), strjoin(fieldnames(D)', ', '));
    end
    prefs = D;
    for f = fieldnames(u)'
        prefs.(f{1}) = u.(f{1});
    end

    [nimp,~,~] = size(data);
    [~,nvars]  = size(vars);
    N          = size(order,1);
    nfig       = size(order,2);

    % Catches the common form of the offset trap: VARS shorter than the real
    % variable list makes nvars too small, so nvars+order points into the
    % variance-share half instead of the impulse-response half. This only
    % detects the out-of-range case; a short-but-in-range VARS is undetectable
    % here, so keep passing the full name list.
    if size(data,2) < nvars + max(order(:))
        error('plotIRF:dataTooNarrow', ...
              ['DATA has %d columns but the largest index read is %d ' ...
               '(nvars=%d from VARS, max(ORDER)=%d). VARS is probably not the ' ...
               'full variable list.'], ...
              size(data,2), nvars + max(order(:)), nvars, max(order(:)));
    end

    % ---- resolve the grid; nrow dominates ---------------------------------
    hasR = isfield(u,'nrow');
    hasC = isfield(u,'ncol');
    if      hasR && ~hasC; prefs.ncol = ceil(N / prefs.nrow);
    elseif ~hasR &&  hasC; prefs.nrow = ceil(N / prefs.ncol);
    end
    if prefs.nrow * prefs.ncol < N
        wanted     = prefs.ncol;
        prefs.ncol = ceil(N / prefs.nrow);
        warning('plotIRF:gridInconsistent', ...
                ['nrow=%d, ncol=%d holds %d panels but %d were asked for. ' ...
                 'nrow dominates: ncol raised to %d.'], ...
                prefs.nrow, wanted, prefs.nrow*wanted, N, prefs.ncol);
    end

    % NOISE may be a SCALAR -- one colour for the whole figure, the historical
    % behaviour -- or a VECTOR with one entry per panel, so a single figure can
    % mix technology (blue) and noise (red) panels. Figure B.1 needs the latter:
    % its two panels are the two SHOCKS, not two variables.
    nz = prefs.NOISE(:)';
    if isscalar(nz); nz = repmat(nz, 1, N); end
    assert(numel(nz) == N, 'plotIRF:noiseLen', ...
        'prefs.NOISE has %d entries but there are %d panels', numel(nz), N);
    LINES = repmat({'-b'}, 1, N);
    LINES(nz == 1) = {'-r'};

    if prefs.CJ == 1
        XX2 = 0:20;      XX2reverse = 20:-1:0;
        XX  = -20:20;    XXreverse  = 20:-1:-20;
    else
        XX  = 1:nimp;    XXreverse  = nimp:-1:1;
    end

    % ---- draw -------------------------------------------------------------
    fout = gobjects(1,nfig);          % gobjects, not zeros: real handles
    for ff = 1:nfig
        fout(ff) = figure('Color',prefs.color, ...
                          'Position',prefs.position,'Name',Title);
        gg = gobjects(1,N);
        bh = gobjects(1,N);           % the MAIN line per panel, for the legend
        for n = 1:N
            gg(n) = subplot(prefs.nrow, prefs.ncol, n);
            hold on;
            if sum(n == select_vars) == 1
                if ndims(data) == 3          % if available, plot confidence bands
                    if prefs.SLIDE == 1      % from the shock onward only
                        if prefs.confidence_bands == 2      % outer band
                            grpyat = [(XX2)' data(21:end,nvars+order(n,ff),4); (XX2reverse)' data(nimp:-1:21,nvars+order(n,ff),5)];
                            patch(grpyat(:,1),grpyat(:,2),[0.9 0.9 0.9],'edgecolor',[0.9 0.9 0.9]);
                        end
                        grpyat = [(XX2)' data(21:end,nvars+order(n,ff),2); (XX2reverse)' data(nimp:-1:21,nvars+order(n,ff),3)];
                        patch(grpyat(:,1),grpyat(:,2),[0.7 0.7 0.7],'edgecolor',[0.7 0.7 0.7]);
                    else
                        if prefs.confidence_bands == 2      % outer band
                            grpyat = [(XX)' data(1:end,nvars+order(n,ff),4); (XXreverse)' data(nimp:-1:1,nvars+order(n,ff),5)];
                            patch(grpyat(:,1),grpyat(:,2),[0.9 0.9 0.9],'edgecolor',[0.9 0.9 0.9]);
                        end
                        grpyat = [(XX)' data(1:end,nvars+order(n,ff),2); (XXreverse)' data(nimp:-1:1,nvars+order(n,ff),3)];
                        patch(grpyat(:,1),grpyat(:,2),[0.7 0.7 0.7],'edgecolor',[0.7 0.7 0.7]);
                    end
                end

                % OVERLAY BAND, drawn here rather than with the overlay's line
                % below. A 2-D patch has no z-order of its own -- it simply goes
                % on top of whatever is already drawn -- so adding it after the
                % lines would bury them. Semi-transparent, so the baseline's grey
                % band stays legible underneath. Inner band only: two full
                % two-band stacks per panel is unreadable at this size.
                if ~isempty(prefs.overlay) && sum(n == select_vars) == 1 ...
                        && isfield(prefs.overlay,'band') && ~isempty(prefs.overlay.band) ...
                        && prefs.overlay.band
                    ovb = prefs.overlay;
                    bc  = [0.55 0.70 0.95];
                    if isfield(ovb,'bandcolor') && ~isempty(ovb.bandcolor)
                        bc = ovb.bandcolor;
                    end
                    if prefs.SLIDE == 1
                        gp = [(XX2)' ovb.data(21:end,nvars+order(n,ff),2); ...
                              (XX2reverse)' ovb.data(nimp:-1:21,nvars+order(n,ff),3)];
                    else
                        gp = [(XX)' ovb.data(1:end,nvars+order(n,ff),2); ...
                              (XXreverse)' ovb.data(nimp:-1:1,nvars+order(n,ff),3)];
                    end
                    patch(gp(:,1), gp(:,2), bc, 'EdgeColor','none', 'FaceAlpha',0.35);
                end

                bh(n) = plot(XX, data(:,nvars+order(n,ff),1), LINES{n}, 'LineWidth',2);
            end

            % Overlay: a second run's response, no bands. Drawn AFTER the main
            % line so it sits on top, and only where the panel has a line at all.
            if ~isempty(prefs.overlay) && sum(n == select_vars) == 1
                ov = prefs.overlay;
                if ~isfield(ov,'style') || isempty(ov.style); ov.style = '--k'; end
                ovh = plot(XX, ov.data(:,nvars+order(n,ff),1), ov.style, 'LineWidth',2);
                % An RGB the linespec cannot express. Set after the fact so
                % ov.style keeps deciding the MARKER and DASH pattern.
                if isfield(ov,'color') && ~isempty(ov.color); ovh.Color = ov.color; end
                if isfield(ov,'label') && ~isempty(ov.label) && n == N
                    % Centred under the FIGURE, not under the last panel.
                    % 'southoutside' anchors to the axes it belongs to, which
                    % puts it under the right-hand panel on a 1x2 grid.
                    % FontSize explicit: the default is ~9 (90% of the axes
                    % font), which reads small against the 11pt titles and 10pt
                    % ylabels around it. 10 matches the ylabels.
                    % TWO ENTRIES WHEN .baselabel IS SET. Without it the legend
                    % names the overlay alone, which reads as though the
                    % unlabelled line were the thing being compared TO nothing.
                    % Both handles live in THIS panel's axes, which is what
                    % legend requires; bh(n) is empty if panel n carries no main
                    % line, so it is checked rather than assumed.
                    lgh = ovh;  lgt = {ov.label};
                    if isfield(ov,'baselabel') && ~isempty(ov.baselabel) ...
                            && isgraphics(bh(n))
                        lgh = [bh(n), ovh];  lgt = {ov.baselabel, ov.label};
                    end
                    lg = legend(lgh, lgt, 'Orientation','horizontal', ...
                                'Interpreter','latex', 'Box','off', 'FontSize',10);
                    lg.Units = 'normalized';

                    % MAKE ROOM ONLY IF THERE IS NOT ROOM, and take it from the
                    % stack as a whole.
                    %
                    % This used to subtract a flat 0.13 from EVERY panel's
                    % height. On B.12's 1x2 grid, where a panel is 0.815 of the
                    % figure tall, that costs 16%. On a 3x2 grid, where a panel
                    % is 0.235, it costs 55% -- which is why Figures R.2/R.3
                    % looked squeezed against Figure B.3 even though they share
                    % its 425x400 canvas AND its 3x2 grid.
                    %
                    % PLOTIRF_PAPER_INDIVIDUAL, which draws B.3/B.4, never moves
                    % its panels: it drops the legend into the margin subplot
                    % already leaves below the bottom row. That works when the
                    % margin holds the tick labels AND the legend -- true on a
                    % 400pt canvas, false on B.12's 189pt one, where the same
                    % fraction is only 21pt. Hence the room is MEASURED rather
                    % than assumed: TightInset(2) is what the labels occupy, and
                    % only the shortfall is reclaimed. On a B.3-shaped figure the
                    % shortfall is ~0 and the panels keep their full size.
                    %
                    % Reclaimed by an AFFINE squeeze of the whole stack onto
                    % [need, 1], not a subtraction per panel, so every grid gives
                    % up the same FRACTION and the row spacing stays proportional.
                    drawnow                       % TightInset needs a laid-out figure
                    STRIP = 0.0147 + 0.04;        % the legend box, as B.3 places it
                    CLEAR = 0.012;                % breathing room below it
                    axn   = gg(isgraphics(gg));
                    low   = Inf;
                    for a = axn
                        ti  = get(a, 'TightInset');
                        low = min(low, a.Position(2) - ti(2));
                    end
                    need = STRIP + CLEAR - low;
                    if need > 0
                        s = 1 - need;
                        for a = axn
                            a.Position(2) = need + a.Position(2)*s;
                            a.Position(4) = a.Position(4)*s;
                        end
                    end
                    lg.Position(1) = 0.5 - lg.Position(3)/2;   % centre on the figure
                    lg.Position(2) = 0.0147;                   % B.3's legend baseline
                end
            end

            zl = plot(XX, zeros(nimp,1), '--k', 'linewidth',0.5);
            % Keep the zero line OUT of any legend. It is drawn after the overlay,
            % so an existing legend would otherwise auto-adopt it as 'data1'.
            zl.Annotation.LegendInformation.IconDisplayStyle = 'off';
            title(vars{order(n,ff)},'FontSize',11,'Interpreter','latex')
            if mod(n-1, prefs.ncol) == 0      % first panel of each row
                ylabel(local_ylab(prefs.ylab, n),'FontSize',10,'Interpreter','latex')
            end
            set(gca,'TickLabelInterpreter','latex')
            ax = gca;
            if ~isempty(prefs.xtick); ax.XTick = prefs.xtick; end
            axis tight
            hold off; grid on; box off
        end

        % Centre a lone third figure-column, as before.
        if size(order,2) == 3
            pos = get(gg,'Position');
            new = mean(cellfun(@(v)v(1), pos(1:2)));
            set(gg(3),'Position',[new, pos{end}(2:end)])
        end
    end
end

function t = local_ylab(y, n)
%LOCAL_YLAB  The y-label for panel n. Char -> same everywhere; cell -> per panel.
    if ischar(y) || isstring(y)
        t = y;
    elseif iscell(y)
        if n <= numel(y); t = y{n}; else; t = ''; end
    else
        t = 'percent';
    end
end
