function [fout, prefs] = plotIRF(data, order, vars, Title, select_vars, prefs)
%PLOTIRF  Impulse-response panel figure, configured by a preferences struct.
%
%   [F, P] = plotIRF(data, order, vars, Title)
%   [F, P] = plotIRF(data, order, vars, Title, select_vars)
%   [F, P] = plotIRF(data, order, vars, Title, select_vars, prefs)
%   P = plotIRF()      returns the default preferences and draws nothing.
%
%   data         nimp x 2*nvars x 5. Columns nvars+1..2*nvars are the impulse
%                responses, which is the half this function reads. Pages:
%                1 = point estimate, 2/3 = inner band, 4/5 = outer band.
%   order        N x nfig. Rows are the variables to plot, in panel order; each
%                column makes a separate figure.
%   vars         cell array of panel titles. Its length sets the offset into
%                data, so it must be the full variable list.
%   Title        figure Name. No file is written; the caller saves the figure.
%   select_vars  panel positions that get a line and bands; the rest get only
%                the zero line. Default 1:N.
%   prefs        struct of preferences. Unknown fields are an error.
%     CJ                1    1 = x-axis -20:20 with the shock at 0; 0 = 1:nimp.
%     NOISE             0    0 = blue line, 1 = red. A scalar, or one entry
%                            per panel.
%     SLIDE             0    1 = draw the bands from the shock onward only.
%     confidence_bands  1    1 = inner band only; 2 = also the outer band.
%     nrow              2    rows of panels.
%     ncol              3    columns of panels.
%     position               figure Position, in pixels.
%     xtick    [-20 -10 0 10 20]   x ticks; [] for automatic, as CJ = 0 needs.
%     color           'w'    figure background.
%     ylab       'percent'   y-axis label on the first panel of each row. A char
%                            applies to every labelled panel; a cell of length N
%                            gives one entry per panel. The interpreter is
%                            latex, so a percent sign is written \%.
%     overlay          []    a second line per panel, for comparing runs. Struct:
%                              .data       same shape and row layout as data
%                              .style      linespec (default '--k')
%                              .label      legend text; a legend is drawn if set
%                              .baselabel  legend text for the main line
%                              .color      RGB for the line, overriding the
%                                          colour in .style
%                              .band       true to draw the overlay's inner band
%                              .bandcolor  RGB of that band (default light blue)
%
%   F   handles of the figures created, one per column of order.
%   P   the preferences used, after defaults and grid resolution.
%
%   Grid: if only nrow is set, ncol = ceil(N/nrow), and the reverse. If both
%   are set and cannot hold N panels, nrow is kept and ncol is raised, with a
%   warning.
%
%   See also PLOTIRF_PAPER_INDIVIDUAL.

    % Defaults.
    D = struct( ...
        'CJ',               1, ...
        'NOISE',            0, ...
        'SLIDE',            0, ...
        'confidence_bands', 1, ...
        'nrow',             2, ...
        'ncol',             3, ...
        'position',         [1 1 4/3*550 4/3*550*2/4.5], ...
        'xtick',            [-20, -10, 0, 10, 20], ...
        'color',            'w', ...
        'ylab',             'percent', ...
        'overlay',          []);

    % One argument or none: return the defaults.
    if nargin <= 1
        fout = D;
        return
    end

    if nargin < 5 || isempty(select_vars); select_vars = 1:size(order,1); end
    if nargin < 6;                         prefs       = struct();       end

    % Merge the user's preferences over the defaults.
    u   = prefs;
    bad = setdiff(fieldnames(u), fieldnames(D));
    if ~isempty(bad)
        error('plotIRF:unknownPref', 'Unknown preference(s): %s. Valid: %s.', ...
              strjoin(bad(:)', ', '), strjoin(fieldnames(D)', ', '));
    end
    prefs = D;
    for f = fieldnames(u)'
        prefs.(f{1}) = u.(f{1});
    end

    [nimp,~,~] = size(data);
    [~,nvars]  = size(vars);
    N          = size(order,1);
    nfig       = size(order,2);

    % vars must be the full variable list, so that nvars+order indexes the
    % impulse-response half of data.
    if size(data,2) < nvars + max(order(:))
        error('plotIRF:dataTooNarrow', ...
              ['DATA has %d columns but the largest index read is %d ' ...
               '(nvars=%d from VARS, max(ORDER)=%d). VARS is probably not the ' ...
               'full variable list.'], ...
              size(data,2), nvars + max(order(:)), nvars, max(order(:)));
    end

    % Resolve the grid; nrow takes precedence.
    hasR = isfield(u,'nrow');
    hasC = isfield(u,'ncol');
    if      hasR && ~hasC; prefs.ncol = ceil(N / prefs.nrow);
    elseif ~hasR &&  hasC; prefs.nrow = ceil(N / prefs.ncol);
    end
    if prefs.nrow * prefs.ncol < N
        wanted     = prefs.ncol;
        prefs.ncol = ceil(N / prefs.nrow);
        warning('plotIRF:gridInconsistent', ...
                ['nrow=%d, ncol=%d holds %d panels but %d were asked for. ' ...
                 'nrow dominates: ncol raised to %d.'], ...
                prefs.nrow, wanted, prefs.nrow*wanted, N, prefs.ncol);
    end

    % Line colour per panel. NOISE is a scalar or has one entry per panel.
    nz = prefs.NOISE(:)';
    if isscalar(nz); nz = repmat(nz, 1, N); end
    assert(numel(nz) == N, 'plotIRF:noiseLen', ...
        'prefs.NOISE has %d entries but there are %d panels', numel(nz), N);
    LINES = repmat({'-b'}, 1, N);
    LINES(nz == 1) = {'-r'};

    % x-axis.
    if prefs.CJ == 1
        XX2 = 0:20;      XX2reverse = 20:-1:0;
        XX  = -20:20;    XXreverse  = 20:-1:-20;
    else
        XX  = 1:nimp;    XXreverse  = nimp:-1:1;
    end

    % Draw.
    fout = gobjects(1,nfig);
    for ff = 1:nfig
        fout(ff) = figure('Color',prefs.color, ...
                          'Position',prefs.position,'Name',Title);
        gg = gobjects(1,N);
        bh = gobjects(1,N);           % the main line of each panel, for the legend
        for n = 1:N
            gg(n) = subplot(prefs.nrow, prefs.ncol, n);
            hold on;
            if sum(n == select_vars) == 1
                if ndims(data) == 3          % confidence bands
                    if prefs.SLIDE == 1      % from the shock onward only
                        if prefs.confidence_bands == 2      % outer band
                            grpyat = [(XX2)' data(21:end,nvars+order(n,ff),4); (XX2reverse)' data(nimp:-1:21,nvars+order(n,ff),5)];
                            patch(grpyat(:,1),grpyat(:,2),[0.9 0.9 0.9],'edgecolor',[0.9 0.9 0.9]);
                        end
                        grpyat = [(XX2)' data(21:end,nvars+order(n,ff),2); (XX2reverse)' data(nimp:-1:21,nvars+order(n,ff),3)];
                        patch(grpyat(:,1),grpyat(:,2),[0.7 0.7 0.7],'edgecolor',[0.7 0.7 0.7]);
                    else
                        if prefs.confidence_bands == 2      % outer band
                            grpyat = [(XX)' data(1:end,nvars+order(n,ff),4); (XXreverse)' data(nimp:-1:1,nvars+order(n,ff),5)];
                            patch(grpyat(:,1),grpyat(:,2),[0.9 0.9 0.9],'edgecolor',[0.9 0.9 0.9]);
                        end
                        grpyat = [(XX)' data(1:end,nvars+order(n,ff),2); (XXreverse)' data(nimp:-1:1,nvars+order(n,ff),3)];
                        patch(grpyat(:,1),grpyat(:,2),[0.7 0.7 0.7],'edgecolor',[0.7 0.7 0.7]);
                    end
                end

                % Overlay band, drawn before the lines so that it lies beneath
                % them.
                if ~isempty(prefs.overlay) && sum(n == select_vars) == 1 ...
                        && isfield(prefs.overlay,'band') && ~isempty(prefs.overlay.band) ...
                        && prefs.overlay.band
                    ovb = prefs.overlay;
                    bc  = [0.55 0.70 0.95];
                    if isfield(ovb,'bandcolor') && ~isempty(ovb.bandcolor)
                        bc = ovb.bandcolor;
                    end
                    if prefs.SLIDE == 1
                        gp = [(XX2)' ovb.data(21:end,nvars+order(n,ff),2); ...
                              (XX2reverse)' ovb.data(nimp:-1:21,nvars+order(n,ff),3)];
                    else
                        gp = [(XX)' ovb.data(1:end,nvars+order(n,ff),2); ...
                              (XXreverse)' ovb.data(nimp:-1:1,nvars+order(n,ff),3)];
                    end
                    patch(gp(:,1), gp(:,2), bc, 'EdgeColor','none', 'FaceAlpha',0.35);
                end

                bh(n) = plot(XX, data(:,nvars+order(n,ff),1), LINES{n}, 'LineWidth',2);
            end

            % Overlay line, drawn after the main line so that it lies on top.
            if ~isempty(prefs.overlay) && sum(n == select_vars) == 1
                ov = prefs.overlay;
                if ~isfield(ov,'style') || isempty(ov.style); ov.style = '--k'; end
                ovh = plot(XX, ov.data(:,nvars+order(n,ff),1), ov.style, 'LineWidth',2);
                % The colour is set afterwards, so ov.style still sets the dash
                % pattern.
                if isfield(ov,'color') && ~isempty(ov.color); ovh.Color = ov.color; end
                if isfield(ov,'label') && ~isempty(ov.label) && n == N
                    % Legend, centred under the figure. It names the overlay,
                    % and the main line too when .baselabel is set.
                    lgh = ovh;  lgt = {ov.label};
                    if isfield(ov,'baselabel') && ~isempty(ov.baselabel) ...
                            && isgraphics(bh(n))
                        lgh = [bh(n), ovh];  lgt = {ov.baselabel, ov.label};
                    end
                    lg = legend(lgh, lgt, 'Orientation','horizontal', ...
                                'Interpreter','latex', 'Box','off', 'FontSize',10);
                    lg.Units = 'normalized';

                    % Make room for the legend if the margin below the panels
                    % is too small: measure what the tick labels leave
                    % (TightInset) and squeeze the whole stack of panels upward
                    % by the shortfall, in proportion.
                    drawnow                       % TightInset needs a laid-out figure
                    STRIP = 0.0147 + 0.04;        % top of the legend strip
                    CLEAR = 0.012;                % clearance above it
                    axn   = gg(isgraphics(gg));
                    low   = Inf;
                    for a = axn
                        ti  = get(a, 'TightInset');
                        low = min(low, a.Position(2) - ti(2));
                    end
                    need = STRIP + CLEAR - low;
                    if need > 0
                        s = 1 - need;
                        for a = axn
                            a.Position(2) = need + a.Position(2)*s;
                            a.Position(4) = a.Position(4)*s;
                        end
                    end
                    lg.Position(1) = 0.5 - lg.Position(3)/2;   % centre on the figure
                    lg.Position(2) = 0.0147;                   % legend baseline
                end
            end

            zl = plot(XX, zeros(nimp,1), '--k', 'linewidth',0.5);
            % Keep the zero line out of the legend.
            zl.Annotation.LegendInformation.IconDisplayStyle = 'off';
            title(vars{order(n,ff)},'FontSize',11,'Interpreter','latex')
            if mod(n-1, prefs.ncol) == 0      % first panel of each row
                ylabel(local_ylab(prefs.ylab, n),'FontSize',10,'Interpreter','latex')
            end
            set(gca,'TickLabelInterpreter','latex')
            ax = gca;
            if ~isempty(prefs.xtick); ax.XTick = prefs.xtick; end
            axis tight
            hold off; grid on; box off
        end

        % When order has three columns, centre the third panel.
        if size(order,2) == 3
            pos = get(gg,'Position');
            new = mean(cellfun(@(v)v(1), pos(1:2)));
            set(gg(3),'Position',[new, pos{end}(2:end)])
        end
    end
end

function t = local_ylab(y, n)
%LOCAL_YLAB  The y-label for panel n: a char applies to every panel, a cell
%   gives one label per panel.
    if ischar(y) || isstring(y)
        t = y;
    elseif iscell(y)
        if n <= numel(y); t = y{n}; else; t = ''; end
    else
        t = 'percent';
    end
end
