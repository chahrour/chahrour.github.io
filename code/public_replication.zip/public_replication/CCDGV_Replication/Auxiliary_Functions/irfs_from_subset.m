function IR_full = irfs_from_subset(AR_full, Sig_full, AR_r, Sig_r, idxA, IR_sub, H, Nfft, A_full, A_r, ridge)
%IRFS_FROM_SUBSET  Full-system IRFs to a shock identified from a subset of variables.
%
%   IR_full = irfs_from_subset(AR_full, Sig_full, AR_r, Sig_r, idxA, IR_sub, ...
%                              H, Nfft, A_full, A_r, ridge)
%
%   AR_full, Sig_full  the full VAR.
%   AR_r, Sig_r        the restricted VAR of the subset (IMPLIED_RESTRICTED_VAR).
%   idxA      rows of A_full that hold the subset's k variables. These index
%             rows of A_full, not columns of the VAR.
%   IR_sub    (H+1) x k response of the subset system, columns in idxA order,
%             stored two-sided with the negative lags first.
%   H         number of rows of IR_sub, less one.
%   Nfft      FFT length.
%   A_full    the rows of A for the full system.
%   A_r       the subset selector [I_k 0].
%   ridge     Tikhonov term added to the subset spectrum f_S; 0 for none.
%
%   IR_full   (H+1) x size(A_full,1), in the same two-sided convention.
%
%   Method. The filter that recovers the shock from the subset is
%
%       psi_S*(w) = f_S(w)^{-1} T_S(w),        T_S = fft(IR_sub).
%
%   It is embedded in the full variable space with zeros on the excluded rows,
%   so that the shock is a function of the subset's history only, and the full
%   system's spectrum is applied:
%
%       T_full(w) = f_y(w) psi(w)*,            IR_full = ifft(T_full).
%
%   The excluded variables' responses therefore come from the full VAR's
%   spectrum; they are not a projection on the subset's state.
%
%   See also NOFX_BUILD_IRFS, NOFX_RESTRICTED.

    n = size(A_full,1);
    k = numel(idxA);
    z = exp(-1i*2*pi*(0:Nfft-1)/Nfft);

    % T_S(w) from the subset IRFs, zero-padded to the FFT length.
    TS = zeros(k, 1, Nfft);
    pad = Nfft - (H+1);
    for a = 1:k
        TS(a,1,:) = fft([IR_sub(:,a); zeros(pad,1)]);
    end

    % psi_S*(w) = f_S(w)^{-1} T_S(w), from the restricted system.
    PsiS = tf_sweep(A_r, companion(AR_r), loading(AR_r), z);      % k x nr x Nfft
    FS   = pagemtimes(pagemtimes(PsiS, Sig_r), 'none', PsiS, 'ctranspose');
    if ridge > 0; FS = FS + ridge*eye(k); end
    psiS = zeros(k, 1, Nfft);
    for kf = 1:Nfft                       % one small k x k solve per frequency
        psiS(:,:,kf) = FS(:,:,kf) \ TS(:,:,kf);
    end
    clear PsiS FS TS

    % T_full(w) = f_y(w) psi(w)*, with zeros on the excluded rows. Multiplying
    % right to left avoids forming the n x n spectrum.
    Psi = tf_sweep(A_full, companion(AR_full), loading(AR_full), z);
    Tfull = pagemtimes(Psi, pagemtimes(Sig_full, ...
                pagemtimes(Psi(idxA,:,:), 'ctranspose', psiS, 'none')));
    clear Psi

    % Back to the time domain.
    IR_full = zeros(H+1, n);
    for r = 1:n
        ir = ifft(squeeze(Tfull(r,1,:)), 'symmetric');
        IR_full(:,r) = ir(1:H+1);
    end
end

function B = companion(AR)
%   Companion matrix of a VAR with coefficient block AR.
    [n, np] = size(AR);
    B = [AR; [eye(np-n), zeros(np-n, n)]];
end

function C = loading(AR)
%   Loading of the innovations on the companion state.
    [n, np] = size(AR);
    C = [eye(n); zeros(np-n, n)];
end
