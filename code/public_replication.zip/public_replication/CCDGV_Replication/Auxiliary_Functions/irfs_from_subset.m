function IR_full = irfs_from_subset(AR_full, Sig_full, AR_r, Sig_r, idxA, IR_sub, H, Nfft, A_full, A_r, ridge)
%IRFS_FROM_SUBSET  Full-system IRFs to a shock identified from a subset of variables.
%
%   IR_full = IRFS_FROM_SUBSET(AR_full,Sig_full,AR_r,Sig_r,idxA,IR_sub,H,Nfft,A_full,A_r,ridge)
%
%   IR_sub    (H+1) x k, the subset system's response, columns in idxA order
%   idxA      rows of A_full holding those same k variables  (NOT VAR columns)
%   A_full    the full manifest basis; A_r  the subset selector [I_k 0]
%   ridge     Tikhonov term on f_S; both paper callers pass 0
%
%   IR_full   (H+1) x size(A_full,1)
%
%   METHOD. Recover the shock-recovery filter from the RESTRICTED system,
%
%       psi_S*(w) = f_S(w)^{-1} T_S(w),        T_S = fft(IR_sub)
%
%   embed it in the full variable space with ZEROS on every excluded row -- the
%   statement that the shock is a function of the subset's history only -- and
%   then apply the FULL system's spectrum:
%
%       T_full(w) = f_y(w) psi(w)*,            IR_full = ifft(T_full)
%
%   THIS IS NOT A PROJECTION. The excluded variables' responses come from the
%   full VAR's own spectrum, so they are that system's responses to a shock
%   identified without them -- not a regression of them on the subset's state.
%   The distinction matters for Figure B.12, whose dashed RER line is often
%   described as a projection and is not one.
%
%   TWO INDEX SPACES. idxA indexes rows of A_full, which under the manifest is
%   [Aproj; constructed] -- NOT the VAR's columns. For the baseline spec the two
%   coincide (the first 8 manifest rows are the 8 VAR variables) which is exactly
%   why the original's literal [1 2 3 5 6 7 8] worked and would keep appearing to
%   work under the equity specs while being wrong. Resolve by name; see
%   NOFX_RESTRICTED.
%
%   PHASE CONVENTION. IR_sub is stored two-sided with the negative lags first, so
%   its FFT carries a factor e^{-iw*smax}. That factor passes through the linear
%   operations above unchanged and the IFFT returns the same convention, so
%   caller and callee agree without an explicit shift.
%
%   DEVIATION FROM THE ORIGINAL: the full spectrum is formed one frequency at a
%   time rather than materialised as an n x n x Nfft array (360 MB at 30 rows,
%   per worker). Arithmetic is identical; verified to 6e-14 in VERIFY_NOFX_PORT.
%   The original's `idxZ`/`m` were dead and are dropped.
%
%   PORTED from No_FX_Analysis/irfs_from_subset.m.
%
%   See also NOFX_BUILD_IRFS, NOFX_RESTRICTED.

    n = size(A_full,1);
    k = numel(idxA);
    z = exp(-1i*2*pi*(0:Nfft-1)/Nfft);

    % T_S(w) from the subset IRFs, zero-padded to the FFT length
    TS = zeros(k, 1, Nfft);
    pad = Nfft - (H+1);
    for a = 1:k
        TS(a,1,:) = fft([IR_sub(:,a); zeros(pad,1)]);
    end

    % psi_S*(w) = f_S(w)^{-1} T_S(w), from the RESTRICTED system
    PsiS = tf_sweep(A_r, companion(AR_r), loading(AR_r), z);      % k x nr x Nfft
    FS   = pagemtimes(pagemtimes(PsiS, Sig_r), 'none', PsiS, 'ctranspose');
    if ridge > 0; FS = FS + ridge*eye(k); end
    psiS = zeros(k, 1, Nfft);
    for kf = 1:Nfft                       % k x k, too small for pagemldivide to pay
        psiS(:,:,kf) = FS(:,:,kf) \ TS(:,:,kf);
    end
    clear PsiS FS TS

    % T_full(w) = f_y(w) psi(w)*, with zeros on the excluded rows. Folded right
    % to left so the n x n spectrum is never formed: only its idxA columns act.
    Psi = tf_sweep(A_full, companion(AR_full), loading(AR_full), z);
    Tfull = pagemtimes(Psi, pagemtimes(Sig_full, ...
                pagemtimes(Psi(idxA,:,:), 'ctranspose', psiS, 'none')));
    clear Psi

    IR_full = zeros(H+1, n);
    for r = 1:n
        ir = ifft(squeeze(Tfull(r,1,:)), 'symmetric');
        IR_full(:,r) = ir(1:H+1);
    end
end

% -------------------------------------------------------------------------
function B = companion(AR)
    [n, np] = size(AR);
    B = [AR; [eye(np-n), zeros(np-n, n)]];
end

function C = loading(AR)
    [n, np] = size(AR);
    C = [eye(n); zeros(np-n, n)];
end
