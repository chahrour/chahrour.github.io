function [AR_r, Sig_r] = implied_restricted_var(AR, Sig, idxV)
%IMPLIED_RESTRICTED_VAR  The VAR(p) that a full VAR implies for a subset of its variables.
%
%   [AR_r, Sig_r] = implied_restricted_var(AR, Sig, idxV)
%
%   AR     n x (n*p), concatenated [B1 ... Bp].
%   Sig    n x n reduced-form covariance.
%   idxV   columns of the VAR to keep.
%   AR_r   k x (k*p) coefficients of the population projection of the subset on
%          its own p lags, k = numel(idxV).
%   Sig_r  covariance of that projection's residual.
%
%   Nothing is fitted to data: this is the VAR(p) one would recover from the
%   subset alone if the full system were the truth. The subset's marginal
%   process is a VARMA, so the VAR(p) is an approximation to it.
%
%   Method: solve the discrete Lyapunov equation for the companion state,
%   Sx = B Sx B' + C Sig C', read off the autocovariances
%   Gam(h) = S B^h Sx S' for h = 0..p, restrict them to idxV, and solve the
%   block-Toeplitz Yule-Walker system.
%
%   See also NOFX_BUILD_IRFS, NOFX_RESTRICTED.

    % Companion form.
    [n, np] = size(AR);
    p  = np/n;
    nx = n*p;
    B = [AR; [eye(nx-n), zeros(nx-n,n)]];
    C = [eye(n); zeros(nx-n,n)];

    % State covariance from the Lyapunov equation.
    Sx = reshape((eye(nx^2) - kron(B,B)) \ reshape(C*Sig*C', [], 1), nx, nx);

    % Autocovariances of the observables at lags 0..p, restricted to idxV.
    S = [eye(n), zeros(n, nx-n)];
    G = cell(1, p+1);  Bh = eye(nx);
    for h = 0:p
        G{h+1} = S*Bh*Sx*S';
        Bh = Bh*B;
    end
    G = cellfun(@(g) g(idxV,idxV), G, 'UniformOutput', false);

    % Block-Toeplitz Yule-Walker system.
    k  = numel(idxV);
    ZZ = zeros(k*p);
    for a = 1:p
        for b = 1:p
            d = b - a;
            if d >= 0; blk = G{d+1}; else; blk = G{-d+1}'; end
            ZZ((a-1)*k+(1:k), (b-1)*k+(1:k)) = blk;
        end
    end
    yZ = cell2mat(G(2:p+1));

    AR_r  = yZ / ZZ;
    Sig_r = G{1} - AR_r*yZ';
    Sig_r = (Sig_r + Sig_r')/2;      % symmetrise
end
