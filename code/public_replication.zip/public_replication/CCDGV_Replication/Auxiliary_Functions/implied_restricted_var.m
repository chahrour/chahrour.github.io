function [AR_r, Sig_r] = implied_restricted_var(AR, Sig, idxV)
%IMPLIED_RESTRICTED_VAR  The VAR(p) a full VAR implies for a subset of its variables.
%
%   [AR_r, Sig_r] = IMPLIED_RESTRICTED_VAR(AR, Sig, idxV)
%
%   AR    n x (n*p), concatenated [B1 ... Bp]
%   Sig   n x n reduced-form covariance
%   idxV  columns of the VAR to keep
%
%   NOT AN ESTIMATE. Nothing is fitted to data. This returns the VAR(p) an
%   econometrician would recover if the full system were the truth and they
%   observed only the subset: the population L2 projection of y^S_t on its own p
%   lags. Answers "what would a no-FX VAR look like if the baseline is right?",
%   which is a different question from what an inclvar = 2 run answers.
%
%   NOT EXACT AS A REPRESENTATION, EXACTLY COMPUTED. The marginal process of a
%   subset of a VAR(p) is a VARMA, not a VAR(p), so the projection genuinely
%   discards something -- that approximation is the object of interest. What is
%   exact is the computation of it.
%
%   METHOD. Solve the discrete Lyapunov equation for the companion state,
%
%       Sx = B Sx B' + C Sig C',
%
%   read off the observables' autocovariances Gam(h) = S B^h Sx S' for h = 0..p,
%   restrict to idxV, and solve the block-Toeplitz Yule-Walker system. Sig_r is
%   the resulting projection residual covariance.
%
%   REPLACES A 2e6-DRAW SIMULATION. The original (No_FX_Analysis/
%   restricted_via_simulation_new.m) simulated the full system and ran OLS on the
%   subset -- the same population object, approached by Monte Carlo. At T = 2e6
%   that left 2-4% error on coefficients of scale ~1.1, enough to move the
%   Figure B.11 noise correlation over 0.7720-0.7754 on fixed data purely with the
%   random seed. This is 55x faster and has no such spread, so the statistic is
%   reproducible. The paper's 0.7724 is one draw from that distribution; computed
%   exactly the same construction gives 0.7743.
%
%   See also NOFX_BUILD_IRFS, NOFX_RESTRICTED.

    [n, np] = size(AR);
    p  = np/n;
    nx = n*p;
    B = [AR; [eye(nx-n), zeros(nx-n,n)]];
    C = [eye(n); zeros(nx-n,n)];

    Sx = reshape((eye(nx^2) - kron(B,B)) \ reshape(C*Sig*C', [], 1), nx, nx);

    S = [eye(n), zeros(n, nx-n)];
    G = cell(1, p+1);  Bh = eye(nx);
    for h = 0:p
        G{h+1} = S*Bh*Sx*S';
        Bh = Bh*B;
    end
    G = cellfun(@(g) g(idxV,idxV), G, 'UniformOutput', false);

    k  = numel(idxV);
    ZZ = zeros(k*p);
    for a = 1:p
        for b = 1:p
            d = b - a;
            if d >= 0; blk = G{d+1}; else; blk = G{-d+1}'; end
            ZZ((a-1)*k+(1:k), (b-1)*k+(1:k)) = blk;
        end
    end
    yZ = cell2mat(G(2:p+1));

    AR_r  = yZ / ZZ;
    Sig_r = G{1} - AR_r*yZ';
    Sig_r = (Sig_r + Sig_r')/2;      % kill the asymmetric rounding; chol follows
end
