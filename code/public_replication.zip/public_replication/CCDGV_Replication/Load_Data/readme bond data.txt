
BOND DATA
================================================================================

The G7 bond series come from Global Financial Data, purchased directly in 2026
and stored as CCDGV_Replication/Raw_Data/gfd_monthly.csv. Monthly, 1970:01 to
2026:08, no interior gaps. Three series per country:

  Country          Yield       Price index   Total return
  Canada           IGCAN10D    PRCANGVM      TRCANGVM
  France           IGFRA10D    PRFRAGVM      TRFRAGVM
  Germany          IGDEU10D    PRDEUGVM      TRDEUGVM
  Italy            IGITA10D    PRITAGVM      TRITAGVM
  Japan            IGJPN10D    PRJPNGVM      TRJPNGVM
  United Kingdom   IGGBR10D    PRGBRGVM      TRGBRGVM
  United States    IGUSA10D    PRUSG10M      TRUSG10M

All local currency. The yields are annualised percent, yields to maturity on
coupon bonds. The total return indices reinvest coupons; the price indices do
not, and the gap between them is what the splice screen in load_bonds.m checks.

"GFD readme.txt" and "G7 10-Year Bond Series Information.xlsx" sit beside the
csv in Raw_Data and carry GFD's own description of each ticker, including the
sources behind the historical splices.

PROVENANCE. These series were previously taken from Bonds_local_M.mat and
Yields_M.mat, a Global Financial Data extract distributed with the Lustig,
Stathopoulos and Verdelhan (2019, AER) replication package. That extract ended
2016:07 and did not contain a ten-year United Kingdom total return series. The
direct purchase replaced it. CCDGV_Replication/Notes/bond_data_vintage/ compares
the two in detail.


================================================================================
CONSTRUCTION CHOICES
================================================================================

Recorded here rather than in the loader, so the code stays readable. Each of
these is a decision a reader could otherwise reverse without noticing.

TIMING. Row t of rx_country holds the return realised DURING quarter t, paired
with the interest differential from t-1:

    logR_t = log(P_t / P_{t-1})
    rx_t   = (logR*_t - logR_t) + idiff_ec_pa_{t-1}

Row 1 is NaN by construction: no return is observable in the first quarter. An
excess return needs the rate from one quarter earlier, not two.

NaN, NEVER ZERO OR ONE. Every series is NaN where there is no observation, and
the panel is padded with NaN rather than extended with ones() or zeros().
log(1) = 0, so a padded price index would enter estimation as a run of exactly
zero returns and survive mean/std/regress without complaint.

WEIGHTS ARE RENORMALISED per quarter over whatever countries are actually
present (wagg), rather than assuming a fixed set of countries has the missing
data. B.wcov reports the weight coverage achieved in each quarter.

IDIFF IS AN ARGUMENT, not loaded inside the loader: the bond returns and the
VAR's short rate must be the same series. Data_Replication/load_interestrates
reads a different workbook that agrees to the last digit on all 12,252
overlapping daily observations, 1975-01-02 to 2021-12-17, every country, so
taking the argument costs nothing numerically and removes the duplication.

pad_to MEANS "EXTEND TO AT LEAST", never "truncate to". The data reach 2026Q2
and the default pad_to is 2018Q4, so on the normal path nothing is padded and
nothing is cut. Surplus quarters are harmless downstream: ryan_data aligns by
date through ismember on Yb.Time, and CCDGV_data_alt_tfp_measures slices to
solow_n.

APPROXIMATIONS. P_t(10y minus one quarter) is proxied by P_t(10y), i.e. the
index is assumed rolled to constant maturity. The yields are yields to maturity
on COUPON bonds, treated as zero-coupon; Lustig, Stathopoulos and Verdelhan flag
the same approximation.

GERMANY. The German series has an implied duration of 7.00, in line with the
5.5-7.5 of the other six countries, so it is the ten-year benchmark it claims to
be. Worth knowing because the series this replaced had two German columns with
durations of about 4.0 and 6.6, and picking between them was not obvious.

THE UNITED KINGDOM TOTAL RETURN INDEX POSTS coupons in March and September
rather than accruing them monthly: mean carry 1.38 and 1.45 pp in those months
against 0.43 pp in the other ten. The mean still matches the yield, and nothing
here uses the monthly frequency. This is why the United Kingdom is exempt from
the splice screen (opt.screen_skip) -- included, it fires about 110 times on a
convention rather than an error.

THE SPLICE SCREEN REPORTS AND DOES NOT REPAIR. GFD indices are chain-linked and
joined at the turn of the calendar year, and at a join the rescaling factor
appears as a one-month return with no economic content. The screen flags a month
when

    |(log TR ret - log PR ret) - y_{t-1}/12| > opt.screen_tol

Twelve months over 1970-2026 across the six countries other than the United
Kingdom trip it, and all twelve are a January or a February. Filtering them
would make any change in a downstream result attributable to the filter rather
than to the data, so the default only prints. Set opt.screen = 'nan' to blank
the flagged months instead; under strict_q that removes the whole quarter.


================================================================================
BOND YIELDS, EARLIER SOURCE
================================================================================

Raw_Data/FRED_10YGOVBONDYIELDS.xls holds the FRED/OECD long-term government bond
yields (IRLTLT01), quarterly, which preceded the GFD yields. Nothing reads it.
Kept because it is the independent cross-check on the GFD yields: over
1976Q1-2018Q4 the two agree to within a basis point on average for every country
except France, where GFD runs about 7 bp lower. See tab "Original Data" for
the series list.
