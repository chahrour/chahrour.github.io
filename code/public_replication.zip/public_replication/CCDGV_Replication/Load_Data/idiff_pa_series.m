function [idiff_ec_pa, t] = idiff_pa_series(src)
%IDIFF_PA_SERIES  Period-average short-rate differentials from the rate panel.
%
%   [idiff_ec_pa, t] = IDIFF_PA_SERIES()           the untagged built panel
%   [idiff_ec_pa, t] = IDIFF_PA_SERIES('_f2026')   that vintage
%   [idiff_ec_pa, t] = IDIFF_PA_SERIES(i_all)      a rate timetable, passed directly
%
%   idiff_ec_pa  T x 7 quarterly LOG short-rate differentials, US MINUS FOREIGN,
%                from 1976Q1. Columns 1:6 are CA FR GE IT JP UK -- the order
%                LOAD_BONDS indexes by -- and column 7 the trade-weighted G6.
%   t            matching quarter-start datetimes
%
%   THE THIRD CALLING FORM IS REQUIRED, NOT A CONVENIENCE. ASSET_PRICE_data, this
%   function's reason for existing, is called from four places, and one of them is
%   data_import_and_transform:704 -- i.e. from INSIDE the basic data build, via
%   asset_price_series. At that moment Y_benchmark*.mat does not exist: the build
%   is in the middle of writing it. A version that could only read the saved panel
%   would deadlock the build. So the build passes the i_all it already holds
%   (computed at :387, well before :704) and standalone callers load it from disk.
%
%   THE SAMPLE IS THE CALLER'S TO DECLARE, NOT THIS FUNCTION'S TO DISCOVER. This
%   returns every quarter the rate panel has, from 1976Q1 to the data's end. It
%   does not trim, and it does not manufacture NaN so that a downstream mask stops
%   in the right place. ASSET_PRICE_data states its own window (AP_START, AP_END)
%   and trims there.
%
%   ONE DIFFERENCE FROM THE RETIRED SCRIPT, and it is the only one: retime's string
%   method 'mean' omits NaN, so the rate panel carries partial-quarter averages at
%   Italy 1978Q2 and Japan 1978Q3, whose Datastream feeds start mid-quarter
%   (1978-06-09, 1978-08-01), so those two cells are averages of part of a
%   quarter rather than of a whole one.
%
%   COLUMN 7 KEEPS THE ORIGINAL CONSTRUCTION, DELIBERATELY: a PLAIN weighted sum of
%   the six, hence NaN wherever a country is missing.
%   Y's own IDIFF column is a different object -- geo_aggregate_spliced renormalises
%   over the countries present and backfills, so it covers 172 quarters against this
%   column's 161. The two agree to 6.9e-18 wherever both exist; only coverage
%   differs. Using Y.IDIFF here would silently change the aggregate load_bonds sees.
%
%   NOT PROVIDED: the end-of-period variant, idiff_ec. The panel carries period
%   averages because cfg.daily_agg is a single global setting fixed at "mean".
%   Nothing live needs the EOP variant from here. The setting that used to select
%   it is gone with the orig core. The
%   Granger figures need EOP rates and build their own, in BUILD_EW_PANEL.
%
%   See also LOAD_BONDS, ASSET_PRICE_DATA, BUILD_EW_PANEL,
%   DATA_IMPORT_AND_TRANSFORM.

    if nargin < 1 || isempty(src); src = ''; end
    if istimetable(src)
        ia = src;                                  % handed in by the build
    else
        here = fileparts(fileparts(mfilename('fullpath')));
        f = fullfile(here, '..', 'Data_Replication', 'Built_Data', ...
                     ['Y_benchmark' char(src) '.mat']);
        assert(isfile(f), 'idiff_pa_series:noPanel', ...
            ['%s not found. It carries the quarterly rate panel. Build it with ' ...
             'Data_Replication/build_all_vintages.m.'], f);
        R = load(f, 'i_all');
        assert(isfield(R,'i_all'), 'idiff_pa_series:noRatePanel', ...
            '%s carries no i_all (the quarterly rate panel). Rebuild it.', f);
        ia = R.i_all;
    end

    NAMES = {'Canada','France','Germany','Italy','Japan','UK'};   % LOAD_BONDS order
    have  = ia.Properties.VariableNames;
    assert(ismember('US', have), 'idiff_pa_series:noUS', ...
        'the rate panel has no US column -- it has %s.', strjoin(have, ', '));
    t  = (datetime(1976,1,1) : calquarters(1) : ia.Time(end))';
    [tf, loc] = ismember([year(t) quarter(t)], ...
                         [year(ia.Time) quarter(ia.Time)], 'rows');
    lus = NaN(numel(t),1);  lus(tf) = log(ia.US(loc(tf)));
    idiff_ec_pa = NaN(numel(t), 7);
    for k = 1:6
        assert(ismember(NAMES{k}, have), 'idiff_pa_series:noColumn', ...
            '"%s" is not a column of the rate panel -- it has %s.', ...
            NAMES{k}, strjoin(have, ', '));
        v = NaN(numel(t),1);  v(tf) = log(ia.(NAMES{k})(loc(tf)));
        idiff_ec_pa(:,k) = lus - v;
    end
    % The trade weights in this column order. A plain sum, NOT renormalised.
    idiff_ec_pa(:,7) = idiff_ec_pa(:,1:6) * [0.0984 0.1599 0.2945 0.1230 0.1843 0.1399]';
end
