function [idiff_ec_pa, t] = idiff_pa_series(src)
%IDIFF_PA_SERIES  Period-average short-rate differentials from the rate panel.
%
%   [idiff_ec_pa, t] = IDIFF_PA_SERIES()           from Y_benchmark.mat
%   [idiff_ec_pa, t] = IDIFF_PA_SERIES('_f2026')   from Y_benchmark_f2026.mat
%   [idiff_ec_pa, t] = IDIFF_PA_SERIES(i_all)      from a rate timetable
%
%   idiff_ec_pa  T x 7 quarterly log short-rate differentials, US minus foreign,
%                from 1976Q1 to the end of the panel. Columns 1:6 are CA FR GE IT
%                JP UK, the order LOAD_BONDS uses. Column 7 is the trade-weighted
%                G6, a plain weighted sum that is NaN when any country is missing.
%   t            matching quarter-start datetimes
%
%   The data build passes i_all directly, because Y_benchmark is not yet written
%   when it calls this.
%
%   See also LOAD_BONDS, ASSET_PRICE_DATA, DATA_IMPORT_AND_TRANSFORM.

    if nargin < 1 || isempty(src); src = ''; end
    if istimetable(src)
        ia = src;                                  % passed in by the build
    else
        here = fileparts(fileparts(mfilename('fullpath')));
        f = fullfile(here, '..', 'Data_Replication', 'Built_Data', ...
                     ['Y_benchmark' char(src) '.mat']);
        assert(isfile(f), 'idiff_pa_series:noPanel', ...
            ['%s not found. It carries the quarterly rate panel. Build it with ' ...
             'Data_Replication/build_all_vintages.m.'], f);
        R = load(f, 'i_all');
        assert(isfield(R,'i_all'), 'idiff_pa_series:noRatePanel', ...
            '%s carries no i_all (the quarterly rate panel). Rebuild it.', f);
        ia = R.i_all;
    end

    NAMES = {'Canada','France','Germany','Italy','Japan','UK'};   % LOAD_BONDS order
    have  = ia.Properties.VariableNames;
    assert(ismember('US', have), 'idiff_pa_series:noUS', ...
        'the rate panel has no US column -- it has %s.', strjoin(have, ', '));
    t  = (datetime(1976,1,1) : calquarters(1) : ia.Time(end))';
    [tf, loc] = ismember([year(t) quarter(t)], ...
                         [year(ia.Time) quarter(ia.Time)], 'rows');
    lus = NaN(numel(t),1);  lus(tf) = log(ia.US(loc(tf)));
    idiff_ec_pa = NaN(numel(t), 7);
    for k = 1:6
        assert(ismember(NAMES{k}, have), 'idiff_pa_series:noColumn', ...
            '"%s" is not a column of the rate panel -- it has %s.', ...
            NAMES{k}, strjoin(have, ', '));
        v = NaN(numel(t),1);  v(tf) = log(ia.(NAMES{k})(loc(tf)));
        idiff_ec_pa(:,k) = lus - v;
    end
    % Column 7: trade weights in this column order; a plain sum, not renormalized.
    idiff_ec_pa(:,7) = idiff_ec_pa(:,1:6) * [0.0984 0.1599 0.2945 0.1230 0.1843 0.1399]';
end
