function [idiff_ec_pa, t] = idiff_pa_series(ia)
%IDIFF_PA_SERIES  Period-average short-rate differentials from the rate panel.
%
%   [idiff_ec_pa, t] = IDIFF_PA_SERIES(i_all)
%
%   i_all        the build's quarterly rate timetable, one column per country
%   idiff_ec_pa  T x 7 quarterly log short-rate differentials, US minus foreign,
%                from 1976Q1 to the end of the panel. Columns 1:6 are CA FR GE IT
%                JP UK, the order LOAD_BONDS uses. Column 7 is the trade-weighted
%                G6, a plain weighted sum that is NaN when any country is missing.
%   t            matching quarter-start datetimes
%
%   See also LOAD_BONDS, ASSET_PRICE_DATA, DATA_IMPORT_AND_TRANSFORM.

    NAMES = {'Canada','France','Germany','Italy','Japan','UK'};   % LOAD_BONDS order
    have  = ia.Properties.VariableNames;
    assert(ismember('US', have), 'idiff_pa_series:noUS', ...
        'the rate panel has no US column -- it has %s.', strjoin(have, ', '));
    t  = (datetime(1976,1,1) : calquarters(1) : ia.Time(end))';
    [tf, loc] = ismember([year(t) quarter(t)], ...
                         [year(ia.Time) quarter(ia.Time)], 'rows');
    lus = NaN(numel(t),1);  lus(tf) = log(ia.US(loc(tf)));
    idiff_ec_pa = NaN(numel(t), 7);
    for k = 1:6
        assert(ismember(NAMES{k}, have), 'idiff_pa_series:noColumn', ...
            '"%s" is not a column of the rate panel -- it has %s.', ...
            NAMES{k}, strjoin(have, ', '));
        v = NaN(numel(t),1);  v(tf) = log(ia.(NAMES{k})(loc(tf)));
        idiff_ec_pa(:,k) = lus - v;
    end
    % Column 7: trade weights in this column order; a plain sum, not renormalized.
    idiff_ec_pa(:,7) = idiff_ec_pa(:,1:6) * [0.0984 0.1599 0.2945 0.1230 0.1843 0.1399]';
end
