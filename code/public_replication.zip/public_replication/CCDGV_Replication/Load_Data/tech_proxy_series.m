function [V, t, names] = tech_proxy_series()
%TECH_PROXY_SERIES  The four technology-proxy series of Figure C.15, with dates.
%
%   [V, t, names] = TECH_PROXY_SERIES()
%
%   V      T x 4  [rd, tech_std, patent_app, patent_val], manifest order
%   t      T x 1  quarter dates, from column 1 of the sheet
%   names  the sheet headers of the four columns
%
%   Reads Raw_Data/CCDGV/USDATA.xlsx. Columns are selected by position, and their
%   headers are asserted. Coverage differs by series; quarters outside a series'
%   span are NaN:
%       rd           1976Q1-2018Q4
%       tech_std     1976Q1-2014Q4
%       patent_app   1981Q1-2014Q4
%       patent_val   1976Q1-2010Q4
%
%   See also CCDGV_MANIFEST, CCDGV_PROJECT.

    % Keep the sheet's own headers, so the assert below checks them as written.
    Tb = readtable(raw_path('CCDGV','USDATA.xlsx'), 'VariableNamingRule', 'preserve');
    t  = Tb{:,1};
    assert(isdatetime(t), 'tech_proxy:noDates', ...
           'USDATA.xlsx column 1 is %s, expected dates', class(t));

    X = table2array(Tb(:,2:end));          % data columns; column 1 is the date
    hdr = Tb.Properties.VariableNames(2:end);

    % Column index in X, expected header, transform. The loader multiplies every
    % column by 100, so log(x) arrives as 100*log(x) and x/100 arrives as x
    % (Patent_Value/GDP is already a ratio to GDP).
    LOG = @(x) reallog_nan(x);
    RAW = @(x) x/100;
    want = { 13, 'Real_RD',             LOG
             16, 'Tech_Standards',      LOG
             14, 'Patent_Applications', LOG
             15, 'Patent_Value/GDP',    RAW };

    V = nan(height(Tb), size(want,1));
    names = cell(1, size(want,1));
    for k = 1:size(want,1)
        c = want{k,1};
        assert(c <= numel(hdr) && strcmp(hdr{c}, want{k,2}), ...
            'tech_proxy:layout', ...
            ['USDATA.xlsx column %d is "%s", expected "%s". The sheet has been ' ...
             're-cut; these series are selected positionally, so fix the indices ' ...
             'here before any figure is trusted.'], ...
            c+1, hdr{min(c,numel(hdr))}, want{k,2});
        V(:,k)   = want{k,3}(X(:,c));
        names{k} = hdr{c};
    end
end

function y = reallog_nan(x)
%   log, with non-positive values set to NaN.
    y = nan(size(x));
    ok = x > 0;
    y(ok) = log(x(ok));
end
