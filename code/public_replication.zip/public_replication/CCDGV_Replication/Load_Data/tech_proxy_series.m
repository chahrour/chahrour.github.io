function [V, t, names] = tech_proxy_series()
%TECH_PROXY_SERIES  The four technology-proxy series of Figure B.10, with dates.
%
%   [V, t, names] = TECH_PROXY_SERIES()
%
%   V      172 x 4  [rd, tech_std, patent_app, patent_val], manifest order
%   t      172 x 1  quarter-start datetimes, read from the sheet's own column 1
%   names  the sheet headers actually taken, for the assert below
%
%   Read straight from Raw_Data/USDATA.xlsx. Both data cores call this, so the
%   columns are provably the same series in each -- the same arrangement as
%   G6_SOLOW_SERIES.
%
%   POSITIONAL BY DECISION, NOT BY OVERSIGHT. The original code selected these
%   with bare column numbers (var_ind = [10,13,16,14,15]) against a hand-kept
%   parallel label list, which is exactly the pattern the manifest exists to
%   remove -- and it has already caused a live bug here, where that var_ind
%   override left panel 1 labelled "U.S. Trade Balance" while carrying R&D, and
%   wrote a Patent Value figure out as TB_IRFs.eps. We keep the positions because
%   USDATA.xlsx is a frozen input that is not going to be re-cut, but we ASSERT
%   the headers we expect at those positions, so a re-cut sheet fails loudly here
%   instead of silently relabelling every downstream figure.
%
%   NOTE column 10 (NX_GDP_FRED) is deliberately NOT here: it is already the
%   manifest's nx_gdp, via US_data.m's us_nx_gdp_broad = us_data(:,10). The B.10
%   block plots it as a fifth panel under the label "U.S. Trade Balance", which
%   is a DIFFERENT series from the US_G6_TB that Figure B.1 plots under the same
%   label. Two figures, one caption, two series -- not reproduced here.
%
%   COVERAGE IS RAGGED, and shorter than the VAR sample. Quarters outside a
%   series' span come back NaN; ccdgv_project fits each row on whatever sample it
%   has, so a partial series costs coverage, not correctness:
%       rd           1976Q1-2018Q4   full
%       tech_std     1976Q1-2014Q4
%       patent_app   1981Q1-2014Q4   starts five years late
%       patent_val   1976Q1-2010Q4
%
%   See also CCDGV_MANIFEST, CCDGV_PROJECT.

    % Resolved through raw_path: the raw folder is no longer on the MATLAB path,
    % so a bare filename would not be found.
    % PRESERVE, so the header assert below checks the SPREADSHEET's names rather
    % than MATLAB's rewrite of them. Without it every run warned that headers had
    % been modified, and the expected names were the mangled forms -- which meant
    % the check could not notice a column actually being renamed to the mangled
    % spelling. Only one header is affected: Patent_Value/GDP, whose slash is what
    % triggered the rewrite.
    Tb = readtable(raw_path('CCDGV','USDATA.xlsx'), 'VariableNamingRule', 'preserve');
    t  = Tb{:,1};
    assert(isdatetime(t), 'tech_proxy:noDates', ...
           'USDATA.xlsx column 1 is %s, expected dates', class(t));

    X = table2array(Tb(:,2:end));          % the code's convention: drop col 1
    hdr = Tb.Properties.VariableNames(2:end);

    % X-index -> expected header -> transform. Indices AND transforms are
    % the original's, which is the only definition of what
    % these series mean in the paper's figure.
    %
    % UNITS. The loaders apply data = 100*data to EVERY column, so what we return
    % here is the PRE-scaled quantity:
    %   log(x)  -> 100*log(x) downstream, matching the original's 100*log
    %   x/100   -> x          downstream, i.e. untouched, which is what that
    %              script does to Patent_Value_GDP (already a ratio to GDP)
    % The /100 reads oddly on its own; it is there so this column arrives at the
    % figure in the draft's units instead of 100x them.
    LOG = @(x) reallog_nan(x);
    RAW = @(x) x/100;
    want = { 13, 'Real_RD',             LOG
             16, 'Tech_Standards',      LOG
             14, 'Patent_Applications', LOG
             15, 'Patent_Value/GDP',    RAW };

    V = nan(height(Tb), size(want,1));
    names = cell(1, size(want,1));
    for k = 1:size(want,1)
        c = want{k,1};
        assert(c <= numel(hdr) && strcmp(hdr{c}, want{k,2}), ...
            'tech_proxy:layout', ...
            ['USDATA.xlsx column %d is "%s", expected "%s". The sheet has been ' ...
             're-cut; these series are selected positionally, so fix the indices ' ...
             'here before any figure is trusted.'], ...
            c+1, hdr{min(c,numel(hdr))}, want{k,2});
        V(:,k)   = want{k,3}(X(:,c));
        names{k} = hdr{c};
    end
end

% -------------------------------------------------------------------------
function y = reallog_nan(x)
%   log, with non-positive values sent to NaN rather than -Inf or complex. A
%   zero or negative here means the sheet changed; NaN keeps it out of the
%   projection instead of poisoning the row.
    y = nan(size(x));
    ok = x > 0;
    y(ok) = log(x(ok));
end
