function B = load_bonds(idiff_ec_pa, opt)
%LOAD_BONDS  Quarterly G7 bond yields and excess bond return differentials.
%
%   B = LOAD_BONDS(idiff_ec_pa)
%   B = LOAD_BONDS(idiff_ec_pa, opt)
%
%   idiff_ec_pa  T x >=6 quarterly LOG short-rate differentials (US - foreign),
%                first row 1976Q1, country order CAN FRA GER ITA JPN UK.
%   opt          optional overrides of the defaults set below.
%
%   B  struct with fields
%       dates_q      T x 2   [year quarter]
%       yields       T x 7   quarterly log yields, opt.names order
%       yield_us     T x 1
%       yield_g6     T x 1   trade-weighted G6 aggregate, NaN-aware
%       rx_country   T x 6   per-country excess bond return differential
%       rx_g6        T x 1   G6 aggregate
%       wcov         T x 1   weight coverage of the G6 aggregate, per quarter
%       names        1 x 7   country labels
%       opt          the options actually used, including opt.source
%
%   Reads Raw_Data/gfd_monthly.csv. Home is the US, foreign is the weighted G6
%   aggregate; returns are foreign minus home. opt.screen reports months where
%   the accrued coupon implied by the total-return and price indices departs
%   from y/12 by more than opt.screen_tol. Construction choices are documented
%   in Load_Data/readme bond data.txt.
%
%   See also ASSET_PRICE_DATA.

    d.file     = 'gfd_monthly.csv';
    d.names    = {'CAN','FRA','GER','ITA','JPN','UK','USA'};
    d.tr       = {'TRCANGVM','TRFRAGVM','TRDEUGVM','TRITAGVM','TRJPNGVM','TRGBRGVM','TRUSG10M'};
    d.pr       = {'PRCANGVM','PRFRAGVM','PRDEUGVM','PRITAGVM','PRJPNGVM','PRGBRGVM','PRUSG10M'};
    d.ig       = {'IGCAN10D','IGFRA10D','IGDEU10D','IGITA10D','IGJPN10D','IGGBR10D','IGUSA10D'};
    d.weights  = [0.0984 0.1599 0.2945 0.1230 0.1843 0.1399];   % G6, sums to 1
    d.q_start  = [1976 1];
    d.q_end    = [];            % [] = to the end of the available data
    d.sampling = 'average';     % 'average' = 3-month mean | 'eoq' = last month
    d.strict_q = true;          % NaN a quarter if any of its 3 months is missing
    d.pad_to   = [2018 4];      % [] = stop where the data stop
    d.screen   = 'warn';        % 'off' | 'warn' | 'nan'
    d.screen_tol  = 0.5;        % pp, on |(TR ret - PR ret) - y/12|
    d.screen_skip = {'UK'};     % coupons posted, not accrued

    if nargin < 2 || isempty(opt); opt = struct(); end
    if isfield(opt,'ger_bond')
        warning('load_bonds:gerBond', ...
            'opt.ger_bond has no meaning: the GFD file has one German series.');
        opt = rmfield(opt,'ger_bond');
    end
    for f = fieldnames(d)'
        if ~isfield(opt, f{1}); opt.(f{1}) = d.(f{1}); end
    end
    opt.source = 'gfd2026';

    assert(abs(sum(opt.weights) - 1) < 1e-12, 'load_bonds:weights', ...
        'G6 weights must sum to one.');
    nC = numel(opt.names);
    assert(numel(opt.tr)==nC && numel(opt.pr)==nC && numel(opt.ig)==nC, ...
        'load_bonds:tickerCount', ...
        'names/tr/pr/ig must all have %d entries.', nC);

    assert(nargin >= 1 && ~isempty(idiff_ec_pa), 'load_bonds:noIdiff', ...
        'load_bonds needs idiff_ec_pa -- run IDIFF_data first.');
    assert(size(idiff_ec_pa,2) >= nC-1, 'load_bonds:idiffCols', ...
        'idiff_ec_pa has %d columns; need at least %d.', size(idiff_ec_pa,2), nC-1);

%% =============================== READ CSV ===============================
    % Resolved explicitly, not by `which`: the raw folder is no longer added to
    % the MATLAB path, because a data directory on the path lets a file shadow a
    % function of the same name.
    fn = opt.file;
    if exist(fn,'file') ~= 2; fn = raw_path('CCDGV', opt.file); end
    assert(exist(fn,'file') == 2, 'load_bonds:noFile', ...
        '%s not found; it should be at %s.', opt.file, raw_path('CCDGV', opt.file));

    io   = detectImportOptions(fn);
    mcol = io.VariableNames{1};   % the month stamp is column 1 by construction.
    io   = setvartype(io, mcol, 'char');
    T    = readtable(fn, io);

    ym = parse_months(T.(mcol), opt.file);
    assert(all(diff(ym(:,1)*12 + ym(:,2)) == 1), 'load_bonds:gap', ...
        '%s is not a contiguous monthly calendar.', opt.file);

    TRm = grab(T, opt.tr, opt.file);
    PRm = grab(T, opt.pr, opt.file);
    IGm = grab(T, opt.ig, opt.file);

%% ============================ SPLICE SCREEN =============================
    if ~strcmpi(opt.screen,'off')
        carry = [nan(1,nC); diff(log(TRm)) - diff(log(PRm))] * 100;
        expc  = [nan(1,nC); IGm(1:end-1,:) / 12];
        resid = carry - expc;
        for j = 1:nC
            if any(strcmpi(opt.names{j}, opt.screen_skip)); continue; end
            hit = find(abs(resid(:,j)) > opt.screen_tol);
            for h = hit'
                fprintf(['  [load_bonds] SPLICE %s %d-%02d: coupon ' ...
                         'accrual off by %+.1fpp%s\n'], opt.names{j}, ...
                        ym(h,1), ym(h,2), resid(h,j), ...
                        tern(strcmpi(opt.screen,'nan'), ' -- NaNed', ''));
                if strcmpi(opt.screen,'nan')
                    TRm(h,j) = NaN;  PRm(h,j) = NaN;
                end
            end
        end
    end

%% ======================= BOND PRICES (TOTAL RETURN) ======================
    [dq_p, P_q] = month2quarterly(ym, TRm, opt);

%% ==================== MASTER GRID: prices INTERSECT rates ================
    dq_i = qgrid(1976, 1, size(idiff_ec_pa,1));

    q0 = opt.q_start;
    q1 = opt.q_end;  if isempty(q1); q1 = [9999 4]; end
    [dq, ip, ii] = qintersect2(dq_p, dq_i, q0, q1);
    T_ = size(dq,1);

    P_q = P_q(ip,:);
    ID  = idiff_ec_pa(ii, 1:nC-1);          % columns 1:6 are the country diffs.

    fprintf(['  [load_bonds] source %s (%s); sample %dQ%d-%dQ%d ' ...
             '(T = %d); prices end %dQ%d, rates end %dQ%d\n'], ...
            opt.source, opt.file, dq(1,1),dq(1,2), dq(end,1),dq(end,2), T_, ...
            dq_p(end,1),dq_p(end,2), dq_i(end,1),dq_i(end,2));

%% ============================ YIELD SERIES ==============================
    Y_q = nan(T_, nC);
    [dq_y, Yraw] = month2quarterly(ym, IGm, opt);
    [tf, loc] = ismember(qkey(dq), qkey(dq_y));
    Y_q(tf,:) = Yraw(loc(tf),:);
    if ~all(tf)
        fprintf(['  [load_bonds] yields cover %d of %d quarters; the ' ...
                 'rest are NaN.\n'], sum(tf), T_);
    end
    bond_yields = log((1 + Y_q./100).^(1/4));            % annual -> quarterly log
    yield_us    = bond_yields(:,nC);
    yield_g6    = wagg(bond_yields(:,1:nC-1), opt.weights);

%% ====================== EXCESS RETURN DIFFERENTIAL ======================
    logR = nan(T_, nC);
    logR(2:end,:) = log(P_q(2:end,:) ./ P_q(1:end-1,:));

    rx_country = nan(T_, nC-1);
    rx_country(2:end,:) = (logR(2:end,1:nC-1) - logR(2:end,nC)) + ID(1:end-1,:);

    [rx_g6, wcov] = wagg(rx_country, opt.weights);

%% ========================= PAD WITH NaN (optional) =======================
    if ~isempty(opt.pad_to)
        nPad = (opt.pad_to(1)*4 + opt.pad_to(2)) - (dq(end,1)*4 + dq(end,2));
        if nPad > 0
            kNew        = ((dq(end,1)*4 + dq(end,2)) + 1 : (opt.pad_to(1)*4 + opt.pad_to(2)))';
            dq          = [dq; [floor((kNew-1)/4), mod(kNew-1,4)+1]];
            bond_yields = [bond_yields; nan(nPad, nC)  ];
            yield_us    = [yield_us;    nan(nPad, 1)   ];
            yield_g6    = [yield_g6;    nan(nPad, 1)   ];
            rx_country  = [rx_country;  nan(nPad, nC-1)];
            rx_g6       = [rx_g6;       nan(nPad, 1)   ];
            wcov        = [wcov;        nan(nPad, 1)   ];
            fprintf(['  [load_bonds] padded %d quarter(s) with NaN to ' ...
                     '%dQ%d; they carry no data.\n'], nPad, opt.pad_to(1), opt.pad_to(2));
        elseif nPad < 0
            fprintf(['  [load_bonds] data reach %dQ%d, %d quarter(s) ' ...
                     'past opt.pad_to (%dQ%d); not truncated.\n'], ...
                    dq(end,1), dq(end,2), -nPad, ...
                    opt.pad_to(1), opt.pad_to(2));
        end
    end

%% ================================ OUTPUT ================================
    B = struct('dates_q', dq, 'yields', bond_yields, 'yield_us', yield_us, ...
               'yield_g6', yield_g6, 'rx_country', rx_country, 'rx_g6', rx_g6, ...
               'wcov', wcov, 'names', {opt.names}, 'opt', opt);
end

%==========================================================================
%                            local functions
%==========================================================================
function ym = parse_months(col, fname)
    if ~iscell(col); col = cellstr(col); end
    ym = zeros(numel(col), 2);
    for i = 1:numel(col)
        v = sscanf(strtrim(col{i}), '%d-%d');
        assert(numel(v) == 2 && v(2) >= 1 && v(2) <= 12, ...
            'load_bonds:badMonth', ...
            'Row %d of %s has month stamp ''%s''; expected YYYY-MM.', ...
            i, fname, col{i});
        ym(i,:) = v(:)';
    end
end

function X = grab(T, tickers, fname)
    have = T.Properties.VariableNames;
    X = nan(height(T), numel(tickers));
    for j = 1:numel(tickers)
        k = find(strcmp(tickers{j}, have));
        assert(numel(k) == 1, 'load_bonds:noTicker', ...
            'Ticker %s matched %d columns in %s.', tickers{j}, numel(k), fname);
        v = T.(have{k});
        assert(isnumeric(v), 'load_bonds:nonNumeric', ...
            'Column %s of %s did not read as numeric.', tickers{j}, fname);
        X(:,j) = v;
    end
end

function [dq, Xq] = month2quarterly(ym, X, opt)
    key = ym(:,1)*4 + floor((ym(:,2)-1)/3) + 1;
    [uk, ~, g] = unique(key, 'stable');
    n = accumarray(g, 1);
    keep = find(n == 3);                       % drop partial quarters
    dq = zeros(numel(keep), 2);
    Xq = nan(numel(keep), size(X,2));
    for k = 1:numel(keep)
        blk = X(g == keep(k), :);
        if strcmp(opt.sampling,'eoq')
            Xq(k,:) = blk(end,:);
        elseif opt.strict_q
            Xq(k,:) = mean(blk, 1);                    % NaN if any month missing
        else
            Xq(k,:) = mean(blk, 1, 'omitnan');
        end
        dq(k,1) = floor(uk(keep(k))/4);
        dq(k,2) = uk(keep(k)) - dq(k,1)*4;
        if dq(k,2) == 0; dq(k,1) = dq(k,1)-1; dq(k,2) = 4; end
    end
end

function dq = qgrid(y0, q0, n)
    k = (y0*4 + q0 - 1) + (0:n-1)';
    dq = [floor(k/4), mod(k,4) + 1];
end

function k = qkey(dq)
    k = dq(:,1)*4 + dq(:,2);
end

function [dq, ia, ib] = qintersect2(da, db, q0, q1)
    ka = qkey(da);  kb = qkey(db);
    lo = q0(1)*4 + q0(2);  hi = q1(1)*4 + q1(2);
    k  = intersect(ka, kb);
    k  = k(k >= lo & k <= hi);
    assert(~isempty(k), 'load_bonds:noOverlap', ...
        'Requested sample is empty: prices and short rates do not overlap.');
    assert(all(diff(k) == 1), 'load_bonds:hole', ...
        'The overlapping sample has a hole in it.');
    [~, ia] = ismember(k, ka);  [~, ib] = ismember(k, kb);
    dq = [floor((k-1)/4), mod(k-1,4) + 1];
end

function [a, cov] = wagg(X, w)
    ok  = ~isnan(X);
    Wm  = bsxfun(@times, double(ok), w);
    cov = sum(Wm, 2);
    Xz  = X;  Xz(~ok) = 0;
    a   = sum(Xz .* Wm, 2) ./ cov;
    a(cov <= 0)   = NaN;
    cov(cov <= 0) = NaN;
end

function s = tern(c, a, b)
    if c; s = a; else; s = b; end
end
