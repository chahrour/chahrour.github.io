function T = newcore_country_series(R, country)
%NEWCORE_COUNTRY_SERIES  The five country-varying VAR series, for ONE country.
%
%   T = NEWCORE_COUNTRY_SERIES(R, country)
%
%   R        the loaded Y_benchmark<suffix>.mat struct (needs the per-country
%            panels S_fx, P_all, C_all, I_all, i_all)
%   country  a name from ccdgv_countries, not 'G6'
%   T        timetable with NER, IDIFF, Cstar, CPIDIFF, Istar, q_real
%
%   WHY THIS EXISTS. Five of the eight VAR series vary by country. Y carries only
%   the G6 aggregate of each, so ryan_data had no per-country path and every
%   by-country run would silently re-estimate G6 -- caught 2026-08-07 when
%   Japan's run came back identical to the baseline. The orig loader gets these
%   from fx_ln(:,cc), idiff_ec(:,cc), cons_ln(:,cc), cpi(:,cc), inv_ln(:,cc).
%
%   SAME AGGREGATOR, ONE COLUMN. Each series is rebuilt with the function the G6
%   path uses (data_import_and_transform §3), applied to a single column with
%   weight 1 -- geo_aggregate for FX/CPI/interest, geo_aggregate_growth for
%   consumption/investment. Reproducing the transforms by hand here would be a
%   second implementation free to drift from the first.
%
%   A SINGLE COLUMN, NOT A ONE-HOT WEIGHT over all six. geo_aggregate_growth
%   anchors at the first quarter ANY country is present and weights that row by
%   the available countries; a one-hot vector for a country missing in that row
%   divides by zero and returns an all-NaN series.
%
%   BY NAME, NEVER BY INDEX. cfg.countries is {Germany, Japan, France, UK, Italy,
%   Canada}; ccdgv_countries is {Canada, France, Germany, Italy, Japan, UK, G6}.
%   The two orders share no position but the middle, so a positional map returns
%   the wrong country's data for five of six and still produces a plausible run.
%
%   See also RYAN_DATA, CCDGV_COUNTRIES, GEO_AGGREGATE, GEO_AGGREGATE_GROWTH.

    assert(~strcmp(country,'G6'), 'newcore_country_series:isG6', ...
        'G6 is the aggregate Y already carries -- this is for the six countries.');

    need = {'S_fx','P_all','C_all','I_all','i_all'};
    miss = need(~isfield(R, need));
    assert(isempty(miss), 'newcore_country_series:noPanels', ...
        ['Y_benchmark lacks %s -- it predates the per-country panels. Rebuild ' ...
         'with Data_Replication/build_all_vintages.m.'], strjoin(miss, ', '));

    local_addpath();

    % Levels -> logs, one column each, by name.
    lnS   = geo_aggregate(local_pick(R.S_fx,  country), 1);   % ln S_c
    lnPc  = geo_aggregate(local_pick(R.P_all, country), 1);   % ln P_c
    lnPus = geo_aggregate(local_pick(R.P_all, 'US'   ), 1);   % ln P_US
    lnic  = geo_aggregate(local_pick(R.i_all, country), 1);   % ln(1+i_c)^(1/4)
    lnius = geo_aggregate(local_pick(R.i_all, 'US'   ), 1);   % ln(1+i_US)^(1/4)
    lnCc  = geo_aggregate_growth(local_pick(R.C_all, country), 1);
    lnIc  = geo_aggregate_growth(local_pick(R.I_all, country), 1);

    % The differentials, home minus foreign, exactly as §3c/§3d form them.
    IDIFF   = local_diff(lnius, lnic,  'IDIFF');
    CPIDIFF = local_diff(lnPus, lnPc,  'CPIDIFF');
    q_real  = local_q(lnS, lnPc, lnPus);                      % ln S + ln P* - ln P

    NER   = local_rename(lnS,  'NER');
    Cstar = local_rename(lnCc, 'Cstar');
    Istar = local_rename(lnIc, 'Istar');

    % UNION, not intersection: ryan_data aligns by date and pads NaN, and
    % run_main's NaN drop is taken over the VAR columns only. An intersection
    % here would let the shortest of the six silently set the sample.
    T = synchronize(NER, IDIFF, Cstar, CPIDIFF, Istar, q_real, 'union');
end

% -------------------------------------------------------------------------
function local_addpath()
%   geo_aggregate* live in Data_Replication, which run_pathsetup does not add
%   (it is the data build, not the estimation code). Added here rather than
%   there so the dependency is visible at its one point of use.
    d = fullfile(fileparts(fileparts(fileparts(mfilename('fullpath')))), ...
                 'Data_Replication');
    if isempty(which('geo_aggregate'))
        assert(isfolder(d), 'newcore_country_series:noDataRepl', ...
               '%s not found -- geo_aggregate is unavailable.', d);
        addpath(d);
    end
end

function tt = local_pick(panel, name)
%   One column, BY NAME, with the available names reported on a miss.
    j = find(strcmp(panel.Properties.VariableNames, name));
    assert(isscalar(j), 'newcore_country_series:noColumn', ...
        '"%s" is not a column of this panel -- it has %s.', ...
        name, strjoin(panel.Properties.VariableNames, ', '));
    tt = panel(:, j);

    % geo_aggregate_growth carries the level across an interior gap (right for a
    % renormalized G6, wrong for one country -- it would invent observations).
    % Refuse rather than fabricate; leading and trailing NaN are fine.
    v = tt{:,1};  k = find(~isnan(v));
    assert(~isempty(k), 'newcore_country_series:allNaN', ...
           '%s is entirely missing from this panel.', name);
    assert(~any(isnan(v(k(1):k(end)))), 'newcore_country_series:interiorGap', ...
        ['%s has an interior gap (%d missing quarters inside %s..%s). The ' ...
         'aggregators would carry the level across it and fabricate data.'], ...
        name, sum(isnan(v(k(1):k(end)))), ...
        datestr(tt.Time(k(1)),'yyyyQQ'), datestr(tt.Time(k(end)),'yyyyQQ'));
end

function tt = local_rename(tt, name)
    tt.Properties.VariableNames = {name};
end

function tt = local_diff(homelog, starlog, name)
%   Mirrors data_import_and_transform's build_diff.
    h = local_rename(homelog, 'h');
    s = local_rename(starlog, 's');
    m = synchronize(h, s, 'intersection');
    tt = array2timetable(m.h - m.s, 'RowTimes', m.Time, 'VariableNames', {name});
end

function tt = local_q(Slog, Pstarlog, Phomelog)
%   Mirrors data_import_and_transform's build_q.
    a = local_rename(Slog,     's');
    b = local_rename(Pstarlog, 'pstar');
    c = local_rename(Phomelog, 'phome');
    m = synchronize(synchronize(a, b, 'intersection'), c, 'intersection');
    tt = array2timetable(m.s + m.pstar - m.phome, 'RowTimes', m.Time, ...
                         'VariableNames', {'q_real'});
end
