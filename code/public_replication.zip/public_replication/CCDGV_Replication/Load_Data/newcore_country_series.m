function T = newcore_country_series(R, country)
%NEWCORE_COUNTRY_SERIES  The country-varying VAR series for one country.
%
%   T = NEWCORE_COUNTRY_SERIES(R, country)
%
%   R        the loaded Y_benchmark<suffix>.mat struct, with the per-country
%            panels S_fx, P_all, C_all, I_all, i_all
%   country  a name from ccdgv_countries other than 'G6'
%   T        timetable with NER, IDIFF, Cstar, CPIDIFF, Istar, q_real
%
%   Each series is built with the aggregator the G6 path uses in
%   data_import_and_transform, applied to the country's single column with
%   weight 1. Columns are picked by name, because cfg.countries and
%   ccdgv_countries order the countries differently.
%
%   See also RYAN_DATA, CCDGV_COUNTRIES, GEO_AGGREGATE, GEO_AGGREGATE_GROWTH.

    assert(~strcmp(country,'G6'), 'newcore_country_series:isG6', ...
        'G6 is the aggregate Y already carries -- this is for the six countries.');

    need = {'S_fx','P_all','C_all','I_all','i_all'};
    miss = need(~isfield(R, need));
    assert(isempty(miss), 'newcore_country_series:noPanels', ...
        ['Y_benchmark lacks %s -- it predates the per-country panels. Rebuild ' ...
         'with Data_Replication/build_all_vintages.m.'], strjoin(miss, ', '));

    local_addpath();

    % Log levels, one column each.
    lnS   = geo_aggregate(local_pick(R.S_fx,  country), 1);   % ln S_c
    lnPc  = geo_aggregate(local_pick(R.P_all, country), 1);   % ln P_c
    lnPus = geo_aggregate(local_pick(R.P_all, 'US'   ), 1);   % ln P_US
    lnic  = geo_aggregate(local_pick(R.i_all, country), 1);   % ln(1+i_c)^(1/4)
    lnius = geo_aggregate(local_pick(R.i_all, 'US'   ), 1);   % ln(1+i_US)^(1/4)
    lnCc  = geo_aggregate_growth(local_pick(R.C_all, country), 1);
    lnIc  = geo_aggregate_growth(local_pick(R.I_all, country), 1);

    % Differentials, home minus foreign, and the real exchange rate.
    IDIFF   = local_diff(lnius, lnic,  'IDIFF');
    CPIDIFF = local_diff(lnPus, lnPc,  'CPIDIFF');
    q_real  = local_q(lnS, lnPc, lnPus);                      % ln S + ln P* - ln P

    NER   = local_rename(lnS,  'NER');
    Cstar = local_rename(lnCc, 'Cstar');
    Istar = local_rename(lnIc, 'Istar');

    % Join on the union of dates; ryan_data aligns by date and pads with NaN.
    T = synchronize(NER, IDIFF, Cstar, CPIDIFF, Istar, q_real, 'union');
end

function local_addpath()
%   Add Data_Replication to the path if geo_aggregate is not already on it.
    d = fullfile(fileparts(fileparts(fileparts(mfilename('fullpath')))), ...
                 'Data_Replication');
    if isempty(which('geo_aggregate'))
        assert(isfolder(d), 'newcore_country_series:noDataRepl', ...
               '%s not found -- geo_aggregate is unavailable.', d);
        addpath(d);
    end
end

function tt = local_pick(panel, name)
%   One column of a panel, by name.
    j = find(strcmp(panel.Properties.VariableNames, name));
    assert(isscalar(j), 'newcore_country_series:noColumn', ...
        '"%s" is not a column of this panel -- it has %s.', ...
        name, strjoin(panel.Properties.VariableNames, ', '));
    tt = panel(:, j);

    % Stop on an interior gap: the aggregators would carry the level across it.
    % Leading and trailing NaN are allowed.
    v = tt{:,1};  k = find(~isnan(v));
    assert(~isempty(k), 'newcore_country_series:allNaN', ...
           '%s is entirely missing from this panel.', name);
    assert(~any(isnan(v(k(1):k(end)))), 'newcore_country_series:interiorGap', ...
        ['%s has an interior gap (%d missing quarters inside %s..%s). The ' ...
         'aggregators would carry the level across it and fabricate data.'], ...
        name, sum(isnan(v(k(1):k(end)))), ...
        datestr(tt.Time(k(1)),'yyyyQQ'), datestr(tt.Time(k(end)),'yyyyQQ'));
end

function tt = local_rename(tt, name)
    tt.Properties.VariableNames = {name};
end

function tt = local_diff(homelog, starlog, name)
%   homelog - starlog on the common dates.
    h = local_rename(homelog, 'h');
    s = local_rename(starlog, 's');
    m = synchronize(h, s, 'intersection');
    tt = array2timetable(m.h - m.s, 'RowTimes', m.Time, 'VariableNames', {name});
end

function tt = local_q(Slog, Pstarlog, Phomelog)
%   ln S + ln P* - ln P on the common dates.
    a = local_rename(Slog,     's');
    b = local_rename(Pstarlog, 'pstar');
    c = local_rename(Phomelog, 'phome');
    m = synchronize(synchronize(a, b, 'intersection'), c, 'intersection');
    tt = array2timetable(m.s + m.pstar - m.phome, 'RowTimes', m.Time, ...
                         'VariableNames', {'q_real'});
end
