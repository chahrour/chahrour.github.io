% ASSET_PRICE_data  Equity and bond series for the asset-return panel (script).
%
% Run by data_import_and_transform, which supplies in the workspace:
%   ap_raw    struct of raw inputs (cj_equity, date_d_ec, equity_price_daily,
%             equity_tri_daily); if absent, the files are read here
%   ap_rates  the quarterly rate panel i_all; if absent, it is read from the
%             built Y_benchmark file
% Leaves in the workspace, for the quarters idiff_t_pa (1976Q1-2018Q4):
%   equity_price_us, equity_price_g6      log MSCI price indices
%   excess_equity_return_differential     foreign minus home
%   excess_bond_return_differential       foreign minus home, G6
%   bond_yield_gfd_us, bond_yield_gfd_g6  quarterly log 10-year yields
if exist('ap_raw','var') && isstruct(ap_raw)
    cj_equity          = ap_raw.cj_equity;
    date_d_ec          = ap_raw.date_d_ec;
    equity_price_daily = ap_raw.equity_price_daily;
    equity_tri_daily   = ap_raw.equity_tri_daily;
else
    tmp = importdata(raw_path('CCDGV','nyse_real_lev'));
    cj_equity = tmp.data(:,2);
    equity_price_daily = readtable('DATASTREAM_MSCI_DAILY', 'Sheet', 'Price Indexes', 'VariableNamingRule', 'preserve');
    equity_tri_daily = readtable('DATASTREAM_MSCI_DAILY', 'Sheet', 'Total Return Indexes', 'VariableNamingRule', 'preserve');
    date_d_ec = table2array(equity_price_daily(1:end,1));
    equity_price_daily = table2array(equity_price_daily(1:end,2:end));
    equity_tri_daily = table2array(equity_tri_daily(1:end,2:end));
end

% Date vectors of the daily observations.
dates_d_ec = datevec(date_d_ec);

% For each year, mark the quarter-end business days and average each quarter.
yy_c = 0;
yy_q = 0;

% Clear the arrays grown in the loop.
clear tf_ec tq equity_price_pa equity_tri_pa data_ data_q

for yy = 1970:2023
    yy_c = yy_c + 1;
    yy_vec = datevec(lbusdate(yy, [3,6,9,12]));
   [tf_ec(:,yy_c), index_ec] = ismember(dates_d_ec,yy_vec,'rows');
   
   % Period average over the days of each quarter.
    for qq = 1:4
    quarters = [1:3; 4:6; 7:9; 10:12];
    yy_q = yy_q + 1;
    pa_vec = datevec(datetime(yy,quarters(qq,:),1));
    [tq(:,yy_q), index] = ismember(dates_d_ec(:,1:2),pa_vec(:,1:2),'rows');
    equity_price_pa(yy_q,:) = mean(equity_price_daily(tq(:,yy_q),:));
    equity_tri_pa(yy_q,:) = mean(equity_tri_daily(tq(:,yy_q),:));

    end
   
end 

tf_all_ec = sum(tf_ec,2);
tf_all_ec =logical(tf_all_ec);

equity_price_eop = equity_price_daily(tf_all_ec,:); 
equity_tri_eop = equity_tri_daily(tf_all_ec,:); 

% Quarters as fractional years: 1970 is 1970Q1, 2015+2/4 is 2015Q3.
dates_q_price = 1970:1/4:2023+3/4; 

% Column 8: the trade-weighted geometric G6 aggregate of columns 1-6.
equity_price_pa(:,8)=exp(log(equity_price_pa(:,1))*0.0984+log(equity_price_pa(:,2))*0.1599+log(equity_price_pa(:,3))*0.2945+log(equity_price_pa(:,4))*0.123+log(equity_price_pa(:,5))*0.1843+log(equity_price_pa(:,6))*0.1399);
equity_tri_pa(:,8)=exp(log(equity_tri_pa(:,1))*0.0984+log(equity_tri_pa(:,2))*0.1599+log(equity_tri_pa(:,3))*0.2945+log(equity_tri_pa(:,4))*0.123+log(equity_tri_pa(:,5))*0.1843+log(equity_tri_pa(:,6))*0.1399);

dates_q_return = [1970+1/4:1/4:2023+3/4]'; 

% Quarterly log returns of the period-average total-return index.
equity_tri_return_pa = diff(log(equity_tri_pa));

% Return differential, US minus G6, and the US and G6 price indices.
equity_return_differential = equity_tri_return_pa(:,7)-equity_tri_return_pa(:,8);
equity_price_us = equity_price_pa(:,7);
equity_price_g6 = equity_price_pa(:,8);

% Keep 1976Q1-2018Q4 and take logs.
equity_price_us = equity_price_us( find(dates_q_price== 1976):find(dates_q_price== 2018+3/4));
equity_price_g6 = equity_price_g6( find(dates_q_price== 1976):find(dates_q_price== 2018+3/4));

equity_price_us = log(equity_price_us); % log price index
equity_price_g6 = log(equity_price_g6); % log price index
cj_equity_price = log(cj_equity(find(dates_q_price== 1976):find(dates_q_price== 2018+3/4)));

%% Bonds

% Short-rate differentials (US minus foreign, period average): from ap_rates if
% supplied, otherwise from the built panel.
if exist('ap_rates','var') && istimetable(ap_rates)
    idiff_ec_pa = idiff_pa_series(ap_rates);
elseif exist('built_suffix','var')
    idiff_ec_pa = idiff_pa_series(built_suffix);
else
    idiff_ec_pa = idiff_pa_series();
end
idiff_t_pa = datetime(1976,1,1) + calquarters(0:size(idiff_ec_pa,1)-1)';

% Keep the window AP_START..AP_END. load_bonds takes its sample length from this
% array, so the window also sets the bond sample.
AP_START = [1976 1];
AP_END   = [2018 4];
ap_q    = year(idiff_t_pa) * 4 + quarter(idiff_t_pa);
ap_keep = ap_q >= (AP_START(1)*4 + AP_START(2)) & ap_q <= (AP_END(1)*4 + AP_END(2));
assert(any(ap_keep), 'ASSET_PRICE_data:emptyWindow', ...
    'window %dQ%d..%dQ%d selects nothing.', AP_START(1), AP_START(2), AP_END(1), AP_END(2));
idiff_ec_pa = idiff_ec_pa(ap_keep, :);
idiff_t_pa  = idiff_t_pa(ap_keep);
if size(idiff_ec_pa,1) ~= 172
    fprintf('  [ASSET_PRICE_data] window %dQ%d gives %d quarters (published runs use 172) -- row 19 and Figure C.6 will move.\n', ...
            AP_END(1), AP_END(2), size(idiff_ec_pa,1));
end

% Bond yields and excess returns. load_bonds uses columns 1:6 of idiff_ec_pa.
BOND = load_bonds(idiff_ec_pa);

excess_bond_return_differential = BOND.rx_g6;         % foreign minus home, G6
rx_bond_differential            = BOND.rx_country;    % per country

% GFD 10-year yields, quarterly log.
bond_yield_gfd_us = BOND.yield_us;
bond_yield_gfd_g6 = BOND.yield_g6;
bond_dates_q      = BOND.dates_q;

% Excess equity return differential on the same window.
ap_end_frac = AP_END(1) + (AP_END(2)-1)/4;
ap_start_frac = AP_START(1) + (AP_START(2)-1)/4;
ap_win = (dates_q_return >= ap_start_frac) & (dates_q_return <= ap_end_frac);
ap_sel = true(size(idiff_t_pa));   % idiff_ec_pa is already trimmed to the window
assert(sum(ap_win) == sum(ap_sel), 'ASSET_PRICE_data:windowMismatch', ...
    'equity window has %d quarters, rate window %d.', sum(ap_win), sum(ap_sel));
excess_equity_return_differential = equity_return_differential(ap_win) ...
                                  - idiff_ec_pa(ap_sel, end);
excess_equity_return_differential = - excess_equity_return_differential; % foreign minus home
