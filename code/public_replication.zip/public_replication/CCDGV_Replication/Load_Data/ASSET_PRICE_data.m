% RAW INPUTS COME FROM THE DATA LAYER WHEN THERE IS ONE. ap_raw, if present in the
% workspace, is a struct that Data_Replication's asset_price_series filled by
% calling its own loaders -- so during a build, no raw file is opened from this
% folder. The fallback reads below exist for the two standalone generators
% (gen_figure_assetpricev2, gen_corretfp_alt_news_measures), which run this
% script on its own with nothing to hand it.
%
% Three raw inputs, and that is the complete list for this file:
%   Raw_Data/nyse_real_lev        CJ's real NYSE level (added by RAC)
%   DATASTREAM_MSCI_DAILY.xlsx    sheets 'Price Indexes' and 'Total Return Indexes'
%   gfd_monthly.csv               read inside load_bonds, further down
if exist('ap_raw','var') && isstruct(ap_raw)
    cj_equity          = ap_raw.cj_equity;
    date_d_ec          = ap_raw.date_d_ec;
    equity_price_daily = ap_raw.equity_price_daily;
    equity_tri_daily   = ap_raw.equity_tri_daily;
else
    tmp = importdata(raw_path('CCDGV','nyse_real_lev'));
    cj_equity = tmp.data(:,2);
    equity_price_daily = readtable('DATASTREAM_MSCI_DAILY', 'Sheet', 'Price Indexes', 'VariableNamingRule', 'preserve');
    equity_tri_daily = readtable('DATASTREAM_MSCI_DAILY', 'Sheet', 'Total Return Indexes', 'VariableNamingRule', 'preserve');
    date_d_ec = table2array(equity_price_daily(1:end,1));
    equity_price_daily = table2array(equity_price_daily(1:end,2:end));
    equity_tri_daily = table2array(equity_tri_daily(1:end,2:end));
end

%-- Prepare the data
%date_diff = 693960;                                  % date number difference between Excel and MATLAB convention
dates_d_ec = datevec(date_d_ec);

% find end-of-quarter dates and positions
yy_c = 0;
yy_q = 0;

%initialize
clear tf_ec tq equity_price_pa equity_tri_pa data_ data_q

for yy = 1970:2023
    yy_c = yy_c + 1;
    yy_vec = datevec(lbusdate(yy, [3,6,9,12]));
   [tf_ec(:,yy_c), index_ec] = ismember(dates_d_ec,yy_vec,'rows');
   
   % period average
    for qq = 1:4
    quarters = [1:3; 4:6; 7:9; 10:12];
    yy_q = yy_q + 1;
    pa_vec = datevec(datetime(yy,quarters(qq,:),1));
    [tq(:,yy_q), index] = ismember(dates_d_ec(:,1:2),pa_vec(:,1:2),'rows');
    equity_price_pa(yy_q,:) = mean(equity_price_daily(tq(:,yy_q),:));
    equity_tri_pa(yy_q,:) = mean(equity_tri_daily(tq(:,yy_q),:));

    end
   
end 

tf_all_ec = sum(tf_ec,2);
tf_all_ec =logical(tf_all_ec);

equity_price_eop = equity_price_daily(tf_all_ec,:); 
equity_tri_eop = equity_tri_daily(tf_all_ec,:); 

%
dates_q_price = 1970:1/4:2023+3/4; 

% Notation:
%1970 = 1970Q1 
%2015 +2/4 = 2015Q3

% append G6 values
% equity_price_eop(:,8)=exp(log(equity_price_eop(:,1))*0.0984+log(equity_price_eop(:,2))*0.1599+log(equity_price_eop(:,3))*0.2945+log(equity_price_eop(:,4))*0.123+log(equity_price_eop(:,5))*0.1843+log(equity_price_eop(:,6))*0.1399);

equity_price_pa(:,8)=exp(log(equity_price_pa(:,1))*0.0984+log(equity_price_pa(:,2))*0.1599+log(equity_price_pa(:,3))*0.2945+log(equity_price_pa(:,4))*0.123+log(equity_price_pa(:,5))*0.1843+log(equity_price_pa(:,6))*0.1399);
% equity_tri_eop(:,8)=exp(log(equity_tri_eop(:,1))*0.0984+log(equity_tri_eop(:,2))*0.1599+log(equity_tri_eop(:,3))*0.2945+log(equity_tri_eop(:,4))*0.123+log(equity_tri_eop(:,5))*0.1843+log(equity_tri_eop(:,6))*0.1399);
equity_tri_pa(:,8)=exp(log(equity_tri_pa(:,1))*0.0984+log(equity_tri_pa(:,2))*0.1599+log(equity_tri_pa(:,3))*0.2945+log(equity_tri_pa(:,4))*0.123+log(equity_tri_pa(:,5))*0.1843+log(equity_tri_pa(:,6))*0.1399);


%
dates_q_return = [1970+1/4:1/4:2023+3/4]'; 

% Notation:
%1970 = 1970Q1
%1970 +1/4 = 1970Q2
%2015 +2/4 = 2015Q3


% quarterly returns (relative to previous quarter)
% equity_price_return_eop = diff(log(equity_price_eop));
%equity_price_return_pa = diff(log(equity_price_pa));
%equity_tri_return_eop = diff(log(equity_tri_eop));
equity_tri_return_pa = diff(log(equity_tri_pa));


equity_return_differential = equity_tri_return_pa(:,7)-equity_tri_return_pa(:,8);
equity_price_us = equity_price_pa(:,7);
equity_price_g6 = equity_price_pa(:,8);

%-- Keep only relevant sample
equity_price_us = equity_price_us( find(dates_q_price== 1976):find(dates_q_price== 2018+3/4));
equity_price_g6 = equity_price_g6( find(dates_q_price== 1976):find(dates_q_price== 2018+3/4));

equity_price_us = log(equity_price_us); % log of the price index / %use for alternative specification
equity_price_g6 = log(equity_price_g6); % log of the price index
% equity_price_differential = equity_price_us - equity_price_g6;
cj_equity_price = log(cj_equity(find(dates_q_price== 1976):find(dates_q_price== 2018+3/4)));
%% 

%% ============================== BONDS ===================================

%-- Nominal interest rate differential (end of period, using Euro$)
% The differentials
% come from the built rate panel via IDIFF_PA_SERIES. run_main sets built_suffix
% before calling this file, so the vintage follows the run.
% ap_rates, if present, is the rate timetable handed down by the build (which
% cannot have written the panel yet -- see IDIFF_PA_SERIES). Otherwise take the
% vintage from built_suffix, which run_main sets above this call.
if exist('ap_rates','var') && istimetable(ap_rates)
    idiff_ec_pa = idiff_pa_series(ap_rates);
elseif exist('built_suffix','var')
    idiff_ec_pa = idiff_pa_series(built_suffix);
else
    idiff_ec_pa = idiff_pa_series();
end
idiff_t_pa = datetime(1976,1,1) + calquarters(0:size(idiff_ec_pa,1)-1)';

% ---- THE WINDOW IS NOW DECLARED, NOT INHERITED ---------------------------------
% load_bonds:112 builds the differentials' date grid as
% qgrid(1976, 1, size(idiff_ec_pa,1)) -- it reads the START from a hardcoded
% 1976Q1 and the END from the ARRAY'S LENGTH. So however long this array is sets
% the bond sample, and through it excess_bond_return_differential, which becomes
% manifest row 19 (exret_bond_lead) in Figure B.6 and the section 4.2 numbers.
%
% The rate panel runs to the data's end (2026Q1), so an undeclared window would
% silently give a 202-quarter bond sample and move row 19.
%
% So the window is stated. Changing AP_END is a visible decision rather than a
% side effect of how long an input happens to be. Keeping it at 2018Q4
% reproduces every published number; extending it is a real option, and the
% assert below is what makes the consequence show up rather than pass silently.
AP_START = [1976 1];
AP_END   = [2018 4];
ap_q    = year(idiff_t_pa) * 4 + quarter(idiff_t_pa);
ap_keep = ap_q >= (AP_START(1)*4 + AP_START(2)) & ap_q <= (AP_END(1)*4 + AP_END(2));
assert(any(ap_keep), 'ASSET_PRICE_data:emptyWindow', ...
    'window %dQ%d..%dQ%d selects nothing.', AP_START(1), AP_START(2), AP_END(1), AP_END(2));
idiff_ec_pa = idiff_ec_pa(ap_keep, :);
idiff_t_pa  = idiff_t_pa(ap_keep);
if size(idiff_ec_pa,1) ~= 172
    fprintf('  [ASSET_PRICE_data] window %dQ%d gives %d quarters (published runs use 172) -- row 19 and Figure B.6 will move.\n', ...
            AP_END(1), AP_END(2), size(idiff_ec_pa,1));
end

% This used to claim idiff_ec_pa is passed in "so that the
% bond returns and the VAR's short rate are the same series". THEY ARE NOT. There
% are three constructions of the interest differential alive at once, all from the
% same Datastream rates:
%
%   Y.IDIFF                      the VAR's G6 differential, built by
%                                geo_aggregate_spliced -- renormalised over the
%                                countries present and BACKFILLED, so it has no
%                                pre-1978Q4 NaN
%   newcore_country_series.IDIFF per-country, lnius - lnic, for by-country runs
%   idiff_ec_pa (here)           per-country, plus a column 7 G6
%                                that is a PLAIN weighted sum and so NaN before
%                                1978Q3
%
% What is true is narrower: the bond returns and the VAR short rate come from the
% same SOURCE, not the same series. load_bonds uses columns 1:6 only (:120), so
% column 7 never reaches it.
%
% THE RATES COME FROM THE BUILT i_all PANEL, through IDIFF_PA_SERIES. It
% reproduces the retired script's columns 1:6 at max |diff| = 0.000e+00, with one
% difference: it GAINS two partial quarters the old construction made NaN --
% Italy 1978Q2 and Japan 1978Q3, whose Datastream feeds start mid-quarter
% (1978-06-09, 1978-08-01). The old code averaged over a fixed calendar-day grid,
% so a quarter missing any day was NaN; retime's 'mean' omits NaN and averages
% the rows present.
%
% THOSE TWO OBSERVATIONS ARE IN FORCE, and they are not free: they move rx_g6 by
% 4.4e-3 and wcov by 0.18, and rx_g6 feeds exret_bond_lead (manifest row 19),
% which reaches Figure B.6's expected-excess-return panel and the section 4.2
% bond-return numbers. Figure 5 is unaffected -- it uses the bond YIELDS, which
% are bit-identical across the two constructions. Both quarters fall before
% 1978Q4, where every G6 specification starts, so no estimation window contains
% them; they enter only through rx_g6's own history.
BOND = load_bonds(idiff_ec_pa);   % cols 1:6 only; col 7 is unused by it

excess_bond_return_differential = BOND.rx_g6;         % foreign - home, G6
rx_bond_differential            = BOND.rx_country;    % per-country

% GFD 10-year yields, quarterly log.
bond_yield_gfd_us = BOND.yield_us;
bond_yield_gfd_g6 = BOND.yield_g6;
bond_dates_q      = BOND.dates_q;

% ALIGNED ON DATES 2026-10-11. This line used to subtract idiff_ec_pa(:,end)
% WHOLE from a 1976Q1-2018Q4 slice of the equity returns, which worked only
% because its input happened to have exactly those 172 rows. The window is
% stated once and applied to both sides, so neither depends on an input's length.
ap_end_frac = AP_END(1) + (AP_END(2)-1)/4;
ap_start_frac = AP_START(1) + (AP_START(2)-1)/4;
ap_win = (dates_q_return >= ap_start_frac) & (dates_q_return <= ap_end_frac);
ap_sel = true(size(idiff_t_pa));   % already trimmed to the window above
assert(sum(ap_win) == sum(ap_sel), 'ASSET_PRICE_data:windowMismatch', ...
    'equity window has %d quarters, rate window %d.', sum(ap_win), sum(ap_sel));
excess_equity_return_differential = equity_return_differential(ap_win) ...
                                  - idiff_ec_pa(ap_sel, end);
excess_equity_return_differential = - excess_equity_return_differential; % foreign - home
