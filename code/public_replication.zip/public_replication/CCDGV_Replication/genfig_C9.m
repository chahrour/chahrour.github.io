function fout = genfig_C9(base_info, horizons, dest)
%GENFIG_C9  Figure C.9: responses to noise under other horizons of the
%           expected-TFP target.
%
%   fout = GENFIG_C9(base_info, horizons, dest)
%
%   base_info  descriptor of the baseline run, drawn solid with its 16-84 band
%   horizons   the other horizons h of E_t[TFP_{t+h}], one dashed line each;
%              the legend calls the horizon h, as the paper does
%   dest       output directory
%   fout       the figure
%
%   The horizon enters only the technology and noise decomposition, so that
%   step alone is rerun, once per horizon, on the baseline's stored VAR draws
%   and projections. Technology is identified from TFP alone and its responses
%   do not depend on the horizon, so only the noise responses are drawn.
%
%   The packed responses are cached beside the run as cjh_<run file> and reused
%   while the run file and the horizons are unchanged.
%
%   See also GENFIG_C7C8, CJ_DECOMPOSITION, CJ_BANDS.

    if ~isfolder(dest); mkdir(dest); end
    [nm, f] = data_name(base_info);
    [~, dn, vnames] = cj_bands(base_info);
    n = numel(horizons) + 1;
    N = NaN([size(dn), n]);
    N(:,:,:,n) = dn;                                  % solid line last

    % The other horizons, from the cache if it matches this run.
    d     = dir(f);
    key   = sprintf('%s|%.8f|%d|%s', nm, d.datenum, d.bytes, mat2str(horizons));
    cache = fullfile(fileparts(f), ['cjh_' nm]);
    if isfile(cache) && isequal(getfield(load(cache, 'key'), 'key'), key)
        L = load(cache, 'bands');
        N(:,:,:,1:n-1) = L.bands;
    else
        R = load(f, 'ARs','Sigs','Aproj_draw','keys','vnames','info', ...
                    'point_estimate','bound','bound2');
        S   = R.info.settings;
        hs  = min(S.smax, S.smax_store);
        w   = S.smax+1-hs : S.smax+1+hs;              % the window a run stores
        win = (-50:20) + hs + 1;                      % as cj_bands
        for k = 1:n-1
            [~, in] = cj_decomposition(R.ARs, R.Sigs, R.Aproj_draw, R.keys, R.vnames, ...
                                       S.smax, S.vd_fr, horizons(k));
            N(:,:,:,k) = pack_bands(cumsum(in(w,:,:)), win, 30, R);
            fprintf('  C.9: horizon %d done\n', horizons(k));
        end
        bands = N(:,:,:,1:n-1);
        save(cache, 'key', 'bands');
    end

    % TFP does not respond to noise by construction: set it to exactly zero.
    iT = var_order(vnames, 'Home TFP');
    N(:, [iT, numel(vnames)+iT], :, :) = 0;

    ROWS = {'Home TFP', 'Interest Rate Differential', 'Home Consumption', ...
            'Real Exchange Rate', 'Foreign Consumption', 'Expected Excess Returns'};
    ord  = var_order(vnames, ROWS{:});  ord = ord(:);
    labels = arrayfun(@(k) sprintf('$h = %d$', k), horizons, 'UniformOutput', false);
    COLS = [0.850 0.325 0.098     % orange
            0.929 0.694 0.125     % yellow
            0.494 0.184 0.556     % purple
            0.466 0.674 0.188     % green
            0.301 0.745 0.933     % cyan
            0.635 0.078 0.184];   % dark red
    COLS = COLS(1:numel(horizons),:);
    plotIRF_paper_individual(N, ord, vnames, 'FigureC9', 1:6, 1, 1, 0, 1, labels, 4, 1, COLS);
    fout = gcf;
    % Print the whole 425x400 canvas rather than cropping to content.
    set(fout, 'Color','w', 'InvertHardcopy','off', 'PaperUnits','points', ...
              'PaperPosition',[0 0 425 400], 'PaperSize',[425 400]);
    print(fout, fullfile(dest, 'FigureC9.pdf'), '-dpdf', '-r0');
    fprintf('  wrote FigureC9.pdf (baseline horizon %d; others %s)\n', ...
            base_info.settings.j_cj_horizon, mat2str(horizons));
end
