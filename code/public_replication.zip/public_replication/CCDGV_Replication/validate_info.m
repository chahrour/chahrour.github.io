function problems = validate_info(info)
%VALIDATE_INFO  Check an info struct for internal contradictions.
%
%   validate_info(info)             prints findings; ERRORS if any are hard
%   p = validate_info(info)         returns them instead, errors on nothing
%
%   p is a struct array with fields .level ('error'|'warn'), .what, .detail.
%
%   The point is redundancy: several fields restate the same fact, and nothing
%   forces them to agree. settings.nvars is set from numel(specs{inclvar}) at
%   one moment and read everywhere after; the Minnesota prior arrays are sized
%   from nvars/nlags/nconst; vecm.nlag is nlags-1. Any of those can drift if a
%   field is edited by hand or an old info is loaded against new code.
%
%   Checks are deliberately cheap and local -- nothing here loads data.
%
%   See also CCDGV_MANIFEST, DATA_NAME.

    problems = struct('level',{},'what',{},'detail',{});
    add = @(L,W,D) struct('level',L,'what',W,'detail',D);

    % ---- required structure -------------------------------------------
    % inclvarnms is NOT required: it is derived from inclvar by unpack_info and
    % is legitimately absent before the run reaches the boundary. inclvar is the
    % field that must be there.
    for f = {'country','datver','method','inclvar','ed','sd'}
        if ~isfield(info,f{1})
            problems(end+1) = add('error','missing field', f{1});
        end
    end
    if ~isfield(info,'settings')
        problems(end+1) = add('error','missing field','settings');
        problems = finish(problems, nargout); return
    end
    S = info.settings;

    % ---- inclvar indexes the manifest's spec list ----------------------
    % inclvarnms/nvars are DERIVED by unpack_info, so they can no longer
    % contradict inclvar within a run. What CAN go stale is a loaded info whose
    % recorded names no longer match a since-edited manifest -- that is what the
    % second check catches.
    try
        [~, ~, V] = ccdgv_manifest();
    catch
        V = {};
        problems(end+1) = add('warn','manifest unreadable','could not check inclvar');
    end
    if ~isempty(V) && isfield(info,'inclvar')
        if info.inclvar < 1 || info.inclvar > numel(V)
            problems(end+1) = add('error','inclvar out of range', sprintf( ...
                'inclvar = %d but the manifest declares %d specs', info.inclvar, numel(V)));
        elseif isfield(info,'inclvarnms')
            want = V{info.inclvar};
            if ~isequal(info.inclvarnms(:)', want(:)')
                problems(end+1) = add('error','recorded spec is stale', sprintf( ...
                    ['info records [%s] for inclvar=%d, but the manifest now says ' ...
                     '[%s]. This info predates a manifest edit.'], ...
                    strjoin(info.inclvarnms,' '), info.inclvar, strjoin(want,' ')));
            elseif isfield(S,'nvars') && S.nvars ~= numel(want)
                problems(end+1) = add('error','nvars vs spec', sprintf( ...
                    'settings.nvars = %d but spec %d has %d variables', ...
                    S.nvars, info.inclvar, numel(want)));
            end
        end
    end

    % ---- spec keys themselves -----------------------------------------
    if isfield(info,'inclvarnms')
        k = info.inclvarnms;
        if numel(unique(k)) ~= numel(k)
            d = k(cellfun(@(x) sum(strcmp(k,x))>1, k));
            problems(end+1) = add('error','duplicate spec keys', strjoin(unique(d), ', '));
        end
        try
            D = ccdgv_manifest();
            bad = setdiff(k, {D.key});
            if ~isempty(bad)
                problems(end+1) = add('error','spec key not in manifest', strjoin(bad, ', '));
            end
        catch
            problems(end+1) = add('warn','manifest unreadable','could not cross-check spec keys');
        end
    end

    % ---- prior arrays sized off nvars/nlags/nconst ---------------------
    if all(isfield(S,{'nvars','nlags','nconst','indiv_coeff_priorvar'}))
        want = (S.nlags*S.nvars + S.nconst) * S.nvars;
        got  = numel(S.indiv_coeff_priorvar);
        if got ~= want
            problems(end+1) = add('error','prior variance size', sprintf( ...
                'indiv_coeff_priorvar has %d elements, expected (nlags*nvars+nconst)*nvars = %d', got, want));
        end
    end
    if all(isfield(S,{'nvars','indiv_coeff_priormean'}))
        if numel(S.indiv_coeff_priormean) ~= S.nvars
            problems(end+1) = add('error','prior mean size', sprintf( ...
                'indiv_coeff_priormean has %d elements, expected nvars = %d', ...
                numel(S.indiv_coeff_priormean), S.nvars));
        end
    end

    % ---- fdvar indexes the VAR ----------------------------------------
    if isfield(info,'fdvar') && ~isempty(info.fdvar) && isfield(S,'nvars')
        bad = info.fdvar(info.fdvar < 1 | info.fdvar > S.nvars);
        if ~isempty(bad)
            problems(end+1) = add('error','fdvar out of range', sprintf( ...
                'fdvar has %s but nvars = %d', mat2str(bad), S.nvars));
        end
    end

    % ---- VECM lag restatement ------------------------------------------
    if isfield(S,'vecm') && isstruct(S.vecm) && isfield(S.vecm,'nlag') && isfield(S,'nlags')
        if S.vecm.nlag ~= S.nlags - 1
            lv = 'warn';
            if isfield(info,'method') && ismember(info.method,[3 4]); lv = 'error'; end
            problems(end+1) = add(lv,'vecm.nlag', sprintf( ...
                'vecm.nlag = %d but nlags-1 = %d', S.vecm.nlag, S.nlags-1));
        end
    end

    % ---- first-stage prior ----------------------------------------------
    % A malformed proj_prior would not fail until run_main is deep into the
    % projection loop, after the data stage has run.
    if isfield(S,'proj_prior') && ~isempty(S.proj_prior)
        PP = S.proj_prior;
        miss = setdiff({'draw','lambda','decay','free_block0','arlags'}, fieldnames(PP));
        % Only a DRAWING prior needs every field: struct('draw',false) is the
        % shape run_main itself builds when a run carries no prior at all.
        if PP.draw && ~isempty(miss)
            problems(end+1) = add('error','proj_prior', sprintf( ...
                'proj_prior is missing %s', strjoin(miss, ', ')));
        elseif PP.draw
            % lambda = 0 IS ALLOWED, and it is what this package uses. Zero
            % shrinkage makes the prior improper, but the posterior is proper
            % whenever the regression itself is identified, which the first-stage
            % projection is: ccdgv_project_draw adds no prior mass and draws from
            % the OLS posterior. Rejecting it here would reject every run.
            if ~(isscalar(PP.lambda) && PP.lambda >= 0)
                problems(end+1) = add('error','proj_prior', sprintf( ...
                    'proj_prior.lambda = %g; must be >= 0', PP.lambda));
            end
            if ~(isscalar(PP.arlags) && PP.arlags >= 0 && PP.arlags == fix(PP.arlags))
                problems(end+1) = add('error','proj_prior', ...
                    'proj_prior.arlags must be a non-negative integer');
            end
        end
    end

    % ---- enumerations ---------------------------------------------------
    problems = enum(problems, add, info, 'method',        [1:4 6], 'error');
    problems = enum(problems, add, S,    'shock_extract', 1:4,   'error');
    problems = enum(problems, add, S,    'point_estimate',0:1,   'error');
    % cc is no longer stored -- unpack_info derives it from country -- so the
    % check moves to the field that IS stored. A run whose country is not in the
    % list would otherwise fail deep inside the data loader on a bad column.
    if isfield(info,'country') && ~any(strcmp(info.country, ccdgv_countries()))
        problems(end+1) = add('error','country', sprintf('"%s" is not one of %s', ...
            char(string(info.country)), strjoin(ccdgv_countries(), ', ')));
    end
    % A loaded info from before the change can still carry a stale settings.cc.
    if isfield(S,'cc') && isfield(info,'country') && ...
       any(strcmp(info.country, ccdgv_countries())) && S.cc ~= ccdgv_countries(info.country)
        problems(end+1) = add('error','cc', sprintf( ...
            'recorded cc = %d but country %s is column %d -- a pre-derivation run', ...
            S.cc, info.country, ccdgv_countries(info.country)));
    end
    if isfield(info,'datver') && ~any(strcmp(info.datver, {'orig','new'}))
        problems(end+1) = add('warn','datver', sprintf('"%s" is not orig|new', char(info.datver)));
    end

    % ---- positive counts ------------------------------------------------
    for f = {'nvars','nlags','ndraws'}
        if isfield(S,f{1})
            v = S.(f{1});
            if ~isscalar(v) || v < 1 || v ~= fix(v)
                problems(end+1) = add('error','not a positive integer', ...
                    sprintf('settings.%s = %s', f{1}, mat2str(v)));
            end
        end
    end

    % ---- realised sample inside what was asked for ----------------------
    if all(isfield(info,{'ed','ed_realised'})) && info.ed_realised > info.ed + 1e-9
        problems(end+1) = add('error','sample overruns ed', sprintf( ...
            'ed_realised %.2f > ed %.2f', info.ed_realised, info.ed));
    end
    % Requested vs realised start. WARN on any material gap, in either
    % direction -- not just an early start. data_name uses the REQUESTED sd, so
    % two runs that ask for the same start but realise different samples share a
    % filename and the second overwrites the first. Tolerance is half a quarter,
    % so float noise cannot trigger it.
    if all(isfield(info,{'sd','sd_realised'})) && ~isempty(info.sd_realised)
        gap = info.sd_realised - info.sd;
        if abs(gap) > 0.13
            problems(end+1) = add('warn','start not honoured', sprintf( ...
                ['asked %.2f, realised %.2f (%+.0f quarters). The filename uses ' ...
                 'the REQUESTED start (sd%s), so another run with a different ' ...
                 'realised sample would overwrite this one.'], ...
                info.sd, info.sd_realised, round(gap*4), num2str(info.sd)));
        end
    end
    if all(isfield(info,{'ed','ed_realised'})) && ~isempty(info.ed_realised) && ...
            abs(info.ed_realised - info.ed) > 0.13
        problems(end+1) = add('warn','end not honoured', sprintf( ...
            'asked %.2f, realised %.2f (%+.0f quarters)', ...
            info.ed, info.ed_realised, round((info.ed_realised-info.ed)*4)));
    end

    % ---- progress: order and staleness ----------------------------------
    if isfield(info,'progress')
        ORDER = {'config','data','estimation','identification','moments','trading','complete'};
        % reshape to a ROW: intersect returns a column, and `for s = <column>`
        % iterates ONCE with s bound to the whole list.
        have  = reshape(intersect(ORDER, fieldnames(info.progress), 'stable'), 1, []);
        tprev = -inf; prev = '';
        for s = have
            e = info.progress.(s{1});
            if isfield(e,'done') && ~e.done
                problems(end+1) = add('warn','stage failed', ...
                    sprintf('%s: %s', s{1}, char(e.error)));
            end
            if isfield(e,'timestamp')
                t = datenum(e.timestamp,'yyyy-mm-dd HH:MM:SS');
                if t < tprev - 1e-9
                    problems(end+1) = add('error','stage out of order', sprintf( ...
                        '%s (%s) predates %s -- its inputs are stale', ...
                        s{1}, e.timestamp, prev));
                end
                tprev = t; prev = s{1};
            end
        end
        if isfield(info,'complete')
            fin = isfield(info.progress,'complete') && info.progress.complete.done;
            if logical(info.complete) ~= fin
                problems(end+1) = add('error','complete flag', ...
                    'info.complete disagrees with progress.complete');
            end
        end
    end

    % ---- identification passes ------------------------------------------
    if isfield(info,'ident')
        need = {'label','shock_extract','KLbar','KUbar','want_vardec_fd'};
        for k = 1:numel(info.ident)
            I = info.ident(k);
            miss = need(~isfield(I, need));
            if ~isempty(miss)
                problems(end+1) = add('error','ident missing fields', ...
                    sprintf('ident(%d): %s', k, strjoin(miss,', ')));
                continue
            end
            if ~ismember(I.shock_extract, 1:4)
                problems(end+1) = add('error','ident shock_extract', sprintf( ...
                    'ident(%d) "%s" has shock_extract = %s', k, I.label, ...
                    mat2str(I.shock_extract)));
            end
            if I.KLbar > I.KUbar
                problems(end+1) = add('error','ident band inverted', sprintf( ...
                    'ident(%d) "%s": KLbar %g > KUbar %g', k, I.label, ...
                    I.KLbar, I.KUbar));
            end
        end
        lab = {info.ident.label};
        if numel(unique(lab)) ~= numel(lab)
            problems(end+1) = add('error','duplicate ident labels', ...
                strjoin(unique(lab(cellfun(@(x) sum(strcmp(lab,x))>1, lab))), ', '));
        end
        if isfield(info,'idrun')
            bad = info.idrun(info.idrun < 1 | info.idrun > numel(info.ident));
            if ~isempty(bad)
                problems(end+1) = add('error','idrun out of range', sprintf( ...
                    'idrun has %s but ident has %d entries', mat2str(bad), numel(info.ident)));
            end
            if ~any(info.idrun == 1)
                problems(end+1) = add('warn','pass 1 not run', ...
                    'dataplots/vardec_fd come from pass 1; downstream code expects it');
            end
        end
    end

    % ---- the filename must be derivable ---------------------------------
    try
        data_name(info);
    catch ME
        problems(end+1) = add('error','data_name fails', ME.message);
    end

    problems = finish(problems, nargout);
end

% -------------------------------------------------------------------------
function p = enum(p, add, s, f, allowed, level)
    if isfield(s,f) && ~ismember(s.(f), allowed)
        p(end+1) = add(level, f, sprintf('%s = %s, expected one of %s', ...
                       f, mat2str(s.(f)), mat2str(allowed)));
    end
end

function p = finish(p, nout)
    if nout > 0; return; end          % caller wants the list, stay quiet
    nerr = sum(strcmp({p.level},'error'));
    if isempty(p)
        fprintf('  validate_info: no contradictions found.\n');
        return
    end
    fprintf('\n  validate_info: %d finding(s)\n', numel(p));
    for i = 1:numel(p)
        fprintf('    [%-5s] %-26s %s\n', p(i).level, p(i).what, p(i).detail);
    end
    fprintf('\n');
    if nerr > 0
        error('validate_info:contradiction', ...
              '%d contradiction(s) in info -- see the list above.', nerr);
    end
end
