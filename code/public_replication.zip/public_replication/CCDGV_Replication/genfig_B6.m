function fout = genfig_B6(base_info, dest, opt)
%GENFIG_B6  Figure B.6 -- technology, noise, and asset returns.
%
%   fout = GENFIG_B6(base_info)
%   fout = GENFIG_B6(base_info, dest)
%   fout = GENFIG_B6(base_info, dest, opt)
%   fout  [technology figure, noise figure]
%
%   Three panels, 1x3, matching the draft's returns_tech.eps / returns_noise.eps:
%       Expected Excess Equity Return Diff.     projected  (exret_eq_lead)
%       Expected Excess 10-Y Bond Return Diff.  projected  (exret_bond_lead)
%       Expected Excess Returns                 constructed (expexret)
%
%   WHY THIS REPLACES gen_figure_assetpricev2. That script mixed two families and
%   the figure did not say which was which: the first two panels came from a
%   first-stage OLS of external return data on the companion state, the third was
%   read out of the saved run at literal column 11. Both are rows of A here, so
%   the distinction lives in the manifest and r2 rather than in the plotting code.
%
%   It also could not run: it is pinned to `baseline_Avg_OCT2025`, which is not on
%   the path, and its literals 11/15 address the old 26-row layout -- under the
%   current manifest those are the trade balance and Tech Standards.
%
%   THE FIRST TWO PANELS ARE LEADS. exret_*_lead hold t+1 at row t, because the
%   figure is about EXPECTED returns. See ccdgv_manifest.
%
%   READ THE R2 WITH THIS ONE. Excess returns are close to unforecastable: the
%   projections come back around 0.44 (equity) and 0.33 (bond), against 0.98 for
%   the equity prices. So those two lines are the VAR's best linear predictor of
%   a series it largely does not span -- unlike the third panel, which is an exact
%   linear functional of the state.
%
%   PROJECTION BASIS: the full companion state, as every other manifest row. The
%   published figure used aux_lags = 0 (contemporaneous Y only). See
%   PROJECTION_BASIS.md -- this figure is the sharpest case of that divergence.
%
%   See also GENFIG_B14, CCDGV_MANIFEST, PLOTIRF.

    assert(nargin >= 2 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end

    [~, f] = data_name(base_info);
    assert(isfile(f), 'genfig_B6:noFile', '%s not found', f);
    D = load(f, 'irtfp','irnoise','vnames','point_estimate','bound','bound2','r2');
    % One projection stage, so the run file holds the only one there is.

    ROWS = {'Expected Excess Equity Return Diff.', ...
            'Expected Excess 10-Y Bond Return Diff.', ...
            'Expected Excess Returns'};
    ord = var_order(D.vnames, ROWS{:});  ord = ord(:);

    % Two-line titles, as the draft. The manifest names are correct but far too
    % long for a 1x3 strip -- they overlap. Only these three entries change;
    % numel(lab) still sets plotIRF's offset into DATA, so it must stay full length.
    lab = D.vnames;
    lab{ord(1)} = {'Expected Excess';'Equity Return Diff.'};
    lab{ord(2)} = {'Expected Excess';'10-Y Bond Return Diff.'};
    lab{ord(3)} = {'Expected Excess';'Currency Returns'};

    h = (size(D.irtfp,1)-1)/2;
    hgrid = -50:20;  discard = 30;
    dt = pack_bands(cumsum(D.irtfp),   hgrid+h+1, discard, D);
    dn = pack_bands(cumsum(D.irnoise), hgrid+h+1, discard, D);

    p = plotIRF;
    p.nrow = 1;  p.ncol = 3;
    % Taller than the old generator's [1 1 550 550/4.5] (= 550x122, aspect 4.5:1).
    % That canvas printed whole left wide margins and squat panels; the draft's
    % own content box is 452x118 with a 51pt gutter for the ylabel. Raising the
    % height gives the panels more room, and the export below crops to content
    % rather than printing the canvas, so the strip fills the width it is given.
    p.position = [1 1 680 170 ];

    p.NOISE = zeros(1,numel(ord));
    fout(1) = local_export(plotIRF(dt, ord, lab, 'returns_tech_new', 1:numel(ord), p), ...
                           fullfile(dest,'returns_tech_new.pdf'));
    p.NOISE = ones(1,numel(ord));
    fout(2) = local_export(plotIRF(dn, ord, lab, 'returns_noise_new', 1:numel(ord), p), ...
                           fullfile(dest,'returns_noise_new.pdf'));

    fprintf('  wrote returns_tech_new.pdf / returns_noise_new.pdf\n');
    fprintf('    %s\n', data_name(base_info));
    % r2 covers the DATA rows only -- a constructed row is an exact functional of
    % the state, so it has none. Panels 1-2 are projections and report it; panel 3
    % is constructed and does not.
    for k = 1:numel(ord)
        if isfield(D,'r2') && ord(k) <= numel(D.r2)
            fprintf('    r2 %.4f  %s\n', D.r2(ord(k)), D.vnames{ord(k)});
        else
            fprintf('    r2    --   %s (constructed, exact)\n', D.vnames{ord(k)});
        end
    end
end

% -------------------------------------------------------------------------
function f = local_export(f, target)
%   TIGHT CROP here, unlike genfig_B9B10/B7/B10 which print the whole canvas.
%   Those match a draft whose margins are part of the layout; this is a 1x3 strip
%   where the canvas is mostly whitespace, so cropping to content is what makes it
%   read at the size the draft does.
    f = f(1);
    set(f, 'Color','w', 'InvertHardcopy','off');
    exportgraphics(f, target, 'ContentType','vector', 'BackgroundColor','white');
end

