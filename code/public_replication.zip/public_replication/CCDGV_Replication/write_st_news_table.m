function out = write_st_news_table(info, opt)
%WRITE_ST_NEWS_TABLE  Technology/noise exchange rate changes vs the Stavrakeva-Tang news index.
%
%   out = WRITE_ST_NEWS_TABLE(info, OPT)
%
%   The correlation quoted in Section 4.5 ("approximately 40%"): the quarterly
%   change in the trade-weighted nominal exchange rate implied by the technology
%   and noise disturbances, against the "exchange rate news index" of
%   Stavrakeva and Tang (2020), which aggregates the exchange rate effects of
%   daily macro announcements to a quarterly frequency.
%
%   info   run descriptor. exhibits passes sweep_infos.extend: the run whose
%          sample reaches furthest into the index's coverage.
%   OPT    .outdir  REQUIRED: the directory holding Figures/ and Tables/
%          .echo    print the correlations (default true)
%
%   THE VAR-IMPLIED SERIES. infer_shocks recovers the two disturbances from TFP
%   and E_t TFP_{t+j} (point-estimate draw) and applies the NER row of their
%   two-sided MA to them (opt.cond). Its first difference is compared with the
%   index. NER here is the G6 trade-weighted, period-average rate (EOP = 0),
%   which is what the index is built to match.
%
%   THE INDEX: Raw_Data/StavrakevaTang_news_index_q.csv, 2002Q2-2020Q3, the
%   country-level quarterly series Stavrakeva and Tang provided (ER_data_q.xlsx,
%   quarterly-average columns of sheets ER_news_index_change_q and
%   ER_change_Dexch_q) for CAD, EUR, GBP and JPY:
%     index_<cur>  exchange rate news index
%     dner_<cur>   change in the log exchange rate, same convention
%   Aggregated here with the G6 trade weights the rest of the data build uses,
%   the euro taking Germany + France + Italy, and NEGATED: Stavrakeva and Tang
%   quote the opposite direction to NER here.
%
%   Dates follow this repository's convention: 2002.25 is the quarter from
%   3/31/2002 to 6/30/2002, which ER_data_q.xlsx labels 3/31/2002. The dner
%   series exist to CHECK that convention and the sign: aggregated, they should
%   correlate with this run's own change in NER at essentially 1, and fall to
%   about 0.4 when shifted by one quarter either way. The table reports it.
%
%   See also INFER_SHOCKS.

    if nargin < 2; opt = struct(); end
    if ~isfield(opt,'echo'); opt.echo = true; end
    % opt.outdir is the EXHIBIT ROOT; this function appends Tables/ itself, which
    % is the same convention every generator here uses.
    assert(isfield(opt,'outdir') && ~isempty(opt.outdir), 'write_st_news_table:noOutdir', ...
        'opt.outdir is required: the directory holding Figures/ and Tables/.');
    opt.outdir = fullfile(opt.outdir, 'Tables');
    if ~isfolder(opt.outdir); mkdir(opt.outdir); end

    % ---- the VAR side ----------------------------------------------------
    S  = infer_shocks(info, struct('cond', {{'NER'}}));
    D  = load(S.meta.file, 'data', 'dates', 'info');
    in = var_order(D.info.inclvarnms, 'ner');
    dv = D.dates(:);
    dner = diff(D.data(:,in));            dner_d = dv(2:end);
    cner = diff(S.cond(:,1));             cner_d = S.dates(2:end);

    % ---- the index -------------------------------------------------------
    f = raw_path('CCDGV', ...
                 'StavrakevaTang_news_index_q.csv');
    fid = fopen(f, 'r');
    assert(fid > 0, 'write_st_news_table:noData', '%s not found', f);
    C = textscan(fid, repmat('%f',1,9), 'Delimiter', ',', 'HeaderLines', 1);
    fclose(fid);
    % CAD, EUR (= DEU + FRA + ITA), GBP, JPY -- the G6 weights of
    % data_import_and_transform (cfg.weights), which sum to one.
    w = [0.0984; 0.2945 + 0.1599 + 0.1230; 0.1399; 0.1843];
    st_d     = C{1};
    st_index = -[C{2:5}] * w;
    st_dner  = -[C{6:9}] * w;

    % ---- the overlap, on quarter keys ------------------------------------
    q  = @(d) round(d(:)*4);
    kk = intersect(intersect(q(st_d), q(dner_d)), q(cner_d));
    assert(numel(kk) >= 8, 'write_st_news_table:overlap', ...
        'only %d quarters shared with the index (it covers %s-%s).', numel(kk), ...
        qlabel(st_d(1)), qlabel(st_d(end)));
    pick = @(d, x) x(ismember(q(d), kk));
    a = pick(st_d,  st_index);
    b = pick(cner_d, cner);
    c = pick(dner_d, dner);
    e = pick(st_d,  st_dner);

    r = @(x,y) local_corr(x,y);
    R = [r(a,b); r(a,c); r(b,c); r(c,e)];

    if R(4) < 0.95
        warning('write_st_news_table:alignment', ...
            ['NER here and Stavrakeva-Tang''s correlate at only %.3f. The two ' ...
             'should be the same series on the same dates; check the date ' ...
             'convention before reading the other rows.'], R(4));
    end

    % ---- write -----------------------------------------------------------
    span = sprintf('%s--%s', qlabel(kk(1)/4), qlabel(kk(end)/4));
    vspan = sprintf('%s--%s', qlabel(dv(1)), qlabel(dv(end)));
    lab = ccdgv_prov_label(struct('info', D.info));
    St = D.info.settings;
    prov = sprintf('%s, ndraws=%d, smax=%g, point-estimate draw, overlap %s (%d obs)', ...
                   lab, St.ndraws, St.smax, strrep(span,'--','-'), numel(kk));

    LBL = { ...
      'News index & $\Delta s_t$ due to technology and noise'
      'News index & $\Delta s_t$'
      '$\Delta s_t$ due to technology and noise & $\Delta s_t$'
      '$\Delta s_t$ & $\Delta s_t$, Stavrakeva--Tang' };

    fn  = fullfile(opt.outdir, 'tab_st_news.tex');
    fid = fopen(fn, 'w');  cl = onCleanup(@() fclose(fid));
    fprintf(fid,'%% Generated by write_st_news_table.m -- do not edit by hand.\n%% %s\n', prov);
    fprintf(fid,'\\begin{table}[htbp]\n\\centering\n');
    fprintf(fid,'\\caption{Technology and noise vs.\\ the exchange rate news index}\n');
    fprintf(fid,'\\label{tab:st_news}\n');
    fprintf(fid,'\\begin{tabular}{l l c}\n\\hline\n');
    fprintf(fid,'\\multicolumn{2}{c}{Correlation between} & \\\\ \\hline\n');
    for i = 1:numel(LBL)
        fprintf(fid,'%s & $%.2f$ \\\\\n', LBL{i}, R(i));
    end
    fprintf(fid,'\\hline\n\\end{tabular}\n');
    fprintf(fid,['\\caption*{\\footnotesize \\emph{Notes:} Quarterly changes in the ' ...
        'trade-weighted nominal exchange rate, $\\Delta s_t$, over %s (%d quarters). ' ...
        'News index: the trade-weighted exchange rate news index of ' ...
        '\\citet{stavrakeva2018survey}, quarterly averages. $\\Delta s_t$ due to ' ...
        'technology and noise: the exchange rate path implied by the two disturbances ' ...
        'jointly, from the VAR estimated over %s at the point estimate. The last row ' ...
        'checks that the two sources date the same quarters alike.}\n'], ...
        span, numel(kk), vspan);
    fprintf(fid,'\\end{table}\n');
    fprintf('  wrote Tables/tab_st_news.tex\n');

    out = struct('corr', R, 'nobs', numel(kk), 'span', span, 'labels', {LBL});

    if opt.echo
        fprintf('\n  Stavrakeva-Tang news index, %s (%d obs), VAR %s\n', ...
                strrep(span,'--','-'), numel(kk), strrep(vspan,'--','-'));
        NM = {'index vs tech+noise dNER', 'index vs dNER', ...
              'tech+noise dNER vs dNER', 'dNER vs ST dNER (check)'};
        for i = 1:4
            fprintf('    %-28s %6.3f\n', NM{i}, R(i));
        end
    end
end

function v = local_corr(x, y)
    c = corrcoef(x(:), y(:));  v = c(1,2);
end

function s = qlabel(d)
%   2002.25 -> 2002Q2
    y = floor(d + 1e-9);
    s = sprintf('%dQ%d', y, round((d - y)*4) + 1);
end
