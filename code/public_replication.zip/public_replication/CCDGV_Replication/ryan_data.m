% ryan_data.m
% =========================================================================
% Builds `data` and `dates` for the VAR from the rebuilt panels in
% replicated data (../Data_Replication/Built_Data/Y_benchmark<suffix>.mat). Reads
% `start_date` and `end_date` from the workspace exactly as run_main sets them,
% and returns every manifest data series as `data`, plus `dates`. The count is
% whatever ccdgv_manifest declares -- 21 at present -- and run_main asserts that
% the column count and the manifest agree.
%
% NO CASE SWITCH. There is one unconditional matrix, and which columns enter the
% VAR is decided downstream by
% ccdgv_manifest + info.inclvar, resolved by NAME in run_main. The loader's only
% job is to supply every declared series, or NaN where it cannot.
%
% A SERIES THIS BUILD LACKS COMES BACK NaN, and that is now quiet -- see the
% TB_G6/NX_GDP guard below, whose warning is the only signal.
%
% Conventions matched to the original:
%   - column order = ccdgv_manifest's data list, identical to
%     the manifest's order;
%   - `data = 100*data` scaling;
%   - rows = [cfg.sample_start, end_date]: the FULL history is loaded and clipped
%     to start at Ryan's cfg.sample_start (keep it at 1978Q4 to match the paper
%     baseline) and end at run_main's end_date (fractional year, 2008+1/4=2008:Q2).
% =========================================================================

if ~exist('end_date','var'); end_date = Inf; end   % default: take all of Ryan's sample

% --- locate & load Ryan's FULL replicated history -----------------------
% `built_suffix` (e.g. '_f2026') selects a vintage-tagged build produced by
% data_import_and_transform with built_suffix_override set. Unset -> the legacy
% untagged filenames, so existing callers are unaffected.
here = fileparts(mfilename('fullpath'));
bsfx = '';
if exist('built_suffix','var') && ~isempty(built_suffix)
    bsfx = char(built_suffix);
end
ryanfile = fullfile(here, '..', 'Data_Replication', 'Built_Data', ['Y_benchmark' bsfx '.mat']);
assert(exist(ryanfile,'file')==2, ...
    'ryan_data: %s not found — run Data_Replication/data_import_and_transform first.', ryanfile);
R  = load(ryanfile);   Yb = R.Y;                   % FULL history (~1976Q1-2019Q3)

% Record which Fernald vintage this build carries. Nothing selects it here -- it
% is baked into whichever Y_benchmark<bsfx>.mat was built, and cfg travels inside
% that file. Surfacing it means a run can say which vintage it used instead of
% the answer depending on what was built last under the untagged name.
tfp_vintage = 'unknown';
if isfield(R,'cfg') && isfield(R.cfg,'fernald_vintage')
    tfp_vintage = char(string(R.cfg.fernald_vintage));
end
tfp_source = sprintf('Y_benchmark%s.mat (Fernald %s)', bsfx, tfp_vintage);

% --- clip rows to [start, end_date] -------------------------------------
% Start = `start_date` if set in the workspace (fractional year, e.g. 1976 ->
% 1976Q1), else Ryan's cfg.sample_start (1978Q4 paper baseline).
if exist('start_date','var') && isfinite(start_date)
    sd = datetime(floor(start_date), round((start_date-floor(start_date))*4)*3 + 1, 1);
    Yb = Yb(Yb.Time >= sd, :);
elseif isfield(R,'cfg') && isfield(R.cfg,'sample_start')
    Yb = Yb(Yb.Time >= R.cfg.sample_start, :);     % start = Ryan's explicit window start
end
if isfinite(end_date)                              % fractional year -> quarter-start datetime
    ed = datetime(floor(end_date), round((end_date-floor(end_date))*4)*3 + 1, 1);
    Yb = Yb(Yb.Time <= ed, :);
end

% --- Ryan's variables (column vectors) ----------------------------------
TFP=Yb.TFP; C=Yb.C; I=Yb.I; NER=Yb.NER; IDIFF=Yb.IDIFF;
Cs=Yb.Cstar; PId=Yb.CPIDIFF; Is=Yb.Istar; Q=Yb.q_real;   % Q = ln S + ln P* - ln P

% --- per-country override -----------------------------------------------
% Y's NER, IDIFF, Cstar, CPIDIFF and Istar are G6 AGGREGATES. A country run
% replaces those five with that country's own, rebuilt by
% newcore_country_series from the per-country panels using the same aggregators.
% TFP, C and I are US series and do not vary by country, so they stay.
%
% WITHOUT THIS the country never reached the data and every by-country run on
% this core re-estimated G6 -- six runs differing only in their filename and in
% whatever sample window each was pinned to (found 2026-08-07; genfig_B9B10 now
% compares the six pairwise, which is the check that catches it).
%
% Aligned BY DATE, as SOLOW_G6/TECH/EXRET below are: the panels carry their own
% full history while Yb's window moves with start_date/end_date.
if exist('country','var') && ~strcmp(country,'G6')
    CT        = newcore_country_series(R, country);
    [tf, loc] = ismember(Yb.Time, CT.Time);
    ctnm      = {'NER','IDIFF','Cstar','CPIDIFF','Istar','q_real'};
    ctv       = nan(height(Yb), numel(ctnm));
    for ctk = 1:numel(ctnm)
        v = CT.(ctnm{ctk});
        ctv(tf,ctk) = v(loc(tf));
    end
    NER = ctv(:,1);  IDIFF = ctv(:,2);  Cs = ctv(:,3);
    PId = ctv(:,4);  Is    = ctv(:,5);  Q  = ctv(:,6);
    fprintf('  ryan_data: per-country series for %s (%d of %d quarters covered)\n', ...
            country, sum(all(isfinite(ctv),2)), height(Yb));
end

% Trade-balance auxiliaries, appended to Y by data_import_and_transform (§6b) in
% in that order. Guarded so a Y
% built before that block still loads.
%
% ⚠ THE WARNING IS THE ONLY SIGNAL. This guard used to say the resulting NaNs
% were "loud rather than silent" because the NaN-row drop below would shorten the
% sample. That drop was since removed (see the note further down -- it was masking
% on ALL columns and capping every run at TB_G6's end). So an unrebuilt Y now
% yields two all-NaN rows in A that propagate into the variance-decomposition
% integrals, where they cost ~20x runtime in failed quadrature and produce NaN
% variance shares. This has happened:
% Trade Balance, U.S. Net Exports) came back NaN while every other series was fine.
% If you see this warning, rebuild BOTH tagged Y files, not just the untagged one.
%
% Stored as fractions; `data = 100*data` further down puts them in percent of GDP.
if ismember('TB_G6',  Yb.Properties.VariableNames); TB_G6  = Yb.TB_G6;
else; TB_G6  = nan(height(Yb),1); warning('ryan_data:noTB','Y has no TB_G6; rebuild Y_benchmark.'); end
if ismember('NX_GDP', Yb.Properties.VariableNames); NX_GDP = Yb.NX_GDP;
else; NX_GDP = nan(height(Yb),1); warning('ryan_data:noNX','Y has no NX_GDP; rebuild Y_benchmark.'); end

% --- equity series: real MSCI TOTAL-RETURN index,
% CPI-deflated, period-average, log levels (lnEQreal_US/_G6) from EQ_real_msci.mat,
% the from-scratch replacement for the original nominal MSCI price index. Aligned to
% Yb rows; loaded only if built (else the equity cases error like any unbuilt series).
%   EQ_US/EQ_G6 : log levels, the manifest's eq_us and eq_g6.
%
% The real-log-RETURN variants (rEQreal_US/_G6) used to be read here for the
% growth-equity variants: the manifest has no growth spec,
% nothing selected them, and they never reached `data`. Dropped with the rest of
% the case machinery -- EQ_real_msci.mat still carries the columns, so restoring
% them is two lines if a growth spec is ever added to ccdgv_manifest.
% NaN COLUMNS WHEN UNBUILT, NOT ABSENT ONES. These used to start as [] and stay
% that way if the panel was missing, and `data` below concatenates them -- so an
% unbuilt equity panel silently produced a matrix TWO COLUMNS NARROWER, shifting
% every column after it. The manifest-count assert in run_main catches the width
% eventually, but only after the projection loop has already run against
% mislabelled columns. Full-height NaN keeps every later column where it belongs
% and lets a spec that actually selects eq_us or eq_g6 fail on the NaN, which is
% what the line above means by erroring "like any unbuilt series".
EQ_US  = nan(height(Yb), 1);   EQ_G6 = nan(height(Yb), 1);
eqfile = fullfile(here, '..', 'Data_Replication', 'Built_Data', ['EQ_real_msci' bsfx '.mat']);
if exist(eqfile,'file')==2
    E = load(eqfile); EQt = E.EQ_out;
    [tf, loc]  = ismember(Yb.Time, EQt.Time);
    EQ_US(tf)  = EQt.lnEQreal_US(loc(tf));
    EQ_G6(tf)  = EQt.lnEQreal_G6(loc(tf));
else
    warning('ryan_data:noEquityPanel', ...
        ['%s not found: eq_us and eq_g6 are NaN for this run. Specs that use ' ...
         'them will fail on the NaN; the rest are unaffected.'], eqfile);
end

% --- the manifest's data series, in manifest order -----------------------
% ONE unconditional matrix. There is no case switch: which of these columns
% enters the VAR is ccdgv_manifest's business (info.inclvar picks a spec, and
% run_main selects columns by name via var_order), not the loader's. A series
% this build cannot supply comes back NaN and is projected on whatever sample it
% has -- membership is decided downstream, so the loader has nothing to branch on.
%
% ORDER IS THE CONTRACT: it must match ccdgv_manifest's data list and
% the manifest's rows exactly. Appending is safe, reordering is
% not.
% solow_g6, manifest row 13. Aligned BY DATE, not by position: Yb's window moves
% with start_date/end_date while the Solow series is fixed from 1976Q1, so a head
% slice would silently misalign whenever the window does not start there.
% Quarters outside its span come back NaN and are projected on what exists.
% the Solow panel is now built in
% Data_Replication/data_import_and_transform (load_solow + geo_aggregate_growth,
% beside every other foreign aggregate), so Y carries the column and the separate
% the Foreign Solow residual is built in the data step. No alignment work
% is needed any more -- it arrives on Y's own grid.
assert(ismember('SOLOW_G6', Yb.Properties.VariableNames), 'ryan_data:noSolow', ...
    ['%s predates the SOLOW_G6 column. Rebuild with ' ...
     'Data_Replication/build_all_vintages.m.'], ryanfile);
SOLOW_G6 = Yb.SOLOW_G6;

% Technology proxies, manifest rows 14-17. Aligned BY DATE for the same reason
% as SOLOW_G6: Yb's window moves, USDATA.xlsx's does not. Like the Solow column
% these are read from the ORIGINAL sheet, so they are not part of the
% from-scratch replication either.
[tech_v, tech_t] = tech_proxy_series();
TECH = nan(height(Yb), size(tech_v,2));
[tf, loc] = ismember(Yb.Time, tech_t);
TECH(tf,:) = tech_v(loc(tf),:);

% Expected excess return differentials, manifest rows 18-19. As TECH: read from
% the ORIGINAL ASSET_PRICE_data (which run_main runs before this loader), aligned
% by date, LED one quarter with a NaN final row.
% EXRET and the bond yields, read BY DATE from AP_returns.mat -- the same way
% EQ_US/EQ_G6 come from EQ_real_msci.mat above. This used to require the four
% series as loose WORKSPACE variables, with an assert reading "run
% ASSET_PRICE_data first (run_main does)", which is why run_main re-ran the whole
% of ASSET_PRICE_data -- re-reading the MSCI workbook and re-running load_bonds --
% for series the build had already computed and could simply have saved.
%
% EXRET IS LED BY ONE QUARTER, as before: the manifest's exret_*_lead are the
% return realised over t+1, so the value at t is next quarter's. The panel stores
% the UNLED series, so the lead is applied here, where it is visible.
lead1 = @(x) [x(2:end); NaN];
EXRET = nan(height(Yb), 2);
BY    = nan(height(Yb), 2);
apfile = fullfile(here, '..', 'Data_Replication', 'Built_Data', ['AP_returns' bsfx '.mat']);
assert(exist(apfile,'file')==2, 'ryan_data:noAPreturns', ...
    ['%s not found. It carries exret_eq/exret_bond/by_us/by_g6 and is written by ' ...
     'Data_Replication/data_import_and_transform. Rebuild with ' ...
     'Data_Replication/build_all_vintages.m.'], apfile);
A = load(apfile); APt = A.AP_out;
[tf, loc] = ismember(Yb.Time, APt.Time);
ap_eq_lead   = lead1(APt.exret_eq);      % MATLAB cannot index a call result
ap_bond_lead = lead1(APt.exret_bond);
EXRET(tf,:) = [ap_eq_lead(loc(tf)), ap_bond_lead(loc(tf))];
BY(tf,:)    = [APt.by_us(loc(tf)), APt.by_g6(loc(tf))];   % NOT led: levels

data = [TFP C I NER IDIFF Cs PId Is EQ_US EQ_G6 TB_G6 SOLOW_G6 TECH EXRET BY [NaN; diff(TB_G6)]];
% the last column is dtb_g6, the quarterly change in TB_G6 (manifest row dtb_g6)

% --- NO NaN-ROW DROP HERE. It used to mask on ALL columns, so an auxiliary with
%     partial coverage silently shortened the VAR's sample to its own span: TB_G6
%     ends 2018Q4, which capped every run at 2018Q4 whatever end_date said.
%     run_main builds the mask from the VAR columns only; auxiliaries keep their
%     NaNs and ccdgv_project fits each on whatever sample it has.
data  = 100 * data;                                         % match the original scaling
dates = year(Yb.Time).' + (quarter(Yb.Time).' - 1)/4;       % fractional-year row vector
