function [data, dates, tfp_vintage, tfp_source] = ryan_data(country, start_date, end_date)
%RYAN_DATA  Build `data` and `dates` for the VAR from the built panels.
%
%   [data, dates, tfp_vintage, tfp_source] = ryan_data(country, start_date, end_date)
%
%   country               'G6', or a country name for a by-country run
%   start_date, end_date  sample limits as fractional years (2008.25 = 2008Q2).
%                         Non-finite: from the build's cfg.sample_start, or to
%                         the end of the panel.
%   data    T x N matrix, one column per data series of ccdgv_manifest, in
%           manifest order, multiplied by 100. A series with no value is NaN.
%   dates   1 x T fractional years
%   tfp_vintage, tfp_source   the Fernald vintage the panel carries

% Load the panel.
here = fileparts(mfilename('fullpath'));
ryanfile = fullfile(here, '..', 'Data_Replication', 'Built_Data', 'Y_benchmark_f2026.mat');
assert(exist(ryanfile,'file')==2, ...
    'ryan_data: %s not found — run Data_Replication/data_import_and_transform first.', ryanfile);
R  = load(ryanfile);   Yb = R.Y;                   % full history

% Record which Fernald vintage the panel carries.
tfp_vintage = 'unknown';
if isfield(R,'cfg') && isfield(R.cfg,'fernald_vintage')
    tfp_vintage = char(string(R.cfg.fernald_vintage));
end
tfp_source = sprintf('Y_benchmark_f2026.mat (Fernald %s)', tfp_vintage);

% Clip rows to [start_date, end_date]. A fractional year becomes a quarter-start date.
if isfinite(start_date)
    sd = datetime(floor(start_date), round((start_date-floor(start_date))*4)*3 + 1, 1);
    Yb = Yb(Yb.Time >= sd, :);
elseif isfield(R,'cfg') && isfield(R.cfg,'sample_start')
    Yb = Yb(Yb.Time >= R.cfg.sample_start, :);
end
if isfinite(end_date)
    ed = datetime(floor(end_date), round((end_date-floor(end_date))*4)*3 + 1, 1);
    Yb = Yb(Yb.Time <= ed, :);
end

% Variables as column vectors.
TFP=Yb.TFP; C=Yb.C; I=Yb.I; NER=Yb.NER; IDIFF=Yb.IDIFF;
Cs=Yb.Cstar; PId=Yb.CPIDIFF; Is=Yb.Istar;

% By-country run: replace the five G6 aggregates with the country's own series,
% aligned by date. TFP, C and I are US series and stay.
if ~strcmp(country,'G6')
    CT        = newcore_country_series(R, country);
    [tf, loc] = ismember(Yb.Time, CT.Time);
    ctnm      = {'NER','IDIFF','Cstar','CPIDIFF','Istar'};
    ctv       = nan(height(Yb), numel(ctnm));
    for ctk = 1:numel(ctnm)
        v = CT.(ctnm{ctk});
        ctv(tf,ctk) = v(loc(tf));
    end
    NER = ctv(:,1);  IDIFF = ctv(:,2);  Cs = ctv(:,3);
    PId = ctv(:,4);  Is    = ctv(:,5);
    fprintf('  ryan_data: per-country series for %s (%d of %d quarters covered)\n', ...
            country, sum(all(isfinite(ctv),2)), height(Yb));
end

% Trade balance, stored as a fraction of GDP. NaN, with a warning, if the panel
% lacks it.
if ismember('TB_G6',  Yb.Properties.VariableNames); TB_G6  = Yb.TB_G6;
else; TB_G6  = nan(height(Yb),1); warning('ryan_data:noTB','Y has no TB_G6; rebuild Y_benchmark.'); end

% Equity: log real MSCI total-return indices, aligned by date. NaN, with a
% warning, if the equity panel has not been built.
EQ_US  = nan(height(Yb), 1);   EQ_G6 = nan(height(Yb), 1);
eqfile = fullfile(here, '..', 'Data_Replication', 'Built_Data', 'EQ_real_msci_f2026.mat');
if exist(eqfile,'file')==2
    E = load(eqfile); EQt = E.EQ_out;
    [tf, loc]  = ismember(Yb.Time, EQt.Time);
    EQ_US(tf)  = EQt.lnEQreal_US(loc(tf));
    EQ_G6(tf)  = EQt.lnEQreal_G6(loc(tf));
else
    warning('ryan_data:noEquityPanel', ...
        ['%s not found: eq_us and eq_g6 are NaN for this run. Specs that use ' ...
         'them will fail on the NaN; the rest are unaffected.'], eqfile);
end

% Foreign Solow residual.
assert(ismember('SOLOW_G6', Yb.Properties.VariableNames), 'ryan_data:noSolow', ...
    ['%s predates the SOLOW_G6 column. Rebuild with ' ...
     'Data_Replication/build_all_vintages.m.'], ryanfile);
SOLOW_G6 = Yb.SOLOW_G6;

% Technology proxies, aligned by date.
[tech_v, tech_t] = tech_proxy_series();
TECH = nan(height(Yb), size(tech_v,2));
[tf, loc] = ismember(Yb.Time, tech_t);
TECH(tf,:) = tech_v(loc(tf),:);

% Excess return differentials and bond yields from AP_returns, aligned by date.
% The excess returns are led one quarter: the value at t is the return realised
% over t+1.
lead1 = @(x) [x(2:end); NaN];
EXRET = nan(height(Yb), 2);
BY    = nan(height(Yb), 2);
apfile = fullfile(here, '..', 'Data_Replication', 'Built_Data', 'AP_returns_f2026.mat');
assert(exist(apfile,'file')==2, 'ryan_data:noAPreturns', ...
    ['%s not found. It carries exret_eq/exret_bond/by_us/by_g6 and is written by ' ...
     'Data_Replication/data_import_and_transform. Rebuild with ' ...
     'Data_Replication/build_all_vintages.m.'], apfile);
A = load(apfile); APt = A.AP_out;
[tf, loc] = ismember(Yb.Time, APt.Time);
ap_eq_lead   = lead1(APt.exret_eq);      % MATLAB cannot index a call result
ap_bond_lead = lead1(APt.exret_bond);
EXRET(tf,:) = [ap_eq_lead(loc(tf)), ap_bond_lead(loc(tf))];
BY(tf,:)    = [APt.by_us(loc(tf)), APt.by_g6(loc(tf))];   % levels, not led

% One column per manifest data series; the order must match ccdgv_manifest.
data = [TFP C I NER IDIFF Cs PId Is EQ_US EQ_G6 TB_G6 SOLOW_G6 TECH EXRET BY];

% Rows with NaN are kept: auxiliary series have partial coverage.
data  = 100 * data;                                         % scale by 100
dates = year(Yb.Time).' + (quarter(Yb.Time).' - 1)/4;       % fractional-year row vector
end
