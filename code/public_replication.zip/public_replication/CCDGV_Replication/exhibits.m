function exhibits(cfg, S)
%EXHIBITS  Build every figure and table, in the order they appear in the paper.
%
%   exhibits(cfg, S)
%
%   S is the struct of run descriptors that sweep() returns. If it is omitted,
%   the saved copy in cfg.resultdir is loaded.
%
%   Figures land in cfg.exhibitdir/Figures, tables in cfg.exhibitdir/Tables, and
%   the extended-sample appendix in cfg.exhibitdir/Extended. paper_exhibits.tex
%   collects all of them.
%
%   WHICH GENERATOR MAKES WHICH EXHIBIT. The numbered generators are named for
%   the exhibit they produce; the rest are named for their content. The output
%   filenames are historical and do not track the numbering.
%
%     Figure 1         genplots_uhlig      uhlig_resubmit
%     Figures 2-4      genplots_paper      Figure2a_tfp/_noise, Figure2b, Figure3b
%     Figure 5         genfig_asset_proj   asset_proj_tech/_noise
%     Figure 6         genpoorman          POORMAN_yearly
%     Figures 7, B.13  genplots_ew         GC_ALL_EWSAMPLE{a,b}, GC_ALL{a,b}
%     Figure B.5       genfig_tb           TB_IRFs_new
%     Figure B.6       genfig_B6           returns_tech_new/_noise_new
%     Figures B.7-B.8  genfig_B7B8         alt_technology, alt_noise
%     Figures B.9-B.10 genfig_B9B10        individual_tfp_new/_noise_new
%     Figure B.11      genfig_B11          shock_series_new
%     Figure B.12      genfig_B12          irrer_r_new
%     Figure B.14      genfig_B14          Patents_IRFs_tfp_new/_noise_new
%
%   Tables come from the write_* functions, named after what they contain.

    if nargin < 2 || isempty(S)
        f = fullfile(cfg.resultdir, 'sweep_infos.mat');
        assert(isfile(f), 'exhibits:noInfos', ...
            '%s not found -- run sweep(cfg) first.', f);
        L = load(f); S = L.sweep_infos;
    end

    % EVERY GENERATOR STARTS FROM A CLEAN STATE, and that now happens before each
    % one rather than only here. Some adopt the current figure, which would make
    % their output depend on what ran before them; and nothing closed what a
    % generator left open, so figures accumulated across the whole run. That is
    % not only untidy: exportgraphics drawnow-syncs every open figure, so the
    % cost of writing one PDF grows with the number still on screen -- measured
    % at 5 s with two figures open and 20 s with forty. By the extended-sample
    % figures, near the end, fifty to eighty were open and the export could stall
    % for minutes.
    close all

    FIG = fullfile(cfg.exhibitdir, 'Figures');
    TAB = fullfile(cfg.exhibitdir, 'Tables');
    for d = {FIG, TAB}; if ~isfolder(d{1}); mkdir(d{1}); end; end

    base = S.base;
    datam = local_runfile(cfg, base);
    % The write_* functions take the exhibit ROOT and append Tables/ themselves.
    % arlags travels with it because the variance-share denominator has to be
    % refit at the projection stage's own AR order.
    topt  = struct('outdir', cfg.exhibitdir, 'arlags', cfg.vd_arlags);

    fprintf('\n--- main text ---\n');
    close all
    genplots_uhlig(datam, FIG);                              % Figure 1
    write_uhlig_tables(datam, topt);                         % Tables 1, B.4, B.5
    close all
    genplots_paper(datam, FIG);                              % Figures 2, 3, 4
    write_vd_table(datam, topt);                             % Table 2
    write_moments_table(datam, topt);                        % Table 3
    close all
    genfig_asset_proj(base, FIG);                            % Figure 5
    genpoorman(struct('vintage', cfg.vintage, ...            % Figure 6, Table B.8
                      'start','paper', 'end_date','run', ...
                      'datafile', datam, 'outdir', cfg.exhibitdir));
    close all
    genplots_ew(FIG, struct( ...                             % Figures 7, B.13
        'fig7', struct('range',[1974.00 2001.50],'NH',16), ...
        'b13',  struct('range',[1976.00 2020.00],'NH',20), ...
        'vintage', cfg.vintage));

    fprintf('\n--- appendix B ---\n');
    close all
    genfig_tb(base, FIG);                                    % Figure B.5
    close all
    genfig_B6(base, FIG);                                    % Figure B.6
    close all
    genfig_B7B8(base, local_alt(S), FIG);                     % Figures B.7, B.8
    write_alt_tables(S, struct('echo',false,'outdir',cfg.exhibitdir));   % Tables B.6, B.7
    close all
    genfig_B9B10(S.country, base, FIG);                        % Figures B.9, B.10
    close all
    genfig_B11(base, S.nofx, FIG);                           % Figure B.11
    close all
    genfig_B12(base, S.nofx, FIG);                           % Figure B.12
    close all
    genfig_B14(base, FIG);                                   % Figure B.14
    write_trading_table(datam, topt);                        % Table B.9

    fprintf('\n--- numbers quoted in the text ---\n');
    write_text_numbers(S, topt);
    write_asset_proj_vd_table(base, topt);

    fprintf('\n--- referee figures ---\n');
    close all
    genfig_R1(base, local_r1(S), FIG);
    close all
    genfig_R23(base, S.eqnofx, 'w/o FX, w/ Equity Prices', 'R2', 'Real Exchange Rate', FIG);
    close all
    genfig_R23(base, S.bynofx, 'w/o FX, w/ Bond Yields',   'R3', 'Real Exchange Rate', FIG);
    % R2fx/R3fx ARE NOT DRAWN ANY MORE. They passed genfig_R23 the same base, the
    % same alternative and the same 'Real Exchange Rate' label as R2/R3, differing
    % only in the legend wording and the filename -- 886 pixels in 330k, which is
    % the legend text. They existed while R2/R3's sixth panel was blank; R2/R3
    % pass the label too now, so the pair was four redundant figures under a
    % caption claiming a difference that is not there.
    close all
    genfig_R23(base, S.eq, 'w/ Equity Prices', 'R4', 'Real Exchange Rate', FIG);
    close all
    genfig_R23(base, S.by, 'w/ Bond Yields',   'R5', 'Real Exchange Rate', FIG);

    % The extended-sample appendix runs four of the main-text generators again on
    % the extended estimate, writing the same filenames into Extended/.
    fprintf('\n--- appendix B, extended sample ---\n');
    EFIG = fullfile(cfg.exhibitdir, 'Extended', 'Figures');
    ETAB = fullfile(cfg.exhibitdir, 'Extended', 'Tables');
    for d = {EFIG, ETAB}; if ~isfolder(d{1}); mkdir(d{1}); end; end
    edatam = local_runfile(cfg, S.extend);
    eopt   = struct('outdir', fullfile(cfg.exhibitdir,'Extended'), ...
                    'arlags', cfg.vd_arlags);
    close all
    genplots_uhlig(edatam, EFIG);                            % Figure B.1
    write_uhlig_tables(edatam, eopt);                        % Table B.1
    close all
    genplots_paper(edatam, EFIG);                            % Figures B.2, B.3, B.4
    write_vd_table(edatam, eopt);                            % Table B.2
    write_moments_table(edatam, eopt);                       % Table B.3

    fprintf('\nExhibits written to %s\n', cfg.exhibitdir);

    % ---- and the document that collects them --------------------------------
    local_compile(cfg.exhibitdir);
end

% =========================================================================
function local_compile(root)
%LOCAL_COMPILE  Rebuild paper_exhibits.pdf from the figures just written.
%
%   THE PDF IS TRACKED AND ITS INPUTS ARE NOT. Figures/ and Tables/ are
%   gitignored because they are generated; paper_exhibits.pdf is in version
%   control because it is the thing a reader opens. That combination drifts
%   silently -- the committed document is only ever as current as whoever last
%   remembered to run pdflatex, and nothing in the repository says when that was.
%   It had gone stale by a day's work before anyone noticed. Compiling it here
%   means it cannot be older than the figures beside it.
%
%   A MISSING FIGURE DOES NOT FAIL THE BUILD. paper_exhibits.tex draws a red
%   "<file> not found" box instead, by design, so a partial run still produces a
%   readable document -- which also means a broken document compiles silently.
%   The count is checked and reported.
    tex = fullfile(root, 'paper_exhibits.tex');
    if ~isfile(tex)
        fprintf('  no paper_exhibits.tex in %s; nothing to compile\n', root);
        return
    end
    if system('which pdflatex > /dev/null 2>&1') ~= 0
        fprintf(['  pdflatex not on PATH: paper_exhibits.pdf NOT rebuilt and is\n' ...
                 '  now older than the figures above. Compile it by hand.\n']);
        return
    end

    here = cd(root);
    back = onCleanup(@() cd(here));
    % Twice: the notes in two appendix tables \ref the hand-written calibration
    % table, and a one-pass run leaves those as ??.
    for k = 1:2
        [st, ~] = system('pdflatex -interaction=nonstopmode -halt-on-error paper_exhibits.tex');
    end
    if st ~= 0 || ~isfile('paper_exhibits.pdf')
        fprintf(2, '  pdflatex failed; see %s\n', fullfile(root,'paper_exhibits.log'));
        return
    end

    % How many slots came out empty. pdftotext is not always present, so this is
    % best-effort: no report is better than a wrong one.
    nmiss = NaN;
    if system('which pdftotext > /dev/null 2>&1') == 0
        [~, out] = system('pdftotext paper_exhibits.pdf - | grep -c "not found"');
        nmiss = str2double(strtrim(out));
    end
    if isfinite(nmiss) && nmiss > 0
        fprintf(2, ['  paper_exhibits.pdf rebuilt, but %d exhibit slot(s) are empty.\n' ...
                    '  Those figures or tables were not produced by this run.\n'], nmiss);
    elseif isfinite(nmiss)
        fprintf('  paper_exhibits.pdf rebuilt, every slot filled\n');
    else
        fprintf('  paper_exhibits.pdf rebuilt\n');
    end
end

% =========================================================================
function f = local_runfile(cfg, info)
    [~, nm] = data_name(info);
    [~, stem, ext] = fileparts(nm);
    f = fullfile(cfg.resultdir, [stem ext]);
    assert(isfile(f), 'exhibits:noRun', ...
        '%s not found -- run sweep(cfg) first.', f);
end

function A = local_alt(S)
% The alternative specifications overlaid on Figures B.7 and B.8, in the order
% the paper draws them.
    A = {'VECM',              S.vecm
         'w/ Trade Balance',  S.tb
         'w/ Equity Price',   S.eq
         'w/ Foreign Solow',  S.forTFP
         'w/ Bond Yields',    S.by};
end

function R = local_r1(S)
% The two no-FX asset specifications overlaid on Figure R1.1.
    R = {'w/o FX, w/ Equity Prices', S.eqnofx
         'w/o FX, w/ Bond Yields',   S.bynofx};
end
