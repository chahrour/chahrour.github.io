function exhibits(cfg, S, compile)
%EXHIBITS  Build every figure and table, in the order they appear in the paper.
%
%   exhibits(cfg)
%   exhibits(cfg, S)
%   exhibits(cfg, S, compile)
%
%   cfg      settings struct from config().
%   S        run descriptors returned by sweep(); if omitted or empty, the saved
%            copy in cfg.resultdir is loaded.
%   compile  rebuild paper_exhibits.pdf at the end (default true).
%
%   Figures go to cfg.exhibitdir/Figures and tables to cfg.exhibitdir/Tables.
%   Each file is named for its number in the draft, e.g. Figure2a.pdf, TableC9.tex.

    if nargin < 3; compile = true; end
    if nargin < 2 || isempty(S); S = load_sweep_infos(cfg); end

    % Figures are closed before each generator: some generators adopt the current
    % figure, and exportgraphics slows down as open figures accumulate.
    close all

    FIG = fullfile(cfg.exhibitdir, 'Figures');
    TAB = fullfile(cfg.exhibitdir, 'Tables');
    for d = {FIG, TAB}; if ~isfolder(d{1}); mkdir(d{1}); end; end

    base = S.base;
    datam = local_runfile(cfg, base);
    % The write_* functions take the exhibit root and append Tables/ themselves.
    % arlags is the AR order of the variance-share denominator.
    topt  = struct('outdir', cfg.exhibitdir, 'arlags', cfg.vd_arlags);

    fprintf('\n--- main text ---\n');
    close all
    genplots_uhlig(datam, FIG, 'Figure1');                   % Figure 1
    write_uhlig_tables(datam, setfield(topt, 'names', ...   % Tables 1, C.4, C.5
        struct('main','Table1', 'AF','TableC4', 'HF','TableC5')));
    close all
    genplots_paper(datam, FIG, ...                           % Figures 2, 3, 4
        {'Figure2a','Figure2b','Figure3','Figure4'});
    write_vd_table(datam, setfield(topt, 'name', 'Table2'));        % Table 2
    write_moments_table(datam, setfield(topt, 'name', 'Table3'));   % Table 3
    close all
    genfig_asset_proj(base, FIG);                            % Figure 5
    genpoorman(struct('vintage', cfg.vintage, ...            % Figure 6, Table C.8
                      'start','paper', 'end_date','run', ...
                      'datafile', datam, 'outdir', cfg.exhibitdir));
    close all
    genplots_ew(FIG, struct( ...                             % Figures 7, C.13
        'fig7', struct('range',[1974.00 2001.50],'NH',16), ...
        'c13',  struct('range',[1976.00 2020.00],'NH',20)));

    % Figures C.1-C.4 and Tables C.1-C.3: the same generators on the extended sample.
    fprintf('\n--- appendix C, extended sample ---\n');
    edatam = local_runfile(cfg, S.extend);
    close all
    genplots_uhlig(edatam, FIG, 'FigureC1');                 % Figure C.1
    write_uhlig_tables(edatam, setfield(topt, 'names', ...  % Table C.1
        struct('main','TableC1')));
    close all
    genplots_paper(edatam, FIG, ...                          % Figures C.2, C.3, C.4
        {'FigureC2a','FigureC2b','FigureC3','FigureC4'});
    write_vd_table(edatam, setfield(topt, 'name', 'TableC2'));       % Table C.2
    write_moments_table(edatam, setfield(topt, 'name', 'TableC3'));  % Table C.3

    fprintf('\n--- appendix C ---\n');
    close all
    genfig_tb(base, FIG);                                    % Figure C.5
    close all
    genfig_C6(base, FIG);                                    % Figure C.6
    close all
    genfig_C7C8(base, local_alt(S), FIG);                     % Figures C.7, C.8
    write_alt_tables(S, struct('echo',false,'outdir',cfg.exhibitdir));   % Tables C.6, C.7
    close all
    genfig_C9C10(S.country, base, FIG);                        % Figures C.9, C.10
    close all
    genfig_C11(base, S.nofx, FIG);                           % Figure C.11
    close all
    genfig_C12(base, S.nofx, FIG);                           % Figure C.12
    close all
    genfig_C14(base, FIG);                                   % Figure C.14
    write_trading_table(datam, topt);                        % Table C.9

    fprintf('\n--- numbers quoted in the text ---\n');
    write_text_numbers(S, topt);
    write_asset_proj_vd_table(base, topt);

    fprintf('\n--- referee figures ---\n');
    close all
    genfig_R1(base, local_r1(S), FIG);
    close all
    genfig_R23(base, S.eqnofx, 'w/o FX, w/ Equity Prices', 'R2', 'Real Exchange Rate', FIG);
    close all
    genfig_R23(base, S.bynofx, 'w/o FX, w/ Bond Yields',   'R3', 'Real Exchange Rate', FIG);
    close all
    genfig_R23(base, S.eq, 'w/ Equity Prices', 'R4', 'Real Exchange Rate', FIG);
    close all
    genfig_R23(base, S.by, 'w/ Bond Yields',   'R5', 'Real Exchange Rate', FIG);

    fprintf('\nExhibits written to %s\n', cfg.exhibitdir);

    % Compile the document that collects the exhibits.
    if compile; compile_exhibits(cfg.exhibitdir); end
end

function f = local_runfile(cfg, info)
    [~, nm] = data_name(info);
    [~, stem, ext] = fileparts(nm);
    f = fullfile(cfg.resultdir, [stem ext]);
    assert(isfile(f), 'exhibits:noRun', ...
        '%s not found -- run sweep(cfg) first.', f);
end

function A = local_alt(S)
% The alternative specifications overlaid on Figures C.7 and C.8, in plot order.
    A = {'VECM',              S.vecm
         'w/ Trade Balance',  S.tb
         'w/ Equity Price',   S.eq
         'w/ Foreign Solow',  S.forTFP
         'w/ Bond Yields',    S.by};
end

function R = local_r1(S)
% The two no-FX asset specifications overlaid on the referee figure R1.
    R = {'w/o FX, w/ Equity Prices', S.eqnofx
         'w/o FX, w/ Bond Yields',   S.bynofx};
end
