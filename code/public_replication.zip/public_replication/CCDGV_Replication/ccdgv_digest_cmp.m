function out = ccdgv_digest_cmp(A, B, opt)
%CCDGV_DIGEST_CMP  Compare two digests and name every difference.
%
%   out = ccdgv_digest_cmp(A, B)         two digests from ccdgv_digest
%   out = ccdgv_digest_cmp(dirA, dirB)   digest both directories, then compare
%   out = ccdgv_digest_cmp(A, B, opt)
%
%   opt.tol    absolute tolerance (default 0, exact).
%   opt.quiet  suppress the report (default false).
%   opt.mode   'draws' (default) compares the draw-level summaries, which is
%              valid when both runs share a random stream; 'median' compares the
%              posterior-median summaries, for runs that do not; 'both' compares
%              all of them.
%
%   out.equal  true if nothing differs beyond opt.tol.
%   out.diffs  one row per differing quantity: run, field, what, a, b, reldiff.
%   out.onlyA  runs present in A and not in B.
%   out.onlyB  runs present in B and not in A.
%
%   Arrays of different shape are reported as a shape difference and not
%   compared further.
%
%   See also CCDGV_DIGEST.

    if nargin < 3; opt = struct(); end
    if ~isfield(opt,'tol');   opt.tol = 0;       end
    if ~isfield(opt,'quiet'); opt.quiet = false; end
    if ~isfield(opt,'mode');  opt.mode = 'draws'; end
    assert(ismember(opt.mode, {'draws','median','both'}), 'ccdgv_digest_cmp:mode', ...
        'opt.mode must be draws, median or both -- got "%s"', char(opt.mode));

    if (ischar(A) || isstring(A)) && isfolder(A); A = ccdgv_digest(char(A), struct('quiet',true)); end
    if (ischar(B) || isstring(B)) && isfolder(B); B = ccdgv_digest(char(B), struct('quiet',true)); end

    na = {A.run};  nb = {B.run};
    out.onlyA = setdiff(na, nb);
    out.onlyB = setdiff(nb, na);
    shared    = intersect(na, nb);
    out.diffs = cell(0, 6);

    for s = shared(:)'
        a = A(strcmp(na, s{1}));
        b = B(strcmp(nb, s{1}));
        for f = union(fieldnames(a), fieldnames(b))'
            if any(strcmp(f{1}, {'run','file'})); continue; end
            out.diffs = [out.diffs; local_cmp(s{1}, f{1}, ...
                local_fld(a,f{1}), local_fld(b,f{1}), opt.tol, opt.mode)];
        end
    end

    out.equal = isempty(out.diffs) && isempty(out.onlyA) && isempty(out.onlyB);

    if ~opt.quiet
        fprintf('\n=== digest comparison ===\n');
        fprintf('  %d run(s) in common', numel(shared));
        if ~isempty(out.onlyA); fprintf(', %d only in A', numel(out.onlyA)); end
        if ~isempty(out.onlyB); fprintf(', %d only in B', numel(out.onlyB)); end
        fprintf('\n');
        for k = 1:numel(out.onlyA); fprintf('  ONLY IN A: %s\n', out.onlyA{k}); end
        for k = 1:numel(out.onlyB); fprintf('  ONLY IN B: %s\n', out.onlyB{k}); end
        if isempty(out.diffs)
            fprintf('  no differences at tol %g\n', opt.tol);
        else
            fprintf('  %d difference(s):\n', size(out.diffs,1));
            w = min(size(out.diffs,1), 40);
            for k = 1:w
                d = out.diffs(k,:);
                fprintf('    %-34s %-22s %-12s %s\n', d{1}, d{2}, d{3}, d{6});
            end
            if size(out.diffs,1) > w
                fprintf('    ... and %d more\n', size(out.diffs,1)-w);
            end
        end
        if out.equal; fprintf('  GATE PASS\n'); else; fprintf('  GATE FAIL\n'); end
    end
end

function rows = local_cmp(run, path, a, b, tol, mode)
    rows = cell(0,6);
    if isempty(a) && isempty(b); return; end
    if xor(isempty(a), isempty(b))
        rows = {run, path, 'presence', a, b, local_say(isempty(a))};
        return
    end
    % One side 'absent' and the other populated: report an absence.
    aAbs = ischar(a) && strcmp(a, 'absent');
    bAbs = ischar(b) && strcmp(b, 'absent');
    if aAbs || bAbs
        if aAbs && bAbs; return; end
        rows = {run, path, 'absence', a, b, local_say(aAbs)};
        return
    end
    if ischar(a) || ischar(b)
        if ~isequal(a, b)
            rows = {run, path, 'text', a, b, sprintf('%s vs %s', ...
                    local_brief(a), local_brief(b))};
        end
        return
    end
    if isstruct(a) && isstruct(b)
        % A numeric summary, or a nested struct.
        if isfield(a,'kind') && isfield(b,'kind') && strcmp(a.kind,'numeric') && strcmp(b.kind,'numeric')
            if ~isequal(a.size, b.size)
                rows = {run, path, 'SHAPE', a.size, b.size, ...
                        sprintf('%s vs %s', mat2str(a.size), mat2str(b.size))};
                return      % no element-wise comparison across shapes
            end
            for q = local_fields(mode)
                if ~isfield(a, q{1}) || ~isfield(b, q{1}); continue; end
                rows = [rows; local_scalarcmp(run, [path '.' q{1}], ...
                        a.(q{1}), b.(q{1}), tol)];
            end
            return
        end
        for f = union(fieldnames(a), fieldnames(b))'
            if strcmp(f{1},'kind'); continue; end
            rows = [rows; local_cmp(run, [path '.' f{1}], ...
                    local_fld(a,f{1}), local_fld(b,f{1}), tol, mode)];
        end
        return
    end
    rows = local_scalarcmp(run, path, a, b, tol);
end

function rows = local_scalarcmp(run, path, a, b, tol)
    rows = cell(0,6);
    if ~isnumeric(a) || ~isnumeric(b)
        if ~isequal(a,b); rows = {run, path, 'value', a, b, 'differs'}; end
        return
    end
    if ~isequal(size(a), size(b))
        rows = {run, path, 'SHAPE', size(a), size(b), ...
                sprintf('%s vs %s', mat2str(size(a)), mat2str(size(b)))};
        return
    end
    both = isfinite(a) & isfinite(b);
    if any(isfinite(a(:)) ~= isfinite(b(:)))
        rows = {run, path, 'NaN-pattern', a, b, ...
                sprintf('%d cell(s) finite in one only', ...
                        sum(isfinite(a(:)) ~= isfinite(b(:))))};
        return
    end
    if ~any(both(:)); return; end
    d = abs(a(both) - b(both));
    if max(d) <= tol; return; end
    scale = max(max(abs(a(both))), max(abs(b(both))));
    rel   = max(d) / max(scale, realmin);
    rows  = {run, path, 'numeric', a, b, ...
             sprintf('max|d| %.3e  rel %.3e', max(d), rel)};
end

function v = local_fld(s, f)
    if isstruct(s) && isfield(s, f); v = s.(f); else; v = []; end
end

function t = local_say(aEmpty)
    if aEmpty; t = 'absent in A'; else; t = 'absent in B'; end
end

function s = local_brief(v)
% A short label for a value in a diff row.
    if ischar(v);        s = v;
    elseif isstring(v);  s = char(v);
    elseif isnumeric(v) && isscalar(v); s = num2str(v);
    elseif isstruct(v);  s = sprintf('struct(%s)', strjoin(fieldnames(v)', ','));
    elseif isempty(v);   s = '[]';
    else;                s = class(v);
    end
end

function q = local_fields(mode)
% The summary fields each mode compares.
    draws = {'nfin','nnan','ninf','sum','sumsq','min','max','spot'};
    med   = {'medsum','medmin','medmax','medspot'};
    switch char(mode)
        case 'draws';  q = draws;
        case 'median'; q = [{'nfin','nnan','ninf'}, med];
        case 'both';   q = [draws, med];
    end
end
