function check_specs(cfg, S)
%CHECK_SPECS  Check that each key's VAR holds the variables its name implies.
%
%   check_specs(cfg, S)
%
%   cfg  settings struct; run files are read from cfg.resultdir.
%   S    run descriptors from sweep, keyed by specification.
%
%   A variable is in the VAR when its projection r2 is 1. Errors on a mismatch.

    %   key       not in the VAR      in the VAR
    WANT = { ...
      'base',   {},                 {'ner'}
      'nofx',   {'ner'},            {}
      'eq',     {},                 {'ner','eq_us','eq_g6'}
      'eqnofx', {'ner'},            {'eq_us','eq_g6'}
      'by',     {},                 {'ner','by_us','by_g6'}
      'bynofx', {'ner'},            {'by_us','by_g6'}
      'tb',     {},                 {'ner','tb_g6'}
      'forTFP', {},                 {'ner','solow_g6'}
    };
    % Specifications with no descriptor or no run file are skipped and reported.
    checked = 0;  skipped = {};
    for k = 1:size(WANT,1)
        key = WANT{k,1};
        if ~isfield(S, key)
            skipped{end+1} = sprintf('%s (not in sweep_infos)', key);  %#ok<AGROW>
            continue
        end
        [~, nm] = data_name(S.(key));
        [~, stem, ext] = fileparts(nm);
        f = fullfile(cfg.resultdir, [stem ext]);
        if ~isfile(f)
            skipped{end+1} = sprintf('%s (no run file)', key);  %#ok<AGROW>
            continue
        end
        checked = checked + 1;
        D = load(f, 'keys', 'r2');
        invar = D.keys(abs(D.r2 - 1) < 1e-8);
        absent  = setdiff(WANT{k,3}, invar);
        present = intersect(WANT{k,2}, invar);
        assert(isempty(absent) && isempty(present), 'sweep:specMismatch', ...
            ['specification "%s" is not what its name says.\n' ...
             '  missing from its VAR : %s\n' ...
             '  present but should not be: %s\n' ...
             'Its VAR holds: %s\n' ...
             'Check the inclvar paired with "%s" in the SPECS table.'], ...
            key, local_or(absent), local_or(present), strjoin(invar', ' '), key);
    end
    if isempty(skipped)
        fprintf('  spec check: all %d named VARs hold what their keys say.\n', checked);
    else
        fprintf(['  spec check: %d of %d named VARs hold what their keys say; ' ...
                 '%d not checked (%s).\n'], checked, size(WANT,1), numel(skipped), ...
                strjoin(skipped, ', '));
    end
end

function s = local_or(c)
    if isempty(c); s = '(none)'; else; s = strjoin(c, ', '); end
end
