function check_specs(cfg, S)
%CHECK_SPECS  Each key's VAR must contain what the key says it does.
%
%   The exhibits select runs by key -- genfig_R23(base, S.bynofx, ...) -- so a
%   key paired with the wrong inclvar draws the wrong specification under the
%   right label, which looks like a result rather than a mistake. A VAR variable
%   is reproduced exactly by its own projection, so r2 == 1 identifies it.
    WANT = { ...
      'base',   {},                 {'ner'}
      'nofx',   {'ner'},            {}
      'eq',     {},                 {'ner','eq_us','eq_g6'}
      'eqnofx', {'ner'},            {'eq_us','eq_g6'}
      'by',     {},                 {'ner','by_us','by_g6'}
      'bynofx', {'ner'},            {'by_us','by_g6'}
      'tb',     {},                 {'ner','tb_g6'}
      'forTFP', {},                 {'ner','solow_g6'}
    };
    % A SKIPPED SPEC IS NOT A PASSING SPEC. Both continues below are legitimate --
    % a partial sweep has not produced every run -- but the count at the end used
    % to claim all of them had been checked, which is the one thing a checker must
    % never say. Skips are tallied and named instead.
    checked = 0;  skipped = {};
    for k = 1:size(WANT,1)
        key = WANT{k,1};
        if ~isfield(S, key)
            skipped{end+1} = sprintf('%s (not in sweep_infos)', key);  %#ok<AGROW>
            continue
        end
        [~, nm] = data_name(S.(key));
        [~, stem, ext] = fileparts(nm);
        f = fullfile(cfg.resultdir, [stem ext]);
        if ~isfile(f)
            skipped{end+1} = sprintf('%s (no run file)', key);  %#ok<AGROW>
            continue
        end
        checked = checked + 1;
        D = load(f, 'keys', 'r2');
        invar = D.keys(abs(D.r2 - 1) < 1e-8);
        absent  = setdiff(WANT{k,3}, invar);
        present = intersect(WANT{k,2}, invar);
        assert(isempty(absent) && isempty(present), 'sweep:specMismatch', ...
            ['specification "%s" is not what its name says.\n' ...
             '  missing from its VAR : %s\n' ...
             '  present but should not be: %s\n' ...
             'Its VAR holds: %s\n' ...
             'Check the inclvar paired with "%s" in the SPECS table.'], ...
            key, local_or(absent), local_or(present), strjoin(invar', ' '), key);
    end
    if isempty(skipped)
        fprintf('  spec check: all %d named VARs hold what their keys say.\n', checked);
    else
        fprintf(['  spec check: %d of %d named VARs hold what their keys say; ' ...
                 '%d not checked (%s).\n'], checked, size(WANT,1), numel(skipped), ...
                strjoin(skipped, ', '));
    end
end

function s = local_or(c)
    if isempty(c); s = '(none)'; else; s = strjoin(c, ', '); end
end
