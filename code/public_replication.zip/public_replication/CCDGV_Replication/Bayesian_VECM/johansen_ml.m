function [alpha, beta, Sig] = johansen_ml(D, r)
% Johansen ML estimates for rank r with beta = [I_r; B] normalisation, and residual covariance.
p = D.p;
if r == 0
    beta = zeros(p, 0); alpha = zeros(p, 0);
else
    b = D.V(:, 1:r);
    beta = b/b(1:r, :);
    alpha = (D.XY'*beta)/(beta'*D.XX*beta);
end
Pi = alpha*beta';
Sig = (D.YY - Pi*D.XY - D.XY'*Pi' + Pi*D.XX*Pi')/D.T;
end
