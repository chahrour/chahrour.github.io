function D = rmatnorm(mu, U, V)
% vec D ~ N(vec mu, V (x) U):  rows-covariance U (m x m), columns-covariance V (s x s).
[m, s] = size(mu);
D = mu + chol(U, 'lower')*randn(m, s)*chol(V, 'lower')';
end
