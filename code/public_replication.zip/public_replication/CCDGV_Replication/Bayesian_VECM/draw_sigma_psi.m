function [Sigma, Psi] = draw_sigma_psi(R, alpha, B)
% Exact draw of (Sigma, Psi) given (alpha, B):  Sigma ~ IW(A + v ab'ba' + W'M_Z W, T-d+q+r),
% Psi | Sigma ~ N_{d x p}(Psihat, Sigma, (Z'Z)^{-1})   (from (A.5) after integrating Psi analytically).
D = R.D; r = R.r;
beta = [eye(r); B];
Pi = alpha*beta';
WW = D.YY - Pi*D.XY - D.XY'*Pi' + Pi*D.XX*Pi';
S = R.A + R.v*(alpha*(beta'*beta)*alpha') + WW;
Sigma = rinvwishart(S, R.T - R.d + R.q + r);
if R.d > 0
    Psihat = D.ZZinv*(D.ZY - D.ZX*Pi');
    Psi = rmatnorm(Psihat, D.ZZinv, Sigma);
else
    Psi = zeros(0, R.p);
end
end
