function D = rmatt_f(mu, LU, FQ, g)
% Draw from t_{m x s}(mu, U, Q, g) given factors LU*LU' = U and FQ*FQ' = Q:
%   W ~ IW_s(Q, g+s-1) = G'G,   D = mu + LU * N * G,  N ~ N(0, I_{m x s}).
[m, s] = size(mu);
[~, G] = rinvwishart_f(FQ, g + s - 1);
D = mu + LU*randn(m, s)*G;
end
