function [Ad, Bd] = gibbs_marginal(R, n_draws, n_burn, alpha0, B0)
% Marginal (collapsed) two-block Gibbs sampler for (alpha, B) -- Theorem 4.6.
% Ad : p x r x n_draws,  Bd : (p-r) x r x n_draws
p = R.p; r = R.r;
if nargin < 4 || isempty(alpha0)
    [alpha0, beta0] = johansen_ml(R.D, r);
    B0 = beta0(r+1:end, :);
end
alpha = alpha0; B = B0;
Ad = zeros(p, r, n_draws); Bd = zeros(p - r, r, n_draws);
for it = 1:n_burn + n_draws
    beta = [eye(r); B];
    [ahat, ~, ~, g, LSa, FK] = alpha_given_beta(R, beta);
    alpha = rmatt_f(ahat, LSa, FK, g);
    [Bhat, ~, ~, g, LUB, LC3] = B_given_alpha(R, alpha);
    B = rmatt_f(Bhat, LUB, LC3, g);
    if it > n_burn
        Ad(:, :, it - n_burn) = alpha; Bd(:, :, it - n_burn) = B;
    end
end
end
