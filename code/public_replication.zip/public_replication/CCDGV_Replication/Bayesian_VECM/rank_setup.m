function R = rank_setup(D, r, A, q, v)
% Pre-computations for the posterior given rank r under prior (3.1) with hyperparameters (A, q, v).
p = D.p;
R = struct('D', D, 'r', r, 'A', A, 'q', q, 'v', v, 'p', p, 'T', D.T, 'd', D.d);
R.C1 = D.XX + v*eye(p);
R.C1inv = inv(R.C1);  R.C1inv = (R.C1inv + R.C1inv')/2;
R.N = A + D.YY;                          % A + Y' M_Z Y
R.Pihat = D.XY'*R.C1inv;                 % Y' M_Z X C1^{-1}
R.Sres = R.N - R.Pihat*R.C1*R.Pihat';     % "S" of Theorem 4.6
R.Sres = (R.Sres + R.Sres')/2;
R.LS = chol(R.Sres, 'lower');            % S = LS LS'
R.Pt = R.LS \ R.Pihat;                   % LS^{-1} Pihat
R.nu0 = D.T + q - D.d;                   % T + q - d
R.C2 = R.C1 - D.XY*(R.N\D.XY');          % C2 of Theorem 4.3
R.LC1inv = chol(R.C1inv, 'lower');
end
