function J = draw_joint(R, draws, n)
% n draws from the joint posterior p(alpha, beta, Gamma_1..k-1, Sigma | D, r) for any rank r:
%   0 < r < p : (alpha, B) from the marginal Gibbs output (thinned), then (Sigma, Psi) exactly;
%   r = p     : Pi' ~ t_{p x p}(Pihat', C1^{-1}, Sres, T+q-d-p+1) directly, then (Sigma, Psi);
%   r = 0     : Pi = 0.
p = R.p; r = R.r; D = R.D;
J = struct('alpha', cell(n, 1), 'beta', [], 'Gammas', [], 'Sigma', [], 'Psi', []);
if r > 0 && r < p
    m = size(draws.alpha, 3);
    idx = round(linspace(1, m, n));
end
for i = 1:n
    if r == 0
        alpha = zeros(p, 0); beta = zeros(p, 0); B = zeros(p, 0);
    elseif r == p
        Pi = rmatt_f(R.Pihat', R.LC1inv, R.LS, R.nu0 - p + 1)';
        alpha = Pi; beta = eye(p); B = zeros(0, p);
    else
        alpha = draws.alpha(:, :, idx(i)); B = draws.B(:, :, idx(i)); beta = [eye(r); B];
    end
    [Sigma, Psi] = draw_sigma_psi(R, alpha, B);
    J(i).alpha = alpha; J(i).beta = beta; J(i).Sigma = Sigma; J(i).Psi = Psi;
    J(i).Gammas = split_psi(Psi, p, D.k);
end
end
