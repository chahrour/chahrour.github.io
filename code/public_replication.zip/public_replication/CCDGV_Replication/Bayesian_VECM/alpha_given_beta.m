function [ahat, Sa, Kinv, g, LSa, FK] = alpha_given_beta(R, beta)
% Theorem 4.6(i):  alpha | beta, D, r ~ t_{p x r}(ahat, Sa, (beta' C1 beta)^{-1}, T+q-(d+p)+1)
% Factor-based: K = LK LK', H = LK^{-1} beta' X'M_Z Y,  ahat = (LK^{-T} H)',  Sa = N - H'H,
% FK = LK^{-T} so that FK FK' = K^{-1}.
K = beta'*R.C1*beta;  K = (K + K')/2;
LK = chol(K, 'lower');
H = LK \ (beta'*R.D.XY);                  % r x p
ahat = (LK' \ H)';
Sa = R.N - H'*H;  Sa = (Sa + Sa')/2;
LSa = chol(Sa, 'lower');
FK = LK' \ eye(size(K, 1));
Kinv = FK*FK';
g = R.nu0 - R.p + 1;
end
