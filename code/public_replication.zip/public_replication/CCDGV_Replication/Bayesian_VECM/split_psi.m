function Gammas = split_psi(Psi, p, k)
% Psi (d x p) -> cell of Gamma_i (p x p), i = 1..k-1  (Psi rows are stacked Gamma_i')
Gammas = cell(1, k - 1);
for i = 1:k-1
    Gammas{i} = Psi((i-1)*p+1:i*p, :)';
end
end
