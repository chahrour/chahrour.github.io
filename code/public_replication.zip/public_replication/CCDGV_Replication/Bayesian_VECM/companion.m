function F = companion(alpha, beta, Gammas)
% Companion matrix of the levels VAR(k) implied by the VECM (Section 3.2).
p = size(alpha, 1); k = numel(Gammas) + 1;
Pi = alpha*beta';
G = [{zeros(p)}, Gammas, {zeros(p)}];       % G{1}=0, G{i+1}=Gamma_i, G{k+1}=0
Ai = cell(1, k);
for i = 1:k
    Ai{i} = G{i+1} - G{i};
end
Ai{1} = Ai{1} + eye(p) + Pi;
F = [Ai{:}];
if k > 1
    F = [F; eye(p*(k-1)), zeros(p*(k-1), p)];
end
end
