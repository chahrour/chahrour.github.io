function S = rinvwishart(A, q)
% IW_m(A, q): density |S|^{-(m+q+1)/2} etr(-1/2 S^{-1} A), E[S] = A/(q-m-1).
S = rinvwishart_f(chol((A + A')/2, 'lower'), q);
end
