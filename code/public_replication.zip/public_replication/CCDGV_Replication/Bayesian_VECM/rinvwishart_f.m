function [S, G] = rinvwishart_f(LA, q)
% IW_m(A, q) draw given a factor LA with LA*LA' = A (any square root), without inverting A.
% W = C Z Z' C' ~ Wishart(A^{-1}, q) with C = LA^{-T} and Z the Bartlett factor, so
% S = W^{-1} = LA Z^{-T} Z^{-1} LA' = G'G with G = Z \ LA'.  Returns S and the factor G (S = G'G).
m = size(LA, 1);
Z = zeros(m);
Z(1:m+1:end) = sqrt(chi2rnd(q - (0:m-1)));
idx = tril(true(m), -1);
Z(idx) = randn(nnz(idx), 1);
G = Z \ LA';
S = G'*G;
end
