# Provenance

Villani (2005) Bayesian VECM library, copied 2026-09-16 from
`~/Dropbox/Bayesian_VECM/matlab/`, used by `est_method = 6`
(`Auxiliary_Functions/ccdgv_bvecm.m`).

**Only the files that path needs are kept, unmodified:** `vecm_data`,
`johansen_ml`, `rank_setup`, `gibbs_marginal`, `alpha_given_beta`,
`B_given_alpha`, `draw_joint`, `draw_sigma_psi`, `split_psi`, `companion`,
`rmatt_f`, `rmatnorm`, `rinvwishart`, `rinvwishart_f`, plus `simulate_vecm`
for the verification script, which stayed in the research tree.

Left in Dropbox: the rank posterior and marginal likelihoods (`rank_posterior`,
Chib, closed form, importance sampling), BMA, IRF helpers, the Monte Carlo
(`run_mc`, `report_mc`, results), `test_bvecm`, and the original README and
HANDOFF notes -- none of which ship here.
Specs declare the rank, so none of that is used.

The original HANDOFF note is wrong about the Minnesota dummy prior: T must
become T + m. The correction is implemented in `ccdgv_bvecm_minn.m`; the note and
the hyperparameter write-up it refers to are in the research tree, not here.
