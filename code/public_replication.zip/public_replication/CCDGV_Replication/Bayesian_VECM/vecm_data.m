function D = vecm_data(x, k, det)
% Build Y = dx_t, X = x_{t-1}, Z = (dx_{t-1},...,dx_{t-k+1}, d_t) of Villani (2005, eq. 2.3)
% and the moment matrices with Z partialled out.
%   x   : T0 x p levels,  k : VAR lag length (k-1 lagged differences),  det : 'none' | 'const'
if nargin < 3, det = 'none'; end
[T0, p] = size(x);
dx = diff(x);
Y = dx(k:end, :);
X = x(k:T0-1, :);
T = size(Y, 1);
Z = zeros(T, 0);
for i = 1:k-1
    Z = [Z, dx(k-i:end-i, :)]; %#ok<AGROW>
end
if strcmp(det, 'const'), Z = [Z, ones(T, 1)]; end
d = size(Z, 2);
D = struct('Y', Y, 'X', X, 'Z', Z, 'T', T, 'p', p, 'k', k, 'd', d, 'det', det);
if d > 0
    D.ZZ = Z'*Z; D.ZZinv = inv(D.ZZ); D.ZY = Z'*Y; D.ZX = Z'*X;
    My = Y - Z*(D.ZZinv*D.ZY);  Mx = X - Z*(D.ZZinv*D.ZX);
else
    D.ZZ = []; D.ZZinv = []; D.ZY = zeros(0, p); D.ZX = zeros(0, p);
    My = Y; Mx = X;
end
D.YY = My'*My;    % Y' M_Z Y
D.XX = Mx'*Mx;    % X' M_Z X
D.XY = Mx'*My;    % X' M_Z Y
% Johansen reduced rank regression (eigenvalues descending)
S00 = D.YY/T; S11 = D.XX/T; S01 = D.XY'/T; S10 = S01';
L11 = chol(S11, 'lower'); Li = inv(L11);
M = Li*S10*(S00\S01)*Li';
[V, lam] = eig((M + M')/2, 'vector');
[lam, ord] = sort(lam, 'descend');
V = Li'*V(:, ord);                 % normalised so V' S11 V = I
D.lam = lam; D.V = V;
end
