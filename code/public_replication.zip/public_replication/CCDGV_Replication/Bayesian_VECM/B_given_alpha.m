function [Bhat, UB, C3, g, LUB, LC3] = B_given_alpha(R, alpha)
% Theorem 4.6(ii):  B | alpha, D, r ~ t_{(p-r) x r}(Bhat, G3 - G2' G1^{-1} G2, C3, T+q+r-(d+p)+1)
% Numerically robust version (alpha may be nearly rank deficient => M = alpha'S^{-1}alpha nearly singular):
%   At = LS^{-1} alpha = Qa Ra,   M = Ra'Ra,   bhat = Pt' Qa Ra^{-T},
%   R  = C1^{-1} + E'E,  E = (I - Qa Qa') Pt          (= C1^{-1} + Pihat'S^{-1}Pihat - bhat M bhat')
%   chol(R) = [L11 0; L21 L22]  =>  G3 - G2'G1^{-1}G2 = L22 L22',   w = L11^{-1} u,
%   Bhat = bhat_2 + L21 w,   C3 = w'w + M^{-1} = F'F with F = [w; Ra^{-T}].
p = R.p; r = R.r;
At = R.LS \ alpha;
[Qa, Ra] = qr(At, 0);
E = R.Pt - Qa*(Qa'*R.Pt);
Rm = R.C1inv + E'*E;  Rm = (Rm + Rm')/2;
LR = chol(Rm, 'lower');
L11 = LR(1:r, 1:r); L21 = LR(r+1:p, 1:r); L22 = LR(r+1:p, r+1:p);
bhat = (R.Pt'*Qa)/Ra';                      % p x r
u = eye(r) - bhat(1:r, :);
w = L11 \ u;
Bhat = bhat(r+1:p, :) + L21*w;
V = Ra' \ eye(r);                           % V'V = M^{-1}
F = [w; V];
[~, Rc] = qr(F, 0);
LC3 = Rc';                                  % C3 = LC3 LC3'
LUB = L22;
UB = L22*L22';
C3 = Rc'*Rc;
g = R.nu0 + r - p + 1;
end
