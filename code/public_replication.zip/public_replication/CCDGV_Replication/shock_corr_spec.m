function R = shock_corr_spec(ref, alt, opt)
%SHOCK_CORR_SPEC  Correlation of the CJ disturbances between two specifications.
%
%   R = SHOCK_CORR_SPEC(ref_info, alt_info)
%   R = SHOCK_CORR_SPEC(S.base, S.eq)       two of sweep()'s descriptors
%   R = SHOCK_CORR_SPEC(ref, alt, opt)
%
%   opt.echo       print the result (default true)
%   opt.ref_label  override the printed name of each side. Without these the
%   opt.alt_label  label is derived from inclvar, which cannot distinguish the
%                  two no-FX objects -- both are built from the baseline run.
%   opt.infer_ref  options passed to INFER_SHOCKS for the reference run
%   opt.infer_alt  ditto for the alternative. Use
%                    struct('restricted',true,'nofx_info',I.nofx)
%                  -- WITH ref AS THE BASELINE -- to compare against the paper's
%                  no-FX object rather than a re-estimated inclvar=2 run. They
%                  are different objects; see NOFX_RESTRICTED.
%
%   R.rho_tfp / R.rho_noise    correlations, with R.p_tfp / R.p_noise
%   R.n, R.t0, R.t1            overlap length and first/last shared quarter
%   R.n_ref, R.n_alt           each run's own length, so a short overlap shows
%   R.ref, R.alt               the two files the numbers came from
%
%   TAKES INFOS, like GENFIG_B11 and GENFIG_B12: paths come from data_name, so
%   changing a spec in sweep propagates with nothing to retype. A char
%   argument must be a scalar info struct from sweep(),
%   which is what makes this usable by hand between sweeps.
%
%   BUILT ON INFER_SHOCKS, not on the older filter_shocks: infer_shocks resolves
%   the two MA rows BY NAME through var_order, reads j_cj_horizon from the run's
%   own info.settings instead of assuming 20, and returns dates aligned to the
%   series. Under the equity layouts every row from E[TFP] onward shifts by +2,
%   so a positional selection is wrong there and silently so.
%
%   ALIGNED ON SHARED DATES, not by position. sweep pins each spec's start to
%   what its own data supported and the specs can lose different numbers of rows
%   to the VAR-column NaN mask, so the two shock vectors need not cover the same
%   quarters. Correlating them positionally would compare different dates and
%   report a number that looks fine. Same intersect idiom as GENFIG_B11.
%
%   See also INFER_SHOCKS, GENFIG_B11, SWEEP.

    if nargin < 3; opt = struct(); end
    if ~isfield(opt,'echo'); opt.echo = true; end

    [ref_info, ref_lab] = resolve(ref);
    [alt_info, alt_lab] = resolve(alt);
    ref_lab = getfielddef(opt,'ref_label',ref_lab);
    alt_lab = getfielddef(opt,'alt_label',alt_lab);

    o_ref = getfielddef(opt,'infer_ref',struct());
    o_alt = getfielddef(opt,'infer_alt',struct());

    A = infer_shocks(ref_info, o_ref);
    B = infer_shocks(alt_info, o_alt);

    % Quarterly fractional years. Round to the quarter before matching so that
    % 1/4-step floating point cannot drop a quarter the two runs share.
    [d, ia, ib] = intersect(round(A.dates*4)/4, round(B.dates*4)/4);
    assert(numel(d) > 8, 'shock_corr_spec:noOverlap', ...
        '%s and %s share only %d quarters', ref_lab, alt_lab, numel(d));

    [rt, pt] = pearson(A.ehat_tfp(ia),   B.ehat_tfp(ib));
    [rn, pn] = pearson(A.ehat_noise(ia), B.ehat_noise(ib));

    R = struct('ref_label',ref_lab, 'alt_label',alt_lab, ...
               'rho_tfp',rt, 'p_tfp',pt, 'rho_noise',rn, 'p_noise',pn, ...
               'n',numel(d), 't0',d(1), 't1',d(end), ...
               'n_ref',numel(A.dates), 'n_alt',numel(B.dates), ...
               'ref',A.meta.file, 'alt',B.meta.file, ...
               'system_ref',A.meta.system, 'system_alt',B.meta.system);

    if opt.echo
        fprintf('  %-28s tech %+0.3f (p %.3f)  noise %+0.3f (p %.3f)  %s-%s, n=%d\n', ...
                alt_lab, rt, pt, rn, pn, qlabel(R.t0), qlabel(R.t1), R.n);
        if R.n < R.n_ref || R.n < R.n_alt
            fprintf('    %-26s overlap %d of %d (%s) / %d (%s)\n', '', ...
                    R.n, R.n_ref, ref_lab, R.n_alt, alt_lab);
        end
    end
end

% -------------------------------------------------------------------------
function [I, lab] = resolve(x)
% An info struct passes through; a char is a sweep_infos field name. Cell
% entries (the by-country runs) are rejected rather than silently taking one.
    if isstruct(x)
        assert(isscalar(x), 'shock_corr_spec:notScalar', ...
               'got a %d-element info array -- name a single spec', numel(x));
        I = x;  lab = spec_label(I);
        return
    end
    error('shock_corr_spec:badArg', ...
        ['expected a scalar info struct, got %s. Pass one of sweep()''s ' ...
         'descriptors directly, e.g. S.base.'], class(x));
end

function s = spec_label(I)
    s = sprintf('vars%d', I.inclvar);
    if isfield(I,'country') && ~strcmp(I.country,'G6'); s = [I.country '/' s]; end
end

function [r, p] = pearson(x, y)
% corrcoef, not corr: base MATLAB, no Statistics Toolbox, and it returns the
% p-value too. Both are column vectors of equal length by construction here.
    [Rm, Pm] = corrcoef(x, y);
    r = Rm(1,2);  p = Pm(1,2);
end

function s = qlabel(d)
    y = floor(d + 1e-8);
    q = round((d - y)*4) + 1;
    s = sprintf('%dQ%d', y, q);
end

function v = getfielddef(S, f, d)
    if isfield(S,f) && ~isempty(S.(f)); v = S.(f); else; v = d; end
end
