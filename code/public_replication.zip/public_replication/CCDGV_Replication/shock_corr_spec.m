function R = shock_corr_spec(ref, alt, opt)
%SHOCK_CORR_SPEC  Correlation of the technology and noise disturbances between two runs.
%
%   R = SHOCK_CORR_SPEC(ref, alt)
%   R = SHOCK_CORR_SPEC(ref, alt, opt)
%
%   ref, alt       scalar run descriptors from sweep(), e.g. S.base and S.eq
%   opt.echo       print the result (default true)
%   opt.ref_label  printed name of each side (default: built from inclvar and
%   opt.alt_label  country)
%   opt.infer_ref  options passed to INFER_SHOCKS for the reference run
%   opt.infer_alt  the same for the alternative. With the baseline as both ref
%                  and alt, struct('restricted',true,'nofx_info',S.nofx)
%                  compares against the implied no-FX system (NOFX_RESTRICTED).
%
%   R.rho_tfp / R.rho_noise      correlations, with R.p_tfp / R.p_noise
%   R.n, R.t0, R.t1              overlap length and first/last shared quarter
%   R.n_ref, R.n_alt             each run's own length
%   R.ref, R.alt                 the two run files
%   R.system_ref, R.system_alt   which system each side used
%
%   The two shock series are matched on shared dates, because specifications
%   can cover different quarters.
%
%   See also INFER_SHOCKS, GENFIG_C11, SWEEP.

    if nargin < 3; opt = struct(); end
    if ~isfield(opt,'echo'); opt.echo = true; end

    % Labels and infer_shocks options for each side.
    [ref_info, ref_lab] = resolve(ref);
    [alt_info, alt_lab] = resolve(alt);
    ref_lab = getfielddef(opt,'ref_label',ref_lab);
    alt_lab = getfielddef(opt,'alt_label',alt_lab);

    o_ref = getfielddef(opt,'infer_ref',struct());
    o_alt = getfielddef(opt,'infer_alt',struct());

    % Recover the disturbances of both runs.
    A = infer_shocks(ref_info, o_ref);
    B = infer_shocks(alt_info, o_alt);

    % Match on dates rounded to the quarter.
    [d, ia, ib] = intersect(round(A.dates*4)/4, round(B.dates*4)/4);
    assert(numel(d) > 8, 'shock_corr_spec:noOverlap', ...
        '%s and %s share only %d quarters', ref_lab, alt_lab, numel(d));

    % Correlations over the shared quarters.
    [rt, pt] = pearson(A.ehat_tfp(ia),   B.ehat_tfp(ib));
    [rn, pn] = pearson(A.ehat_noise(ia), B.ehat_noise(ib));

    R = struct('ref_label',ref_lab, 'alt_label',alt_lab, ...
               'rho_tfp',rt, 'p_tfp',pt, 'rho_noise',rn, 'p_noise',pn, ...
               'n',numel(d), 't0',d(1), 't1',d(end), ...
               'n_ref',numel(A.dates), 'n_alt',numel(B.dates), ...
               'ref',A.meta.file, 'alt',B.meta.file, ...
               'system_ref',A.meta.system, 'system_alt',B.meta.system);

    if opt.echo
        fprintf('  %-28s tech %+0.3f (p %.3f)  noise %+0.3f (p %.3f)  %s-%s, n=%d\n', ...
                alt_lab, rt, pt, rn, pn, qlabel(R.t0), qlabel(R.t1), R.n);
        if R.n < R.n_ref || R.n < R.n_alt
            fprintf('    %-26s overlap %d of %d (%s) / %d (%s)\n', '', ...
                    R.n, R.n_ref, ref_lab, R.n_alt, alt_lab);
        end
    end
end

function [I, lab] = resolve(x)
% Accept a scalar info struct and return it with its label.
    if isstruct(x)
        assert(isscalar(x), 'shock_corr_spec:notScalar', ...
               'got a %d-element info array -- name a single spec', numel(x));
        I = x;  lab = spec_label(I);
        return
    end
    error('shock_corr_spec:badArg', ...
        ['expected a scalar info struct, got %s. Pass one of sweep()''s ' ...
         'descriptors directly, e.g. S.base.'], class(x));
end

function s = spec_label(I)
    s = sprintf('vars%d', I.inclvar);
    if isfield(I,'country') && ~strcmp(I.country,'G6'); s = [I.country '/' s]; end
end

function [r, p] = pearson(x, y)
% Pearson correlation and its p-value.
    [Rm, Pm] = corrcoef(x, y);
    r = Rm(1,2);  p = Pm(1,2);
end

function s = qlabel(d)
    y = floor(d + 1e-8);
    q = round((d - y)*4) + 1;
    s = sprintf('%dQ%d', y, q);
end

function v = getfielddef(S, f, d)
    if isfield(S,f) && ~isempty(S.(f)); v = S.(f); else; v = d; end
end
