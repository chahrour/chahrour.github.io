function cfg = id_cfg(info, k, extra)
%ID_CFG  Build genmaxshare_final's cfg for identification pass k.
%
%   cfg = ID_CFG(info, k)
%   cfg = ID_CFG(info, k, extra)   extra overrides/adds fields (e.g. want_shocks)
%
%   Merges the SHARED identification settings on info.settings with the PER-PASS
%   settings on info.ident(k). Those are the two halves of what used to be
%   id_cfg_base plus three copies of it in run_main.
%
%   WHY A HELPER RATHER THAN PASSING info STRAIGHT IN. genmaxshare_final
%   validates cfg against a whitelist and errors on an unknown field -- a check
%   that has already caught a real bug. Handed `info`, which carries dozens of
%   fields, that check would have to go. Keeping the narrow struct keeps the
%   validation; the merge is just explicit at the call site.
%
%   Aproj/keys come from the CALLER's workspace via `extra`, not from info: they
%   are already saved with the data stage and there is no reason for run_stage to
%   rewrite them into info at every stage.
%
%   See also GENMAXSHARE_FINAL, VALIDATE_INFO.

    if nargin < 3; extra = struct(); end

    assert(isfield(info,'ident'), 'id_cfg:noIdent', 'info has no ident list');
    assert(k >= 1 && k <= numel(info.ident), 'id_cfg:badIndex', ...
           'identification %d requested but info.ident has %d entries', k, numel(info.ident));

    S = info.settings;
    I = info.ident(k);

    cfg = struct( ...
        'nimp',           S.nimp, ...
        'vd_fr',          S.vd_fr, ...
        'j_cj_horizon',   S.j_cj_horizon, ...
        'bound',          S.bound, ...
        'bound2',         S.bound2, ...
        'point_estimate', S.point_estimate, ...
        'shock_extract',  I.shock_extract, ...
        'KLbar',          I.KLbar, ...
        'KUbar',          I.KUbar, ...
        'want_vardec_fd', I.want_vardec_fd, ...
        'label',          I.label);

    for f = fieldnames(extra)'
        cfg.(f{1}) = extra.(f{1});
    end
end
