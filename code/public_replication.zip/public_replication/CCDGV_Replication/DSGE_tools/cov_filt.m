function [cov_fil,cov0] = cov_filt(ma_in,max_per)

M                       = size(ma_in,1)-1;
ny                      = size(ma_in,2);
ne                      = size(ma_in,3);

%Get in FFT space in the right orientation
ma_in                   = ifftshift(ma_in(1:end-1,:,:),1);  %Put time zero at first index
ma_in                   = permute(ma_in,[2,3,1]);  %now in [nvars,nshocks,npers] form

%Fourier transform
ft_in = fft(ma_in,[],3);

cvg = zeros(ny,ny,M);
for jj = 1:M
    cvg(:,:,jj) = ft_in(:,:,jj)*ft_in(:,:,jj)';
end

%Compute unconditional covariance
cov0 = real(ifft(cvg,[],3));

%Which points to keep in computing covariances
lam_grid = 2*pi*(0:(M-1))/M;
freq_uc  = [0+2*pi/max_per, 2*pi-2*pi/max_per]  ; 
idx_drop = ~(((lam_grid >= freq_uc(1)) + (lam_grid <= freq_uc(2)))==2);

%Now filter
cvg2 = cvg;
cvg2(:,:,idx_drop) = 0;
cov_fil = real(ifft(cvg2,[],3));

end
