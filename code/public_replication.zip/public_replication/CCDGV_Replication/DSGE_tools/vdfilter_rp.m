function [Vy,Ve] = vdfilter_rp(B,C,M,lam,Ngrid)
% -------------------------------------------------------------------------
% Compute variance over frequencies lam = [lam1,lam2] when
% the target data have the VAR representation:
%       x(t) = M*(I-BL)^-1*C*e(t)
%
% Vectorized rewrite of the adaptive-integral original (kept as
% DSGE_tools/vdfilter_rp_int.m), applying to vdfilter_rp exactly the treatment
% DSGE_tools/vdfilter already had -- same log-spaced grid, same trapezoid rule,
% same sqrt-weighted single-matrix-product trick, same tf_sweep call.
%
% THE ALGEBRA. With T1(w) = M (I - B e^{-iw})^{-1} C and real B, C, M, the +w
% transfer function is the conjugate of the -w one, so the original's two
% integrands collapse onto ONE sweep:
%       gomega:  T1 * T2.'          = T1 * T1^H       -> Vy   (ny x ny)
%       gomege:  T1.' * conj(T1)    = conj(T1^H * T1)
% and since only the real part is kept, Re(conj(T1^H T1)) = Re(T1^H T1), so
%       Ve = (1/pi) * Re integral T1^H T1            (ne x ne)
% The original evaluated T1 and T2 separately in gomega and then AGAIN in
% gomege -- four dense complex solves per quadrature node, at every node of an
% adaptive rule, where one batched sweep over a fixed grid suffices.
%
% Both integrals are formed as a single matrix product over the sqrt-weighted
% grid, so there is no extra ny x ne x Ngrid intermediate beyond T1 itself:
%       Vy = (1/pi) Re (Tb  * Tb'),  Tb = sqrt(w)-weighted T1, ny x ne*Ngrid
%       Ve = (1/pi) Re (Tv' * Tv ),  Tv = the same, stacked ny*Ngrid x ne
%
% WHY THIS MATTERS HERE. maxshr:48 calls this for the IDENTIFICATION when
% shock_extract==2 (the frequency-domain max-share target behind Tables B.1 and
% B.2), once per posterior draw. It was the dominant cost of those two passes --
% 0.181 s/draw against 0.108 for the FEV target.
%
% Ve is fed to eig() in maxshr to get the rotation, so accuracy is checked on
% the resulting TABLES, not just on Ve. See verify_vdfilter_rp.
% -------------------------------------------------------------------------

% Options
if nargin < 4 || isempty(lam);   lam = [2*pi/32,2*pi/6]; end  % default 6-32 periods
if nargin < 5 || isempty(Ngrid); Ngrid = 8000; end            % grid points per band
% KEEP 8000. Dropping to 2000 was tried and reverted: measured end to end it saved
% NOTHING (498.7 s against 486.9 s, i.e. noise) while moving dataplots_AF by
% 1.2e-3 relative -- max|d| = 0.006 on a variance share printed at two decimals,
% so it can flip a digit in Table B.4. The earlier 1.4e-6 / "~6x faster" estimate
% was measured on vdfilter_rp in isolation and does not survive at run level:
% this is not the bottleneck in identification.

% Frequency grid over the band: LOG-SPACED so nodes cluster at the low-frequency
% edge, where near-unit-root spectra are sharply peaked (~1/w^2). Requires
% lam(1) > 0, true for every band used here (the widest is 2*pi/1000). Weights
% are the non-uniform trapezoid rule -- positive, so the sqrt-weighting is valid.
lamg          = logspace(log10(lam(1)),log10(lam(2)),Ngrid);
wq            = zeros(1,Ngrid);
wq(2:Ngrid-1) = (lamg(3:Ngrid)-lamg(1:Ngrid-2))/2;
wq(1)         = (lamg(2)-lamg(1))/2;
wq(Ngrid)     = (lamg(Ngrid)-lamg(Ngrid-1))/2;
sw            = reshape(sqrt(wq),1,1,Ngrid);

% T1(w) = M (I - B e^{-iw})^{-1} C over the whole band in one call
T1 = tf_sweep(M,B,C,exp(-1i*lamg));      % ny x ne x Ngrid
ny = size(T1,1);
ne = size(T1,2);
T1 = T1.*sw;                             % fold the quadrature weights in once

% Vy = (1/pi) Re sum_k w_k T1_k T1_k^H
Tb = reshape(T1, ny, ne*Ngrid);
Vy = (1/pi)*real(Tb*Tb');

% Ve = (1/pi) Re sum_k w_k T1_k^H T1_k
% permute to ny x Ngrid x ne so the reshape stacks the grid under ny, making
% column j the vectorization of T1(:,j,:); then Tv'*Tv sums over (i,k).
Tv = reshape(permute(T1,[1 3 2]), ny*Ngrid, ne);
Ve = (1/pi)*real(Tv'*Tv);

end
