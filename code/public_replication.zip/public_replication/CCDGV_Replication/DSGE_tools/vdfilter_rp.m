function [Vy,Ve] = vdfilter_rp(B,C,M,lam,Ngrid)
%VDFILTER_RP  Variance over a frequency band, by output and by shock.
%
%   [Vy, Ve] = vdfilter_rp(B, C, M, lam, Ngrid)
%
%   The target has the representation x(t) = M*(I - B L)^{-1}*C*e(t).
%
%   B, C   state transition and shock loading.
%   M      ny x nx output map.
%   lam    [lam1 lam2], the band in angular frequency (default 6-32 periods).
%          lam1 must be positive.
%   Ngrid  grid points per band (default 8000).
%
%   With T1(w) = M (I - B e^{-iw})^{-1} C,
%       Vy = (1/pi) * Re integral T1 T1^H dw      (ny x ny)
%       Ve = (1/pi) * Re integral T1^H T1 dw      (ne x ne)
%   MAXSHR takes the eigenvectors of Ve for the frequency-domain target.
%
%   See also VDFILTER, TF_SWEEP, MAXSHR.

% Defaults.
if nargin < 4 || isempty(lam);   lam = [2*pi/32,2*pi/6]; end  % default 6-32 periods
if nargin < 5 || isempty(Ngrid); Ngrid = 8000; end            % grid points per band

% Log-spaced frequency grid, which clusters nodes at the low-frequency edge
% where near-unit-root spectra are sharply peaked, with trapezoid weights.
lamg          = logspace(log10(lam(1)),log10(lam(2)),Ngrid);
wq            = zeros(1,Ngrid);
wq(2:Ngrid-1) = (lamg(3:Ngrid)-lamg(1:Ngrid-2))/2;
wq(1)         = (lamg(2)-lamg(1))/2;
wq(Ngrid)     = (lamg(Ngrid)-lamg(Ngrid-1))/2;
sw            = reshape(sqrt(wq),1,1,Ngrid);

% T1(w) = M (I - B e^{-iw})^{-1} C over the whole band.
T1 = tf_sweep(M,B,C,exp(-1i*lamg));      % ny x ne x Ngrid
ny = size(T1,1);
ne = size(T1,2);
T1 = T1.*sw;                             % fold in the quadrature weights

% Vy = (1/pi) Re sum_k w_k T1_k T1_k^H.
Tb = reshape(T1, ny, ne*Ngrid);
Vy = (1/pi)*real(Tb*Tb');

% Ve = (1/pi) Re sum_k w_k T1_k^H T1_k. Permuting to ny x Ngrid x ne makes
% column j of Tv the vectorisation of T1(:,j,:).
Tv = reshape(permute(T1,[1 3 2]), ny*Ngrid, ne);
Ve = (1/pi)*real(Tv'*Tv);

end
