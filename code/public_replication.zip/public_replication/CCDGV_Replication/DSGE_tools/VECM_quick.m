function [Bvecm,vmat,res,Bvecm_lev,vmat_lev,res_lev] = VECM_quick(y,xx,fdvar,P,Q)
%VECM_QUICK  Restricted-OLS VECM (est_method 4), the hard version of method 1.
%
%   [Bvecm,vmat,res,Bvecm_lev,vmat_lev,res_lev] = VECM_QUICK(y,xx,fdvar,P,Q)
%
%   fdvar  rows of y in first differences -- used to build the restriction
%          selector, which zeroes the lag-nlags coefficients on those variables
%   P,Q    the basis map for make_gam, from CCDGV_TRANSFORM. Optional: omitted
%          or empty gives P = I and Q = 0, i.e. no basis change.
%
%   The restriction here is the EXACT counterpart of the near-dogmatic prior
%   est_method 1 applies through unpack_info's
%       bidx(end-1-nvars+fdvar,:) = 1e-9
%   -- the same rows, driven to exactly zero rather than shrunk. That is why the
%   two coincide at the point estimate under a flat prior.
%
%   P AND Q ARE SEPARATE FROM fdvar and must be passed in. They are not
%   derivable from it: P and Q map between the estimated and levels bases, and
%   for the VECM neither is diagonal. See CCDGV_TRANSFORM.
%
%   See also CCDGV_TRANSFORM, MAKE_GAM, GENVARS.

nrhs  = size(xx,2);
nvars = size(y,2);
nlags = (nrhs-1)/nvars;

if nargin < 4 || isempty(P); P = eye(nvars);   end
if nargin < 5 || isempty(Q); Q = zeros(nvars); end

Qsel = selector(nrhs-1-nvars+fdvar,nrhs)';
c    = zeros(size(Qsel,2),nvars);

b0 = xx\y;

%Restricted OLS formula
br = b0 - ((xx'*xx)\Qsel)*((Qsel'*((xx'*xx)\Qsel))\(Qsel'*b0-c));

Bvecm = companion_form(br(1:end-1,:)');
res   = y - xx*br;       % T x nvar matrix of residuals
vmat  = cov(res);

%Put in levels var
[Bvecm_lev, P] = make_gam(br(1:end-1,:)',P,Q,nvars,nlags);
vmat_lev = (P\vmat)/P';

res_lev = (P\res')';
