function [Bvecm,vmat,res,Bvecm_lev,vmat_lev,res_lev] = VECM_quick(y,xx,fdvar,P,Q)
%VECM_QUICK  VECM by restricted OLS.
%
%   [Bvecm, vmat, res, Bvecm_lev, vmat_lev, res_lev] = VECM_quick(y, xx, fdvar, P, Q)
%
%   y, xx  left- and right-hand sides of the VAR; the constant is the last
%          column of xx.
%   fdvar  rows of y that are first differences. Their lag-nlags coefficients
%          are restricted to zero.
%   P, Q   the basis map for MAKE_GAM, from CCDGV_TRANSFORM. Defaults: P = I,
%          Q = 0.
%
%   Bvecm, vmat, res              companion matrix, residual covariance and
%                                 residuals of the estimated system.
%   Bvecm_lev, vmat_lev, res_lev  the same for the system in levels.
%
%   See also CCDGV_TRANSFORM, MAKE_GAM.

nrhs  = size(xx,2);
nvars = size(y,2);
nlags = (nrhs-1)/nvars;

if nargin < 4 || isempty(P); P = eye(nvars);   end
if nargin < 5 || isempty(Q); Q = zeros(nvars); end

% Restriction: zero coefficients on the last lag of the differenced variables.
Qsel = selector(nrhs-1-nvars+fdvar,nrhs)';
c    = zeros(size(Qsel,2),nvars);

% Unrestricted OLS.
b0 = xx\y;

% Restricted OLS.
br = b0 - ((xx'*xx)\Qsel)*((Qsel'*((xx'*xx)\Qsel))\(Qsel'*b0-c));

Bvecm = companion_form(br(1:end-1,:)');
res   = y - xx*br;       % T x nvars residuals
vmat  = cov(res);

% The system in levels.
[Bvecm_lev, P] = make_gam(br(1:end-1,:)',P,Q,nvars,nlags);
vmat_lev = (P\vmat)/P';

res_lev = (P\res')';
