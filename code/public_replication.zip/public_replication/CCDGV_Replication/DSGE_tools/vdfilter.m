function [Vy,Ve] = vdfilter(B,C,targ,lam,A,M)
% -------------------------------------------------------------------------
% Compute variance over frequencies lam = [lam1,lam2] when
% data have the VAR representation:
%       x(t) = b + B*x(t-1) + C*e(t)
%
% Vectorized rewrite of the original adaptive-integral version (kept as
% DSGE_tools/vdfilter_int.m).  The spectral density is
%       g(w) = 1/(2*pi) * T1(w) * T1(w)^H,   T1(w) = A (I - B e^{-iw})^{-1} C,
% (for real A,B,C the +/-w transfer functions are complex conjugates, so the
% original T1*T2.' equals T1*T1^H).  T1 is evaluated for the whole band in
% one tf_sweep call (Schur/eig fast path, dense fallback only at near-pole
% grid points), and the band integral is a trapezoid rule.  The integral of
% sum_k w_k T1_k T1_k^H is formed as a single (sqrt-weighted) matrix product
% Tb*Tb' -- no ny x ny x M intermediate.
%
%   Vy = 2*Re integral_lam1^lam2 g(w) dw                 (ny x ny)
%   Ve = 2*Re integral g_e(w) dw,  g_e uses C*targ'      (ny x ny)
% Reproduces vdfilter_int to ~1e-7 on the variance shares (see verify_vdfilter).
% -------------------------------------------------------------------------

% Options
if nargin < 4 || isempty(lam); lam = [2*pi/32,2*pi/6]; end  % default 6-32 periods
if nargin < 6 || isempty(M);   M = 2000; end                % grid points per band
% 2000 vs the former 8000: 1.4e-06 relative on Vy/Ve, ~6x faster. Measured
% 2026-08-05; see verify_vdfilter for the M-vs-accuracy table.

% Frequency grid over the band: LOG-SPACED so nodes cluster at the low-freq
% edge, where near-unit-root spectra are sharply peaked (~1/w^2).  Requires
% lam(1) > 0 (always true for the variance bands used here).  Non-uniform
% trapezoid weights (positive, so the sqrt-weighting trick below is valid).
lamg = logspace(log10(lam(1)),log10(lam(2)),M);
w        = zeros(1,M);
w(2:M-1) = (lamg(3:M)-lamg(1:M-2))/2;
w(1)     = (lamg(2)-lamg(1))/2;
w(M)     = (lamg(M)-lamg(M-1))/2;
sw       = reshape(sqrt(w),1,1,M);

% T1(w) = A (I - B e^{-iw})^{-1} C  on the whole grid (ny x ne x M)
T1 = tf_sweep(A,B,C,exp(-1i*lamg));
ny = size(T1,1);
ne = size(T1,2);

% Vy = (1/pi) * integral T1 T1^H = (1/pi) * Tb Tb',  Tb = sqrt(w)-weighted T1
Tb = reshape(T1.*sw, ny, ne*M);
Vy = (1/pi)*real(Tb*Tb');

% Ve: same with the target loading C*targ'  =>  T1e = T1 * targ'
T1e = pagemtimes(T1, targ.');                  % ny x 1 x M
Teb = reshape(T1e.*sw, ny, M);
Ve  = (1/pi)*real(Teb*Teb');

end
