function [Vy,Ve] = vdfilter(B,C,targ,lam,A,M)
%VDFILTER  Variance over a frequency band of a system in VAR form.
%
%   [Vy, Ve] = vdfilter(B, C, targ, lam, A, M)
%
%   The state follows x(t) = B*x(t-1) + C*e(t) and the outputs are y = A*x.
%
%   B, C  state transition and shock loading.
%   targ  1 x ne row that selects a shock: Ve uses the loading C*targ'.
%   lam   [lam1 lam2], the band in angular frequency (default 6-32 periods).
%         lam1 must be positive.
%   A     ny x nx output map.
%   M     grid points per band (default 2000).
%
%   Vy = 2*Re integral_lam1^lam2 g(w) dw                     (ny x ny)
%   Ve = the same with the loading C*targ'                   (ny x ny)
%   where g(w) = 1/(2*pi) * T1(w) * T1(w)^H and T1(w) = A (I - B e^{-iw})^{-1} C.
%
%   See also TF_SWEEP, VDFILTER_RP.

% Defaults.
if nargin < 4 || isempty(lam); lam = [2*pi/32,2*pi/6]; end  % default 6-32 periods
if nargin < 6 || isempty(M);   M = 2000; end                % grid points per band

% Log-spaced frequency grid, which clusters nodes at the low-frequency edge
% where near-unit-root spectra are sharply peaked, with trapezoid weights.
lamg = logspace(log10(lam(1)),log10(lam(2)),M);
w        = zeros(1,M);
w(2:M-1) = (lamg(3:M)-lamg(1:M-2))/2;
w(1)     = (lamg(2)-lamg(1))/2;
w(M)     = (lamg(M)-lamg(M-1))/2;
sw       = reshape(sqrt(w),1,1,M);

% T1(w) = A (I - B e^{-iw})^{-1} C on the whole grid (ny x ne x M).
T1 = tf_sweep(A,B,C,exp(-1i*lamg));
ny = size(T1,1);
ne = size(T1,2);

% Vy = (1/pi) * Tb*Tb', with Tb the sqrt(w)-weighted T1.
Tb = reshape(T1.*sw, ny, ne*M);
Vy = (1/pi)*real(Tb*Tb');

% Ve: the same with T1e = T1 * targ'.
T1e = pagemtimes(T1, targ.');                  % ny x 1 x M
Teb = reshape(T1e.*sw, ny, M);
Ve  = (1/pi)*real(Teb*Teb');

end
