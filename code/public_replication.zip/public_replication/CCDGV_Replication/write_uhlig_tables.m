function out = write_uhlig_tables(datam, opt)
%WRITE_UHLIG_TABLES  Emit Tables 1, B.1 and B.2 in the draft's own shape.
%
%   out = WRITE_UHLIG_TABLES(DATAM, OPT)
%
%   All three are the SAME forecast-error-variance decomposition of the SAME
%   posterior draws, under three max-share identification targets:
%
%     Table 1    tab: Uhlig VDs   dataplots      FEV at horizon 100
%   THE NUMBERS BELOW ARE THE EXHIBIT'S, from paper_exhibits.tex, not the
%   filename's. tabB01 is Table B.4, tabB02 is B.5; the file stems are historical
%   and renaming them would break the tex for no gain.
%
%     Table B.4  tab: Uhlig_AF    dataplots_AF   2-1000 quarter periodicities
%     Table B.5  tab: Uhlig_HF    dataplots_HF   6-32   quarter periodicities
%
%   DATAM  name of a case .mat produced by run_main (resolved through
%          sweep_datam, so SWEEP_DATAM redirects it like everything else), or a
%          struct already holding the variables.
%   OPT    .outdir   REQUIRED: the directory holding Figures/ and Tables/
%          .which    subset of {'main','AF','HF'}; default all present
%          .echo     print the rows to the console (default true)
%
%   Each table is 8 rows x 6 forecast horizons. The values are the POINT
%   ESTIMATE page of dataplots (page 1), which with point_estimate=0 is the
%   MEDIAN across draws -- so they depend on the draw count, and a reduced-draw
%   run will not reproduce the published numbers.
%
%   Rows are selected BY NAME via ccdgv_order, not by the literal order_vdec
%   saved in the .mat: those indices are correct only for the 8-variable
%   baseline layout, and the equity specifications shift everything from E[TFP]
%   onward by +2. The draft's tables list eight variables and omit the ninth
%   (Delta q_t) that order_vdec carries, so the first eight are taken.
%
%   THE NOTES NOW STATE THE TARGET. Until 2026-08-19 the provenance line silently
%   dropped it -- id_meta is keyed by the pass LABEL and this asked for its own
%   SPEC key -- so all three tables carried identical provenance despite being
%   three different identifications. See local_prov and CCDGV_ID_META.
%
%   On a 1000-draw baseline run, B.1 and B.2 reproduce
%   the published tables in 48/48 cells each; Table 1 in 47/48. The exception is
%   Foreign Consumption at Q4 -- published 0.04, ours 0.026794, which rounds to
%   0.03. That is NOT a rounding-boundary case (0.035 is the threshold, so it
%   sits 8.2e-03 below it) and it is deterministic across runs. smax cannot
%   explain it: smax never enters this table's computation path. See GAP_REPORT.

    if nargin < 2; opt = struct(); end
    if ~isfield(opt,'echo');   opt.echo = true; end
    % opt.outdir is the EXHIBIT ROOT; this function appends Tables/ itself, which
    % is the same convention every generator here uses.
    assert(isfield(opt,'outdir') && ~isempty(opt.outdir), 'write_uhlig_tables:noOutdir', ...
        'opt.outdir is required: the directory holding Figures/ and Tables/.');
    opt.outdir = fullfile(opt.outdir, 'Tables');
    if ~isfolder(opt.outdir); mkdir(opt.outdir); end

    if isstruct(datam)
        D = datam;
    else
        % datam is the path itself -- callers pass data_name(info). The old
        % sweep_datam indirection (an env var read inside the function) is gone.
        D = load(datam);
    end

    SPEC = { ...
      'main', 'dataplots',    'tab: Uhlig VDs', 'tabB_uhlig_main.tex', ...
          'Share of forecast error variance explained by the main exchange rate shock ($\varepsilon_1$)', ...
          'The table reports the variance shares accounted for by the main exchange rate shock.'
      'AF',   'dataplots_AF', 'tab: Uhlig_AF',  'tabB01_uhlig_AF.tex', ...
          'Share of forecast error variance explained by the FX shock: target 2--1000 quarter periodicities', ...
          ['The table reports the estimated variance shares at different horizons accounted for by ' ...
           'the exchange rate shock that explains most of the forecast error variance of the exchange ' ...
           'rate over the [2,1000] quarter periodicity range.']
      'HF',   'dataplots_HF', 'tab: Uhlig_HF',  'tabB02_uhlig_HF.tex', ...
          'Share of forecast error variance explained by the FX shock: target 6--32 quarter periodicities', ...
          ['The table reports the estimated variance shares at different horizons accounted for by ' ...
           'the exchange rate shock that explains most of the forecast error variance of the exchange ' ...
           'rate over the [6,32] quarter periodicity range.'] };

    if isfield(opt,'which') && ~isempty(opt.which); keep = opt.which; else; keep = SPEC(:,1)'; end

    o    = ccdgv_order(D.vnames);
    rows = o.vdec(1:8);                       % the draft's eight rows
    lab  = D.vnames(rows);
    out  = struct();

    for i = 1:size(SPEC,1)
        key = SPEC{i,1}; var = SPEC{i,2};

        % NOT ASKED FOR is silent; ASKED FOR BUT ABSENT is not. The two used to
        % share one `continue`, so a run whose appendix passes never happened
        % produced Table 1 and no B.1/B.2, said nothing, and left the gap to be
        % discovered as a red box in a 34-page inventory. dataplots_AF/_HF exist
        % only when info.idrun asked for passes 2/3, which only the baseline cell
        % of a sweep does.
        if ~ismember(key, keep); continue; end
        if ~isfield(D, var) || isempty(D.(var))
            warning('write_uhlig_tables:noPass', ...
                ['%s not in %s -- skipping %s. That array is written only when ' ...
                 'info.idrun includes pass %d; a run with idrun = 1 produces ' ...
                 'Table 1 alone.'], var, ccdgv_prov_label(D), SPEC{i,4}, i);
            continue
        end
        M  = D.(var)(D.vd_feh, rows, 1)';     % 8 x numel(vd_feh), point estimate
        fn = fullfile(opt.outdir, SPEC{i,4});
        % i IS the identification pass number: SPEC's rows are in info.ident's
        % order, main/AF/HF against passes 1/2/3. The key is this function's own
        % name for the pass and means nothing to the saved run -- which is
        % exactly what used to be passed here.
        local_write(fn, M, lab, D.vd_feh, SPEC{i,3}, SPEC{i,5}, SPEC{i,6}, ...
                    local_prov(D, i));
        out.(key) = M;
        fprintf('  wrote Tables/%s\n', SPEC{i,4});
        if opt.echo
            fprintf('\n  %s\n', SPEC{i,3});
            fprintf('    %-28s%s\n', '', sprintf('%7s', "Q"+string(D.vd_feh)));
            for r = 1:size(M,1)
                fprintf('    %-28s%s\n', lab{r}, sprintf('%7.2f', M(r,:)));
            end
        end
    end
end

function local_write(fn, M, lab, feh, tlabel, caption, note, prov)
    fid = fopen(fn,'w'); c = onCleanup(@() fclose(fid));
    fprintf(fid,'%% Generated by write_uhlig_tables.m -- do not edit by hand.\n%% %s\n', prov);
    provTX = tex_escape(prov);   % the caption is TEXT mode: case_name has underscores
    fprintf(fid,'\\begin{table}[t]\n\t\\centering\n');
    fprintf(fid,'\t\\caption{%s} \\label{%s}\n', caption, tlabel);
    fprintf(fid,'\t\\resizebox{0.975\\columnwidth}{!}{%%\n');
    fprintf(fid,'\t\t\\begin{tabular}{l | %s}\n\t\t\t\\hline\n', repmat(' C{1.5cm} ',1,numel(feh)));
    fprintf(fid,'\t\t\t&    \\multicolumn{%d}{c}{Forecast Horizon (Quarters)} \\\\\n\t\t\t\\hline\n', numel(feh));
    fprintf(fid,'\t\t\t&  %s \\\\ \n\t\t\t\\hline\n', ...
            strjoin(arrayfun(@(h) sprintf('$Q$%d',h), feh, 'UniformOutput',false), ' & '));
    for r = 1:size(M,1)
        fprintf(fid,'\t\t\t%-28s & %s\\\\\n', lab{r}, ...
                strjoin(arrayfun(@(v) sprintf('%.2f',v), M(r,:), 'UniformOutput',false), ' & '));
    end
    fprintf(fid,'\t\t\t\\hline\n\t\t\\end{tabular}\n\t}\n');
    fprintf(fid,'\t\\caption*{\\footnotesize  \\emph{Notes:} %s %s}\n', note, provTX);
    fprintf(fid,'\\end{table}\n');
end

function s = local_prov(D, k)
%   k is the identification PASS INDEX, not this file's SPEC key.
%
%   This took the key ('main' | 'AF' | 'HF') and asked
%   isfield(D.id_meta, key). run_main names id_meta's fields after
%   info.ident(k).label -- 'baseline_FEV100', 'AF_2_1000', 'HF_6_32' -- so the
%   test was never true, and being an isfield guard it failed SILENTLY: `band`
%   stayed empty and the provenance line came out without the target. Tables 1,
%   B.1 and B.2 are one statistic under three different targets, so the omitted
%   field was the only thing distinguishing their notes -- all three carried
%   byte-identical provenance. Resolution moved to ccdgv_id_meta, which looks the
%   label up from info.ident.
    nd = ''; sm = ''; cn = '';
    if isfield(D,'ndraws');     nd = sprintf('ndraws=%d, ', D.ndraws);   end
    if isfield(D,'smax');       sm = sprintf('smax=%g, ',  D.smax);      end
    lab = ccdgv_prov_label(D);
    if ~isempty(lab);           cn = sprintf('%s, ', lab);               end
    band = '';
    m = ccdgv_id_meta(D, k);
    if ~isempty(m)
        if m.shock_extract == 2
            band = sprintf('target [%.0f,%.0f] qtr periodicities, ', 2*pi/m.KUbar, 2*pi/m.KLbar);
        else
            band = sprintf('FEV target at horizon %g, ', m.KUbar);
        end
    end
    s = sprintf('%s%s%s%spoint estimate = median across draws.', cn, band, nd, sm);
end
