% UNPACK_INFO  Put the contents of `info` into workspace variables.
%
%   A script: it reads `info` from the calling workspace and defines the names
%   that run_main, and the scripts it calls, read as plain variables.
%
%   It also derives, and writes back onto info for the record, inclvarnms and
%   nvars (from inclvar), the basis transform and fdvar (from the manifest), and
%   the Minnesota prior arrays. cc is derived from country and is not stored.
%
%   See also VALIDATE_INFO, ID_CFG, RUN_MAIN.

assert(exist('info','var') == 1, 'unpack_info:noInfo', ...
       'unpack_info needs a variable called `info` in the workspace.');
assert(isfield(info,'settings'), 'unpack_info:noSettings', ...
       'info has no settings struct.');

ui_S = info.settings;

% Identity. cc is the country's data column.
country  = info.country;
cc       = ccdgv_countries(country);
datver   = info.datver;

% Sample.
end_date = info.ed;
start_date = info.sd;

% The VAR. inclvarnms and nvars follow from inclvar and the manifest.
[~, ~, ui_V, ui_TR] = ccdgv_manifest();
assert(isfield(info,'inclvar'), 'unpack_info:noInclvar', 'info has no inclvar');
assert(info.inclvar >= 1 && info.inclvar <= numel(ui_V), 'unpack_info:badInclvar', ...
       'info.inclvar = %d but the manifest declares %d specs', info.inclvar, numel(ui_V));
info.inclvarnms   = ui_V{info.inclvar};
nvars             = numel(info.inclvarnms);
info.settings.nvars = nvars;
nlags    = ui_S.nlags;
nconst   = ui_S.nconst;

% Basis transform, from the manifest's entry for this specification. trP and trQ
% are the identity map when it declares none. A Bayesian VECM specification
% (method 6) declares an estimator rule instead: it is estimated in levels, so
% its transform is the identity and the rule goes on info.settings.bvecm_rule.
ui_tr = ui_TR{info.inclvar};
if isfield(ui_tr,'bayes')
    assert(info.method == 6, 'unpack_info:bvecmMethod', ...
        'spec %d is a Bayesian VECM, which needs est_method 6 (got %d).', info.inclvar, info.method);
    info.settings.bvecm_rule = ui_tr;
    ui_tr = [];
end
[trP, trQ, fdvar, trnames, ui_pmean, ui_pin] = ccdgv_transform(ui_tr, info.inclvarnms);
has_transform = ~isempty(ui_tr);
info.fdvar          = fdvar;         % written back for the record
info.settings.trP   = trP;
info.settings.trQ   = trQ;
info.settings.trnames = trnames;     % estimated-variable names, for reporting
info.settings.has_transform = has_transform;
if isfield(info,'fdvar_requested') && ~isequal(info.fdvar_requested, fdvar)
    warning('unpack_info:fdvarOverridden', ...
        ['info.fdvar was %s but spec %d derives %s from its transform. Using ' ...
         'the manifest''s. Declare the basis in ccdgv_manifest, not on info.'], ...
        mat2str(info.fdvar_requested), info.inclvar, mat2str(fdvar));
end

% Estimation.
est_method            = info.method;
ndraws                = ui_S.ndraws;
prior                 = ui_S.prior;
prior_norm            = ui_S.prior_norm;
% Minnesota prior arrays, from nlags, nvars and the manifest's pins.
ui_bidx = ones(nlags*nvars+1, nvars);
% A prior variance scale of 1e-9 on the pinned rows holds those coefficients at
% the prior mean, which imposes the cointegration restriction through the prior.
ui_bidx(end-1-nvars+ui_pin, :) = 0.000000001;
indiv_coeff_priorvar  = ui_bidx(:);
% Prior mean on each variable's own first lag, from the manifest.
indiv_coeff_priormean = ui_pmean;
% An override of the prior mean, if info.settings carries one. It is saved with
% the run.
if isfield(info.settings,'priormean_override') && ~isempty(info.settings.priormean_override)
    indiv_coeff_priormean = info.settings.priormean_override(:);
    fprintf('  [prior] priormean_override in force: %s\n', mat2str(indiv_coeff_priormean'));
end
info.settings.indiv_coeff_priorvar  = indiv_coeff_priorvar;
info.settings.indiv_coeff_priormean = indiv_coeff_priormean;
maxeig_cutoff         = ui_S.maxeig_cutoff;
param                 = ui_S.vecm;

% Identification. Each pass carries its own shock_extract in info.ident(k).
shock_extract  = ui_S.shock_extract;
point_estimate = ui_S.point_estimate;
nimp           = ui_S.nimp;
vd_fr          = ui_S.vd_fr;
vd_feh         = ui_S.vd_feh;
bound          = ui_S.bound;
bound2         = ui_S.bound2;
idrun          = info.idrun;

% Technology and noise decomposition.
j_cj_horizon = ui_S.j_cj_horizon;
smax         = ui_S.smax;

% Plotting.
nplot            = ui_S.nplot;
confidence_bands = ui_S.confidence_bands;

clear ui_S ui_V ui_bidx ui_pmean ui_pin ui_tr
