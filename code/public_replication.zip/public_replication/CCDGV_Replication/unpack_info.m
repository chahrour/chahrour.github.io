function info = unpack_info(info)
%UNPACK_INFO  Derive the fields of a run descriptor that follow from its spec.
%
%   info = unpack_info(info)
%
%   From inclvar and the manifest: inclvarnms and settings.nvars; for a
%   Bayesian VECM specification settings.bvecm_rule; and the Minnesota prior
%   arrays settings.indiv_coeff_priorvar and indiv_coeff_priormean.
%
%   See also ESTIMATE_ONE, VALIDATE_INFO, CCDGV_MANIFEST.

    % The VAR. inclvarnms and nvars follow from inclvar and the manifest.
    [~, ~, V, TR] = ccdgv_manifest();
    info.inclvarnms     = V{info.inclvar};
    nvars               = numel(info.inclvarnms);
    info.settings.nvars = nvars;
    nlags               = info.settings.nlags;

    % A Bayesian VECM specification (method 6) carries its estimator rule.
    if isfield(TR{info.inclvar}, 'bayes')
        info.settings.bvecm_rule = TR{info.inclvar};
    end

    % Minnesota prior arrays: no coefficient's prior variance is rescaled, and
    % every variable's own first lag has prior mean 1, the random walk.
    info.settings.indiv_coeff_priorvar  = ones((nlags*nvars+1)*nvars, 1);
    info.settings.indiv_coeff_priormean = ones(nvars, 1);
end
