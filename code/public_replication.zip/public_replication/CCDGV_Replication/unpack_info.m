% UNPACK_INFO  Put an info struct's contents into the local workspace.
%
%   unpack_info            (a SCRIPT, not a function -- it must write into the
%                           caller's workspace, and the run_main tail plus the
%                           scripts it calls read these as plain variables)
%
%   REQUIRES  info, with the fields run_main's head builds.
%   DEFINES   the names listed below, and nothing else.
%
%   DERIVED, not read: cc (from country), inclvarnms and nvars (from inclvar),
%   and the Minnesota prior arrays (from nlags/nvars/fdvar). Each is written back
%   onto info so the saved run still records it, but info stores exactly one
%   spelling of each fact, so no two fields of a run can contradict each other.
%
%   This is the interface between "what a run IS" (one struct) and "what the
%   code READS" (loose variables). Everything downstream of the boundary in
%   run_main takes its values from here, so a caller can build an info, run the
%   tail, change one field, and run it again -- which is what a sweep needs.
%
%   A script rather than a function because a function cannot write into its
%   caller's workspace without assignin, and the alternative (returning a struct
%   the caller expands) just moves the same problem one line down. The cost is an
%   implicit interface, which is why the DEFINES list below is exhaustive: if you
%   add a name here, add it to that list.
%
%   See also VALIDATE_INFO, ID_CFG.

assert(exist('info','var') == 1, 'unpack_info:noInfo', ...
       'unpack_info needs a variable called `info` in the workspace.');
assert(isfield(info,'settings'), 'unpack_info:noSettings', ...
       'info has no settings struct.');

ui_S = info.settings;

% --- identity ---------------------------------------------------------------
% cc is DERIVED from country, and deliberately NOT written back onto info. It is
% the column the data loaders index (fx_ln(:,cc) and friends), so the two are one
% fact with two spellings -- and they drifted: sweep's by-country loop set the
% name and left the index at 7, so every country run silently re-estimated G6.
%
% Writing it back would reintroduce that exact failure one loop iteration later:
% sweep reuses ONE info across countries, so a stored cc from the Canada run
% survives into the France iteration and contradicts the new name. Nothing needs
% it stored -- country is saved with the run and ccdgv_countries is in the repo,
% so cc is recoverable from the file whenever anyone wants it.
country  = info.country;
cc       = ccdgv_countries(country);
datver   = info.datver;

% --- sample -----------------------------------------------------------------
end_date = info.ed;
start_date = info.sd;

% --- the VAR ----------------------------------------------------------------
% DERIVED from inclvar, not read from info. inclvar is the only stored fact
% about which variables are in the VAR; inclvarnms and nvars follow from it and
% the manifest's spec list. Storing all three invited them to disagree -- the
% contradiction validate_info used to hunt for is now impossible to create.
% They are written BACK onto info so the saved file still records them: a reader
% should not need the manifest to know which variables ran.
[~, ~, ui_V, ui_TR] = ccdgv_manifest();
assert(isfield(info,'inclvar'), 'unpack_info:noInclvar', 'info has no inclvar');
assert(info.inclvar >= 1 && info.inclvar <= numel(ui_V), 'unpack_info:badInclvar', ...
       'info.inclvar = %d but the manifest declares %d specs', info.inclvar, numel(ui_V));
info.inclvarnms   = ui_V{info.inclvar};
nvars             = numel(info.inclvarnms);
info.settings.nvars = nvars;
nlags    = ui_S.nlags;
nconst   = ui_S.nconst;

% --- basis transform --------------------------------------------------------
% DERIVED from inclvar, for the same reason inclvarnms and nvars are: the basis
% a spec is estimated in is a property OF the spec, not an independent choice.
% fdvar comes out of the same table, so it cannot disagree with the transform
% that produces it -- the first VECM attempt failed precisely by declaring
% fdvar while nothing differenced the data.
%
% trP/trQ are [] -> identity for every spec but the VECM, so this is a strict
% no-op on the baseline path.
%
% A BAYESIAN VECM spec (est_method 6) declares an estimator rule instead of a
% basis. It is estimated on the levels data, so its transform is the identity
% and the rule travels on info.settings.bvecm_rule.
ui_tr = ui_TR{info.inclvar};
if isfield(ui_tr,'bayes')
    assert(info.method == 6, 'unpack_info:bvecmMethod', ...
        'spec %d is a Bayesian VECM, which needs est_method 6 (got %d).', info.inclvar, info.method);
    info.settings.bvecm_rule = ui_tr;
    ui_tr = [];
end
[trP, trQ, fdvar, trnames, ui_pmean, ui_pin] = ccdgv_transform(ui_tr, info.inclvarnms);
has_transform = ~isempty(ui_tr);
info.fdvar          = fdvar;         % written back for the record
info.settings.trP   = trP;
info.settings.trQ   = trQ;
info.settings.trnames = trnames;     % estimated-variable names, for reporting
info.settings.has_transform = has_transform;
if isfield(info,'fdvar_requested') && ~isequal(info.fdvar_requested, fdvar)
    warning('unpack_info:fdvarOverridden', ...
        ['info.fdvar was %s but spec %d derives %s from its transform. Using ' ...
         'the manifest''s. Declare the basis in ccdgv_manifest, not on info.'], ...
        mat2str(info.fdvar_requested), info.inclvar, mat2str(fdvar));
end

% --- estimation -------------------------------------------------------------
est_method            = info.method;
ndraws                = ui_S.ndraws;
prior                 = ui_S.prior;
prior_norm            = ui_S.prior_norm;
% DERIVED from nlags/nvars/fdvar, like inclvarnms above -- not stored, so they
% cannot go stale when inclvar changes. Written back onto info for the record.
ui_bidx = ones(nlags*nvars+1, nvars);
% PINS, does not loosen: this scales the prior VARIANCE, so 1e-9 drives those
% coefficients to the prior mean rather than freeing them. The rows are
% end-1-nvars+ui_pin -- the same expression VECM_quick uses to build its
% restriction selector Q. That is the point: est_method 4 imposes the
% cointegration restriction exactly by restricted OLS, and est_method 1 imposes
% the SAME restriction softly through a near-dogmatic prior, which is why the two
% coincide at the point estimate under a flat prior (see genvars' method-4 note).
%
% ui_pin COMES FROM THE MANIFEST, not from fdvar. The two agree today
% (ccdgv_transform asserts every differenced row is pinned), but the pin is the
% cointegration restriction and belongs beside the basis that defines it.
ui_bidx(end-1-nvars+ui_pin, :) = 0.000000001;
indiv_coeff_priorvar  = ui_bidx(:);
% PRIOR MEAN ON EACH VARIABLE'S OWN FIRST LAG, also from the manifest. genvars
% used to decide this for itself as `lev = ones; lev(fdvar) = 0`, i.e. "anything
% not differenced is a level, so give it a unit-root prior". Correct for every
% untransformed spec, and exactly backwards for the VECM, whose undifferenced
% rows are the cointegrating relations the spec ASSUMES STATIONARY -- so the
% prior was pulling the two error-correction terms toward random walks.
indiv_coeff_priormean = ui_pmean;
% Experiment hook, and the reason it is a field rather than an edit: an override
% is SAVED on info, so a result file records which prior produced it. Used to
% compare the stationary (0) and unit-root (1) treatments of q and idiff.
if isfield(info.settings,'priormean_override') && ~isempty(info.settings.priormean_override)
    indiv_coeff_priormean = info.settings.priormean_override(:);
    fprintf('  [prior] priormean_override in force: %s\n', mat2str(indiv_coeff_priormean'));
end
info.settings.indiv_coeff_priorvar  = indiv_coeff_priorvar;
info.settings.indiv_coeff_priormean = indiv_coeff_priormean;
maxeig_cutoff         = ui_S.maxeig_cutoff;
param                 = ui_S.vecm;

% --- data construction ------------------------------------------------------
% EOP, tfp_measure and percapita were unpacked here with a note saying the data
% loader read them from this workspace. It does not -- ryan_data reads none of
% the three, and nothing else did either. Removed rather than kept as a hook for
% a loader that no longer exists.

% --- identification ---------------------------------------------------------
% shock_extract is kept for consumers that still read a single value; the passes
% themselves carry their own in info.ident(k), which is what id_cfg uses.
shock_extract  = ui_S.shock_extract;
point_estimate = ui_S.point_estimate;
nimp           = ui_S.nimp;
vd_fr          = ui_S.vd_fr;
vd_feh         = ui_S.vd_feh;
bound          = ui_S.bound;
bound2         = ui_S.bound2;
idrun          = info.idrun;

% --- CJ ---------------------------------------------------------------------
j_cj_horizon = ui_S.j_cj_horizon;
smax         = ui_S.smax;

% --- plotting ---------------------------------------------------------------
nplot            = ui_S.nplot;
confidence_bands = ui_S.confidence_bands;

clear ui_S ui_V ui_bidx ui_pmean ui_pin ui_tr
