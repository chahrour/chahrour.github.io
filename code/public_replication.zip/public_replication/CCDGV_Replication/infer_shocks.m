function S = infer_shocks(src, opt)
%INFER_SHOCKS  Recover the CJ technology and noise disturbance series from a run.
%
%   S = INFER_SHOCKS(info)        a run descriptor -- path via data_name
%   S = INFER_SHOCKS(filename)    a result .mat directly
%   S = INFER_SHOCKS(src, opt)    opt.j_cj_horizon overrides the run's
%
%   opt.cond         cell of manifest row NAMES, e.g. {'NER'}. Also return the
%                    path of those series implied by the two disturbances
%                    together (S.cond), i.e. each row's MA applied to the
%                    recovered shocks -- leads and lags included.
%
%   opt.restricted   build the shocks from the PAPER's no-FX object instead of
%                    the run as estimated: the VAR the full system implies for a
%                    subset. Needs opt.nofx_info (which variables to keep) and
%                    takes opt.nofx_opt through to NOFX_RESTRICTED.
%                    Called with the BASELINE run as src -- no separate no-FX
%                    estimation is involved. See NOFX_RESTRICTED for why this is
%                    a different object from an inclvar = 2 run.
%
%   S.ehat_tfp    T x 1 technology disturbances
%   S.ehat_noise  T x 1 noise disturbances
%   S.dates       T x 1 fractional years, aligned to the two series
%   S.cond        T x numel(opt.cond), only when opt.cond is given. LEVELS of
%                 each series due to technology and noise jointly, demeaned
%                 data, same dates as the shocks.
%   S.meta        what it was built from
%
%   NOT the max-share shocks. genmaxshare_final's want_shocks returns the shocks
%   of the MAX-SHARE identification; these are the Chahrour-Jurado disturbances,
%   recovered from the two-sided MA representation of TFP and E_t[TFP_{t+j}].
%   Different identification, different object -- do not substitute one for the
%   other. (The paper_inventory note claiming otherwise was wrong.)
%
%   METHOD (from shock_estimate.m / "Extracting Shocks.pdf"). Stack
%   y = [tfp; E_t tfp_{t+j}] and the two-sided MA coefficients B into a banded
%   BB, then take the minimum-norm solution
%
%       lam  = (BB*BB') \ y;      ehat = lam' * BB;
%
%   which is the least-squares choice of iid shocks reproducing y exactly. The
%   result is truncated back to the observed sample.
%
%   EXTRACTED FROM shock_extract.m, with three things fixed:
%
%   1. ROWS RESOLVED BY NAME. The original took irtfp(:,[1, nvars+1]), assuming
%      A = [I_nvars; constructed] so that E[TFP] sat at nvars+1. Under the
%      manifest basis A = [Aproj; constructed] and nvars+1 is a DATA row --
%      eq_us on the baseline layout. The same literal now selects the wrong
%      series silently.
%   2. DATES FROM THE RUN. The original recovered them by searching USDATA for
%      an exact floating-point match to the first TFP value
%      (find(orig_tfp == tfp_raw(1))), which ties the function to a spreadsheet
%      and to bit-identical arithmetic. The run already saves `dates`.
%   3. NO HARD-CODED LAG COUNT. The original stacked exactly four lags with a
%      literal [data(4:end,:), data(3:end-1,:), ...] and warned "this code is not
%      flexible to the choice of lags". Built from nlags here.
%
%   See also GENFIG_B11, GEN_AUXVARS, DATA_NAME.

    if nargin < 2; opt = struct(); end

    % ---- resolve the source -------------------------------------------
    if isstruct(src)
        [~, f] = data_name(src);
        if ~isfile(f) && isfield(src,'outdir')
            f = fullfile(src.outdir, data_name(src));
        end
    else
        f = char(src);
    end
    assert(isfile(f), 'infer_shocks:noFile', '%s not found', f);

    % The recovery uses the whole two-sided MA of the POINT ESTIMATE. A run saves
    % that draw at full length as irtfp_pe/irnoise_pe, and every draw only on the
    % shorter stored window (smax_store); a file without _pe has the full length
    % in irtfp itself.
    if all(ismember({'irtfp_pe','irnoise_pe'}, who('-file', f)))
        D = load(f, 'ARs','data','dates','vnames','irtfp_pe','irnoise_pe','info');
        D.irtfp = D.irtfp_pe;  D.irnoise = D.irnoise_pe;
    else
        D = load(f, 'ARs','data','dates','vnames','irtfp','irnoise','info');
    end
    for r = {'ARs','data','dates','vnames','irtfp','irnoise'}
        assert(isfield(D,r{1}), 'infer_shocks:missing', ...
               '%s has no %s -- was it produced by the current run_main?', f, r{1});
    end

    if isfield(opt,'j_cj_horizon'); jh = opt.j_cj_horizon;
    else;                           jh = D.info.settings.j_cj_horizon; end

    % ---- WHICH SYSTEM -------------------------------------------------
    % Default: the run as estimated. opt.restricted swaps in the paper's no-FX
    % object -- the VAR the FULL system implies for a subset, derived rather than
    % estimated (NOFX_RESTRICTED). Everything below is unchanged by the swap:
    % only the AR block, the data columns and the two MA rows differ, so the
    % recovery algebra has exactly one implementation.
    if isfield(opt,'restricted') && opt.restricted
        assert(isfield(opt,'nofx_info'), 'infer_shocks:noNofxInfo', ...
               'opt.restricted needs opt.nofx_info to say which columns to drop');
        nopt = struct(); if isfield(opt,'nofx_opt'); nopt = opt.nofx_opt; end
        R = nofx_restricted(src, opt.nofx_info, nopt);
        AR = R.AR_rs{end};  cols = R.idxV;
        if isfield(R,'irtfp_pe'); D.irtfp = R.irtfp_pe; D.irnoise = R.irnoise_pe;
        else;                     D.irtfp = R.irtfp;    D.irnoise = R.irnoise;    end
    else
        AR = D.ARs{end};  cols = 1:size(D.data,2);
    end
    nvars = numel(cols);
    nlags = size(AR,2)/nvars;

    % ---- E_t[TFP_{t+j}] as a row of the state --------------------------
    % ia1'*B^j, not gen_auxvars: the same row by construction (TFP is state
    % element 1), and it is defined for the restricted system too, which has no
    % Aproj of its own. The recovery below already assumes TFP is first -- assert
    % it once here rather than let a reordered spec fail silently.
    %
    % ASSERT ON THE SPEC'S VARIABLE LIST, NOT ON vnames. This used to check
    % D.vnames{1} == 'Home TFP', which is the first MANIFEST ROW name and stays
    % 'Home TFP' whatever basis the data columns are in. On the VECM it therefore
    % asserted happily while column 1 of `data` was dTFP -- the guard passed on
    % precisely the run it existed to catch. inclvarnms is the VAR's own variable
    % list and is what both `data` column 1 and companion state element 1 are.
    assert(strcmp(D.info.inclvarnms{1}, 'tfp'), 'infer_shocks:tfpNotFirst', ...
           'VAR variable 1 is %s, not tfp -- the recovery assumes TFP leads the state', ...
           D.info.inclvarnms{1});

    % AND THAT `data` IS THE LEVELS MATRIX. run_main now saves levels under
    % `data` and the estimated basis under `data_est`; a file written before that
    % has the TRANSFORMED matrix under `data`, which cannot be paired with the
    % levels ARs and cannot be converted back here (inverting y_t = P z_t -
    % Q z_{t-1} needs a z_0 the file does not carry). Refuse rather than compute
    % a plausible wrong answer. Untransformed specs are unaffected either way --
    % their two matrices are identical -- so this only ever fires on the VECM.
    % who('-file') rather than loading data_est: asking load() for a variable a
    % file does not have warns, and every pre-fix file (the baseline included)
    % would print one on every call. The header read is cheap and only happens
    % for a spec that actually declares a transform.
    if isfield(D.info.settings,'has_transform') && D.info.settings.has_transform ...
            && ~ismember('data_est', who('-file', f))
        error('infer_shocks:staleBasis', ...
            ['%s declares a basis transform but has no `data_est`, so it predates ' ...
             'the fix that made `data` the LEVELS matrix. Its `data` is in the ' ...
             'ESTIMATED basis and pairing it with the levels ARs gives shocks that ' ...
             'are not the run''s. Re-run this spec.'], f);
    end
    ia1 = zeros(nvars*nlags,1);  ia1(1) = 1;
    exp_tfp_j = ia1' * companion_form(AR)^jh;

    % ---- stack the data as the companion state -------------------------
    y0 = D.data(:,cols) - mean(D.data(:,cols), 1);
    T0 = size(y0,1);
    b_data = zeros(T0-nlags+1, nvars*nlags);
    for L = 1:nlags                                   % lag 0 first, as the VAR
        b_data(:, (L-1)*nvars+(1:nvars)) = y0(nlags-L+1 : T0-L+1, :);
    end

    term_tfp = zeros(1, nvars*nlags);  term_tfp(1) = 1;
    tfp     = b_data * term_tfp';
    exp_tfp = b_data * exp_tfp_j';

    % ---- the two MA rows, BY NAME --------------------------------------
    i = var_order(D.vnames, 'Home TFP', 'E[TFP]');
    it = flip(cumsum(D.irtfp),  1);
    in = flip(cumsum(D.irnoise),1);
    irtfp1   = it(:, i, end);       % point-estimate draw, as the original
    irnoise1 = in(:, i, end);

    % ---- minimum-norm shocks reproducing y ------------------------------
    nB = size(irnoise1,1);
    B  = zeros(2,2,nB);
    for jj = 1:nB
        B(:,:,jj) = [irtfp1(jj,:)', irnoise1(jj,:)'];
    end
    y = [tfp'; exp_tfp'];  y = y(:);
    T = numel(y)/2;

    Btil = reshape(B, [2, 2*nB]);
    BB   = zeros(2*T, (nB+T)*2);
    for jj = 1:T
        BB(2*(jj-1)+(1:2), 2*(jj-1)+(1:size(Btil,2))) = Btil;
    end

    lam  = (BB*BB') \ y;
    efull = reshape(lam' * BB, [2, T+1+2*(nB-1)/2]);

    h    = (nB-1)/2;
    ehat = efull(:, h+1:h+T);

    S = struct();
    S.ehat_tfp   = ehat(1,:)';
    S.ehat_noise = ehat(2,:)';

    % dates: the run's own, trimmed by the lags the stacking consumes
    d = D.dates(:);
    S.dates = d(end-T+1:end);
    assert(numel(S.dates) == T, 'infer_shocks:dates', ...
           'got %d shocks but %d dates', T, numel(S.dates));

    % ---- the series the two disturbances imply, if asked ----------------
    % Same banded MA as BB, with the requested rows' responses in place of TFP
    % and E[TFP], applied to the FULL shock vector -- the shocks before and after
    % the sample enter through the leads and lags of the two-sided MA.
    if isfield(opt,'cond') && ~isempty(opt.cond)
        ic = var_order(D.vnames, opt.cond{:});
        k  = numel(ic);
        ct = it(:, ic, end);  cn = in(:, ic, end);
        C  = zeros(k, 2, nB);
        for jj = 1:nB
            C(:,:,jj) = [ct(jj,:)', cn(jj,:)'];
        end
        Ctil = reshape(C, [k, 2*nB]);
        CC   = zeros(k*T, (nB+T)*2);
        for jj = 1:T
            CC(k*(jj-1)+(1:k), 2*(jj-1)+(1:size(Ctil,2))) = Ctil;
        end
        S.cond = reshape(CC*efull(:), [k, T])';
    end

    S.meta = struct('file', f, 'nvars', nvars, 'nlags', nlags, ...
                    'j_cj_horizon', jh, 'T', T, 'cols', cols, ...
                    'system', 'as estimated', ...
                    'rows', {{D.vnames{i(1)}, D.vnames{i(2)}}});
    if isfield(opt,'restricted') && opt.restricted
        S.meta.system = 'implied restricted VAR (paper no-FX)';
    end
end
