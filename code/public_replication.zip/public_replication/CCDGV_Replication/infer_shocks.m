function S = infer_shocks(src, opt)
%INFER_SHOCKS  Recover the technology and noise disturbance series from a run.
%
%   S = INFER_SHOCKS(info)        a run descriptor; the path comes from data_name
%   S = INFER_SHOCKS(filename)    a run .mat
%   S = INFER_SHOCKS(src, opt)
%
%   opt.j_cj_horizon  overrides the run's horizon j
%   opt.cond          cell of manifest row names, e.g. {'NER'}: also return the
%                     path of those series implied by the two disturbances
%   opt.restricted    use the no-FX system the run implies for a subset of its
%                     variables (NOFX_RESTRICTED) instead of the run as
%                     estimated. Needs opt.nofx_info, the descriptor naming the
%                     variables to keep; opt.nofx_opt is passed through.
%
%   S.ehat_tfp    T x 1 technology disturbances
%   S.ehat_noise  T x 1 noise disturbances
%   S.dates       T x 1 fractional years
%   S.cond        T x numel(opt.cond), when opt.cond is given: the level of each
%                 (demeaned) series due to technology and noise jointly
%   S.meta        what it was built from
%
%   These are the Chahrour-Jurado disturbances, not the max-share shocks. They
%   are recovered at the point estimate from the two-sided MA representation of
%   y = [tfp; E_t tfp_{t+j}]. With the MA coefficients stacked into a banded
%   matrix BB, the minimum-norm shocks that reproduce y exactly are
%
%       lam = (BB*BB') \ y;      ehat = lam' * BB;
%
%   truncated to the observed sample.
%
%   See also GENFIG_C11, NOFX_RESTRICTED, DATA_NAME.

    if nargin < 2; opt = struct(); end

    % Locate the run file.
    if isstruct(src)
        [~, f] = data_name(src);
    else
        f = char(src);
    end
    assert(isfile(f), 'infer_shocks:noFile', '%s not found', f);

    % The recovery uses the full-length two-sided MA of the point estimate,
    % saved as irtfp_pe/irnoise_pe. A file without them has it in irtfp/irnoise.
    if all(ismember({'irtfp_pe','irnoise_pe'}, who('-file', f)))
        D = load(f, 'ARs','data','dates','vnames','irtfp_pe','irnoise_pe','info');
        D.irtfp = D.irtfp_pe;  D.irnoise = D.irnoise_pe;
    else
        D = load(f, 'ARs','data','dates','vnames','irtfp','irnoise','info');
    end
    for r = {'ARs','data','dates','vnames','irtfp','irnoise'}
        assert(isfield(D,r{1}), 'infer_shocks:missing', ...
               '%s has no %s -- was it produced by the current run_main?', f, r{1});
    end

    if isfield(opt,'j_cj_horizon'); jh = opt.j_cj_horizon;
    else;                           jh = D.info.settings.j_cj_horizon; end

    % The system: the run as estimated, or the restricted no-FX system it
    % implies. Only the AR block, the data columns and the two MA rows differ.
    if isfield(opt,'restricted') && opt.restricted
        assert(isfield(opt,'nofx_info'), 'infer_shocks:noNofxInfo', ...
               'opt.restricted needs opt.nofx_info to say which columns to drop');
        nopt = struct(); if isfield(opt,'nofx_opt'); nopt = opt.nofx_opt; end
        R = nofx_restricted(src, opt.nofx_info, nopt);
        AR = R.AR_rs{end};  cols = R.idxV;
        if isfield(R,'irtfp_pe'); D.irtfp = R.irtfp_pe; D.irnoise = R.irnoise_pe;
        else;                     D.irtfp = R.irtfp;    D.irnoise = R.irnoise;    end
    else
        AR = D.ARs{end};  cols = 1:size(D.data,2);
    end
    nvars = numel(cols);
    nlags = size(AR,2)/nvars;

    % E_t[TFP_{t+j}] is row e1'*B^j of the companion state, which requires TFP
    % to be the first VAR variable.
    assert(strcmp(D.info.inclvarnms{1}, 'tfp'), 'infer_shocks:tfpNotFirst', ...
           'VAR variable 1 is %s, not tfp -- the recovery assumes TFP leads the state', ...
           D.info.inclvarnms{1});

    % `data` must be the levels matrix. A run with a basis transform also saves
    % data_est; a file that declares a transform without it holds the
    % transformed matrix under `data` and cannot be used.
    if isfield(D.info.settings,'has_transform') && D.info.settings.has_transform ...
            && ~ismember('data_est', who('-file', f))
        error('infer_shocks:staleBasis', ...
            ['%s declares a basis transform but has no `data_est`, so it predates ' ...
             'the fix that made `data` the LEVELS matrix. Its `data` is in the ' ...
             'ESTIMATED basis and pairing it with the levels ARs gives shocks that ' ...
             'are not the run''s. Re-run this spec.'], f);
    end
    ia1 = zeros(nvars*nlags,1);  ia1(1) = 1;
    exp_tfp_j = ia1' * companion_form(AR)^jh;

    % Stack the demeaned data as the companion state.
    y0 = D.data(:,cols) - mean(D.data(:,cols), 1);
    T0 = size(y0,1);
    b_data = zeros(T0-nlags+1, nvars*nlags);
    for L = 1:nlags                                   % lag 0 first
        b_data(:, (L-1)*nvars+(1:nvars)) = y0(nlags-L+1 : T0-L+1, :);
    end

    % The TFP and E_t[TFP_{t+j}] series.
    term_tfp = zeros(1, nvars*nlags);  term_tfp(1) = 1;
    tfp     = b_data * term_tfp';
    exp_tfp = b_data * exp_tfp_j';

    % The two MA rows, found by name.
    i = var_order(D.vnames, 'Home TFP', 'E[TFP]');
    it = flip(cumsum(D.irtfp),  1);
    in = flip(cumsum(D.irnoise),1);
    irtfp1   = it(:, i, end);       % point-estimate draw
    irnoise1 = in(:, i, end);

    % Minimum-norm shocks that reproduce y.
    nB = size(irnoise1,1);
    B  = zeros(2,2,nB);
    for jj = 1:nB
        B(:,:,jj) = [irtfp1(jj,:)', irnoise1(jj,:)'];
    end
    y = [tfp'; exp_tfp'];  y = y(:);
    T = numel(y)/2;

    Btil = reshape(B, [2, 2*nB]);
    BB   = zeros(2*T, (nB+T)*2);
    for jj = 1:T
        BB(2*(jj-1)+(1:2), 2*(jj-1)+(1:size(Btil,2))) = Btil;
    end

    lam  = (BB*BB') \ y;
    efull = reshape(lam' * BB, [2, T+1+2*(nB-1)/2]);

    % Keep the shocks dated inside the sample.
    h    = (nB-1)/2;
    ehat = efull(:, h+1:h+T);

    S = struct();
    S.ehat_tfp   = ehat(1,:)';
    S.ehat_noise = ehat(2,:)';

    % Dates: the run's own, less the lags the stacking uses.
    d = D.dates(:);
    S.dates = d(end-T+1:end);
    assert(numel(S.dates) == T, 'infer_shocks:dates', ...
           'got %d shocks but %d dates', T, numel(S.dates));

    % Series implied by the two disturbances: the requested rows' MA applied to
    % the full shock vector, including shocks before and after the sample.
    if isfield(opt,'cond') && ~isempty(opt.cond)
        ic = var_order(D.vnames, opt.cond{:});
        k  = numel(ic);
        ct = it(:, ic, end);  cn = in(:, ic, end);
        C  = zeros(k, 2, nB);
        for jj = 1:nB
            C(:,:,jj) = [ct(jj,:)', cn(jj,:)'];
        end
        Ctil = reshape(C, [k, 2*nB]);
        CC   = zeros(k*T, (nB+T)*2);
        for jj = 1:T
            CC(k*(jj-1)+(1:k), 2*(jj-1)+(1:size(Ctil,2))) = Ctil;
        end
        S.cond = reshape(CC*efull(:), [k, T])';
    end

    S.meta = struct('file', f, 'nvars', nvars, 'nlags', nlags, ...
                    'j_cj_horizon', jh, 'T', T, 'cols', cols, ...
                    'system', 'as estimated', ...
                    'rows', {{D.vnames{i(1)}, D.vnames{i(2)}}});
    if isfield(opt,'restricted') && opt.restricted
        S.meta.system = 'implied restricted VAR (paper no-FX)';
    end
end
