function fout = genfig_B7B8(base_info, alts, dest)
%GENFIG_B7B8  Figures B.7 and B.8 -- disturbances under alternative specifications.
%   fout = GENFIG_B7B8(base_info, alts)
%   fout = GENFIG_B7B8(base_info, alts, dest)
%
%   base_info  the baseline run, drawn solid with 16-84 bands
%   alts       n x 2 cell, {legend label, info} per dashed overlay. Any row whose
%              info is empty is DROPPED and reported -- that is how the VECM slot
%              stays visible while its estimation question is unresolved, rather
%              than being quietly filled with something that is not a VECM.
%   fout       [B.7 figure, B.8 figure]
%
%   The draft's alt_technology.eps / alt_noise.eps: "the point estimate of the
%   responses obtained from the VAR applied to the extended sample ... and from a
%   VECM where the real exchange rate and interest rate differential are assumed
%   stationary ... also ... the baseline VAR with one additional variable."
%
%   Structurally identical to GENFIG_B9B10 -- one run solid with bands, several
%   dashed point estimates, same six panels, same 425x400 canvas -- so it shares
%   the plotter and the export settings. It differs only in what the overlays
%   ARE: specifications rather than countries. plotIRF_paper_individual used to
%   hard-code six country labels; it now takes them as an argument and infers the
%   overlay count, with the countries as the default so B.9/B.10 are unchanged.
%
%   ROW SETS MUST MATCH. Every run has to carry the same manifest layout, which
%   in practice means every run must postdate the same manifest edit. Adding
%   solow_g6 took the data list from 12 rows to 13 and vnames from 30 to 31, so a
%   result file written before that cannot be overlaid on one written after. This
%   is asserted, not assumed -- a silent mismatch here would draw one spec's row
%   against another's.
%
%   See also GENFIG_B9B10, PLOTIRF_PAPER_INDIVIDUAL, SWEEP.

    assert(nargin >= 3 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end

    keep = ~cellfun(@isempty, alts(:,2));
    if any(~keep)
        fprintf('  B.7/B.8: no run for %s -- omitted from the figure\n', ...
                strjoin(alts(~keep,1)', ', '));
    end
    alts = alts(keep,:);
    assert(~isempty(alts), 'genfig_B7B8:noAlts', 'no alternative specs supplied');
    labels = alts(:,1)';
    runs   = [alts(:,2)', {base_info}];      % solid LAST, as the plotter expects

    % ---- assemble (nimp x 2*nrows x 5 x numel(runs)) --------------------
    n = numel(runs);
    for jj = n:-1:1
        [dt, dn, vn] = local_panel(runs{jj});
        if jj == n
            vnames = vn;
            individual_tfp   = NaN([size(dt), n]);
            individual_noise = NaN([size(dn), n]);
        else
            assert(isequal(vn, vnames), 'genfig_B7B8:rowMismatch', ...
                ['%s has %d rows against the baseline''s %d -- the runs predate ' ...
                 'different manifest versions and cannot be overlaid. Re-run them ' ...
                 'against the current manifest.'], ...
                data_name(runs{jj}), numel(vn), numel(vnames));
        end
        individual_tfp(:,:,:,jj)   = dt;
        individual_noise(:,:,:,jj) = dn;
    end

    iT = var_order(vnames, 'Home TFP');
    individual_noise(:, [iT, numel(vnames)+iT], :, :) = 0;

    ROWS = {'Home TFP', 'Interest Rate Differential', 'Home Consumption', ...
            'Real Exchange Rate', 'Foreign Consumption', 'Expected Excess Returns'};
    ord = var_order(vnames, ROWS{:});  ord = ord(:);


    % The draft's five overlays -- VECM, Trade Balance, Equity Price, Foreign
    % Solow, Bond Yields -- take MATLAB's default colours in that order, and
    % LEGCOLS 3 lays the legend out as the draft does: VECM, Trade Balance,
    % Equity Price on the first row, the other two below. COLS is explicit
    % because the default ColorOrder has seven entries, so a seventh overlay
    % would take the solid line's colour.
    LEGCOLS = 3;  COFF = 1;
    COLS = [0.850 0.325 0.098     % orange
            0.929 0.694 0.125     % yellow
            0.494 0.184 0.556     % purple
            0.466 0.674 0.188     % green
            0.301 0.745 0.933     % cyan
            0.635 0.078 0.184     % dark red
            0.400 0.400 0.400];   % grey
    COLS = COLS(1:numel(labels),:);
    plotIRF_paper_individual(individual_tfp,   ord, vnames, 'altTFP',   1:6, 1, 0, 0, 1, labels, LEGCOLS, COFF, COLS);
    fout(1) = local_export(gcf, fullfile(dest, 'alt_technology.pdf'));

    plotIRF_paper_individual(individual_noise, ord, vnames, 'altNOISE', 1:6, 1, 1, 0, 1, labels, LEGCOLS, COFF, COLS);
    fout(2) = local_export(gcf, fullfile(dest, 'alt_noise.pdf'));


    fprintf('  wrote alt_technology.pdf (B.7), alt_noise.pdf (B.8)\n');
    fprintf('    baseline %s\n', data_name(base_info));
    for k = 1:numel(labels)
        fprintf('    %-22s %s\n', labels{k}, data_name(alts{k,2}));
    end
end

% -------------------------------------------------------------------------
function f = local_export(f, target)
%   The draft's alt_*.eps are 425x400 on white, exactly as B.9/B.10 -- see
%   GENFIG_B9B10's local_export for why print beats exportgraphics here.
    set(f, 'Color','w', 'InvertHardcopy','off', 'PaperUnits','points', ...
           'PaperPosition',[0 0 425 400], 'PaperSize',[425 400]);
    print(f, target, '-dpdf', '-r0');
end

function [dt, dn, vnames] = local_panel(info)
    [~, f] = data_name(info);
    assert(isfile(f), 'genfig_B7B8:noFile', '%s not found', f);
    D = load(f, 'irtfp','irnoise','vnames','point_estimate','bound','bound2');
    h = (size(D.irtfp,1)-1)/2;
    hgrid = -50:20;  discard = 30;
    dt = pack_bands(cumsum(D.irtfp),   hgrid+h+1, discard, D);
    dn = pack_bands(cumsum(D.irnoise), hgrid+h+1, discard, D);
    vnames = D.vnames;
end

