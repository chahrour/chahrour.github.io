function out = write_text_numbers(I, opt)
%WRITE_TEXT_NUMBERS  The numbers the draft quotes in its text that no exhibit shows.
%
%   out = WRITE_TEXT_NUMBERS(I)
%   out = WRITE_TEXT_NUMBERS(I, opt)
%
%   I     sweep()'s descriptors. Uses .base, and .extend and .nofx where
%         a row needs them.
%   opt   .outdir  REQUIRED: the directory holding Figures/ and Tables/
%         .echo    print the rows (default true)
%
%   Writes Tables/tab_text_numbers.tex, and Tables/tab_response_numbers.tex for
%   the numbers the second-round responses to the referees quote.
%
%   tab_text_numbers: one row per number the draft states in
%   its text, in the order the text states them, with the draft's value beside
%   this run's and how this run's was computed. Numbers that can be read off a
%   table (Tables 1-3, B.4-B.9) are not repeated; numbers read off a figure are,
%   because a figure gives them only by eye.
%
%   A ROW THAT CANNOT BE COMPUTED SAYS WHY instead of stopping the table: it is
%   written as "--" with the reason in its last column, and a warning is issued.
%   The anticipation row needs vstfp_real, which only runs made after b131a1f
%   carry, so on an older run it is the expected case rather than a failure.
%
%   Several rows reuse the generators of other tables -- write_moments_table,
%   write_st_news_table, shock_corr_spec -- so the number here is the number
%   those tables report; their own .tex output goes to a temporary folder. The
%   exception is WRITE_ASSET_PROJ_VD_VARIANTS, whose table is written to OUTDIR
%   here, with the other text numbers.
%
%   STATISTICS, so each row means one thing:
%     responses   Figures 1 and 2's own line: the point estimate when the run
%                 sets point_estimate, otherwise the median across draws.
%     shares      medians across draws, Both = median Tech + median Noise, as in
%                 Table 2. For a projected series: of the SERIES itself (its
%                 variance as denominator), under each first stage of
%                 the run's single projection stage
%                 and is the drawn one when proj_prior.draw is set.
%     correlations of the returns: of the parts the two disturbances drive, over
%                 2-100 quarter periodicities, under each first stage
%                 (CCDGV_PROJ_VARIANT).
%     moments     the medians Table 3 reports; a ratio is Both over Unconditional.
%
%   See also WRITE_MOMENTS_TABLE, WRITE_ASSET_PROJ_VD_TABLE, WRITE_ST_NEWS_TABLE,
%   SHOCK_CORR_SPEC, INFER_SHOCKS, CCDGV_EXTSHARE.

    if nargin < 2; opt = struct(); end
    if ~isfield(opt,'echo'); opt.echo = true; end
    % The AR order for the variance-share denominator must match the projection
    % stage's own, or the share is taken against the wrong residual process.
    assert(isfield(opt,'arlags'), 'write_text_numbers:noArlags', ...
        'opt.arlags is required and must equal the projection stage''s arlags.');
    % opt.outdir is the EXHIBIT ROOT; this function appends Tables/ itself, which
    % is the same convention every generator here uses.
    assert(isfield(opt,'outdir') && ~isempty(opt.outdir), 'write_text_numbers:noOutdir', ...
        'opt.outdir is required: the directory holding Figures/ and Tables/.');
    % THE ROOT IS KEPT, because not every callee wants the same thing.
    % write_asset_proj_vd_table takes the exhibit ROOT and appends Tables/ itself;
    % passing it this function's already-appended path is what produced
    % Figures_Tables/Tables/Tables/tab_asset_proj_vd.tex on every run.
    opt.exhibit_root = opt.outdir;   % travels into local_shares; a local
                                     % function sees no caller workspace
    opt.outdir = fullfile(opt.outdir, 'Tables');
    if ~isfolder(opt.outdir); mkdir(opt.outdir); end

    tmp = tempname;  mkdir(tmp);
    cl  = onCleanup(@() rmdir(tmp, 's'));
    q   = struct('echo', false, 'outdir', tmp);

    [~, f] = data_name(I.base);
    assert(isfile(f), 'write_text_numbers:noFile', '%s not found', f);
    D = load(f, 'irtfp','irnoise','vnames','point_estimate','dataplots', ...
                'vstfp','vsnoise','vd_fr','vd_feh','info','bound');
    if any(strcmp(who('-file', f), 'vstfp_real'))
        L = load(f, 'vstfp_real');  D.vstfp_real = L.vstfp_real;
    end

    % The two generators several rows share, run once. A failure is kept and
    % re-raised by each row that needs it, so it is reported row by row.
    MOM = local_try(@() write_moments_table(f, q));
    % The projected-series variance shares. This also writes
    % Tables/tab_asset_proj_vd.tex, so it goes to the real outdir.
    VAR = local_try(@() local_shares(I.base, opt));

    T = cell(0, 5);     % where | what | draft | this run | how

    % ---- Section 2: the main exchange rate shock (Figure 1, footnote 8) -----
    T = local_row(T, 'Sec.\ 2', ...
        'Real exchange rate: half-life of the response to the main exchange rate shock', ...
        'about 3 years', @() local_halflife(D));
    T = local_row(T, 'Sec.\ 2', ...
        'Home TFP: peak response to the main exchange rate shock, and when', ...
        'about 0.4\%, roughly 20 quarters after', @() local_tfppeak(D));
    T = local_row(T, 'Sec.\ 2', ...
        'Share of the variance of US / G6 equity prices explained by the main exchange rate shock (projected on it, footnote 8)', ...
        '23\% / 27\%', @() local_asset(VAR, 'uhlig', 'equity'));
    T = local_row(T, 'Sec.\ 2', ...
        'Same, US / G6 10-year bond yields', ...
        '37\% / 41\%', @() local_asset(VAR, 'uhlig', 'yields'));

    % ---- Section 3: Figure 2 and the anticipation split ---------------------
    T = local_row(T, 'Sec.\ 3.1', ...
        'Technology: response of $\mathbb{E}_t(a_{t+20})$ 20 quarters before the TFP increase', ...
        'about 0.2\%', @() local_fig2(D, 'tech_pre'));
    T = local_row(T, 'Sec.\ 3.1', ...
        'Technology: response of TFP at $t=0$', ...
        '0.75\%', @() local_fig2(D, 'tech_tfp0'));
    T = local_row(T, 'Sec.\ 3.1', ...
        'Share of the TFP increase foreseen five years ahead (the first over the second)', ...
        'around one-quarter', @() local_fig2(D, 'ratio'));
    T = local_row(T, 'Sec.\ 3.1', ...
        'Noise: response of $\mathbb{E}_t(a_{t+20})$ on impact', ...
        'roughly 0.5\%', @() local_fig2(D, 'noise_e0'));
    T = local_row(T, 'Sec.\ 3.1', ...
        'Real exchange rate, 2--100 quarters: share due to technology from movements before $t=0$ vs at and after $t=0$', ...
        '34\% vs 11\%', @() local_anticipation(D));

    % ---- Section 4.1: Table 3 as ratios -------------------------------------
    T = local_row(T, 'Sec.\ 4.1', ...
        'Share of cov$(\lambda_{t+1}, r_t - r_t^\star)$ accounted for by the two disturbances', ...
        'roughly two-thirds ($-0.82$ of $-1.30$)', @() local_moment(MOM, 'cov_fama'));
    T = local_row(T, 'Sec.\ 4.1', ...
        'Share of cov$(\sum_k \mathbb{E}_t\lambda_{t+k+1}, r_t - r_t^\star)$ accounted for', ...
        'almost all', @() local_moment(MOM, 'cov_engel'));
    T = local_row(T, 'Sec.\ 4.1', ...
        'Share of cov$(\Delta q_t, \Delta(c_t - c_t^\star))$ accounted for', ...
        'roughly 30\%', @() local_moment(MOM, 'cov_dq_dcd'));

    % ---- Section 4.2: asset prices and returns -------------------------------
    T = local_row(T, 'Sec.\ 4.2', ...
        'Share of US / G6 equity prices explained by the two disturbances, 2--100 quarters', ...
        '37\% / 42\%', @() local_asset(VAR, 'cj', 'equity'));
    T = local_row(T, 'Sec.\ 4.2', ...
        'Same, US / G6 10-year bond yields', ...
        '46\% / 53\%', @() local_asset(VAR, 'cj', 'yields'));
    T = local_row(T, 'Sec.\ 4.2', ...
        'Correlation of expected excess equity and currency returns, 2--100 quarters', ...
        '$-0.10$', @() local_retcorr(D, f, VAR, 'Expected Excess Equity Return Diff.'));
    T = local_row(T, 'Sec.\ 4.2', ...
        'Correlation of expected excess bond and currency returns, 2--100 quarters', ...
        '$-0.50$', @() local_retcorr(D, f, VAR, 'Expected Excess 10-Y Bond Return Diff.'));
    T = local_row(T, 'Sec.\ 4.2', ...
        'Share of expected excess equity / bond returns explained by the two disturbances, 6--32 quarters', ...
        'about 50\%', @() local_retshare(VAR, 3));
    T = local_row(T, 'Sec.\ 4.2', ...
        'Share of expected excess equity / bond returns explained by the two disturbances, 2--100 quarters', ...
        'not stated', @() local_retshare(VAR, 1));

    % ---- Section 4.3-4.6: shock series ----------------------------------------
    T = local_row(T, 'Sec.\ 4.3', ...
        'Correlation of $\Delta s_t$ due to technology and noise with the Stavrakeva--Tang news index', ...
        'approximately 40\% (2002--2018)', @() local_st(I, q));
    T = local_row(T, 'Sec.\ 4.3, fn.\ 18', ...
        'Correlation of the technology / noise disturbances with high-frequency US monetary policy shocks', ...
        'close to zero, insignificant', @() local_mp(I.base));
    T = local_row(T, 'Sec.\ 4.4', ...
        'Correlation of the disturbances with those of the VAR without the exchange rate: technology / noise', ...
        '99\% / 79\%', @() local_nofx(I));

    % ---- write -----------------------------------------------------------------
    lab  = ccdgv_prov_label(struct('info', D.info));
    St   = D.info.settings;
    prov = sprintf('%s, ndraws=%d, smax=%g', lab, St.ndraws, St.smax);
    fn   = fullfile(opt.outdir, 'tab_text_numbers.tex');
    local_write(fn, T, prov, 'Numbers quoted in the text', 'tab:text_numbers', 'Draft', ...
        ['Each number the draft states in its text that no table shows, in the ' ...
         'order the text states it. Responses are in percent, from the line Figures ' ...
         '1 and 2 draw. Variance shares are medians across draws, Both = Tech + ' ...
         'Noise. ' local_fsnote()]);
    fprintf('  wrote Tables/tab_text_numbers.tex\n');

    % ---- the second-round responses to the referees ----------------------------
    % Figures R1.1-R1.3 and R3.1-R3.2. The statements
    % about them are checked here, with the numbers the letters quote.
    R = cell(0, 5);
    R = local_row(R, 'R1, 3b', ...
        'Correlation of the disturbances with those of the VAR without the exchange rate, with bond yields: technology / noise (Figure R1.1)', ...
        '99\% / 75\%', @() local_corr(I, 'bynofx'));
    R = local_row(R, 'R1, 3b', ...
        'Same, with equity prices', ...
        '99\% / 26\%', @() local_corr(I, 'eqnofx'));
    R = local_row(R, 'R1, 3b', ...
        'Responses of the VAR without the exchange rate, with equity prices (Figure R1.2): share inside the baseline''s 16--84 band, technology / noise', ...
        'within estimation uncertainty', @() local_inband(D, I, 'eqnofx', false));
    R = local_row(R, 'R1, 3b', ...
        'Same, with bond yields (Figure R1.3)', ...
        'within estimation uncertainty', @() local_inband(D, I, 'bynofx', false));
    R = local_row(R, 'R3, 4', ...
        'Responses of the VAR with equity prices added (Figure R3.1): share inside the baseline''s 16--84 band, technology / noise', ...
        'within the credible sets throughout', @() local_inband(D, I, 'eq', true));
    R = local_row(R, 'R3, 4', ...
        'Same, with bond yields added (Figure R3.2)', ...
        'within the credible sets throughout', @() local_inband(D, I, 'by', true));
    R = local_row(R, 'R1, fn.\ 1', ...
        'Noise: first quarter after impact at which zero is inside the 16--84 band of the US / G6 equity price response', ...
        'around period 50', @() local_zero(D, {'US equity prices','G6 equity prices'}));
    R = local_row(R, 'R1, 3c; R3, 4', ...
        'Share of US / G6 equity prices explained by the two disturbances, 2--100 quarters', ...
        '37\% / 42\%', @() local_asset(VAR, 'cj', 'equity'));
    R = local_row(R, 'R1, 3c; R3, 4', ...
        'Same, US / G6 10-year bond yields', ...
        '46\% / 53\%', @() local_asset(VAR, 'cj', 'yields'));
    R = local_row(R, 'R1, 3d', ...
        'Share of the variance of US / G6 equity prices explained by the main exchange rate shock', ...
        '23\% / 27\%', @() local_asset(VAR, 'uhlig', 'equity'));
    R = local_row(R, 'R1, 3d', ...
        'Same, US / G6 10-year bond yields', ...
        '37\% / 41\%', @() local_asset(VAR, 'uhlig', 'yields'));
    fnR = fullfile(opt.outdir, 'tab_response_numbers.tex');
    local_write(fnR, R, prov, 'Numbers quoted in the responses to the referees', ...
        'tab:response_numbers', 'Letter', ...
        ['Each number the second-round responses state, by referee and comment ' ...
         '(R1 = Referee 1, R3 = Referee 3), with this run''s value. Statements ' ...
         'that a figure''s responses lie within the baseline''s uncertainty are ' ...
         'checked as the share of the alternative VAR''s median responses, over ' ...
         '$h = -20,\dots,20$ and the figure''s rows, that lie inside the baseline''s ' ...
         '16--84 band. The calibration numbers of the models (Referee 1, Comment 1) ' ...
         'are parameters, not estimates, and are not repeated. ' local_fsnote()]);
    fprintf('  wrote Tables/tab_response_numbers.tex\n');

    out = struct('rows', {T}, 'file', fn, 'response_rows', {R}, 'response_file', fnR);
    if opt.echo
        fprintf('\n  Numbers quoted in the text (%s)\n', lab);
        local_echo(T, 'draft');
        fprintf('\n  Numbers quoted in the responses to the referees\n');
        local_echo(R, 'letter');
    end
end

% =========================================================================
function local_echo(T, src)
    pl = @(x) strrep(strrep(x, '\%', '%'), '\ ', ' ');
    for k = 1:size(T,1)
        fprintf('    %-17s %-58.58s %s %-24.24s run %s\n', pl(T{k,1}), ...
                pl(T{k,2}), src, pl(T{k,3}), pl(T{k,4}));
    end
end

function T = local_row(T, where, what, draft, fh)
%   One row; a failure becomes "--" with the reason, not an error.
    try
        [val, how] = fh();
    catch e
        val = '--';
        how = ['not computed: ' local_esc(e.message)];
        warning('write_text_numbers:row', '%s -- %s', what, e.message);
    end
    T(end+1,:) = {where, what, draft, val, how};
end

function o = local_shares(base_info, opt)
%LOCAL_SHARES  The projected series' variance shares, per series.
%
%   Built from write_asset_proj_vd_table's `ext`, which carries the per-draw
%   arrays, rather than from the table's own summary matrices: those are shaped
%   per horizon for the FEV statistic and per band for the CJ one, so they are not
%   conformable with each other.
%
%   ext covers four series -- by_us, by_g6, eq_us, eq_g6. The expected-excess-
%   return rows are not among them, so the rows that ask for those report that the
%   number is unavailable rather than a wrong one.
%
%   `own` is one value per series: the share of the ACTUAL series at Q100, i.e.
%   the share of the projected series times the factor that converts it, median
%   across draws.
    % The ROOT, not opt.outdir -- this callee appends Tables/ itself. It writes the
    % same file exhibits writes directly, with the same content, so the repeat is
    % harmless; what was not harmless was writing it one directory deeper.
    V = write_asset_proj_vd_table(base_info, ...
            struct('echo', false, 'outdir', opt.exhibit_root, 'arlags', opt.arlags));
    E = V.ext;
    hQ = find(E.horizons == 100, 1);
    assert(~isempty(hQ), 'write_text_numbers:noQ100', ...
        'the shares are not computed at Q100 (horizons %s).', mat2str(E.horizons));
    o = struct();
    o.names = E.names;
    o.keys  = E.keys;
    o.r2    = E.r2;
    % internal x factor is the share of the ACTUAL series; the generator's own
    % local_stack forms the printed product the same way. The two are conformable
    % per statistic -- FEV by horizon, CJ by band -- but not with each other.
    o.uhlig_series = V.uhlig_internal .* V.uhlig_factor;   % nseries x nhorizon
    % cj_internal holds THREE columns per band -- Both, Tech, Noise -- so the
    % "Both" column for band k is 3k-2, i.e. columns 1:3:end. One factor per band
    % applies to all three, so the product is those columns times cj_factor.
    o.cj_series    = V.cj_internal(:, 1:3:end) .* V.cj_factor;   % nseries x nband
    % Without the factor: the factor rescales a share of the projection into a
    % share of the actual series, and the expected-return rows have no actual
    % series. See local_retshare.
    o.cj_projected = V.cj_internal(:, 1:3:end);                  % nseries x nband
    o.own          = o.uhlig_series(:, hQ);                % nseries x 1, at Q100
    o.bands = E.bands;
    o.horizons = E.horizons;
    o.ext   = E;
end

function v = local_try(fh)
% A row that cannot be computed reports why, rather than going quiet. The
% message reaches the table as the row's value, so a broken call is visible in
% the output instead of looking merely empty.
    try
        v = fh();
    catch e
        fprintf(2, '  write_text_numbers: %s failed -- %s\n', ...
                func2str(fh), e.message);
        v = e;
    end
end

% ---- Figure 1 ----------------------------------------------------------------
function [val, how] = local_halflife(D)
    x = local_fig1(D, 'Real Exchange Rate');
    [pk, kp] = max(abs(x));
    hp = find(abs(x(kp:end)) <= pk/2, 1) - 1;            % quarters after the peak
    hi = find(abs(x(kp:end)) <= abs(x(1))/2, 1) + kp - 2; % quarters after impact
    val = sprintf('%s from the peak; %s to half the impact', ...
                  local_years(hp, numel(x)-kp), local_years(hi, numel(x)-1));
    how = sprintf(['Figure 1''s line, peak at quarter %d. Time until it is half the ' ...
                   'peak; and from impact until it is half the impact response.'], kp - 1);
end

function [val, how] = local_tfppeak(D)
    x = local_fig1(D, 'Home TFP');
    [m, k] = max(x);
    val = sprintf('%.2f\\%% at quarter %d', m, k - 1);
    how = 'Figure 1''s line; quarter 0 is impact.';
end

function x = local_fig1(D, name)
    assert(isfield(D,'dataplots') && ~isempty(D.dataplots), ...
        'write_text_numbers:noUhlig', 'the run has no dataplots (max-share pass not run)');
    nv = numel(D.vnames);
    assert(size(D.dataplots,2) == 2*nv, 'write_text_numbers:dataplots', ...
        'dataplots is %d columns, expected 2 x %d', size(D.dataplots,2), nv);
    x = D.dataplots(:, nv + var_order(D.vnames, name), 1);
end

function s = local_years(q, cap)
    if isempty(q); s = sprintf('over %.1f years', cap/4); else; s = sprintf('%.1f years', q/4); end
end

% ---- Figure 2 ----------------------------------------------------------------
function [val, how] = local_fig2(D, which)
    h0 = (size(D.irtfp,1) + 1)/2;                     % t = 0
    iT = var_order(D.vnames, 'Home TFP');
    iE = var_order(D.vnames, 'E[TFP]');
    a  = local_line(cumsum(D.irtfp),   D);
    n  = local_line(cumsum(D.irnoise), D);
    switch which
        case 'tech_pre';  val = sprintf('%.2f\\%%', a(h0-20, iE));
        case 'tech_tfp0'; val = sprintf('%.2f\\%%', a(h0, iT));
        case 'ratio';     val = sprintf('%.0f\\%%', 100*a(h0-20, iE)/a(h0, iT));
        case 'noise_e0';  val = sprintf('%.2f\\%%', n(h0, iE));
    end
    how = 'Figure 2''s line.';
end

function m = local_line(x, D)
    if D.point_estimate; m = x(:,:,end); else; m = median(x, 3); end
end

% ---- anticipation (vstfp_real) -------------------------------------------------
function [val, how] = local_anticipation(D)
    assert(isfield(D,'vstfp_real'), 'write_text_numbers:noReal', ...
        'this run has no vstfp_real -- it predates b131a1f. Re-run run_main for the baseline.');
    local_band(D, 1, [2 100]);
    i    = var_order(D.vnames, 'Real Exchange Rate');
    tot  = median(D.vstfp(i,1,:), 3);
    post = median(D.vstfp_real(i,:), 2);
    val  = sprintf('%.0f\\%% vs %.0f\\%%', 100*(tot - post), 100*post);
    how  = sprintf(['vstfp\\_real (current and past technology shocks) is the at-and-' ...
                    'after share; before is Table 2''s technology share (%.0f\\%%) minus it.'], ...
                   100*tot);
end

function local_band(D, b, per)
    got = sort(round(2*pi ./ D.vd_fr(b,:)));
    assert(isequal(got, per), 'write_text_numbers:band', ...
        'vd_fr row %d is %d-%d quarters, expected %d-%d', b, got, per);
end

% ---- Table 3 ratios -------------------------------------------------------------
function [val, how] = local_moment(o, field)
    if isa(o, 'MException'); rethrow(o); end
    r = strcmp(o.rows, field);
    assert(any(r), 'write_text_numbers:noMoment', '%s not in Table 3', field);
    both = o.M(r,3);  unc = o.M(r,4);
    val  = sprintf('%.0f\\%% ($%.2f$ of $%.2f$)', 100*both/unc, both, unc);
    how  = 'Table 3: Both over Unconditional.';
end

% ---- projected series: the four first stages -------------------------------------
function [val, how] = local_asset(o, which, asset)
    if isa(o, 'MException'); rethrow(o); end
    pair = extra_asset_rows(asset);
    k    = var_order(o.names, pair{:});
    % k names TWO series (US and G6), so the row reports both.
    switch which
        case 'uhlig'
            hQ  = find(o.horizons == 100, 1);
            v   = o.uhlig_series(k, hQ);
            how = 'Max-share FEV at 100 quarters, of the actual series.';
        case 'cj'
            v   = o.cj_series(k, local_bandcol(o, 1));
            how = 'Both, 2--100 quarters, of the actual series.';
    end
    val = sprintf('%.0f\\%% / %.0f\\%%', 100*v(1), 100*v(2));
end

function [val, how] = local_retshare(o, b)
%   b: vd_fr row -- 1 = 2-100 quarters, 3 = 6-32 quarters
    if isa(o, 'MException'); rethrow(o); end
    want = {'Expected Excess Equity Return Diff.', ...
            'Expected Excess 10-Y Bond Return Diff.'};
    % Guard rather than assert: if the shares generator's series list is ever
    % narrowed again, the row says so instead of reporting someone else's number.
    if ~all(ismember(want, o.names))
        val = 'not available';
        per = {'2--100', '', '6--32'};
        how = sprintf(['Both, %s quarters, of the expected return. The ' ...
                       'variance-share generator does not cover these two ' ...
                       'series, so there is nothing to report.'], per{b});
        return
    end
    k   = var_order(o.names, want{:});
    % NO FACTOR HERE, unlike the asset-price rows. The factor converts a share of
    % the projection into a share of the actual series; an expected excess return
    % has no actual series -- it IS the projection, the residual being the return
    % surprise -- so the share of the projection is the statistic.
    v   = o.cj_projected(k, local_bandcol(o, b));
    val = sprintf('%.0f\\%% / %.0f\\%%', 100*v(1), 100*v(2));
    per = {'2--100', '', '6--32'};
    how = sprintf(['Both, %s quarters, of the expected return, which is the first ' ...
                   'stage''s fitted value -- the residual is the return surprise, so ' ...
                   'no projection-to-actual factor applies.'], per{b});
end

function [val, how] = local_retcorr(D, f, o, name)
%   Correlation, over 2-100 quarter periodicities, of the parts of the two
%   returns driven by the two disturbances, under each first stage. Only the
%   equity / bond row is projected; the currency return is built from the VAR's
%   own rows. The projection residual is orthogonal to every VAR shock, so it
%   does not enter.
%
%   Band covariance from the level responses' Fourier transforms (Parseval):
%   cov = sum over the band's frequencies, both halves, of Re(X conj(Y)), for
%   technology plus noise; the same for the two variances. Zero-padded to 2^13
%   points so the band edges are resolved; the normalisation cancels.
    if isa(o, 'MException'); rethrow(o); end
    local_band(D, 1, [2 100]);
    ix = var_order(D.vnames, name);
    ic = var_order(D.vnames, 'Expected Excess Returns');
    nf  = 2^13;
    lam = 2*pi*(0:nf-1)'/nf;
    bb  = D.vd_fr(1,:);
    in  = @(l) l >= bb(1) & l <= bb(2);
    m   = in(lam) | in(2*pi - lam);
    F   = @(x) fft(reshape(x, size(x,1), []), nf, 1);
    % One projection stage, so one number. The run file already holds it.
    nd = size(D.irtfp,3) - 1;                          % the posterior draws
    a  = cumsum(D.irtfp(:,:,1:nd));  n = cumsum(D.irnoise(:,:,1:nd));
    Ax = F(a(:,ix,:));  Ac = F(a(:,ic,:));  Nx = F(n(:,ix,:));  Nc = F(n(:,ic,:));
    Ax = Ax(m,:);  Ac = Ac(m,:);  Nx = Nx(m,:);  Nc = Nc(m,:);
    cxy = real(sum(Ax.*conj(Ac) + Nx.*conj(Nc), 1));
    vx  = sum(abs(Ax).^2 + abs(Nx).^2, 1);
    vc  = sum(abs(Ac).^2 + abs(Nc).^2, 1);
    own = median(cxy ./ sqrt(vx .* vc));
    val = sprintf('$%.2f$', own);
    how = ['Implied by the two disturbances over 2--100 quarter periodicities ' ...
           '(band covariance of the level responses); median across draws. The ' ...
           'projection residual is orthogonal to the shocks and does not enter.'];
end

function c = local_bandcol(o, b)
    c = find(o.bands == b, 1);
    assert(~isempty(c), 'write_text_numbers:band', 'band %d not computed', b);
end

function [val, how] = local_st(I, q)
    o   = write_st_news_table(I.extend, q);
    val = sprintf('%.2f (%s, %d quarters)', o.corr(1), o.span, o.nobs);
    how = 'tab\_st\_news, first row; the extended-sample run.';
end

function [val, how] = local_mp(base)
    S  = infer_shocks(base);
    fx = raw_path('CCDGV', 'HFMP_Jarocinski_Karadi.xls');
    assert(isfile(fx), 'write_text_numbers:noHFMP', '%s not found', fx);
    M  = readmatrix(fx, 'Sheet', 'For Matlab');        % year | month | ff4_hf
    M  = M(all(isfinite(M(:,1:2)), 2), :);
    qk = M(:,1)*4 + ceil(M(:,2)/3) - 1;                 % quarter key = round(date*4)
    [uk, ~, g] = unique(qk);
    mp = accumarray(g, M(:,3), [], @(v) sum(v(isfinite(v))));   % quarterly sum
    sk = round(S.dates(:)*4);
    [kk, ia, ib] = intersect(sk, uk);
    assert(numel(kk) >= 8, 'write_text_numbers:mpOverlap', ...
        'only %d quarters shared with the monetary policy shocks', numel(kk));
    [Rt, Pt] = corrcoef(S.ehat_tfp(ia),   mp(ib));
    [Rn, Pn] = corrcoef(S.ehat_noise(ia), mp(ib));
    val = sprintf('$%.2f$ ($p=%.2f$) / $%.2f$ ($p=%.2f$), %s--%s, %d quarters', ...
                  Rt(1,2), Pt(1,2), Rn(1,2), Pn(1,2), ...
                  local_q(kk(1)), local_q(kk(end)), numel(kk));
    how = ['ff4\_hf, the Gertler--Karadi fed funds futures surprise, from the ' ...
           'Jarocinski--Karadi file in Raw\_Data, summed within the quarter.'];
end

function [val, how] = local_nofx(I)
    assert(isfield(I,'nofx') && ~isempty(I.nofx), 'write_text_numbers:noNofx', ...
        'sweep_infos has no nofx');
    R1 = shock_corr_spec(I.base, I.nofx, struct('echo', false));
    R2 = shock_corr_spec(I.base, I.base, struct('echo', false, ...
            'infer_alt', struct('restricted', true, 'nofx_info', I.nofx)));
    val = sprintf('%.0f\\%% / %.0f\\%% re-estimated; %.0f\\%% / %.0f\\%% implied', ...
                  100*R1.rho_tfp, 100*R1.rho_noise, 100*R2.rho_tfp, 100*R2.rho_noise);
    how = ['tab\_shock\_corr, rows ``No exchange rate'''' and its implied version ' ...
           '(the baseline''s VAR restricted to the other variables).'];
end

function [val, how] = local_corr(I, key)
    assert(isfield(I, key) && ~isempty(I.(key)), 'write_text_numbers:noSpec', ...
        'sweep_infos has no %s', key);
    R = shock_corr_spec(I.base, I.(key), struct('echo', false));
    val = sprintf('%.0f\\%% / %.0f\\%%', 100*R.rho_tfp, 100*R.rho_noise);
    how = sprintf('shock\\_corr\\_spec(base, %s); %d shared quarters.', key, R.n);
end

function [val, how] = local_inband(D, I, key, withfx)
%   Share of (row, h) points, h = -20..20, at which the alternative run's median
%   response lies inside the baseline's [bound, 1-bound] band.
    assert(isfield(I, key) && ~isempty(I.(key)), 'write_text_numbers:noSpec', ...
        'sweep_infos has no %s', key);
    [~, fa] = data_name(I.(key));
    A = load(fa, 'irtfp', 'irnoise', 'vnames');
    rows = {'Home TFP','E[TFP]','Home Consumption','Foreign Consumption', ...
            'Interest Rate Differential'};
    if withfx; rows{end+1} = 'Real Exchange Rate'; end
    sh = NaN(1,2);
    for s = 1:2
        if s == 1; xb = D.irtfp; xa = A.irtfp; else; xb = D.irnoise; xa = A.irnoise; end
        rr = rows;  if s == 2; rr = rows(2:end); end    % noise: Home TFP is zero by construction
        ib = var_order(D.vnames, rr{:});  ia = var_order(A.vnames, rr{:});
        wb = (size(xb,1)+1)/2 + (-20:20);  wa = (size(xa,1)+1)/2 + (-20:20);
        b  = cumsum(xb(:, ib, :));  b = b(wb,:,:);
        a  = cumsum(xa(:, ia, :));  a = median(a(wa,:,:), 3);
        lo = quantile(b, D.bound, 3);  hi = quantile(b, 1 - D.bound, 3);
        in = a >= lo & a <= hi;
        sh(s) = mean(in(:));
    end
    val = sprintf('%.0f\\%% / %.0f\\%%', 100*sh(1), 100*sh(2));
    how = sprintf('Median of %s against the baseline''s %g--%g band, $h=-20..20$, %d rows.', ...
                  key, 100*D.bound, 100*(1-D.bound), numel(rows));
end

function [val, how] = local_zero(D, names)
    i  = var_order(D.vnames, names{:});
    h0 = (size(D.irnoise,1)+1)/2;
    x  = cumsum(D.irnoise(:, i, :));
    lo = quantile(x(h0+1:end,:,:), D.bound, 3);
    hi = quantile(x(h0+1:end,:,:), 1 - D.bound, 3);
    q  = NaN(1, numel(i));
    for k = 1:numel(i)
        j = find(lo(:,k) <= 0 & hi(:,k) >= 0, 1);
        if ~isempty(j); q(k) = j; end
    end
    f = @(v) local_ifnan(v, size(x,1) - h0);
    val = sprintf('quarter %s / %s', f(q(1)), f(q(2)));
    how = sprintf('The projected rows of the baseline, %g--%g band; quarter 0 is impact.', ...
                  100*D.bound, 100*(1-D.bound));
end

function s = local_ifnan(v, cap)
    if isnan(v); s = sprintf('beyond %d', cap); else; s = sprintf('%d', v); end
end

function s = local_fsnote()
    s = ['A number that involves a series projected on the VAR is given under the ' ...
         'same five first stages as the by-first-stage figures: (1) OLS on the full ' ...
         'companion state and (2) OLS on $y_t$ only, both FIXED point estimates; and ' ...
         '(3) AR(2), (4) AR(3), (5) AR(4), all DRAWN at $\lambda = 0$ -- one ' ...
         'projection per VAR draw, differing only in the AR order assumed for the ' ...
         'projection residual, so only these three carry first-stage uncertainty. ' ...
         'Variance shares are of the series itself: writing $y = \hat{y} + \mu$ with ' ...
         '$\mu$ orthogonal to the companion state, each line divides by ITS OWN ' ...
         'implied $V(y) = V(\hat{y}) + V(\mu)$, measured the same way as the share ' ...
         'and with $\mu$ refitted on that stage''s residual.'];
end

function s = local_q(k)
    s = sprintf('%dQ%d', floor(k/4), mod(k,4) + 1);
end

% ---- LaTeX ------------------------------------------------------------------------
function local_write(fn, T, prov, title, label, srccol, note)
    fid = fopen(fn, 'w');  c = onCleanup(@() fclose(fid));
    fprintf(fid, '%% Generated by write_text_numbers.m -- do not edit by hand.\n%% %s\n', prov);
    fprintf(fid, '\\begin{table}[htbp]\n\\centering\\scriptsize\\setlength{\\tabcolsep}{4pt}\n');
    fprintf(fid, '\\caption{%s}\n\\label{%s}\n', title, label);
    fprintf(fid, ['\\begin{tabular}{>{\\raggedright\\arraybackslash}p{1.1cm} ' ...
                  '>{\\raggedright\\arraybackslash}p{4.6cm} ' ...
                  '>{\\raggedright\\arraybackslash}p{2.1cm} ' ...
                  '>{\\raggedright\\arraybackslash}p{3.6cm} ' ...
                  '>{\\raggedright\\arraybackslash}p{4.4cm}}\n\\hline\n']);
    fprintf(fid, 'Where & Statement & %s & This run & How \\\\ \\hline\n', srccol);
    for k = 1:size(T,1)
        fprintf(fid, '%s & %s & %s & %s & %s \\\\ \\hline\n', T{k,:});
    end
    fprintf(fid, '\\end{tabular}\n');
    fprintf(fid, '\\caption*{\\footnotesize \\emph{Notes:} %s Run: %s.}\n', note, local_esc(prov));
    fprintf(fid, '\\end{table}\n');
end

function s = local_esc(s)
    s = strrep(s, '\', '/');
    s = strrep(s, '_', '\_');  s = strrep(s, '%', '\%');
    s = strrep(s, '&', '\&');  s = strrep(s, '#', '\#');
    s = strrep(s, '$', '\$');
end
