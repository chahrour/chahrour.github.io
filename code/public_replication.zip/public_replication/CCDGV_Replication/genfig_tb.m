function fout = genfig_tb(base_info, dest, opt)
%GENFIG_TB  Figure C.5: responses of the trade balance to technology and noise.
%
%   fout = GENFIG_TB(base_info, dest)
%
%   base_info  descriptor of the baseline run
%   dest       output directory (required)
%   fout       the figure handle
%
%   Two panels (technology, noise) of the U.S./G6 goods trade balance in percent
%   of GDP. The series is outside the baseline VAR; its response is the
%   projection of the series on the VAR's state.
%
%   See also GENFIG_C14, PLOTIRF.

    assert(nargin >= 2 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end

    % sfx is a file-name suffix; it is always empty.
    sfx = '';

    % The level responses on horizons -20:20, for the trade-balance row.
    [dt, dn, vnames] = cj_bands(base_info);
    i  = var_order(vnames, 'U.S./G6 Trade Balance');
    fout = local_draw(dt(:,i,:), dn(:,i,:), ['FigureC5' sfx], dest);
end

% -------------------------------------------------------------------------
function f = local_draw(dt, dn, nm, dest)

    % plotIRF reads the second half of the data columns, so the two shocks are
    % laid out as two "variables" and duplicated into columns 3:4.
    d = NaN(size(dt,1), 4, 5);
    d(:,[1 3],:) = repmat(dt(:,1,:), 1, 2);
    d(:,[2 4],:) = repmat(dn(:,1,:), 1, 2);

    p = plotIRF;
    p.nrow = 1;  p.ncol = 2;
    p.NOISE = [0 1];                                   % technology blue, noise red
    p.position = [1 1 4/3*425 4/3*425/3];
    p.ylab = {{'U.S./G6 Trade Balance';'(\% of GDP)'}, ''};
    fB = plotIRF(d, [1;2], {'Technology','Noise'}, nm, [1 2], p);
    exportgraphics(fB(1), fullfile(dest, [nm '.pdf']));
    f = fB(1);
    fprintf('  wrote %s.pdf\n', nm);
end

