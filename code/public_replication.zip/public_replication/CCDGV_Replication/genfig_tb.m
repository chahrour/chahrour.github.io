function fout = genfig_tb(base_info, dest, opt)
%GENFIG_TB  Technology, noise and the trade balance (draft Figure B.5).
%
%   fout = GENFIG_TB(base_info)
%   fout = GENFIG_TB(base_info, dest)
%   fout = GENFIG_TB(base_info, dest, opt)
%   Two figures, each two panels (technology, noise), of the U.S./G6 goods trade
%   balance in percent of GDP. They differ in WHICH series is projected on the
%   companion state:
%
%     TB_IRFs_diff_new  the paper's construction. The quarterly CHANGE in TB/GDP
%                       (manifest row dtb_g6) is projected, and its response is
%                       added up from h = -20, so the plotted level is zero
%                       just before h = -20.
%     TB_IRFs_new       the LEVEL of TB/GDP (row tb_g6) is projected; its
%                       response is the running sum of the stored
%                       first-difference response, as for every other panel.
%
%   WHICH ONE TO USE: TB_IRFs_new, the level-projected panel. It is the one on
%   the common convention. TB_IRFs_diff_new's baseline is an exception -- it
%   sums from h = -20 rather than from the start of the stored window -- and
%   putting it on the common convention shifts the whole path up about 0.05% of
%   GDP without changing its shape, because the second sum then accumulates 230
%   extra quarters of anticipation whose per-quarter size is near the noise
%   floor. Measured 2026-10-08; the exception is left in place deliberately.
%
%   The two are different regressions, not one regression drawn two ways:
%   projecting the level on a trending levels state mostly fits the trend.
%   Both series are outside the baseline VAR -- read with the projections' r2.
%
%   See also GENFIG_B14, PLOTIRF.

    assert(nargin >= 2 && ~isempty(dest), [mfilename ':noDest'], 'dest is required: the directory to write into.');
    if ~endsWith(dest, filesep); dest = [dest filesep]; end
    if ~isfolder(dest); mkdir(dest); end

    [~, f] = data_name(base_info);
    assert(isfile(f), 'genfig_tb:noFile', '%s not found', f);
    D = load(f, 'irtfp','irnoise','vnames','point_estimate','bound','bound2');
    % One projection stage, so the run file holds the only one there is.
    sfx = '';

    h = (size(D.irtfp,1)-1)/2;

    % LEVEL projected: the running sum of the stored response, plotted -20:20
    i  = var_order(D.vnames, 'U.S./G6 Trade Balance');
    hgrid = -50:20;  discard = 30;
    dt = pack_bands(cumsum(D.irtfp(:,i,:)),   hgrid+h+1, discard, D);
    dn = pack_bands(cumsum(D.irnoise(:,i,:)), hgrid+h+1, discard, D);
    fout(1) = local_draw(dt, dn, ['TB_IRFs_new' sfx], dest);

    % CHANGE projected: cumsum once gives the response of the change; adding
    % that up over -20:20 gives the level, zero before h = -20.
    j  = var_order(D.vnames, 'U.S./G6 Trade Balance (change)');
    w  = (-20:20) + h + 1;
    ct = cumsum(D.irtfp(:,j,:));    ct = cumsum(ct(w,:,:));
    cn = cumsum(D.irnoise(:,j,:));  cn = cumsum(cn(w,:,:));
    dt = pack_bands(ct, 1:numel(w), 0, D);
    dn = pack_bands(cn, 1:numel(w), 0, D);
    fout(2) = local_draw(dt, dn, ['TB_IRFs_diff_new' sfx], dest);
end

% -------------------------------------------------------------------------
function f = local_draw(dt, dn, nm, dest)

    % plotIRF takes its panels from VARS and reads the second half of DATA, so
    % the two SHOCKS are laid out as two "variables", duplicated into 3:4.
    d = NaN(size(dt,1), 4, 5);
    d(:,[1 3],:) = repmat(dt(:,1,:), 1, 2);
    d(:,[2 4],:) = repmat(dn(:,1,:), 1, 2);

    p = plotIRF;
    p.nrow = 1;  p.ncol = 2;
    p.NOISE = [0 1];                                   % technology blue, noise red
    p.position = [1 1 4/3*425 4/3*425/3];
    p.ylab = {{'U.S./G6 Trade Balance';'(\% of GDP)'}, ''};
    fB = plotIRF(d, [1;2], {'Technology','Noise'}, nm, [1 2], p);
    exportgraphics(fB(1), fullfile(dest, [nm '.pdf']));
    f = fB(1);
    fprintf('  wrote %s.pdf\n', nm);
end

