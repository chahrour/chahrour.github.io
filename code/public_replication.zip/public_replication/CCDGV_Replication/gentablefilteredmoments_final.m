function R = gentablefilteredmoments_final(datam, opt)
%GENTABLEFILTEREDMOMENTS_FINAL  The three BAND-FILTERED rows of Table 3.
%
%   R = GENTABLEFILTEREDMOMENTS_FINAL(DATAM, OPT)
%
%   Table 3 is a COMPOSITE of two generators. Its own note says so:
%
%     "The moments including Engel beta_Lambda, cov(sum E_t lambda, r-r*), and
%      rho(q_t) are computed on the data filtered over [2--100] quarter
%      periodicities."
%
%   Those three rows come from here; the other seven from
%   gentablemoments_final. Function rewrite of gentablefilteredmoments.m, which
%   stays on disk as the reference.
%
%   RETURNS (each with .tfp / .noise / .comp / .var)
%     R.stats.beta_engel   covengel / var_rrdiff, all band-filtered
%     R.stats.cov_engel    -cov(RER(Ex.Ret), r-r*) over the band
%     R.stats.rho_qt       first-order autocorrelation of q over the band
%
%   TWO THINGS FIXED, both of which the original coupled together.
%
%   1. THE `A` AUGMENTATION IS GONE. The original appends ten rows to A -- via a
%      ~40-line block building term_2pastcumeret with its own 500-term series and
%      a near-unit-root branch -- of which the published moments read NONE. They
%      use only orer, orrdiff and ocumeret. The rows existed because
%      vdfilter_horizons preallocated `Vy_h = zeros(nx,nx,...)` while assigning a
%      size(A,1) x size(A,1) result: 26x26 into 32x32. The augmentation padded A
%      to exactly nx so the assignment would fit.
%
%      That coupling IS the "not dimension-generic (40x40 vs 34x34)" failure
%      recorded in GAP_REPORT, and why tab03_filtered is missing from the equity
%      run cases: on an equity layout nx = 40 and the padding no longer lands.
%
%      Preallocating size(A,1) instead removes the need for any of it. Safe
%      because row i of T1 = A*(I-Be^{-iw})^{-1}*C depends only on row i of A, so
%      appending rows adds rows and columns but cannot change existing entries --
%      verified directly, max|diff| = 0 on the shared block.
%
%   2. INDICES RESOLVED BY NAME (ccdgv_moment_vars), as in gentablemoments_final.
%      The original hard-codes orer/orrdiff/ocumeret, which shift by +2 on an
%      equity layout and silently select ECPIDIFF / ENER / $\Delta$BS Wedge.
%
%   SPEED. The original evaluates six adaptive `integral(...,'ArrayValued',true)`
%   calls per draw, each recomputing T1 and T2 separately at every quadrature
%   node -- roughly 20 minutes over 1000 draws. Here the resolvent is swept
%   grid-at-once with tf_sweep and the horizon weights applied with pagemtimes,
%   the same treatment vdfilter_rp received. T2 = conj(T1) for real A, B, C.
%
%   OPT  .max_per  upper periodicity of the band, default 100 -> [2, 100]
%        .ngrid    quadrature nodes, default 4000
%        .pp       percentile for the bands, default 16
%
%   See also GENTABLEMOMENTS_FINAL, WRITE_MOMENTS_TABLE, COV_FILT, TF_SWEEP.

    if nargin < 2; opt = struct(); end
    if ~isfield(opt,'max_per'); opt.max_per = 100;  end
    if ~isfield(opt,'ngrid');   opt.ngrid   = 4000; end
    if ~isfield(opt,'pp');      opt.pp      = 16;   end

    if isstruct(datam)
        D = datam; cname = 'struct';
    else
        % datam is the path itself -- callers pass data_name(info). The old
        % sweep_datam indirection (an env var read inside the function) is gone.
        D = load(datam); cname = datam;
        % run_main SAVES irtfp/irnoise on +/-smax_store only; these moments need
        % the full +/-smax, which exists only in memory there. It computes them
        % and saves them as `moments`/`filtered_moments` -- read those instead.
        if isfield(D,'info') && isfield(D,'irtfp')
            assert(size(D.irtfp,1) == 2*D.info.settings.smax+1, 'gentablefilteredmoments_final:window', ...
                ['%s stores responses on +/-%d quarters, short of smax = %d; the ' ...
                 'moments need the full length. Re-run run_main for this case.'], ...
                datam, (size(D.irtfp,1)-1)/2, D.info.settings.smax);
        end
    end
    for f = {'ARs','Sigs','irtfp','irnoise','j_cj_horizon','vnames','Aproj','keys'}
        assert(isfield(D,f{1}), 'gentablefilteredmoments_final:missing', ...
               '%s not in the case file.', f{1});
    end

    ix = ccdgv_moment_vars(D.vnames);
    NEED = {'rer','rrdiff','cumeret'};
    skipped = {};
    for f = NEED
        if isnan(ix.(f{1})); skipped(end+1,:) = {'filtered', f{1}}; end %#ok<AGROW>
    end

    Aproj = D.Aproj; keys = D.keys;   % projections + their names, from the run
    ARs = D.ARs; Sigs = D.Sigs;
    irtfp_all = D.irtfp; irnoise_all = D.irnoise;
    j_cj = D.j_cj_horizon;
    NN = numel(ARs);
    [k, nxx] = size(ARs{1}); nlags = nxx/k;
    mp = opt.max_per; ng = opt.ngrid;

    if ~isempty(skipped)
        warning('gentablefilteredmoments_final:skipped', ...
            'filtered moments skipped -- layout lacks: %s', strjoin(skipped(:,2)',', '));
        z = NaN(1,NN);
        S = struct('beta_engel',blank(z),'cov_engel',blank(z),'rho_qt',blank(z));
        R = struct('stats',S,'skipped',{skipped},'ix',ix,'pp',opt.pp, ...
                   'meta',struct('ndraws',NN-1,'case',cname,'max_per',mp));
        return
    end

    i_rer = ix.rer; i_rrdiff = ix.rrdiff; i_cumeret = ix.cumeret;

    ce_v=NaN(1,NN); ce_t=NaN(1,NN); ce_n=NaN(1,NN); ce_c=NaN(1,NN);
    vr_v=NaN(1,NN); vr_t=NaN(1,NN); vr_n=NaN(1,NN); vr_c=NaN(1,NN);
    rq_v=NaN(1,NN); rq_t=NaN(1,NN); rq_n=NaN(1,NN); rq_c=NaN(1,NN);

    parfor bb = 1:NN
        AR = ARs{bb}; Sig = Sigs{bb};
        nx = size(AR,2);
        B  = [AR;[eye(nx-k),zeros(nx-k,k)]];
        At = chol(Sig)';
        C  = [At; zeros(nx-k,k)];
        [A,~,~,~,~,~] = gen_auxvars(AR',Aproj,keys,k,nlags,j_cj);

        % unconditional, band-filtered, at horizons 0 and 1
        Vf = vdh_fast(B, C, A, [2*pi/mp, 2*pi/2], [0 1], ng);

        % conditional: band-pass the cumulated IRFs (cov_filt, DSGE_tools)
        Ct = cov_filt(flip(cumsum(irtfp_all(:,:,bb))),   mp);
        Cn = cov_filt(flip(cumsum(irnoise_all(:,:,bb))), mp);
        Cc = Ct + Cn;

        ce_v(bb) = -Vf(i_cumeret,i_rrdiff,1);
        ce_t(bb) = -Ct(i_cumeret,i_rrdiff,1);
        ce_n(bb) = -Cn(i_cumeret,i_rrdiff,1);
        ce_c(bb) = -Cc(i_cumeret,i_rrdiff,1);

        vr_v(bb) = Vf(i_rrdiff,i_rrdiff,1);
        vr_t(bb) = Ct(i_rrdiff,i_rrdiff,1);
        vr_n(bb) = Cn(i_rrdiff,i_rrdiff,1);
        vr_c(bb) = Cc(i_rrdiff,i_rrdiff,1);

        rq_v(bb) = Vf(i_rer,i_rer,2)/Vf(i_rer,i_rer,1);
        rq_t(bb) = Ct(i_rer,i_rer,2)/Ct(i_rer,i_rer,1);
        rq_n(bb) = Cn(i_rer,i_rer,2)/Cn(i_rer,i_rer,1);
        rq_c(bb) = Cc(i_rer,i_rer,2)/Cc(i_rer,i_rer,1);
    end

    S = struct();
    S.cov_engel  = struct('tfp',ce_t,'noise',ce_n,'comp',ce_c,'var',ce_v);
    S.beta_engel = struct('tfp',ce_t./vr_t,'noise',ce_n./vr_n, ...
                          'comp',ce_c./vr_c,'var',ce_v./vr_v);
    S.rho_qt     = struct('tfp',rq_t,'noise',rq_n,'comp',rq_c,'var',rq_v);

    R = struct('stats',S,'skipped',{skipped},'ix',ix,'pp',opt.pp, ...
               'meta',struct('ndraws',NN-1,'nvars',k,'nlags',nlags, ...
                             'case',cname,'max_per',mp,'ngrid',ng));
end

% -------------------------------------------------------------------------
function Vy = vdh_fast(B, C, A, lam, horizons, ng)
%VDH_FAST  Band-filtered covariance of A*(I-BL)^-1*C at the given horizons.
%   Vectorized replacement for the original's vdfilter_horizons. Two changes:
%   preallocates size(A,1) (not nx -- see the header), and evaluates the whole
%   band in one tf_sweep instead of six adaptive integrals per draw.
%
%       Vy(:,:,h) = 2*Re integral_lam1^lam2 (1/2pi) T1(w) T1(w)^H e^{i w h} dw
%
%   using T2 = conj(T1) for real A, B, C, exactly as in vdfilter_rp.
    ny = size(A,1);
    lamg = linspace(lam(1), lam(2), ng);
    wq   = zeros(1,ng);
    wq(2:ng-1) = (lamg(3:ng)-lamg(1:ng-2))/2;
    wq(1)      = (lamg(2)-lamg(1))/2;
    wq(ng)     = (lamg(ng)-lamg(ng-1))/2;

    T1 = tf_sweep(A, B, C, exp(-1i*lamg));            % ny x ne x ng
    P  = pagemtimes(T1,'none',T1,'ctranspose');       % ny x ny x ng

    Vy = zeros(ny, ny, numel(horizons));
    for kk = 1:numel(horizons)
        w = reshape(wq .* exp(1i*lamg*horizons(kk)), 1, 1, ng);
        Vy(:,:,kk) = 2*real(sum(P .* w, 3))/(2*pi);
    end
end

function s = blank(z)
    s = struct('tfp',z,'noise',z,'comp',z,'var',z);
end
