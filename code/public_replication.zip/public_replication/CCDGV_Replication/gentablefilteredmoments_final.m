function R = gentablefilteredmoments_final(datam, opt)
%GENTABLEFILTEREDMOMENTS_FINAL  The three band-filtered moments of Table 3.
%
%   R = GENTABLEFILTEREDMOMENTS_FINAL(DATAM, OPT)
%
%   Computes the Engel beta, cov(sum E_t lambda, r-r*) and rho(q_t) on data
%   filtered over [2, max_per]-quarter periodicities. The other rows of Table 3
%   come from gentablemoments_final.
%
%   DATAM  struct holding ARs, Sigs, irtfp, irnoise, j_cj_horizon, vnames, Aproj
%          and keys, or the path of a .mat with those variables. irtfp and
%          irnoise must span the full +/-smax quarters.
%   OPT    .max_per  upper periodicity of the band (default 100)
%          .ngrid    quadrature nodes (default 4000)
%          .pp       percentile for the bands (default 16)
%
%   R.stats, each with .tfp / .noise / .comp / .var, 1 x ndraws+1:
%     beta_engel   cov_engel / var(r-r*), band-filtered
%     cov_engel    -cov(RER(Ex.Ret), r-r*) over the band
%     rho_qt       first-order autocorrelation of q over the band
%   R.skipped lists the variables the layout lacks; the stats are then NaN.
%
%   Variables are found by name through ccdgv_moment_vars.
%
%   See also GENTABLEMOMENTS_FINAL, WRITE_MOMENTS_TABLE, COV_FILT, TF_SWEEP.

    if nargin < 2; opt = struct(); end
    if ~isfield(opt,'max_per'); opt.max_per = 100;  end
    if ~isfield(opt,'ngrid');   opt.ngrid   = 4000; end
    if ~isfield(opt,'pp');      opt.pp      = 16;   end

    if isstruct(datam)
        D = datam; cname = 'struct';
    else
        D = load(datam); cname = datam;
        % The moments need responses on the full +/-smax quarters. A saved run
        % stores a shorter window; run_main computes these moments in memory
        % and saves them as filtered_moments.
        if isfield(D,'info') && isfield(D,'irtfp')
            assert(size(D.irtfp,1) == 2*D.info.settings.smax+1, 'gentablefilteredmoments_final:window', ...
                ['%s stores responses on +/-%d quarters, short of smax = %d; the ' ...
                 'moments need the full length. Re-run run_main for this case.'], ...
                datam, (size(D.irtfp,1)-1)/2, D.info.settings.smax);
        end
    end
    for f = {'ARs','Sigs','irtfp','irnoise','j_cj_horizon','vnames','Aproj','keys'}
        assert(isfield(D,f{1}), 'gentablefilteredmoments_final:missing', ...
               '%s not in the case file.', f{1});
    end

    % Find the three variables by name; note any the layout lacks.
    ix = ccdgv_moment_vars(D.vnames);
    NEED = {'rer','rrdiff','cumeret'};
    skipped = {};
    for f = NEED
        if isnan(ix.(f{1})); skipped(end+1,:) = {'filtered', f{1}}; end %#ok<AGROW>
    end

    Aproj = D.Aproj; keys = D.keys;   % projections and their names, from the run
    ARs = D.ARs; Sigs = D.Sigs;
    irtfp_all = D.irtfp; irnoise_all = D.irnoise;
    j_cj = D.j_cj_horizon;
    NN = numel(ARs);
    [k, nxx] = size(ARs{1}); nlags = nxx/k;
    mp = opt.max_per; ng = opt.ngrid;

    % Without the variables, return NaN stats.
    if ~isempty(skipped)
        warning('gentablefilteredmoments_final:skipped', ...
            'filtered moments skipped -- layout lacks: %s', strjoin(skipped(:,2)',', '));
        z = NaN(1,NN);
        S = struct('beta_engel',blank(z),'cov_engel',blank(z),'rho_qt',blank(z));
        R = struct('stats',S,'skipped',{skipped},'ix',ix,'pp',opt.pp, ...
                   'meta',struct('ndraws',NN-1,'case',cname,'max_per',mp));
        return
    end

    i_rer = ix.rer; i_rrdiff = ix.rrdiff; i_cumeret = ix.cumeret;

    % Per-draw accumulators: cov_engel (ce), var(r-r*) (vr), rho_q (rq), each
    % unconditional (v), technology (t), noise (n) and combined (c).
    ce_v=NaN(1,NN); ce_t=NaN(1,NN); ce_n=NaN(1,NN); ce_c=NaN(1,NN);
    vr_v=NaN(1,NN); vr_t=NaN(1,NN); vr_n=NaN(1,NN); vr_c=NaN(1,NN);
    rq_v=NaN(1,NN); rq_t=NaN(1,NN); rq_n=NaN(1,NN); rq_c=NaN(1,NN);

    parfor bb = 1:NN
        % Companion form, impact matrix and the auxiliary-variable loadings.
        AR = ARs{bb}; Sig = Sigs{bb};
        nx = size(AR,2);
        B  = [AR;[eye(nx-k),zeros(nx-k,k)]];
        At = chol(Sig)';
        C  = [At; zeros(nx-k,k)];
        [A,~,~,~,~,~] = gen_auxvars(AR',Aproj,keys,k,nlags,j_cj);

        % Unconditional band-filtered covariances at horizons 0 and 1.
        Vf = vdh_fast(B, C, A, [2*pi/mp, 2*pi/2], [0 1], ng);

        % Conditional: band-pass the cumulated impulse responses.
        Ct = cov_filt(flip(cumsum(irtfp_all(:,:,bb))),   mp);
        Cn = cov_filt(flip(cumsum(irnoise_all(:,:,bb))), mp);
        Cc = Ct + Cn;

        ce_v(bb) = -Vf(i_cumeret,i_rrdiff,1);
        ce_t(bb) = -Ct(i_cumeret,i_rrdiff,1);
        ce_n(bb) = -Cn(i_cumeret,i_rrdiff,1);
        ce_c(bb) = -Cc(i_cumeret,i_rrdiff,1);

        vr_v(bb) = Vf(i_rrdiff,i_rrdiff,1);
        vr_t(bb) = Ct(i_rrdiff,i_rrdiff,1);
        vr_n(bb) = Cn(i_rrdiff,i_rrdiff,1);
        vr_c(bb) = Cc(i_rrdiff,i_rrdiff,1);

        rq_v(bb) = Vf(i_rer,i_rer,2)/Vf(i_rer,i_rer,1);
        rq_t(bb) = Ct(i_rer,i_rer,2)/Ct(i_rer,i_rer,1);
        rq_n(bb) = Cn(i_rer,i_rer,2)/Cn(i_rer,i_rer,1);
        rq_c(bb) = Cc(i_rer,i_rer,2)/Cc(i_rer,i_rer,1);
    end

    S = struct();
    S.cov_engel  = struct('tfp',ce_t,'noise',ce_n,'comp',ce_c,'var',ce_v);
    S.beta_engel = struct('tfp',ce_t./vr_t,'noise',ce_n./vr_n, ...
                          'comp',ce_c./vr_c,'var',ce_v./vr_v);
    S.rho_qt     = struct('tfp',rq_t,'noise',rq_n,'comp',rq_c,'var',rq_v);

    R = struct('stats',S,'skipped',{skipped},'ix',ix,'pp',opt.pp, ...
               'meta',struct('ndraws',NN-1,'nvars',k,'nlags',nlags, ...
                             'case',cname,'max_per',mp,'ngrid',ng));
end

function Vy = vdh_fast(B, C, A, lam, horizons, ng)
%VDH_FAST  Band-filtered covariance of A*(I-BL)^-1*C at the given horizons.
%
%       Vy(:,:,h) = 2*Re integral_lam1^lam2 (1/2pi) T1(w) T1(w)^H e^{i w h} dw
%
%   evaluated on an ng-point trapezoid grid in one tf_sweep.

    % Grid and trapezoid weights.
    ny = size(A,1);
    lamg = linspace(lam(1), lam(2), ng);
    wq   = zeros(1,ng);
    wq(2:ng-1) = (lamg(3:ng)-lamg(1:ng-2))/2;
    wq(1)      = (lamg(2)-lamg(1))/2;
    wq(ng)     = (lamg(ng)-lamg(ng-1))/2;

    % Transfer function and its outer product at every node.
    T1 = tf_sweep(A, B, C, exp(-1i*lamg));            % ny x ne x ng
    P  = pagemtimes(T1,'none',T1,'ctranspose');       % ny x ny x ng

    Vy = zeros(ny, ny, numel(horizons));
    for kk = 1:numel(horizons)
        w = reshape(wq .* exp(1i*lamg*horizons(kk)), 1, 1, ng);
        Vy(:,:,kk) = 2*real(sum(P .* w, 3))/(2*pi);
    end
end

function s = blank(z)
    s = struct('tfp',z,'noise',z,'comp',z,'var',z);
end
