function out = ccdgv_countries(country)
%CCDGV_COUNTRIES  The country list, and the data column of each country.
%
%   names = ccdgv_countries()       1x7 cell, in data-column order
%   cc    = ccdgv_countries(name)   that country's column index
%
%   The order is the column order of the loaders' country matrices (fx_ln,
%   idiff_ec, cons_ln, cpi, inv_ln), so it must not change.
%
%   See also UNPACK_INFO, VALIDATE_INFO.

    names = {'Canada', 'France', 'Germany', 'Italy', 'Japan', 'UK', 'G6'};

    if nargin < 1
        out = names;
        return
    end

    k = find(strcmp(names, country));
    assert(isscalar(k), 'ccdgv_countries:unknown', ...
           '"%s" is not a country -- expected one of %s', ...
           char(string(country)), strjoin(names, ', '));
    out = k;
end
