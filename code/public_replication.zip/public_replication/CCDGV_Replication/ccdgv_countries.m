function out = ccdgv_countries(country)
%CCDGV_COUNTRIES  The country list, and the data column each country occupies.
%
%   names = CCDGV_COUNTRIES()        1x7 cell, IN DATA-COLUMN ORDER
%   cc    = CCDGV_COUNTRIES(name)    that country's column index
%
%   THE INDEX IS NOT A LABEL. cc is the column the loaders read --
%   fx_ln(:,cc), idiff_ec(:,cc), cons_ln(:,cc), cpi(:,cc), inv_ln(:,cc) in
%   the data loader. So the ORDER below is not
%   a presentation choice: it is the column order of those matrices, and
%   reordering it silently repoints every country run at another country's data.
%   Add a country only by appending, and only alongside the loaders.
%
%   WHY THIS IS A FUNCTION. cc used to be stored on info.settings beside
%   info.country, two representations of one fact, and they drifted: sweep's
%   by-country loop set the NAME and left the INDEX at 7, so all six country runs
%   re-estimated G6 and differed only in their filename. unpack_info now DERIVES
%   cc from info.country the way it derives inclvarnms from inclvar, which makes
%   that contradiction unrepresentable rather than merely detectable.
%
%   See also UNPACK_INFO, VALIDATE_INFO, CONFIG.

    names = {'Canada', 'France', 'Germany', 'Italy', 'Japan', 'UK', 'G6'};

    if nargin < 1
        out = names;
        return
    end

    k = find(strcmp(names, country));
    assert(isscalar(k), 'ccdgv_countries:unknown', ...
           '"%s" is not a country -- expected one of %s', ...
           char(string(country)), strjoin(names, ', '));
    out = k;
end
