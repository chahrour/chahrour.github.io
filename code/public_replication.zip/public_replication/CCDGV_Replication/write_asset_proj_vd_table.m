function out = write_asset_proj_vd_table(base_info, opt)
%WRITE_ASSET_PROJ_VD_TABLE  Variance shares of the EXTERNALLY PROJECTED asset
%                           series -- of the actual series, not of the fitted one.
%
%   out = WRITE_ASSET_PROJ_VD_TABLE(base_info)
%   out = WRITE_ASSET_PROJ_VD_TABLE(base_info, opt)
%
%   base_info  the BASELINE run (inclvar 1), where none of the four asset series
%              is in the VAR. An augmented spec is refused.
%   opt        .bands   rows of vd_fr for Panel B; default [1 3]
%              .outdir  REQUIRED: the dir holding Figures/ and Tables/
%              .echo    print the table; default true
%              .arlags  AR order for the residual; default 4
%              .M       band quadrature grid; default 500
%
%   Writes Tables/tab_asset_proj_vd.tex. The numerical counterpart of Asset 12's
%   figures, and the projected counterpart of tab_asset_vd_equity/yields, which
%   report the same statistics for the specs that put the asset IN the VAR.
%
%   THREE LINES PER SERIES, WHICH IS THE POINT OF THE TABLE:
%       as projected    the share of the FITTED series' variance -- what every
%                       other table in this repository reports for a projected
%                       row, because that is what the identification code's
%                       denominator is
%       x factor        V(xhat)/[V(xhat)+V(u)], measured the same way as the
%                       column's own denominator
%       of the series   their product: the share of the ACTUAL series' variance
%   Showing all three makes the arithmetic checkable by eye, which matters
%   because the factor is the whole content of the table.
%
%   WHY NOT JUST MULTIPLY BY R2. That is the right idea and the wrong number.
%   R2 is the factor for the UNCONDITIONAL SAMPLE variance; Panel A's denominator
%   is a forecast-error variance at horizon h and Panel B's is a spectral band.
%   This VAR is estimated on log levels with maxeig_cutoff = 1, so an R2 near 1
%   largely records a shared trend -- precisely the low-frequency power a 6-32
%   quarter band discards. R2 is printed beside each series so the gap is visible;
%   it is an upper bound on every factor in the table, and it approaches 1 for a
%   persistent series whatever the band factor does. See CCDGV_EXTSHARE.
%
%   THE FACTOR IS A MEDIAN ACROSS DRAWS, applied to a statistic that is itself a
%   point estimate (Panel A) or a median (Panel B). Forming the product per draw
%   would be better, but datadraws is not saved -- only the five quantile pages
%   of dataplots are. The factor's own 16-84 spread is reported in the note, so a
%   reader can see how much that substitution could be worth. It is small
%   whenever the factor is tight across draws, which is the usual case.
%
%   See also CCDGV_EXTSHARE, GENFIG_ASSET_PROJ.

    if nargin < 2; opt = struct(); end
    if ~isfield(opt,'echo');   opt.echo = true;  end
    if ~isfield(opt,'bands')  || isempty(opt.bands);  opt.bands  = [1 3]; end
    if ~isfield(opt,'arlags') || isempty(opt.arlags); opt.arlags = 4;     end
    if ~isfield(opt,'M')      || isempty(opt.M);      opt.M      = 500;   end
    % opt.outdir is the EXHIBIT ROOT; this function appends Tables/ itself, which
    % is the same convention every generator here uses.
    assert(isfield(opt,'outdir') && ~isempty(opt.outdir), 'write_asset_proj_vd_table:noOutdir', ...
        'opt.outdir is required: the directory holding Figures/ and Tables/.');
    opt.outdir = fullfile(opt.outdir, 'Tables');
    if ~isfolder(opt.outdir); mkdir(opt.outdir); end

    % ---- source -------------------------------------------------------------
    if isstruct(base_info) && isfield(base_info,'vnames')
        D = base_info;
    else
        if isstruct(base_info); [~, f] = data_name(base_info); else; f = base_info; end
        assert(isfile(f), 'write_asset_proj_vd_table:noFile', '%s not found', f);
        D = load(f);
    end
    for fl = {'vnames','vd_feh','vd_fr','r2','ARs','Sigs','Aproj','keys','data'}
        assert(isfield(D,fl{1}), 'write_asset_proj_vd_table:missing', ...
            ['%s not found in the case file. This table needs the data AND ' ...
             'estimation stages, because it recomputes the variance denominators ' ...
             'the identification code keeps only as ratios.'], fl{1});
    end

    BY = extra_asset_rows('yields');
    EQ = extra_asset_rows('equity');
    RT = extra_asset_rows('returns');
    ROWS = [BY, EQ, RT];
    idx  = var_order(D.vnames, ROWS{:});  idx = idx(:)';

    % The mirror image of WRITE_ASSET_VD_TABLE's assert: that one demands the
    % asset be IN the VAR, this one demands it be outside.
    for k = idx
        assert(k <= numel(D.r2) && abs(D.r2(k) - 1) >= 1e-8, ...
            'write_asset_proj_vd_table:inVAR', ...
            ['%s has r2 = %.4f here -- it is IN this VAR, so there is no ' ...
             'projection to correct. Pass the BASELINE run (inclvar = 1); the ' ...
             'augmented specs are tabulated by write_asset_vd_table.'], ...
            D.vnames{k}, D.r2(k));
    end
    lab = D.vnames(idx);

    % Rows that project onto nothing produce a table of NaN that compiles.
    live = arrayfun(@(k) any(isfinite(D.Aproj(k,:))) && isfinite(D.r2(k)), idx);
    assert(all(live), 'write_asset_proj_vd_table:dead', ...
        ['%s has no usable projection (all-NaN row). Was Yields_M.mat on the ' ...
         'path when this run was built?'], strjoin(lab(~live), ', '));

    % ---- the factors --------------------------------------------------------
    E = ccdgv_extshare(D, ROWS, struct('horizons', D.vd_feh, 'bands', opt.bands, ...
                                       'arlags', opt.arlags, 'M', opt.M));
    facA = median(E.fac_fev,  3);                  % nrows x numel(vd_feh)
    facB = median(E.fac_band, 3);                  % nrows x numel(bands)
    sprA = quantile(E.fac_fev,  [0.16 0.84], 3);
    sprB = quantile(E.fac_band, [0.16 0.84], 3);

    % ---- Panel A: max-share FEV --------------------------------------------
    hasA = isfield(D,'dataplots') && ~isempty(D.dataplots);
    if hasA
        Ai   = D.dataplots(D.vd_feh, idx, 1)';     % nrows x nh, as projected
        hdrA = arrayfun(@(h) sprintf('$Q$%d',h), D.vd_feh, 'UniformOutput', false);
        A    = local_stack(Ai, facA);
    else
        A = []; hdrA = {}; Ai = [];
        warning('write_asset_proj_vd_table:noUhlig', ...
            ['dataplots absent -- writing Panel B only. The max-share pass did ' ...
             'not run for this spec (info.idrun empty?).']);
    end

    % ---- Panel B: CJ bands --------------------------------------------------
    hasB = isfield(D,'vstfp') && isfield(D,'vsnoise') && ...
           ~isempty(D.vstfp) && ~isempty(D.vsnoise);
    if hasB
        tfp   = median(D.vstfp(idx,:,:),   3);
        noise = median(D.vsnoise(idx,:,:), 3);
        Bi   = zeros(numel(idx), 3*numel(opt.bands));
        facBx = zeros(numel(idx), 3*numel(opt.bands));
        bandhdr = cell(1,numel(opt.bands));
        for k = 1:numel(opt.bands)
            b = opt.bands(k);
            Bi(:,3*k-2:3*k)    = [tfp(:,b) + noise(:,b), tfp(:,b), noise(:,b)];
            % One factor per BAND, repeated across Both/Tech/Noise: the three
            % share a denominator, so they share a correction.
            facBx(:,3*k-2:3*k) = repmat(facB(:,k), 1, 3);
            bandhdr{k} = sprintf('Periodicities of %g--%g Quarters', ...
                                 round(2*pi/D.vd_fr(b,2)), round(2*pi/D.vd_fr(b,1)));
        end
        B = local_stack(Bi, facBx);
    else
        B = []; bandhdr = {}; Bi = [];
        warning('write_asset_proj_vd_table:noCJ', ...
            'vstfp/vsnoise absent -- writing Panel A only.');
    end

    assert(~isempty(A) || ~isempty(B), 'write_asset_proj_vd_table:nothingToWrite', ...
        '%s carries neither dataplots nor vstfp/vsnoise.', ccdgv_prov_label(D));
    assert(isempty(A) || isempty(B) || size(A,2) == size(B,2), ...
        'write_asset_proj_vd_table:widthMismatch', ...
        ['Panel A is %d columns (vd_feh) and Panel B is %d (%d bands x 3); they ' ...
         'share one tabular. Give opt.bands %g entries.'], ...
        size(A,2), size(B,2), numel(opt.bands), numel(D.vd_feh)/3);

    % ---- write --------------------------------------------------------------
    fn = fullfile(opt.outdir, 'tab_asset_proj_vd.tex');
    local_write(fn, A, B, lab, hdrA, bandhdr, E, local_prov(D, E, hasA, hasB));
    fprintf('  wrote Tables/tab_asset_proj_vd.tex\n');

    out = struct('uhlig_internal', Ai, 'uhlig_factor', facA, ...
                 'cj_internal', Bi, 'cj_factor', facB, ...
                 'rows', idx, 'labels', {lab}, 'ext', E);

    if opt.echo
        fprintf('\n  Externally projected variance shares (%s)\n', ccdgv_prov_label(D));
        fprintf('    residual: %s\n', E.note);
        for k = 1:numel(lab)
            fprintf('    %-22s r2 %.4f   factor 6-32q %.4f [%.4f %.4f]   %s\n', ...
                    lab{k}, E.r2(k), facB(k,end), ...
                    sprB(k,end,1), sprB(k,end,2), E.source{k});
        end
        if hasA
            fprintf('\n    Panel A -- max-share, as projected / factor / of the series\n');
            local_echo(A, lab, hdrA, 8);
        end
        if hasB
            fprintf('\n    Panel B -- CJ\n');
            local_echo(B, lab, repmat({'Both','Tech','Noise'},1,numel(opt.bands)), 8);
        end
    end
end

% =========================================================================
function M = local_stack(internal, factor)
%LOCAL_STACK  Three lines per series: as projected, factor, product.
%   Interleaved rather than blocked, so each series reads as one unit and the
%   product sits directly under the two numbers that make it.
    n = size(internal,1);
    M = NaN(3*n, size(internal,2));
    M(1:3:end,:) = internal;
    M(2:3:end,:) = factor;
    M(3:3:end,:) = internal .* factor;
end

function local_echo(M, lab, hdr, w)
    fprintf('    %-24s', '');
    for k = 1:numel(hdr); fprintf('%*s', w, hdr{k}); end
    fprintf('\n');
    TAG = {'as projected','x factor','of the series'};
    for r = 1:size(M,1)
        k = ceil(r/3);  t = mod(r-1,3)+1;
        if t == 1; nm = lab{k}; else; nm = ''; end
        fprintf('    %-12s%-12s%s\n', nm, TAG{t}, sprintf('%*.3f', w, M(r,:)));
    end
end

function local_write(fn, A, B, lab, hdrA, bandhdr, E, prov)
    if isempty(A); nc = size(B,2); else; nc = size(A,2); end
    fid = fopen(fn,'w'); c = onCleanup(@() fclose(fid));
    fprintf(fid,'%% Generated by write_asset_proj_vd_table.m -- do not edit by hand.\n%% %s\n', prov);

    fprintf(fid,'\\begin{table}[tb]\n\t\\centering\n');
    fprintf(fid,['\t\\caption{Variance shares of the externally projected asset ' ...
                 'series \\label{tab: asset proj VDs}}\n']);
    fprintf(fid,'\t\\resizebox{\\columnwidth}{!}{%%\n');
    fprintf(fid,'\t\t\\begin{tabular}{l l | %s}\n\t\t\t\\hline\n', repmat(' C{1.4cm} ',1,nc));

    if ~isempty(A)
        fprintf(fid,'\t\t\t\\multicolumn{%d}{l}{\\textbf{Panel A. Max-share identification}}\\\\\n', nc+2);
        fprintf(fid,'\t\t\t& & \\multicolumn{%d}{c}{Forecast Horizon (Quarters)} \\\\\n\t\t\t\\hline\n', nc);
        fprintf(fid,'\t\t\t& & %s \\\\\n\t\t\t\\hline\n', strjoin(hdrA,' & '));
        local_rows(fid, A, lab, E);
    end

    if ~isempty(B)
        if ~isempty(A); fprintf(fid,'\t\t\t\\hline\n'); end
        fprintf(fid,'\t\t\t\\multicolumn{%d}{l}{\\textbf{Panel B. CJ technology and noise disturbances}}\\\\\n', nc+2);
        fprintf(fid,'\t\t\t& & ');
        for k = 1:numel(bandhdr)
            if k < numel(bandhdr)
                fprintf(fid,'\\multicolumn{3}{c|}{%s} & ', bandhdr{k});
            else
                fprintf(fid,'\\multicolumn{3}{c}{%s} \\\\\n', bandhdr{k});
            end
        end
        fprintf(fid,'\t\t\t\\hline\n');
        fprintf(fid,'\t\t\t& & %s \\\\\n\t\t\t\\hline\n', ...
                strjoin(repmat({'Both & Tech. & Noise'},1,numel(bandhdr)), ' & '));
        local_rows(fid, B, lab, E);
    end

    fprintf(fid,'\t\t\t\\hline\n\t\t\\end{tabular}\n\t}\n');

    note = [ ...
      'Estimated on the BASELINE VAR, in which none of these four series is a ' ...
      'VAR variable: each row of the auxiliary matrix is the VAR''s best linear ' ...
      'predictor of the series, and the shocks are therefore the paper''s own, ' ...
      'identified on the eight baseline variables and unaffected by the assets. ' ...
      '\textbf{Each series occupies three lines.} ``As projected'''' is the share ' ...
      'of the FITTED series'' variance, which is what the identification code ' ...
      'computes, because its denominator is built from the same projected row. ' ...
      '``Of the series'''' is the share of the ACTUAL series'' variance, and the ' ...
      '``factor'''' line between them is what converts one into the other. ' ...
      '\textbf{The conversion is exact, not an approximation.} Writing ' ...
      '$x=\hat{x}+u$, the projection residual $u$ is orthogonal to the whole ' ...
      'companion state and hence to every VAR shock, so a shock''s contribution ' ...
      'to the variance of $x$ equals its contribution to the variance of ' ...
      '$\hat{x}$; only the denominator changes, by ' ...
      '$V(\hat{x})/[V(\hat{x})+V(u)]$. ' ...
      '\textbf{The factor is not $R^2$}, though $R^2$ is the same ratio for the ' ...
      'unconditional sample variance. Panel A''s denominator is a forecast-error ' ...
      'variance at horizon $h$ and Panel B''s a spectral band, so each column ' ...
      'needs $V(\cdot)$ measured its own way. Because this VAR is estimated on ' ...
      'log levels with roots against the unit circle, $R^2$ is dominated by the ' ...
      'shared trend --- exactly the power a $6$--$32$ quarter band discards --- ' ...
      'so it is an upper bound on every factor here, and it approaches one for a ' ...
      'persistent series whatever the band factor does. ' ...
      local_r2line(E) ' ' local_facline(E) ' ' local_uline(E) ' ' ...
      'The factor is a median across draws applied to a statistic that is ' ...
      'itself a point estimate (Panel A) or a median (Panel B); the per-draw ' ...
      'product is unavailable because only the quantile pages of the shares are ' ...
      'stored. ' ...
      'The yield rows are quarterly log yields scaled by 100, i.e. percent per ' ...
      'quarter; the equity rows are the real (CPI-deflated) total-return MSCI ' ...
      'index in log levels. The two pairs are not on a common scale, but ' ...
      'variance shares are unitless and so are comparable across all four. '];
    fprintf(fid,'\t\\caption*{\\footnotesize \\emph{Notes:} %s%s}\n', note, tex_escape(prov));
    fprintf(fid,'\\end{table}\n');
end

function local_rows(fid, M, lab, E)
    TAG = {'as projected','$\times$ factor','of the series'};
    for r = 1:size(M,1)
        k = ceil(r/3);  t = mod(r-1,3)+1;
        if t == 1
            fprintf(fid,'\t\t\t\\hline\n');
            nm = sprintf('%s ($R^2$ %.3f)', lab{k}, E.r2(k));
        else
            nm = '';
        end
        fprintf(fid,'\t\t\t%-34s & %-16s & %s\\\\\n', nm, TAG{t}, ...
                strjoin(arrayfun(@(v) sprintf('%.3f',v), M(r,:), ...
                                 'UniformOutput',false), ' & '));
    end
end

function s = local_r2line(E)
    s = ['$R^2$ is printed beside each series so the gap is visible: ' ...
         strjoin(arrayfun(@(k) sprintf('%.3f', E.r2(k)), 1:numel(E.r2), ...
                          'UniformOutput', false), ', ') ' in row order.'];
end

function s = local_facline(E)
    f = median(E.fac_band(:,end,:), 3);
    s = sprintf(['The narrowest band''s factors are %s, which is the comparison ' ...
                 'that matters.'], ...
                strjoin(arrayfun(@(v) sprintf('%.3f', v), f(:)', ...
                                 'UniformOutput', false), ', '));
end

function s = local_uline(E)
    if all(strcmp(E.source,'residual'))
        s = ['$V(u)$ comes from the stored projection residual''s own AR ' ...
             'representation, so its serial correlation is estimated rather ' ...
             'than assumed.'];
    elseif any(strcmp(E.source,'r2'))
        s = ['\textbf{This run did not store the projection residual}, so ' ...
             '$V(u)$ is recovered exactly in sample from $R^2$ but spread ' ...
             'across horizons and bands AS WHITE NOISE --- the only ' ...
             'approximation left in the conversion, and re-running removes it. ' ...
             'It is not a conservative one. A band of $6$--$32$ quarters sits ' ...
             'near where a moderately autocorrelated process peaks relative to ' ...
             'its own variance, so an AR residual with $\phi$ between about ' ...
             '$0.2$ and $0.8$ puts MORE of its variance in the band than white ' ...
             'noise does; assuming white noise then understates $V(u)$ over the ' ...
             'band and so OVERSTATES the factor. These figures are therefore ' ...
             'still an upper bound, a tighter one than $R^2$ rather than a ' ...
             'bound from the other side.'];
    else
        s = '';
    end
end

function s = local_prov(D, E, hasA, hasB)
    p = {};
    lab = ccdgv_prov_label(D);
    if ~isempty(lab); p{end+1} = lab; end
    if isfield(D,'info') && isfield(D.info,'inclvarnms')
        p{end+1} = sprintf('%d-variable VAR, none of the four asset rows in it', ...
                           numel(D.info.inclvarnms));
    end
    if isfield(D,'ndraws'); p{end+1} = sprintf('ndraws=%d', D.ndraws); end
    p{end+1} = sprintf('factors from %d draws', E.ndraws);
    p{end+1} = sprintf('residual source %s', strjoin(unique(E.source), '/'));
    if hasA
        m = ccdgv_id_meta(D, 1);
        if ~isempty(m)
            if m.shock_extract == 2
                p{end+1} = sprintf('Panel A target [%.0f,%.0f] qtr periodicities', ...
                                   2*pi/m.KUbar, 2*pi/m.KLbar);
            else
                p{end+1} = sprintf('Panel A FEV target at horizon %g', m.KUbar);
            end
        end
    end
    if hasB; p{end+1} = 'Panel B shares are medians across draws, Both = Tech + Noise'; end
    s = [strjoin(p, ', ') '.'];
end
