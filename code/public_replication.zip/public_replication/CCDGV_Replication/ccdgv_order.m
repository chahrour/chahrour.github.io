function o = ccdgv_order(vnames)
%CCDGV_ORDER  The paper's variable selections, resolved BY NAME.
%
%   o = CCDGV_ORDER(vnames) returns a struct of index vectors into `vnames`:
%       o.uhlig    Figure 1 / Table 1 panel order      (was `order`)
%       o.vdec     Table 1 variance-decomposition rows (was `order_vdec`)
%       o.fig2b    Figures 3 and 4, six panels         (was `order_fig2b`)
%       o.fig2b_r  ditto, the resubmit ordering        (was `order_fig2b_resubmit`)
%       o.tfp_exp  Figure 2, TFP and E[TFP]            (was the literal [1 9])
%
%   WHY THIS EXISTS. run_main hard-codes these as literal indices, e.g.
%   order_fig2b = [1,12,2,15,6,11]. Those indices are correct ONLY for the
%   8-variable baseline layout. The equity specifications
%   insert 'US equity' and 'G6 equity' at positions 9-10, which shifts every
%   variable from 'E[TFP]' onward by +2 -- so the same literals silently select
%   the WRONG series:
%
%       index 12  base: Interest Rate Differential   equity: ENER
%       index 15  base: Real Exchange Rate           equity: ECPIDIFF
%       index 11  base: Expected Excess Returns      equity: E[TFP]
%       index  9  base: E[TFP]                       equity: US equity
%
%   The figures and tables were internally consistent -- labels came from the
%   same wrong indices -- so nothing errored; the equity exhibits simply showed
%   different variables from the ones the paper reports.
%
%   Resolving by name is layout-independent and fixes every affected exhibit at
%   once. It is a DISPLAY-time selection: the saved .mat already holds the full
%   dataplots / irtfp / vardec_fd arrays over all variables, so no re-estimation
%   is needed.
%
%   SELF-CHECK: for an 8-variable baseline layout the result must reproduce the
%   historical literals exactly. It is asserted below, so a typo in a name here
%   fails loudly instead of quietly moving a published number.

    ix = @(nm) find_one(vnames, nm);

    o.vdec    = [ix('Home TFP'), ix('Home Consumption'), ix('Foreign Consumption'), ...
                 ix('Home Investment'), ix('Foreign Investment'), ...
                 ix('Interest Rate Differential'), ix('Real Exchange Rate'), ...
                 ix('Expected Excess Returns'), ix('$\Delta q_t$')];

    o.fig2b   = [ix('Home TFP'), ix('Interest Rate Differential'), ...
                 ix('Home Consumption'), ix('Real Exchange Rate'), ...
                 ix('Foreign Consumption'), ix('Expected Excess Returns')];

    o.fig2b_r = [ix('Home TFP'), ix('Home Consumption'), ix('Foreign Consumption'), ...
                 ix('Interest Rate Differential'), ix('Real Exchange Rate'), ...
                 ix('Expected Excess Returns')];

    o.tfp_exp = [ix('Home TFP'), ix('E[TFP]')];

    % ---- self-check against the historical literals (8-variable layout) ----
    if numel(vnames) >= 9 && strcmp(vnames{9}, 'E[TFP]')
        assert(isequal(o.vdec,       [1,2,6,3,8,12,15,11,18]), 'ccdgv_order: vdec mismatch');
        assert(isequal(o.fig2b,      [1,12,2,15,6,11]), 'ccdgv_order: fig2b mismatch');
        assert(isequal(o.fig2b_r,    [1,2,6,12,15,11]), 'ccdgv_order: fig2b_resubmit mismatch');
        assert(isequal(o.tfp_exp,    [1,9]), 'ccdgv_order: tfp_exp mismatch');
    end
end

