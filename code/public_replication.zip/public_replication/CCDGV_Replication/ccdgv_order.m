function o = ccdgv_order(vnames)
%CCDGV_ORDER  The paper's variable selections, as indices into vnames.
%
%   o = ccdgv_order(vnames)
%
%   vnames  cell of variable names, as saved in a run file.
%   o       struct of index vectors:
%             o.vdec     variance-decomposition rows (Tables 1 and 2)
%             o.fig2b    six panels: TFP, interest differential, consumption,
%                        exchange rate, foreign consumption, excess returns
%             o.fig2b_r  the same six in the order of Figures 3 and 4: levels
%                        first in each row, so a rate panel follows them
%             o.tfp_exp  TFP and E[TFP] (Figure 2)
%
%   Variables are found by name, so the result holds for any VAR layout.

    ix = @(nm) find_one(vnames, nm);

    o.vdec    = [ix('Home TFP'), ix('Home Consumption'), ix('Foreign Consumption'), ...
                 ix('Home Investment'), ix('Foreign Investment'), ...
                 ix('Interest Rate Differential'), ix('Real Exchange Rate'), ...
                 ix('Expected Excess Returns'), ix('$\Delta q_t$')];

    o.fig2b   = [ix('Home TFP'), ix('Interest Rate Differential'), ...
                 ix('Home Consumption'), ix('Real Exchange Rate'), ...
                 ix('Foreign Consumption'), ix('Expected Excess Returns')];

    o.fig2b_r = [ix('Home TFP'), ix('Home Consumption'), ix('Foreign Consumption'), ...
                 ix('Real Exchange Rate'), ix('Interest Rate Differential'), ...
                 ix('Expected Excess Returns')];

    o.tfp_exp = [ix('Home TFP'), ix('E[TFP]')];

    % Check against fixed indices, for a layout whose row 9 is E[TFP].
    if numel(vnames) >= 9 && strcmp(vnames{9}, 'E[TFP]')
        assert(isequal(o.vdec,       [1,2,6,3,8,12,15,11,18]), 'ccdgv_order: vdec mismatch');
        assert(isequal(o.fig2b,      [1,12,2,15,6,11]), 'ccdgv_order: fig2b mismatch');
        assert(isequal(o.fig2b_r,    [1,2,6,15,12,11]), 'ccdgv_order: fig2b_resubmit mismatch');
        assert(isequal(o.tfp_exp,    [1,9]), 'ccdgv_order: tfp_exp mismatch');
    end
end

