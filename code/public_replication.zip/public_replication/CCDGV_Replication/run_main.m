

%% Run the case described by info.
%
% EVERYTHING BELOW THIS LINE READS `info` AND NOTHING ELSE FROM ABOVE IT.
% Hand a finished info to a script starting here and it runs to the end; change
% one field and run it again. unpack_info puts info's contents into the local
% names the rest of this file and the scripts it calls expect.
unpack_info;

%Get started
nvars    = numel(info.inclvarnms);
[manifest, constructed] = ccdgv_manifest();   % data rows, constructed rows
vkey     = {manifest.key};

%-- START OF DATA STAGE


% Consumers read these as top-level variables, so carry them alongside
% info rather than only inside info.settings.
Sc = struct('bound',bound,'bound2',bound2,'vd_fr',vd_fr,'vd_feh',vd_feh, ...
    'nplot',nplot,...
    'confidence_bands',confidence_bands,'point_estimate',point_estimate, ...
    'nvars',nvars,'nlags',nlags,'ndraws',ndraws,'smax',smax, ...
    'j_cj_horizon',j_cj_horizon, ...
    'end_date',info.ed,'country',info.country);
info = run_stage(info,'config',Sc);

% Vintage -> which built file ryan_data loads. ALWAYS a tagged name: the untagged
% Y_benchmark.mat is whatever was built last and has silently swapped vintage
% before now, so the suffix is always spelled out. The vintage is cfg.vintage --
% '2026' as shipped -- and it names the panel this run reads.
built_suffix = ['_f' info.settings.fv_requested];

% Asset prices are NOT loaded unconditionally. ASSET_PRICE_data used to run for
% every spec -- re-reading the MSCI workbook and re-running load_bonds -- purely
% because ryan_data wanted four series as loose workspace variables. The build
% saves them as a dated panel (AP_returns.mat) and ryan_data reads them by date,
% as it already read the equity panel.

% Put `data` and `dates` in the workspace, from the rebuilt panels in
% Data_Replication/Built_Data. The research code also carried an 'orig' core
% built from spreadsheets; this package does not, and there is no branch for it.
ryan_data;

%What elements of data are in the VAR
yidx = var_order(vkey, info.inclvarnms{:})';

% THE DECLARED WINDOW IS BINDING. A NaN in a VAR column at this point is a NaN
% INSIDE the window the spec asked for -- the data loader has already clipped to
% [info.settings.sd, info.settings.ed] (ryan_data:52-64 for the new core, the
% ryan_data clips to it before building `data`). So there is nothing left
% to discover here, and silently dropping rows is the wrong answer.
%
% IT USED TO DROP THEM and print a count, which made the estimation sample an
% OUTCOME rather than a CHOICE: the baseline asked for 1976Q1, eleven rows went,
% and it ran from 1978Q4 -- a boundary nobody had chosen and nothing recorded
% except sd_realised, after the fact. CONTEXT.md notes that moving that start from
% 1976Q1 to 1978Q4 moves the variance decomposition more than the entire data
% rebuild, so this was not a cosmetic silence.
%
% Now it is an error naming the series and the quarters. The fix for a spec that
% trips it is to declare a start the data actually support, not to loosen this.
% The mask still looks at the VAR COLUMNS ONLY: an auxiliary's missing quarters
% are its own business, and masking on all columns is what used to let TB_G6's
% 2018Q4 end cap every run regardless of end_date.
nanrow = ~all(isfinite(data(:,yidx)), 2);
if any(nanrow)
    if isdatetime(dates); dstr = @(k) char(string(dates(k),'yyyy-QQQ'));
    else;                 dstr = @(k) sprintf('%.2f', dates(k)); end
    lines = {};
    for jj = yidx(:)'
        q = find(~isfinite(data(:,jj)));
        if isempty(q); continue; end
        if jj <= numel(manifest); nm = manifest(jj).name; else; nm = sprintf('col %d', jj); end
        if numel(q) <= 6
            when = strjoin(cellfun(dstr, num2cell(q), 'UniformOutput', false), ', ');
        else
            when = sprintf('%s .. %s (%d quarters)', dstr(q(1)), dstr(q(end)), numel(q));
        end
        lines{end+1} = sprintf('    %-16s %s', nm, when);   %#ok<SAGROW>
    end
    error('run_main:nanInWindow', ...
        ['%d of %d quarters in the DECLARED window %s..%s have a NaN in a VAR ' ...
         'column.\n%s\nThe window is binding: set info.sd (and/or info.ed), which ' ...
         'unpack_info turns into start_date/end_date, to a range these series ' ...
         'cover. datver "%s", inclvar %d.'], ...
        sum(nanrow), size(data,1), dstr(1), dstr(size(data,1)), ...
        strjoin(lines, newline), char(string(info.datver)), info.inclvar);
end
yall  = data;  nvall = size(data,2);
data  = data(:,yidx);
vnames   = [{manifest(1:nvall).name},  {constructed.name}];
vnames_short = [{manifest(1:nvall).short}, {constructed.short}];

% --- basis transform, if the spec declares one ------------------------------
% y_t = P*z_t - Q*z_{t-1}, with trP/trQ derived from the manifest in
% unpack_info. genvars estimates on y; make_gam maps back to z afterwards, so
% everything downstream still sees the spec's own variables.
%
% dataL is the LEVELS matrix and stays behind for ccdgv_project. That is not a
% convenience: the AR block genvars returns is a LEVELS system (post make_gam),
% so the companion state gen_auxvars builds is a levels state, and Aproj must be
% projected on the same basis it will be multiplied against. Projecting on the
% transformed matrix would not error -- it would silently be the wrong state.
%
% Strict no-op when the spec declares no transform: trP = I, trQ = 0 gives back
% the input unchanged and drops no row. That is what keeps every other spec,
% the baseline included, bit-identical.
dataL = data;
if has_transform
    zlag  = data(1:end-1, :);          % z_{t-1}
    znow  = data(2:end,   :);          % z_t
    data  = znow*trP' - zlag*trQ';     % y_t, row t of the estimated system
    % One quarter is consumed by the lag. EVERYTHING row-indexed must lose the
    % same one, or Aproj regresses a series on a state offset by a quarter --
    % again, silently.
    dataL = dataL(2:end, :);
    yall  = yall(2:end, :);
    dates = dates(2:end);
    fprintf('  transform: %d of %d variables in first differences; %s\n', ...
            numel(fdvar), nvars, strjoin(trnames, ', '));
    fprintf('  transform consumed 1 quarter; sample now %d obs\n', size(data,1));
else
    assert(isequal(trP, eye(nvars)) && ~any(trQ(:)), 'run_main:badNoOp', ...
        'spec %d declares no transform but trP/trQ are not the identity map.', ...
        info.inclvar);
end

%Project all vars on restricted data. 
% projblocks: per-series basis width, from the manifest. [] there means the run's
% nlags (the full companion state), which is what all but the two expected-excess-
% return rows use. RECORDED per row, because r2 is not comparable across rows that
% used different bases.
%
% Ures: the projection RESIDUALS, one column per series, NaN where that series'
% OLS could not use the row. Stored because r2 alone cannot convert a variance
% share of the projected series into one of the actual series -- the shares are
% forecast-error and spectral-band variances, r2 is an unconditional sample
% variance ratio, and with roots against the unit circle those differ a lot. See
% CCDGV_PROJECT's note and CCDGV_EXTSHARE.
r2 = NaN(1,nvall); nobs = NaN(1,nvall); Aproj = NaN(nvall,nvars*nlags);
projblocks = NaN(1,nvall);
Ures = NaN(size(yall,1), nvall);
for jj = 1:nvall
    pb = manifest(jj).projblocks;
    if isempty(pb); pb = nlags; end
    projblocks(jj) = pb;
    % dataL, NOT data: the levels basis, which is what the stored AR block and
    % hence gen_auxvars' companion are in. Identical to `data` for every spec
    % that declares no transform.
    [Aproj(jj,:), r2(jj), nobs(jj), Ures(:,jj)] = ...
        ccdgv_project(yall(:,jj), dataL, nlags, pb);
end
if any(projblocks ~= nlags)
    for jj = find(projblocks ~= nlags)
        fprintf('  %-16s projected on %d of %d state blocks (R2 %.4f)\n', ...
                vkey{jj}, projblocks(jj), nlags, r2(jj));
    end
end

% --- DRAW the first stage, if the run asks for it --------------------------
% Aproj_draw is nvall x nvars*nlags x (ndraws+1): page j is the first stage
% paired with VAR draw j, the last page is the posterior mean and is what the
% point-estimate page of every response uses. The two posteriors are
% independent given the state, so pairing them by index is the whole of the
% combination -- see CCDGV_PROJECT_DRAW.
%
% A ROW IN THE VAR KEEPS ITS EXACT UNIT VECTOR on every page. OLS returns it,
% a prior would shrink it, and gen_cj_irfs_tfsweep reads the VAR variables'
% own rows to build everything else -- drawing them would corrupt the
% responses the identification itself is built on.
%
% With draw = false the pages are identical copies of Aproj, so every
% downstream consumer is bit-for-bit unchanged and the only cost is memory
% (21 x 32 x 1001 doubles, ~5 MB).
if isfield(info.settings,'proj_prior'); PP = info.settings.proj_prior;
else;                                    PP = struct('draw',false); end
Aproj_draw = repmat(Aproj, 1, 1, ndraws+1);
proj_draw_rec = cell(1, nvall);
% The residual process the draws assume: its innovation variance per draw and
% its AR coefficients. CCDGV_EXTSHARE turns a share of the projected series into
% one of the actual series and needs V(u) in the share's own metric; taking it
% from the model rather than from var(x - Yl*a_j) keeps the estimation error
% out of the denominator.
proj_s2draw = NaN(nvall, ndraws);
proj_phi    = cell(1, nvall);
% r2 AT THE POSTERIOR MEAN. The stored r2/Ures belong to the OLS row in Aproj;
% the point-estimate PAGE of Aproj_draw is the posterior mean, and it fits worse.
% SHRINKAGE IS NOT THE REASON, or not the main one: nineteen of the twenty-one
% rows run at lambda = 0 and are not shrunk at all. Two things differ whatever
% lambda is:
%
%   THE ESTIMATOR. ccdgv_project is plain OLS. ccdgv_project_draw is GLS under an
%   AR(p) error model -- the quasi-differencing by phi is always on, so even the
%   lambda -> 0 limit is GLS, not OLS. A GLS fit is not chosen to maximise the
%   OLS R-squared, so it does not match one.
%
%   THE SAMPLE. ccdgv_project uses every row where the regressors and the target
%   are all finite; ccdgv_project_draw uses the LONGEST CONTIGUOUS run of those
%   rows, because an AR error model needs consecutive observations. Coverage is
%   ragged -- patent_app starts in 1981, the GFD yields stop short -- so for
%   those rows the two fits are not even computed on the same quarters.
%
% Shrinkage does add to the gap for the two expected-return rows, which the
% manifest runs at lambda = 0.05. Storing both numbers stops a table printing one
% next to a response computed from the other.
r2_pm = NaN(1, nvall);
if PP.draw
    ndrawn = 0;
    for jj = 1:nvall
        if ~(r2(jj) < 1 - 1e-8); continue; end          % in the VAR: never drawn
        pb = projblocks(jj);
        % Seeded by the row's FROZEN offset, not by its loop position, so adding
        % or removing a manifest row cannot shift any other row's draws.
        %
        % The base is 2300 and that number is load-bearing. The research code ran
        % five projection first stages and seeded the k-th as 2000 + 100*k + jj;
        % the paper's exhibits are stage 3, so they were drawn from 2300 + jj.
        % This package runs that stage as its only one, so its base must be 2300
        % for the draws to be the ones the published figures show.
        rng(info.settings.proj_seed_base + manifest(jj).seed, 'twister');
        % Per-row shrinkage where the manifest sets it. The expected-return rows
        % forecast future returns, so their first stage is shrunk to avoid
        % overfitting; every other row takes the run's cfg.proj.lambda.
        PPj = PP;
        if isfield(manifest(jj),'projlambda') && ~isempty(manifest(jj).projlambda)
            PPj.lambda = manifest(jj).projlambda;
        end
        [Adj, amj, recj, s2j] = ccdgv_project_draw(yall(:,jj), dataL, nlags, pb, PPj, ndraws);
        if ~recj.ok
            fprintf('  %-16s too short to draw (%d obs); kept at the point estimate\n', ...
                    vkey{jj}, recj.n);
            continue
        end
        Aproj_draw(jj,:,1:ndraws) = permute(Adj, [3 2 1]);
        Aproj_draw(jj,:,end)      = amj;
        proj_s2draw(jj,:) = s2j(:)';  proj_phi{jj} = recj.phi;
        xj = yall(:,jj);  Ylj = lagmatrix(dataL, 0:nlags-1);
        mj = all(isfinite(Ylj),2) & isfinite(xj);
        uj = xj(mj) - Ylj(mj,:)*amj';
        r2_pm(jj) = 1 - sum((uj - mean(uj)).^2) / sum((xj(mj) - mean(xj(mj))).^2);
        proj_draw_rec{jj} = recj;  ndrawn = ndrawn + 1;
    end
    info.settings.proj_draw_summary = sprintf('%d of %d projected rows', ...
                                              ndrawn, sum(r2 < 1 - 1e-8));
    pl = arrayfun(@(m) ~isempty(m.projlambda), manifest(1:nvall));
    if any(pl)
        for jj = find(pl)
            fprintf('  %-16s first stage shrunk at lambda %g (row setting)\n', ...
                    vkey{jj}, manifest(jj).projlambda);
        end
    end
    fprintf(['  first stage DRAWN for %d of %d rows (lambda %g, decay %g, ' ...
             'AR(%d) errors, block 0 %s)\n'], ndrawn, sum(r2 < 1 - 1e-8), ...
            PP.lambda, PP.decay, PP.arlags, subsref({'penalised','free'}, substruct('{}',{1+PP.free_block0})));
end
% COMPARED WITHIN A BLOCK STRUCTURE, not against the longest row. A row
% projected on the contemporaneous block alone loses no lags; one on the full
% companion state loses nlags-1 quarters. Measuring every row against the longest
% therefore reported nineteen of twenty-one as short on every run, for a reason
% that is the lag structure rather than the data, which trains a reader to ignore
% the line. Only a row short of others sharing its block structure is worth
% naming.
pb_live = projblocks(1:nvall);
for b = unique(pb_live(isfinite(nobs)))
    g = find(pb_live == b & isfinite(nobs));
    if isempty(g); continue; end
    full = max(nobs(g));
    short = g(nobs(g) < full);
    for jj = short(:)'
        fprintf('  %-9s projected on %d of %d quarters (R2 %.4f) -- short for its block\n', ...
                vkey{jj}, nobs(jj), full, r2(jj));
    end
end

% Row j of Aproj is series j of the loaded data, so its key is manifest entry j.
% EXACT equality, not <=. With <=, a manifest entry that no loader emits passes
% the check and silently mislabels every column after it -- which is what
% by_us/by_g6/sp500 did once tb_g6/nx_gdp were appended.
assert(nvall == numel(manifest), ...
    ['loader returned %d columns but the manifest declares %d. They must match ' ...
     'one-for-one and in order.'], nvall, numel(manifest));
datakeys = vkey(1:nvall);

%Save results from data steps
% TFP vintage, as reported by whichever loader ran. Neither path takes it from
% info -- it is inherited from the
% built Y_benchmark file -- so it is recorded here after the fact.
if exist('tfp_vintage','var'); info.settings.tfp_vintage = tfp_vintage; end
if exist('tfp_source','var');  info.settings.tfp_source  = tfp_source;  end

info.sd_realised = dates(1); info.ed_realised = dates(end);
% `data` IS SAVED IN LEVELS, NOT IN THE ESTIMATED BASIS. Everything else in this
% file -- ARs (post make_gam), Aproj, irtfp/irnoise, vnames, keys -- is in the
% levels basis, so saving the transformed matrix under `data` left the file
% self-inconsistent for the one spec that has a transform. Any consumer pairing
% `data` with `ARs` was then silently wrong for the VECM and right for every
% other spec: infer_shocks read column 1 as TFP when it was dTFP (correlation
% with the TFP level 0.088), and multiplied a LEVELS companion row into a
% TRANSFORMED state. That alone moved the VECM's technology shock correlation
% with the baseline from 0.005 to 0.257.
%
% dataL IS data for every spec that declares no transform, so this changes
% nothing for the fifteen specs that declare none. The estimated basis is kept
% as `data_est` --
% genvars is handed it directly and never reads this file, so nothing needs it,
% but it is what the VAR was actually fit on and is worth being able to inspect.

St = struct('data',dataL,'data_est',data,'dates',dates, ...
            'vnames',{vnames},'vnames_short',{vnames_short}, ...
            'Aproj',Aproj,'r2',r2,'nobs',nobs,'projblocks',projblocks, ...
            'Ures',Ures,'keys',{datakeys});
St.Aproj_draw = Aproj_draw;  St.proj_draw_rec = {proj_draw_rec};
St.proj_s2draw = proj_s2draw;  St.proj_phi = {proj_phi};  St.r2_pm = r2_pm;
info.settings.proj_prior = PP;
info = run_stage(info,'data',St);

%--END OF DATA STAGE


%-- START ESTIMATION

% Estimate VARs
[ARs, Sigs, Res, Xtra] = genvars(data,info);
St = struct(); St.ARs = ARs; St.Sigs = Sigs; St.Res = Res;
if isfield(Xtra,'bvecm'); St.bvecm = Xtra.bvecm; info.settings.bvecm = Xtra.bvecm; end
clear Xtra
info = run_stage(info,'estimation',St);

%--END OF ESTIMATION STAGE


%--START IDENTIFICATION STAGE

% Reduced form VAR
% ---------------------------------------------------------------
%   Table 1   shock_extract=1, KLbar=KUbar=100   FEV at horizon 100
%   Table B.4 shock_extract=2, [2*pi/1000,2*pi/2]  2-1000 quarters
%   Table B.5 shock_extract=2, [2*pi/32,  2*pi/6]  6-32   quarters

% Aproj_draw, not Aproj: genmaxshare_final reads page j for draw j and the
% last page for the point estimate. With draw = false the pages are copies.
idx   = struct('Aproj',Aproj_draw, 'keys',{datakeys}, 'nvnames',numel(vnames));
Rall  = cell(1, numel(info.ident));
for k = info.idrun(:)'
    Rall{k} = genmaxshare_final(ARs, Sigs, Res, id_cfg(info, k, idx));
    fprintf('  identification %d/%d: %s\n', k, numel(info.ident), info.ident(k).label);
end

Rb = Rall{1};
dataplots = Rb.dataplots;  vardec_fd = Rb.vardec_fd;
country   = info.country;

% CLEARED FIRST. The caller's workspace is not cleared, so without this a spec
% run with idrun = 1 inherits whatever the PREVIOUS cell left under these names
% and run_stage saves them as its own. That is not hypothetical: before this line,
% eq/tb/forTFP/nofx each carried the BASELINE's dataplots_AF and dataplots_HF,
% bit-identical, while their own dataplots was correct. id_meta named only the one
% pass that ran, so the file contradicted itself.
clear dataplots_AF vardec_fd_AF dataplots_HF vardec_fd_HF

% Appendix copies, present only if those passes were asked for.
if numel(Rall) >= 2 && ~isempty(Rall{2})
    dataplots_AF = Rall{2}.dataplots;  vardec_fd_AF = Rall{2}.vardec_fd;
end
if numel(Rall) >= 3 && ~isempty(Rall{3})
    dataplots_HF = Rall{3}.dataplots;  vardec_fd_HF = Rall{3}.vardec_fd;
end

% id_meta: one entry per pass that ran, keyed by label.
id_meta = struct('note', ['dataplots/vardec_fd = pass 1 (Table 1). Suffixed ' ...
    '_AF/_HF are passes 2/3 (Tables B.4/B.5). vardec_fd is empty for any pass ' ...
    'with want_vardec_fd=false -- see genmaxshare_final.']);
for k = info.idrun(:)'
    id_meta.(matlab.lang.makeValidName(info.ident(k).label)) = Rall{k}.cfg;
end
clear Rall idx



%% CJ identification in one sweep
% factor tfp & noise spectra, then
% tfp + noise impulse responses and variance shares.  Resolvents
% (I-Bz)\C are evaluated grid-at-once with tf_sweep (Schur/eig fast
% paths) and the integrands vectorized with pagemtimes (~9x faster).
% Saves tfp_freq.mat, noise.mat (+ tfpcoeffs.mat, noisecoeffs.mat).
Aproj_point = Aproj;  Aproj = Aproj_draw;   %#ok<NASGU> per-draw pages for the CJ pass
gen_cj_irfs_tfsweep;
Aproj = Aproj_point;  clear Aproj_point      % back to the stored 2-D row
% SAVED on the stored window, every draw; the point estimate at full length.
% The in-memory irtfp/irnoise stay at +/-smax for the moments below. See
% cfg.smax_store.
cj_hs = smax;
if isfield(info.settings,'smax_store'); cj_hs = min(smax, info.settings.smax_store); end
cj_w  = smax+1-cj_hs : smax+1+cj_hs;
St = struct(); St.irtfp = irtfp(cj_w,:,:); St.irnoise = irnoise(cj_w,:,:);
St.irtfp_pe = irtfp(:,:,end);  St.irnoise_pe = irnoise(:,:,end);
clear cj_hs cj_w
St.vstfp = vstfp; St.vsnoise = vsnoise; St.vstfp_real = vstfp_real;
% Per-draw factorization warning flags: 1 x ndraws each, negligible size, and the
% only way to answer "did any draw's spectral factorization misbehave?" after the
% fact. 
St.warntfp = warntfp; St.warnnoise = warnnoise;
for v = {'dataplots','vardec_fd','dataplots_AF','vardec_fd_AF','dataplots_HF','vardec_fd_HF','id_meta'}
    if exist(v{1},'var'); St.(v{1}) = eval(v{1}); end
end
info = run_stage(info,'identification',St);




%% Table 3 moments -- computed HERE, saved with the run
%
% ONLY WHERE A TABLE READS THEM. write_moments_table runs on `base` and `extend`,
% and write_text_numbers on `base`; no other specification's moments are read by
% any exhibit. Computing them for all sixteen cost about 33 s each, roughly an
% eighth of the sweep. The sweep sets info.want_moments, as it sets idrun and
% trade_windows; a spec left out of it carries no moments, so asking a new
% question of one means re-running that spec.
want_moments = ~isfield(info,'want_moments') || info.want_moments;
if want_moments && exist('irtfp','var') && exist('ARs','var')
    Dm = struct('ARs',{ARs}, 'Sigs',{Sigs}, 'irtfp',irtfp, ...
        'irnoise',irnoise, 'j_cj_horizon',j_cj_horizon, ...
        'vnames',{vnames}, 'Aproj',Aproj, 'keys',{datakeys});
    moments = gentablemoments_final(Dm);
    fprintf('  moments: %d block(s) skipped\n', size(moments.skipped,1));
    % Three of Table 3's ten rows -- Engel beta_Lambda, cov(sum E_t
    % lambda, r-r*) and rho(q_t) -- are computed on data BAND-FILTERED
    % over [2,100] quarter periodicities, per the draft's own note. They
    % come from a separate generator; the published table is a composite.
    % Verified: filtering moves Engel beta from -6.95 to 8.50 against a
    % published 9.29, and makes the Unconditional column exact.
    filtered_moments = gentablefilteredmoments_final(Dm);
    fprintf('  filtered moments: %d block(s) skipped\n', size(filtered_moments.skipped,1));
    clear Dm
    St = struct('moments',moments,'filtered_moments',filtered_moments);
    info = run_stage(info,'moments',St);

    % Table B.6 -- rolling-window trading strategy. Only when the sweep asks for
    % it (the baseline cells set info.trade_windows, as they set idrun). Runs on
    % dataL, the LEVELS matrix the VAR was fit on, so it covers exactly this
    % run's sample, core and vintage. Before 'complete': a stage written after
    % it would reset info.complete.
    if isfield(info,'trade_windows') && ~isempty(info.trade_windows)
        trading = gen_tradingstrategy(dataL, dates, info);
        info = run_stage(info,'trading',struct('trading',trading));
        clear trading
    end
    info = run_stage(info,'complete',[]);
end
