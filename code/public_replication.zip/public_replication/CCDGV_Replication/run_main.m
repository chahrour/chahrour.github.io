% RUN_MAIN  Run the specification described by `info`, end to end.
%
%   A script: it reads `info` from the calling workspace and leaves `info` and
%   its results there. The stages are data and projections, VAR estimation,
%   identification, the technology and noise decomposition, moments, and the
%   trading strategy. run_stage saves each one to the run file.
%
%   See also ESTIMATE_ONE, UNPACK_INFO, RUN_STAGE.

% Put the contents of info into the local names this script, and the scripts it
% calls, expect.
unpack_info;

nvars    = numel(info.inclvarnms);
[manifest, constructed] = ccdgv_manifest();   % data rows, constructed rows
vkey     = {manifest.key};

%% Data stage

% Save the settings that readers of the run file take as top-level variables.
Sc = struct('bound',bound,'bound2',bound2,'vd_fr',vd_fr,'vd_feh',vd_feh, ...
    'nplot',nplot,...
    'confidence_bands',confidence_bands,'point_estimate',point_estimate, ...
    'nvars',nvars,'nlags',nlags,'ndraws',ndraws,'smax',smax, ...
    'j_cj_horizon',j_cj_horizon, ...
    'end_date',info.ed,'country',info.country);
info = run_stage(info,'config',Sc);

% Suffix of the built panel that ryan_data loads, from the TFP vintage.
built_suffix = ['_f' info.settings.fv_requested];

% Load `data` and `dates` from the panels in Data_Replication/Built_Data.
ryan_data;

% Columns of data that are in the VAR.
yidx = var_order(vkey, info.inclvarnms{:})';

% The sample window is binding: a NaN in a VAR column inside it is an error that
% names the series and the quarters. Only the VAR columns are checked.
nanrow = ~all(isfinite(data(:,yidx)), 2);
if any(nanrow)
    if isdatetime(dates); dstr = @(k) char(string(dates(k),'yyyy-QQQ'));
    else;                 dstr = @(k) sprintf('%.2f', dates(k)); end
    lines = {};
    for jj = yidx(:)'
        q = find(~isfinite(data(:,jj)));
        if isempty(q); continue; end
        if jj <= numel(manifest); nm = manifest(jj).name; else; nm = sprintf('col %d', jj); end
        if numel(q) <= 6
            when = strjoin(cellfun(dstr, num2cell(q), 'UniformOutput', false), ', ');
        else
            when = sprintf('%s .. %s (%d quarters)', dstr(q(1)), dstr(q(end)), numel(q));
        end
        lines{end+1} = sprintf('    %-16s %s', nm, when);   %#ok<SAGROW>
    end
    error('run_main:nanInWindow', ...
        ['%d of %d quarters in the DECLARED window %s..%s have a NaN in a VAR ' ...
         'column.\n%s\nThe window is binding: set info.sd (and/or info.ed), which ' ...
         'unpack_info turns into start_date/end_date, to a range these series ' ...
         'cover. datver "%s", inclvar %d.'], ...
        sum(nanrow), size(data,1), dstr(1), dstr(size(data,1)), ...
        strjoin(lines, newline), char(string(info.datver)), info.inclvar);
end
yall  = data;  nvall = size(data,2);
data  = data(:,yidx);
vnames   = [{manifest(1:nvall).name},  {constructed.name}];
vnames_short = [{manifest(1:nvall).short}, {constructed.short}];

% Basis transform, if the specification declares one: y_t = P*z_t - Q*z_{t-1},
% with trP and trQ from unpack_info. genvars estimates on y and make_gam maps
% back to z. dataL keeps the levels, which is the basis of the stored AR block
% and so the one ccdgv_project must use. With no transform, trP = I and trQ = 0.
dataL = data;
if has_transform
    zlag  = data(1:end-1, :);          % z_{t-1}
    znow  = data(2:end,   :);          % z_t
    data  = znow*trP' - zlag*trQ';     % y_t, row t of the estimated system
    % The lag uses one quarter; drop the same row from everything row-indexed.
    dataL = dataL(2:end, :);
    yall  = yall(2:end, :);
    dates = dates(2:end);
    fprintf('  transform: %d of %d variables in first differences; %s\n', ...
            numel(fdvar), nvars, strjoin(trnames, ', '));
    fprintf('  transform consumed 1 quarter; sample now %d obs\n', size(data,1));
else
    assert(isequal(trP, eye(nvars)) && ~any(trQ(:)), 'run_main:badNoOp', ...
        'spec %d declares no transform but trP/trQ are not the identity map.', ...
        info.inclvar);
end

% Project every series on the VAR state.
% projblocks: number of state blocks each series is projected on; an empty
%   manifest entry means nlags, the full companion state.
% Ures: projection residuals, one column per series, NaN where a row was unused.
r2 = NaN(1,nvall); nobs = NaN(1,nvall); Aproj = NaN(nvall,nvars*nlags);
projblocks = NaN(1,nvall);
Ures = NaN(size(yall,1), nvall);
for jj = 1:nvall
    pb = manifest(jj).projblocks;
    if isempty(pb); pb = nlags; end
    projblocks(jj) = pb;
    % Project on dataL, the levels basis.
    [Aproj(jj,:), r2(jj), nobs(jj), Ures(:,jj)] = ...
        ccdgv_project(yall(:,jj), dataL, nlags, pb);
end
if any(projblocks ~= nlags)
    for jj = find(projblocks ~= nlags)
        fprintf('  %-16s projected on %d of %d state blocks (R2 %.4f)\n', ...
                vkey{jj}, projblocks(jj), nlags, r2(jj));
    end
end

% Draw the first stage, if the run asks for it. Aproj_draw is
% nvall x nvars*nlags x (ndraws+1): page j pairs with VAR draw j and the last
% page is the posterior mean. Rows of variables in the VAR are not drawn and keep
% their unit vector. With draw = false every page is a copy of Aproj.
if isfield(info.settings,'proj_prior'); PP = info.settings.proj_prior;
else;                                    PP = struct('draw',false); end
Aproj_draw = repmat(Aproj, 1, 1, ndraws+1);
proj_draw_rec = cell(1, nvall);
% Residual process of each drawn row: innovation variance per draw, and AR
% coefficients. ccdgv_extshare uses them.
proj_s2draw = NaN(nvall, ndraws);
proj_phi    = cell(1, nvall);
% R-squared at the posterior mean. It differs from r2, the OLS fit: the draw is
% GLS under AR errors, on the longest contiguous run of usable rows.
r2_pm = NaN(1, nvall);
if PP.draw
    ndrawn = 0;
    for jj = 1:nvall
        if ~(r2(jj) < 1 - 1e-8); continue; end          % in the VAR: never drawn
        pb = projblocks(jj);
        % Seed from the row's fixed manifest offset, so adding or removing a row
        % does not shift the draws of the others.
        rng(info.settings.proj_seed_base + manifest(jj).seed, 'twister');
        % Row-specific shrinkage, where the manifest sets it.
        PPj = PP;
        if isfield(manifest(jj),'projlambda') && ~isempty(manifest(jj).projlambda)
            PPj.lambda = manifest(jj).projlambda;
        end
        [Adj, amj, recj, s2j] = ccdgv_project_draw(yall(:,jj), dataL, nlags, pb, PPj, ndraws);
        if ~recj.ok
            fprintf('  %-16s too short to draw (%d obs); kept at the point estimate\n', ...
                    vkey{jj}, recj.n);
            continue
        end
        Aproj_draw(jj,:,1:ndraws) = permute(Adj, [3 2 1]);
        Aproj_draw(jj,:,end)      = amj;
        proj_s2draw(jj,:) = s2j(:)';  proj_phi{jj} = recj.phi;
        % R-squared of the posterior-mean fit.
        xj = yall(:,jj);  Ylj = lagmatrix(dataL, 0:nlags-1);
        mj = all(isfinite(Ylj),2) & isfinite(xj);
        uj = xj(mj) - Ylj(mj,:)*amj';
        r2_pm(jj) = 1 - sum((uj - mean(uj)).^2) / sum((xj(mj) - mean(xj(mj))).^2);
        proj_draw_rec{jj} = recj;  ndrawn = ndrawn + 1;
    end
    info.settings.proj_draw_summary = sprintf('%d of %d projected rows', ...
                                              ndrawn, sum(r2 < 1 - 1e-8));
    pl = arrayfun(@(m) ~isempty(m.projlambda), manifest(1:nvall));
    if any(pl)
        for jj = find(pl)
            fprintf('  %-16s first stage shrunk at lambda %g (row setting)\n', ...
                    vkey{jj}, manifest(jj).projlambda);
        end
    end
    fprintf(['  first stage DRAWN for %d of %d rows (lambda %g, decay %g, ' ...
             'AR(%d) errors, block 0 %s)\n'], ndrawn, sum(r2 < 1 - 1e-8), ...
            PP.lambda, PP.decay, PP.arlags, subsref({'penalised','free'}, substruct('{}',{1+PP.free_block0})));
end
% Report rows with fewer usable quarters than others projected on the same
% number of state blocks.
pb_live = projblocks(1:nvall);
for b = unique(pb_live(isfinite(nobs)))
    g = find(pb_live == b & isfinite(nobs));
    if isempty(g); continue; end
    full = max(nobs(g));
    short = g(nobs(g) < full);
    for jj = short(:)'
        fprintf('  %-9s projected on %d of %d quarters (R2 %.4f) -- short for its block\n', ...
                vkey{jj}, nobs(jj), full, r2(jj));
    end
end

% Row j of Aproj is manifest entry j, so the loader's columns must match the
% manifest one for one.
assert(nvall == numel(manifest), ...
    ['loader returned %d columns but the manifest declares %d. They must match ' ...
     'one-for-one and in order.'], nvall, numel(manifest));
datakeys = vkey(1:nvall);

% Record the TFP vintage and source the loader reported.
if exist('tfp_vintage','var'); info.settings.tfp_vintage = tfp_vintage; end
if exist('tfp_source','var');  info.settings.tfp_source  = tfp_source;  end

info.sd_realised = dates(1); info.ed_realised = dates(end);
% Save the data stage. `data` is saved in levels, like everything else in the
% run file; the basis the VAR was fit on is saved as data_est.
St = struct('data',dataL,'data_est',data,'dates',dates, ...
            'vnames',{vnames},'vnames_short',{vnames_short}, ...
            'Aproj',Aproj,'r2',r2,'nobs',nobs,'projblocks',projblocks, ...
            'Ures',Ures,'keys',{datakeys});
St.Aproj_draw = Aproj_draw;  St.proj_draw_rec = {proj_draw_rec};
St.proj_s2draw = proj_s2draw;  St.proj_phi = {proj_phi};  St.r2_pm = r2_pm;
info.settings.proj_prior = PP;
info = run_stage(info,'data',St);

%% Estimation stage: the reduced-form VAR
[ARs, Sigs, Res, Xtra] = genvars(data,info);
St = struct(); St.ARs = ARs; St.Sigs = Sigs; St.Res = Res;
if isfield(Xtra,'bvecm'); St.bvecm = Xtra.bvecm; info.settings.bvecm = Xtra.bvecm; end
clear Xtra
info = run_stage(info,'estimation',St);

%% Identification stage
% One max-share pass per entry of info.idrun:
%   pass 1  shock_extract=1, KLbar=KUbar=100       FEV at horizon 100 (Table 1)
%   pass 2  shock_extract=2, [2*pi/1000, 2*pi/2]   2-1000 quarters (Table C.4)
%   pass 3  shock_extract=2, [2*pi/32,   2*pi/6]   6-32 quarters (Table C.5)
% genmaxshare_final reads page j of Aproj_draw for draw j and the last page for
% the point estimate.
idx   = struct('Aproj',Aproj_draw, 'keys',{datakeys}, 'nvnames',numel(vnames));
Rall  = cell(1, numel(info.ident));
for k = info.idrun(:)'
    Rall{k} = genmaxshare_final(ARs, Sigs, Res, id_cfg(info, k, idx));
    fprintf('  identification %d/%d: %s\n', k, numel(info.ident), info.ident(k).label);
end

% Pass 1 goes under the unsuffixed names.
Rb = Rall{1};
dataplots = Rb.dataplots;  vardec_fd = Rb.vardec_fd;
country   = info.country;

% Remove any appendix results already in the workspace.
clear dataplots_AF vardec_fd_AF dataplots_HF vardec_fd_HF

% Appendix passes, present only if they ran.
if numel(Rall) >= 2 && ~isempty(Rall{2})
    dataplots_AF = Rall{2}.dataplots;  vardec_fd_AF = Rall{2}.vardec_fd;
end
if numel(Rall) >= 3 && ~isempty(Rall{3})
    dataplots_HF = Rall{3}.dataplots;  vardec_fd_HF = Rall{3}.vardec_fd;
end

% id_meta: one entry per pass that ran, keyed by label.
id_meta = struct('note', ['dataplots/vardec_fd = pass 1 (Table 1). Suffixed ' ...
    '_AF/_HF are passes 2/3 (Tables C.4/C.5). vardec_fd is empty for any pass ' ...
    'with want_vardec_fd=false -- see genmaxshare_final.']);
for k = info.idrun(:)'
    id_meta.(matlab.lang.makeValidName(info.ident(k).label)) = Rall{k}.cfg;
end
clear Rall idx

%% Technology and noise decomposition
% gen_cj_irfs_tfsweep factors the TFP and noise spectra and computes the
% technology and noise impulse responses and variance shares. It reads Aproj as
% the per-draw pages.
Aproj_point = Aproj;  Aproj = Aproj_draw;   %#ok<NASGU> per-draw pages for the CJ pass
gen_cj_irfs_tfsweep;
Aproj = Aproj_point;  clear Aproj_point      % back to the stored 2-D row
% Save every draw on the window +/-smax_store, and the point estimate at full
% length. The in-memory irtfp/irnoise keep +/-smax for the moments below.
cj_hs = smax;
if isfield(info.settings,'smax_store'); cj_hs = min(smax, info.settings.smax_store); end
cj_w  = smax+1-cj_hs : smax+1+cj_hs;
St = struct(); St.irtfp = irtfp(cj_w,:,:); St.irnoise = irnoise(cj_w,:,:);
St.irtfp_pe = irtfp(:,:,end);  St.irnoise_pe = irnoise(:,:,end);
clear cj_hs cj_w
St.vstfp = vstfp; St.vsnoise = vsnoise; St.vstfp_real = vstfp_real;
% Per-draw warning flags from the spectral factorisation.
St.warntfp = warntfp; St.warnnoise = warnnoise;
for v = {'dataplots','vardec_fd','dataplots_AF','vardec_fd_AF','dataplots_HF','vardec_fd_HF','id_meta'}
    if exist(v{1},'var'); St.(v{1}) = eval(v{1}); end
end
info = run_stage(info,'identification',St);
%% Moments (Tables 3 and C.3), where the sweep asks for them
want_moments = ~isfield(info,'want_moments') || info.want_moments;
if want_moments && exist('irtfp','var') && exist('ARs','var')
    Dm = struct('ARs',{ARs}, 'Sigs',{Sigs}, 'irtfp',irtfp, ...
        'irnoise',irnoise, 'j_cj_horizon',j_cj_horizon, ...
        'vnames',{vnames}, 'Aproj',Aproj, 'keys',{datakeys});
    moments = gentablemoments_final(Dm);
    fprintf('  moments: %d block(s) skipped\n', size(moments.skipped,1));
    % Three rows of Table 3 (Engel beta_Lambda, cov(sum E_t lambda, r-r*) and
    % rho(q_t)) use data band-filtered over periodicities of 2 to 100 quarters.
    filtered_moments = gentablefilteredmoments_final(Dm);
    fprintf('  filtered moments: %d block(s) skipped\n', size(filtered_moments.skipped,1));
    clear Dm
    St = struct('moments',moments,'filtered_moments',filtered_moments);
    info = run_stage(info,'moments',St);

    % Table C.9: the rolling-window trading strategy, when the sweep asks for it.
    % It runs on dataL, the levels the VAR was fit on, and is saved before the
    % 'complete' stage.
    if isfield(info,'trade_windows') && ~isempty(info.trade_windows)
        trading = gen_tradingstrategy(dataL, dates, info);
        info = run_stage(info,'trading',struct('trading',trading));
        clear trading
    end
    info = run_stage(info,'complete',[]);
end
