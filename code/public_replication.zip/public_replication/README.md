> **Preliminary replication package readme prepared by Claude.**
>
> Items marked **[Authors: …]** still need the authors' input before deposit.

# Replication package for "Exchange Rate Disconnect Revisited"

Ryan Chahrour, Vito Cormun, Pierre De Leo, Pablo Guerrón-Quintana, and Rosen Valchev

## Overview

The code in this replication package builds the dataset of the paper from raw
inputs, estimates every specification the paper reports, and produces every
figure and table in the paper and its appendices. It is written in MATLAB. One
master script, `run_all.m`, runs all four stages:

1. Build the data panels from the raw files in `Data_Replication/Raw_Data`.
2. Estimate 16 specifications (15 Bayesian VARs and a Bayesian VECM), 1000
   posterior draws each.
3. Draw the empirical figures and write the tables.
4. Draw the model figures (Figures 8 and D.1) from stored model solutions.

A full run takes about 30 minutes on a recent laptop with a parallel pool, and
needs about 5.5 GB of free disk space for the estimation output.

## Data Availability and Provenance Statements

The paper uses secondary data only. Most sources are public; four files come
from subscription databases (LSEG Datastream, MSCI through Datastream, and Global
Financial Data). Every raw file the code reads is in `Data_Replication/Raw_Data`,
and the build reads only those files: it needs no network access and no
credentials.

### Statement about Rights

- [ ] I certify that the author(s) of the manuscript have legitimate access to and permission to use the data used in this manuscript.
- [ ] I certify that the author(s) of the manuscript have documented permission to redistribute/publish the data contained within this replication package. Appropriate permission are documented in the [LICENSE.txt](LICENSE.txt) file.

**[Authors: confirm both statements. The LSEG, MSCI and Global Financial Data
files listed below are included in this preliminary package; their providers'
terms generally restrict redistribution.]**

### License for Data

**[Authors: choose a license, for example CC-BY 4.0, and add `LICENSE.txt`. Data
from LSEG, MSCI and Global Financial Data remain subject to their providers'
terms.]**

### Summary of Availability

- [ ] All data **are** publicly available.
- [x] Some data **cannot be made** publicly available.
- [ ] **No data can be made** publicly available.

### Details on each Data Source

| Data.Name | Data.Files | Location | Provided | Citation |
|---|---|---|---|---|
| Utilization-adjusted US TFP | `data_quarterly_2026.06.04.xlsx` | `Data_Replication/Raw_Data/Fernald/` | Yes | Fernald (2026) |
| Spot exchange rates | `_exchangerates.xlsx` | `Data_Replication/Raw_Data/Datastream_new/` | Yes (proprietary) | LSEG (2026a) |
| Three-month eurocurrency rates | `_interestrates.xlsx` | `Data_Replication/Raw_Data/Datastream_new/` | Yes (proprietary) | LSEG (2026b) |
| MSCI equity indexes | `DATASTREAM_MSCI_DAILY_UPDATED.xlsx` | `Data_Replication/Raw_Data/Datastream_new/` | Yes (proprietary) | MSCI (2026) |
| Ten-year government bonds | `gfd_monthly.csv` | `Data_Replication/Raw_Data/CCDGV/` | Yes (proprietary) | Global Financial Data (2026) |
| OECD national accounts, prices, money | `EO_*.csv`, `CPI_*.csv`, `KEI_*.csv` | `Data_Replication/Raw_Data/OECD/` | Yes | OECD (2026a, 2026b, 2026c) |
| FRED series | `*.csv` | `Data_Replication/Raw_Data/FRED/`, `.../EW/` | Yes | see below |
| Engel and West (2005) data | `EW_DATA_ALL.xlsx` | `Data_Replication/Raw_Data/EW/` | Yes | Engel and West (2005) |
| US trade balance and technology proxies | `USDATA.xlsx` | `Data_Replication/Raw_Data/CCDGV/` | Yes | see below |
| Foreign Solow residuals | `EO_solow_ALL.csv` | `Data_Replication/Raw_Data/OECD/` | Yes | OECD (2026a) |
| Exchange rate news index | `StavrakevaTang_news_index_q.csv` | `Data_Replication/Raw_Data/CCDGV/` | Yes | Stavrakeva and Tang (2026) |
| High-frequency monetary policy surprises | `HFMP_Jarocinski_Karadi.xls` | `Data_Replication/Raw_Data/CCDGV/` | Yes | Jarociński and Karadi (2020) |
| Real NYSE index | `nyse_real_lev` | `Data_Replication/Raw_Data/CCDGV/` | Yes | **[Authors: source]** |

**US total factor productivity.** John Fernald's quarterly, utilization-adjusted
TFP series for the US business sector, vintage of June 4, 2026, downloaded on
July 29, 2026 from https://www.frbsf.org/economic-research/files/quarterly_tfp.xlsx
(column `dtfp_util`). The file at that address is replaced with each new vintage,
so this vintage can no longer be downloaded; it is included. Public, free of charge.

**Exchange rates.** Daily spot rates against the US dollar for Canada, France,
Germany, Italy, Japan, the United Kingdom and the euro (LSEG instrument codes
`CAD=`, `FRF=`, `DEM=`, `ITL=`, `JPY=`, `GBP=`, `EUR=`, bid quotes), January 2,
1976 to July 1, 2026, retrieved from LSEG in July 2026. The French, German and
Italian rates are chained on the euro rate from January 2, 2002. Access requires
an LSEG Workspace or Datastream subscription.

**Interest rates.** Daily three-month eurocurrency deposit rates, middle rates
(Datastream mnemonics `ECCAD3M`, `ECFFR3M`, `ECWGM3M`, `ECITL3M`, `ECJAP3M`,
`ECUKP3M`, `ECUSD3M`), 1975 to July 2026, retrieved from LSEG Datastream on July
29, 2026. Requires a Datastream subscription.

**Equity prices.** Daily MSCI country indexes for the seven countries, price and
gross total return (Datastream mnemonics `MSUSAM$`, `MSITALL`, `MSCNDAL`,
`MSGERML`, `MSJPANL`, `MSUTDKL`, `MSFRNCL`; total return with datatype `MSRI`),
1970 to July 2026, retrieved from LSEG Datastream on July 27, 2026. The VAR and the
figures use the total-return index deflated by CPI. Requires a Datastream
subscription; MSCI's terms also apply.

**Government bonds.** Monthly ten-year government bond yields, price indexes and
total-return indexes for the G7 countries from Global Financial Data (GFD
Indices), 1970 to 2026, purchased in 2026. Requires a GFD subscription.

**OECD data.** Downloaded through the OECD's SDMX interface
(https://sdmx.oecd.org/public/rest/data/) in July and October 2026; each file is
the response to one query, saved as CSV. Public, free of charge, under the OECD's
terms of use.

- Real and nominal private consumption, investment and GDP, and the inputs to the
  foreign Solow residuals: Economic Outlook No. 119 (`OECD.ECO.MAD,DSD_EO@DF_EO`),
  files `EO_consumption_ALL.csv`, `EO_investment_ALL.csv`, `EO_gdp_ALL.csv`,
  `EO_gdp_EWPANEL.csv`, `EO_solow_ALL.csv`.
- Consumer prices: `OECD.SDD.TPS,DSD_PRICES@DF_PRICES_ALL` (`CPI_ALL.csv`), and
  the COICOP 2018 series that continue it for Canada, France, Italy and Japan
  (`CPI_C2018_ALL.csv`).
- German consumption, investment and GDP growth before 1991, and narrow money:
  Key Short-Term Economic Indicators (`OECD.SDD.STES,DSD_KEI@DF_KEI`), files
  `KEI_DEU_*.csv` and `KEI_money_*.csv`.

**FRED.** Retrieved from FRED, Federal Reserve Bank of St. Louis, in 2026. Public,
free of charge.

- `CPIAUCNS` (US CPI, BLS). The BLS did not publish an index for October 2025.
  The 2025Q4 US CPI value in `us_cpi_repair.csv` is the quarterly average of this
  series with October interpolated linearly. **[Authors: the script that makes
  this file is not yet in the package.]**
- `A019RE1Q156NBEA` (US net exports as a share of GDP, BEA).
- `NAEXKP02DEQ661S`, `NAEXKP04DEQ661S` (German consumption and investment volume
  indexes, OECD via FRED); used only by an alternative setting.
- `MANMM101EZM189S` (euro-area M1, OECD via FRED), `MSM4UKQ` (UK M4).

**Engel and West (2005).** The quarterly exchange rate, price, output, money and
interest rate data of Engel and West (2005) for the G7 countries, 1974Q1–2001Q3,
from https://users.ssc.wisc.edu/~cengel/Data/Fundamentals/data.htm. Used for
Figure 7, and for French, German and Italian money before 1999 in Figure C.14.

**US trade balance and technology proxies (`USDATA.xlsx`).** A workbook compiled by
the authors, quarterly, 1976Q1–2018Q4. It holds:

- The US goods trade balance with the six other G7 countries (IMF 2026), as a
  share of US nominal GDP (OECD).
- US real R&D investment, FRED series `Y694RX1Q020SBEA` (BEA).
- US patent applications (Marco et al. 2015), the value of granted patents as a
  share of GDP (Cascaldi-Garcia and Vukotic 2022), and the adoption of new ICT
  standards (Baron and Schmidt 2019).

**[Authors: download dates for these series, and the sources of the extracts.]**

**Foreign Solow residuals.** Built by `Data_Replication/load_solow_rebuild.m` from
OECD Economic Outlook No. 119 (`EO_solow_ALL.csv`: real GDP `GDPV`, real gross
fixed capital formation `ITV`, employment `ET` and hours per worker `HRS`),
1970Q1–2021Q4. For each country, ln A = ln Y − 0.3 ln K − 0.7 ln L, with L hours
times employment and K accumulated from investment by perpetual inventory at 10%
annual depreciation. The series start in 1970Q1, except the UK's (1971Q1),
France's (1980Q1, when its hours series starts) and Germany's (1991Q1). The six
are aggregated from their growth rates with the trade weights below, reweighted
over the countries present each quarter.

**Trade weights.** The six foreign countries are aggregated with fixed weights,
the average of their 1978 and 2008 shares of world trade: Germany 0.2945, Japan
0.1843, France 0.1599, United Kingdom 0.1399, Italy 0.1230, Canada 0.0984 (lines
46–47 of `Data_Replication/data_import_and_transform.m`). **[Authors: source of
the world-trade shares.]**

**Real NYSE index (`nyse_real_lev`).** Quarterly, 1970Q1–2018Q4. The build reads it,
but no exhibit uses it. **[Authors: source, or remove it and the line that reads
it.]**

**Exchange rate news index.** Quarterly news index for the Canadian dollar, euro,
pound and yen, 2002Q2–2020Q3, provided by Vania Stavrakeva and Jenny Tang
(Stavrakeva and Tang 2026). **[Authors: confirm permission to redistribute.]**

**Monetary policy surprises.** Jarociński and Karadi (2020), sheet `For Matlab`,
series `ff4_hf`, from the replication package of that paper. Used for one number
quoted in the text.

## Dataset list

Paths are relative to `Data_Replication/`, except for `Model/saved_model`.

| Data file | Source | Notes | Provided |
|---|---|---|---|
| `Raw_Data/Fernald/data_quarterly_2026.06.04.xlsx` | Fernald (2026) | US TFP | Yes |
| `Raw_Data/Datastream_new/_exchangerates.xlsx` | LSEG (2026a) | Exchange rates | Yes |
| `Raw_Data/Datastream_new/_interestrates.xlsx` | LSEG (2026b) | Interest rates | Yes |
| `Raw_Data/Datastream_new/DATASTREAM_MSCI_DAILY_UPDATED.xlsx` | MSCI (2026) | Equity indexes | Yes |
| `Raw_Data/CCDGV/gfd_monthly.csv` | Global Financial Data (2026) | Bond yields and returns | Yes |
| `Raw_Data/CCDGV/USDATA.xlsx` | Authors' compilation | Trade balance, technology proxies | Yes |
| `Raw_Data/CCDGV/StavrakevaTang_news_index_q.csv` | Stavrakeva and Tang (2026) | News index | Yes |
| `Raw_Data/CCDGV/HFMP_Jarocinski_Karadi.xls` | Jarociński and Karadi (2020) | Monetary policy surprises | Yes |
| `Raw_Data/CCDGV/nyse_real_lev` | **[Authors]** | Read, not used in any exhibit | Yes |
| `Raw_Data/EW/EW_DATA_ALL.xlsx` | Engel and West (2005) | Figure 7; money before 1999 | Yes |
| `Raw_Data/EW/Euro_M1_FRED.csv`, `UK_M4_FRED.csv` | FRED | Money, Figure C.14 | Yes |
| `Raw_Data/OECD/*.csv` | OECD (2026a, b, c) | Consumption, investment, GDP, CPI, money, Solow residual inputs | Yes |
| `Raw_Data/FRED/us_cpi_repair.csv` | Computed from FRED `CPIAUCNS` | US CPI, 2025Q4 | Yes |
| `Raw_Data/FRED/A019RE1Q156NBEA.csv` | FRED | US net exports; read, not used in any exhibit | Yes |
| `Raw_Data/FRED/NAEXKP0*DEQ661S.csv` | FRED | Alternative German splice, not used by default | Yes |
| `Built_Data/Y_benchmark_f2026.csv` | Built by stage 1 | The VAR panel, 1976Q1–2026Q1 | Yes |
| `Built_Data/AP_returns_f2026.csv` | Built by stage 1 | Expected-return inputs and bond yields | Yes |
| `Built_Data/EQ_real_msci_f2026.csv` | Built by stage 1 | Real equity indexes | Yes |
| `Built_Data/Y_ew.csv` | Built by stage 1 | Granger-causality panel, Figure C.14 | Yes |
| `Model/saved_model/*.mat` | Computed with Dynare | Model impulse responses | Yes |

These files are in the package but not read by the default build:
`Raw_Data/CCDGV/OECD_GDP.xlsx`, `OECD_CPI.xlsx`;
`Raw_Data/EW/Canada_M1_FRED.csv`, `US_M1_FRED.csv`, `Japan_M1_OECD.xlsx`;
`Raw_Data/FRED/CPIAUCNS.csv` (the source of `us_cpi_repair.csv`);
`Raw_Data/OECD/KEI_money_UK_MABM.csv`; `Raw_Data/OECD_orig/*.xlsx` (alternative
setting); and the documentation files `EO119_Database_documentation.pdf`,
`G7 10-Year Bond Series Information.xlsx`, `GFD readme.txt` and the `SOURCE.txt`
files.

The CSV files in `Built_Data` are a readable copy of the panels; the estimation
reads the `.mat` versions, which stage 1 writes.

## Computational requirements

### Software Requirements

- **MATLAB.** Developed on R2025b and run in full on R2026a. Toolboxes:

  | Toolbox | Used for |
  |---|---|
  | Statistics and Machine Learning | `chi2rnd`, `chi2cdf`, `tinv`, `corr` |
  | Econometrics | `lagmatrix`; HAC standard errors (`myhac.m` calls its internal functions) |
  | Financial | `lbusdate`, in the data build |
  | Parallel Computing (optional) | `parfor` loops; without it they run serially, with the same results |

- **LaTeX** (optional). `pdflatex` compiles `Figures_Tables/paper_exhibits.tex`,
  which collects every exhibit in one document. The code looks for it with the
  shell command `which pdflatex`, which fails on Windows and, on macOS, in a
  MATLAB started from the Dock, whose path usually lacks `/Library/TeX/texbin`.
  Without it, the figures and tables are still written, but the
  `paper_exhibits.pdf` that ships with the package is not replaced; MATLAB prints
  a note saying so.
- **Dynare 6.1 and the Symbolic Math Toolbox** (optional). Needed only to re-solve
  the theoretical models. The default run draws the model figures from the
  solutions stored in `Model/saved_model`.

No other software needs installing. `run_all.m` resets MATLAB's path and adds only
this package's folders, so it is both the setup program and the master script.
The package was run on macOS.

### Controlled Randomness

- [x] Random seeds are set in the code:
  - Posterior draws of the VARs: line 35 of `CCDGV_Replication/genvars.m`
    (`randn('state',0)`).
  - Posterior draws for the series outside the VAR (Appendix B.3): line 50 of
    `CCDGV_Replication/Auxiliary_Functions/ccdgv_project_draws.m`, seeded from
    `cfg.proj_seed_base = 2300` in `config.m` plus a fixed offset for each series.
  - The Bayesian VECM: line 39 of
    `CCDGV_Replication/Auxiliary_Functions/ccdgv_bvecm.m` (`rng(0,'twister')`).

The only random draws inside a parallel loop are those of the rolling-window
estimates behind Table C.9 (`gen_tradingstrategy.m`), and each window reseeds
through `genvars.m`. Results with and without a parallel pool therefore agree up
to floating-point rounding. For the 15 VARs, the first n draws of a run equal an
n-draw run; the VECM's draws depend on the total number of draws.

### Memory, Runtime, Storage Requirements

#### Summary

Approximate time needed to reproduce the analyses on a standard 2026 desktop
machine:

- [ ] <10 minutes
- [x] 10-60 minutes
- [ ] 1-2 hours
- [ ] 2-8 hours
- [ ] 8-24 hours
- [ ] 1-3 days
- [ ] 3-14 days
- [ ] > 14 days

Approximate storage space needed:

- [ ] < 25 MBytes
- [ ] 25 MB - 250 MB
- [ ] 250 MB - 2 GB
- [x] 2 GB - 25 GB
- [ ] 25 GB - 250 GB
- [ ] > 250 GB

#### Details

The package itself is about 25 MB. Stage 2 writes about 5.1 GB to
`CCDGV_Replication/saved_results`, about 320 MB per specification. Stage 3 adds a
further 313 MB file there, for Figure C.13. The figures and tables take under
10 MB. **[Authors: memory of the machine used for the full run.]**

A full run from raw inputs, with 1000 draws, took 30 minutes in MATLAB R2026a with
a parallel pool on **[Authors: laptop model, processor, memory, macOS version]**.
Rerunning stage 3 alone takes about 2 minutes on an Apple M1 Max (10 cores, 64 GB
of memory, macOS 26) in MATLAB R2025b, once the Figure C.13 file exists.

## Description of programs/code

```
run_all.m          master script: path setup, then stages 1-4
config.m           every setting, in one struct

Data_Replication/  stage 1
  build_all_vintages.m          runs the data build
  data_import_and_transform.m   reads Raw_Data and writes the panels in Built_Data
  build_ew_panel.m              the panel for the Granger-causality tests (Figure C.14)
  fetch_oecd_sdmx.m             reads, or with cfg.use_cache = false downloads, an OECD query
  load_solow_rebuild.m          the foreign Solow residuals, from OECD Economic Outlook data
  geo_aggregate*.m              trade-weighted aggregates of the six foreign countries
  Raw_Data/                     raw inputs (see above)
  Built_Data/                   panels written by stage 1

CCDGV_Replication/ stages 2 and 3
  sweep.m           the table of 16 specifications and the loop over them
  estimate_one.m    one specification: data, estimation, identification, moments
  exhibits.m        calls each figure and table generator in paper order
  genplots_*.m, genfig_*.m, genpoorman.m     figure generators
  write_*.m         table generators
  Auxiliary_Functions/   estimation, identification, the projection of series
                         outside the VAR (Appendix B.3), plotting
  Bayesian_VECM/    an implementation of Villani (2005), for the VECM specification
  DSGE_tools/       filtering and variance-decomposition utilities
  Load_Data/        the asset-price and per-country series
  saved_results/    one file per specification, written by stage 2

Model/             stage 4
  run_model.m        draws Figures 8 and D.1 from saved_model/
  model_resolve.m    optional: re-solves the models with Dynare
  saved_model/       the models' impulse responses
  Dynare/            the .mod files and parameter scripts

Figures_Tables/
  Figures/, Tables/    output, one file per exhibit, named by its number in the paper
  Hand/                Tables 4, D.1 and D.2, which are typed by hand
  paper_exhibits.tex   collects every exhibit in one document
```

The 16 specifications are the baseline VAR (1978Q4–2008Q2), the extended sample
(1978Q4–2020Q1), six alternative specifications for Appendix C (among them a
Bayesian VECM), two used only in the responses to the referees, and one VAR for
each of the six foreign countries. Their samples are in `sweep.m`.

### License for Code

**[Authors: choose a license, for example the Modified BSD License, and add it to
`LICENSE.txt`.]**

## Instructions to Replicators

1. Open MATLAB in a new session, so that no other code is on the path.
2. Change to the folder that holds this README.
3. Optionally, edit `config.m` (see below).
4. Run `run_all`.

Figures are written to `Figures_Tables/Figures`, tables to
`Figures_Tables/Tables`, and, if `pdflatex` is available, the collected exhibits
to `Figures_Tables/paper_exhibits.pdf`.

### Details

- **Stage 1** is skipped when the four `.mat` panels are already in
  `Data_Replication/Built_Data`; delete them to rebuild. A new copy of the
  package has none, so its first run builds them. The build reads the files in
  `Raw_Data` and does not go online. Setting `cfg.use_cache = false` (and
  deleting the panels) downloads the OECD and FRED series of the main panel again
  and **overwrites the files in `Raw_Data`** with current vintages, which differ
  from the ones used in the paper. It does not refresh the Granger-causality
  panel's inputs. No FRED API key is needed.
- **Stage 2** re-estimates every specification and overwrites
  `saved_results`. With `cfg.estimate = false`, `run_all` skips it and redraws
  the exhibits from the results already there. `cfg.ndraws` sets the number of
  posterior draws (1000 in the paper); 25 is enough to check that the code runs.
- **Stage 4** needs the baseline estimate from stage 2. To re-solve the models
  first, set `cfg.resolve_models = true` and `cfg.dynare_path` to Dynare's
  `matlab/` folder. After a re-solve, start a new MATLAB session before any
  further empirical work: `Model/Dynare` holds functions that would shadow the
  estimation code.
- The sample of each specification is binding: if a VAR variable is missing
  within it, the run stops and names the series and quarters.

## List of tables and programs

Line numbers refer to `CCDGV_Replication/exhibits.m` unless another program is
named. Output files are in `Figures_Tables/Figures` and `Figures_Tables/Tables`.

| Figure/Table # | Program | Line Number | Output file | Note |
|---|---|---|---|---|
| Figure 1 | `genplots_uhlig.m` | 40 | `Figure1.pdf` | |
| Table 1 | `write_uhlig_tables.m` | 41 | `Table1.tex` | |
| Figure 2 | `genplots_paper.m` | 44 | `Figure2a.pdf`, `Figure2b.pdf` | |
| Figures 3, 4 | `genplots_paper.m` | 44 | `Figure3.pdf`, `Figure4.pdf` | |
| Table 2 | `write_vd_table.m` | 46 | `Table2.tex` | |
| Table 3 | `write_moments_table.m` | 47 | `Table3.tex` | |
| Figure 5 | `genfig_asset_proj.m` | 49 | `Figure5a.pdf`, `Figure5b.pdf` | |
| Figure 6, Table C.8 | `genpoorman.m` | 50 | `Figure6.pdf`, `TableC8.tex` | |
| Figure 7, Figure C.14 | `genplots_ew.m` | 53 | `Figure7a.pdf`, `Figure7b.pdf`, `FigureC14a.pdf`, `FigureC14b.pdf` | |
| Figure 8 | `Model/genfig_model.m` | `Model/run_model.m`, 47–48 | `Figure8a.pdf`, `Figure8b.pdf` | |
| Table 4 | — | — | `Figures_Tables/Hand/Table4.tex` | Calibration, typed by hand |
| Figure C.1 | `genplots_uhlig.m` | 61 | `FigureC1.pdf` | Extended sample |
| Table C.1 | `write_uhlig_tables.m` | 62 | `TableC1.tex` | Extended sample |
| Figures C.2–C.4 | `genplots_paper.m` | 65 | `FigureC2a.pdf`, `FigureC2b.pdf`, `FigureC3.pdf`, `FigureC4.pdf` | Extended sample |
| Table C.2 | `write_vd_table.m` | 67 | `TableC2.tex` | Extended sample |
| Table C.3 | `write_moments_table.m` | 68 | `TableC3.tex` | Extended sample |
| Tables C.4, C.5 | `write_uhlig_tables.m` | 41 | `TableC4.tex`, `TableC5.tex` | |
| Figure C.5 | `genfig_tb.m` | 72 | `FigureC5.pdf` | |
| Figure C.6 | `genfig_C6.m` | 74 | `FigureC6a.pdf`, `FigureC6b.pdf` | |
| Figures C.7, C.8 | `genfig_C7C8.m` | 76 | `FigureC7.pdf`, `FigureC8.pdf` | |
| Tables C.6, C.7 | `write_alt_tables.m` | 77 | `TableC6.tex`, `TableC7.tex` | |
| Figure C.9 | `genfig_C9.m` | 79 | `FigureC9.pdf` | |
| Figures C.10, C.11 | `genfig_C10C11.m` | 81 | `FigureC10.pdf`, `FigureC11.pdf` | |
| Figure C.12 | `genfig_C12.m` | 83 | `FigureC12.pdf` | |
| Figure C.13 | `genfig_C13.m` | 85 | `FigureC13.pdf` | |
| Figure C.15 | `genfig_C15.m` | 87 | `FigureC15a.pdf`, `FigureC15b.pdf` | |
| Table C.9 | `write_trading_table.m` | 88 | `TableC9.tex` | |
| Figure D.1 | `Model/genfig_model_lrr.m` | `Model/run_model.m`, 49 | `FigureD1a.pdf`, `FigureD1b.pdf` | |
| Tables D.1, D.2 | — | — | `Figures_Tables/Hand/TableD1.tex`, `TableD2.tex` | Calibration, typed by hand |
| Numbers quoted in the text | `write_text_numbers.m`, `write_asset_proj_vd_table.m` | 91–92 | `tab_text_numbers.tex`, `tab_asset_proj_vd.tex` | |

Lines 96–104 draw the figures in the responses to the referees
(`shock_series_R1.pdf`, `R2a.pdf` to `R5b.pdf`), and line 91 also writes the
numbers quoted in those responses (`tab_response_numbers.tex`). They are not in
the paper.

The table files hold only the `tabular` environment; the paper supplies the
caption and notes.

## Checking a change

Not part of reproducing the paper. `ccdgv_digest(file)` reduces a results file to
every number an exhibit reads, and `ccdgv_digest_cmp(A, B)` lists the
differences between two such digests. Use `struct('mode','median')` as a third
argument to compare runs with different draw counts or from different machines.
Figure PDFs are not comparable byte for byte, since they embed a time stamp.

## References

**[Authors: verify Adjemian et al. (2024), Baron and Schmidt (2019),
Cascaldi-Garcia and Vukotic (2022) and Marco et al. (2015), which were written
from memory, and add access dates where they are missing.]**

Adjemian, Stéphane, et al. 2024. "Dynare: Reference Manual, Version 6." Dynare
Working Papers 80, CEPREMAP.

Baron, Justus, and Julia Schmidt. 2019. "Technological Standardization,
Endogenous Productivity and Transitory Dynamics." Working paper.

Cascaldi-Garcia, Danilo, and Marija Vukotic. 2022. "Patent-Based News Shocks."
*Review of Economics and Statistics* 104 (1): 51–66.

Engel, Charles, and Kenneth D. West. 2005. "Exchange Rates and Fundamentals."
*Journal of Political Economy* 113 (3): 485–517. Data at
https://users.ssc.wisc.edu/~cengel/Data/Fundamentals/data.htm.

Federal Reserve Bank of St. Louis. 2026. FRED, Federal Reserve Economic Data:
series `CPIAUCNS`, `A019RE1Q156NBEA`, `NAEXKP02DEQ661S`, `NAEXKP04DEQ661S`,
`MANMM101EZM189S`, `MSM4UKQ`, `Y694RX1Q020SBEA`. https://fred.stlouisfed.org
(accessed 2026).

Fernald, John G. 2026. "A Quarterly, Utilization-Adjusted Series on Total Factor
Productivity," vintage of June 4, 2026. Federal Reserve Bank of San Francisco.
https://www.frbsf.org/economic-research/files/quarterly_tfp.xlsx (accessed July
29, 2026). Method described in Federal Reserve Bank of San Francisco Working Paper
2012-19.

Global Financial Data. 2026. "GFD Indices: G7 Ten-Year Government Bond Yields,
Price and Total Return Indexes," monthly. https://globalfinancialdata.com
(accessed 2026).

International Monetary Fund. 2026. "International Trade in Goods (by partner
country)." IMF Data, https://data.imf.org. **[Authors: access date.]**

Jarociński, Marek, and Peter Karadi. 2020. "Deconstructing Monetary Policy
Surprises—The Role of Information Shocks." *American Economic Journal:
Macroeconomics* 12 (2): 1–43.

LSEG. 2026a. "Spot Exchange Rates against the US Dollar, Daily (CAD=, FRF=,
DEM=, ITL=, JPY=, GBP=, EUR=)." LSEG Data & Analytics (accessed July 2026).

LSEG. 2026b. "Three-Month Eurocurrency Deposit Rates, Daily (ECCAD3M, ECFFR3M,
ECWGM3M, ECITL3M, ECJAP3M, ECUKP3M, ECUSD3M)." LSEG Datastream (accessed July 29,
2026).

Marco, Alan C., Michael Carley, Steven Jackson, and Amanda F. Myers. 2015. "The
USPTO Historical Patent Data Files: Two Centuries of Innovation." USPTO Economic
Working Paper 2015-1.

MSCI. 2026. "MSCI Country Indexes, Price and Gross Total Return, Daily: Canada,
France, Germany, Italy, Japan, United Kingdom, USA." Via LSEG Datastream
(accessed July 27, 2026).

OECD. 2026a. "Economic Outlook No. 119." OECD Data Explorer,
https://sdmx.oecd.org/public/rest/data/OECD.ECO.MAD,DSD_EO@DF_EO (accessed 2026).

OECD. 2026b. "Consumer Price Indices." OECD Data Explorer,
https://sdmx.oecd.org/public/rest/data/OECD.SDD.TPS,DSD_PRICES@DF_PRICES_ALL
(accessed 2026).

OECD. 2026c. "Key Short-Term Economic Indicators." OECD Data Explorer,
https://sdmx.oecd.org/public/rest/data/OECD.SDD.STES,DSD_KEI@DF_KEI (accessed
2026).

Stavrakeva, Vania, and Jenny Tang. 2026. "A Fundamental Connection: Exchange
Rates and Macroeconomic Expectations." *Review of Economics and Statistics* 108
(5): 1332–48.

Villani, Mattias. 2005. "Bayesian Reference Analysis of Cointegration."
*Econometric Theory* 21 (2): 326–57.

## Acknowledgements

**[Authors: research assistance, data providers.]**
