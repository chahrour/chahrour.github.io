# Replication package

Code and data for *Exchange Rates and Technology Expectations* (CCDGV). Running one
command rebuilds the data from its raw sources, estimates every specification, and
produces every figure and table in the paper.

## How to run it

Open MATLAB in a **fresh session**, `cd` to this folder, and type:

```matlab
run_all
```

That is the whole procedure. Roughly an hour on a recent laptop, and it is worth
knowing where that hour goes, because three of the four stages are cheap:

| stage | cost |
|---|---|
| 1. build the data panels | ~6 min, and skipped entirely when `Built_Data` is present |
| 2. estimate 16 specifications | **nearly all of the hour** — and Table B.9's trading strategy is 310 s of it, about 11%, for one table |
| 3. figures and tables | ~3 min |
| 4. model exhibits | seconds, from stored IRFs |

So `cfg.estimate = false` turns an hour into a few minutes whenever the
estimates have not changed, and `cfg.ndraws = 25` makes stage 2 itself a
plumbing check rather than a result.

Stage 2 uses a parallel pool if one is available and runs serially otherwise, with
identical results either way. The timings above were measured on a 10-worker pool;
with fewer workers stage 2 scales roughly in proportion, and the other stages are
unaffected. Figures land in `Figures_Tables/Figures`, tables in
`Figures_Tables/Tables`, and `Figures_Tables/paper_exhibits.tex` collects them into
one document.

**The fresh session matters.** `run_all` calls `restoredefaultpath` and then adds
only this package's folders, because MATLAB's path is global and a session that has
other copies of these function names on it can silently resolve to the wrong one.
`run_all` checks that the functions it needs resolve inside this folder and stops if
they do not.

Developed and tested on MATLAB R2025b. Required toolboxes, as MATLAB's own
dependency analysis reports them:

| toolbox | needed for |
|---|---|
| Statistics and Machine Learning | the posterior draws (`chi2rnd`, `quantile`) |
| Econometrics | `lagmatrix` throughout the projection stage, the VECM specification, HP filtering |
| Financial | `lbusdate`, the last business day of a quarter |

Parallel Computing is optional. The estimation uses `parfor`, which MATLAB runs
serially when the toolbox is absent — the results are the same, it just takes
longer.

## Settings

Everything adjustable is in `config.m`, which returns one struct. The sample is
not among them: each specification's start and end are in `sweep`'s own table,
because they differ by specification and by country.

```matlab
cfg.ndraws         = 1000;     % posterior sample
cfg.estimate       = true;     % false re-renders exhibits from saved_results
cfg.resolve_models = false;    % re-solve the models with Dynare (see below)
```

`cfg.estimate = false` skips the sweep and rebuilds every figure and table from
the runs already in `saved_results` — minutes instead of most of an hour, and
what you want when only a figure or a table has changed. It re-renders; it does
not re-check. The exhibits then reflect whatever those run files hold, so
anything that moves the estimates — a manifest edit, a projection setting, a data
rebuild — needs it `true`. `sweep` itself always re-estimates and overwrites, with
no skip-if-present shortcut.

`cfg.ndraws = 1000` is the posterior sample. **25 draws runs in about 20 seconds and
is enough to check that the pipeline works, but it is not publishable** — and a
25-draw run is not the first 25 draws of a 1000-draw run, because the draws are
generated as one block whose shape depends on the count.

The sample window is **binding**. If a VAR variable is missing anywhere inside the
requested window, the run stops and names the series and the quarters rather than
dropping those rows and estimating a shorter sample.

## Layout

```
run_all.m          the only entry point: build -> estimate -> exhibits
config.m           every setting, one struct

Data_Replication/
  build_all_vintages.m      drives the data build
  data_import_and_transform.m   assembles the panels from raw sources
  build_ew_panel.m          the panel behind the Granger-causality exhibits
  Raw_Data/                 every raw input, ~45 MB. One folder: the estimation
                            code used to carry a second copy, and six files were
                            byte-identical across the two. The files that lived
                            only there are under Raw_Data/CCDGV.
  Built_Data/               the panels the estimation reads, written by stage 1
                            (not in version control: stage 1 rebuilds them)

CCDGV_Replication/
  sweep.m           the specification table and the loop over it
  estimate_one.m    one specification end to end
  exhibits.m        the ordered list of generator calls
  ccdgv_digest.m    reduces a run file to a comparable fingerprint
  genfig_*.m        figure generators
  genplots_*.m      figure generators
  write_*.m         table generators
  Auxiliary_Functions/   estimation, identification, projection, plotting
  Load_Data/        the asset-price block and the per-country series
  Bayesian_VECM/    Villani (2005) library, used by the VECM specification
  DSGE_tools/       filtering and variance-decomposition utilities
  saved_results/    one .mat per specification (not in version control)

Model/
  run_model.m        Figures 8, 9 and C.1, from stored IRFs -- no Dynare needed
  model_config.m     every model-block setting, one struct
  model_data.m       the empirical panels, resolved by name from the baseline run
  model_resolve.m    OPTIONAL: re-solve the models with Dynare 6.1
  saved_model/       the solved models' impulse responses, 172 KB (in version control)
  Dynare/            the .mod files and the re-solve chain

Figures_Tables/
  paper_exhibits.tex   collects every exhibit
  Hand/                the calibration tables, copied verbatim from the draft
  Figures/  Tables/    generated output (not in version control)
```

## The three stages

**1. Data.** `build_all_vintages` runs `data_import_and_transform`, which reads the
spreadsheets and cached API responses in `Data_Replication/Raw_Data` and writes the
panels in `Built_Data`. **It needs no network and no credentials**: every web
source is read from a cached response in `Raw_Data`, so the build is offline and
deterministic. It is skipped when the panels are already present; delete
`Built_Data` to force a rebuild, which costs nothing but time — the folder holds
only output, and a fresh clone has none of it.

**2. Estimation.** `sweep(cfg)` runs the 16 specifications in its table and writes
one file per specification into `saved_results`, returning their descriptors. Each
specification differs only in which variables enter the VAR, which country, and the
sample; everything else comes from `config.m`. The per-specification start dates in
that table are the first quarter each one's variables are all observed — they differ
because the foreign aggregates begin at different dates.

**3. Exhibits.** `exhibits(cfg, S)` calls each generator in paper order.

**4. Model exhibits.** `run_model` draws Figures 8, 9 and C.1. See below.

## One thing to know before reading the code

**The generator filenames match their exhibit numbers; the output filenames do
not.** `genfig_B11.m` makes Figure B.11, but writes `shock_series_new.pdf`. Four
generators produce two exhibits each, and six are named for their content rather
than a number:

| file | exhibit |
|---|---|
| `genplots_uhlig.m` | Figure 1 |
| `genplots_paper.m` | Figures 2, 3, 4 |
| `genfig_asset_proj.m` | Figure 5 |
| `genpoorman.m` | Figure 6, Table B.8 |
| `genplots_ew.m` | Figures 7 and B.13 |
| `genfig_tb.m` | Figure B.5 |
| `genfig_B7B8.m` | Figures B.7 and B.8 |
| `genfig_B9B10.m` | Figures B.9 and B.10 |

The full list, generator to exhibit to output filename, is at the top of
`exhibits.m`.

## What it produces, and what it does not

21 figures (1–7 and B.1–B.14), 12 tables (1–3 and B.1–B.9), the table of numbers
quoted in the text, and the figures from the responses to the referees.

**The model exhibits are included.** See the Model section below.

**One published table is also absent.** The paper's "Variance shares of the projected
series under the five first stages" compares those shares *across* the five
projection stages. With a single stage there is nothing to compare, so the table is
dropped; the individual numbers the text quotes from it appear in the table of
text numbers.

Projected series use one first stage throughout: drawn, AR(2) errors, no shrinkage.

## The model exhibits

Figures 8 and 9 compare the empirical estimate against three solved models, and
Figure C.1 shows a long-run-risk variant. From this folder, in a fresh session:

```matlab
run_model
```

**No Dynare and no Symbolic Math Toolbox.** The three models' impulse responses are
stored in `Model/saved_model`, and the empirical panels come from this package's own
baseline estimate, so this takes seconds once `sweep` has been run.

| model | drawn as |
|---|---|
| Complete markets, CRRA | solid |
| Complete markets, Epstein–Zin | dashed |
| Incomplete markets, CRRA | dotted |

**The left-hand panels are this package's estimate, not the published one.** They
come from the current baseline run rather than the 2024 snapshot the original model
code read, so Figures 8 and 9 differ from the published versions by the data
vintage. The model panels are unaffected.

**Tables 4, C.1 and C.2 are not generated.** They are calibration tables, written by
hand; `Figures_Tables/Hand` holds them copied verbatim from the draft so the
exhibits document is complete.

### Re-solving the models

Optional, and the only step that needs Dynare:

```matlab
model_resolve('all')        % or 'cm1', 'cm3', 'im', 'lrr'
```

Set `mcfg.dynare_path` in `model_config.m` to Dynare's `matlab/` directory first, or
pass it as the second argument. **Dynare 6.1** produced the published figures.

It writes nothing but the impulse responses: every intermediate the chain once
loaded from disk it now keeps in memory.

**It reads no data file at all.** `kalman_paramsmat2026.mat` was described here
as the chain's one input; it is not an input, it is an intermediate the chain
produces and then re-reads. `InformationStructureParameters` computes the Kalman
system from three hardcoded parameters and saves its whole workspace under that
name, and `IRFsFirstOrder` loads it back a few steps later in the same session.
The file is gitignored and absent from a fresh clone, which is why that goes
unnoticed: the chain writes it before it reads it. Everything a re-solve needs is
in the `.mod` files and the parameter scripts beside them.

**Run it in its own MATLAB session.** `Model/Dynare` carries an older
`gen_auxvars` that the model chain needs, and MATLAB's path is global, so having it
loaded would shadow the estimation code. `run_model` asserts the estimation
functions are unshadowed before it draws anything; start a fresh session for
empirical work afterwards.

The technology and noise decomposition runs through the package's own
`gen_cj_irfs_tfsweep`, the same code the empirical exhibits use, rather than the
symbolic factorisation the original model folder shipped.

## Notes on the data

- **TFP** is Fernald's utilization-adjusted series, the vintage dated 2026-06-04,
  which ends 2026Q1. TFP enters as a level built by cumulating the published growth
  rate, so a different vintage shifts every quarter.
- **The foreign Solow residual** is read from the original `G6SolowResiduals.xlsx`
  and its "G6" is four countries before 1991, when the German and Canadian series
  begin. The aggregate is renormalised at entry rather than zero-filled.
- **Exchange rates and interest rates** are quarterly period averages of daily
  Datastream series, except in the two Granger-causality exhibits (Figures 7 and
  B.13), which use end-of-quarter values to match Engel and West (2005).
- **Money** enters only the Granger-causality exhibits. France, Germany and Italy
  have no national narrow aggregate after the euro changeover, so those three use
  Engel and West's series through 1998Q4 and cumulated euro-area growth thereafter.
  The United Kingdom uses OECD narrow money from 1986Q4, extended backward with the
  growth rate of M4.
- **No credentials are needed.** The cached API responses in `Raw_Data` are what the
  build reads. Re-pulling live data requires a FRED key, supplied through the
  `FRED_API_KEY` environment variable.

## Checking a change

The two functions below are developer tools, not a step in reproducing the
paper. Nothing in `run_all` calls them; they exist so that someone changing the
code can prove what the change did.

`ccdgv_digest(file)` reduces a run file to a fingerprint of every number an exhibit
reads, and `ccdgv_digest_cmp(A, B)` reports the differences and names the array each
one is in. Comparing digests is how to tell whether a change moved anything:

```matlab
A = ccdgv_digest('saved_results');     % before
% ... make a change, re-run sweep ...
B = ccdgv_digest('saved_results');     % after
ccdgv_digest_cmp(A, B)                 % exact by default
```

That comparison is only valid when both runs share a random stream — the same
specification at the same draw count. To compare runs that do not, such as a
different draw count, another machine, or this package against the published
reference, pass `opt.mode`:

```matlab
ccdgv_digest_cmp(A, B, struct('mode','median'))   % posterior medians only
```

`'draws'` (the default) compares every element including draws, `'median'`
compares the posterior medians, and `'both'` compares each. Draw-level fields
differ across streams for no reason worth reporting, which is why the default is
wrong for that case.

Figures are a deterministic function of the run files, so the digest is the real
check. Do not compare figure PDFs byte for byte: they embed a creation timestamp,
and the exported canvas size differs across machines, so identical numbers produce
different files.

To run one piece by hand, `run_pathsetup` sets up the path without running anything.
