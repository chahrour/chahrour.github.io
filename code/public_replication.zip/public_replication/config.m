function cfg = config()
%CONFIG  Every setting for the replication package, in one place.
%
%   Change anything here; nothing else in the package needs editing.
%
%   Paths are derived from this file's own location, so the package runs from
%   wherever it is unpacked. There are no environment variables and no symbolic
%   links.

HERE = fileparts(mfilename('fullpath'));

% ---- the two settings a replicator is most likely to change ----------------
cfg.end_date   = 2008 + 1/4;   % last quarter (2008Q2 is the paper's baseline)

% Each specification's start date is in sweep's SPECS table; see
% the table in sweep.m. The requested window is BINDING: a NaN in a VAR column
% inside it is an error, not a dropped row.

% ---- where things go -------------------------------------------------------
cfg.resultdir  = fullfile(HERE, 'CCDGV_Replication', 'saved_results');
cfg.exhibitdir = fullfile(HERE, 'Figures_Tables');
cfg.builtdir   = fullfile(HERE, 'Data_Replication', 'Built_Data');

% ---- the model exhibits ----------------------------------------------------
% Figures 8, 9 and C.1 are built from the impulse responses stored in
% Model/saved_model, so by default they need no Dynare and no Symbolic Math
% Toolbox. Set resolve_models true to re-solve the three models from their .mod
% files first, which is the only step that needs Dynare, and give dynare_path
% YOUR Dynare matlab/ directory. Dynare 6.1 produced the published figures.
cfg.resolve_models = false;
cfg.dynare_path    = '';       % e.g. '/Applications/Dynare/6.1/matlab'

% ---- data ------------------------------------------------------------------
% EVERY PANEL THE PIPELINE READS, not just one. Testing a single filename meant
% a build interrupted after Y_benchmark looked complete, and stage 1 was skipped
% on the next run with the other panels missing or half-written.
cfg.build_data = ~all(cellfun(@(f) isfile(fullfile(cfg.builtdir, f)), ...
    {'Y_benchmark_f2026.mat', 'Y_benchmark.mat', ...
     'AP_returns_f2026.mat',  'EQ_real_msci_f2026.mat', 'Y_ew_f2026.mat'}));
% Fernald TFP vintage. One vintage ships and one is used: the June 2026 file.
% cfg.vintage selects it -- run_main builds built_suffix from it, and that names
% the panel the estimation reads.
cfg.vintage  = '2026';

% ---- fresh data pulls, and the credentials they need -----------------------
% THE DEFAULT IS CACHED AND OFFLINE. Every web source -- OECD SDMX, OECD KEI and
% FRED -- is read from the CSVs saved under Data_Replication/Raw_Data, so a build
% needs no network and no credentials, and reproduces the paper's panels exactly.
% That is what you want unless you are deliberately refreshing the data.
%
% Set use_cache false to re-download everything instead. A missing or empty cache
% file is fetched regardless, so a first build still populates the cache.
cfg.use_cache = true;

% OECD NEEDS NO CREDENTIAL. The SDMX and KEI endpoints are open; the loaders call
% them straight through websave. Nothing to set here.
%
% FRED NEEDS A FREE API KEY, and only when use_cache is false. Get one at
% https://fred.stlouisfed.org/docs/api/api_key.html, then supply it by EITHER
%   - setting the FRED_API_KEY environment variable, or
%   - writing it alone on one line in Raw_Data/FRED/API_KEY.txt (gitignored), or
%   - writing it the same way in ~/.fred_api_key,
% which is the order the resolver tries. DO NOT PASTE IT BELOW AND COMMIT IT:
% this file is in version control and those three locations are not. The setting
% here is a path to a key file, for the case where yours lives somewhere else.
cfg.fred_key_file = '';        % optional; tried first when non-empty

% ---- estimation ------------------------------------------------------------
% false re-renders the exhibits from the runs already in saved_results, skipping
% the sweep. Minutes instead of most of an hour, and the right setting when only
% a figure or table has changed. Set it true for the first run and after any
% change that moves the estimates.
cfg.estimate   = true;
cfg.ndraws     = 1000;         % posterior draws. 25 runs in ~20 s and is enough
                               % to check the plumbing; it is NOT publishable.
cfg.nlags      = 4;
cfg.smax       = 1000;         % frequency-domain truncation for the VD
cfg.smax_store = 250;          % IRF horizons stored; drives the file size
cfg.nimp       = 600;
cfg.nplot      = 40;
cfg.j_cj_horizon = 20;
cfg.bound      = 0.16;
cfg.bound2     = 0.1;

% ---- projection: one first stage, drawn, AR(2) errors ----------------------
% The research code carried five alternative first stages; the paper uses this
% one. proj_seed_base fixes the draw sequence, and each projected row's offset
% is frozen in ccdgv_manifest so that adding or removing a row cannot shift the
% draws of the rows after it.
% lambda is the DEFAULT shrinkage, used by every row that does not ask for its
% own. ccdgv_manifest overrides it per row -- the two expected-return rows use
% 0.05, forecasting future returns, using shrinkage to avoid overfitting.
cfg.proj = struct('lambda', 0, 'arlags', 2, 'decay', 1, ...
                  'free_block0', true, 'draw', true);
cfg.proj_seed_base = 2300;

% ---- variance decomposition ------------------------------------------------
cfg.vd_fr  = [2*pi/100 2*pi/2; 2*pi/3000 2*pi/2; 2*pi/32 2*pi/6];
cfg.vd_feh = [1 4 12 24 40 100];
cfg.vd_arlags = 2;             % AR order for the denominator refit in the
                               % asset-projection variance shares. Must match
                               % cfg.proj.arlags: the share is of the ACTUAL
                               % series, so the residual process has to be the
                               % one the first stage implies.
end
