function cfg = config()
%CONFIG  Every setting for the replication package.
%
%   cfg = config()
%
%   Paths are derived from this file's location.

HERE = fileparts(mfilename('fullpath'));

% Sample end.
cfg.end_date   = 2008 + 1/4;   % last quarter (2008Q2 is the paper's baseline)

% Each specification's start date is in the SPECS table in sweep.m. The window is
% binding: a NaN in a VAR column inside it is an error.

% Output and data folders.
cfg.resultdir  = fullfile(HERE, 'CCDGV_Replication', 'saved_results');
cfg.exhibitdir = fullfile(HERE, 'Figures_Tables');
cfg.builtdir   = fullfile(HERE, 'Data_Replication', 'Built_Data');

% Model exhibits. Figures 8, 9 and D.1 are drawn from stored impulse responses.
% Set resolve_models true to re-solve the models first; that needs Dynare, and
% dynare_path must then be Dynare's matlab/ directory.
cfg.resolve_models = false;
cfg.dynare_path    = '';       % e.g. '/Applications/Dynare/6.1/matlab'

% Data. Stage 1 runs unless every panel the pipeline reads is already built.
cfg.build_data = ~all(cellfun(@(f) isfile(fullfile(cfg.builtdir, f)), ...
    {'Y_benchmark_f2026.mat', 'AP_returns_f2026.mat', ...
     'EQ_real_msci_f2026.mat', 'Y_ew.mat'}));
% Fernald TFP vintage; it names the panel the estimation reads.
cfg.vintage  = '2026';

% Web sources (OECD, FRED) are read from the CSVs cached in Raw_Data. Set
% use_cache false to download them again; a missing cache file is always fetched.
cfg.use_cache = true;

% FRED needs an API key, and only when use_cache is false. It is looked up in the
% FRED_API_KEY environment variable, then Raw_Data/FRED/API_KEY.txt, then
% ~/.fred_api_key. fred_key_file is an optional path to a key file, tried first.
cfg.fred_key_file = '';        % optional

% Estimation. estimate = false skips the sweep and redraws the exhibits from the
% runs already in saved_results.
cfg.estimate   = true;
cfg.ndraws     = 1000;         % posterior draws; 25 is enough to check the plumbing
cfg.nlags      = 4;
cfg.smax       = 1000;         % frequency-domain truncation for the variance decomposition
cfg.smax_store = 250;          % IRF horizons stored
cfg.nimp       = 600;
cfg.nplot      = 40;
cfg.j_cj_horizon = 20;
cfg.bound      = 0.16;
cfg.bound2     = 0.1;

% Projection first stage: drawn, AR(2) errors. lambda is the default shrinkage;
% ccdgv_manifest overrides it for some rows. proj_seed_base fixes the draw
% sequence.
cfg.proj = struct('lambda', 0, 'arlags', 2, 'decay', 1, ...
                  'free_block0', true, 'draw', true);
cfg.proj_seed_base = 2300;

% Variance decomposition: frequency bands and forecast-error horizons.
cfg.vd_fr  = [2*pi/100 2*pi/2; 2*pi/3000 2*pi/2; 2*pi/32 2*pi/6];
cfg.vd_feh = [1 4 12 24 40 100];
% AR order for the denominator of the asset-projection variance shares. Must
% match cfg.proj.arlags.
cfg.vd_arlags = 2;
end
