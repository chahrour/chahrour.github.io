function build_all_vintages()
%BUILD_ALL_VINTAGES  Rebuild EVERY tagged Y_benchmark, not just the default one.
%
%   build_all_vintages()
%
%   data_import_and_transform produces ONE file per invocation, named by
%   cfg.built_suffix. Two are in use: untagged and _f2026, the same vintage
%   "rebuild the data" done by hand naturally refreshes one and leaves the others
%   stale, with nothing downstream able to tell.
%
%   That is not hypothetical. On 2026-08-06 §6b was added to
%   data_import_and_transform (appending TB_G6 and NX_GDP to Y) and only the
%   under both names.
%   sweep loaded a two-days-stale build, ryan_data substituted NaN for both
%   series, and the run produced two dead rows in every result while taking ~20x
%   longer -- the NaNs make the variance-decomposition quadrature fail to
%   converge. The only signal was a warning buried under 3648 others.
%
%   RUN THIS, not data_import_and_transform directly, whenever the builder
%   changes. If you add a vintage, add it here.
%
%   WHY EACH BUILD IS A FUNCTION CALL. data_import_and_transform opens with
%   `clearvars -except <the three overrides>`, which would delete a loop variable
%   living in the same workspace. Calling it inside a function gives it its own
%   workspace to clear, leaving the loop in this one untouched. Do not "simplify"
%   this into a bare for-loop around the script.
%
%   See also DATA_IMPORT_AND_TRANSFORM, RYAN_DATA.

    V = { '2026', '_f2026' };

    % The untagged default is what compare_* scripts and older callers read.
    % The untagged panel: same vintage, no suffix, for callers that do not set
    % built_suffix.
    V(end+1,:) = { '2026', '' };

    fprintf('=== rebuilding %d Y_benchmark variants ===\n', size(V,1));
    for k = 1:size(V,1)
        fprintf('\n--- vintage %s -> Y_benchmark%s.mat ---\n', V{k,1}, V{k,2});
        build_one(V{k,1}, V{k,2});
    end

    % --- the Engel-West panel, one per Fernald vintage ------------------
    % A SECOND DATASET, not a variant of the first. It keeps Engel and West's
    % END-OF-PERIOD convention for the exchange rate and the interest
    % differential (the two Granger exhibits use it; every other exhibit is
    % period-average) and extends EW's published series with newcore growth.
    % build_ew_panel is a function, so it needs no clearvars wrapper.
    fprintf('\n=== building %d Y_ew variants ===\n', 2);
    for k = 1:size(V,1)
        if isempty(V{k,2}); continue; end            % no untagged EW copy
        fprintf('\n--- vintage %s -> Y_ew%s.mat ---\n', V{k,1}, V{k,2});
        build_ew_panel('vintage', V{k,1}, 'suffix', V{k,2});
    end

    fprintf('\n=== verifying ===\n');
    here = fileparts(mfilename('fullpath'));
    for k = 1:size(V,1)
        f = fullfile(here,'Built_Data',['Y_benchmark' V{k,2} '.mat']);
        R = load(f); n = R.Y.Properties.VariableNames;
        fprintf('  %-24s %2d vars  TB_G6:%d NX_GDP:%d  %d rows\n', ...
                ['Y_benchmark' V{k,2} '.mat'], numel(n), ...
                ismember('TB_G6',n), ismember('NX_GDP',n), height(R.Y));
    end
    for k = 1:size(V,1)
        if isempty(V{k,2}); continue; end
        f = fullfile(here,'Built_Data',['Y_ew' V{k,2} '.mat']);
        if ~isfile(f); fprintf('  %-24s MISSING\n', ['Y_ew' V{k,2} '.mat']); continue; end
        R = load(f); n = R.Y.Properties.VariableNames;
        fprintf('  %-24s %2d vars  US_TFP:%d  %d rows  %s..%s\n', ...
                ['Y_ew' V{k,2} '.mat'], numel(n), ismember('US_TFP',n), height(R.Y), ...
                string(R.Y.Time(1),'yyyy-QQQ'), string(R.Y.Time(end),'yyyy-QQQ'));
    end
end

% -------------------------------------------------------------------------
function build_one(vintage, suffix)
%   Its own workspace, so the script's clearvars cannot reach the caller's loop.
%
%   The data source comes from config.m. data_import_and_transform never calls
%   config() -- it opens with clearvars and builds its own cfg -- so the two
%   settings a replicator may want travel through the override gate, which is the
%   only channel into that script. Without this they would be settings that look
%   live in config.m and do nothing.
    fernald_vintage_override = vintage;   %#ok<NASGU>  read by the script
    built_suffix_override    = suffix;    %#ok<NASGU>
    % config.m sits at the package root, which is not on the path when this file
    % is run on its own.
    addpath(fileparts(fileparts(mfilename('fullpath'))));
    C = config();
    use_cache_override    = C.use_cache;      %#ok<NASGU>
    fred_key_file_override = C.fred_key_file; %#ok<NASGU>
    data_import_and_transform
end
