function build_all_vintages()
%BUILD_ALL_VINTAGES  Build every data panel the package reads.
%
%   build_all_vintages()
%
%   Runs data_import_and_transform once per row of V (TFP vintage, file
%   suffix), then build_ew_panel, and lists the files written to Built_Data.
%
%   See also DATA_IMPORT_AND_TRANSFORM, BUILD_EW_PANEL, RYAN_DATA.

    % TFP vintage and file suffix of each build.
    V = { '2026', '_f2026' };

    fprintf('=== building %d Y_benchmark panel(s) ===\n', size(V,1));
    for k = 1:size(V,1)
        fprintf('\n--- vintage %s -> Y_benchmark%s.mat ---\n', V{k,1}, V{k,2});
        build_one(V{k,1}, V{k,2});
    end

    % The Engel-West panel, used by the two Granger exhibits (Figures 7 and
    % C.13). It keeps end-of-period exchange rates and interest differentials,
    % and carries no TFP series, so it has no vintage tag.
    fprintf('\n=== building the Y_ew panel ===\n');
    build_ew_panel();

    % List what was written.
    fprintf('\n=== verifying ===\n');
    here = fileparts(mfilename('fullpath'));
    for k = 1:size(V,1)
        f = fullfile(here,'Built_Data',['Y_benchmark' V{k,2} '.mat']);
        R = load(f); n = R.Y.Properties.VariableNames;
        fprintf('  %-24s %2d vars  TB_G6:%d NX_GDP:%d  %d rows\n', ...
                ['Y_benchmark' V{k,2} '.mat'], numel(n), ...
                ismember('TB_G6',n), ismember('NX_GDP',n), height(R.Y));
    end
    f = fullfile(here,'Built_Data','Y_ew.mat');
    if ~isfile(f)
        fprintf('  %-24s MISSING\n', 'Y_ew.mat');
    else
        R = load(f);
        fprintf('  %-24s %2d vars  %d rows  %s..%s\n', 'Y_ew.mat', width(R.Y), height(R.Y), ...
                string(R.Y.Time(1),'yyyy-QQQ'), string(R.Y.Time(end),'yyyy-QQQ'));
    end
end

function build_one(vintage, suffix)
% Runs data_import_and_transform in its own workspace: the script begins with
% clearvars, and takes its settings from the *_override variables set here.
    fernald_vintage_override = vintage;   %#ok<NASGU>  read by the script
    built_suffix_override    = suffix;    %#ok<NASGU>
    % config.m is at the package root, which may not be on the path.
    addpath(fileparts(fileparts(mfilename('fullpath'))));
    C = config();
    use_cache_override    = C.use_cache;      %#ok<NASGU>
    fred_key_file_override = C.fred_key_file; %#ok<NASGU>
    data_import_and_transform
end
