function logagg = geo_aggregate(tt_levels, weights)
% GEO_AGGREGATE  Trade-weighted geometric mean of country levels, in logs,
%                with per-quarter renormalization over the AVAILABLE countries.
%
%   logagg = GEO_AGGREGATE(tt_levels, weights)
%
%   For each quarter t:  ln(X*_t) = sum_{c in A_t} (w_c / W_t) * ln(X_{c,t}),
%   where A_t is the set of countries with a non-NaN value that quarter and
%   W_t = sum of their weights. A missing country simply gets no weight; the
%   aggregate is NaN only when every country is missing. When all countries are
%   present this reduces to the plain weighted mean sum_c w_c*ln(X_c).
%
%   USE FOR commensurable / always-present series: FX, CPI, interest (gross)
%   rates. For incommensurable LEVELS where a country enters mid-sample (e.g.
%   national-currency consumption/investment with Germany from 1991), use
%   geo_aggregate_growth instead — renormalizing a weighted mean of log-LEVELS
%   would create a spurious jump the quarter the new country enters.
%
%   tt_levels : quarterly timetable, one column per country, in LEVELS (>0).
%   weights   : 1xN row vector aligned to the columns of tt_levels; sums to 1.
%   logagg    : single-column timetable 'lnAgg' with the aggregated log series.

    arguments
        tt_levels timetable
        weights   (1,:) double
    end

    X = tt_levels.Variables;
    assert(size(X,2) == numel(weights), ...
        'geo_aggregate: #columns (%d) must match #weights (%d).', ...
        size(X,2), numel(weights));
    assert(abs(sum(weights)-1) < 1e-6, 'geo_aggregate: weights must sum to 1.');

    L  = log(X);                       % T x N (NaN where a country is missing)
    W  = weights(:)';                  % 1 x N
    A  = ~isnan(L);                    % availability mask
    Lz = L; Lz(~A) = 0;                % zero out NaN so they don't poison the sum
    Wm = A .* W;                       % weight where available, 0 elsewhere
    agg = sum(Wm .* Lz, 2) ./ sum(Wm, 2);   % renormalized; 0/0 -> NaN if all missing

    logagg = array2timetable(agg, 'RowTimes', tt_levels.Time, ...
                             'VariableNames', {'lnAgg'});
end
