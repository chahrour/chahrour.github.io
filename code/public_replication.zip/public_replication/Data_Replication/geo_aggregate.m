function logagg = geo_aggregate(tt_levels, weights)
% GEO_AGGREGATE  Trade-weighted geometric mean of country levels, in logs.
%
%   logagg = GEO_AGGREGATE(tt_levels, weights)
%
%   tt_levels  quarterly timetable of levels (>0), one column per country.
%   weights    1xN row vector aligned to the columns; sums to 1.
%   logagg     single-column timetable 'lnAgg'.
%
%   Each quarter the weights are renormalized over the countries with data:
%       ln(X*_t) = sum_{c in A_t} (w_c / W_t) * ln(X_{c,t})
%   The aggregate is NaN only when every country is missing. Use this for series
%   whose levels are comparable across countries. When a country enters
%   mid-sample with levels in its own units, use GEO_AGGREGATE_GROWTH, which
%   avoids a jump at entry.
%
%   See also GEO_AGGREGATE_GROWTH.

    arguments
        tt_levels timetable
        weights   (1,:) double
    end

    X = tt_levels.Variables;
    assert(size(X,2) == numel(weights), ...
        'geo_aggregate: #columns (%d) must match #weights (%d).', ...
        size(X,2), numel(weights));
    assert(abs(sum(weights)-1) < 1e-6, 'geo_aggregate: weights must sum to 1.');

    L  = log(X);                       % T x N, NaN where a country is missing
    W  = weights(:)';                  % 1 x N
    A  = ~isnan(L);                    % availability mask
    Lz = L; Lz(~A) = 0;                % zero where missing, so the sum ignores it
    Wm = A .* W;                       % weight where available, 0 elsewhere
    agg = sum(Wm .* Lz, 2) ./ sum(Wm, 2);   % 0/0 -> NaN if all missing

    logagg = array2timetable(agg, 'RowTimes', tt_levels.Time, ...
                             'VariableNames', {'lnAgg'});
end
