function logagg = geo_aggregate_growth(tt_levels, weights)
% GEO_AGGREGATE_GROWTH  Trade-weighted geometric aggregate built from log-GROWTH,
%                       robust to countries entering/leaving mid-sample.
%
%   logagg = GEO_AGGREGATE_GROWTH(tt_levels, weights)
%
%   Aggregates the renormalized weighted log-CHANGES and cumulates them:
%       d ln X*_t = sum_{c in A_t} (w_c / W_t) * d ln X_{c,t}
%   anchored at the weighted initial level over the countries available in the
%   first non-empty quarter. This matches the original CONSUMPTION_data.m
%   construction (cumsum of weighted diffs), extended to renormalize over the
%   AVAILABLE countries each quarter.
%
%   USE FOR incommensurable LEVELS with a country entering mid-sample (e.g.
%   national-currency consumption/investment, Germany from 1991): a new country
%   contributes its GROWTH (small) rather than its log-LEVEL (huge, different
%   units), so there is no jump at entry. For fully-present series this equals
%   geo_aggregate exactly. The absolute level is an arbitrary constant (absorbed
%   by the VAR); only the dynamics carry information.

    arguments
        tt_levels timetable
        weights   (1,:) double
    end

    L = log(tt_levels.Variables);      % T x N
    W = weights(:)';
    T = size(L,1);

    % Renormalized weighted log-growth per quarter.
    D  = diff(L);                      % (T-1) x N
    A  = ~isnan(D); Dz = D; Dz(~A) = 0;
    Wm = A .* W;
    aggD = sum(Wm .* Dz, 2) ./ sum(Wm, 2);   % NaN where no country has a growth

    % Anchor at the weighted initial level over the first non-empty quarter.
    aggL   = nan(T,1);
    anyrow = any(~isnan(L), 2);
    t0     = find(anyrow, 1);
    if ~isempty(t0)
        a0       = ~isnan(L(t0,:));
        aggL(t0) = (W(a0)/sum(W(a0))) * L(t0,a0)';
        for t = t0+1:T
            g = aggD(t-1);
            if isnan(g), g = 0; end    % no growth info this quarter -> carry level
            aggL(t) = aggL(t-1) + g;
        end
    end

    logagg = array2timetable(aggL, 'RowTimes', tt_levels.Time, ...
                             'VariableNames', {'lnAgg'});
end
