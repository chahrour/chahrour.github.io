function logagg = geo_aggregate_growth(tt_levels, weights)
% GEO_AGGREGATE_GROWTH  Trade-weighted geometric aggregate built from log growth.
%
%   logagg = GEO_AGGREGATE_GROWTH(tt_levels, weights)
%
%   tt_levels  quarterly timetable of levels (>0), one column per country.
%   weights    1xN row vector aligned to the columns.
%   logagg     single-column timetable 'lnAgg'.
%
%   Aggregates the log changes, with weights renormalized each quarter over the
%   countries that have a change, and cumulates them:
%       d ln X*_t = sum_{c in A_t} (w_c / W_t) * d ln X_{c,t}
%   The level is anchored at the weighted log level of the countries present in
%   the first non-empty quarter, so it is defined up to a constant. A country
%   that enters mid-sample contributes its growth, not its level, so there is no
%   jump at entry.
%
%   See also GEO_AGGREGATE.

    arguments
        tt_levels timetable
        weights   (1,:) double
    end

    L = log(tt_levels.Variables);      % T x N
    W = weights(:)';
    T = size(L,1);

    % Renormalized weighted log growth per quarter.
    D  = diff(L);                      % (T-1) x N
    A  = ~isnan(D); Dz = D; Dz(~A) = 0;
    Wm = A .* W;
    aggD = sum(Wm .* Dz, 2) ./ sum(Wm, 2);   % NaN where no country has a change

    % Anchor at the weighted level in the first non-empty quarter, then cumulate.
    aggL   = nan(T,1);
    anyrow = any(~isnan(L), 2);
    t0     = find(anyrow, 1);
    if ~isempty(t0)
        a0       = ~isnan(L(t0,:));
        aggL(t0) = (W(a0)/sum(W(a0))) * L(t0,a0)';
        for t = t0+1:T
            g = aggD(t-1);
            if isnan(g), g = 0; end    % no growth this quarter: carry the level
            aggL(t) = aggL(t-1) + g;
        end
    end

    logagg = array2timetable(aggL, 'RowTimes', tt_levels.Time, ...
                             'VariableNames', {'lnAgg'});
end
