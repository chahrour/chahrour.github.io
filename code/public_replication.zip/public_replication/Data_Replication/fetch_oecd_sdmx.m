function tt = fetch_oecd_sdmx(dataflowRef, key, varargin)
% FETCH_OECD_SDMX  Download OECD SDMX data into a timetable.
%
%   tt = FETCH_OECD_SDMX(dataflowRef, key, 'Name',Value, ...)
%
%   Calls the OECD Data Explorer SDMX REST API, saves the raw CSV, and returns
%   the observations as a timetable.
%
%   dataflowRef   "AGENCY,DATAFLOW,VERSION", e.g.
%                 "OECD.SDD.NAD,DSD_NAMAIN1@DF_QNA_EXPENDITURE_NATIO_CURR,1.1"
%   key           dot-separated SDMX key, e.g.
%                 "Q.Y.USA.S1M.S1.P3._Z._Z._T.XDC.L.N.T0102". A dimension may be
%                 a '+'-joined list, to pull several series in one request.
%
%   Name-value options
%     'StartPeriod'  SDMX period, default "1970-Q1".
%     'EndPeriod'    SDMX period, default "" (latest available).
%     'RawFile'      where to save the CSV; default "" (a temporary file).
%     'Refresh'      default true. If false and RawFile exists, the cached file
%                    is parsed and nothing is downloaded.
%     'Timeout'      download timeout in seconds, default 120.
%     'ColumnDims'   metadata columns whose values, joined by '_', name each
%                    output column. Default "REF_AREA"; ["REF_AREA","MEASURE"]
%                    gives columns like 'USA_CPV'.
%
%   tt   timetable with period-start row times and one variable per distinct
%        ColumnDims combination.
%
%   Endpoint:
%   https://sdmx.oecd.org/public/rest/data/{REF}/{KEY}?startPeriod=..&format=csvfilewithlabels

    p = inputParser;
    p.addParameter('StartPeriod', "1970-Q1", @(x) isstring(x)||ischar(x));
    p.addParameter('EndPeriod',   "",        @(x) isstring(x)||ischar(x));
    p.addParameter('RawFile',     "",        @(x) isstring(x)||ischar(x));
    p.addParameter('Refresh',     true,      @(x) islogical(x)||isnumeric(x));
    p.addParameter('Timeout',     120,       @isnumeric);
    p.addParameter('ColumnDims',  "REF_AREA",@(x) isstring(x)||ischar(x)||iscellstr(x));
    p.parse(varargin{:});
    opt = p.Results;
    coldims = string(opt.ColumnDims);

    % Build the request URL.
    base = "https://sdmx.oecd.org/public/rest/data";
    url  = base + "/" + string(dataflowRef) + "/" + string(key) + ...
           "?format=csvfilewithlabels";
    if strlength(opt.StartPeriod) > 0
        url = url + "&startPeriod=" + opt.StartPeriod;
    end
    if strlength(opt.EndPeriod) > 0
        url = url + "&endPeriod=" + opt.EndPeriod;
    end

    % Choose where the CSV goes.
    if strlength(string(opt.RawFile)) == 0
        csvfile = string(tempname) + ".csv";
    else
        csvfile = string(opt.RawFile);
        d = fileparts(csvfile);
        if strlength(d) > 0 && ~exist(d,'dir'); mkdir(d); end
    end

    % Download, or reuse the cached file. A 0-byte cached file counts as missing.
    stale = exist(csvfile,'file') && dir(csvfile).bytes == 0;
    web = weboptions('Timeout', opt.Timeout, 'ContentType','text');
    if opt.Refresh || ~exist(csvfile,'file') || stale
        fprintf('  OECD SDMX GET %s\n', url);
        try
            websave(csvfile, url, web);
        catch ME
            if exist(csvfile,'file'); delete(csvfile); end   % do not cache a partial file
            rethrow(ME);
        end
    else
        fprintf('  OECD SDMX (cached) %s\n', csvfile);
    end

    % Parse the CSV.
    T = readtable(csvfile, 'VariableNamingRule','preserve', ...
                  'TextType','string');

    req = [coldims, "TIME_PERIOD", "OBS_VALUE"];
    miss = req(~ismember(req, string(T.Properties.VariableNames)));
    if ~isempty(miss)
        error('fetch_oecd_sdmx:badResponse', ...
              ['Expected column(s) %s not found in %s.\n' ...
               'First bytes of response may be an SDMX error — open the file ' ...
               'or the URL to inspect.'], strjoin(miss,', '), csvfile);
    end

    % Series id per row: the ColumnDims values joined by '_', e.g. "USA_CPV".
    ids = string(T.(char(coldims(1))));
    for d = 2:numel(coldims)
        ids = ids + "_" + string(T.(char(coldims(d))));
    end
    when = parse_oecd_period(T.TIME_PERIOD);
    val  = double(T.OBS_VALUE);

    % Pivot to one column per series on a common period grid.
    series = unique(ids, 'stable');
    times  = unique(when);
    times  = sort(times(~isnat(times)));
    X = nan(numel(times), numel(series));
    for s = 1:numel(series)
        m = ids == series(s);
        [tf, loc] = ismember(when(m), times);
        v = val(m);
        X(loc(tf), s) = v(tf);
    end

    tt = array2timetable(X, 'RowTimes', times, ...
                         'VariableNames', cellstr(series));
end

function dt = parse_oecd_period(p)
% Convert OECD SDMX TIME_PERIOD strings to period-start datetimes:
%   'YYYY-Qn' -> quarter start, 'YYYY-MM' -> month start, 'YYYY' -> January 1.
    p  = string(p);
    dt = NaT(size(p));

    isQ = contains(p, "-Q");
    if any(isQ)
        ab = split(p(isQ), "-Q");
        ab = reshape(ab, [], 2);
        y  = str2double(ab(:,1));  q = str2double(ab(:,2));
        dt(isQ) = datetime(y, (q-1)*3 + 1, 1);
    end

    isM = ~isQ & (strlength(p) == 7) & contains(p, "-");
    if any(isM)
        ab = split(p(isM), "-");
        ab = reshape(ab, [], 2);
        y  = str2double(ab(:,1));  m = str2double(ab(:,2));
        dt(isM) = datetime(y, m, 1);
    end

    isA = ~isQ & ~isM & (strlength(p) == 4);
    if any(isA)
        dt(isA) = datetime(str2double(p(isA)), 1, 1);
    end
end
