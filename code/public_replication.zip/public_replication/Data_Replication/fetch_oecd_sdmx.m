function tt = fetch_oecd_sdmx(dataflowRef, key, varargin)
% FETCH_OECD_SDMX  Download one OECD SDMX data series into a timetable.
%
%   tt = FETCH_OECD_SDMX(dataflowRef, key, 'Name',Value, ...)
%
% Hits the OECD Data Explorer SDMX REST API (the live replacement for the
% retired stats.oecd.org), saves the raw CSV for provenance, and returns the
% observations as a quarterly/monthly timetable. One call = one series.
%
% INPUTS
%   dataflowRef : "AGENCY,DATAFLOW,VERSION"
%                 e.g. "OECD.SDD.NAD,DSD_NAMAIN1@DF_QNA_EXPENDITURE_NATIO_CURR,1.1"
%   key         : dot-separated SDMX key selecting a SINGLE series, e.g.
%                 "Q.Y.USA.S1M.S1.P3._Z._Z._T.XDC.L.N.T0102"
%                 (REF_AREA may also be a '+'-joined list to pull several areas
%                  at once; the result then has one column per REF_AREA.)
%
% OPTIONS (name-value)
%   'StartPeriod' : SDMX period, default "1970-Q1"
%   'EndPeriod'   : SDMX period, default ""  (= latest available)
%   'RawFile'     : path to save the downloaded CSV; default "" (temp file).
%                   Pass a Raw_Data/OECD/... path to keep the raw on disk.
%   'Refresh'     : logical, default true. If false and RawFile already exists,
%                   skip the download and parse the cached file (offline reruns).
%   'Timeout'     : webread/websave timeout in seconds, default 120.
%
%   'ColumnDims'  : string array of metadata columns whose combination names
%                   each output column, joined by '_'. Default ["REF_AREA"].
%                   To pull several measures for several countries in ONE call,
%                   use a '+'-joined key and pass ["REF_AREA","MEASURE"] so the
%                   columns come back as 'USA_CPV', 'USA_CP', ... (combine
%                   requests -> stay well under the API rate limit).
%
% OUTPUT
%   tt : timetable, RowTimes = period-start datetimes. One variable per distinct
%        ColumnDims combination (named by those codes joined with '_'); with the
%        default a single-area key yields one variable named by that area.
%
% The URL it builds is itself the provenance record — log it / keep RawFile.
% Endpoint pattern:
%   https://sdmx.oecd.org/public/rest/data/{REF}/{KEY}?startPeriod=..&format=csvfilewithlabels
%
% See DATA_SOURCES.md (OECD section) for confirmed dataflows and keys.

    p = inputParser;
    p.addParameter('StartPeriod', "1970-Q1", @(x) isstring(x)||ischar(x));
    p.addParameter('EndPeriod',   "",        @(x) isstring(x)||ischar(x));
    p.addParameter('RawFile',     "",        @(x) isstring(x)||ischar(x));
    p.addParameter('Refresh',     true,      @(x) islogical(x)||isnumeric(x));
    p.addParameter('Timeout',     120,       @isnumeric);
    p.addParameter('ColumnDims',  "REF_AREA",@(x) isstring(x)||ischar(x)||iscellstr(x));
    p.parse(varargin{:});
    opt = p.Results;
    coldims = string(opt.ColumnDims);

    % --- Build the request URL ------------------------------------------
    base = "https://sdmx.oecd.org/public/rest/data";
    url  = base + "/" + string(dataflowRef) + "/" + string(key) + ...
           "?format=csvfilewithlabels";
    if strlength(opt.StartPeriod) > 0
        url = url + "&startPeriod=" + opt.StartPeriod;
    end
    if strlength(opt.EndPeriod) > 0
        url = url + "&endPeriod=" + opt.EndPeriod;
    end

    % --- Resolve the destination CSV ------------------------------------
    if strlength(string(opt.RawFile)) == 0
        csvfile = string(tempname) + ".csv";
    else
        csvfile = string(opt.RawFile);
        d = fileparts(csvfile);
        if strlength(d) > 0 && ~exist(d,'dir'); mkdir(d); end
    end

    % --- Download (or reuse cached raw) ---------------------------------
    % Treat a 0-byte cached file as missing (a previous failed download can
    % leave an empty stub that would otherwise be reused or mis-parsed).
    stale = exist(csvfile,'file') && dir(csvfile).bytes == 0;
    web = weboptions('Timeout', opt.Timeout, 'ContentType','text');
    if opt.Refresh || ~exist(csvfile,'file') || stale
        fprintf('  OECD SDMX GET %s\n', url);
        try
            websave(csvfile, url, web);
        catch ME
            if exist(csvfile,'file'); delete(csvfile); end   % don't cache a partial file
            rethrow(ME);
        end
    else
        fprintf('  OECD SDMX (cached) %s\n', csvfile);
    end

    % --- Parse the CSV (code + label columns) ---------------------------
    T = readtable(csvfile, 'VariableNamingRule','preserve', ...
                  'TextType','string');

    req = [coldims, "TIME_PERIOD", "OBS_VALUE"];
    miss = req(~ismember(req, string(T.Properties.VariableNames)));
    if ~isempty(miss)
        error('fetch_oecd_sdmx:badResponse', ...
              ['Expected column(s) %s not found in %s.\n' ...
               'First bytes of response may be an SDMX error — open the file ' ...
               'or the URL to inspect.'], strjoin(miss,', '), csvfile);
    end

    % Series id per row = ColumnDims values joined by '_' (e.g. "USA_CPV").
    ids = string(T.(char(coldims(1))));
    for d = 2:numel(coldims)
        ids = ids + "_" + string(T.(char(coldims(d))));
    end
    when = parse_oecd_period(T.TIME_PERIOD);
    val  = double(T.OBS_VALUE);

    % --- Pivot series -> columns, on a common period grid ---------------
    series = unique(ids, 'stable');
    times  = unique(when);
    times  = sort(times(~isnat(times)));
    X = nan(numel(times), numel(series));
    for s = 1:numel(series)
        m = ids == series(s);
        [tf, loc] = ismember(when(m), times);
        v = val(m);
        X(loc(tf), s) = v(tf);
    end

    tt = array2timetable(X, 'RowTimes', times, ...
                         'VariableNames', cellstr(series));
end

% -------------------------------------------------------------------------
function dt = parse_oecd_period(p)
% Convert OECD SDMX TIME_PERIOD strings to period-START datetimes.
%   'YYYY-Qn' -> quarter start ; 'YYYY-MM' -> month start ; 'YYYY' -> Jan 1.
    p  = string(p);
    dt = NaT(size(p));

    isQ = contains(p, "-Q");
    if any(isQ)
        ab = split(p(isQ), "-Q");
        ab = reshape(ab, [], 2);
        y  = str2double(ab(:,1));  q = str2double(ab(:,2));
        dt(isQ) = datetime(y, (q-1)*3 + 1, 1);
    end

    isM = ~isQ & (strlength(p) == 7) & contains(p, "-");
    if any(isM)
        ab = split(p(isM), "-");
        ab = reshape(ab, [], 2);
        y  = str2double(ab(:,1));  m = str2double(ab(:,2));
        dt(isM) = datetime(y, m, 1);
    end

    isA = ~isQ & ~isM & (strlength(p) == 4);
    if any(isA)
        dt(isA) = datetime(str2double(p(isA)), 1, 1);
    end
end
