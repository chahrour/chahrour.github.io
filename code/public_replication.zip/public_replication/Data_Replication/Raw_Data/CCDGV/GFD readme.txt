- The file gfd_monthly.csv contains the following series at monthly frequency from 1970 to 2026. (This file was downloaded by Dongchen through a GFD account.)

| Country        | Yield Ticker | Price Index Ticker | Total Return Ticker |
| -------------- | ------------ | ------------------ | ------------------- |
| Canada         | IGCAN10D     | PRCANGVM           | TRCANGVM            |
| France         | IGFRA10D     | PRFRAGVM           | TRFRAGVM            |
| Germany        | IGDEU10D     | PRDEUGVM           | TRDEUGVM            |
| Italy          | IGITA10D     | PRITAGVM           | TRITAGVM            |
| Japan          | IGJPN10D     | PRJPNGVM           | TRJPNGVM            |
| United Kingdom | IGGBR10D     | PRGBRGVM           | TRGBRGVM            |
| United States  | IGUSA10D     | PRUSG10M           | TRUSG10M            |

- The file G7 10-Year Bond Series Information (1).xlsx contains information on what these data series represent. (This file was shared with me by the GFD representative.)
