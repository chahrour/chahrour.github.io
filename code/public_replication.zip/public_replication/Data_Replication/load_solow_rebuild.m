function [tt, info] = load_solow_rebuild(varargin)
% LOAD_SOLOW_REBUILD  Foreign Solow residuals rebuilt from OECD Economic Outlook
%                     No. 119
%
%   [tt, info] = LOAD_SOLOW_REBUILD('Name',Value, ...)
%
%   Per country:
%
%   ln A_t = ln Y_t - alpha ln K_t - (1-alpha) ln L_t,        alpha = 0.3
%
%   Y_t  real GDP                          EO GDPV  (volume, SA)
%   I_t  real gross fixed capital formation EO ITV   (total, volume, SA)
%   L_t  total hours = hours per worker x employment   EO HRS x EO ET
%   K_t  perpetual inventory on I_t, quarterly depreciation d = 1-(1-0.10)^(1/4):
%          K_t0 = (1-d)^(1/2) I_t0 / (gbar + d)       first quarter with I_t
%          K_t  = (1-d) K_{t-1} + (1-d)^(1/2) I_t
%        gbar = mean quarterly growth rate of Y_t over the window.
%
%
% OPTIONS (name-value)
%   'Countries'   cellstr, default {'Germany','Japan','France','UK','Italy','Canada'}
%                 (the cfg.countries order of data_import_and_transform)
%   'Start'       datetime, default 1970Q1  } the window. gbar and the capital
%   'End'         datetime, default 2021Q4  } stock's starting quarter depend on
%                 it; the defaults are the spreadsheet's EViews workfile. EO
%                 carries PROJECTIONS after its last historical quarter (EO 119:
%                 history to early 2026) without flagging them -- never set End
%                 past the last actual quarter.
%   'Alpha'       capital share, default 0.3
%   'DeltaAnnual' annual depreciation rate, default 0.10
%   'Refresh'     re-download even if RawFile exists, default false
%   'RawFile'     cache of the API response,
%                 default Raw_Data/OECD/EO_solow_ALL.csv
%
% OUTPUT
%   tt    quarterly timetable of TFP LEVELS (not logged), one column per country
%         -- the layout load_solow returns, so geo_aggregate_growth takes either.
%   info  struct: .coverage (table: first/last quarter of each input and of
%         TFP, per country), .key (the SDMX key fetched), .opts.

    p = inputParser;
    p.addParameter('Countries',  {'Germany','Japan','France','UK','Italy','Canada'}, @iscellstr);
    p.addParameter('Start',      datetime(1970,1,1),  @isdatetime);
    p.addParameter('End',        datetime(2021,10,1), @isdatetime);
    p.addParameter('Alpha',      0.3,  @isnumeric);
    p.addParameter('DeltaAnnual',0.10, @isnumeric);
    p.addParameter('Refresh',    false, @(x) islogical(x) || isnumeric(x));
    p.addParameter('RawFile',    "",    @(x) isstring(x) || ischar(x));
    p.parse(varargin{:});
    o = p.Results;

    raw = string(o.RawFile);
    if strlength(raw) == 0
        raw = fullfile(fileparts(mfilename('fullpath')), 'Raw_Data', 'OECD', 'EO_solow_ALL.csv');
    end

    ISO  = struct('Canada','CAN', 'France','FRA', 'Germany','DEU', ...
                  'Italy','ITA', 'Japan','JPN', 'UK','GBR');
    isos = cellfun(@(c) ISO.(c), o.Countries, 'UniformOutput', false);
    meas = {'GDPV','ITV','ET','HRS'};

    % One request: all countries x all four measures (REF_AREA.MEASURE.FREQ).
    key   = sprintf('%s.%s.Q', strjoin(isos,'+'), strjoin(meas,'+'));
    combo = fetch_oecd_sdmx("OECD.ECO.MAD,DSD_EO@DF_EO,1.5", key, ...
                'StartPeriod', "1965-Q1", 'RawFile', raw, ...
                'Refresh', logical(o.Refresh), 'ColumnDims', ["REF_AREA","MEASURE"]);
    combo = combo(combo.Time >= o.Start & combo.Time <= o.End, :);

    d   = 1 - (1 - o.DeltaAnnual)^(1/4);
    T   = height(combo);
    n   = numel(o.Countries);
    lnA = nan(T, n);
    cov = cell(n, 6);

    for k = 1:n
        c = isos{k};
        % EO quarterly levels are annualised (x4). Dividing by 4 rescales the
        % level only; kept so Y and I are quarterly flows, as in the spreadsheet.
        Y = eo_col(combo, c, 'GDPV') / 4;
        I = eo_col(combo, c, 'ITV')  / 4;
        H = eo_col(combo, c, 'HRS');
        E = eo_col(combo, c, 'ET');
        L = H .* E;

        gbar = mean(Y(2:end) ./ Y(1:end-1) - 1, 'omitnan');
        K  = nan(T, 1);
        t0 = find(~isnan(I), 1);
        if ~isempty(t0)
            K(t0) = (1-d)^(1/2) / (gbar + d) * I(t0);
            for t = t0+1:T
                K(t) = (1-d) * K(t-1) + (1-d)^(1/2) * I(t);   % a gap in I ends K, as in EViews
            end
        end
        lnA(:,k) = log(Y) - o.Alpha*log(K) - (1-o.Alpha)*log(L);

        cov(k,:) = {o.Countries{k}, span(combo.Time, Y), span(combo.Time, I), ...
                    span(combo.Time, H), span(combo.Time, E), span(combo.Time, lnA(:,k))};
    end

    tt = array2timetable(exp(lnA), 'RowTimes', combo.Time, 'VariableNames', o.Countries);
    info.coverage = cell2table(cov, 'VariableNames', ...
        {'Country','GDPV','ITV','HRS','ET','TFP'});
    info.key  = key;
    info.opts = o;
end

function x = eo_col(combo, iso, m)
    cn = sprintf('%s_%s', iso, m);
    if ismember(cn, combo.Properties.VariableNames)
        x = combo.(cn);
    else
        warning('load_solow_rebuild:missing', ...
            '%s not in the EO response (no quarterly %s for %s?) -- filled NaN.', cn, m, iso);
        x = nan(height(combo), 1);
    end
end

function s = span(t, x)
    i = find(~isnan(x));
    if isempty(i)
        s = "none";
    else
        s = string(sprintf('%dQ%d-%dQ%d', year(t(i(1))), quarter(t(i(1))), ...
                                          year(t(i(end))), quarter(t(i(end)))));
    end
end
