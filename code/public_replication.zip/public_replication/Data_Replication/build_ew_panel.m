function out = build_ew_panel(varargin)
%BUILD_EW_PANEL  Build the end-of-period panel for Figure C.14.
%
%   out = BUILD_EW_PANEL()
%   out = BUILD_EW_PANEL('uk','MANM', ...)
%
%   Name-value options
%     'uk'        UK money measure: 'MANM' (narrow, default) or 'MABM' (broad).
%     'refresh'   Download again instead of using the cached responses. Default false.
%     'outdir'    Default Built_Data.
%
%   out   struct with the panel Y, its settings cfg, and notes.
%
%   Writes Y_ew.mat and Y_ew.csv: quarterly series from 1976Q1 for six countries
%   (CA FR GE IT JP UK) and the US, on Engel and West's end-of-period sampling
%   convention.
%
%     series    source                                     quarterly value
%     EX_*      Datastream_new/_exchangerates.xlsx, daily  end of period, log
%     EURO_*    Datastream_new/_interestrates.xlsx, daily  end of period, annualized percent
%     USEURO_*  EURO_US and EURO_*                         US minus foreign, quarterly log gross
%     CPI_*     OECD prices, quarterly index               as published, level
%     GDP_*     OECD EO GDPV, quarterly                    as published, log
%     M1_*      see below                                  last month of quarter, level
%
%   Money:
%     Canada, Japan, US       OECD KEI narrow money.
%     France, Germany, Italy  Engel and West's M1 through 1998Q4, then the
%                             cumulated growth of euro-area M1 (FRED). There is
%                             no national series after the euro changeover.
%     UK                      OECD narrow (or broad) money from its own start,
%                             extended backward with the growth of M4 (FRED
%                             MSM4UKQ).
%
%   See also BUILD_ALL_VINTAGES, GENPLOTS_EW.

    p = inputParser;
    p.addParameter('uk','MANM',      @(s) any(strcmp(s,{'MANM','MABM'})));
    p.addParameter('refresh',false,  @(x) islogical(x)||isnumeric(x));
    p.addParameter('outdir','',      @(s) ischar(s)||isstring(s));
    p.parse(varargin{:});
    o = p.Results;
    root = fileparts(mfilename('fullpath'));
    if isempty(char(o.outdir)); o.outdir = fullfile(root,'Built_Data'); end
    if ~isfolder(o.outdir); mkdir(o.outdir); end
    addpath(root);                                    % for fetch_oecd_sdmx

    CTRY  = {'CA','FR','GE','IT','JP','UK'};          % country order throughout
    ISO   = {'CAN','FRA','DEU','ITA','JPN','GBR'};
    EUROJ = datetime(1998,10,1);                      % 1998Q4, last national M1
    T0    = datetime(1976,1,1);                       % first quarter of the panel

    fprintf('build_ew_panel: UK extension %s\n', o.uk);

    % Load the sources.
    EW   = local_ew_base(root, CTRY);                 % M1 for FR, GE, IT
    EX   = local_fx(root, CTRY);
    RT   = local_rates(root, CTRY);
    CPI  = local_oecd_cpi(root, ISO, o.refresh);
    GDP  = local_oecd_gdp(root, ISO, o.refresh);
    GDP  = local_german_gdp_backcast(root, GDP, o.refresh);   % EO starts Germany in 1991Q1
    [MN, EA, UKB, uknote] = local_money(root, o.uk, o.refresh);

    % Quarterly grid from T0 to the earliest end of the FX, rate, CPI and GDP series.
    t_end = min([EX.Time(end), RT.Time(end), CPI.Time(end), GDP.Time(end)]);
    grid  = (T0:calquarters(1):t_end)';
    fprintf('  output grid: %s .. %s (%d quarters)\n', ...
        string(grid(1),'yyyy-QQQ'), string(grid(end),'yyyy-QQQ'), numel(grid));

    % Assemble the panel, country by country.
    q = @(r) log((1 + r/100).^(1/4));                 % annualized percent -> quarterly log gross
    Y = timetable(grid);
    Y.Properties.DimensionNames{1} = 'Time';
    for k = 1:6
        c = CTRY{k};
        % Single-source series.
        Y.(['EX_'   c]) = log(local_on_grid(EX(:,c),  grid));   % log
        Y.(['CPI_'  c]) = local_on_grid(CPI(:,c), grid);        % level
        Y.(['GDP_'  c]) = log(local_on_grid(GDP(:,c), grid));   % log
        ri = local_on_grid(RT(:,c),  grid);
        Y.(['EURO_'   c]) = ri;                                  % annualized percent
        Y.(['USEURO_' c]) = q(local_on_grid(RT(:,'US'), grid)) - q(ri);  % US minus foreign
        % Money.
        switch c
            case {'FR','GE','IT'}
                % Engel and West's level through 1998Q4, then euro-area growth.
                Y.(['M1_' c]) = local_splice(grid, EW.Time, EW.(['M1_' c]), EA, 'EA', EUROJ, 'log');
            case 'UK'
                % OECD money from its own start, extended backward with M4 growth.
                Y.M1_UK = local_backcast(grid, MN(:,'UK'), UKB(:,'UK_base'));
            otherwise
                Y.(['M1_' c]) = local_on_grid(MN(:,c), grid);    % one source throughout
        end
    end
    Y.CPI_US    = local_on_grid(CPI(:,'US'), grid);
    Y.GDP_US    = log(local_on_grid(GDP(:,'US'), grid));
    Y.M1_US     = local_on_grid(MN(:,'US'),  grid);
    Y.EURO_US   = local_on_grid(RT(:,'US'),  grid);

    % Report coverage and save.
    local_coverage(Y, CTRY);
    cfg = struct('uk_measure',o.uk, 'euro_join',EUROJ, ...
                 'uk_join',"data-determined: the OECD series' own start", ...
                 'built',datetime('now'), ...
                 'agg','end of period (FX, rates); last month of quarter (money)', ...
                 'orientation','EX is foreign currency per USD, as NER_data''s fx_ln', ...
                 'notes',{{uknote, ...
                   'EX and GDP are stored as LOGS (like fx_ln and gdp_ln); CPI and M1 as levels.', ...
                   'USEURO_* is already US-minus-foreign in quarterly log gross units, like idiff_ec.', ...
                   'EW data is used ONLY for M1_FR/GE/IT before 1999 -- no API has national M1 after the changeover.'}});
    Y_bench = Y;  %#ok<NASGU>
    stem = fullfile(o.outdir, 'Y_ew');
    save([stem '.mat'], 'Y', 'Y_bench', 'cfg');
    writetimetable(Y, [stem '.csv']);
    fprintf('build_ew_panel: wrote %d quarters x %d series to %s\n', ...
            height(Y), width(Y), o.outdir);
    out = struct('Y',Y, 'cfg',cfg, 'notes',{cfg.notes});
end

function T = local_ew_base(root, CTRY)
%   Engel and West's M1 for France, Germany and Italy, from EW_DATA_ALL sheet A
%   (1974Q1-2001Q3, dates in column A as 'YYYY:Q'). Columns are read by name.
    f = fullfile(root,'Raw_Data','EW','EW_DATA_ALL.xlsx');
    assert(isfile(f), 'build_ew_panel:noEW', '%s not found.', f);
    R = readtable(f, 'Sheet','A', 'VariableNamingRule','preserve');
    lab = string(R{:,1});
    keep = ~ismissing(lab) & contains(lab, ':');
    R = R(keep,:);  lab = lab(keep);
    parts = split(lab, ':');
    tt = datetime(str2double(parts(:,1)), 3*str2double(parts(:,2))-2, 1);
    want = {'M1_FR','M1_GE','M1_IT'};  %#ok<NASGU>
    want = want;
    have = R.Properties.VariableNames;
    miss = want(~ismember(want, have));
    assert(isempty(miss), 'build_ew_panel:ewColumns', ...
        'EW_DATA_ALL is missing %s. It has: %s', strjoin(miss,', '), strjoin(have,', '));
    T = timetable(tt);
    T.Properties.DimensionNames{1} = 'Time';   % timetable() names it after the input
    for w = want
        v = R.(w{1});
        if ~isnumeric(v); v = str2double(string(v)); end   % '#N/A' -> NaN
        T.(w{1}) = v;
    end
end

function Q = local_fx(root, CTRY)
%   Daily spot rates, end of period by quarter, from the 'Replication' sheet.
%   Columns are CAD, FRF, DEM, ITL, JPY, GBP, in USD per unit of foreign currency;
%   the euro is already chained onto FRF, DEM and ITL.
    f = fullfile(root,'Raw_Data','Datastream_new','_exchangerates.xlsx');
    assert(isfile(f), 'build_ew_panel:noFX', '%s not found.', f);
    R = readtable(f,'Sheet','Replication','VariableNamingRule','preserve');
    d = R{:,1};  if ~isdatetime(d); d = datetime(d,'ConvertFrom','excel'); end
    V = R{:,2:end};
    assert(size(V,2) == 6, 'build_ew_panel:fxCols', ...
        'expected 6 FX columns (CAD FRF DEM ITL JPY GBP), found %d', size(V,2));
    Q = local_eop(d, V, CTRY);
end

function Q = local_rates(root, CTRY)
%   Daily 3-month deposit rates in annualized percent, end of period by quarter.
%   Sheet columns are CAD, FRF, DEM, ITL, JPY, GBP, USD: the US is last.
    f = fullfile(root,'Raw_Data','Datastream_new','_interestrates.xlsx');
    assert(isfile(f), 'build_ew_panel:noRates', '%s not found.', f);
    R = readtable(f,'Sheet','Replication','VariableNamingRule','preserve');
    d = R{:,1};  if ~isdatetime(d); d = datetime(d,'ConvertFrom','excel'); end
    V = R{:,2:end};
    assert(size(V,2) == 7, 'build_ew_panel:rateCols', ...
        'expected 7 rate columns (6 countries + US), found %d', size(V,2));
    Q = local_eop(d, V(:,1:6), CTRY);
    U = local_eop(d, V(:,7),   {'US'});
    Q = synchronize(Q, U, 'union');
    Q.Properties.DimensionNames{1} = 'Time';
end

function Q = local_eop(d, V, names)
%   Daily to quarterly, taking the last available observation in the quarter.
    ok = ~isnat(d);
    TT = array2timetable(V(ok,:), 'RowTimes', d(ok), 'VariableNames', names);
    TT = sortrows(TT);
    Q  = retime(TT, 'quarterly', 'lastvalue');
    % Stop if a series has a quarter with no quote at all inside its span.
    for j = 1:width(Q)
        v = Q{:,j};  k = find(isfinite(v));
        if isempty(k); continue; end
        assert(~any(~isfinite(v(k(1):k(end)))), 'build_ew_panel:interiorGap', ...
            '%s has an interior quarter with no quote at all.', Q.Properties.VariableNames{j});
    end
end

function Q = local_oecd_cpi(root, ISO, refresh)
%   OECD quarterly CPI index, all items, not seasonally adjusted: the dataflow
%   and key shape DATA_IMPORT_AND_TRANSFORM uses for P_all.
    DF  = "OECD.SDD.TPS,DSD_PRICES@DF_PRICES_ALL,1.0";
    key = sprintf("%s.Q.N.CPI.IX._T.N._Z", strjoin([{'USA'}, ISO], '+'));
    raw = fullfile(root,'Raw_Data','OECD','CPI_ALL.csv');
    C   = fetch_oecd_sdmx(DF, key, 'StartPeriod',"1960-Q1", 'RawFile',raw, ...
                          'Refresh',refresh, 'ColumnDims',["REF_AREA"]);
    Q = local_rename_iso(C, ISO);
end

function Q = local_oecd_gdp(root, ISO, refresh)
%   OECD Economic Outlook GDPV, the chain-linked real volume. Germany starts
%   1991Q1; LOCAL_GERMAN_GDP_BACKCAST fills the earlier quarters.
    DF  = "OECD.ECO.MAD,DSD_EO@DF_EO,1.5";
    key = sprintf("%s.GDPV.Q", strjoin([{'USA'}, ISO], '+'));
    raw = fullfile(root,'Raw_Data','OECD','EO_gdp_EWPANEL.csv');
    C   = fetch_oecd_sdmx(DF, key, 'StartPeriod',"1960-Q1", 'RawFile',raw, ...
                          'Refresh',refresh, 'ColumnDims',["REF_AREA"]);
    Q = local_rename_iso(C, ISO);
end

function GDP = local_german_gdp_backcast(root, GDP, refresh)
%   Backcast German GDP before the first EO quarter with KEI quarterly GDP
%   growth (measure B1GQ_Q). The growth rates are compounded to a pseudo-level
%   and scaled to the EO level at the join, so the level is continuous there.
    if ~ismember('GE', GDP.Properties.VariableNames); return; end
    v = GDP.GE;  k = find(isfinite(v));
    if isempty(k) || k(1) == 1; return; end           % nothing to backcast
    join = GDP.Time(k(1));
    key  = "DEU.Q.B1GQ_Q.GR._T.Y.G1";
    raw  = fullfile(root,'Raw_Data','OECD','KEI_DEU_gdp.csv');
    G    = fetch_oecd_sdmx("OECD.SDD.STES,DSD_KEI@DF_KEI,4.0", key, ...
                'StartPeriod',"1960-Q1", 'RawFile',raw, 'Refresh',refresh);
    g    = G{:,1};  gt = G.Properties.RowTimes;
    ok   = isfinite(g);
    lvl  = cumprod(1 + g(ok)/100);                    % arbitrary base; the scale below removes it
    P    = timetable(gt(ok), lvl, 'VariableNames', {'x'});
    P.Properties.DimensionNames{1} = 'Time';
    pj   = local_on_grid(P, join);
    assert(isfinite(pj) && pj > 0, 'build_ew_panel:noGermanJoin', ...
        'KEI German GDP has no value at the join quarter %s.', string(join,'yyyy-QQQ'));
    scale = v(k(1)) / pj;
    pre   = GDP.Time < join;
    v(pre) = local_on_grid(P, GDP.Time(pre)) * scale;
    GDP.GE = v;
    fprintf('  German GDP backcast from KEI B1GQ_Q before %s (%d quarters filled)\n', ...
            string(join,'yyyy-QQQ'), sum(pre & isfinite(v)));
end

function [MN, EA, UKB, uknote] = local_money(root, ukmeas, refresh)
%   The money series, quarterly (last month of the quarter).
%     MN   OECD KEI narrow money for CA, JP and US, plus the UK on ukmeas.
%     EA   euro-area M1 (cached FRED EA19), which extends FR, GE and IT from 1999Q1.
%     UKB  UK M4, FRED MSM4UKQ, which ends 2016Q4; used for the UK backcast.
    DF  = "OECD.SDD.STES,DSD_KEI@DF_KEI,4.0";
    nat = {'CAN','JPN','USA'};  natn = {'CA','JP','US'};
    key = sprintf("%s.M.MANM.IX._Z.Y._Z", strjoin(nat,'+'));
    raw = fullfile(root,'Raw_Data','OECD','KEI_money_MANM.csv');
    C   = fetch_oecd_sdmx(DF, key, 'StartPeriod',"1960-01", 'RawFile',raw, ...
                          'Refresh',refresh, 'ColumnDims',["REF_AREA"]);
    M = local_pick_iso(C, nat, natn);
    keyU = sprintf("GBR.M.%s.IX._Z.Y._Z", ukmeas);
    rawU = fullfile(root,'Raw_Data','OECD',sprintf('KEI_money_UK_%s.csv', ukmeas));
    U = fetch_oecd_sdmx(DF, keyU, 'StartPeriod',"1960-01", 'RawFile',rawU, ...
                        'Refresh',refresh, 'ColumnDims',["REF_AREA"]);
    U = local_pick_iso(U, {'GBR'}, {'UK'});
    M = synchronize(M, U, 'union');
    M.Properties.DimensionNames{1} = 'Time';
    MN = retime(M, 'quarterly', 'lastvalue');

    fe = fullfile(root,'Raw_Data','EW','Euro_M1_FRED.csv');
    assert(isfile(fe), 'build_ew_panel:noEuroM1', '%s not found.', fe);
    E  = readtable(fe);
    ed = E.observation_date;  if ~isdatetime(ed); ed = datetime(ed); end
    tE = timetable(ed, E.MANMM101EZM189S, 'VariableNames', {'EA'});
    tE.Properties.DimensionNames{1} = 'Time';
    EA = retime(tE, 'quarterly', 'lastvalue');

    fu = fullfile(root,'Raw_Data','EW','UK_M4_FRED.csv');
    assert(isfile(fu), 'build_ew_panel:noUKM4', '%s not found.', fu);
    Ut = readtable(fu);
    ud = Ut.observation_date;  if ~isdatetime(ud); ud = datetime(ud); end
    v  = Ut.MSM4UKQ;  if ~isnumeric(v); v = str2double(string(v)); end
    k  = isfinite(v) & ~isnat(ud);
    tU = timetable(ud(k), v(k), 'VariableNames', {'UK_base'});
    tU.Properties.DimensionNames{1} = 'Time';
    UKB = retime(tU, 'quarterly', 'lastvalue');

    if strcmp(ukmeas,'MABM')
        uknote = ['UK money: FRED MSM4UKQ (M4) through 2016Q4, then OECD MABM ' ...
                  '(BROAD) growth -- concept-consistent with an M4 base. Broad is ' ...
                  'right for the UK and WRONG for Canada, whose EW M1 correlates ' ...
                  '-0.08 with broad and 0.54 with narrow.'];
    else
        uknote = ['UK money: FRED MSM4UKQ (M4) through 2016Q4, then OECD MANM ' ...
                  '(NARROW) growth -- family-consistent with the others but ' ...
                  'spliced onto a BROAD base.'];
    end
end

function y = local_splice(grid, t_ew, v_ew, N, name, join, mode)
%   v_ew up to and including the quarter join, then the level at join extended
%   with the changes of donor column name in N. Only the donor's changes enter.
%   mode is 'log' for strictly positive levels (log changes) or 'raw' for a
%   series that can be negative (first differences).
    y = NaN(numel(grid),1);
    % The Engel-West block.
    [tf, loc] = ismember(grid, t_ew);
    pre = tf & grid <= join;
    y(pre) = v_ew(loc(pre));
    anchor_i = find(grid == join, 1);
    assert(~isempty(anchor_i), 'build_ew_panel:noAnchor', ...
        'the join quarter %s is not on the output grid.', string(join,'yyyy-QQQ'));
    a = y(anchor_i);
    if ~isfinite(a)
        % No value at the join quarter: leave the extension NaN.
        warning('build_ew_panel:anchorNaN', ...
            '%s has no EW value at the join quarter; leaving the extension NaN.', name);
        return
    end
    % The extension.
    if ~ismember(name, N.Properties.VariableNames)
        warning('build_ew_panel:noDonor', ...
            'no newcore donor column "%s"; series stops at the join.', name);
        return
    end
    nv = local_on_grid(N(:,name), grid);
    if strcmp(mode,'log')
        assert(all(nv(isfinite(nv)) > 0), 'build_ew_panel:nonPositive', ...
            '%s has a non-positive value and cannot be spliced in logs.', name);
        d = [NaN; diff(log(nv))];
    else
        d = [NaN; diff(nv)];
    end
    post = find(grid > join);
    run  = a;
    for i = post(:)'
        if ~isfinite(d(i)); break; end                 % stop at the first hole
        if strcmp(mode,'log'); run = run * exp(d(i)); else; run = run + d(i); end
        y(i) = run;
    end
end

function y = local_backcast(grid, new_tt, old_tt)
%   The new series from its own first observation, extended backward by
%   cumulating the old series' log growth, anchored at the new series' first
%   value. Only the old series' growth enters.
    new = local_on_grid(new_tt, grid);
    old = local_on_grid(old_tt, grid);
    y   = new;
    i0  = find(isfinite(new), 1);
    assert(~isempty(i0), 'build_ew_panel:noNewSeries', ...
        'the new series has no finite observation on the grid.');
    d = [NaN; diff(log(old))];
    a = new(i0);
    for i = (i0-1):-1:1
        if ~isfinite(d(i+1)); break; end      % stop at the first hole
        a = a / exp(d(i+1));
        y(i) = a;
    end
end

function v = local_on_grid(tt, grid)
%   One timetable column on a quarterly grid, NaN where it has no value. Matched
%   on (year, quarter), because the sources stamp a quarter on different days.
    v  = NaN(numel(grid),1);
    gq = [year(grid), quarter(grid)];
    tq = [year(tt.Properties.RowTimes), quarter(tt.Properties.RowTimes)];
    x  = tt{:,1};
    [tf, loc] = ismember(gq, tq, 'rows');
    v(tf) = x(loc(tf));
end

function Q = local_rename_iso(C, ISO)
%   Rename the REF_AREA columns of an SDMX timetable to this file's country names.
    Q = local_pick_iso(C, [{'USA'}, ISO], [{'US'}, {'CA','FR','GE','IT','JP','UK'}]);
end

function Q = local_pick_iso(C, isos, names)
%   Pick columns by name. A column may be named "<ISO>" or "<ISO>_<MEASURE>",
%   depending on the ColumnDims passed to fetch_oecd_sdmx.
    have = C.Properties.VariableNames;
    Q = timetable(C.Properties.RowTimes);
    Q.Properties.DimensionNames{1} = 'Time';
    for k = 1:numel(isos)
        j = find(strcmp(have, isos{k}) | startsWith(have, [isos{k} '_']), 1);
        if isempty(j)
            warning('build_ew_panel:noArea', '%s absent from the response (have: %s).', ...
                    isos{k}, strjoin(have,', '));
            continue
        end
        Q.(names{k}) = C{:,j};
    end
end

function local_coverage(Y, CTRY)
%   Print the number of non-NaN quarters of each series, by country.
    fprintf('\n  coverage (non-NaN of %d quarters, %s .. %s):\n', height(Y), ...
        string(Y.Time(1),'yyyy-QQQ'), string(Y.Time(end),'yyyy-QQQ'));
    fprintf('    %-5s %7s %7s %7s %7s %7s\n','ctry','EX','EURO','CPI','GDP','M1');
    for k = 1:numel(CTRY)
        c = CTRY{k};
        fprintf('    %-5s %7d %7d %7d %7d %7d\n', c, ...
            sum(isfinite(Y.(['EX_' c]))),  sum(isfinite(Y.(['EURO_' c]))), ...
            sum(isfinite(Y.(['CPI_' c]))), sum(isfinite(Y.(['GDP_' c]))), ...
            sum(isfinite(Y.(['M1_' c]))));
    end
    fprintf('    %-5s %7s %7d %7d %7d %7d\n','US','--', ...
        sum(isfinite(Y.EURO_US)), sum(isfinite(Y.CPI_US)), ...
        sum(isfinite(Y.GDP_US)),  sum(isfinite(Y.M1_US)));
end
