function out = build_ew_panel(varargin)
%BUILD_EW_PANEL  The Engel-West-CONVENTION panel for Figure B.13.
%
%   out = BUILD_EW_PANEL()
%   out = BUILD_EW_PANEL('vintage','2026', 'suffix','_f2026', ...)
%
%   Name-value options
%     'vintage'   Fernald vintage for US TFP; '2026' is the one that ships. Default '2026'.
%     'suffix'    Filename tag, and the output is written under it ALONE.
%                 Omitted, it defaults to ['_f' vintage]; pass '' for the
%                 untagged panel.
%     'uk'        UK money measure: 'MANM' (narrow, default) or 'MABM' (broad).
%     'refresh'   Re-download instead of using the API caches. Default false.
%     'outdir'    Default Built_Data/.
%
%   Writes Built_Data/Y_ew<suffix>.{mat,csv} -- one pair, not two.
%
%   WHAT THIS IS. Figure B.13 runs the Engel-West Granger test on OUR data, on
%   their END-OF-PERIOD sampling convention. It is not a replication of their
%   numbers -- that is Figure 7, which reads EW_DATA_ALL directly and needs no
%   builder. This panel therefore carries OUR series throughout, extended as far
%   as the sources reach, so a figure can declare any window up to ~2026Q1.
%
%   CORRECTING AN EARLIER VERSION OF THIS FILE. It first took EW's levels as the
%   base for all six series and extended them with newcore growth. That was
%   wrong, and measurably so. The published B.13 uses EW_DATA_ALL for EXACTLY
%   THREE COLUMNS -- M1_FR, M1_GE, M1_IT, at M1_DATA:21,25,29 -- and for nothing
%   else: NER_DATA, IDIFF_DATA, CPI_DATA, GDP_DATA and US_DATA contain no
%   reference to that file. Making EW the base imported two defects that do not
%   otherwise exist:
%     * EW quotes the exchange rate as the RECIPROCAL of Datastream (EX_CA starts
%       0.9842 against exp(fx_ln_CA) = 1.0167), so splicing EW levels to
%       Datastream growth put a sign flip at the join;
%     * EW's Canadian M1 correlates only 0.54 with narrow money on log changes --
%       and -0.08 with broad -- so no available series continues it. Using EW as
%       Canada's base glues two different objects together at 2001Q3.
%   Both vanish when B.13 simply stays on our own sources.
%
%   SOURCES, AND WHERE A SPLICE IS STILL NEEDED. Four of six series are
%   SINGLE-SOURCE across the whole sample, so there is no join to get wrong:
%
%     series   source                                      aggregation   splice
%     EX       Datastream_new/_exchangerates.xlsx (daily)   END OF PERIOD  none
%     USEURO   Datastream_new/_interestrates.xlsx (daily)   END OF PERIOD  none
%     CPI      OECD SDMX prices, quarterly index            as published   none
%     GDP      OECD EO GDPV, quarterly, stored as a LOG     as published   none
%     M1       see below                                    last month     YES
%     US_TFP   Fernald sheet, vintage-selected              as published   none
%
%   MONEY IS THE ONLY SPLICED SERIES, and only because two country groups have no
%   continuous source:
%     * FRANCE, GERMANY, ITALY -- national M1 ends at the euro changeover and
%       exists on NEITHER FRED nor OECD afterwards (post-1999 national M1 is
%       reported in euro; see M1_DATA:49-57, "not expressed in country
%       currency"). EW's level to 1998Q4, then cumulated euro-area growth. This
%       is the one forced use of EW data, and it is what the published figure
%       already does.
%     * UNITED KINGDOM -- OECD NARROW MONEY from its own start, 1986Q4, extended
%       BACKWARD with the growth of FRED MSM4UKQ (which is M4, and which died in
%       2016Q4 -- leaving the published B.13 silently missing UK money for its
%       last eight quarters). This puts the UK on the same measure, from the same
%       provider, joined by the same convention as Canada, Japan and the US.
%       CHANGED 2026-10-11, from a forward splice that kept M4 to 2016Q4 and
%       extended with broad money. Four constructions were built and compared at
%       a 2020Q1 end date; the UK's count of significant tests ranged over 21 of
%       a possible 102:
%           M4 -> broad at 2016Q4 (the old default)   UK 35, total 233
%           broad from 1987Q1, M4 backcast            UK 28, total 226
%           narrow from 1986Q4, M4 backcast  <- now   UK 49, total 247
%           narrow only, 1986Q4-2020Q1, no splice     UK 44, total 242
%       So the UK money choice is a bigger lever than the whole of the rest of
%       the re-sourcing. It was NOT chosen for landing nearest the published 45
%       and 249 -- the published figure rests on a series that dies mid-sample
%       with eight quarters silently dropped, so closeness to it is not evidence.
%       It was chosen because it is the only one of the four that matches the
%       measure, provider and join convention of the countries the UK is
%       compared against. 'MABM' still selects broad if wanted.
%     * CANADA, JAPAN, THE US -- OECD KEI narrow money, one source throughout.
%
%   WHY OECD RATHER THAN FRED FOR MONEY. FRED's MANMM101* series are a mirror of
%   OECD Main Economic Indicators: FRED's own notes give the SDMX filters
%   (MEASURE=MANM, UNIT_MEASURE=IX, ADJUSTMENT=Y) and name the release. The same
%   KEI dataflow this repo already uses for the German backcast serves them, about
%   2.5 years more current, which also removes Japan_M1_OECD.xlsx from the flow.
%   Canada is the proof they are the same object: correlation of log changes is
%   exactly 1.000000 before 2002, 0.967 for 2002-2018, 0.847 from 2019 --
%   revisions to a later vintage. The euro-area series stays on the CACHED FRED
%   EA19 file because EA19 is no longer served by OECD and EA20 is a different
%   aggregate (log changes correlate 0.72 over 1999+).
%
%   ORIENTATION. EX is left in Datastream's orientation, foreign currency per
%   USD, matching NER_DATA's fx_ln -- so this panel is directly comparable with
%   the published figure. Figure 7 keeps EW's reciprocal orientation in its own
%   file. A Granger Wald test is invariant to the sign of y, so what matters is
%   that each panel is internally consistent, which both now are.
%
%   See also BUILD_ALL_VINTAGES, GENPLOTS_EW.

    p = inputParser;
    p.addParameter('vintage','2026', @(s) strcmp(s,'2026'));
    p.addParameter('suffix','',      @(s) ischar(s)||isstring(s));
    p.addParameter('uk','MANM',      @(s) any(strcmp(s,{'MANM','MABM'})));
    p.addParameter('refresh',false,  @(x) islogical(x)||isnumeric(x));
    p.addParameter('outdir','',      @(s) ischar(s)||isstring(s));
    p.parse(varargin{:});
    o = p.Results;
    root = fileparts(mfilename('fullpath'));
    % AN OMITTED SUFFIX IS NOT AN EMPTY ONE. Called bare, this tags the output
    % with the vintage, so build_ew_panel('vintage','2026') cannot quietly
    % overwrite the untagged panel with 2026 data. A caller that WANTS the
    % untagged file -- build_all_vintages' last row -- passes 'suffix','' and
    % gets it, because the suffix now redirects rather than adding a copy.
    if ismember('suffix', p.UsingDefaults); o.suffix = ['_f' o.vintage]; end
    if isempty(char(o.outdir)); o.outdir = fullfile(root,'Built_Data'); end
    if ~isfolder(o.outdir); mkdir(o.outdir); end
    addpath(root);                                    % fetch_oecd_sdmx lives here

    CTRY  = {'CA','FR','GE','IT','JP','UK'};          % GC_RUN:10 order throughout
    ISO   = {'CAN','FRA','DEU','ITA','JPN','GBR'};
    EUROJ = datetime(1998,10,1);                      % 1998Q4, last national M1
    T0    = datetime(1976,1,1);                       % B.13's start

    fprintf('build_ew_panel: Fernald %s, UK extension %s\n', o.vintage, o.uk);

    EW   = local_ew_base(root, CTRY);                 % only M1_FR/GE/IT are used
    EX   = local_fx(root, CTRY);
    RT   = local_rates(root, CTRY);
    CPI  = local_oecd_cpi(root, ISO, o.refresh);
    GDP  = local_oecd_gdp(root, ISO, o.refresh);
    GDP  = local_german_gdp_backcast(root, GDP, o.refresh);   % DEU starts 1991Q1 in EO
    [MN, EA, UKB, uknote] = local_money(root, o.uk, o.refresh);
    TFP  = local_tfp(root, o.vintage);

    t_end = min([EX.Time(end), RT.Time(end), CPI.Time(end), GDP.Time(end)]);
    grid  = (T0:calquarters(1):t_end)';
    fprintf('  output grid: %s .. %s (%d quarters)\n', ...
        string(grid(1),'yyyy-QQQ'), string(grid(end),'yyyy-QQQ'), numel(grid));

    q = @(r) log((1 + r/100).^(1/4));                 % IDIFF_DATA:43, annual -> quarterly log gross
    Y = timetable(grid);
    Y.Properties.DimensionNames{1} = 'Time';
    for k = 1:6
        c = CTRY{k};
        % --- single-source series: no splice, no join to get wrong ----------
        Y.(['EX_'   c]) = log(local_on_grid(EX(:,c),  grid));   % stored as a LOG, like fx_ln
        Y.(['CPI_'  c]) = local_on_grid(CPI(:,c), grid);        % level, as CPI_DATA
        Y.(['GDP_'  c]) = log(local_on_grid(GDP(:,c), grid));   % LOG, as gdp_ln
        ri = local_on_grid(RT(:,c),  grid);
        Y.(['EURO_'   c]) = ri;                                  % raw annualized %
        Y.(['USEURO_' c]) = q(local_on_grid(RT(:,'US'), grid)) - q(ri);  % as idiff_ec
        % --- money: the only spliced series --------------------------------
        switch c
            case {'FR','GE','IT'}
                % Forced: no national M1 after the changeover on either API.
                Y.(['M1_' c]) = local_splice(grid, EW.Time, EW.(['M1_' c]), EA, 'EA', EUROJ, 'log');
            case 'UK'
                % OECD narrow money from its own start (1986Q4), extended
                % BACKWARD with M4's growth -- the same direction splice_german
                % and geo_aggregate_spliced use, i.e. the new series is the base
                % from the moment it exists and the old one only fills earlier
                % quarters. See the header for why this replaced a forward splice.
                Y.M1_UK = local_backcast(grid, MN(:,'UK'), UKB(:,'UK_base'));
            otherwise
                Y.(['M1_' c]) = local_on_grid(MN(:,c), grid);    % one source throughout
        end
    end
    Y.CPI_US    = local_on_grid(CPI(:,'US'), grid);
    Y.GDP_US    = log(local_on_grid(GDP(:,'US'), grid));
    Y.M1_US     = local_on_grid(MN(:,'US'),  grid);
    Y.EURO_US   = local_on_grid(RT(:,'US'),  grid);
    Y.US_TFP    = local_on_grid(TFP, grid);

    local_coverage(Y, CTRY);
    cfg = struct('vintage',o.vintage, 'uk_measure',o.uk, 'euro_join',EUROJ, ...
                 'uk_join',"data-determined: the OECD series' own start", ...
                 'built',datetime('now'), ...
                 'agg','end of period (FX, rates); last month of quarter (money)', ...
                 'orientation','EX is foreign currency per USD, as NER_data''s fx_ln', ...
                 'notes',{{uknote, ...
                   'EX and GDP are stored as LOGS (like fx_ln and gdp_ln); CPI and M1 as levels.', ...
                   'USEURO_* is already US-minus-foreign in quarterly log gross units, like idiff_ec.', ...
                   'EW data is used ONLY for M1_FR/GE/IT before 1999 -- no API has national M1 after the changeover.'}});
    Y_bench = Y;  %#ok<NASGU>
    % The suffix REDIRECTS, as in DATA_IMPORT_AND_TRANSFORM: writing the untagged
    % file as well meant a tagged build overwrote the untagged panel every time.
    stem = fullfile(o.outdir, ['Y_ew' char(o.suffix)]);
    save([stem '.mat'], 'Y', 'Y_bench', 'cfg');
    writetimetable(Y, [stem '.csv']);
    fprintf('build_ew_panel: wrote %d quarters x %d series to %s\n', ...
            height(Y), width(Y), o.outdir);
    out = struct('Y',Y, 'cfg',cfg, 'notes',{cfg.notes});
end

% =========================================================================
function T = local_ew_base(root, CTRY)
%   EW_DATA_ALL sheet A: 111 quarters, 1974Q1-2001Q3, column A as 'YYYY:QQ'.
%   Read BY NAME throughout -- the sheet has a stray #N/A in row 1 next to
%   CPI_US and positional indexing would silently offset.
    f = fullfile(root,'Raw_Data','EW','EW_DATA_ALL.xlsx');
    assert(isfile(f), 'build_ew_panel:noEW', '%s not found.', f);
    R = readtable(f, 'Sheet','A', 'VariableNamingRule','preserve');
    lab = string(R{:,1});
    keep = ~ismissing(lab) & contains(lab, ':');
    R = R(keep,:);  lab = lab(keep);
    parts = split(lab, ':');
    tt = datetime(str2double(parts(:,1)), 3*str2double(parts(:,2))-2, 1);
    % ONLY the three columns the published figure actually takes from EW:
    % M1_DATA:21,25,29. Everything else in B.13 is our own data, so nothing else
    % is read here -- importing more was the mistake the header records.
    want = {'M1_FR','M1_GE','M1_IT'};  %#ok<NASGU>
    want = want;
    have = R.Properties.VariableNames;
    miss = want(~ismember(want, have));
    assert(isempty(miss), 'build_ew_panel:ewColumns', ...
        'EW_DATA_ALL is missing %s. It has: %s', strjoin(miss,', '), strjoin(have,', '));
    T = timetable(tt);
    T.Properties.DimensionNames{1} = 'Time';   % timetable() names it after the input
    for w = want
        v = R.(w{1});
        if ~isnumeric(v); v = str2double(string(v)); end   % '#N/A' -> NaN
        T.(w{1}) = v;
    end
end

% =========================================================================
function Q = local_fx(root, CTRY)
%   Daily spot -> END OF PERIOD quarterly. The 'Replication' sheet is the final
%   one: EUR is already chained onto FRF/DEM/ITL, so all six columns are complete
%   (verified 1976-01-02..2026-07-01, 21 observations in Jan-2010).
%   Columns are CAD, FRF, DEM, ITL, JPY, GBP -- already GC_RUN's country order.
    f = fullfile(root,'Raw_Data','Datastream_new','_exchangerates.xlsx');
    assert(isfile(f), 'build_ew_panel:noFX', '%s not found.', f);
    R = readtable(f,'Sheet','Replication','VariableNamingRule','preserve');
    d = R{:,1};  if ~isdatetime(d); d = datetime(d,'ConvertFrom','excel'); end
    V = R{:,2:end};
    assert(size(V,2) == 6, 'build_ew_panel:fxCols', ...
        'expected 6 FX columns (CAD FRF DEM ITL JPY GBP), found %d', size(V,2));
    % ORIENTATION: left as Datastream quotes it, FOREIGN CURRENCY PER USD, which
    % is what NER_DATA's fx_ln is. EW quotes the reciprocal; that difference now
    % lives entirely in Figure 7's own file and never meets this panel.
    Q = local_eop(d, V, CTRY);
end

% =========================================================================
function Q = local_rates(root, CTRY)
%   Daily 3-month deposit middle rates -> END OF PERIOD quarterly, annualized
%   percent, which is the unit EW's EURO_* carry. Sheet column order is
%   CAD, FRF, DEM, ITL, JPY, GBP, USD -- note the US is LAST, not first.
    f = fullfile(root,'Raw_Data','Datastream_new','_interestrates.xlsx');
    assert(isfile(f), 'build_ew_panel:noRates', '%s not found.', f);
    R = readtable(f,'Sheet','Replication','VariableNamingRule','preserve');
    d = R{:,1};  if ~isdatetime(d); d = datetime(d,'ConvertFrom','excel'); end
    V = R{:,2:end};
    assert(size(V,2) == 7, 'build_ew_panel:rateCols', ...
        'expected 7 rate columns (6 countries + US), found %d', size(V,2));
    Q = local_eop(d, V(:,1:6), CTRY);
    U = local_eop(d, V(:,7),   {'US'});
    Q = synchronize(Q, U, 'union');
    Q.Properties.DimensionNames{1} = 'Time';
end

% =========================================================================
function Q = local_eop(d, V, names)
%   Daily -> quarterly, LAST AVAILABLE observation in the quarter.
%
%   The original EOP series picks lbusdate(yy,[3,6,9,12]) -- the last BUSINESS
%   DAY of the quarter-end month -- while 'lastvalue' takes the last available
%   quote. They coincide whenever that day has a quote, which is the normal case;
%   where it does not, 'lastvalue' degrades to the previous trading day instead of
%   returning NaN, which is the behaviour we want. The difference is checked
%   against the original in the step-2 gate rather than assumed here.
    ok = ~isnat(d);
    TT = array2timetable(V(ok,:), 'RowTimes', d(ok), 'VariableNames', names);
    TT = sortrows(TT);
    Q  = retime(TT, 'quarterly', 'lastvalue');
    % A quarter with no quote at all for a currency is a real hole, not a
    % holiday. Refuse rather than let a renormalizing aggregate paper over it.
    for j = 1:width(Q)
        v = Q{:,j};  k = find(isfinite(v));
        if isempty(k); continue; end
        assert(~any(~isfinite(v(k(1):k(end)))), 'build_ew_panel:interiorGap', ...
            '%s has an interior quarter with no quote at all.', Q.Properties.VariableNames{j});
    end
end

% =========================================================================
function Q = local_oecd_cpi(root, ISO, refresh)
%   OECD quarterly CPI index, all items, NSA -- the same dataflow and key shape
%   DATA_IMPORT_AND_TRANSFORM uses for P_all, fetched here so this builder does
%   not require Y_benchmark to have been rebuilt first.
    DF  = "OECD.SDD.TPS,DSD_PRICES@DF_PRICES_ALL,1.0";
    key = sprintf("%s.Q.N.CPI.IX._T.N._Z", strjoin([{'USA'}, ISO], '+'));
    raw = fullfile(root,'Raw_Data','OECD','CPI_ALL.csv');
    C   = fetch_oecd_sdmx(DF, key, 'StartPeriod',"1960-Q1", 'RawFile',raw, ...
                          'Refresh',refresh, 'ColumnDims',["REF_AREA"]);
    Q = local_rename_iso(C, ISO);
end

% =========================================================================
function Q = local_oecd_gdp(root, ISO, refresh)
%   OECD Economic Outlook GDPV -- the chain-linked real volume, so log(GDPV) is
%   the counterpart of EW's log(GDP_*). Added to the main build 2026-10-09;
%   fetched directly here for the same reason as CPI.
%   Correlation with the original OECD_GDP.xlsx series, log level / log change:
%     CAN 1.0000/0.9960  FRA 0.9999/0.9098  DEU 0.9998/0.9870  ITA 1.0000/0.9818
%     JPN 0.9999/0.9846  GBR 0.9998/0.9681  USA 1.0000/0.9973
%   France is the weak one on growth and is the country to watch in the gate.
%   DEU starts 1991Q1 (pre-unification gap) -- the splice covers it, since EW's
%   German GDP runs from 1974.
    DF  = "OECD.ECO.MAD,DSD_EO@DF_EO,1.5";
    key = sprintf("%s.GDPV.Q", strjoin([{'USA'}, ISO], '+'));
    raw = fullfile(root,'Raw_Data','OECD','EO_gdp_EWPANEL.csv');
    C   = fetch_oecd_sdmx(DF, key, 'StartPeriod',"1960-Q1", 'RawFile',raw, ...
                          'Refresh',refresh, 'ColumnDims',["REF_AREA"]);
    Q = local_rename_iso(C, ISO);
end

% =========================================================================
function GDP = local_german_gdp_backcast(root, GDP, refresh)
%   EO's German GDP starts 1991Q1 -- the pre-unification gap that C and I have
%   too -- which would cost B.13 sixty quarters for Germany, 1976Q1-1990Q4, that
%   the published figure HAS (OECD_GDP.xlsx carries them). Closed from the API
%   rather than from that spreadsheet: KEI measure B1GQ_Q is German QoQ GDP
%   growth, 1970Q2-2026Q2, the same key shape cfg.kei_german already uses for
%   consumption (P3_S1M_Q) and investment (P51G_Q). Verified to cover all 60
%   missing quarters.
%
%   Linked the way SPLICE_GERMAN links: a pseudo-level is compounded from the
%   growth rates and scaled by a single ratio at the join, so only the donor's
%   GROWTH enters and the level is continuous at the seam.
    if ~ismember('GE', GDP.Properties.VariableNames); return; end
    v = GDP.GE;  k = find(isfinite(v));
    if isempty(k) || k(1) == 1; return; end           % nothing to backcast
    join = GDP.Time(k(1));
    key  = "DEU.Q.B1GQ_Q.GR._T.Y.G1";
    raw  = fullfile(root,'Raw_Data','OECD','KEI_DEU_gdp.csv');
    G    = fetch_oecd_sdmx("OECD.SDD.STES,DSD_KEI@DF_KEI,4.0", key, ...
                'StartPeriod',"1960-Q1", 'RawFile',raw, 'Refresh',refresh);
    g    = G{:,1};  gt = G.Properties.RowTimes;
    ok   = isfinite(g);
    lvl  = cumprod(1 + g(ok)/100);                    % arbitrary base, killed by the ratio
    P    = timetable(gt(ok), lvl, 'VariableNames', {'x'});
    P.Properties.DimensionNames{1} = 'Time';
    pj   = local_on_grid(P, join);
    assert(isfinite(pj) && pj > 0, 'build_ew_panel:noGermanJoin', ...
        'KEI German GDP has no value at the join quarter %s.', string(join,'yyyy-QQQ'));
    scale = v(k(1)) / pj;
    pre   = GDP.Time < join;
    v(pre) = local_on_grid(P, GDP.Time(pre)) * scale;
    GDP.GE = v;
    fprintf('  German GDP backcast from KEI B1GQ_Q before %s (%d quarters filled)\n', ...
            string(join,'yyyy-QQQ'), sum(pre & isfinite(v)));
end

% =========================================================================
function [MN, EA, UKB, uknote] = local_money(root, ukmeas, refresh)
%   Three objects, because money has three different provenances.
%     MN   OECD KEI money, quarterly (last month): CA, JP, US narrow, plus the
%          UK on `ukmeas` as the EXTENSION series.
%     EA   the euro-area series that extends FRA/GER/ITA from 1999Q1. Cached
%          FRED EA19: OECD no longer serves EA19 and EA20 is a different
%          aggregate (log changes correlate 0.72 over 1999+).
%     UKB  the UK BASE, FRED MSM4UKQ. It is M4, not M1, and it stops 2016Q4 --
%          which is why the published B.13 is missing UK money for its last
%          eight quarters, silently, since GC_RUN drops NaN rows per test.
    DF  = "OECD.SDD.STES,DSD_KEI@DF_KEI,4.0";
    nat = {'CAN','JPN','USA'};  natn = {'CA','JP','US'};
    key = sprintf("%s.M.MANM.IX._Z.Y._Z", strjoin(nat,'+'));
    raw = fullfile(root,'Raw_Data','OECD','KEI_money_MANM.csv');
    C   = fetch_oecd_sdmx(DF, key, 'StartPeriod',"1960-01", 'RawFile',raw, ...
                          'Refresh',refresh, 'ColumnDims',["REF_AREA"]);
    M = local_pick_iso(C, nat, natn);
    keyU = sprintf("GBR.M.%s.IX._Z.Y._Z", ukmeas);
    rawU = fullfile(root,'Raw_Data','OECD',sprintf('KEI_money_UK_%s.csv', ukmeas));
    U = fetch_oecd_sdmx(DF, keyU, 'StartPeriod',"1960-01", 'RawFile',rawU, ...
                        'Refresh',refresh, 'ColumnDims',["REF_AREA"]);
    U = local_pick_iso(U, {'GBR'}, {'UK'});
    M = synchronize(M, U, 'union');
    M.Properties.DimensionNames{1} = 'Time';
    MN = retime(M, 'quarterly', 'lastvalue');

    fe = fullfile(root,'Raw_Data','EW','Euro_M1_FRED.csv');
    assert(isfile(fe), 'build_ew_panel:noEuroM1', '%s not found.', fe);
    E  = readtable(fe);
    ed = E.observation_date;  if ~isdatetime(ed); ed = datetime(ed); end
    tE = timetable(ed, E.MANMM101EZM189S, 'VariableNames', {'EA'});
    tE.Properties.DimensionNames{1} = 'Time';
    EA = retime(tE, 'quarterly', 'lastvalue');

    fu = fullfile(root,'Raw_Data','EW','UK_M4_FRED.csv');
    assert(isfile(fu), 'build_ew_panel:noUKM4', '%s not found.', fu);
    Ut = readtable(fu);
    ud = Ut.observation_date;  if ~isdatetime(ud); ud = datetime(ud); end
    v  = Ut.MSM4UKQ;  if ~isnumeric(v); v = str2double(string(v)); end
    k  = isfinite(v) & ~isnat(ud);
    tU = timetable(ud(k), v(k), 'VariableNames', {'UK_base'});
    tU.Properties.DimensionNames{1} = 'Time';
    UKB = retime(tU, 'quarterly', 'lastvalue');

    if strcmp(ukmeas,'MABM')
        uknote = ['UK money: FRED MSM4UKQ (M4) through 2016Q4, then OECD MABM ' ...
                  '(BROAD) growth -- concept-consistent with an M4 base. Broad is ' ...
                  'right for the UK and WRONG for Canada, whose EW M1 correlates ' ...
                  '-0.08 with broad and 0.54 with narrow.'];
    else
        uknote = ['UK money: FRED MSM4UKQ (M4) through 2016Q4, then OECD MANM ' ...
                  '(NARROW) growth -- family-consistent with the others but ' ...
                  'spliced onto a BROAD base.'];
    end
end

% =========================================================================
function T = local_tfp(root, vintage)
%   The Fernald sheet, cumulated to a log level exactly as GC_RUN:59 does. No
%   splice: there is one source for the whole sample.
    switch vintage
        case '2026'; f = fullfile(root,'Raw_Data','Fernald','data_quarterly_2026.06.04.xlsx');
    end
    assert(isfile(f), 'build_ew_panel:noFernald', '%s not found.', f);
    R  = readtable(f, 'Sheet','quarterly', 'Range','A2', 'VariableNamingRule','preserve');
    lab = string(R{:,1});
    ok  = ~ismissing(lab) & ~cellfun(@isempty, regexp(cellstr(lab), '^\d{4}:Q?\d$', 'once'));
    R   = R(ok,:);  lab = lab(ok);
    pr  = regexp(cellstr(lab), '^(\d{4}):Q?(\d)$', 'tokens', 'once');
    yr  = cellfun(@(c) str2double(c{1}), pr);
    qt  = cellfun(@(c) str2double(c{2}), pr);
    d   = R.dtfp_util;
    if ~isnumeric(d); d = str2double(string(d)); end
    lvl = cumsum(d(2:end)/400);                       % GC_RUN:59, drops quarter 1
    T   = timetable(datetime(yr(2:end), 3*qt(2:end)-2, 1), lvl, 'VariableNames', {'US_TFP'});
    T.Properties.DimensionNames{1} = 'Time';
end

% =========================================================================
function y = local_splice(grid, t_ew, v_ew, N, name, join, mode)
%   EW's level up to and including `join`, then EW(join) + cumulated newcore
%   changes. The donor's own level never enters -- only its changes -- so EW's
%   published numbers survive untouched. Mirrors M1_DATA:21-30.
%
%   `mode` is 'log' for strictly positive levels or 'raw' for a rate that can go
%   negative. Taking a log of a negative rate returns a complex number in MATLAB
%   WITHOUT WARNING, which is why this is an explicit argument and not inferred.
    y = NaN(numel(grid),1);
    % (a) the EW block
    [tf, loc] = ismember(grid, t_ew);
    pre = tf & grid <= join;
    y(pre) = v_ew(loc(pre));
    anchor_i = find(grid == join, 1);
    assert(~isempty(anchor_i), 'build_ew_panel:noAnchor', ...
        'the join quarter %s is not on the output grid.', string(join,'yyyy-QQQ'));
    a = y(anchor_i);
    if ~isfinite(a)
        % EW has no value at the join for this series (e.g. FRA/GER/ITA M1 after
        % the changeover is handled by an earlier join, so this should not fire).
        warning('build_ew_panel:anchorNaN', ...
            '%s has no EW value at the join quarter; leaving the extension NaN.', name);
        return
    end
    % (b) the extension
    if ~ismember(name, N.Properties.VariableNames)
        warning('build_ew_panel:noDonor', ...
            'no newcore donor column "%s"; series stops at the join.', name);
        return
    end
    nv = local_on_grid(N(:,name), grid);
    if strcmp(mode,'log')
        assert(all(nv(isfinite(nv)) > 0), 'build_ew_panel:nonPositive', ...
            '%s has a non-positive value and cannot be spliced in logs.', name);
        d = [NaN; diff(log(nv))];
    else
        d = [NaN; diff(nv)];
    end
    post = find(grid > join);
    run  = a;
    for i = post(:)'
        if ~isfinite(d(i)); break; end                 % stop at the first hole
        if strcmp(mode,'log'); run = run * exp(d(i)); else; run = run + d(i); end
        y(i) = run;
    end
end

% =========================================================================
function y = local_backcast(grid, new_tt, old_tt)
%   The NEW series' levels from its own first observation, extended BACKWARD by
%   cumulating the OLD series' growth, anchored at the new series' first value.
%
%   This is the direction the rest of the repo splices in: splice_german takes
%   EO's level from 1991Q1 and uses the original German series only before that,
%   and geo_aggregate_spliced links at the first all-present quarter. A forward
%   splice -- keeping the old series as long as it lasts and switching when it
%   dies -- is the opposite convention and is what this replaced.
%
%   Only the old series' GROWTH enters, never its level, so the whole path is in
%   the new series' units. For the Granger tests that is the only thing that
%   matters: they use d log M1, so the regression sees the old series' growth
%   before the join and the new series' growth after it, and nothing else.
    new = local_on_grid(new_tt, grid);
    old = local_on_grid(old_tt, grid);
    y   = new;
    i0  = find(isfinite(new), 1);
    assert(~isempty(i0), 'build_ew_panel:noNewSeries', ...
        'the new series has no finite observation on the grid.');
    d = [NaN; diff(log(old))];
    a = new(i0);
    for i = (i0-1):-1:1
        if ~isfinite(d(i+1)); break; end      % stop at the first hole
        a = a / exp(d(i+1));
        y(i) = a;
    end
end

% =========================================================================
function v = local_on_grid(tt, grid)
%   One timetable column onto a quarterly grid BY YEAR AND QUARTER, padding NaN.
%   Matched on (year, quarter) rather than the timestamp because the OECD, FRED
%   and Datastream paths do not all stamp a quarter on the same day.
    v  = NaN(numel(grid),1);
    gq = [year(grid), quarter(grid)];
    tq = [year(tt.Properties.RowTimes), quarter(tt.Properties.RowTimes)];
    x  = tt{:,1};
    [tf, loc] = ismember(gq, tq, 'rows');
    v(tf) = x(loc(tf));
end

% =========================================================================
function Q = local_rename_iso(C, ISO)
%   An SDMX timetable with REF_AREA columns -> this file's country short names.
    Q = local_pick_iso(C, [{'USA'}, ISO], [{'US'}, {'CA','FR','GE','IT','JP','UK'}]);
end

function Q = local_pick_iso(C, isos, names)
%   Columns BY NAME, tolerating the "<ISO>" and "<ISO>_<MEASURE>" shapes
%   fetch_oecd_sdmx produces depending on ColumnDims.
    have = C.Properties.VariableNames;
    Q = timetable(C.Properties.RowTimes);
    Q.Properties.DimensionNames{1} = 'Time';
    for k = 1:numel(isos)
        j = find(strcmp(have, isos{k}) | startsWith(have, [isos{k} '_']), 1);
        if isempty(j)
            warning('build_ew_panel:noArea', '%s absent from the response (have: %s).', ...
                    isos{k}, strjoin(have,', '));
            continue
        end
        Q.(names{k}) = C{:,j};
    end
end

% =========================================================================
function local_coverage(Y, CTRY)
    fprintf('\n  coverage (non-NaN of %d quarters, %s .. %s):\n', height(Y), ...
        string(Y.Time(1),'yyyy-QQQ'), string(Y.Time(end),'yyyy-QQQ'));
    fprintf('    %-5s %7s %7s %7s %7s %7s\n','ctry','EX','EURO','CPI','GDP','M1');
    for k = 1:numel(CTRY)
        c = CTRY{k};
        fprintf('    %-5s %7d %7d %7d %7d %7d\n', c, ...
            sum(isfinite(Y.(['EX_' c]))),  sum(isfinite(Y.(['EURO_' c]))), ...
            sum(isfinite(Y.(['CPI_' c]))), sum(isfinite(Y.(['GDP_' c]))), ...
            sum(isfinite(Y.(['M1_' c]))));
    end
    fprintf('    %-5s %7s %7d %7d %7d %7d\n','US','--', ...
        sum(isfinite(Y.EURO_US)), sum(isfinite(Y.CPI_US)), ...
        sum(isfinite(Y.GDP_US)),  sum(isfinite(Y.M1_US)));
    fprintf('    %-5s US_TFP %d\n','', sum(isfinite(Y.US_TFP)));
end
