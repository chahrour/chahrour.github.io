%% data_import_and_transform.m
% =========================================================================
% Independent, from-scratch reconstruction of the dataset used in
%   "Exchange Rate Disconnect Revisited" (CCDGV).
%
% This script loads raw data from Raw_Data/<provider>/, documents every
% transformation explicitly, assembles the 8-variable baseline VAR vector
% Y_t (paper Eq. 2), and saves a tidy output for comparison against the
% project's original constructed data.
%
% See DATA_SOURCES.md for the full source table and the open questions that
% are flagged inline below as  % QUESTION(n):  (n = item in that doc).
%
% Pipeline:
%   0. Configuration (paths, sample, countries, trade weights)
%   1. Load raw series, per provider, into quarterly timetables
%   2. Build foreign (trade-weighted G6) aggregates
%   3. Transform: logs, differentials, TFP level from Fernald growth
%   4. Assemble Y_t and trim to the sample
%   5. Save outputs (.mat and .csv) + auxiliary series
%
% Conventions:
%   - S_t : USD per unit of foreign currency  (so up = USD depreciation)
%   - Interest differential entered as ln((1+i)/(1+i*))
%   - Real exchange rate q_t = ln(S) + ln(CPI*) - ln(CPI)
%   - All foreign aggregates: trade-weighted GEOMETRIC mean of country logs
%     (Engel 2016 convention)  % QUESTION(1): confirm geometric vs arithmetic
%
% =========================================================================

% A caller may pre-set `datastream_vintage_override` to A/B the raw-data vintages
% (see cfg.datastream_vintage) without editing this file; it survives the clear.
clearvars -except datastream_vintage_override fernald_vintage_override ...
                  built_suffix_override use_cache_override fred_key_file_override
clc;

%% 0. Configuration ------------------------------------------------------
cfg = struct();

% --- Paths
cfg.root    = fileparts(mfilename('fullpath'));      % .../Data_Replication
cfg.rawdir  = fullfile(cfg.root, 'Raw_Data');
cfg.outdir  = fullfile(cfg.root, 'Built_Data');
if ~exist(cfg.outdir, 'dir'); mkdir(cfg.outdir); end

% --- Sample window. §4 trims Y_t DIRECTLY to [sample_start, sample_end] (no
% NaN-drop; you control the dates). Paper benchmark is 1978Q4-2008Q2; the data on
% disk supports up to 1976Q1-2019Q3 (FX-bound). A start earlier than a series'
% coverage leaves NaNs and warns. (quarter-start datetimes)
cfg.sample_start = datetime(1978,10,1);   % 1978:Q4  (paper benchmark start)
cfg.sample_end   = datetime(2008,4,1);    % 2008:Q2  (paper benchmark end)
cfg.extended_end = datetime(2018,10,1);   % 2018:Q4  (Appendix B robustness, convenience)

% --- Foreign block: the other six G7, and trade weights (paper fn. 5).
% Weights = average of 1978 and 2008 "country world trade / total" shares.
% QUESTION(2): which world-trade source produced the 1978 & 2008 shares?
cfg.countries = {'Germany','Japan','France','UK','Italy','Canada'};
cfg.weights   = [0.2945, 0.1843, 0.1599, 0.1399, 0.1230, 0.0984];
assert(abs(sum(cfg.weights)-1) < 1e-6, 'Trade weights must sum to 1.');

% --- Euro transition: fixed legacy-currency/Euro conversions used by
% Datastream to splice a synthetic local-currency/USD rate (paper fn. 5).
% QUESTION: confirm full set; only Italy (1936.27 Lira/EUR) is given in text.
cfg.euro_fix = struct('Italy',1936.27, 'Germany',1.95583, ...
                      'France',6.55957);   % Canada/Japan/UK never euro

% --- OECD SDMX. The responses are cached under Raw_Data/OECD; the build reads
% those, so it needs no network and no credentials.
% ISO-3 REF_AREA codes (includes US, which is not in cfg.countries).
cfg.iso = struct('US','USA', 'Canada','CAN', 'France','FRA', 'Germany','DEU', ...
                 'Italy','ITA', 'Japan','JPN', 'UK','GBR');

% Dataflow references "AGENCY,DATAFLOW,VERSION".
cfg.oecd.eo         = "OECD.ECO.MAD,DSD_EO@DF_EO,1.5";   % Economic Outlook No.119
cfg.oecd.qna_natcur = "OECD.SDD.NAD,DSD_NAMAIN1@DF_QNA_EXPENDITURE_NATIO_CURR,1.1";
cfg.oecd.prices     = "OECD.SDD.TPS,DSD_PRICES@DF_PRICES_ALL,1.0";
% COICOP 2018 CPI dataflow — same key structure, same series, different
% classification vintage. The OECD is migrating countries from COICOP 1999 to
% COICOP 2018 ONE AT A TIME and the old-flow series STOPS when a country moves
% (Japan: COICOP 1999 ends 2021Q2). See extend_cpi_coicop2018.
cfg.oecd.prices_c2018 = "OECD.SDD.TPS,DSD_PRICES_COICOP2018@DF_PRICES_C2018_ALL,1.0";
% Extend each country's CPI with the COICOP-2018 flow where the old flow has run
% out (level-linked, so the COICOP-1999 segment and the paper window are
% untouched). Without this the foreign CPI aggregate silently drops Japan from
% 2021Q3 on — geo_aggregate renormalizes rather than returning NaN.
cfg.cpi_coicop2018_extend = true;

% --- US CPI 2025Q4 repair. BLS never published the OCTOBER 2025 US CPI (federal
% shutdown), so no 2025Q4 quarterly aggregate exists anywhere: the OECD monthly
% series jumps 2025-09 -> 2025-11 and the FRED source series returns '.' for
% 2025-10. That leaves an INTERIOR hole in CPIDIFF and q_real which no amount of
% sample trimming can remove. With this ON, any missing US CPI quarter is filled
% from Raw_Data/FRED/us_cpi_repair.csv, a tracked one-row input (see repair_usCPI.m:
% the missing MONTH is linearly interpolated on the index level, averaged into
% the quarter, and GROWTH-LINKED onto the OECD level of the preceding quarter
% (bases differ, 1982-84=100 vs 2015=100), so no level jump can enter.
% The repaired value is pinned from both sides: forward-linking from 2025Q3 and
% back-linking from 2026Q1 agree to 1.4e-07 log units. See DATA_SOURCES.md #8.
% ⚠ This value is CONSTRUCTED — the October index does not exist. Set false to
% leave the NaN visible instead (the §4 NaN audit will report it either way).
cfg.us_cpi_repair = true;

% --- Consumption & investment: OECD Economic Outlook (EO), chain-linked
% VOLUME (real). Chosen over the QNA institutional-sector series because EO
% carries the long 1965+ history that matches OECD_orig; the QNA by-sector cut
% only starts 1980-1996 for FRA/CAN/DEU/JPN/GBR/ITA. EO
% key order is simply REF_AREA.MEASURE.FREQ. Each variable is an EO "trio":
% volume (VAR input) + nominal + deflator, with volume = nominal / deflator.
% Reference year is country-specific (US/CAN 2017, DEU/JPN/FRA/ITA 2020, GBR 2023).
cfg.oecd.eo_vintage     = "EO No.119 (DSD_EO@DF_EO v1.5)";
cfg.oecd.eo_consumption = struct('volume','CPV', 'nominal','CP', 'deflator','PCP');
cfg.oecd.eo_investment  = struct('volume','ITV', 'nominal','IT', 'deflator','PIT'); % GFCF total
% GDP, same EO trio pattern. Used by the Granger-causality exhibits (the GDP
% differential and the money-minus-output term), not by the VAR.
cfg.oecd.eo_gdp         = struct('volume','GDPV','nominal','GDP','deflator','PGDP');
cfg.oecd.eo_key         = "%s.%s.Q";    % REF_AREA.MEASURE.FREQ

% --- CPI: OECD CPI database DSD_PRICES (cfg.oecd.prices), NOT the EO CPI
% variable (EO lacks DEU/FRA/GBR/ITA). National (METHODOLOGY=N) all-items
% (EXPENDITURE=_T) price INDEX (MEASURE=CPI, UNIT=IX, TRANSFORMATION=_Z),
% Not seasonally adjusted (ADJUSTMENT=N) — the only adjustment with all 7 G7
% (SA missing for FRA/GBR/ITA). Key order:
%   REF_AREA.FREQ.METHODOLOGY.MEASURE.UNIT_MEASURE.EXPENDITURE.ADJUSTMENT.TRANSFORMATION
% NB: CPI is NSA whereas consumption/investment (EO) are SA — flag for the VAR.
cfg.oecd.cpi_key = "%s.Q.N.CPI.IX._T.N._Z";   % %s = '+'-joined REF_AREA(s)

% --- Price block of the VAR (var #8, ln(P/P*)): which price index to use.
%   "CPI" (default) = OECD all-items CPI (NSA) — matches the original/paper, and
%                     our download reproduces the original CPI bit-for-bit.
%   "PCP"           = EO private consumption deflator (SA) — the alternative.
% Both home & foreign series are built and trade-weighted the same way; this one
% flag selects which feeds Y_t (and the real exchange rate q). Easy switch.
% ⚠ PCP caveat: the foreign deflator aggregate is NaN before 1991 (Germany EO
% starts 1991-Q1), so the "PCP" variant needs a sample from 1991+ OR a German
% pre-1991 backcast before it can cover the 1978Q4 benchmark.
cfg.price = "CPI";

% --- Daily Datastream series (FX & eurocurrency deposit rates): how to
% aggregate the daily data to quarterly. "mean" = period average (baseline,
% Appendix A) or "lastvalue" = end-of-quarter (the alternative the originals
% the rates and FX blocks also compute).
cfg.daily_agg = "mean";

% --- Equity (MSCI) daily->quarterly aggregation. Period average, as for every
% other daily series: the equity index enters the VAR as a level alongside the FX
% and rate series, and they are all aggregated the same way (cfg.daily_agg).
% Kept as its own setting only because the equity block reads a different sheet.
cfg.equity_agg = "mean";

% --- Datastream vintage. The original DATASTREAM_*.xlsx files (copied from the
% co-authors' project, no live Datastream access) stop at FX 2019-09, ECRATES
% 2021-12, MSCI 2023-12 — FX is what capped the built panel at 2019Q3. A fresh
% LSEG/Refinitiv pull in Raw_Data/Datastream_new/ carries all three to 2026-07.
% Both wired series are CLEAN SUPERSETS of the originals — same instrument, same
% vendor codes, just re-pulled under the LSEG branding (verified at the raw daily
% level):
%   - RATES (_interestrates.xlsx, re-pulled 2026-07-29): same DSGRID mnemonics
%     ECCAD3M/ECFFR3M/ECWGM3M/ECITL3M/ECJAP3M/ECUKP3M/ECUSD3M, headers now read
%     "FT/LSEG DS" where the original said "FT/RFV". BIT-IDENTICAL on all seven
%     series over the entire 12252-date overlap (1975-01-02..2021-12-17),
%     identical NaN pattern (ITA from 1978-06-09, JPN from 1978-08-01), then
%     1201 further days to 2026-07-27.
%     [An EARLIER LSEG rates pull, since overwritten, WAS a different feed —
%     1/32-grid vs decimal, ~1pp daily gaps, corrupt euro-era FRA/ITA. That is
%     what cfg.euro_rate_unify below was built for; it no longer applies.]
%   - MSCI: bit-identical for all six foreign countries over the whole
%     1970-2023 overlap; ONE cell differs, US 2023-12-29 (1.5e-6 relative,
%     period-averaged into 2023Q4 -> no material effect).
%   - FX (_exchangerates.xlsx, 1976-01-02..2026-07-01): the one series where the
%     new pull is NOT identical. Same instrument snapped at a different time of
%     day, and the RIC is a BID vs the original's middle rate, so DAILY quotes
%     disagree (corr of daily log changes only 0.79-0.82). Quarterly averaging
%     washes that out: the trade-weighted aggregate ln S* has corr(level)
%     0.999995 / corr(growth) 0.999892 vs the original, max gap 1.6e-03 log
%     units = 4.5% of one s.d. of the quarterly change (3.6% inside the paper
%     window). See compare_fx_vintages.m and DATA_SOURCES.md #1.
%   "orig"   = original files only (paper baseline; rates stop 2021-12)
%   "new"    = LSEG files only — one feed throughout   [DEFAULT]
%   "splice" = original through its last date, LSEG after it (kept for A/B)
% With euro_rate_unify OFF, "new" and "splice" leave the rates and MSCI blocks of
% Y bit-for-bit equal to "orig" (verified: 0.000e+00 on all 9 columns, 175 obs).
% FX is deliberately NOT spliced: the gap is far inside sampling noise and a
% single continuous feed is simpler and more transparent than a seam, which is
% the objective here. "splice" therefore reads the LSEG FX file, same as "new";
% only "orig" reads DATASTREAM_FX.xlsx.
cfg.datastream_vintage = "new";
if exist('datastream_vintage_override','var') && ~isempty(datastream_vintage_override)
    cfg.datastream_vintage = string(datastream_vintage_override);
end

% --- Euro-era deposit rates. From 1999 France/Germany/Italy share one currency
% and one money-market rate, and the deposit file reflects that: FRA=GER=ITA to
% the digit from 1999 on, bar 3 days (FRA) and 9 days (ITA) up to 0.17pp.
% OBSOLETE, DEFAULT OFF: this existed only to repair the superseded LSEG rates
% pull, whose country-specific euro RICs (EUR3MD=FR/=DE/=IT) disagreed and whose
% French quote was not credible (2017-01-16: FR +0.330 vs DE -0.365, 3M EURIBOR
% ~-0.33). The current _interestrates.xlsx has no such problem — it reproduces
% the original file exactly. Turning this ON now does harm rather than good: with
% vintage "new" the whole file counts as the LSEG segment, so it would overwrite
% those 12 genuine days and move IDIFF in 8 quarters (max 7.8e-07 = 0.04% of one
% s.d. of the quarterly change; 1999Q1 is inside the paper window).
% Kept as a switch only so the old behaviour stays reproducible.
cfg.euro_rate_unify = false;
cfg.euro_start      = datetime(1999,1,1);

% --- Fernald TFP vintage. One vintage ships and one is used:
%   "2026" = data_quarterly_2026.06.04.xlsx, produced 2026-06-04, ends 2026Q1.
% Earlier vintages were wired while the dataset was being settled and are not any
% more; the package reproduces the paper against this file.
%
% THE FRBSF PUBLISHES EVERY VINTAGE AT THE SAME URL AND FILENAME
% (frbsf.org/economic-research/files/quarterly_tfp.xlsx), overwriting in place.
% Nothing on johnfernald.net/TFP signals a new release, and the only vintage
% marker is the "Produced on <date>" note in row 1 of the 'quarterly' sheet, so
% the file here is renamed with that date on arrival -- see
% Raw_Data/Fernald/SOURCE.txt. Downloading it again gets whatever is current, not
% this one.
%
% A NEW VINTAGE REVISES THE WHOLE HISTORY, not just the tail. The VAR uses the
% cumulated log level cumsum(dtfp_util/400), so a revision to an early quarter
% shifts every later level, and the revisions are not small: against the 2021
% vintage the log changes correlate about 0.93 inside the paper window. TFP is
% also what caps the panel -- FX and the rates already reach 2026Q2 -- so this
% file alone sets the sample end at 2026Q1.
cfg.fernald_vintage = "2026";
if exist('fernald_vintage_override','var') && ~isempty(fernald_vintage_override)
    cfg.fernald_vintage = string(fernald_vintage_override);
end

% --- Built_Data filename suffix. "" reproduces the legacy untagged names. A
% sweep sets e.g. "_f2026" so that building a second vintage does not overwrite
% the first — Y_benchmark.mat and EQ_real_msci.mat are otherwise FIXED names and
% the two Fernald vintages would silently clobber each other. §5 writes BOTH the
% suffixed and the unsuffixed files, so anything reading the bare name keeps
% working. Consumed by CCDGV_Replication/ryan_data.m via its `built_suffix` hook.
cfg.built_suffix = "";
if exist('built_suffix_override','var') && ~isempty(built_suffix_override)
    cfg.built_suffix = string(built_suffix_override);
end


% ONE PLACE DECIDES EVERY OUTPUT FILENAME. cfg.built_suffix REDIRECTS the output;
% it does not add a second copy. The old code wrote the untagged file first and
% then a tagged copy, so a tagged build overwrote the untagged panel every time --
% which build_all_vintages had to work around by running the untagged vintage
% LAST, and which silently replaced the tracked untagged CSVs for anyone running
% this script on its own with built_suffix_override set. The suffix is fixed by
% the time this closure is made and never reassigned after it.
out = @(stem, ext) fullfile(cfg.outdir, [stem char(cfg.built_suffix) ext]);
% --- Germany pre-1991 splice. EO consumption/investment for Germany begin
% 1991-Q1 (post-reunification only). OECD's own continuous West-Germany->unified
% series is NOT on the current live API but IS in the archived original files
% (Raw_Data/OECD_orig/). With the splice ON, German C/I before the splice date
% are backcast using the original file's GROWTH, scaled to the EO level at the
% splice date (continuous). OFF -> the foreign aggregate renormalizes onto the
% other 5 countries before 1991. See DATA_SOURCES.md "Germany splice" + Q#1.
cfg.german_splice    = true;
cfg.german_splice_dt = datetime(1991,1,1);
% Backcast source for German C/I before 1991 (EO starts 1991-Q1):
%   "kei"       = OECD Key Economic Indicators (MEI) via SDMX — REPORTED QoQ growth
%                 (G1); SAME OECD API as EO/CPI; the clean reported series. DEFAULT.
%   "fred"      = OECD MEI via FRED (index 2015=100). The index's differenced growth
%                 is noisier (post-1991 corr with EO only 0.73 for consumption).
%   "orig_file" = archived Raw_Data/OECD_orig/*.xlsx (2021 vintage cross-check).
% All match the original to ~1.0 pre-1991; KEI G1 = EO to 1.0000 post-1991 (see the
% "Source comparison" note below). KEI G1 chosen: clean, OECD-API, EO-consistent.
cfg.german_splice_src = "kei";
cfg.kei        = "OECD.SDD.STES,DSD_KEI@DF_KEI,4.0";   % Key Economic Indicators (MEI)
cfg.kei_german = struct('consumption','P3_S1M_Q', 'investment','P51G_Q', ...
                        'gdp','B1GQ_Q');   % , verified on the API:
% DEU.Q.B1GQ_Q.GR._T.Y.G1 returns 225 quarters, 1970Q2-2026Q2, covering all 60
% quarters EO's German GDP is missing (1976Q1-1990Q4). This is the key the
% noGermanGDPBackcast warning was waiting for -- G_all's German column is no
% longer NaN before 1991Q1.
cfg.kei_key    = "%s.Q.%s.GR._T.Y.G1";  % REF_AREA.FREQ.MEASURE.UNIT.ACTIVITY.ADJ.TRANSFORM
cfg.fred_german = struct('consumption','NAEXKP02DEQ661S', ...   % FRED option: vol index
                         'investment', 'NAEXKP04DEQ661S');

cfg.oecd.start   = "1965-Q1";   % SDMX startPeriod (EO history begins 1965)
% --- Data source: cached CSVs vs fresh API pulls. cfg.use_cache=true reuses the
% saved Raw_Data CSVs (offline, fast, reproducible) for ALL web sources (OECD
% SDMX, KEI, FRED); false re-downloads everything. A missing/0-byte cache file is
% always (re)fetched regardless, so first run still populates the cache.
% Set from config.m's cfg.use_cache, which build_all_vintages passes through the
% clearvars gate above. The literal default keeps this script runnable on its own.
if exist('use_cache_override','var') && ~isempty(use_cache_override)
    cfg.use_cache = logical(use_cache_override);
else
    cfg.use_cache = true;
end
if exist('fred_key_file_override','var') && ~isempty(fred_key_file_override)
    cfg.fred_key_file = fred_key_file_override;
end
cfg.oecd.refresh = ~cfg.use_cache;   % loaders re-download only when not using cache
% NOTE: EO includes projections beyond the last historical quarter; the §4
% sample trim drops them. Germany EO starts 1991-Q1 (no source has pre-1991
% German consumption) -> foreign aggregate is short pre-1991 unless backcast.

fprintf('Config loaded. Sample %s to %s (benchmark).\n', ...
        datestr(cfg.sample_start,'yyyyQQ'), datestr(cfg.sample_end,'yyyyQQ'));

%% 1. Load raw series ----------------------------------------------------
% Each loader returns a quarterly timetable (RowTimes = quarter start dates).
% Country-level series come back with one column per cfg.countries entry.

% 1c. Fernald utilization-adjusted US TFP growth [johnfernald.net, Jan 2 2022]
%     RESOLVED: sheet 'quarterly', column 'dtfp_util', units = annualized %
%     ( = 400 * dlog ). File: Raw_Data/Fernald/data_quarterly_2026.06.04.xlsx (1947Q1-2021Q3).
tfp_growth = load_fernald_tfp(cfg);        % annualized % growth, single col

% 1d. OECD real consumption, real investment (GFCF), CPI [OECD SDMX API]
%     Consumption WIRED to EO chain-linked volume CPV (real). 'ALL' pulls every
%     country (US first) x {CPV,CP,PCP} in a SINGLE combined request; cached raw
%     is Raw_Data/OECD/EO_consumption_ALL.csv. Column 1 = US (home), 2:end = G7.
%     cons_ref keeps the nominal (CP) and deflator (PCP) panels for reference.
%     TIP: set cfg.oecd.refresh=false to rerun offline from cache (0 calls).
%
% https://webfs-eco.oecd.org/files/.Stat/EO119/EO119_Database_documentation.pdf
[C_all, cons_ref] = load_oecd_series(cfg, 'consumption', 'ALL');  % 1 API call

% Investment WIRED to EO GFCF (total) chain-linked volume ITV (real), same
% 'ALL' single-request pattern as consumption; cached EO_investment_ALL.csv.
[I_all, inv_ref] = load_oecd_series(cfg, 'investment', 'ALL');  % 1 API call

% GDP, for the Granger exhibits. Same EO dataflow and the same one-call pattern
% as consumption and investment; GDPV is the chain-linked volume, so log(GDPV) is
% the counterpart of the original core's log(real GDP) from OECD_GDP.xlsx.
% GERMANY: EO GDP for Germany starts 1991Q1, the same pre-unification gap that
% C/I have, and splice_german is applied below only when a backcast key is
% configured for 'gdp'. Until then the German column is NaN before
% cfg.german_splice_dt and the warning below says so.
[G_all, gdp_ref] = load_oecd_series(cfg, 'gdp', 'ALL');  % 1 API call

% --- GERMANY pre-1991 splice (cfg.german_splice). EO C/I for Germany start
% 1991-Q1; backcast earlier quarters with the German GROWTH from the source set
% by cfg.german_splice_src (default "kei" = OECD KEI reported QoQ growth; also
% "fred" or the archived "orig_file"), scaled to the EO level at
% cfg.german_splice_dt (continuous). This restores a proper 6-country foreign
% block back to 1976. The KEI growth series is the same linked MEI series the
% paper used: pre-1991 growth matches the archived original at corr 0.99999 for
% consumption and 0.99964 for investment, and equals EO to 1.0000 after 1991.
if cfg.german_splice
    C_all = splice_german(C_all, load_german_backcast(cfg,'consumption'), cfg.german_splice_dt);
    I_all = splice_german(I_all, load_german_backcast(cfg,'investment'),  cfg.german_splice_dt);
    % GDP only if a backcast key exists for it. No key is guessed: a wrong SDMX
    % key returns an empty series, which splices to nothing and looks like
    % success. The original core HAS German GDP back to 1976 (OECD_GDP.xlsx), so
    % whoever wires this should decide between the KEI/FRED route the other two
    % use and reading that file via the existing 'orig_file' path.
    srcf = lower(string(cfg.german_splice_src));
    hasg = (srcf == "kei"       && isfield(cfg.kei_german,'gdp'))  || ...
           (srcf == "fred"      && isfield(cfg.fred_german,'gdp')) || ...
            srcf == "orig_file";
    if hasg
        G_all = splice_german(G_all, load_german_backcast(cfg,'gdp'), cfg.german_splice_dt);
    else
        warning('data_import:noGermanGDPBackcast', ...
            ['German GDP is NaN before %s: EO GDPV for DEU starts 1991Q1 and no ' ...
             '''gdp'' backcast key is configured for cfg.german_splice_src="%s". ' ...
             'Germany covers 112 of 172 quarters on the 1976Q1-2018Q4 grid.'], ...
            string(cfg.german_splice_dt, 'yyyy-QQQ'), srcf);
    end
end
C_home = C_all(:, 1);  C_for = C_all(:, 2:end);   % US home; six G7 foreign
I_home = I_all(:, 1);  I_for = I_all(:, 2:end);

% CPI WIRED to OECD CPI database (DSD_PRICES): national all-items index, NSA.
% (EO's CPI variable lacks 4 of the G7.) Cached CPI_ALL.csv.
% Foreign Solow residuals, manifest row 13. MOVED HERE 2026-10-09 from
% the original G6SolowResiduals.xlsx sheet, read through
% g6_solow_series. There is no API for these -- they are a hand-built panel from
% the original project -- so the spreadsheet stays, but the AGGREGATION now uses
% geo_aggregate_growth like every other foreign aggregate instead of its own
% hand-rolled renormalisation. Verified identical: log changes agree to 2.2e-16
% and correlate 1.0000000000 with the retired script, the levels differing by a
% single constant (2.784209, sd 7.7e-16) because the anchor convention differs.
% That constant is harmless and was checked, not assumed: the VAR absorbs it in
% nconst, and ccdgv_project fits an intercept (:92) while the ridge path demeans,
% so coefficients, r2 and residuals are invariant -- measured at 3.9e-14 on the
% fixed path and 4.1e-15 on the drawn one.
SOL_all = load_solow(cfg);
SOLOW_G6 = geo_aggregate_growth(SOL_all, cfg.weights);

[P_all, cpi_ref] = load_oecd_series(cfg, 'cpi', 'ALL');  % 1 API call
P_home = P_all(:, 1);          % US (home)  CPI
P_for  = P_all(:, 2:end);      % six G7 (foreign) CPI, in cfg.countries order

% Alternative price series for the VAR price block: the EO private consumption
% deflator PCP (from the consumption load's cons_ref), so cfg.price='PCP' can
% substitute it for CPI. Same panel layout as CPI (US first), aggregated like
% CPI in §2. PCP is SA and Germany starts 1991 (see cfg.price caveat).
PCP_home = cons_ref.PCP(:, 1);     % US (home) consumption deflator
PCP_for  = cons_ref.PCP(:, 2:end); % six G7 (foreign) deflators, cfg.countries order

% 1e. Interest rates: 3-month eurocurrency deposit rates [Datastream ECRATES].
%     Loader returns the quarterly GROSS rate (1+i)^(1/4) per country, US-first
%     (period-averaged daily annualized %, then ^(1/4)).
%     The foreign aggregate (§2) and the differential ln((1+i)/(1+i*)) (§3) then
%     use the SAME geo_aggregate / build_diff as the price block.
i_all  = load_datastream_eurorate(cfg);    % quarterly gross rate, US-first 7 cols
i_home = i_all(:, 1);                       % US
i_for  = i_all(:, 2:end);                   % six G7 (cfg.countries order)

% 1a. Nominal exchange rate, USD per foreign currency [Datastream FX, sheet 'S'].
%     Daily spot, period-averaged to quarterly (cfg.daily_agg). No US column
%     (S is already USD/foreign); the VAR variable is the trade-weighted foreign
%     aggregate ln(S*) built in §2. Orientation confirmed USD-per-foreign.
S_fx = load_datastream_fx(cfg);            % quarterly FX levels, cols: cfg.countries


%% 2. Foreign (trade-weighted) aggregates --------------------------------
% All foreign aggregates are trade-weighted GEOMETRIC means of country logs:
%   ln(X*_t) = sum_c w_c * ln(X_{c,t})       % QUESTION(1)
% Implemented in geo_aggregate() (helpers_aggregation.m).
% Both aggregators renormalize the trade weights over the countries AVAILABLE
% each quarter (a missing country gets no weight), so the panel can start as
% early as data allow (~1976) rather than waiting for every country. We use the
% LEVEL-based geo_aggregate for commensurable, always-present series (FX, CPI)
% and the GROWTH-based geo_aggregate_growth for incommensurable national-currency
% LEVELS where a country enters mid-sample (consumption, investment, deflator —
% Germany from 1991) to avoid a spurious entry jump. The eurodeposit rates are
% commensurable (a level is meaningful) BUT their panel grows mid-sample, so a
% renormalized LEVEL aggregate would step
% at each entry.
%
% TWO DATES PER COUNTRY, AND THEY ARE BOTH USED. The Datastream feeds begin
% mid-quarter -- Italy 1978-06-09, Japan 1978-08-01 -- so the FIRST quarter each
% appears in is a partial average (Italy 1978Q2, Japan 1978Q3), and the first
% quarter each is present for in full is the next one (Italy 1978Q3, Japan
% 1978Q4). retime's 'mean' omits NaN, which is what produces the partial figure
% rather than a NaN; IDIFF_PA_SERIES says the same and is where it matters.
%
% geo_aggregate_spliced keeps the true 6-country level on the
% all-present block (1978Q4+, == geo_aggregate, so the paper window is unchanged)
% and backcasts earlier quarters via overlap-chained growth, level-linked at the
% first all-present quarter — no entry jump. (Moot when all countries are present.)
S_star_log   = geo_aggregate(S_fx,           cfg.weights);   % ln(S*_t)  (all present)
C_star_log   = geo_aggregate_growth(C_for,   cfg.weights);   % ln(C*_t)  (DEU from 1991)
I_star_log   = geo_aggregate_growth(I_for,   cfg.weights);   % ln(I*_t)  (DEU from 1991)
P_star_log   = geo_aggregate(P_for,          cfg.weights);   % ln(CPI*_t) (all present)
PCP_star_log = geo_aggregate_growth(PCP_for, cfg.weights);   % ln(PCP*_t) (DEU from 1991)
i_star_log   = geo_aggregate_spliced(i_for,  cfg.weights);   % Σ w_c·ln(1+i_c)^(1/4); ITA/JPN entry spliced
% Aggregation matches the ORIGINAL methods: CPI_data.m uses the level form
% (geo_aggregate), CONSUMPTION_data.m the cumulated-growth form
% (geo_aggregate_growth); both with these same weights.

%% 3. Transformations to build Y_t ---------------------------------------
% ASSUMPTION: every loader in §1 returns a series on the SAME quarterly grid
% (RowTimes = quarter-start dates). The element-wise differentials below rely
% on that; synchronize_all() in §4 still does a final intersection as a guard.
% If loaders return ragged grids, synchronize each pair before subtracting.
%
% 3a. TFP level from Fernald growth.
%     dtfp_util is annualized % growth -> quarterly log change = g/400
%     (file note: "percent change at an annual rate = 400 * change in ln").
%     Cumulate to a log level. The first obs (1947:Q1) has no growth value;
%     fillmissing sets it to 0 so the cumulated level starts at 0 there.
%     The starting level is just a constant (absorbed by the VAR); within
%     the estimation sample only the increments matter.
dlog_tfp = tfp_growth{:,1} / 400;
log_tfp  = cumsum(fillmissing(dlog_tfp, 'constant', 0));
TFP_log  = array2timetable(log_tfp, 'RowTimes', tfp_growth.Time, ...
                           'VariableNames', {'lnTFP'});

% 3b. Logs of home levels.
lnC   = log_tt(C_home, 'lnC');
lnI   = log_tt(I_home, 'lnI');

% 3c. Interest-rate differential ln((1+i)/(1+i*)) = ln(1+i_US)^(1/4) - Σ w_c
%     ln(1+i_c)^(1/4), via the same build_diff as the price block (i_home is the
%     US quarterly gross rate, i_star_log the foreign aggregate from §2).
int_diff = build_diff(log_tt(i_home, 'lni'), i_star_log, 'int_diff');

% 3d. Price-level differential ln(P/P*) = ln(P) - ln(P*). cfg.price selects the
%     index: 'CPI' (OECD all-items CPI, paper baseline) or 'PCP' (EO consumption
%     deflator). Both are built; the flag picks which enters Y_t and q.
cpi_diff = build_diff(log_tt(P_home,  'lnP'), P_star_log,   'price_diff');   % ln(CPI/CPI*)
pcp_diff = build_diff(log_tt(PCP_home,'lnP'), PCP_star_log, 'price_diff');   % ln(PCP/PCP*)
switch upper(string(cfg.price))
    case "CPI"; price_diff = cpi_diff;  Phome_log = log_tt(P_home,  'lnP'); Pstar = P_star_log;
    case "PCP"; price_diff = pcp_diff;  Phome_log = log_tt(PCP_home,'lnP'); Pstar = PCP_star_log;
    otherwise;  error('cfg.price must be "CPI" or "PCP".');
end

% 3e. Real exchange rate (derived, not a VAR input itself but saved).
%     q_t = ln(S) + ln(P*) - ln(P), using the SAME price index as the VAR.
%     (Different source grids -> synchronize before subtracting.)
q_real = build_q(S_star_log, Pstar, Phome_log, 'q_real');

%% 4. Assemble Y_t and trim to sample ------------------------------------
% Column order:
%   [ TFP, C, I, NER, IDIFF, C*, CPIDIFF, I* ]
% = [Home TFP, Home Consumption, Home Investment, ln S*, interest differential,
%    Foreign Consumption, CPI differential ln(P/P*), Foreign Investment].
% (Paper Eq. 2 lists them in a different order; the VAR is order-invariant, but we
%  match the original layout for a direct column-by-column comparison in §6.)
Y = synchronize_all( ...
        rename(TFP_log,    'TFP'),     ...     % 1 Home TFP
        rename(lnC,        'C'),       ...     % 2 Home Consumption
        rename(lnI,        'I'),       ...     % 3 Home Investment
        rename(S_star_log, 'NER'),     ...     % 4 NER (ln S*, agg FX)
        rename(int_diff,   'IDIFF'),   ...     % 5 ln((1+i)/(1+i*))
        rename(C_star_log, 'Cstar'),   ...     % 6 Foreign Consumption
        rename(price_diff, 'CPIDIFF'), ...     % 7 ln(P/P*)  [CPI or PCP per cfg.price]
        rename(I_star_log, 'Istar'),   ...     % 8 Foreign Investment
        rename(q_real,     'q_real') );        %   (extra) real exchange rate

% Y is the FULL assembled history (the intersection grid where all 8 series
% cover, ~1976Q1-2019Q3, no NaN). We ALWAYS save this full panel so downstream
% consumers (the ryan_data.m adapter, your own runs) can select ANY window. The
% explicit window [cfg.sample_start, cfg.sample_end] is just a VIEW (Y_bench) for
% the §6 match test and convenience; it does NOT limit what gets saved.
Y_bench = Y(isbetween(Y.Time, cfg.sample_start, cfg.sample_end), :);

fprintf('Y_t assembled: FULL %s..%s (%d obs) | window %s..%s (%d obs) x 8 vars.\n', ...
        datestr(Y.Time(1),'yyyyQQ'),       datestr(Y.Time(end),'yyyyQQ'),       height(Y), ...
        datestr(Y_bench.Time(1),'yyyyQQ'), datestr(Y_bench.Time(end),'yyyyQQ'), height(Y_bench));

% WHY does the panel start/end where it does? Y is the INTERSECTION of the eight
% inputs, so a single short series silently sets the span — and which one it is
% is not obvious from the result. Name it, with the runner-up for context.
inputs = { 'TFP',     TFP_log;     'C',       lnC;         'I',     lnI; ...
           'NER',     S_star_log;  'IDIFF',   int_diff;    'Cstar', C_star_log; ...
           'CPIDIFF', price_diff;  'Istar',   I_star_log };
spans = cellfun(@(t) [t.Time(find(~isnan(t{:,1}),1)), t.Time(find(~isnan(t{:,1}),1,'last'))], ...
                inputs(:,2), 'UniformOutput', false);
spans = vertcat(spans{:});
[~, iStart] = max(spans(:,1));            % latest start  -> binds the beginning
[~, iEnd]   = min(spans(:,2));            % earliest end  -> binds the end
[~, ordE]   = sort(spans(:,2));
fprintf(['  binding: START by %-7s (%s)   END by %-7s (%s)' ...
         '   [next-shortest end: %s %s]\n'], ...
        inputs{iStart,1}, datestr(spans(iStart,1),'yyyyQQ'), ...
        inputs{iEnd,1},   datestr(spans(iEnd,2),  'yyyyQQ'), ...
        inputs{ordE(2),1}, datestr(spans(ordE(2),2),'yyyyQQ'));
if strcmp(inputs{iEnd,1}, 'TFP') && string(cfg.fernald_vintage) ~= "2026"
    fprintf(['  (TFP is capped by cfg.fernald_vintage="%s", which ends there. The "2026" ' ...
             'vintage runs to 2026Q1 and would\n   extend the panel, but it is not a ' ...
             'longer version of the same series: Fernald revised essentially the\n' ...
             '   whole history, 298 of 299 overlapping quarters back to 1947Q2. In log ' ...
             'changes the two vintages\n   correlate 0.9471 overall and 0.9345 inside ' ...
             'the paper window. Switching changes results.)\n'], cfg.fernald_vintage);
end
% NaN audit. A NaN anywhere in the VAR block is disqualifying for estimation on a
% window that contains it, and an INTERIOR hole (data on both sides) cannot be
% fixed by trimming — so name the exact quarters and variables rather than
% warning vaguely. Known live example: US CPI has no 2025Q4 value because BLS
% never published the October 2025 index (federal shutdown), so OECD publishes no
% quarterly aggregate for that quarter; CPIDIFF and q_real are NaN there.
miss = ismissing(Y{:, 1:8});
if any(miss, 'all')
    rows = find(any(miss, 2));
    fprintf('\n⚠ NaN audit: %d NaN cell(s) in the VAR block of the full panel:\n', sum(miss,'all'));
    for i = rows(:)'
        vars = miss(i,:);
        % INTERIOR = the same variable has data both before and after this
        % quarter, so trimming the sample cannot remove the hole.
        interior = any(any(~miss(1:i-1, vars), 1) & any(~miss(i+1:end, vars), 1));
        if interior; flag = '  <-- INTERIOR hole (cannot be trimmed away)'; else; flag = ''; end
        fprintf('   %s : %-20s%s\n', datestr(Y.Time(i),'yyyyQQ'), ...
                strjoin(Y.Properties.VariableNames(vars), ', '), flag);
    end
    fprintf(['   -> Estimation windows must avoid these quarters. An INTERIOR hole ' ...
             'cannot be trimmed away.\n\n']);
    warning('Full panel has a NaN in a VAR variable — see the NaN audit above.');
end

%% 5. Save outputs — ALWAYS the FULL history -----------------------------
% Y_benchmark.mat holds the full timetable Y (the adapter reads this), the
% windowed view Y_bench, and cfg. The CSV and the plain matrix are also full.
% Always write the untagged name (legacy consumers), and additionally a
% suffixed copy when cfg.built_suffix is set, so vintages can coexist.
%
% PER-COUNTRY PANELS. Everything above this point aggregates
% to the G6 before saving, so Y carries a single NER / CPIDIFF / q_real and the
% country dimension is lost. genpoorman (paper Figure 6 and Table B.5) needs
% per-country real exchange rates for all seven columns -- six countries plus the
% aggregate -- and until now had to bypass the data build entirely and read
% Raw_Data Excel through NER_data/CPI_data to get them.
%
%   S_fx   quarterly FX LEVELS, one column per foreign country in cfg.countries
%          order (6 cols; see load_datastream_fx at ~line 345)
%   P_all  quarterly CPI, 7 columns, US FIRST then cfg.countries (see ~line 321)
%
% EXTENDED 2026-08-07 with the three remaining panels, same US-FIRST convention:
%
%   C_all  quarterly real consumption, national currency (~line 316)
%   I_all  quarterly real investment,  national currency (~line 317)
%   i_all  quarterly GROSS interest rates (1+i)^(1/4)    (~line 339)
%   G_all  quarterly real GDP (EO GDPV, chain-linked volume), national currency,
%          US FIRST then cfg.countries. For the GRANGER exhibits, not the VAR --
%          gc_run's GDP differential and its money-minus-output term. log(GDPV)
%          is the counterpart of the original core's log(real GDP) from
%          OECD_GDP.xlsx: correlations of the log level are 0.9998-1.0000 for all
%          seven, and of the log CHANGE 0.968-0.997 except France at 0.910.
%          Germany starts 1991Q1 unless a backcast key is configured.
%
% WHY. Five of the eight VAR series vary by country -- NER, IDIFF, Cstar, CPIDIFF
% and Istar -- and S_fx/P_all covered only two of them, so ryan_data had no
% per-country path, every by-country run would silently re-estimate
% the G6 aggregate. These three close that gap; see ryan_data's country branch,
% which rebuilds each series with the SAME aggregator the G6 path uses, applied
% to one column.
%
% Both are timetables, so they carry their own Time and a consumer can align by
% date rather than by position. That matters: the raw-loader path genpoorman
% used previously relied on three independently loaded files all happening to be
% 172 rows starting 1976Q1, with no assertion anywhere.
%
% Purely additive -- every existing consumer loads Y / Y_bench / cfg by name and
% is unaffected by the extra variables.
%% 6b. Auxiliary trade-balance series, appended to Y ----------------------
% Two measures, in this order:
%   TB_G6   US-G6 goods trade balance / nominal GDP  (USDATA cols 18/19)
%   NX_GDP  total US net exports / GDP               (FRED A019RE1Q156NBEA)
%
% APPENDED WITH addvars, NOT passed into synchronize_all above. That call is an
% INTERSECTION: the G6 series ends 2018Q4, so feeding it in would truncate Y from
% 2026Q1 back to 2018Q4 for every downstream consumer. Here the columns are
% NaN-padded outside their coverage and Y's grid is untouched.
%
% STORED AS FRACTIONS. ryan_data applies `data = 100*data` (:127) and the orig
% loader does the same, so both paths end in percent of GDP. The FRED series is
% published ALREADY IN PERCENT -- hence the /100. Without it the series would
% be 100x too large, and that looks plausible in isolation.
%
% The G6 measure has no FRED equivalent (it is a bilateral balance against six
% named partners); load_imf_imts referenced further down was never written. So
% BOTH paths read it from the same USDATA sheet, and it is a vintage-identical
% carry-over rather than an independent rebuild.
TB_G6  = nan(height(Y),1);
NX_GDP = nan(height(Y),1);

ud = fullfile(cfg.rawdir,'CCDGV','USDATA.xlsx');
if ~isfile(ud)
    warning('dit:noUSDATA','USDATA.xlsx not found; TB_G6 left NaN.');
else
    Tu = readtable(ud, 'VariableNamingRule', 'preserve');
    Au = table2array(Tu(:,2:end));
    g6 = Au(:,18)./Au(:,19)./1e6;                       % $ / ($m * 1e6) -> fraction
    % DATES READ FROM THE SHEET, NOT ASSUMED FROM THE ROW COUNT. This used to
    % build the grid as 1976Q1 + (0:nrows-1) quarters, which is right only while
    % the sheet starts exactly there and has no gap -- and silently misaligns
    % TB_G6 against Y by whole quarters if it ever does not. Column 1 carries the
    % dates; TECH_PROXY_SERIES reads the same sheet the same way.
    tg = Tu{:,1};
    if ~isdatetime(tg); tg = datetime(tg, 'ConvertFrom', 'excel'); end
    tg = dateshift(tg(:), 'start', 'quarter');
    % Compared against a grid BUILT with calquarters, not by differencing: diff on
    % a datetime gives a fixed duration, and a quarter is 90, 91 or 92 days, so
    % `diff(tg) == calquarters(1)` is false for most of them.
    assert(isequal(tg, tg(1) + calquarters(0:numel(tg)-1)'), 'dit:usdataGrid', ...
        'USDATA.xlsx column 1 is not a contiguous quarterly grid (%s .. %s, %d rows).', ...
        char(string(tg(1),'yyyy-QQQ')), char(string(tg(end),'yyyy-QQQ')), numel(tg));
    [tf,loc] = ismember(Y.Time, tg);
    TB_G6(tf) = g6(loc(tf));
    fprintf('  TB_G6  from %s: %d of %d quarters matched\n', ud, sum(tf & ~isnan(TB_G6)), height(Y));
end

try
    Fb = load_fred(cfg, 'A019RE1Q156NBEA');             % BEA, PERCENT of GDP
    [tf,loc] = ismember(Y.Time, Fb.Properties.RowTimes);
    v = Fb{:,1};
    NX_GDP(tf) = v(loc(tf)) / 100;                      % percent -> fraction
    fprintf('  NX_GDP from FRED A019RE1Q156NBEA: %d of %d quarters matched\n', ...
            sum(tf & ~isnan(NX_GDP)), height(Y));
catch ME
    warning('dit:noFredTB','FRED trade-balance fetch failed (%s); NX_GDP left NaN.', ME.message);
end

Y = addvars(Y, TB_G6, NX_GDP, 'NewVariableNames', {'TB_G6','NX_GDP'});
% SOLOW_G6, aligned BY DATE: the Solow sheet runs 1970Q1-2021Q4 while Y reaches
% 2026Q1, so the column is NaN at both ends rather than silently clipping Y.
sg = NaN(height(Y),1);
[sg_tf, sg_loc] = ismember([year(Y.Time) quarter(Y.Time)], ...
                           [year(SOLOW_G6.Time) quarter(SOLOW_G6.Time)], 'rows');
sg(sg_tf) = SOLOW_G6.lnAgg(sg_loc(sg_tf));
Y = addvars(Y, sg, 'NewVariableNames', {'SOLOW_G6'});

save(out('Y_benchmark','.mat'), 'Y', 'Y_bench', 'cfg', ...
     'S_fx', 'P_all', 'C_all', 'I_all', 'i_all', 'G_all', 'SOL_all');
writetimetable(Y, out('Y_benchmark','.csv'));
fprintf('Saved full Y (%d obs, %d vars) + window + per-country panels (S_fx %dx%d, P_all %dx%d) to %s\n', ...
        height(Y), width(Y)-1, height(S_fx), width(S_fx), height(P_all), width(P_all), cfg.outdir);

% A plain T x 8 matrix of the baseline core variables used to be written here
% "for hand-off" and read by nothing: the estimation takes Y from the built panel
% through ryan_data, which resolves columns by name. Removed rather than kept as
% a convenience, because a second copy of the data with no consumer is the kind
% of file someone later mistakes for an input.

%% 6. Match test vs the ORIGINAL constructed dataset ---------------------
% Compare our 8 VAR variables to the original project's `data` matrix over the
% baseline overlap. Trending series (levels, FX) are compared in GROWTH (which is
% invariant to the different anchors/base years and to the original's x100
% scaling); the stationary interest differential is compared in LEVELS. The
% original `data` columns are [TFP,C,I,NER,IDIFF,C*,CPIDIFF,I*], 1978Q4-2008Q2.

% ASSET_PRICE_data and the helpers it needs live in the sibling CCDGV_Replication
% folder; put them on the path so this script is self-contained.
ccdgv_dir = fullfile(cfg.root, '..', 'CCDGV_Replication');
if exist(ccdgv_dir, 'dir'); addpath(genpath(ccdgv_dir)); end

% ASSET_PRICE_data leaves its series in the workspace; asset_price_series runs it
% in a workspace of its own and returns only these, so nothing else it defines can
% collide with this script.
[equity_price_us, equity_price_g6, ...
 excess_equity_return_differential, excess_bond_return_differential, ...
 bond_yield_gfd_us, bond_yield_gfd_g6, ap_dates] = asset_price_series(ccdgv_dir, ...
                                                          cfg.rawdir, i_all);

% Save the asset returns as a DATED panel, exactly as section 7 saves the MSCI
% equity panel. Before this, ryan_data required these four series as loose
% WORKSPACE variables -- its assert read "run ASSET_PRICE_data first (run_main
% does)" -- which forced run_main to re-run the whole of ASSET_PRICE_data,
% re-reading the MSCI workbook and re-running load_bonds, for series this build
% had already computed. ryan_data was also inconsistent about it: it already read
% EQ_US/EQ_G6 by date out of EQ_real_msci.mat forty lines earlier. Now all of them
% come from a panel, and the redundant run_main call is gone.
% NOTE 'RowTimes': timetable(ap_dates, ...) would name the row-times dimension
% after the input variable, i.e. APt.ap_dates rather than APt.Time, and every
% consumer indexes .Time.
AP_out = timetable(excess_equity_return_differential, excess_bond_return_differential, ...
    bond_yield_gfd_us, bond_yield_gfd_g6, ...
    'RowTimes', ap_dates, ...
    'VariableNames', {'exret_eq','exret_bond','by_us','by_g6'});
save(out('AP_returns','.mat'), 'AP_out', 'cfg');
writetimetable(AP_out, out('AP_returns','.csv'));
fprintf('Saved asset-return aux (%d obs, %s..%s) to %s\n', height(AP_out), ...
        string(ap_dates(1),'yyyy-QQQ'), string(ap_dates(end),'yyyy-QQQ'), cfg.outdir);
% The old data core's constructor used to run here and its first eight columns
% were compared against this build's, as a check that the rebuild reproduced
% them. This package contains one core, so there is nothing to compare against
% and the block is gone.

% --- Auxiliary series (not in baseline VAR; built for figures/robustness).
%     Loaded lazily so a missing file doesn't block the core build.
% RD       = load_fred(cfg, 'Y694RX1Q020SBEA');      % US real R&D (Fig B.10)
% TB_gdp   = load_fred(cfg, 'A019RE1Q156NBEA');      % US net exports %GDP (§4)
% TB_goods = load_imf_imts(cfg);                     % US-G7 goods TB (Fig B.1)
% BY       = load_gfd_bondyields(cfg);               % 10Y yields  (Fig 5)

%% 7. Auxiliary: MSCI REAL equity (TOTAL RETURN index, CPI-deflated) ------
% Variation on the original ASSET_PRICE_data.m, which used the MSCI PRICE index
% in local currency, undeflated. Here we take the MSCI TOTAL RETURN index
% (sheet 2), aggregate daily->quarterly by period average (cfg.equity_agg),
% deflate EACH country by its own CPI to get a
% real local-currency total-return index, then trade-weight the six foreign
% countries (G6) into a constant-weight geometric aggregate — the same
% geo_aggregate / cfg.weights used for FX and CPI.
EQ_tri = load_datastream_msci(cfg);          % quarterly nominal TRI (EOP), [US + 6]

% Deflate per country by its own CPI. Align the quarterly CPI panel P_all (same
% [US, cfg.countries] column order) to the MSCI quarterly grid, then divide.
P_on_eq      = retime(P_all, EQ_tri.Time, 'fillwithmissing');
EQ_real      = EQ_tri;
EQ_real{:,:} = EQ_tri{:,:} ./ P_on_eq{:,:};  % real = nominal TRI / CPI (local ccy)

% Home (US) real log level, and the G6 foreign aggregate (geometric, constant
% trade weights, per-quarter renormalization over available countries).
lnUS = log(EQ_real{:,1});
lnG6 = geo_aggregate(EQ_real(:,2:end), cfg.weights).lnAgg;   % ln(G6 real agg)

% Levels + logs; drop pre-coverage NaN quarters so the return series is contiguous.
EQ_lvl = timetable(EQ_real.Time, exp(lnUS), exp(lnG6), lnUS, lnG6, ...
            'VariableNames', {'EQreal_US','EQreal_G6','lnEQreal_US','lnEQreal_G6'});
EQ_lvl = rmmissing(EQ_lvl);

% Quarterly REAL log returns on the period-averaged index: r_t = ln(idx_t/idx_{t-1}).
% First quarter is NaN by construction (no prior level). Consistent with Y_t's log
% convention and the original's diff(log) equity returns.
rUS = [NaN; diff(EQ_lvl.lnEQreal_US)];
rG6 = [NaN; diff(EQ_lvl.lnEQreal_G6)];
EQ_out = addvars(EQ_lvl, rUS, rG6, 'NewVariableNames', {'rEQreal_US','rEQreal_G6'});

save(out('EQ_real_msci','.mat'), 'EQ_out', 'cfg');
writetimetable(EQ_out, out('EQ_real_msci','.csv'));
fprintf('Saved MSCI real-equity aux (%d obs, %s..%s; EOP returns) to %s\n', ...
        height(EQ_out), datestr(EQ_out.Time(1),'yyyyQQ'), ...
        datestr(EQ_out.Time(end),'yyyyQQ'), cfg.outdir);

% =========================================================================
% LOCAL FUNCTIONS — the loaders and small transform helpers.
% Each loader reads one raw source from Raw_Data/ and returns it on the common
% quarterly grid.
% =========================================================================

function [eq_us, eq_g6, exret_eq, exret_bond, by_us, by_g6, ap_dates] = asset_price_series(ccdgv_dir, rawroot, ap_rates)
% Run ASSET_PRICE_data in its own workspace and return the series that
% the asset block produces. It is cd'd into CCDGV_Replication because
% its inputs are read by paths relative to that folder.
% ap_rates (i_all) is passed down because ASSET_PRICE_data needs the
% short-rate differentials and we are INSIDE the build -- Y_benchmark*.mat does
% not exist yet, so it cannot read them from disk. It picks ap_rates up out of
% this workspace. See IDIFF_PA_SERIES.
%
% ap_raw carries its RAW inputs, read here by this file's own loaders, so that a
% build opens no spreadsheet from CCDGV_Replication. ASSET_PRICE_data keeps
% fallback reads for the standalone generators that run it with nothing supplied.
ap_raw = load_asset_raw(rawroot);
old = cd(ccdgv_dir);
back = onCleanup(@() cd(old));
ASSET_PRICE_data;
eq_us      = equity_price_us;
eq_g6      = equity_price_g6;
exret_eq   = excess_equity_return_differential;
exret_bond = excess_bond_return_differential;
by_us      = bond_yield_gfd_us;
by_g6      = bond_yield_gfd_g6;
ap_dates   = idiff_t_pa;        % the AP_START..AP_END grid it trimmed to
end

function tt = load_datastream_fx(cfg)
% Return a quarterly timetable of FX LEVELS (USD per foreign currency), one
% column per cfg.countries [Germany, Japan, France, UK, Italy, Canada]. §2 takes
% logs & builds the geometric trade-weighted aggregate ln S*. Matches original
% NER_data.m: same 6 currencies, period average (cfg.daily_agg).
%
% Source is cfg.datastream_vintage: "orig" reads DATASTREAM_FX.xlsx (ends
% 2019-09-05, which is what used to cap the panel at 2019Q3); anything else reads
% the LSEG _exchangerates.xlsx (to 2026-07-01). FX is NOT spliced — see the
% config note.
    if string(cfg.datastream_vintage) == "orig"
        daily = read_fx_orig(cfg);
    else
        daily = read_fx_new(cfg);
    end

    % Daily -> quarterly. NOTE the 'omitnan': unlike the original file, which has
    % no daily holes at all, the LSEG panel leaves scattered single days unquoted
    % (national holidays — 45 ITL, 37 GBP, 8 DEM, 1 FRF/JPY over 50 years). A
    % NaN-PROPAGATING mean would void that whole quarter for that currency (27 of
    % 203 quarters), and §2's geo_aggregate would then renormalize a weighted mean
    % of log levels of INCOMMENSURABLE currencies (ln ITL ~ -6.5 vs ln GBP ~
    % +0.36), producing jumps of up to 1.6 log units. Averaging the ~64 quoted
    % days of a quarter instead of requiring all ~65 is immaterial, and on the
    % original file the two coincide exactly — so this stays faithful to
    % NER_data.m. (The other daily series have no interior holes and keep the
    % NaN-propagating daily_to_quarterly.)
    if cfg.daily_agg == "mean"
        tt = retime(daily, 'quarterly', @(x) mean(x,'omitnan'));
    else
        tt = daily_to_quarterly(daily, cfg.daily_agg);
    end

    % Drop a trailing PARTIAL quarter (daily data stops mid-quarter: 2019-09-05
    % for the original file, 2026-07-01 for the LSEG one). Averaging a handful of
    % days into a quarter that is mostly missing would put a spurious point at
    % the end of the sample.
    qend = dateshift(daily.Time(end), 'end', 'quarter');
    if daily.Time(end) < qend
        tt(tt.Time >= dateshift(daily.Time(end),'start','quarter'), :) = [];
    end
end

function daily = read_fx_orig(cfg)
% Original DATASTREAM_FX.xlsx sheet 'S' (daily spot, USD per foreign currency).
% Layout: row 1 = currency codes (19: AUD,...,GBP), row 2 = Datastream country
% codes, rows 3+ = [date, 19 daily rates]. Euro-legacy currencies (FRF/DEM/ITL)
% are carried post-1999 as synthetic rates by Datastream.
    must_exist(fullfile(cfg.rawdir,'Datastream'));
    f = fullfile(cfg.rawdir,'Datastream','DATASTREAM_FX.xlsx');
    if ~exist(f,'file'); error('FX file not found: %s', f); end

    T  = readtable(f, 'Sheet','S', 'Range','A3', 'ReadVariableNames',false);
    dt = T{:,1};
    if ~isdatetime(dt); dt = datetime(dt); end
    M  = T{:,2:20};                                % 19 daily FX series (AUD..GBP)

    % Select the 6 currencies in cfg.countries order [GER,JPN,FRA,UK,ITA,CAN]:
    %   DEM=8, JPY=11, FRF=7, GBP=19, ITL=10, CAD=4 (positions among the 19).
    sel   = [8 11 7 19 10 4];
    daily = array2timetable(M(:, sel), 'RowTimes', dt, 'VariableNames', cfg.countries);
end

function daily = read_fx_new(cfg)
% LSEG/Refinitiv _exchangerates.xlsx, built FROM THE RAW 'Sorted' SHEET rather
% than from the workbook's hand-made 'Replication' sheet, so every step is in
% code. The workbook's intermediate sheets encode four hand steps; this function
% reproduces them, and compare_fx_vintages.m checks the result against the
% 'Replication' sheet (max relative error 0.000e+00 on all six currencies):
%   1. 'USD per FC'                 the RIC quotes `CAD= (BID)` are FC per USD ->
%                                   invert CAD/FRF/DEM/ITL/JPY; GBP and EUR are
%                                   already USD per FC and pass through.
%   2. 'Append EUR to FRF DEM ITL'  the legacy quotes stop 2001-12-31; from
%                                   2002-01-02 the three are chained forward on
%                                   the euro's own daily return,
%                                   X_t = X_{t-1} * EUR_t / EUR_{t-1}
%                                   (a level-linked splice off the last legacy
%                                   quote, not a fixed-rate conversion).
%   3. 'Nan --> empty'              IFERROR(...,"") -> blanks are missing values.
%   4. 'Replication'                drop the EUR helper column.
% Sheet layout: row 1 = RIC headers, rows 2+ = [date, CAD FRF DEM ITL JPY GBP EUR].
    must_exist(fullfile(cfg.rawdir,'Datastream_new'));
    f = fullfile(cfg.rawdir,'Datastream_new','_exchangerates.xlsx');
    if ~exist(f,'file'); error('FX file (new vintage) not found: %s', f); end

    T   = readtable(f,'Sheet','Sorted','Range','A1','ReadVariableNames',true, ...
                    'VariableNamingRule','preserve');
    dt  = T{:,1};
    if ~isdatetime(dt); dt = datetime(dt); end
    hdr = T.Properties.VariableNames(2:end);
    ccy = cellfun(@(s) char(extractBefore(string(s),'=')), hdr, 'UniformOutput', false);

    % Blank cells arrive as '' in a text column -> NaN.
    V = nan(height(T), numel(ccy));
    for j = 1:numel(ccy)
        c = T{:,j+1};
        if isnumeric(c); V(:,j) = c; else; V(:,j) = str2double(string(c)); end
    end

    % Step 1: USD per FC.
    inv = ~ismember(ccy, {'GBP','EUR'});
    V(:,inv) = 1 ./ V(:,inv);

    % Step 2: append EUR to FRF/DEM/ITL from 2002-01-02.
    iEUR  = strcmp(ccy,'EUR');
    chain = ismember(ccy, {'FRF','DEM','ITL'});
    i0    = find(dt == datetime(2002,1,2));
    assert(isscalar(i0), 'read_fx_new: chain start 2002-01-02 not found in ''Sorted''.');
    eur = V(:,iEUR);
    for i = i0:numel(dt)
        V(i,chain) = V(i-1,chain) * eur(i) / eur(i-1);   % NaN propagates, as Excel's error does
    end

    % Steps 3-4: NaNs already carried; drop EUR and order as cfg.countries
    % [GER,JPN,FRA,UK,ITA,CAN].
    sel   = [find(strcmp(ccy,'DEM')), find(strcmp(ccy,'JPY')), find(strcmp(ccy,'FRF')), ...
             find(strcmp(ccy,'GBP')), find(strcmp(ccy,'ITL')), find(strcmp(ccy,'CAD'))];
    daily = array2timetable(V(:,sel), 'RowTimes', dt, 'VariableNames', cfg.countries);
end

function tt = load_datastream_msci(cfg)
% Read DATASTREAM_MSCI_DAILY.xlsx sheet 'Total Return Indexes' (daily MSCI
% TOTAL-RETURN index, in LOCAL currency per country) and return a quarterly
% timetable of index LEVELS, US first then cfg.countries:
%   [US, Germany, Japan, France, UK, Italy, Canada].
% Daily -> quarterly by cfg.equity_agg, which is the period average.
%
% NB: this deliberately uses the TOTAL RETURN index (sheet 2) — the variation
% requested here — whereas the original baseline used the PRICE index (sheet 1).
%
% File layout (sheet 'Total Return Indexes'): row 1 = names, row 2 = vendor
% codes, row 3 = currency, rows 4+ = [date, 7 daily indices in file order
% Canada, France, Germany, Italy, Japan, UK, USA]. Both vintages share it; which
% file(s) are read is set by cfg.datastream_vintage (see the config note — the
% two are bit-identical over the overlap, so the choice only extends the tail).
    daily = read_datastream_vintages(cfg, 'msci');

    % Reorder file columns [Can,Fra,Ger,Ita,Jpn,UK,USA] -> [US, cfg.countries]
    %   = [USA, Germany, Japan, France, UK, Italy, Canada]:
    sel   = [7 3 5 2 6 4 1];
    daily = daily(:, sel);
    daily.Properties.VariableNames = [{'US'}, cfg.countries];

    % Daily -> quarterly, period average -- the same convention as cfg.daily_agg.
    tt = daily_to_quarterly(daily, cfg.equity_agg);
end

function [f, sheet, skiprows] = datastream_file(cfg, which, vintage)
% Path + sheet + header-row count for a raw daily vendor file. `which` =
% 'ecrates'|'msci'; `vintage` = "orig" (Datastream, Raw_Data/Datastream/) or
% "new" (LSEG/Refinitiv, Raw_Data/Datastream_new/).
    if vintage == "orig"; sub = 'Datastream'; else; sub = 'Datastream_new'; end
    must_exist(fullfile(cfg.rawdir, sub));
    switch which
        case 'ecrates'
            if vintage == "orig"
                f = 'DATASTREAM_ECRATES.xlsx';         sheet = 'Sheet2';
            else
                f = '_interestrates.xlsx';             sheet = 'Replication';
            end
            skiprows = 1;                              % 1 header row
        case 'msci'
            if vintage == "orig"
                f = 'DATASTREAM_MSCI_DAILY.xlsx';
            else
                f = 'DATASTREAM_MSCI_DAILY_UPDATED.xlsx';
            end
            sheet = 'Total Return Indexes';  skiprows = 3;   % name/code/currency
    end
    f = fullfile(cfg.rawdir, sub, f);
    if ~exist(f,'file')
        error('%s file (%s vintage) not found: %s', which, vintage, f);
    end
end

function daily = read_daily_vendor(cfg, which, vintage)
% Read one raw daily file -> timetable of the 7 series in FILE column order
% [CAN,FRA,GER,ITA,JPN,GBR,US] (both 'ecrates' and 'msci' use that order).
    [f, sheet, skiprows] = datastream_file(cfg, which, vintage);
    T  = readtable(f, 'Sheet', sheet, 'Range', sprintf('A%d', skiprows+1), ...
                   'ReadVariableNames', false);
    dt = T{:,1};
    if ~isdatetime(dt); dt = datetime(dt); end
    V  = T{:,2:8};
    if ~isnumeric(V)
        error('%s (%s): columns 2-8 did not read as numeric.', which, vintage);
    end
    daily = array2timetable(V, 'RowTimes', dt, ...
                'VariableNames', {'CAN','FRA','GER','ITA','JPN','GBR','US'});
end

function [daily, seam] = read_datastream_vintages(cfg, which)
% Apply cfg.datastream_vintage: "orig"/"new" read one file; "splice" takes the
% original through its last date and appends the LSEG rows after it, so the
% validated paper window is untouched and only the tail is new. `seam` = last
% date covered by the ORIGINAL feed (NaT when every row is LSEG), so callers can
% tell the two segments apart.
    switch string(cfg.datastream_vintage)
        case "orig"
            daily = read_daily_vendor(cfg, which, "orig");
            seam  = daily.Time(end);
        case "new"
            daily = read_daily_vendor(cfg, which, "new");
            seam  = NaT;
        case "splice"
            old   = read_daily_vendor(cfg, which, "orig");
            new   = read_daily_vendor(cfg, which, "new");
            seam  = old.Time(end);
            daily = [old; new(new.Time > seam, :)];
        otherwise
            error('cfg.datastream_vintage must be "orig", "new" or "splice" (got "%s").', ...
                  cfg.datastream_vintage);
    end
end

function q = daily_to_quarterly(daily, method)
% Daily timetable -> quarterly (quarter-start grid). 'mean' = NaN-PROPAGATING
% period average (a quarter with any missing daily value becomes NaN), matching
% 'mean' = period average; 'lastvalue' = end-of-quarter.
    switch char(method)
        case 'mean';  q = retime(daily, 'quarterly', @mean);   % @mean propagates NaN
        otherwise;    q = retime(daily, 'quarterly', char(method));
    end
end

function i_all = load_datastream_eurorate(cfg)
% Read DATASTREAM_ECRATES.xlsx (daily 3-month eurocurrency deposit rates,
% "FT/RFV middle rate", annualized %) and return the quarterly GROSS rate
% (1+i)^(1/4) per country, US-first: [US, cfg.countries]. Returning the gross
% rate (a positive "level") lets §2 form the foreign aggregate with the same
% geo_aggregate as the price block (Σ w_c·ln(1+i_c)^(1/4)) and §3 the differential
% with build_diff — exactly mirroring CPI/PCP. Steps:
%   1. read daily annualized % (file cols [CAN,FRA,GER,ITA,JPN,GBR,US])
%   2. period-average to quarterly (cfg.daily_agg; 'lastvalue'=end-of-quarter)
%   3. quarterly gross rate G = (1 + r_bar/100)^(1/4)
% Which vendor file(s) feed step 1 is set by cfg.datastream_vintage. The default
% "new" reads the re-pulled LSEG file alone: it reproduces the original feed
% bit-for-bit over the whole 1975-2021 overlap (so the paper window is exactly
% the paper's window) and carries on to 2026-07.
    [daily, seam] = read_datastream_vintages(cfg, 'ecrates');

    % Euro era: France & Italy take Germany's rate (cfg.euro_rate_unify). OFF by
    % default — see the config note; it was a repair for a superseded LSEG pull.
    % Applied ONLY to rows coming from the LSEG feed. The original feed is left
    % exactly as-is: it is near-identical across FRA/GER/ITA post-1999 but NOT
    % bit-identical (3 days for FRA, 9 for ITA, up to 0.17pp), and those days sit
    % inside the paper window — overwriting them would silently move the
    % validated IDIFF.
    if cfg.euro_rate_unify && string(cfg.datastream_vintage) ~= "orig"
        if isnat(seam); isnew = true(height(daily),1); else; isnew = daily.Time > seam; end
        e = isnew & daily.Time >= cfg.euro_start;
        daily.FRA(e) = daily.GER(e);
        daily.ITA(e) = daily.GER(e);
    end

    % Daily -> quarterly (quarter-start grid). 'mean'=period avg; 'lastvalue'=eoq.
    %
    % ONE NOTE ON NaN, because it is not obvious and it decided a sample boundary
    % for years: retime's STRING method 'mean' OMITS NaN, where the handle @mean
    % propagates it. A country's FIRST, PARTIAL quarter therefore gets an average
    % over however many days exist -- Italy's feed starts 1978-06-09 and Japan's
    % 1978-08-01, so 1978Q2 and 1978Q3 are averages of part of a quarter.
    %
    % That is left exactly as it is. The fix for a sample boundary is to CHOOSE the
    % boundary, not to make a loader emit NaN and let a downstream mask discover it.
    % Consumers that care declare their own window: see ASSET_PRICE_data's AP_START
    % and AP_END.
    q = retime(daily, 'quarterly', char(cfg.daily_agg));

    G = (1 + q{:,:}/100).^(1/4);                   % annualized % -> quarterly gross
    % Reorder file cols [CAN,FRA,GER,ITA,JPN,GBR,US] -> [US,GER,JPN,FRA,GBR,ITA,CAN]
    idx   = [7 3 5 2 6 4 1];
    names = [{'US'}, cfg.countries];
    i_all = array2timetable(G(:, idx), 'RowTimes', q.Time, 'VariableNames', names);
end

function raw = load_asset_raw(rawroot)
% Read ASSET_PRICE_data's raw inputs HERE, in the data layer, and hand them over.
% Before this the build cd'd into CCDGV_Replication and let that script open the
% spreadsheets itself, which put raw-file reads in the analysis folder and made the
% build depend on the working directory being right. The arithmetic stays where it
% was -- only the reads moved.
%   Raw_Data/nyse_real_lev       CJ's real NYSE level, column 2
%   DATASTREAM_MSCI_DAILY.xlsx   'Price Indexes' and 'Total Return Indexes'
% Paths are resolved against the raw root passed in rather than the current
% folder, which is the point: no cd is needed to read them. It must be an
% argument, not cfg.rawdir -- a local function cannot see the caller's cfg.
%
% THE TWO FILES SIT IN DIFFERENT SOURCE FOLDERS. nyse_real_lev is CJ's, under
% CCDGV; the MSCI workbook is a Datastream extract and lives with the other
% Datastream files. It used to be duplicated under both, and the copies were
% byte-identical, so the merge kept one.
    tmp = importdata(fullfile(rawroot, 'CCDGV', 'nyse_real_lev'));
    raw.cj_equity = tmp.data(:,2);
    f = fullfile(rawroot, 'Datastream', 'DATASTREAM_MSCI_DAILY.xlsx');
    assert(isfile(f), 'load_asset_raw:noMSCI', '%s not found.', f);
    P = readtable(f, 'Sheet', 'Price Indexes',        'VariableNamingRule', 'preserve');
    T = readtable(f, 'Sheet', 'Total Return Indexes', 'VariableNamingRule', 'preserve');
    raw.date_d_ec          = table2array(P(1:end,1));
    raw.equity_price_daily = table2array(P(1:end,2:end));
    raw.equity_tri_daily   = table2array(T(1:end,2:end));
end
function tt = load_fernald_tfp(cfg)
% Read the Fernald quarterly file from Raw_Data/Fernald/.
% Returns the utilization-adjusted TFP GROWTH column 'dtfp_util' as a
% single-column quarterly timetable, in the file's native units:
%   percent change at an ANNUAL rate ( = 400 * change in natural log ).
% The /400 conversion and cumulation to a log level happen in §3a, so the
% loader stays a faithful "read the raw column" step.
%
% File layout (both vintages, sheet 'quarterly' — identical schema):
%   row 1  = descriptive note (incl. the production date);  row 2 = headers;
%   rows 3+ = data; col 'date' holds 'YYYY:Qn' strings (e.g. '1978:Q4')
%   col 'dtfp_util' is the utilization-adjusted TFP growth used in the paper.
% Which file is read is set by cfg.fernald_vintage (see the config note).
    must_exist(fullfile(cfg.rawdir,'Fernald'));
    f = fullfile(cfg.rawdir,'Fernald', fernald_file(cfg));
    if ~exist(f,'file')
        error('Fernald file (%s vintage) not found: %s', cfg.fernald_vintage, f);
    end

    % Read starting at A2 so row 2 supplies variable names, row 3+ the data.
    T = readtable(f, 'Sheet','quarterly', 'Range','A2', ...
                  'VariableNamingRule','preserve');

    % Below the data the sheet has a blank row then summary-stat rows
    % ('Full sample mean', 'Since 1995:4', 'Past 4 qtrs', ...). Keep only
    % rows whose date matches YYYY:Qn so those (and any blanks) are dropped.
    dstr = string(T.date);
    dstr(ismissing(dstr)) = "";
    keep = ~cellfun('isempty', regexp(dstr, '^\d{4}:Q[1-4]$', 'once'));
    T    = T(keep, :);

    g  = T.dtfp_util;                       % annualized %, = 400*dlog(TFP)
    dt = parse_fernald_quarter(T.date);     % 'YYYY:Qn' -> quarter-start date

    tt = timetable(g, 'RowTimes', dt, 'VariableNames', {'dtfp_util'});
    tt = sortrows(tt);                      % ensure ascending time ('Time' dim)
end

function f = fernald_file(cfg)
% Filename for cfg.fernald_vintage. Both files sit in Raw_Data/Fernald/ and share
% the same schema, so only the name changes.
    switch string(cfg.fernald_vintage)
        case "2026";  f = 'data_quarterly_2026.06.04.xlsx';
        otherwise
            error('ccdgv:fernaldVintage', ...
                  ['cfg.fernald_vintage must be "2026" -- the package ships one ' ...
                   'Fernald file. Got "%s".'], cfg.fernald_vintage);
    end
end

function [tt, ref] = load_oecd_series(cfg, what, which)
% Pull an OECD series from the SDMX API (one call per country) and return a
% quarterly timetable of LEVELS, one column per country named by cfg.countries
% (or a single 'US' column). Raw CSVs are cached under Raw_Data/OECD/ for
% provenance. Set cfg.oecd.refresh=false to reuse cached files offline.
%
% what  = 'consumption' | 'investment' | 'cpi'
% which = 'US' (single col) | 'G7' (one col per cfg.countries)
%
% [tt, ref] : for 'consumption'/'investment', tt is the EO chain-linked VOLUME
%             (real level), and ref holds the companion nominal + deflator
%             panels under their measure-code field names, e.g.
%               consumption -> ref.CP, ref.PCP   (CPV = CP ./ PCP)
%               investment  -> ref.IT, ref.PIT   (ITV = IT ./ PIT)
%             All three measures are pulled in one request and cached as a CSV.

    % Countries to fetch, in output order. 'ALL' = US first, then the six G7,
    % so the home series is column 1 and the foreign block is columns 2:end.
    switch which
        case 'US';  names = {'US'};
        case 'G7';  names = cfg.countries;
        case 'ALL'; names = [{'US'}, cfg.countries];
        otherwise;  error('load_oecd_series: which must be ''US'', ''G7'' or ''ALL''.');
    end

    ref = struct();
    switch what
        case 'consumption'
            % EO private consumption trio CPV/CP/PCP (chain-linked volume).
            [tt, ref] = load_eo_trio(cfg, names, which, cfg.oecd.eo_consumption, 'consumption');
        case 'investment'
            % EO gross fixed capital formation (total) trio ITV/IT/PIT.
            [tt, ref] = load_eo_trio(cfg, names, which, cfg.oecd.eo_investment, 'investment');
        case 'gdp'
            [tt, ref] = load_eo_trio(cfg, names, which, cfg.oecd.eo_gdp, 'gdp');
        case 'cpi'
            % OECD CPI database (DSD_PRICES): national all-items CPI INDEX, NSA,
            % index (base 2015). One combined request, REF_AREA '+'-joined.
            isos  = cellfun(@(n) cfg.iso.(n), names, 'UniformOutput', false);
            key   = sprintf(cfg.oecd.cpi_key, strjoin(isos,'+'));
            raw   = fullfile(cfg.rawdir, 'OECD', sprintf('CPI_%s.csv', which));
            combo = fetch_oecd_sdmx(cfg.oecd.prices, key, ...
                        'StartPeriod', cfg.oecd.start, ...
                        'RawFile',     raw, ...
                        'Refresh',     cfg.oecd.refresh, ...
                        'ColumnDims',  ["REF_AREA","MEASURE"]);
            tt = eo_panel(combo, names, isos, 'CPI');       % cols "ISO_CPI"
            ref.note = sprintf(['OECD CPI DB (%s) | national all-items CPI ' ...
                'index (IX), NOT seasonally adjusted, base 2015.'], cfg.oecd.prices);
            if cfg.cpi_coicop2018_extend
                [tt, ref.c2018] = extend_cpi_coicop2018(cfg, tt, names, isos, which);
            end
            if cfg.us_cpi_repair
                [tt, ref.us_repair] = apply_us_cpi_repair(cfg, tt);
            end
        otherwise
            error('load_oecd_series: unknown series ''%s''.', what);
    end
end

function [tt, info] = extend_cpi_coicop2018(cfg, tt, names, isos, which)
% Extend the COICOP-1999 CPI panel with the COICOP-2018 dataflow, per country.
%
% WHY. The OECD is migrating national CPIs from the COICOP 1999 classification
% (DSD_PRICES@DF_PRICES_ALL — what the paper's series and our bit-for-bit
% validation use) to COICOP 2018 (DSD_PRICES_COICOP2018@DF_PRICES_C2018_ALL),
% ONE COUNTRY AT A TIME, and a country's old-flow series simply STOPS when it
% moves. As of 2026-07 Japan had already moved (COICOP 1999 ends 2021Q2, at any
% frequency), while the US, Germany and the UK had not (absent from COICOP 2018).
% France, Italy and Canada appear in both. Without this the foreign CPI aggregate
% silently loses Japan — weight 0.1843 — from 2021Q3 on, because geo_aggregate
% renormalizes over the available countries rather than going NaN.
%
% METHOD. The two flows are the SAME series, not a revision: over the overlap the
% COICOP-2018 level equals the COICOP-1999 level exactly for Japan and Canada
% (ratio 1.000000, quarterly growth identical to 0.0e+00 in all 225 quarters),
% differs by a pure constant for Italy (1.000310 — a rebasing) and by ~8e-05 for
% France. So this is a source migration, not a splice of different measures.
% Even so we LEVEL-LINK rather than concatenate: the new flow is chained onto the
% old one at the last common quarter using its own growth rates,
%   CPI_t = CPI_{t-1} * (C18_t / C18_{t-1})   for t after the old flow ends,
% so a constant base difference (Italy) can never enter as a step, and the
% COICOP-1999 segment — including the whole validated paper window — is returned
% completely untouched. For Japan and Canada the link is exact, so the result is
% identical to a plain concatenation.
%
% Countries absent from COICOP 2018 are left exactly as they were.
    key = sprintf(cfg.oecd.cpi_key, strjoin(isos,'+'));
    raw = fullfile(cfg.rawdir, 'OECD', sprintf('CPI_C2018_%s.csv', which));
    try
        combo = fetch_oecd_sdmx(cfg.oecd.prices_c2018, key, ...
                    'StartPeriod', cfg.oecd.start, ...
                    'RawFile',     raw, ...
                    'Refresh',     cfg.oecd.refresh, ...
                    'ColumnDims',  ["REF_AREA","MEASURE"]);
    catch ME
        warning('CPI COICOP-2018 extension skipped (%s): %s', cfg.oecd.prices_c2018, ME.message);
        info = struct('extended', {{}}, 'note', 'fetch failed');
        return
    end
    % A country missing from COICOP 2018 is the NORMAL case here (it simply has
    % not migrated yet), not a fault — so mute eo_panel's missing-column warning.
    ws = warning('off','ccdgv:eo_panel:missingColumn');
    new = eo_panel(combo, names, isos, 'CPI');
    warning(ws);
    absent = names(all(isnan(new.Variables),1));
    if ~isempty(absent)
        fprintf('  CPI COICOP 2018: not yet migrated (left on COICOP 1999): %s\n', ...
                strjoin(absent, ', '));
    end

    % Union the time grids so the extension has somewhere to live.
    tt  = synchronize(tt, new, 'union', 'fillwithmissing');
    old = tt(:, 1:numel(names));   nw = tt(:, numel(names)+1:end);
    T   = old.Time;
    X   = old.Variables;   N = nw.Variables;

    extended = {};
    for k = 1:numel(names)
        x = X(:,k); n = N(:,k);
        iold = find(~isnan(x), 1, 'last');
        if isempty(iold) || all(isnan(n)); continue; end
        % Chain forward from the last old observation on the new flow's growth.
        for i = iold+1:numel(T)
            if isnan(n(i)) || isnan(n(i-1)); continue; end
            x(i) = x(i-1) * n(i) / n(i-1);
        end
        if any(~isnan(x(iold+1:end)))
            extended{end+1} = sprintf('%s(%s->%s)', names{k}, ...
                datestr(T(iold),'yyyyQQ'), datestr(T(find(~isnan(x),1,'last')),'yyyyQQ')); %#ok<AGROW>
        end
        X(:,k) = x;
    end
    tt = array2timetable(X, 'RowTimes', T, 'VariableNames', names);
    tt = tt(any(~isnan(X),2), :);        % drop all-NaN rows created by the union

    info = struct('extended', {extended}, 'note', ...
        sprintf('COICOP-2018 (%s) chained onto COICOP-1999 at each country''s last obs.', ...
                cfg.oecd.prices_c2018));
    if ~isempty(extended)
        fprintf('  CPI extended via COICOP 2018: %s\n', strjoin(extended, ', '));
    end
end

function [tt, info] = apply_us_cpi_repair(cfg, tt)
% Fill missing US CPI quarters from Built_Data/us_cpi_repair.mat (see
% repair_usCPI.m and the cfg.us_cpi_repair note). Only ever writes into quarters
% that are ACTUALLY missing — an existing published value is never overwritten —
% and it reports the growth either side of each filled quarter so a spurious jump
% cannot slip in unnoticed.
    info = struct('applied', {{}}, 'note', '');
    if ~ismember('US', tt.Properties.VariableNames); return; end

    % SHIPPED AS A TRACKED CSV, not built. BLS never published the October 2025
    % index, so US CPI has no 2025Q4 value. That gap is INTERIOR -- the panel runs
    % to 2026Q1 -- and newcore_country_series asserts against interior gaps, so
    % without this the country specifications fail outright. It is one row, read
    % here rather than rebuilt, so a fresh clone has it.
    f = fullfile(cfg.rawdir, 'FRED', 'us_cpi_repair.csv');
    if ~exist(f,'file')
        error('ccdgv:usCpiRepairMissing', ...
              ['%s is missing. US CPI has no 2025Q4 value, the gap is interior, ' ...
               'and the country specifications assert against interior gaps -- ' ...
               'so the run would fail later with a less obvious message. Restore ' ...
               'the file or set cfg.us_cpi_repair = false and accept that the ' ...
               'country runs will not complete.'], f);
    end
    rep = readtable(f);
    rep.Quarter = datetime(rep.Quarter);

    us = tt.US;
    for i = 1:height(rep)
        q  = rep.Quarter(i);
        ix = find(tt.Time == q, 1);
        if isempty(ix)                        % quarter not on the grid at all
            continue
        elseif ~isnan(us(ix))                 % already published -> never overwrite
            fprintf(['  US CPI repair: %s already has a published value ' ...
                     '(%.5f) — repair NOT applied.\n'], datestr(q,'yyyyQQ'), us(ix));
            continue
        end
        us(ix) = rep.CPI_repaired(i);
        info.applied{end+1} = datestr(q,'yyyyQQ');                     %#ok<AGROW>
        % Report the seam: growth into and out of the filled quarter, against
        % the historical s.d. of US CPI quarterly growth.
        g  = diff(log(us));
        sd = std(g, 'omitnan');
        fprintf(['  US CPI repair: %s filled with %.5f  ' ...
                 '(growth in %+.5f, out %+.5f; s.d. %.5f)\n'], ...
                datestr(q,'yyyyQQ'), us(ix), g(ix-1), g(ix), sd);
        if max(abs([g(ix-1) g(ix)])) > 4*sd
            warning('US CPI repair at %s produced a >4 s.d. growth move — inspect.', ...
                    datestr(q,'yyyyQQ'));
        end
    end
    tt.US = us;
    info.note = 'from Raw_Data/FRED/us_cpi_repair.csv';
end

function tt = load_solow(cfg)
% Foreign Solow residuals, per country, from the original project's hand-built
% sheet. There is no API for these.
%
%   The sheet's columns are cn/fr/bd/it/jp/uk_tfp -- CANADA, FRANCE, GERMANY
%   (bd = Bundesrepublik Deutschland), ITALY, JAPAN, UK -- which is NOT
%   cfg.countries order. Mapped BY NAME below; a positional map would return the
%   wrong country's data for five of six and still produce a plausible run.
%
%   COVERAGE IS RAGGED AND THE AGGREGATE'S COMPOSITION CHANGES, which the
%   zero-filling would hide: Germany starts 1991Q1 and Canada
%   1997Q1, so over the paper window the "G6" is
%       1976Q1-1990Q4  FRA ITA JPN UK   (39.3% of weight absent: GER + CAN)
%       1991Q1-1996Q4  + GER            ( 9.8% absent: CAN)
%       1997Q1-        all six
%   geo_aggregate_growth renormalises over the countries present in BOTH
%   adjacent quarters, so an entering country contributes its GROWTH rather than
%   a level step, which is the renormalisation the aggregate needs, and
%   why the two agree to 2.2e-16 in log changes.
    f = fullfile(cfg.rawdir, 'CCDGV', 'G6SolowResiduals.xlsx');
    assert(isfile(f), 'data_import:noSolow', '%s not found.', f);
    R = readtable(f, 'VariableNamingRule', 'preserve');
    d = R{:,1};
    if ~isdatetime(d); d = datetime(d, 'ConvertFrom', 'excel'); end
    d = dateshift(d, 'start', 'quarter');
    MAP = struct('Germany','bd_tfp', 'Japan','jp_tfp', 'France','fr_tfp', ...
                 'UK','uk_tfp', 'Italy','it_tfp', 'Canada','cn_tfp');
    V = NaN(height(R), numel(cfg.countries));
    for k = 1:numel(cfg.countries)
        c = cfg.countries{k};
        assert(isfield(MAP, c), 'data_import:solowCountry', ...
            'no Solow column mapped for %s.', c);
        col = MAP.(c);
        assert(ismember(col, R.Properties.VariableNames), 'data_import:solowColumn', ...
            '"%s" is not a column of the Solow sheet -- it has %s.', ...
            col, strjoin(R.Properties.VariableNames, ', '));
        V(:,k) = R.(col);
    end
    tt = array2timetable(V, 'RowTimes', d, 'VariableNames', cfg.countries);
    tt = sortrows(tt);
end

% =========================================================================
function [tt, ref] = load_eo_trio(cfg, names, which, m, tag)
% Fetch an EO {volume, nominal, deflator} trio in ONE combined request (all
% countries x all 3 measures, REF_AREA & MEASURE both '+'-joined) and return
% the VOLUME as a country panel (tt). The nominal and deflator panels are kept
% in ref under their measure-code field names; identity volume = nominal/defl.
%   m   : struct with fields .volume .nominal .deflator (EO MEASURE codes)
%   tag : cache-file tag -> Raw_Data/OECD/EO_<tag>_<which>.csv
    measures = {m.volume, m.nominal, m.deflator};
    isos     = cellfun(@(n) cfg.iso.(n), names, 'UniformOutput', false);
    key      = sprintf(cfg.oecd.eo_key, strjoin(isos,'+'), strjoin(measures,'+'));
    raw      = fullfile(cfg.rawdir, 'OECD', sprintf('EO_%s_%s.csv', tag, which));
    combo = fetch_oecd_sdmx(cfg.oecd.eo, key, ...
                'StartPeriod', cfg.oecd.start, ...
                'RawFile',     raw, ...
                'Refresh',     cfg.oecd.refresh, ...
                'ColumnDims',  ["REF_AREA","MEASURE"]);
    tt               = eo_panel(combo, names, isos, m.volume);   % real level (VAR input)
    ref.(m.nominal)  = eo_panel(combo, names, isos, m.nominal);  % nominal value
    ref.(m.deflator) = eo_panel(combo, names, isos, m.deflator); % deflator
    ref.note = sprintf(['%s | %s=volume (chain-linked, real); %s=nominal; ' ...
        '%s=deflator (country-specific ref year). %s = %s ./ %s.'], ...
        cfg.oecd.eo_vintage, m.volume, m.nominal, m.deflator, ...
        m.volume, m.nominal, m.deflator);
end

function tt = eo_panel(combo, names, isos, measure)
% Slice one MEASURE out of a combined EO timetable (columns 'ISO_MEASURE') into
% a country panel: one column per country, named by the friendly NAMES. Missing
% country/measure columns become NaN (e.g. a series absent for a country).
    vn = string(combo.Properties.VariableNames);
    X  = nan(height(combo), numel(names));
    for k = 1:numel(names)
        cn = string(isos{k}) + "_" + string(measure);       % e.g. "USA_CPV"
        if ismember(cn, vn)
            X(:,k) = combo{:, char(cn)};
        else
            warning('ccdgv:eo_panel:missingColumn', ...
                    'eo_panel: column %s not in response (filled NaN).', cn);
        end
    end
    tt = array2timetable(X, 'RowTimes', combo.Time, 'VariableNames', names);
end

function tt = load_orig_german(cfg, what)
% Read the German column from the ARCHIVED ORIGINAL OECD file (2021 vintage,
% Raw_Data/OECD_orig/) and return a quarterly German LEVEL timetable, used to
% backcast Germany before 1991 (the live EO API starts German C/I at 1991-Q1).
% Consumption: "Level of real consumption" (a level). Investment: the original
% "G6 Data" sheet is QUARTERLY GROWTH RATES (%), cumulated here to a level
% (exp(cumsum(growth/100))) exactly as the original INVESTMENT_data.m does.
    d = fullfile(cfg.rawdir, 'OECD_orig');
    switch what
        case 'consumption'
            f   = fullfile(d, 'OECD_Consumption.xlsx');
            T   = readtable(f, 'Sheet','OECD.Stat export', 'Range','A2', ...
                            'VariableNamingRule','preserve');
            dt  = parse_qdate(T.Country);          % 'Q4-1970'
            lvl = T.Germany;                       % real consumption level
        case 'investment'
            f   = fullfile(d, 'OECD_Investment.xlsx');
            T   = readtable(f, 'Sheet','G6 Data', 'Range','A2', ...
                            'VariableNamingRule','preserve');
            dt  = parse_qdate(T.TIME);             % '1961-Q2'
            lvl = exp(cumsum(T.GER/100));          % growth % -> log level -> level
        otherwise
            error('load_orig_german: what must be ''consumption'' or ''investment''.');
    end
    keep = ~isnat(dt) & ~isnan(lvl);
    tt = sortrows(timetable(lvl(keep), 'RowTimes', dt(keep), ...
                            'VariableNames', {'Germany'}));
end

function tt = load_german_backcast(cfg, what)
% German pre-1991 backcast series (a LEVEL/index timetable named 'Germany'),
% from FRED OECD-MEI (cfg.german_splice_src="fred", default) or the archived
% original file ("orig_file"). Used by splice_german (only the GROWTH matters).
    switch lower(string(cfg.german_splice_src))
        case "kei"
            % OECD KEI reported QoQ growth (G1, %, SA). Build a pseudo-level by
            % compounding (cumprod) — only the growth matters; splice_german
            % rescales it to the EO level at the splice date.
            key = sprintf(cfg.kei_key, 'DEU', cfg.kei_german.(what));
            raw = fullfile(cfg.rawdir, 'OECD', sprintf('KEI_DEU_%s.csv', what));
            g   = fetch_oecd_sdmx(cfg.kei, key, 'StartPeriod', cfg.oecd.start, ...
                      'RawFile', raw, 'Refresh', cfg.oecd.refresh);   % col 'DEU', QoQ %
            lvl = cumprod(1 + g{:,1}/100);
            tt  = array2timetable(lvl, 'RowTimes', g.Time, 'VariableNames', {'Germany'});
        case "fred"
            s  = load_fred(cfg, cfg.fred_german.(what));      % OECD MEI volume index
            tt = s;  tt.Properties.VariableNames = {'Germany'};
        case "orig_file"
            tt = load_orig_german(cfg, what);
        otherwise
            error('cfg.german_splice_src must be "kei", "fred" or "orig_file".');
    end
end

function tt = load_fred(cfg, id)
% Download a FRED series (public CSV endpoint, no API key) and return a
% quarterly timetable with one column named by the series id. Cached to
% Raw_Data/FRED/<id>.csv (refresh per cfg.oecd.refresh). FRED encodes missing
% values as '.'. Reused for the auxiliary FRED series (R&D, trade balance).
    raw = fullfile(cfg.rawdir, 'FRED', [char(id) '.csv']);
    d   = fileparts(raw); if ~exist(d,'dir'); mkdir(d); end
    url = "https://fred.stlouisfed.org/graph/fredgraph.csv?id=" + string(id);
    stale = exist(raw,'file') && dir(raw).bytes == 0;
    if cfg.oecd.refresh || ~exist(raw,'file') || stale
        % ROUTE 1: the official API, if a key is available. Preferred, and the
        % reason a key is worth having: fredgraph.csv (route 2) aggressively
        % throttles non-browser clients -- websave times out and curl returns
        % HTTP 000 -- while fred.stlouisfed.org itself answers 200. The API host
        % is unaffected. Same diagnosis and same route order as repair_usCPI.m.
        % load_fred has cfg, so the configured key file is read here and passed
        % down -- local_fred_key is a local function and sees no caller workspace.
        if isfield(cfg,'fred_key_file'); kf = cfg.fred_key_file; else; kf = ''; end
        key = local_fred_key(d, kf);
        got = false;
        if ~isempty(key)
            try
                api = sprintf(['https://api.stlouisfed.org/fred/series/observations?' ...
                               'series_id=%s&api_key=%s&file_type=json'], char(id), key);
                txt = webread(api, weboptions('Timeout',60,'ContentType','text'));
                j   = jsondecode(txt);
                assert(isfield(j,'observations'), 'unexpected API response');
                o   = j.observations;
                Tapi = table(datetime({o.date}','InputFormat','yyyy-MM-dd'), ...
                             str2double({o.value}'), ...
                             'VariableNames', {'observation_date', char(id)});
                writetable(Tapi, raw);      % cache in the same CSV shape as route 2
                fprintf('  FRED API %s (%d obs)\n', char(id), height(Tapi));
                got = true;
            catch ME
                fprintf('  FRED API failed for %s (%s); falling back to fredgraph.\n', ...
                        char(id), ME.message);
            end
        end
        if ~got
        fprintf('  FRED GET %s\n', url);
        try
            % FRED throttles non-browser clients; a browser User-Agent avoids
            % intermittent "Recv failure" timeouts on websave.
            websave(raw, url, weboptions('Timeout', 120, 'UserAgent', 'Mozilla/5.0'));
        catch ME
            if exist(raw,'file'); delete(raw); end
            rethrow(ME);
        end
        end
    else
        fprintf('  FRED (cached) %s\n', raw);
    end

    T  = readtable(raw, 'VariableNamingRule','preserve');
    dt = T{:,1};  if ~isdatetime(dt); dt = datetime(dt); end
    v  = T{:,2};  if ~isnumeric(v); v = str2double(string(v)); end   % '.' -> NaN
    keep = ~isnat(dt) & ~isnan(v);
    tt = sortrows(timetable(v(keep), 'RowTimes', dt(keep), ...
                            'VariableNames', {matlab.lang.makeValidName(char(id))}));
end

function panel = splice_german(panel, orig_ger, splice_dt)
% Backcast panel.Germany before splice_dt using the ORIGINAL German series'
% growth, scaled to the panel (EO) level at splice_dt -> a continuous level
% with EO growth from splice_dt and original growth before it. Quarters before
% the original series' own start stay NaN.
    eo = panel.Germany;
    kE = panel{panel.Time == splice_dt, 'Germany'};
    kO = orig_ger{orig_ger.Time == splice_dt, 1};
    assert(~isempty(kE) && ~isempty(kO) && ~isnan(kE) && ~isnan(kO), ...
        'splice_german: splice date %s missing in EO or original series.', ...
        datestr(splice_dt,'yyyyQQ'));
    k = kE / kO;                                   % scale original onto EO level
    pre = panel.Time < splice_dt;
    [tf, loc] = ismember(panel.Time(pre), orig_ger.Time);
    fill        = nan(sum(pre), 1);
    fill(tf)    = orig_ger{loc(tf), 1} * k;
    eo(pre)     = fill;
    panel.Germany = eo;
end

function dt = parse_qdate(s)
% Parse quarter strings in either order: 'Qn-YYYY' (e.g. 'Q4-1970') or
% 'YYYY-Qn' (e.g. '1961-Q2') -> quarter-START datetime.
    s   = string(s);
    p   = reshape(split(s, "-"), [], 2);
    a   = p(:,1);  b = p(:,2);
    isQa = startsWith(a, "Q");
    y = nan(size(a));  q = nan(size(a));
    y(isQa)  = str2double(b(isQa));   q(isQa)  = str2double(extractAfter(a(isQa), "Q"));
    y(~isQa) = str2double(a(~isQa));  q(~isQa) = str2double(extractAfter(b(~isQa), "Q"));
    dt = datetime(y, (q-1)*3 + 1, 1);
end

% ---- small transform helpers -------------------------------------------

function logagg = geo_aggregate_spliced(tt_levels, weights)
% Forward-anchored splice for a LEVEL-meaningful series whose country set GROWS
% mid-sample (eurodeposit rates: Italy from 1978Q3, Japan from 1978Q4). A plain
% renormalized LEVEL aggregate (geo_aggregate) steps at each entry because a new
% country's level is swapped into the weighted mean. Instead:
%   * on the contiguous block where EVERY country is present, return the true
%     level aggregate geo_aggregate (so the paper window 1978Q4+ is byte-identical
%     to the unspliced build — the differential there is unchanged);
%   * for earlier quarters, backcast via geo_aggregate_growth, whose increments
%     use only the countries present in BOTH adjacent quarters (the OVERLAP), so
%     an entering country contributes its GROWTH one quarter later, never a level
%     step. The two are level-linked by a single constant at the first all-present
%     quarter (in the all-present block they differ by exactly that constant,
%     since the full weights sum to 1 -> diff(growth) == diff(level)).
% When all countries are present throughout, this returns geo_aggregate exactly.
    L = geo_aggregate(tt_levels, weights);          % true renormalized level
    G = geo_aggregate_growth(tt_levels, weights);   % overlap-chained growth path
    full = all(~isnan(tt_levels.Variables), 2);     % quarters with every country
    t0 = find(full, 1);
    assert(~isempty(t0), 'geo_aggregate_spliced: no quarter has all countries present.');
    kappa = L.lnAgg(t0) - G.lnAgg(t0);              % link at first all-present quarter
    logagg = G;
    logagg.lnAgg = G.lnAgg + kappa;                 % == L on the all-present block
end

function tt = build_diff(homelog_tt, starlog_tt, name)
% Differential (home_log - star_log) on the common grid. Both inputs in LOGS,
% mirroring build_q. Take the home log at the call site with log_tt (the foreign
% aggregate is already in logs because geo_aggregate sums weighted logs).
%   homelog_tt : single-col timetable in LOGS (e.g. ln CPI, home country)
%   starlog_tt : single-col timetable in LOGS (the foreign aggregate)
% Synchronizes the two grids (intersection) before subtracting.
    h = homelog_tt; h.Properties.VariableNames = {'h'};
    s = starlog_tt; s.Properties.VariableNames = {'s'};
    m = synchronize(h, s, 'intersection');
    tt = array2timetable(m.h - m.s, 'RowTimes', m.Time, ...
                         'VariableNames', {name});
end

function tt = build_q(Sstar_log, Pstar_log, Phome_log, name)
% Real exchange rate q = ln(S*) + ln(P*) - ln(P_home), synchronizing the FX
% and price grids (intersection). All three inputs are single-col LOG timetables.
    a = Sstar_log; a.Properties.VariableNames = {'s'};
    b = Pstar_log; b.Properties.VariableNames = {'pstar'};
    c = Phome_log; c.Properties.VariableNames = {'phome'};
    m = synchronize(synchronize(a, b, 'intersection'), c, 'intersection');
    tt = array2timetable(m.s + m.pstar - m.phome, 'RowTimes', m.Time, ...
                         'VariableNames', {name});
end

function tt = log_tt(tt_in, name)
% Natural log of a single-column timetable.
    tt = array2timetable(log(tt_in{:,1}), 'RowTimes', tt_in.Time, ...
                         'VariableNames', {name});
end

function tt = log1p_tt(tt_in, name)
% ln(1 + x) of a single-column timetable (x a decimal rate).
    tt = array2timetable(log1p(tt_in{:,1}), 'RowTimes', tt_in.Time, ...
                         'VariableNames', {name});
end

function tt = rename(x, name)
% Wrap a timetable or a (time-aligned) numeric vector under a new var name.
    if istimetable(x)
        tt = x; tt.Properties.VariableNames = {name};
    else
        error('rename expects a timetable.');
    end
end

function out = synchronize_all(varargin)
% Inner-join several single-column timetables on common quarters.
    out = varargin{1};
    for k = 2:numel(varargin)
        out = synchronize(out, varargin{k}, 'intersection');
    end
end

function dt = parse_fernald_quarter(s)
% Convert Fernald 'YYYY:Qn' date strings to quarter-START datetimes.
%   '1978:Q4' -> datetime(1978,10,1)
    s     = string(s);
    parts = split(s, ":Q");                 % N-by-2: {year, quarter}
    yr    = str2double(parts(:,1));
    q     = str2double(parts(:,2));
    dt    = datetime(yr, (q-1)*3 + 1, 1);
end

function must_exist(p)
    if ~exist(p,'dir')
        error('Expected raw-data folder missing: %s', p);
    end
end

function key = local_fred_key(freddir, keyfile)
% Locate a FRED API key WITHOUT printing it, in this order: cfg.fred_key_file ->
% $FRED_API_KEY -> <FRED>/API_KEY.txt -> ~/.fred_api_key. keyfile must be an
% ARGUMENT: this is a local function and cannot see the caller's cfg.
    key = '';
    home = char(java.lang.System.getProperty('user.home'));
    cands = { rd(keyfile), ...
              getenv('FRED_API_KEY'), ...
              rd(fullfile(freddir,'API_KEY.txt')), ...
              rd(fullfile(freddir,'api_key.txt')), ...
              rd(fullfile(home,'.fred_api_key')) };
    for i = 1:numel(cands)
        k = strtrim(char(cands{i}));
        if ~isempty(k); key = k; return; end
    end
end

function t = rd(f)
    t = '';
    if exist(f,'file')==2
        fid = fopen(f,'r'); t = strtrim(fscanf(fid,'%c')); fclose(fid);
    end
end
