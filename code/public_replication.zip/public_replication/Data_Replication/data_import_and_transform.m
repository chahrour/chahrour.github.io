%% data_import_and_transform.m
% Build the data panels from the raw sources in Raw_Data.
%
% Run through build_all_vintages, which sets the *_override variables read below.
% Writes to Built_Data, each file name ending _f2026 (the Fernald vintage):
%   Y_benchmark   the quarterly panel Y and the per-country panels
%   AP_returns    excess equity and bond return differentials, bond yields
%   EQ_real_msci  real MSCI total-return equity indices
%
% Steps:
%   0. Configuration
%   1. Load raw series into quarterly timetables
%   2. Build the foreign (trade-weighted G6) aggregates
%   3. Transform: logs, differentials, TFP level from Fernald growth
%   4. Assemble Y and report its coverage
%   5. Append the trade-balance and Solow series and save Y
%   6. Asset returns
%   7. Real equity indices
%
% Conventions:
%   - S_t is USD per unit of foreign currency, so up is a USD depreciation.
%   - The interest differential is ln((1+i)/(1+i*)).
%   - The real exchange rate is q_t = ln(S) + ln(P*) - ln(P).
%   - Quarterly timetables carry quarter-start dates.

% The variables kept here are overrides set by the caller.
clearvars -except use_cache_override fred_key_file_override
clc;

%% 0. Configuration
cfg = struct();

% Paths
cfg.root    = fileparts(mfilename('fullpath'));      % .../Data_Replication
cfg.rawdir  = fullfile(cfg.root, 'Raw_Data');
cfg.outdir  = fullfile(cfg.root, 'Built_Data');
if ~exist(cfg.outdir, 'dir'); mkdir(cfg.outdir); end

% Benchmark window, as quarter-start dates. Y is saved in full; the window
% defines the view Y_bench, and its start is ryan_data's default start.
cfg.sample_start = datetime(1978,10,1);   % 1978Q4
cfg.sample_end   = datetime(2008,4,1);    % 2008Q2

% Foreign block: the other six G7 countries and their trade weights, the
% average of the 1978 and 2008 shares of world trade.
cfg.countries = {'Germany','Japan','France','UK','Italy','Canada'};
cfg.weights   = [0.2945, 0.1843, 0.1599, 0.1399, 0.1230, 0.0984];
assert(abs(sum(cfg.weights)-1) < 1e-6, 'Trade weights must sum to 1.');

% Fixed legacy-currency/euro conversion rates.
cfg.euro_fix = struct('Italy',1936.27, 'Germany',1.95583, ...
                      'France',6.55957);   % Canada/Japan/UK never euro

% OECD SDMX. Responses are cached under Raw_Data/OECD.
% ISO-3 REF_AREA codes. The US is included; it is not in cfg.countries.
cfg.iso = struct('US','USA', 'Canada','CAN', 'France','FRA', 'Germany','DEU', ...
                 'Italy','ITA', 'Japan','JPN', 'UK','GBR');

% Dataflow references, "AGENCY,DATAFLOW,VERSION".
cfg.oecd.eo         = "OECD.ECO.MAD,DSD_EO@DF_EO,1.5";   % Economic Outlook No.119
cfg.oecd.qna_natcur = "OECD.SDD.NAD,DSD_NAMAIN1@DF_QNA_EXPENDITURE_NATIO_CURR,1.1";
cfg.oecd.prices     = "OECD.SDD.TPS,DSD_PRICES@DF_PRICES_ALL,1.0";
% CPI under the COICOP 2018 classification, with the same key structure. A
% country's COICOP 1999 series stops when the country moves to the new one.
cfg.oecd.prices_c2018 = "OECD.SDD.TPS,DSD_PRICES_COICOP2018@DF_PRICES_C2018_ALL,1.0";
% Extend each country's CPI with the COICOP 2018 flow where the old flow has ended.
cfg.cpi_coicop2018_extend = true;

% Fill missing US CPI quarters from Raw_Data/FRED/us_cpi_repair.csv. BLS did not
% publish the October 2025 index, so 2025Q4 has no quarterly value; the filled
% value is constructed. Set false to leave the NaN.
cfg.us_cpi_repair = true;

% Consumption and investment: OECD Economic Outlook (EO). Each variable is a
% trio of measures: chain-linked volume (the one used), nominal value, and
% deflator, with volume = nominal / deflator. The reference year differs by country.
cfg.oecd.eo_vintage     = "EO No.119 (DSD_EO@DF_EO v1.5)";
cfg.oecd.eo_consumption = struct('volume','CPV', 'nominal','CP', 'deflator','PCP');
cfg.oecd.eo_investment  = struct('volume','ITV', 'nominal','IT', 'deflator','PIT'); % GFCF total
% GDP, same pattern.
cfg.oecd.eo_gdp         = struct('volume','GDPV','nominal','GDP','deflator','PGDP');
cfg.oecd.eo_key         = "%s.%s.Q";    % REF_AREA.MEASURE.FREQ

% CPI: OECD price database, national all-items index, not seasonally adjusted.
% Key order:
%   REF_AREA.FREQ.METHODOLOGY.MEASURE.UNIT_MEASURE.EXPENDITURE.ADJUSTMENT.TRANSFORMATION
cfg.oecd.cpi_key = "%s.Q.N.CPI.IX._T.N._Z";   % %s = '+'-joined REF_AREA(s)

% Price index used for the price differential and the real exchange rate:
%   "CPI"  OECD all-items CPI, not seasonally adjusted
%   "PCP"  EO private consumption deflator, seasonally adjusted; Germany from 1991
cfg.price = "CPI";

% Daily Datastream series (FX, deposit rates) to quarterly: "mean" is the period
% average, "lastvalue" the end-of-quarter value.
cfg.daily_agg = "mean";

% The same choice for the daily MSCI equity index.
cfg.equity_agg = "mean";

% Optionally set the French and Italian deposit rates to the German rate from
% cfg.euro_start on.
cfg.euro_rate_unify = false;
cfg.euro_start      = datetime(1999,1,1);

% Fernald TFP vintage. "2026" is data_quarterly_2026.06.04.xlsx, which ends
% 2026Q1. Raw_Data/Fernald/SOURCE.txt records where it came from.
cfg.fernald_vintage = "2026";


% Output path for a file stem and extension.
out = @(stem, ext) fullfile(cfg.outdir, [stem '_f2026' ext]);
% Germany before 1991. EO consumption, investment and GDP for Germany begin
% 1991Q1. With the splice on, earlier quarters are backcast with the growth of
% another source, scaled to the EO level at the splice date.
cfg.german_splice    = true;
cfg.german_splice_dt = datetime(1991,1,1);
% Backcast source:
%   "kei"        OECD Key Economic Indicators, reported quarterly growth
%   "fred"       OECD MEI volume index from FRED
%   "orig_file"  the archived spreadsheets in Raw_Data/OECD_orig
cfg.german_splice_src = "kei";
cfg.kei        = "OECD.SDD.STES,DSD_KEI@DF_KEI,4.0";   % Key Economic Indicators (MEI)
cfg.kei_german = struct('consumption','P3_S1M_Q', 'investment','P51G_Q', ...
                        'gdp','B1GQ_Q');
cfg.kei_key    = "%s.Q.%s.GR._T.Y.G1";  % REF_AREA.FREQ.MEASURE.UNIT.ACTIVITY.ADJ.TRANSFORM
cfg.fred_german = struct('consumption','NAEXKP02DEQ661S', ...  % FRED volume index
                         'investment', 'NAEXKP04DEQ661S');

cfg.oecd.start   = "1965-Q1";   % SDMX startPeriod
% Web sources (OECD, FRED). use_cache true reads the cached files in Raw_Data;
% false downloads again. A missing or empty cache file is always fetched.
if exist('use_cache_override','var') && ~isempty(use_cache_override)
    cfg.use_cache = logical(use_cache_override);
else
    cfg.use_cache = true;
end
if exist('fred_key_file_override','var') && ~isempty(fred_key_file_override)
    cfg.fred_key_file = fred_key_file_override;
end
cfg.oecd.refresh = ~cfg.use_cache;   % download only when not using the cache
% EO series include projections beyond the last historical quarter.

fprintf('Config loaded. Sample %s to %s (benchmark).\n', ...
        datestr(cfg.sample_start,'yyyyQQ'), datestr(cfg.sample_end,'yyyyQQ'));

%% 1. Load raw series
% Each loader returns a quarterly timetable. Country panels have one column per
% country in cfg.countries order, with the US first where it is included.

% Fernald utilization-adjusted US TFP growth, annualized percent (400 * dlog).
tfp_growth = load_fernald_tfp(cfg);

% Real consumption (EO volume CPV). cons_ref holds the nominal and deflator panels.
[C_all, cons_ref] = load_oecd_series(cfg, 'consumption', 'ALL');

% Real investment (EO volume ITV).
[I_all, inv_ref] = load_oecd_series(cfg, 'investment', 'ALL');

% Real GDP (EO volume GDPV).
[G_all, gdp_ref] = load_oecd_series(cfg, 'gdp', 'ALL');

% Backcast Germany before cfg.german_splice_dt.
if cfg.german_splice
    C_all = splice_german(C_all, load_german_backcast(cfg,'consumption'), cfg.german_splice_dt);
    I_all = splice_german(I_all, load_german_backcast(cfg,'investment'),  cfg.german_splice_dt);
    % GDP is backcast only if the chosen source has a key for it.
    srcf = lower(string(cfg.german_splice_src));
    hasg = (srcf == "kei"       && isfield(cfg.kei_german,'gdp'))  || ...
           (srcf == "fred"      && isfield(cfg.fred_german,'gdp')) || ...
            srcf == "orig_file";
    if hasg
        G_all = splice_german(G_all, load_german_backcast(cfg,'gdp'), cfg.german_splice_dt);
    else
        warning('data_import:noGermanGDPBackcast', ...
            ['German GDP is NaN before %s: EO GDPV for DEU starts 1991Q1 and no ' ...
             '''gdp'' backcast key is configured for cfg.german_splice_src="%s". ' ...
             'Germany covers 112 of 172 quarters on the 1976Q1-2018Q4 grid.'], ...
            string(cfg.german_splice_dt, 'yyyy-QQQ'), srcf);
    end
end
C_home = C_all(:, 1);  C_for = C_all(:, 2:end);   % US home; six foreign
I_home = I_all(:, 1);  I_for = I_all(:, 2:end);

% Foreign Solow residuals, built from OECD Economic Outlook No. 119 and aggregated
% like the other foreign series.
SOL_all = load_solow_rebuild('Countries', cfg.countries, 'Refresh', cfg.oecd.refresh, ...
    'RawFile', fullfile(cfg.rawdir, 'OECD', 'EO_solow_ALL.csv'));
SOLOW_G6 = geo_aggregate_growth(SOL_all, cfg.weights);

% CPI: national all-items index.
[P_all, cpi_ref] = load_oecd_series(cfg, 'cpi', 'ALL');
P_home = P_all(:, 1);          % US
P_for  = P_all(:, 2:end);      % six foreign countries, cfg.countries order

% Alternative price series: the EO private consumption deflator, same layout.
PCP_home = cons_ref.PCP(:, 1);
PCP_for  = cons_ref.PCP(:, 2:end);

% Interest rates: 3-month eurocurrency deposit rates, as the quarterly gross
% rate (1+i)^(1/4).
i_all  = load_datastream_eurorate(cfg);
i_home = i_all(:, 1);                       % US
i_for  = i_all(:, 2:end);                   % six foreign countries

% Nominal exchange rates, USD per foreign currency, one column per foreign country.
S_fx = load_datastream_fx(cfg);


%% 2. Foreign (trade-weighted) aggregates
% Trade-weighted geometric means of country logs, with the weights renormalized
% each quarter over the countries that have data.
%   geo_aggregate          on levels; for series present throughout (FX, CPI)
%   geo_aggregate_growth   on cumulated growth; for national-currency series
%                          where a country can enter mid-sample
%   geo_aggregate_spliced  the level aggregate where all countries are present,
%                          backcast with growth before that (deposit rates:
%                          Italy and Japan start during 1978)
S_star_log   = geo_aggregate(S_fx,           cfg.weights);   % ln(S*_t)
C_star_log   = geo_aggregate_growth(C_for,   cfg.weights);   % ln(C*_t)
I_star_log   = geo_aggregate_growth(I_for,   cfg.weights);   % ln(I*_t)
P_star_log   = geo_aggregate(P_for,          cfg.weights);   % ln(CPI*_t)
PCP_star_log = geo_aggregate_growth(PCP_for, cfg.weights);   % ln(PCP*_t)
i_star_log   = geo_aggregate_spliced(i_for,  cfg.weights);   % sum_c w_c ln(1+i_c)^(1/4)

%% 3. Transformations
% TFP log level. Fernald growth is annualized percent, so the quarterly log
% change is g/400. The first observation has no growth value and is set to 0;
% the level is cumulated from there.
dlog_tfp = tfp_growth{:,1} / 400;
dlog_tfp(1) = 0;
log_tfp  = cumsum(dlog_tfp);
TFP_log  = array2timetable(log_tfp, 'RowTimes', tfp_growth.Time, ...
                           'VariableNames', {'lnTFP'});

% Logs of home consumption and investment.
lnC   = log_tt(C_home, 'lnC');
lnI   = log_tt(I_home, 'lnI');

% Interest-rate differential ln((1+i)/(1+i*)).
int_diff = build_diff(log_tt(i_home, 'lni'), i_star_log, 'int_diff');

% Price differential ln(P/P*) for both indices; cfg.price picks the one used.
cpi_diff = build_diff(log_tt(P_home,  'lnP'), P_star_log,   'price_diff');   % ln(CPI/CPI*)
pcp_diff = build_diff(log_tt(PCP_home,'lnP'), PCP_star_log, 'price_diff');   % ln(PCP/PCP*)
switch upper(string(cfg.price))
    case "CPI"; price_diff = cpi_diff;  Phome_log = log_tt(P_home,  'lnP'); Pstar = P_star_log;
    case "PCP"; price_diff = pcp_diff;  Phome_log = log_tt(PCP_home,'lnP'); Pstar = PCP_star_log;
    otherwise;  error('cfg.price must be "CPI" or "PCP".');
end

% Real exchange rate q_t = ln(S) + ln(P*) - ln(P), with the same price index.
q_real = build_q(S_star_log, Pstar, Phome_log, 'q_real');

%% 4. Assemble Y
% Columns: [TFP, C, I, NER, IDIFF, C*, CPIDIFF, I*], then q_real. The series are
% joined on the quarters they all cover.
Y = synchronize_all( ...
        rename(TFP_log,    'TFP'),     ...  % 1 home TFP
        rename(lnC,        'C'),       ...  % 2 home consumption
        rename(lnI,        'I'),       ...  % 3 home investment
        rename(S_star_log, 'NER'),     ...  % 4 ln S*
        rename(int_diff,   'IDIFF'),   ...  % 5 ln((1+i)/(1+i*))
        rename(C_star_log, 'Cstar'),   ...  % 6 foreign consumption
        rename(price_diff, 'CPIDIFF'), ...  % 7 ln(P/P*)
        rename(I_star_log, 'Istar'),   ...  % 8 foreign investment
        rename(q_real,     'q_real') );        % real exchange rate

% Y is the full history. Y_bench is the view on the benchmark window.
Y_bench = Y(isbetween(Y.Time, cfg.sample_start, cfg.sample_end), :);

fprintf('Y_t assembled: FULL %s..%s (%d obs) | window %s..%s (%d obs) x 8 vars.\n', ...
        datestr(Y.Time(1),'yyyyQQ'),       datestr(Y.Time(end),'yyyyQQ'),       height(Y), ...
        datestr(Y_bench.Time(1),'yyyyQQ'), datestr(Y_bench.Time(end),'yyyyQQ'), height(Y_bench));

% Report which input sets the start and which sets the end of Y.
inputs = { 'TFP',     TFP_log;     'C',       lnC;         'I',     lnI; ...
           'NER',     S_star_log;  'IDIFF',   int_diff;    'Cstar', C_star_log; ...
           'CPIDIFF', price_diff;  'Istar',   I_star_log };
spans = cellfun(@(t) [t.Time(find(~isnan(t{:,1}),1)), t.Time(find(~isnan(t{:,1}),1,'last'))], ...
                inputs(:,2), 'UniformOutput', false);
spans = vertcat(spans{:});
[~, iStart] = max(spans(:,1));            % latest start
[~, iEnd]   = min(spans(:,2));            % earliest end
[~, ordE]   = sort(spans(:,2));
fprintf(['  binding: START by %-7s (%s)   END by %-7s (%s)' ...
         '   [next-shortest end: %s %s]\n'], ...
        inputs{iStart,1}, datestr(spans(iStart,1),'yyyyQQ'), ...
        inputs{iEnd,1},   datestr(spans(iEnd,2),  'yyyyQQ'), ...
        inputs{ordE(2),1}, datestr(spans(ordE(2),2),'yyyyQQ'));
% Report NaN in the eight VAR columns, quarter by quarter. An interior hole (data
% on both sides) cannot be removed by trimming the sample.
miss = ismissing(Y{:, 1:8});
if any(miss, 'all')
    rows = find(any(miss, 2));
    fprintf('\n⚠ NaN audit: %d NaN cell(s) in the VAR block of the full panel:\n', sum(miss,'all'));
    for i = rows(:)'
        vars = miss(i,:);
        % Interior: the variable has data both before and after this quarter.
        interior = any(any(~miss(1:i-1, vars), 1) & any(~miss(i+1:end, vars), 1));
        if interior; flag = '  <-- INTERIOR hole (cannot be trimmed away)'; else; flag = ''; end
        fprintf('   %s : %-20s%s\n', datestr(Y.Time(i),'yyyyQQ'), ...
                strjoin(Y.Properties.VariableNames(vars), ', '), flag);
    end
    fprintf(['   -> Estimation windows must avoid these quarters. An INTERIOR hole ' ...
             'cannot be trimmed away.\n\n']);
    warning('Full panel has a NaN in a VAR variable — see the NaN audit above.');
end

%% 5. Trade balance and Solow series; save Y
% Two trade-balance measures are appended to Y, as fractions of GDP:
%   TB_G6   US-G6 goods trade balance / nominal GDP  (USDATA.xlsx columns 18/19)
%   NX_GDP  total US net exports / GDP               (FRED A019RE1Q156NBEA)
% They are added with addvars and are NaN outside their coverage, so they do not
% shorten Y.
TB_G6  = nan(height(Y),1);
NX_GDP = nan(height(Y),1);

ud = fullfile(cfg.rawdir,'CCDGV','USDATA.xlsx');
if ~isfile(ud)
    warning('dit:noUSDATA','USDATA.xlsx not found; TB_G6 left NaN.');
else
    Tu = readtable(ud, 'VariableNamingRule', 'preserve');
    Au = table2array(Tu(:,2:end));
    g6 = Au(:,18)./Au(:,19)./1e6;                       % $ / ($m * 1e6) -> fraction
    % Dates are read from column 1 of the sheet.
    tg = Tu{:,1};
    if ~isdatetime(tg); tg = datetime(tg, 'ConvertFrom', 'excel'); end
    tg = dateshift(tg(:), 'start', 'quarter');
    % The grid is checked against one built with calquarters; differencing
    % datetimes gives durations, and quarters differ in length.
    assert(isequal(tg, tg(1) + calquarters(0:numel(tg)-1)'), 'dit:usdataGrid', ...
        'USDATA.xlsx column 1 is not a contiguous quarterly grid (%s .. %s, %d rows).', ...
        char(string(tg(1),'yyyy-QQQ')), char(string(tg(end),'yyyy-QQQ')), numel(tg));
    [tf,loc] = ismember(Y.Time, tg);
    TB_G6(tf) = g6(loc(tf));
    fprintf('  TB_G6  from %s: %d of %d quarters matched\n', ud, sum(tf & ~isnan(TB_G6)), height(Y));
end

try
    Fb = load_fred(cfg, 'A019RE1Q156NBEA');             % percent of GDP
    [tf,loc] = ismember(Y.Time, Fb.Properties.RowTimes);
    v = Fb{:,1};
    NX_GDP(tf) = v(loc(tf)) / 100;                      % percent -> fraction
    fprintf('  NX_GDP from FRED A019RE1Q156NBEA: %d of %d quarters matched\n', ...
            sum(tf & ~isnan(NX_GDP)), height(Y));
catch ME
    warning('dit:noFredTB','FRED trade-balance fetch failed (%s); NX_GDP left NaN.', ME.message);
end

Y = addvars(Y, TB_G6, NX_GDP, 'NewVariableNames', {'TB_G6','NX_GDP'});
% Foreign Solow aggregate, aligned by date; NaN outside its coverage.
sg = NaN(height(Y),1);
[sg_tf, sg_loc] = ismember([year(Y.Time) quarter(Y.Time)], ...
                           [year(SOLOW_G6.Time) quarter(SOLOW_G6.Time)], 'rows');
sg(sg_tf) = SOLOW_G6.lnAgg(sg_loc(sg_tf));
Y = addvars(Y, sg, 'NewVariableNames', {'SOLOW_G6'});

% Save Y with the per-country panels. Panels that include the US have it first.
%   S_fx     FX levels, six foreign countries
%   P_all    CPI
%   C_all, I_all, G_all   real consumption, investment and GDP
%   i_all    gross quarterly interest rates (1+i)^(1/4)
%   SOL_all  foreign Solow residuals, six countries
save(out('Y_benchmark','.mat'), 'Y', 'Y_bench', 'cfg', ...
     'S_fx', 'P_all', 'C_all', 'I_all', 'i_all', 'G_all', 'SOL_all');
writetimetable(Y, out('Y_benchmark','.csv'));
fprintf('Saved full Y (%d obs, %d vars) + window + per-country panels (S_fx %dx%d, P_all %dx%d) to %s\n', ...
        height(Y), width(Y)-1, height(S_fx), width(S_fx), height(P_all), width(P_all), cfg.outdir);

%% 6. Asset returns

% ASSET_PRICE_data and its helpers are in CCDGV_Replication.
ccdgv_dir = fullfile(cfg.root, '..', 'CCDGV_Replication');
if exist(ccdgv_dir, 'dir'); addpath(genpath(ccdgv_dir)); end

% Run ASSET_PRICE_data in a workspace of its own and collect its series.
[excess_equity_return_differential, excess_bond_return_differential, ...
 bond_yield_gfd_us, bond_yield_gfd_g6, ap_dates] = asset_price_series(ccdgv_dir, ...
                                                          cfg.rawdir, i_all);

% Save the asset returns as a dated panel. 'RowTimes' is passed by name so the
% time dimension is called Time.
AP_out = timetable(excess_equity_return_differential, excess_bond_return_differential, ...
    bond_yield_gfd_us, bond_yield_gfd_g6, ...
    'RowTimes', ap_dates, ...
    'VariableNames', {'exret_eq','exret_bond','by_us','by_g6'});
save(out('AP_returns','.mat'), 'AP_out', 'cfg');
writetimetable(AP_out, out('AP_returns','.csv'));
fprintf('Saved asset-return aux (%d obs, %s..%s) to %s\n', height(AP_out), ...
        string(ap_dates(1),'yyyy-QQQ'), string(ap_dates(end),'yyyy-QQQ'), cfg.outdir);

%% 7. Real MSCI equity
% MSCI total-return index in local currency, quarterly, deflated by each
% country's CPI. The six foreign countries are aggregated with geo_aggregate.
EQ_tri = load_datastream_msci(cfg);          % quarterly nominal index, [US, cfg.countries]

% Deflate each country by its own CPI, on the MSCI quarterly grid.
P_on_eq      = retime(P_all, EQ_tri.Time, 'fillwithmissing');
EQ_real      = EQ_tri;
EQ_real{:,:} = EQ_tri{:,:} ./ P_on_eq{:,:};  % real = nominal / CPI

% US real log level and the G6 aggregate.
lnUS = log(EQ_real{:,1});
lnG6 = geo_aggregate(EQ_real(:,2:end), cfg.weights).lnAgg;

% Levels and logs. Quarters before coverage are dropped.
EQ_lvl = timetable(EQ_real.Time, exp(lnUS), exp(lnG6), lnUS, lnG6, ...
            'VariableNames', {'EQreal_US','EQreal_G6','lnEQreal_US','lnEQreal_G6'});
EQ_lvl = rmmissing(EQ_lvl);

% Quarterly real log returns. The first quarter is NaN.
rUS = [NaN; diff(EQ_lvl.lnEQreal_US)];
rG6 = [NaN; diff(EQ_lvl.lnEQreal_G6)];
EQ_out = addvars(EQ_lvl, rUS, rG6, 'NewVariableNames', {'rEQreal_US','rEQreal_G6'});

save(out('EQ_real_msci','.mat'), 'EQ_out', 'cfg');
writetimetable(EQ_out, out('EQ_real_msci','.csv'));
fprintf('Saved MSCI real-equity aux (%d obs, %s..%s; EOP returns) to %s\n', ...
        height(EQ_out), datestr(EQ_out.Time(1),'yyyyQQ'), ...
        datestr(EQ_out.Time(end),'yyyyQQ'), cfg.outdir);

%% Local functions: loaders and transform helpers

function [exret_eq, exret_bond, by_us, by_g6, ap_dates] = asset_price_series(ccdgv_dir, rawroot, ap_rates)
% Run ASSET_PRICE_data in its own workspace, from inside CCDGV_Replication, and
% return its series. The script reads ap_raw (its raw inputs) and ap_rates (the
% rate panel i_all) from this workspace.
ap_raw = load_asset_raw(rawroot);
old = cd(ccdgv_dir);
back = onCleanup(@() cd(old));
ASSET_PRICE_data;
exret_eq   = excess_equity_return_differential;
exret_bond = excess_bond_return_differential;
by_us      = bond_yield_gfd_us;
by_g6      = bond_yield_gfd_g6;
ap_dates   = idiff_t_pa;        % the quarters it kept
end

function tt = load_datastream_fx(cfg)
% Quarterly FX levels (USD per foreign currency), one column per cfg.countries.
    daily = read_fx(cfg);

    % Daily to quarterly. The period average omits NaN: the LSEG file has
    % scattered unquoted days, which would otherwise void whole quarters.
    if cfg.daily_agg == "mean"
        tt = retime(daily, 'quarterly', @(x) mean(x,'omitnan'));
    else
        tt = daily_to_quarterly(daily, cfg.daily_agg);
    end

    % Drop a trailing partial quarter.
    qend = dateshift(daily.Time(end), 'end', 'quarter');
    if daily.Time(end) < qend
        tt(tt.Time >= dateshift(daily.Time(end),'start','quarter'), :) = [];
    end
end

function daily = read_fx(cfg)
% LSEG _exchangerates.xlsx, sheet 'Sorted': row 1 holds RIC headers, rows 2+
% [date, CAD FRF DEM ITL JPY GBP EUR]. Steps:
%   1. Invert the quotes that are foreign currency per USD (all but GBP and EUR).
%   2. From 2002-01-02, after the legacy quotes stop, chain FRF, DEM and ITL
%      forward on the euro's daily return: X_t = X_{t-1} * EUR_t / EUR_{t-1}.
%   3. Drop the EUR column.
    must_exist(fullfile(cfg.rawdir,'Datastream_new'));
    f = fullfile(cfg.rawdir,'Datastream_new','_exchangerates.xlsx');
    if ~exist(f,'file'); error('FX file not found: %s', f); end

    T   = readtable(f,'Sheet','Sorted','Range','A1','ReadVariableNames',true, ...
                    'VariableNamingRule','preserve');
    dt  = T{:,1};
    if ~isdatetime(dt); dt = datetime(dt); end
    hdr = T.Properties.VariableNames(2:end);
    ccy = cellfun(@(s) char(extractBefore(string(s),'=')), hdr, 'UniformOutput', false);

    % Text columns to numbers; blank cells become NaN.
    V = nan(height(T), numel(ccy));
    for j = 1:numel(ccy)
        c = T{:,j+1};
        if isnumeric(c); V(:,j) = c; else; V(:,j) = str2double(string(c)); end
    end

    % Step 1: USD per foreign currency.
    inv = ~ismember(ccy, {'GBP','EUR'});
    V(:,inv) = 1 ./ V(:,inv);

    % Step 2: chain FRF/DEM/ITL on the euro from 2002-01-02.
    iEUR  = strcmp(ccy,'EUR');
    chain = ismember(ccy, {'FRF','DEM','ITL'});
    i0    = find(dt == datetime(2002,1,2));
    assert(isscalar(i0), 'read_fx: chain start 2002-01-02 not found in ''Sorted''.');
    eur = V(:,iEUR);
    for i = i0:numel(dt)
        V(i,chain) = V(i-1,chain) * eur(i) / eur(i-1);   % NaN propagates
    end

    % Step 3: drop EUR and order as cfg.countries [GER,JPN,FRA,UK,ITA,CAN].
    sel   = [find(strcmp(ccy,'DEM')), find(strcmp(ccy,'JPY')), find(strcmp(ccy,'FRF')), ...
             find(strcmp(ccy,'GBP')), find(strcmp(ccy,'ITL')), find(strcmp(ccy,'CAD'))];
    daily = array2timetable(V(:,sel), 'RowTimes', dt, 'VariableNames', cfg.countries);
end

function tt = load_datastream_msci(cfg)
% Quarterly MSCI total-return index levels in local currency, US first then
% cfg.countries. Sheet 'Total Return Indexes': rows 1-3 are names, vendor codes
% and currencies; rows 4+ are [date, Canada, France, Germany, Italy, Japan, UK, USA].
    daily = read_daily_vendor(cfg, 'msci');

    % Reorder the file columns to [US, cfg.countries].
    sel   = [7 3 5 2 6 4 1];
    daily = daily(:, sel);
    daily.Properties.VariableNames = [{'US'}, cfg.countries];

    % Daily to quarterly.
    tt = daily_to_quarterly(daily, cfg.equity_agg);
end

function [f, sheet, skiprows] = datastream_file(cfg, which)
% Path, sheet and header-row count of a raw daily file in Raw_Data/Datastream_new.
% which is 'ecrates' or 'msci'.
    must_exist(fullfile(cfg.rawdir, 'Datastream_new'));
    switch which
        case 'ecrates'
            f = '_interestrates.xlsx';  sheet = 'Replication';
            skiprows = 1;                              % 1 header row
        case 'msci'
            f = 'DATASTREAM_MSCI_DAILY_UPDATED.xlsx';
            sheet = 'Total Return Indexes';  skiprows = 3;   % name, code, currency
    end
    f = fullfile(cfg.rawdir, 'Datastream_new', f);
    if ~exist(f,'file'); error('%s file not found: %s', which, f); end
end

function daily = read_daily_vendor(cfg, which)
% Read one raw daily file into a timetable of its 7 series, in file column order
% [CAN,FRA,GER,ITA,JPN,GBR,US].
    [f, sheet, skiprows] = datastream_file(cfg, which);
    T  = readtable(f, 'Sheet', sheet, 'Range', sprintf('A%d', skiprows+1), ...
                   'ReadVariableNames', false);
    dt = T{:,1};
    if ~isdatetime(dt); dt = datetime(dt); end
    V  = T{:,2:8};
    if ~isnumeric(V)
        error('%s: columns 2-8 did not read as numeric.', which);
    end
    daily = array2timetable(V, 'RowTimes', dt, ...
                'VariableNames', {'CAN','FRA','GER','ITA','JPN','GBR','US'});
end

function q = daily_to_quarterly(daily, method)
% Daily timetable to quarterly. 'mean' is a NaN-propagating period average;
% 'lastvalue' is the end-of-quarter value.
    switch char(method)
        case 'mean';  q = retime(daily, 'quarterly', @mean);   % @mean propagates NaN
        otherwise;    q = retime(daily, 'quarterly', char(method));
    end
end

function i_all = load_datastream_eurorate(cfg)
% Quarterly gross deposit rates (1+i)^(1/4), US first then cfg.countries.
%   1. read the daily annualized percent rates
%   2. aggregate to quarterly with cfg.daily_agg
%   3. convert to the quarterly gross rate (1 + r/100)^(1/4)
    daily = read_daily_vendor(cfg, 'ecrates');

    % Optionally give France and Italy the German rate in the euro era.
    if cfg.euro_rate_unify
        e = daily.Time >= cfg.euro_start;
        daily.FRA(e) = daily.GER(e);
        daily.ITA(e) = daily.GER(e);
    end

    % Daily to quarterly. retime's 'mean' omits NaN, so a country's first, partial
    % quarter is an average over the days that exist (Italy 1978Q2, Japan 1978Q3).
    q = retime(daily, 'quarterly', char(cfg.daily_agg));

    G = (1 + q{:,:}/100).^(1/4);                   % annualized percent -> quarterly gross
    % Reorder file columns [CAN,FRA,GER,ITA,JPN,GBR,US] to [US,GER,JPN,FRA,GBR,ITA,CAN].
    idx   = [7 3 5 2 6 4 1];
    names = [{'US'}, cfg.countries];
    i_all = array2timetable(G(:, idx), 'RowTimes', q.Time, 'VariableNames', names);
end

function raw = load_asset_raw(rawroot)
% Read the raw inputs of ASSET_PRICE_data:
%   Raw_Data/CCDGV/nyse_real_lev                    real NYSE level, column 2
%   Raw_Data/Datastream_new/DATASTREAM_MSCI_DAILY_UPDATED.xlsx
%                                 sheets 'Price Indexes' and 'Total Return Indexes'
    tmp = importdata(fullfile(rawroot, 'CCDGV', 'nyse_real_lev'));
    raw.cj_equity = tmp.data(:,2);
    f = fullfile(rawroot, 'Datastream_new', 'DATASTREAM_MSCI_DAILY_UPDATED.xlsx');
    assert(isfile(f), 'load_asset_raw:noMSCI', '%s not found.', f);
    P = readtable(f, 'Sheet', 'Price Indexes',        'VariableNamingRule', 'preserve');
    T = readtable(f, 'Sheet', 'Total Return Indexes', 'VariableNamingRule', 'preserve');
    raw.date_d_ec          = table2array(P(1:end,1));
    raw.equity_price_daily = table2array(P(1:end,2:end));
    % ASSET_PRICE_data indexes both arrays by the Price sheet's dates, so the
    % total-return rows go on those dates; a date that sheet lacks is NaN.
    [tf, loc] = ismember(raw.date_d_ec, table2array(T(1:end,1)));
    raw.equity_tri_daily        = NaN(height(P), width(T)-1);
    raw.equity_tri_daily(tf,:)  = table2array(T(loc(tf),2:end));
end
function tt = load_fernald_tfp(cfg)
% Fernald utilization-adjusted TFP growth, 'dtfp_util', as a single-column
% quarterly timetable in the file's units: annualized percent (400 * dlog).
% Sheet 'quarterly': row 1 is a note, row 2 the headers, rows 3+ the data, with
% dates as 'YYYY:Qn'.
    must_exist(fullfile(cfg.rawdir,'Fernald'));
    f = fullfile(cfg.rawdir,'Fernald','data_quarterly_2026.06.04.xlsx');
    if ~exist(f,'file'); error('Fernald file not found: %s', f); end

    % Start at A2 so that row 2 supplies the variable names.
    T = readtable(f, 'Sheet','quarterly', 'Range','A2', ...
                  'VariableNamingRule','preserve');

    % Keep only rows dated YYYY:Qn; this drops the summary rows below the data.
    dstr = string(T.date);
    dstr(ismissing(dstr)) = "";
    keep = ~cellfun('isempty', regexp(dstr, '^\d{4}:Q[1-4]$', 'once'));
    T    = T(keep, :);

    g  = T.dtfp_util;                       % annualized percent
    dt = parse_fernald_quarter(T.date);     % 'YYYY:Qn' -> quarter-start date

    tt = timetable(g, 'RowTimes', dt, 'VariableNames', {'dtfp_util'});
    tt = sortrows(tt);                      % ascending time
end

function [tt, ref] = load_oecd_series(cfg, what, which)
% An OECD series as a quarterly timetable of levels, one column per country.
%   what   'consumption' | 'investment' | 'gdp' | 'cpi'
%   which  'US' | 'G7' (cfg.countries) | 'ALL' (US first, then cfg.countries)
%   tt     the series; for the EO variables, the chain-linked volume
%   ref    companion data: for the EO variables the nominal and deflator panels
%          under their measure codes (e.g. ref.CP, ref.PCP), plus a note

    % Countries to fetch, in output order.
    switch which
        case 'US';  names = {'US'};
        case 'G7';  names = cfg.countries;
        case 'ALL'; names = [{'US'}, cfg.countries];
        otherwise;  error('load_oecd_series: which must be ''US'', ''G7'' or ''ALL''.');
    end

    ref = struct();
    switch what
        case 'consumption'
            % EO private consumption: CPV/CP/PCP.
            [tt, ref] = load_eo_trio(cfg, names, which, cfg.oecd.eo_consumption, 'consumption');
        case 'investment'
            % EO gross fixed capital formation: ITV/IT/PIT.
            [tt, ref] = load_eo_trio(cfg, names, which, cfg.oecd.eo_investment, 'investment');
        case 'gdp'
            [tt, ref] = load_eo_trio(cfg, names, which, cfg.oecd.eo_gdp, 'gdp');
        case 'cpi'
            % OECD price database: national all-items CPI index, in one request.
            isos  = cellfun(@(n) cfg.iso.(n), names, 'UniformOutput', false);
            key   = sprintf(cfg.oecd.cpi_key, strjoin(isos,'+'));
            raw   = fullfile(cfg.rawdir, 'OECD', sprintf('CPI_%s.csv', which));
            combo = fetch_oecd_sdmx(cfg.oecd.prices, key, ...
                        'StartPeriod', cfg.oecd.start, ...
                        'RawFile',     raw, ...
                        'Refresh',     cfg.oecd.refresh, ...
                        'ColumnDims',  ["REF_AREA","MEASURE"]);
            tt = eo_panel(combo, names, isos, 'CPI');       % columns "ISO_CPI"
            ref.note = sprintf(['OECD CPI DB (%s) | national all-items CPI ' ...
                'index (IX), NOT seasonally adjusted, base 2015.'], cfg.oecd.prices);
            if cfg.cpi_coicop2018_extend
                [tt, ref.c2018] = extend_cpi_coicop2018(cfg, tt, names, isos, which);
            end
            if cfg.us_cpi_repair
                [tt, ref.us_repair] = apply_us_cpi_repair(cfg, tt);
            end
        otherwise
            error('load_oecd_series: unknown series ''%s''.', what);
    end
end

function [tt, info] = extend_cpi_coicop2018(cfg, tt, names, isos, which)
% Extend the COICOP 1999 CPI panel with the COICOP 2018 dataflow, per country.
% A country's old series stops when it moves to the new classification. The new
% flow is chained onto the old one at its last observation, using the new flow's
% growth rates, CPI_t = CPI_{t-1} * (C18_t / C18_{t-1}), so a difference in base
% cannot enter as a step. Countries absent from COICOP 2018 are unchanged.
    key = sprintf(cfg.oecd.cpi_key, strjoin(isos,'+'));
    raw = fullfile(cfg.rawdir, 'OECD', sprintf('CPI_C2018_%s.csv', which));
    try
        combo = fetch_oecd_sdmx(cfg.oecd.prices_c2018, key, ...
                    'StartPeriod', cfg.oecd.start, ...
                    'RawFile',     raw, ...
                    'Refresh',     cfg.oecd.refresh, ...
                    'ColumnDims',  ["REF_AREA","MEASURE"]);
    catch ME
        warning('CPI COICOP-2018 extension skipped (%s): %s', cfg.oecd.prices_c2018, ME.message);
        info = struct('extended', {{}}, 'note', 'fetch failed');
        return
    end
    % A country missing from COICOP 2018 has not migrated yet; mute the warning.
    ws = warning('off','ccdgv:eo_panel:missingColumn');
    new = eo_panel(combo, names, isos, 'CPI');
    warning(ws);
    absent = names(all(isnan(new.Variables),1));
    if ~isempty(absent)
        fprintf('  CPI COICOP 2018: not yet migrated (left on COICOP 1999): %s\n', ...
                strjoin(absent, ', '));
    end

    % Put both panels on the union of their time grids.
    tt  = synchronize(tt, new, 'union', 'fillwithmissing');
    old = tt(:, 1:numel(names));   nw = tt(:, numel(names)+1:end);
    T   = old.Time;
    X   = old.Variables;   N = nw.Variables;

    extended = {};
    for k = 1:numel(names)
        x = X(:,k); n = N(:,k);
        iold = find(~isnan(x), 1, 'last');
        if isempty(iold) || all(isnan(n)); continue; end
        % Chain forward from the last old observation on the new flow's growth.
        for i = iold+1:numel(T)
            if isnan(n(i)) || isnan(n(i-1)); continue; end
            x(i) = x(i-1) * n(i) / n(i-1);
        end
        if any(~isnan(x(iold+1:end)))
            extended{end+1} = sprintf('%s(%s->%s)', names{k}, ...
                datestr(T(iold),'yyyyQQ'), datestr(T(find(~isnan(x),1,'last')),'yyyyQQ')); %#ok<AGROW>
        end
        X(:,k) = x;
    end
    tt = array2timetable(X, 'RowTimes', T, 'VariableNames', names);
    tt = tt(any(~isnan(X),2), :);        % drop all-NaN rows created by the union

    info = struct('extended', {extended}, 'note', ...
        sprintf('COICOP-2018 (%s) chained onto COICOP-1999 at each country''s last obs.', ...
                cfg.oecd.prices_c2018));
    if ~isempty(extended)
        fprintf('  CPI extended via COICOP 2018: %s\n', strjoin(extended, ', '));
    end
end

function [tt, info] = apply_us_cpi_repair(cfg, tt)
% Fill missing US CPI quarters from Raw_Data/FRED/us_cpi_repair.csv. A published
% value is never overwritten. Prints the growth on either side of each filled quarter.
    info = struct('applied', {{}}, 'note', '');
    if ~ismember('US', tt.Properties.VariableNames); return; end

    % The repair file is a tracked one-row input.
    f = fullfile(cfg.rawdir, 'FRED', 'us_cpi_repair.csv');
    if ~exist(f,'file')
        error('ccdgv:usCpiRepairMissing', ...
              ['%s is missing. US CPI has no 2025Q4 value, the gap is interior, ' ...
               'and the country specifications assert against interior gaps -- ' ...
               'so the run would fail later with a less obvious message. Restore ' ...
               'the file or set cfg.us_cpi_repair = false and accept that the ' ...
               'country runs will not complete.'], f);
    end
    rep = readtable(f);
    rep.Quarter = datetime(rep.Quarter);

    us = tt.US;
    for i = 1:height(rep)
        q  = rep.Quarter(i);
        ix = find(tt.Time == q, 1);
        if isempty(ix)                        % quarter not on the grid
            continue
        elseif ~isnan(us(ix))                 % already published: never overwrite
            fprintf(['  US CPI repair: %s already has a published value ' ...
                     '(%.5f) — repair NOT applied.\n'], datestr(q,'yyyyQQ'), us(ix));
            continue
        end
        us(ix) = rep.CPI_repaired(i);
        info.applied{end+1} = datestr(q,'yyyyQQ');                     %#ok<AGROW>
        % Growth into and out of the filled quarter, against the s.d. of
        % quarterly US CPI growth.
        g  = diff(log(us));
        sd = std(g, 'omitnan');
        fprintf(['  US CPI repair: %s filled with %.5f  ' ...
                 '(growth in %+.5f, out %+.5f; s.d. %.5f)\n'], ...
                datestr(q,'yyyyQQ'), us(ix), g(ix-1), g(ix), sd);
        if max(abs([g(ix-1) g(ix)])) > 4*sd
            warning('US CPI repair at %s produced a >4 s.d. growth move — inspect.', ...
                    datestr(q,'yyyyQQ'));
        end
    end
    tt.US = us;
    info.note = 'from Raw_Data/FRED/us_cpi_repair.csv';
end

function [tt, ref] = load_eo_trio(cfg, names, which, m, tag)
% Fetch an EO {volume, nominal, deflator} trio for all countries in one request.
% Returns the volume panel; ref holds the nominal and deflator panels under
% their measure codes.
%   m    struct with fields .volume .nominal .deflator (EO measure codes)
%   tag  cache file tag: Raw_Data/OECD/EO_<tag>_<which>.csv
    measures = {m.volume, m.nominal, m.deflator};
    isos     = cellfun(@(n) cfg.iso.(n), names, 'UniformOutput', false);
    key      = sprintf(cfg.oecd.eo_key, strjoin(isos,'+'), strjoin(measures,'+'));
    raw      = fullfile(cfg.rawdir, 'OECD', sprintf('EO_%s_%s.csv', tag, which));
    combo = fetch_oecd_sdmx(cfg.oecd.eo, key, ...
                'StartPeriod', cfg.oecd.start, ...
                'RawFile',     raw, ...
                'Refresh',     cfg.oecd.refresh, ...
                'ColumnDims',  ["REF_AREA","MEASURE"]);
    tt               = eo_panel(combo, names, isos, m.volume);   % volume
    ref.(m.nominal)  = eo_panel(combo, names, isos, m.nominal);  % nominal value
    ref.(m.deflator) = eo_panel(combo, names, isos, m.deflator); % deflator
    ref.note = sprintf(['%s | %s=volume (chain-linked, real); %s=nominal; ' ...
        '%s=deflator (country-specific ref year). %s = %s ./ %s.'], ...
        cfg.oecd.eo_vintage, m.volume, m.nominal, m.deflator, ...
        m.volume, m.nominal, m.deflator);
end

function tt = eo_panel(combo, names, isos, measure)
% One measure from a combined timetable (columns 'ISO_MEASURE') as a country
% panel with columns named by names. A missing column becomes NaN.
    vn = string(combo.Properties.VariableNames);
    X  = nan(height(combo), numel(names));
    for k = 1:numel(names)
        cn = string(isos{k}) + "_" + string(measure);       % e.g. "USA_CPV"
        if ismember(cn, vn)
            X(:,k) = combo{:, char(cn)};
        else
            warning('ccdgv:eo_panel:missingColumn', ...
                    'eo_panel: column %s not in response (filled NaN).', cn);
        end
    end
    tt = array2timetable(X, 'RowTimes', combo.Time, 'VariableNames', names);
end

function tt = load_orig_german(cfg, what)
% German level series from the archived OECD files in Raw_Data/OECD_orig.
% Consumption is a level; investment is quarterly growth in percent, cumulated here.
    d = fullfile(cfg.rawdir, 'OECD_orig');
    switch what
        case 'consumption'
            f   = fullfile(d, 'OECD_Consumption.xlsx');
            T   = readtable(f, 'Sheet','OECD.Stat export', 'Range','A2', ...
                            'VariableNamingRule','preserve');
            dt  = parse_qdate(T.Country);          % 'Q4-1970'
            lvl = T.Germany;                       % real consumption level
        case 'investment'
            f   = fullfile(d, 'OECD_Investment.xlsx');
            T   = readtable(f, 'Sheet','G6 Data', 'Range','A2', ...
                            'VariableNamingRule','preserve');
            dt  = parse_qdate(T.TIME);             % '1961-Q2'
            lvl = exp(cumsum(T.GER/100));          % growth in percent -> level
        otherwise
            error('load_orig_german: what must be ''consumption'' or ''investment''.');
    end
    keep = ~isnat(dt) & ~isnan(lvl);
    tt = sortrows(timetable(lvl(keep), 'RowTimes', dt(keep), ...
                            'VariableNames', {'Germany'}));
end

function tt = load_german_backcast(cfg, what)
% German series for the backcast before 1991, as a level timetable named
% 'Germany', from cfg.german_splice_src. Only its growth is used.
    switch lower(string(cfg.german_splice_src))
        case "kei"
            % Reported quarterly growth in percent, compounded to a pseudo-level.
            key = sprintf(cfg.kei_key, 'DEU', cfg.kei_german.(what));
            raw = fullfile(cfg.rawdir, 'OECD', sprintf('KEI_DEU_%s.csv', what));
            g   = fetch_oecd_sdmx(cfg.kei, key, 'StartPeriod', cfg.oecd.start, ...
                      'RawFile', raw, 'Refresh', cfg.oecd.refresh);   % column 'DEU', percent
            lvl = cumprod(1 + g{:,1}/100);
            tt  = array2timetable(lvl, 'RowTimes', g.Time, 'VariableNames', {'Germany'});
        case "fred"
            s  = load_fred(cfg, cfg.fred_german.(what));      % OECD MEI volume index
            tt = s;  tt.Properties.VariableNames = {'Germany'};
        case "orig_file"
            tt = load_orig_german(cfg, what);
        otherwise
            error('cfg.german_splice_src must be "kei", "fred" or "orig_file".');
    end
end

function tt = load_fred(cfg, id)
% A FRED series as a quarterly timetable with one column named by the series id.
% Cached in Raw_Data/FRED/<id>.csv; downloaded when cfg.oecd.refresh is set or
% the cache is missing or empty.
    raw = fullfile(cfg.rawdir, 'FRED', [char(id) '.csv']);
    d   = fileparts(raw); if ~exist(d,'dir'); mkdir(d); end
    url = "https://fred.stlouisfed.org/graph/fredgraph.csv?id=" + string(id);
    stale = exist(raw,'file') && dir(raw).bytes == 0;
    if cfg.oecd.refresh || ~exist(raw,'file') || stale
        % Use the FRED API if a key is available; otherwise, or if it fails,
        % download fredgraph.csv.
        if isfield(cfg,'fred_key_file'); kf = cfg.fred_key_file; else; kf = ''; end
        key = local_fred_key(d, kf);
        got = false;
        if ~isempty(key)
            try
                api = sprintf(['https://api.stlouisfed.org/fred/series/observations?' ...
                               'series_id=%s&api_key=%s&file_type=json'], char(id), key);
                txt = webread(api, weboptions('Timeout',60,'ContentType','text'));
                j   = jsondecode(txt);
                assert(isfield(j,'observations'), 'unexpected API response');
                o   = j.observations;
                Tapi = table(datetime({o.date}','InputFormat','yyyy-MM-dd'), ...
                             str2double({o.value}'), ...
                             'VariableNames', {'observation_date', char(id)});
                writetable(Tapi, raw);      % same CSV shape as the fredgraph download
                fprintf('  FRED API %s (%d obs)\n', char(id), height(Tapi));
                got = true;
            catch ME
                fprintf('  FRED API failed for %s (%s); falling back to fredgraph.\n', ...
                        char(id), ME.message);
            end
        end
        if ~got
        fprintf('  FRED GET %s\n', url);
        try
            % A browser User-Agent avoids timeouts on this endpoint.
            websave(raw, url, weboptions('Timeout', 120, 'UserAgent', 'Mozilla/5.0'));
        catch ME
            if exist(raw,'file'); delete(raw); end
            rethrow(ME);
        end
        end
    else
        fprintf('  FRED (cached) %s\n', raw);
    end

    T  = readtable(raw, 'VariableNamingRule','preserve');
    dt = T{:,1};  if ~isdatetime(dt); dt = datetime(dt); end
    v  = T{:,2};  if ~isnumeric(v); v = str2double(string(v)); end   % '.' -> NaN
    keep = ~isnat(dt) & ~isnan(v);
    tt = sortrows(timetable(v(keep), 'RowTimes', dt(keep), ...
                            'VariableNames', {matlab.lang.makeValidName(char(id))}));
end

function panel = splice_german(panel, orig_ger, splice_dt)
% Backcast panel.Germany before splice_dt with the growth of orig_ger, scaled to
% the panel level at splice_dt. Quarters before orig_ger starts stay NaN.
    eo = panel.Germany;
    kE = panel{panel.Time == splice_dt, 'Germany'};
    kO = orig_ger{orig_ger.Time == splice_dt, 1};
    assert(~isempty(kE) && ~isempty(kO) && ~isnan(kE) && ~isnan(kO), ...
        'splice_german: splice date %s missing in EO or original series.', ...
        datestr(splice_dt,'yyyyQQ'));
    k = kE / kO;                                   % scale orig_ger onto the panel level
    pre = panel.Time < splice_dt;
    [tf, loc] = ismember(panel.Time(pre), orig_ger.Time);
    fill        = nan(sum(pre), 1);
    fill(tf)    = orig_ger{loc(tf), 1} * k;
    eo(pre)     = fill;
    panel.Germany = eo;
end

function dt = parse_qdate(s)
% Parse quarter strings 'Qn-YYYY' or 'YYYY-Qn' to quarter-start datetimes.
    s   = string(s);
    p   = reshape(split(s, "-"), [], 2);
    a   = p(:,1);  b = p(:,2);
    isQa = startsWith(a, "Q");
    y = nan(size(a));  q = nan(size(a));
    y(isQa)  = str2double(b(isQa));   q(isQa)  = str2double(extractAfter(a(isQa), "Q"));
    y(~isQa) = str2double(a(~isQa));  q(~isQa) = str2double(extractAfter(b(~isQa), "Q"));
    dt = datetime(y, (q-1)*3 + 1, 1);
end

% Transform helpers

function logagg = geo_aggregate_spliced(tt_levels, weights)
% Aggregate for a series whose country set grows mid-sample. Where every country
% is present this equals geo_aggregate; earlier quarters follow
% geo_aggregate_growth, linked in level at the first all-present quarter.
    L = geo_aggregate(tt_levels, weights);          % renormalized level
    G = geo_aggregate_growth(tt_levels, weights);   % cumulated growth
    full = all(~isnan(tt_levels.Variables), 2);     % quarters with every country
    t0 = find(full, 1);
    assert(~isempty(t0), 'geo_aggregate_spliced: no quarter has all countries present.');
    kappa = L.lnAgg(t0) - G.lnAgg(t0);              % link at the first all-present quarter
    logagg = G;
    logagg.lnAgg = G.lnAgg + kappa;                 % equals L where all countries are present
end

function tt = build_diff(homelog_tt, starlog_tt, name)
% Differential home_log - star_log on the common quarters. Both inputs are
% single-column timetables in logs.
    h = homelog_tt; h.Properties.VariableNames = {'h'};
    s = starlog_tt; s.Properties.VariableNames = {'s'};
    m = synchronize(h, s, 'intersection');
    tt = array2timetable(m.h - m.s, 'RowTimes', m.Time, ...
                         'VariableNames', {name});
end

function tt = build_q(Sstar_log, Pstar_log, Phome_log, name)
% Real exchange rate ln(S*) + ln(P*) - ln(P_home) on the common quarters. All
% three inputs are single-column timetables in logs.
    a = Sstar_log; a.Properties.VariableNames = {'s'};
    b = Pstar_log; b.Properties.VariableNames = {'pstar'};
    c = Phome_log; c.Properties.VariableNames = {'phome'};
    m = synchronize(synchronize(a, b, 'intersection'), c, 'intersection');
    tt = array2timetable(m.s + m.pstar - m.phome, 'RowTimes', m.Time, ...
                         'VariableNames', {name});
end

function tt = log_tt(tt_in, name)
% Natural log of a single-column timetable.
    tt = array2timetable(log(tt_in{:,1}), 'RowTimes', tt_in.Time, ...
                         'VariableNames', {name});
end

function tt = log1p_tt(tt_in, name)
% ln(1 + x) of a single-column timetable (x a decimal rate).
    tt = array2timetable(log1p(tt_in{:,1}), 'RowTimes', tt_in.Time, ...
                         'VariableNames', {name});
end

function tt = rename(x, name)
% Rename the single variable of a timetable.
    if istimetable(x)
        tt = x; tt.Properties.VariableNames = {name};
    else
        error('rename expects a timetable.');
    end
end

function out = synchronize_all(varargin)
% Inner-join several single-column timetables on common quarters.
    out = varargin{1};
    for k = 2:numel(varargin)
        out = synchronize(out, varargin{k}, 'intersection');
    end
end

function dt = parse_fernald_quarter(s)
% Convert Fernald 'YYYY:Qn' date strings to quarter-start datetimes.
    s     = string(s);
    parts = split(s, ":Q");                 % N-by-2: year, quarter
    yr    = str2double(parts(:,1));
    q     = str2double(parts(:,2));
    dt    = datetime(yr, (q-1)*3 + 1, 1);
end

function must_exist(p)
% Error if the folder does not exist.
    if ~exist(p,'dir')
        error('Expected raw-data folder missing: %s', p);
    end
end

function key = local_fred_key(freddir, keyfile)
% Find a FRED API key, in this order: keyfile, $FRED_API_KEY,
% <freddir>/API_KEY.txt, <freddir>/api_key.txt, ~/.fred_api_key.
    key = '';
    home = char(java.lang.System.getProperty('user.home'));
    cands = { rd(keyfile), ...
              getenv('FRED_API_KEY'), ...
              rd(fullfile(freddir,'API_KEY.txt')), ...
              rd(fullfile(freddir,'api_key.txt')), ...
              rd(fullfile(home,'.fred_api_key')) };
    for i = 1:numel(cands)
        k = strtrim(char(cands{i}));
        if ~isempty(k); key = k; return; end
    end
end

function t = rd(f)
% Trimmed contents of a text file; '' if it does not exist.
    t = '';
    if exist(f,'file')==2
        fid = fopen(f,'r'); t = strtrim(fscanf(fid,'%c')); fclose(fid);
    end
end
