clear
do_setup
set.agno=0; set.dhkw=1; set.nash=0;
[param,set] = parameters(set);
do_file;
do_match;
