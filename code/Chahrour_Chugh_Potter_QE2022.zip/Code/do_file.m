%******************************************************
% SET UP THE MODEL_PROG.M FILE FOR THE MODEL SOLUTION
%******************************************************


%Makes bnds for the estimation
[lbnd, ubnd] = generate_bnds(set);

%Load Parameters
if ~exist('set','var')
    [param,set] = parameters;
else
    disp('Note: Parameters modified in run_all.m!');
end
if set.nash == 0 
    case_nm = 'base';
elseif set.nash == 1
    case_nm = 'nash';
elseif set.nash == 2
    case_nm = 'hall';
end

%Generate a mod object
modl = model(param,set);

%Get dimensions of the model
nx   = length(modl.X);
ny   = length(modl.Y);
neps = size(modl.shck,2);
neq  = nx+ny;
np   = length(struct2array(param));

%Generate model file
model_func(modl,0*ones(1,np));

% Save model object and idx variables
load v_idx
save model_object modl *_idx nx ny neps case_nm np lbnd ubnd

