%% download FRED data

clear mth qtr
url = 'https://fred.stlouisfed.org/';
c = fred(url);

%Main BEA Series
qtr.gdp   = fetch(c,'GDP');       % gdp
qtr.pcnd  = fetch(c,'PCND');      % non-durable consumption
qtr.pcdg  = fetch(c,'PCDG');      % durable consumption
qtr.pcsv  = fetch(c,'PCESV');     % services consumption
qtr.gpdi  = fetch(c,'GPDI');      % gross private domestic investment
qtr.def   = fetch(c,'GDPDEF');    % deflator

%BLS employment
mth.emp = fetch(c,'PAYEMS');       %Employment
mth.urt = fetch(c,'UNRATE');        %Unemployment Rate
mth.lft = fetch(c,'CLF16OV');       %Labor force

%BLS Population
qtr.pop = fetch(c,'CNP16OV');    % noninstitutional population

%Employment Measures (BLS: Productivity and Costs)
qtr.hrs   = fetch(c,'HOANBS');      %hours worked

%Unemployment levels (for constructing job-finding rate)
mth.ulev    = fetch(c,'UNEMPLOY');          %All
mth.ulev_st = fetch(c,'UEMPLT5');           %Short-term (<5wks)

%Hires (for constructing job-finding rate from JOLTS)
mth.hires_nfm = fetch(c,'JTSHIL');              %Hires (total non-farm)

%Other aux variables: R&D
qtr.rnd = fetch(c,'Y694RC1Q027SBEA');

%BEA compensation measures using BEA tables directly in do_data.m

%Hours Measures (BLS: CES)
hrs_list = {    'AWHI'      'Hours Total Private'    'hrs_pvt';
      'CES0600000034'   'Hours Goods Producing'     'hrs_gds';
      'CES3000000034'   'Hours Manufacturing'       'hrs_mfn';
      'CES0800000034'   'Hours Services'            'hrs_svs';
    };
for jj = 1:length(hrs_list)
    mth = setfield(mth, hrs_list{jj,3}, fetch(c, hrs_list{jj,1}));
end

%CPS: Median usual weekly nominal earnings
qtr.cps_ern = fetch(c,'LES1252881500Q');

%Average Hourly Earnings 'super sectors' (BLS: CES production and non-supervisory workers) 
%Fred table: https://fred.stlouisfed.org/release/tables?rid=50&eid=5943)
ern_list = {'AHETPI'        ,  'Total Private'   , 'pvt'; 
            'CES0600000008' ,  'Goods Producing' , 'gds'; 
            'CES1000000008' ,  'Mining'          , 'min'; 
            'CES3000000008' ,  'Manufacturing'   , 'mnf';
            'CES0800000008' ,  'Services'       , 'svs';
            'CES4000000008' ,  'Trade, Transportation, and Utilities', 'ttu';
            'CES4142000008' ,  'Wholesale Trade',  'whl';
            'CES4200000008' ,  'Retail Trade'   ,   'rtl';
            'CES4300000008' ,  'Transportation and Warehousing', 'trn';
            'CES4422000008' ,  'Utilities'      ,   'utl';
            'CES5000000008' ,  'Information'    ,   'ifo';
            'CES5500000008' ,  'Financial Activities', 'fna';
            'CES6000000008' ,  'Professional and Business Services', 'bsv';
            'CES6500000008' ,  'Education and Health Services', 'ehsv';
            'CES7000000008' ,  'Leisure and Hospitality',       'lhs';
            'CES8000000008' ,  'Other Services',                'otr';
            };
for jj = 1:length(ern_list)
    mth = setfield(mth, ern_list{jj,3}, fetch(c, ern_list{jj,1}));
end

%BLS: Labor Productivity and Costs for 'major sectors'
%Fred table: https://fred.stlouisfed.org/release/tables?rid=47&eid=155240
comp_list = {'HCOMPBS'    'Business'                    'lpc_bsn';
    'COMPNFB'    'Nonfarm Business'            'lpc_nfm';
    'PRS88003103' 'Nonfinancial Corporations Sector', 'lpc_nfc';
};
for jj = 1:length(comp_list)
    qtr = setfield(qtr, comp_list{jj,3}, fetch(c, comp_list{jj,1}));
end

close(c);
date_loaded = datestr(today);
save 'data/fred_data.mat' qtr mth date_loaded ern_list comp_list hrs_list

