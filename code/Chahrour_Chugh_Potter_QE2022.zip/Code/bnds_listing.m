function paramp = prior_listing

%Ordering is {Type, mean, stddev, min, max}       
paramp.jrthet  = {'gaminv',  2  , 0.5,  0.25, 10};  
paramp.sig 	 = {'gaminv', 2     ,   0.5    , 0.5  , 15  };            
paramp.an2   = {'beta',   0.1  , 0.05   , 0.0001 , 1  };  
paramp.epn   = {'beta',   0.5  , 0.2   , 0.01 , 0.95  };  
paramp.wpt   = {'beta',   0.5  , 0.2  , 0.5  , 0.999  };


%Bounds on the MA wage parameters
nmax = 40;
for jj = 0:nmax
    paramp = setfield(paramp, ['phix_c', num2str(jj)], {'flat', .5, .2, -.25, .25});
end


