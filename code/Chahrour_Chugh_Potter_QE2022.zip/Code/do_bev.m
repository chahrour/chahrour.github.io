%% Beveridge curve in the data

load formatted_data.mat
brange = [196001, 201804];

urt_hp = urt;
vcn_hp = vcn;

urtv = vect(urt_hp,0,brange);
vcnv = vect(vcn_hp,0,brange);

bet = [ones(size(urtv)),urtv]\vcnv;
disp('Bev. curve slope (data):'); disp(bet(2));





%% Beveridge curve in the models
load flow_results
load v_idx

rng(0000);

eta_tmp = eta(:,7); %Only TFP

iry1 = ir(gx,hx,eta(:,7),40);  %7 is the news shock
yxsim = sim_dat(gx,hx,eta_tmp,212+100,100);

urtm  = yxsim(un_idx,:)';
vcnm  = yxsim(vnf_idx,:)';
bet_sim = [ones(size(urtm)),urtm]\vcnm;
disp('Bev. curve slope (model):'); disp(bet_sim(2));





%% Figure for paper
f = figure;
plot(urtv,vcnv, 'o');
hold on
plot(urtm-mean(urtm) + mean(urtv),vcnm-mean(vcnm)+mean(vcnv), 'x'); 
xlabel('Unemployment Rate', 'Interpreter', 'Latex', 'FontSize',14);
ylabel('Vacancies', 'Interpreter', 'Latex', 'FontSize',14);
l = legend('Data','Model Simulation')';
l.FontSize=14;
l.Interpreter = 'Latex';
saveas(f, [dest_dir,'figure10.eps'], 'epsc')
