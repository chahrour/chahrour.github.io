function [out,idx] = triuv(X)

N = size(X,1);
out = ones(size(X));
for nn = 1:N-1
    out(1:nn,nn+1) = 0;
end
idx = out~=0;
out = X(idx);

