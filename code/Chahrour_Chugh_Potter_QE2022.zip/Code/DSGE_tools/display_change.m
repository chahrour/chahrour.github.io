function out = display_change(paramin,paramout)

fnames = fieldnames(paramin);

for jj = 1: length(fnames)
    disp([sprintf('%10s', fnames{jj}), ': ' num2str(getfield(paramin,fnames{jj}),'%1.4f'),...
        ' -> ' num2str(getfield(paramout,fnames{jj}), '%1.4f')]);
end