%Generate the unqiue cummutation matrix such that
%
%vec(A') = K(m,n)vec(A)


function out = commute(m,n)

out = zeros(m*n,m*n);
for i = 1:m
    for j = 1:n
        out((i-1)*n+j,i+m*(j-1)) = 1;
    end
end

out = sparse(out);