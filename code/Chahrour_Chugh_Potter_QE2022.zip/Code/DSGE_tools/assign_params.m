% ASSIGN_PARAMS - Assign a vector of values to a data structure.
%
% Usage
%
% struct = assign_params(struct,vals)

function struct = assign_params(struct,vals)


names = fieldnames(struct);
ns = length(names);
nt = length(vals);

if ns ~= nt
    error('Number of values and number parameters do not match');
end

for j = 1:nt 
    eval(['struct.', names{j} , '= vals(j);']);
end
