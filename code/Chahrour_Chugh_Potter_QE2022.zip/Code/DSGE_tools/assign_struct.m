% ASSIGN_PARAMS - Assign values from one structure to another for common
% elements
%
% Usage
%
% struct = assign_params(struct1,struct2)

function struct2 = assign_params(struct1,struct2)

%Assign from struct1 to struct2;
names1 = fieldnames(struct1);
names2 = fieldnames(struct2);
ns1 = length(names1);
ns2 = length(names2);


vals1 = struct2array(struct1);
vals2 = struct2array(struct2);

for jj = 1:ns1
    idx = find(strcmp(names1{jj}, names2));
    if ~isempty(idx)
        vals2(idx) = vals1(jj);
    end
end
struct2 = assign_params(struct2,vals2);

