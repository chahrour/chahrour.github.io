% PARAMETETRS - This function returns a parameter structure to use in the model solution.


function [param,set] = parameters(varargin)

%long run values for government share and output growth from data
g_shr  = 0.202480219660108;    
dy_bar =  1.003510371386729;

if nargin>0
    set = varargin{1};
else
    set.agno = 0 ;  %Agnostic wage
    set.dhkw = 1 ;  %DHK wage
    set.nash = 0 ;  %Nash wage
end

%Prefs parameter
param.jrthet = 2.5;

%Leverage factor for stock price
set.lev_fact = 1.5;  

%The max number of MA TFP terms
set.nmax = 40;

%HH preferences
set.bet      =  (1/1.04)^(1/4);       % Discount rate
param.sig    =  1.5;  		          % Intertemporal elasiticity parameter
set.thet     =  0.6;                  % Habit formation

%Price adjustment (for hypothetical NK implications for inflation)
set.bbltheta = 0.8;
set.mccoef = (1-set.bbltheta)*(1-set.bet*set.bbltheta)/set.bbltheta;

%Government exenditure
set.gshr     = g_shr;                 % Government share
set.kap      = 0.2;                   % Replacement rate of unemployment
param.an2    = 0.1;                   % Vacancy adjustmnet cost 

%Production Function and depreciation
set.shrcmp       = NaN;                      % Compensation share of income -> now endogenous
set.shrhr        = 0.17;                     % Hiring costs as % of MPL from Fujita and Ramey 
set.alph         = 0.32;             		 % Capital share of income = captial share in prod. fcn
set.delt0        = 0.03;                     % Capital depreciation rate

%Parameters of matching function
set.typn     = 1.0;             % 1 = cobb dougls, 2 = urn-ball, 3 = HRW
param.epn    = 0.6; 		    % Labor matching elasticity wrt vacancies   (no effect on dynamics for hrw)

%"Great ratios" that I calibrate to get implied parameter values
set.un     = 0.06 ;  		    % unemployment rate
set.nbar   = (1-set.un)*.6;     % labor supply (normalization)
set.taul   = 0.2;               % labor tax rate

%Matchign probabilities
set.qn     = 0.9;       % prob of match in labor (firm-side)
set.lamn   = 0.12;      % exogenous separation rate
set.pn     = NaN;  		% prob of match in labor (hh-side)
set.fss    = NaN;       % SS LFP (independent of surplus share to workers)

%**************************************
% Exogenous parameters
%**************************************

%SS output growth 
set.gamy = dy_bar;    

%AR coeffs
set.rhox    = 0.89;                     % TFP growth rate persistence parameter
set.rhoa    = 0.91;                     % TFP level persistence parameter
set.rhop    = 0.90;                     % PREF persistence
set.rhog    = 0.99;                     % GOV peristence
set.rhob    = 0.90;                     % DISCOUNT persistence
set.rhoc    = 0.90;                     % MATCHING peristence

%SD values
set.sigxs = 0.00;                       % SD of TFP growth rate shocks
set.sigxn = 0.06;  		                % SD of TFP growth rate news shocks
set.siga  = 0.79;                       % SD of stationary TFP 
set.sigp  = 1.354592031735000;          % SD of labors supply shocks
set.sigg  = 0.884437774047750;          % SD of government
set.sigb  = 2.5;                        % SD of prefrence shock
set.sigc  = 0.5;                        % SD of matching shock

%Choose horizon of TFP news
set.phix1 = 0;
set.phix2 = 0;
set.phix3 = 0;
set.phix4 = 0;
set.phix7 = 1;  
set.phix8 = 0;

%How quickly responds to flow, vs lagged dependence. 
if set.dhkw || set.nash
    param.wpt   = .6 ; 
else
    set.wpt = 0.5;
end

%MA process for calibration exercise
set.phixr = 0.05;     %Long-run wage cointegration parameter.
if set.agno
    param.phix_c0 = NaN;
    for i=0:set.nmax
        param = setfield(param, ['phix_c' num2str(i)], 0);
    end
else
    set.phix_c0 = NaN;
    for i=0:set.nmax
        set = setfield(set, ['phix_c' num2str(i)], 0);
    end
end

%Implied parameters
set.delt1= NaN;
set.psii = NaN;      %Disutility of labor
set.rbar = NaN;      %Capital rental rate
set.wbar = NaN;      %Wage rate
set.chin = NaN;      %Steady-state matching efficiency
set.an   = NaN;      %Cost of labor vacancy posting
set.vn   = NaN;
set.gdp  = NaN;
set.gamw = NaN;
set.gamg = NaN;
set.gbar = NaN;
set.gamx = NaN;
set.ybar = NaN;
set.gami = NaN;
set.vnbar= NaN;
set.kbar = NaN;
set.cbar = NaN;
set.ibar = NaN;
set.wshr = NaN;
set.etan = NaN;%Nash parameter set in steady-state
set.omeg0 = NaN;%DHK parameter set in steady-state

%Degree of Approximation
set.me_eq = [];      %Measurement errors set in model.m
set.approx_deg = 1;


