% MODEL_SS - Return the steady state of the model computed analytically
%
% usage:
%
% [ss, parameters] =model_ss(param)


function [Yss, Xss, param,set] = model_ss(param, set)


%This loop assigns values to variables with the same names as the fields in
%param.
nms = fieldnames(param);
for j = 1:length(nms)
    eval([nms{j} '='  'param.' nms{j} ';'])
end

set_list = fieldnames(set);
set_val = struct2array(set);
for j = 1:length(set_list)-2
    eval([set_list{j} '= set_val(j);']);
end


%BEGIN_EXTRACT_HERE

m     = lamn*nbar;
fss   = nbar/(1-un);
s     = fss-nbar+m;
pn    = m/s;
vn    = m/qn;


gamx = gamy;

r     = (gamx)^sig/bet - (1 - delt0);
k     = nbar*gamx*(r/alph)^(1/(alph-1));
delt1 = r;
gdp   = k^alph*(gamx*nbar)^(1-alph);
gbar  = gshr*gdp;


h = gamx;

%Definition labor share, given that there are rents (targets vacancies 17% of MPL)
an    = shrhr*(1-alph)*gdp/nbar*(gamx^-1);
wbar  = (1-alph)*(k/(gamx*nbar))^alph*gamx-an*gamx/qn*(1-(1-lamn)*(bet*gamx^(-sig))*gamx);
kapt  = kap*wbar*(1-taul);
phi_n = an*h/qn;
shrv  = phi_n*m/gdp;
inv   = k*(gamx -1 + delt0);
c     = k^alph*(gamx*nbar)^(1-alph)*(1-shrv) - inv - gbar;

%Start NB stuff...
stuff = (k/nbar)^alph*gamx^(1-alph)*(1-alph)+(1-lamn)*bet*(gamx)^(1-sig)*pn*phi_n;
etan = (kapt + wbar*(taul - 1))/(kapt - stuff + taul*wbar);
%End NB stuff...

%Marginal cost (for computing inflation response)
mc   = log((1-alph)^(-1)*((1-alph)/alph)^alph) + (1-alph)*(log(wbar)-log(gamx)) + alph*log(r);
infl = mccoef/(1-bet)*mc;

%*************************
% Modified GHH prefs
%*************************

h      = gamx;
phi_hh = (wbar*(1-taul)-kapt)/(1+pn/(1-pn)-bet*(1-lamn)*gamx^(1-sig));
uf_lam = -phi_hh*pn/(1-pn)-kapt;
psii   = -uf_lam/(jrthet*fss^(jrthet-1)*h);

%Labor matching equations
chin = m/(vn^epn*s^(1-epn));

%Growth rates always fixed in ss
gamc = gamx;
gamy = gamx;
gamn = 1;
gami = gamx;
gamw = gamx;
gamg = gamw;

wsurp = (wbar*(1-taul)-kap*wbar*(1-taul))/(1-bet*(gamx)^(1-sig)*(1-lamn)*(1-pn));
wshr  = wsurp/(wsurp+an*h/qn);
wny   = wbar*nbar/gdp;
pt    = (gdp - r*k - an*h*vn )/nbar;
phin  = an*h/qn;

%Wage parameter:                                                                                  
omeg0 = wbar*(pt^wpt*(wbar/gamx)^(1-wpt))^-1;    

%Value of firm
vf = (gdp - an*vn*h - wbar*nbar - r*k )/(1-bet*gamx^(1-sig));


%Steady-state X and Y vectors
Yss = [nbar c s fss inv vn pn qn gdp wbar r kapt gamy gamc gamn gami  un gamg gamg 1  gamw gamx^(1-alph) pt gamy wbar wbar vf gamx^lev_fact wsurp wshr wny phin vn/fss mc infl gamx^-sig 1 1];
Xss = [k gamx  1 1 1 1 1 gamx  c nbar inv  wbar gdp 1 vn vn kapt  ones(1,nmax) pt wbar wbar 1 vf 1 1 1];

%END_EXTRACT_HERE

%Set of "implied" parameter values
set.an   = an;         % Labor vacancy posting cost                        
set.chin = chin;       % Labor matching intensity
set.rbar = rbar;       % SS interest rate
set.wbar = wbar ;      % SS wbar/a=\tilde{wbar}
set.psii = psii;
set.delt1 = delt1;

%TLP (11-3-19)
set.delt0 = delt0;
set.pn    = pn;
set.gshr  = gshr;
set.gamx  = gamx;
set.wshr  = wshr;
set.omeg0 = omeg0;
set.etan  = etan;
set.vn    = vn;
