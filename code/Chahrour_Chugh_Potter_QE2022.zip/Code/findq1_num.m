function q1out = findq1_num(B,A,q1_init)

if nargin < 3
    q1_init = rand(size(q1));
end
 
obj = @(q1) objective(q1,B,A);

options = optimoptions('fmincon');

options.Display = 'notify';
[q1out,~,flag] = fmincon(obj,q1_init,[],[],[],[],[],[],@(q1)nlcon(q1),options);

if flag<1
    disp(['Flag: ' num2str(flag)])
end


function [out] = objective(q1,B,A)
maxir =40;
IR = zeros(size(B,1),maxir);
IR(:,1) = A*q1;
for ii = 2:maxir
    IR(:,ii) = B*IR(:,ii-1);
end

out = -sum(IR(1,10:maxir)) + 10*sum(IR(1,1:10).^2);


function [neq,eq] = nlcon(q1)

%No inequality constraints
neq = [];  

%Equality constraints
eq(2) = 1-q1'*q1;