% OUTPUT_TABLE - Takes a table object and prints it to file filename.
% Usage:
% output_table(ltable, 'filename')


function table = output_table(table, filename)
    try
    fid = fopen([filename,'.text'], 'w');
    for i = 1:size(table.text,2)
        fprintf(fid, '%s\n',table.text{i});
    end
    fclose(fid);
    table = 1;
    catch
        table = 0;
    end
    
end