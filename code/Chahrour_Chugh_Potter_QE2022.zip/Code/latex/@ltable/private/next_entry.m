% A simple fuction that return the first value in a vector and return the
% rest of the vector as well.  If vector is empty, returns -1
% for both values
% Usage:
% [value remains] = next_entry(vector)

function [value, remains] = next_entry(vector)
    if numel(vector)==0
        value = -1 ;
        remains = -1;
    else 
        value = vector(1);
        remains = vector (2:end);
    end
end
