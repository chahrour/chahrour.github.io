% OUTPUT_LATEX - Makes and Displays a dvi & pdf file from a .tex file
%
% usage:
%
%
% flag =  output(file_name, latex_path)
%
% where
%
% file_name = the name of the latex file to be compiled
% latex_path = the path to latex compile command on your system

function output(file, ls_str)

str = ['!' ls_str ' ' file];
eval(str);


%Remove the extra files
str = ['!rm ', file,'.aux'];
eval(str);
str = ['!rm ', file,'.log'];
eval(str);

