%% Setup
clear
clc
do_setup



%% Load data from FRED (last run on 9/27/2022)
%do_FredData



%% Construct data and estimate VARs

%Short sample (online appendix)
date_range = [198501,201804];      %Short sample
do_data
do_var_extend
save var_results_2x_short ir_bs ir_bands var_names

%Sample ending in 2007 (used in Kurmann and Sims, 2021)
date_range  = [196001,200703];     
do_data
do_var_KS;  save var_results_ks_07   ir_bs ir_bands var_names
do_var_BBL; save var_results_bbl_07  ir_bs ir_bands var_names
do_var_CCP; save var_results_ccp_07  ir_bs ir_bands var_names

%Sample ending in 2012 (used in Basu, Barsky, and Lee, 2015)
date_range  = [196001,201202];     
do_data
do_var_KS;  save var_results_ks_12   ir_bs ir_bands var_names
do_var_BBL; save var_results_bbl_12  ir_bs ir_bands var_names
do_var_CCP; save var_results_ccp_12  ir_bs ir_bands var_names

%Sample ending in 2018 (our baseline)
date_range  = [196001,201804];     
do_data
do_var_KS;  save var_results_ks_18   ir_bs ir_bands var_names
do_var_BBL; save var_results_bbl_18  ir_bs ir_bands var_names
do_var_CCP; save var_results_ccp_18  ir_bs ir_bands var_names

%Baseline results
date_range  = [196001,201804];     
do_data
do_var_extend
save var_results_2x ir_bs ir_wg ir_wghts ir_bands* ir_bands_wage* ir_other* ir_bands_other* ir_tech* ir_bands_tech* ir_bs* ir_wg* var_names wage_names wage_idx other_idx nper ir_wghts other_nms  tech_nms B cnew

%Alternative TFP: Labor productivity
alt_tfp = 1;         
do_data
do_var_CCP
save var_results_2x_lp ir_bs

%Alternative TFP: Unadjusted TFP
alt_tfp = 2;
do_data
do_var_CCP
save var_results_2x_unadj ir_bs


%% Estimate models with different wage assumptions

%Agnostic wage
clear
do_setup
set.agno=1; set.dhkw=0; set.nash=0;
[param,set] = parameters(set);
do_file;
do_match;

%Nash wage
clear
do_setup
set.agno=0; set.dhkw=0; set.nash=1;
[param,set] = parameters(set);
do_file;
do_match;

%Flow wage
clear
do_setup
set.agno=0; set.dhkw=1; set.nash=0;
[param,set] = parameters(set);
do_file;
do_match;

%% Suitability
do_simulated_example


%% Generate figures & tables
clear
do_setup
do_figures
do_tables

return
%% Execute these to clean up generated_files

delete *.mat
delete model_prog.m
delete param_trans.m
delete param_untrans.m
delete param_unpacker.m
delete figures_output/*



