%% CALIBRATED

load flow_results

%Inputs
tabdata_calib = [set.bet  set.alph  set.delt0  set.lamn set.psii set.kap  set.an set.lev_fact set.phixr,  set.gamx, set.rhox  set.sigxn]';
vert_calib    = {'$\beta$',         '$\alpha$',     '$\delta$',         '$\lambda$',        '$\psi$',               '$\kappa$',         '$a_n$',                                '$\phi_{lev}$',     '$\phi_x$',             '$\gamma_x$',           '$\rho_x$',                 '$\sigma_x$',;...
                'Discount factor',  'Capital share','Depreciation rate','Separation rate',  'Preference parameter', 'Replacement rate', 'Vacancy posting cost (steady state)',  'Leverage factor',  'Wage error-correction','TFP growth (average)', 'TFP growth (persistence)', 'TFP growth (innov std. dev.)',}';
horiz_calib   = {'Parameter','Concept','Value'};

%Filename
filename_calib = [dest_dir, 'params_calib'];

%Creates .text file with table - can use \insert{} command
[table1_calib] = ltable(tabdata_calib, horiz_calib, vert_calib, 'Calibrated Parameters','table_format_file_estimates_calib',filename_calib);


%% AGNO

load agno_results param_final se_final

%Get parameters/se's
params_agno  = param_untrans(struct2array(param_final)');
se_agno      = se_final;

%Inputs
tabdata_agno = [params_agno(:) se_agno(:)];
vert_agno    = {'$\theta$','$\sigma$','$\xi$','$\epsilon$';...
                'Labor supply elasticity', 'Inv. intertemporal elasticity','Vac. posting cost (curvature)','Matching function elasticity' }';
horiz_agno   = {'Parameter','Concept','Estimate','Std. Err.'};

%Filename
filename_agno = [dest_dir, 'params_agno'];

%Creates .text file with table - can use \insert{} command
prefs.label = 'params_agno';
table1_agno = ltable(tabdata_agno, horiz_agno, vert_agno, 'Parameter Estimates (Agnostic Wage)','table_format_file_estimates',filename_agno,prefs);

%% FLOW

load flow_results param_final se_final

%Get parameters/se's
params_flow  = param_untrans(struct2array(param_final)');           
se_flow      = se_final;                                            

%Inputs
tabdata_flow = [params_flow(:) se_flow(:)];
vert_flow    = {'$\theta$','$\sigma$','$\xi$','$\epsilon$','$\omega^F$';...
                'Labor supply elasticity', 'Inv. intertemporal elasticity','Vac. posting cost (curvature)','Matching function elasticity','Flow term' }';
horiz_flow   = {'Parameter','Concept','Estimate','Std. Err.'};

%Filename
filename_flow = [dest_dir, 'params_flow'];

%Creates .text file with table - can use \insert{} command
prefs.label = 'params_flow';
table1_flow = ltable(tabdata_flow, horiz_flow, vert_flow, 'Parameter Estimates (Flow wage)','table_format_file_estimates',filename_flow,prefs);


%% NASH

load nash_results param_final se_final

%Get parameters/no se's
params_nash  = param_untrans(struct2array(param_final)');

%Inputs
tabdata_nash = [params_nash(:) ];
vert_nash    = {'$\theta$','$\sigma$','$\xi$','$\epsilon$','$\omega^{NB}$',  ;...
               'Labor supply elasticity', 'Inv. intertemporal elasticity','Vac. posting cost (curvature)','Matching function elasticity','Nash Term',      }';
horiz_nash   = {'Parameter','Concept','Estimate'};

%Filename
filename_nash = [dest_dir, 'params_nash'];

%Creates .text file with table - can use \insert{} command
prefs.label = 'params_nash';
table1_nash = ltable(tabdata_nash, horiz_nash, vert_nash, 'Parameter Estimates (Nash bargaining)','table_format_file_estimates',filename_nash,prefs);


%% Variance decompositions
do_vd

%% Wage series
load data/fred_data
vert_wage    = ern_list(:,2:-1:1);
horiz_wage   = {'Sector', 'Code'};
prefs.vert_lines = [];
prefs.label = 'ces_wages';
%Filename
filename_wage = [dest_dir, 'wage_series'];

%Creates .text file with table - can use \insert{} command
table1_nash = ltable([], horiz_wage, vert_wage, 'CES Sectoral Wage Series','table_format_file_estimates',filename_wage,prefs);


