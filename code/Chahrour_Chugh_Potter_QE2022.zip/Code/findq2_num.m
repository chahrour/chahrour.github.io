function q2out = findq2_num(AssA,q1,q2_init)

if nargin < 3
    q2_init = rand(size(q1));
end
 
obj = @(q2) objective(q2,AssA);

options = optimoptions('fmincon');

options.Display = 'notify';
[q2out,~,flag] = fmincon(obj,q2_init,[],[],[],[],[],[],@(q2)nlcon(q2,q1),options);

if flag<1
    disp(['Flag: ' num2str(flag)])
end


function [out,q2] = objective(q2,AssA)

out = -q2'*AssA*q2;


function [neq,eq] = nlcon(q2,q1)

%No inequality constraints
neq = [];  

%Equality constraints
eq(1) = q1'*q2;
eq(2) = 1-q2'*q2;