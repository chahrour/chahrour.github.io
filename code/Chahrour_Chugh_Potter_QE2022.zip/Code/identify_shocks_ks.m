function [c_out,errs_out] = identify_shocks_ks(B,c,errs,targ_var1,norm_idx1,hor_idx1)
 

nvar = size(c,1);

kmin1 = 0;
kmax1 = 80;
kmax = max(kmax1);

%% THE FIRST SHOCK


%IR's of choleski shocks at each horizon
Rtil = zeros(size(c,1),size(c,2),kmax+1);
tmp = eye(size(B));
for jj = 0:kmax
    Rtil(:,:,jj+1) = tmp(1:nvar,1:nvar)*c;
    tmp = B*tmp;
end

%Compute S for relevant horizons
S = zeros(nvar,nvar);
% for ll = 0:kmin1-1
%     S = S - 2*Rtil(targ_var1,:,ll+1)'*Rtil(targ_var1,:,ll+1);
% end

for ll = kmin1:kmax1
    S = S + Rtil(targ_var1,:,ll+1)'*Rtil(targ_var1,:,ll+1);
end

%FD identification
% C = zeros(size(B,1),nvar); 
% C(1:nvar, 1:nvar) = c;
% [tmp1,S] = vdfilter(B,C,[1 2],[2*pi/500,2*pi/40]);

%Do PCA on S
[q1,D]  = eig(S(1:end,1:end));                                          %Get eigenstuffs
[~,idx] = sort(diag(D), 'descend');                                     %Get order of eigenvalues
q1      = q1(:,idx(1));                                                 %Re-order eigenvectors in descending order of eigenvalues

%Sign flip of q1
tmp = B^hor_idx1; 
tmp = tmp(1:nvar,1:nvar)*c*q1;
q1  = sign(tmp(norm_idx1))*q1;

% Impulse responses
ww       = null([q1]');
c_out    = c*[q1,ww];
errs_out = errs/(c_out');




