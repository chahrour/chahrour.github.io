function [out,irp_fnw,irp_s] = ir_obj(paramv,setv,ir_bs,ir_wghts,dtfpu_idx,dy_idx,dc_idx,di_idx,dn_idx,dvf_idx,dw_idx)

nir = size(ir_bs,1);
ntarg = 50;


[f, fx, fy, fxp, fyp, eta, R]= model_prog(paramv,setv);

% Check steady-state
if max(abs(f))>1e-7
    [mf,idxf] = max(abs(f));
    disp(['Warning: Non-zero steady-state: fmax = ' num2str(mf), ' eqidx = ' num2str(idxf)]);
    save paramv_tmp paramv
    pause
end

%Solve model
[gx,hx, flag] = gx_hx_alt(fy,fx,fyp,fxp);

if flag ~= 1 
    %paramv
    out = 10000*ones(ntarg*6+48,1);
    size(out)
    return
end
%Impulse responses
iry1 = ir(gx,hx,eta(:,7),nir);  %7 is the news shock

irp_f = zeros(nir,6,1);

%TFP
irp_f(:,1,1) = cumsum(iry1(:,dtfpu_idx));
irp_f(:,1,2) = ir_bs(:,1,1);

%Output
irp_f(:,2,1) = cumsum(iry1(:,dy_idx));
irp_f(:,2,2) = ir_bs(:,2,1);

%Consumption
irp_f(:,3,1) = cumsum(iry1(:,dc_idx));
irp_f(:,3,2) = ir_bs(:,3,1);

%Investmnet
irp_f(:,4,1) = cumsum(iry1(:,di_idx));
irp_f(:,4,2) = ir_bs(:,4,1);

%Employment
irp_f(:,5,1) = cumsum(iry1(:,dn_idx));
irp_f(:,5,2) = ir_bs(:,5,1);

%Stock
irp_f(:,6,1) = cumsum(iry1(:,dvf_idx));
irp_f(:,6,2) = ir_bs(:,6,1);

irp_fnw = irp_f;

%Weights from bootstrap
irp_f = irp_f.*ir_wghts(:,1:6);

%Additional weights by variable
wghts = zeros(1,6);
wghts(:) = [1 1 1 1 1 1];
irp_f = irp_f.*wghts;
out = vec(irp_f(1:ntarg,1:6,1)-irp_f(1:ntarg,1:6,2));

%Penalty for jumpy wages
out = [out;5*diff(diff(iry1(1:ntarg,dw_idx)))];

if nargout > 2
   iry2 =  ir(gx,hx,eta(:,6),nir);
   irp_s = zeros(500,6,1);
   irp_s(:,1,1) = cumsum(iry2(:,dtfpu_idx));
   irp_s(:,2,1) = cumsum(iry2(:,dy_idx));
   irp_s(:,3,1) = cumsum(iry2(:,dc_idx));
   irp_s(:,4,1) = cumsum(iry2(:,di_idx));
   irp_s(:,5,1) = cumsum(iry2(:,dn_idx));
   irp_s(:,6,1) = cumsum(iry2(:,dvf_idx));
end