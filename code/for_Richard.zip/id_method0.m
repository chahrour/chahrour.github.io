function [cnew,Cnew] = id_method0(B,c,targ,freq)

nvar = length(c);

%Initial shock matrix for VAR comp form: Y(t) = B*Y(t-1) + C*eps(t)
C = zeros(size(B,1),nvar);
C(1:nvar, 1:nvar) = c;

%Do PCA on S
[~,S] = vdfilter_rp(B,C,targ,freq);
[q1,D]  = eig(S(1:end,1:end));                                          %Get eigenstuffs
[~,idx] = sort(diag(D), 'descend');                                     %Get order of eigenvalues
q1      = q1(:,idx);                                                    %Re-order eigenvectors in descending order of eigenvalues

%Rotate the c matrix
cnew = c;
cnew(1:end,1:end) = cnew(1:end,1:end)*q1;

%Sign-normalization so that RP goes up on impact !!
cnew(1:end,1)    = sign(targ(1:nvar)*cnew(1:end,1))*cnew(1:end,1);

Cnew = C;
Cnew(1:nvar,1:nvar) = cnew;

