function [shape,scale] = gaminv_params(mu,sd)


alph = (mu/sd)^2+2;
bet = mu*(alph-1);


shape = alph;
scale = bet;