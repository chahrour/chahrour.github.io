function out = numerical_gradients(f,x0,del)

nx = length(x0);

if length(del)<nx
    del(end+1:nx) = del(end);
end

f0 = f(x0);
df = zeros(length(f0),nx);
for jj = 1:nx
    dx = zeros(size(x0));
    max(del(jj),del*abs(x0(jj)));
    dx(jj) = max(del(jj),del(jj)*abs(x0(jj)));
    xtmp1 = x0+.5*dx;
    xtmp2 = x0-.5*dx;
    df(:,jj) = (f(xtmp1)-f(xtmp2))./sum(dx);
end
    
    


out = df;