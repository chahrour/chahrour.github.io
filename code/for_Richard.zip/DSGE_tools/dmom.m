% DMOM - Function providing analytical derivatives of the contemporary covariances
% SigX and SigY for a given model, generated using model_prog.
%
% usage
%
% [dsigx, dsigy, dh_dtheta, dg_dtheta, deta_dtheta, dR_dtheta] = dmom(param,set,S)
%
% where
%
% param = the vector of parameters at which to comupute derivative
% set   = a vector of parameters that do not vary
% S     = a matrix selecting the desired rows of y_t

function [dsigx, dsigy, dh_dtheta, dg_dtheta, deta_dtheta, dR_dtheta, dgam_dtheta, gx, hx, eta, R] = dmom(param,set,S)

%In this case, tau = vec(hx;gx);
[f, fxn, fyn, fxpn, fypn, eta, R, set, dgam_dtheta, deta_dtheta, dR_dtheta]=model_prog(param,set);

dgam_dtheta = sparse(dgam_dtheta);
deta_dtheta = sparse(deta_dtheta);
dR_dtheta = sparse(dR_dtheta);

[gx,hx,flg] = gx_hx_alt(fyn,fxn,fypn,fxpn);
pause

%*************************************************************************
% DERIVATE OF OBJETIVE: Works but too slow now
%*************************************************************************

nx = size(hx,1);
ny = size(gx,1);
nn = nx^2+ny*nx;

%Using the implicit function theorem, taking advantage of fact that GAM*A where GAM = [A1 B1 A2 B2].
A =   [hx; gx*hx; speye(nx); gx];
pause
df_dtau = kron(speye(nx), (fxpn + fypn*gx))*kron(speye(nx),[speye(nx), sparse(zeros(nx,ny))]) + (kron(speye(nx),fyn) + kron(hx',fypn))*kron(speye(nx), [sparse(zeros(ny,nx)), speye(ny)]);
pause

df_dtheta = kron(A',speye(nx+ny))*dgam_dtheta;
pause
dtau_dtheta = -df_dtau\df_dtheta;
pause
%Recreating dh/dtheta, dg/dtheta using a trick
idx = rem(1:nn,nx+ny); idx = [0, idx(1:end-1)];
dh_dtheta = dtau_dtheta(idx<nx,:);
dg_dtheta = dtau_dtheta(idx>=nx,:);

%Derivative of the moments
%dhh2 = kron(kron(speye(nx), commute(nx,nx)),speye(nx))*(kron(speye(nx*nx),hx(:)) + kron(hx(:),speye(nx*nx)))*dh_dtheta;%d(hx kron hx)
%dnn2 = (speye(nx*nx)+commute(nx,nx))*kron(eta,speye(nx))*deta_dtheta;


%dhh2 = sparse(dhh2);
%dnn2 = sparse(dnn2);

eta_eta = sparse(eta*eta');
tmp = sparse((speye(nx*nx)-kron(hx,hx))\speye(nx*nx));
ttt = kron(speye(nx), kron(commute(nx,nx),speye(nx)));
kkk = kron_fast(full(eta_eta(:)'*tmp'), full(speye(nx^2)*tmp));
lll = (kron(speye(nx*nx),hx(:)) + kron(hx(:),speye(nx*nx)));
dsigx1 = kkk*ttt*lll*dh_dtheta;
disp('ho')
pause

dsigx2 = sparse((speye(nx^2)-kron(hx,hx))\dnn2);  %Not needed since eta*eta' is fixed in our fomulation.
dsigx = dsigx1+dsigx2;

%Do the computation for dsigy, using previous result
disp('ha')
pause
ggg = (kron(speye(ny*nx),gx(:)) + kron(gx(:),speye(nx*ny)));
dgg2 = kron(kron(speye(nx), commute(nx,ny)),speye(ny))*ggg*dg_dtheta;%d(gx kron gx)

ny2 = size(S,1);
dsigy = zeros(ny2^2*(K+1),length(param));

%Return only dg_tilde, dR_tilde (only for those variables observed by econometrician)
dg_dtheta = kron(speye(nx), S)*dg_dtheta;
dR_dtheta = kron(S,S)*dR_dtheta;
gx = S*gx;
R = S*R*S';