% FPRINT_MAT - Print a matrix to cvx format
%
% where
%
% fid = the file id to print to
% format = the data format, eg, '%3.2f\t'
% mat = the matrix
% varargin = the column titles

function fid = fprint_mat(fid, format, mat, varargin)


%Column Titles
if ~isempty(varargin)
    tits = varargin{1};
    col_tit = [];
    for j = 1:(size(tits,2)-1)
        col_tit = [col_tit, tits{j}, '\t'];
    end
    cot_tit = [col_tit, tits{j+1}, '\n'];
    fprintf(fid,sprintf(cot_tit));
end

for j = 1:size(mat,1)
    fprintf(fid, format, mat(j,:));
    fprintf(fid, '%s\n', '');
end




