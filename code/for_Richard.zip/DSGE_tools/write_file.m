function out = write_file(fname, s)


f = fopen(fname,'w');


fprintf(f,'%s',s);

fclose(f);
