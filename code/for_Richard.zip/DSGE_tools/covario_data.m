function  outmat = covario_model(dat,nj,corr_opt)
nv = size(dat,1);
outmat = zeros(nj+1,nv^2);
nt = size(dat,2);

%Compute moments
sigY = zeros(nv,nv,nj+1);
for j = 0:nj
    sigY(:,:,j+1) = 1/(nt-j)*dat(:,1:end-j)*dat(:,1+j:end)';
end

for k = 1:nv
    for l = 1:nv
        for j = 0:nj
            if corr_opt
                outmat(j+1, l+nv*(k-1)) = sigY(k,l,j+1)/sqrt(sigY(l,l,1)*sigY(k,k,1));
            else
                outmat(j+1, l+nv*(k-1)) = sigY(k,l,j+1);
            end
        end
    end
end