% QUICK_PCA - Compute the principal components factors
%
% usage
%
% [F_hat, weights, D] = quick_pca(X,k,resriction)
%
% where
%
% X = the data matrix, each variable in a column
% k = the number of factors
% restriction = 1 for lam'lam = eye(k) (default)
%               2 for inv(T)*F'F = eye(k)
%                
%
% F_hat = the PCA factors
% weights = the PCA loadings F_hat = X*weights';
% D = the matrix F'F

function [F_hat, weights, D, lam] = quick_pca(X,k,varargin)

T = size(X,1)-1;
[V, D] = eig(X'*X/T);
weights = V(:, end:-1:end-k+1);
D = D(end:-1:end-k+1,end:-1:end-k+1);

%Choose the normalization
if nargin == 2 || varargin{1} == 1
    F_hat = X*weights;
elseif varargin{1} == 2 
    weights = weights*inv(D.^.5);
    F_hat = X*weights;
end

%The loadings of the data on the factors X = LAM*F;
lam = weights';
