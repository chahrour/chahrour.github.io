function out = hac_autocov(X,m)

X = demean(X);
N = size(X,1);
hc = autocov_per(X,N,0);

for j = 1:m
   tmp = autocov_per(X,N,j);
   kj = 1-(j/(m+1));
   hc = hc + kj*(tmp + tmp'); 
end
out = hc;


function out = autocov_per(X,N,j)

 out = (1/N)*X(j+1:end,:)'*X(1:end-j,:);