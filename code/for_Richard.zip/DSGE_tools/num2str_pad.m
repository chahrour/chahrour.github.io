function out = num2str_pad(x,n)

out = num2str(x);

out = [out,' '*ones(1,n-length(out))];