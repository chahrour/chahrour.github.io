% KALMAN_GH - Compute the liklihood of the data for a model solved
% in the canonical way.
%
% usage
%
% LL = kalman_gh(g,h,eta,R,Y)
%
% where the matrices g,h,eta,R come from the model solution
%
%
% x(t+1) = h*x(t) + eta*eps(t+1)
% y(t)   = g*x(t) + w(t)
% cov(w) = R
%
% and Y is a ny-by-nt vector of observations in the data.
%
% NOTE: Also implemented in kalman_gh_mex, with a major speedup!

function [LL,sigx,Xsmooth,X11t] = kalman_gh(g,h,eta,R,Y,ndrop)

%What is observed?
obsidx = (isnan(Y)==0);

%Some parameters to store
nx = size(h,1);
ny = size(g,1);
nt = length(Y);

%Initial value for P matrix (checked against mom.m)
Q = eta*eta';
h_sq = h*h;
h_sqp = h_sq';

crit = 1;
sigx = Q;
sigg = h*Q*h' + Q;
jj = 1;
while jj<=1000 && crit>1e-12
    sigx_new = h_sq*sigx*h_sqp + sigg;
    crit = max(max(abs(sigx_new-sigx)));
    sigx = sigx_new;
    jj = jj+1;
end

%Staring the recursion
P10 = sigx;
x10 = zeros(nx,1);
LL = 0;%This is the constant term, so not in recursive sum.

%While P10 still changing, update it each time around
j = 1;
crit = 1;

Pt = zeros(nx,nx,nt);
Lt = zeros(nx,nx,nt);
Yerrt = zeros(ny,nt);
X10t = zeros(nx,nt);
Ft = zeros(ny,ny,nt);
X11t = zeros(nx,nt);
while j<=nt
    
   
    %Where are valid observations?
    obs = obsidx(:,j);
    gj = g(obs,:);
    Yj = Y(obs,j);
    Rj = R(obs,obs);

    %Forecast errors in y
    yerr = (Yj-gj*x10);                           %y(t,t-1)
    om10 = gj*P10*gj'+Rj;                               %Forcast errror of y(t,t-1)
    om10inv_yerr = (om10\yerr);

    
    %Store Pt & Lt for smoother (following notation in Durbin-Koopman here)
    Pt(:,:,j) = P10;
    Lt(:,:,j) = h - h*P10*(gj')*(om10\gj);
    Ft(obs,obs,j) = om10;
    Yerrt(obs,j) = yerr;
    X10t(:,j) = x10;
    X11t(:,j) = x10 + P10*gj'*om10inv_yerr;
    %Compute the log-liklihood if after intialization period
    if j>ndrop
        ldt = log_det(om10);
        LL = LL -1/2*(ldt+ yerr'*om10inv_yerr) - sum(obs)/2*log(2*pi);
    end

    %Iterate filter forward
    x10 = h*x10 + h*P10*gj'*om10inv_yerr;              %X(t+1,t);
    P11 = P10 - P10*gj'*(om10\gj)*P10;              %Forecast error of x(t,t);
    
    
    %Steps to skip if covergence
    %if crit > 1e-12 && sum(obs)==ny
        P10n = h*P11*h' + Q;                            %Forecast error of x(t+1,t);
        crit = max(max(abs(P10n-P10)));
        P10 = P10n;
    %end
    
    %And REPEAT the loop
    j = j+1;
    
end

%Smoothing, following page pg87 in Durbin-Koopman
rt = zeros(nx,1);
Xsmooth = zeros(nx,nt);
for j = nt:-1:1
    obs = obsidx(:,j);
    gj = g(obs,:);
    rt = gj'*(Ft(obs,obs,j)\Yerrt(obs,j)) + Lt(:,:,j)'*rt;
    Xsmooth(:,j) = X10t(:,j) + Pt(:,:,j)*rt;    
end


function out = log_det(M)
try
    out = 2*sum(log(diag(chol(M))));
catch
    out = 1000;
end

