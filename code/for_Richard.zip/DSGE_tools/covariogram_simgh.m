% COVARIOGRAM - Generate the covariogram (correlogram) for a linear DSGE model
% 
% usage
%
% out = covariogram(gx,hx,eta,nj,var,var_list,fig_title,lstyle,legend)
%
% simdat = the nvar-by-nt data
% nj = the number of period forward and backward to plot
% var = the vector indexes of the variables in the y(t) vector. If gx,hx are 3d may
%       optionally be an ny-by-nd matrix
% var_list = name of the variables plotted
% fig_title = Title for entire figure
% lstyle = a cellarray of line style (eg 'r-*' means red, stared line). '-' is default.
% legend = a cellarray of titles for each line plotted
%
% Note: correlogram/covariogram option is a parameter which is changed within the code.

function [f,sigY] = covariogram_sim(gx,hx,eta,simdat,nj,vars,var_list,fig_title,varargin)

%Change this to go for covariogram to correlellogram
cor_opt = 0;

%Counters
nv = length(vars);
nd = size(simdat,3);
nt = size(simdat,2);
%Remake vars vector to do multiple plots if it is not done already, and take prime
if (size(vars,1)==1) && (nd==1)
    %do nothing
elseif (size(vars,1)==1) && (nd>1)
    vars = repmat(vars,nd,1);
end
vars = vars';

%Combine Titles
if cor_opt
    symbol = '\rho';
else
    symbol = '\sigma';
end
titles = cell(nv^2,1);
for k = 1:nv
    for l = 1:nv
        titles{l+nv*(k-1)} = [var_list{k} ' vs. '  var_list{l}];
    end
end

%Initialize Things
sigY = cell(2*nj+1,nd);

%Compute Moments
for d = 1:nd
    idx = 1;
    for j = -nj:nj
        if ~isnan(gx(1,1,d))
            [sigY{idx,d}, sigX{idx,d}] = mom(gx(:,:,d),hx(:,:,d),eta(:,:,d)*eta(:,:,d)',j);
        else
            if j>=0
                sigY{idx,d} = 1/(nt-abs(j))*simdat(:,1:end-j,d)*simdat(:,j+1:end,d)';
            else
                sigY{idx,d} = 1/(nt-abs(j))*simdat(:,1-j:end,d)*simdat(:,1:end+j,d)';
            end
        end
        idx = idx+1;
    end
end

%Generate Output for Plotting
outmat = zeros(2*nj+1, nv^2,nd);
for d=1:nd
    for k = 1:nv
        for l = 1:nv
            for j = 1:2*nj+1
                if cor_opt
                    outmat(j, l+nv*(k-1),d) = sigY{j,d}(vars(k,d), vars(l,d))/sqrt(sigY{nj+1,d}(vars(l,d), vars(l,d))*sigY{nj+1,d}(vars(k,d), vars(k,d)));
                else
                    outmat(j, l+nv*(k-1),d) = sigY{j,d}(vars(k,d), vars(l,d));
                end

            end
        end
    end
end

f = make_figure(outmat, titles, cor_opt, fig_title, varargin{1}, varargin{2});



% Make Figure - Based on code of ir_figure.m
%
% usage
%
% fig_out = ir_fig(y,var_list, cor_opt, fig_title, lstyle(optional))
%
% where
%
% y = a TxN matrix of impulse responses
% var_list = name of the variables plotted
% fig_title = Title for entire figure
% lstyle = a cellarray of line style (eg 'r-*' means red, stared line). '-' is default.
% legend = a cellarray of titles for each IR plotted

function fig = make_figure(y, var_list, cor_opt, fig_title,  varargin)

%Create figure, set size
fig = figure;
set(fig, 'PaperOrientation','landscape', 'PaperPosition', [.25, .25, 11,8]);


%Figure dimensions
n = length(var_list);
n_col = ceil(sqrt(n));
n_row = ceil(n/n_col);
n_slide = size(y,3);  %Are the confidence bands
if size(y,2) ~= n
    error('Unequal number of columns and variable titles');
end
t = size(y,1);

%Just do forward covariogram
ndrop = (t-1)/2;
y = y(ndrop+1:end,:,:);
t = size(y,1);

%Choose Line Style
if ~isempty(varargin)
    lstyle = varargin{1};
else
    lstyle = {'-'};
end

%ylim(1) = min(min(min(y))); ylim(1)= ylim(1) - .1*max(abs(ylim));
%ylim(2) = max(max(max(y))); ylim(2)= ylim(2) + .1*max(abs(ylim));
%Plot each IR
for j = 1:n
    s = subplot(n_row,n_col,j);
    hold on
    for k = 1:n_slide
        p = plot([1:t]', y(:,j,k), lstyle{k}, 'linewidth', 2);
    end
    plot([1:t]', 0*[1:t]', ':k');
    tt = title(var_list{j}, 'fontsize', 12);

    if j ==1
        xlabel('j')
        if cor_opt
            ylabel([ '\rho(x_t, x_{t+j})']);
        else
            ylabel([ '\sigma(x_t, x_{t+j})']);
        end
    end

    set(s, 'xlim', [1,t],'Xtick', [1:4:t],'XTickLabel', [0:4:t-1]);
    %Legend
    if n_slide > 1 && ~isempty(varargin{2}) && j/n_col == 1


        l=legend(varargin{2}, 'Location', 'NorthEast', 'Fontsize', 14);
        %set(l, 'OuterPosition', [0.63 0.15 0.219 0.248], 'FontSize', 14,'Interpreter', 'tex')

        %set(l, 'location', 'southeastoutside');
        %set(l,'interpreter', 'latex', 'fontsize', 10, 'string',varargin{2});
    end
end

%Title on figure
if ~isempty(fig_title)
    suptitle(fig_title);
end


function hout=suptitle(str)
%SUPTITLE puts a title above all subplots.
%
%	SUPTITLE('text') adds text to the top of the figure
%	above all subplots (a "super title"). Use this function
%	after all subplot commands.
%
%   SUPTITLE is a helper function for yeastdemo.

%   Copyright 2003-2010 The MathWorks, Inc.


% Warning: If the figure or axis units are non-default, this
% will break.

% Parameters used to position the supertitle.

% Amount of the figure window devoted to subplots
plotregion = .92;

% Y position of title in normalized coordinates
titleypos  = .95;

% Fontsize for supertitle
fs = get(gcf,'defaultaxesfontsize')+4;

% Fudge factor to adjust y spacing between subplots
fudge=1;

haold = gca;
figunits = get(gcf,'units');

% Get the (approximate) difference between full height (plot + title
% + xlabel) and bounding rectangle.

if (~strcmp(figunits,'pixels')),
    set(gcf,'units','pixels');
    pos = get(gcf,'position');
    set(gcf,'units',figunits);
else
    pos = get(gcf,'position');
end
ff = (fs-4)*1.27*5/pos(4)*fudge;

% The 5 here reflects about 3 characters of height below
% an axis and 2 above. 1.27 is pixels per point.

% Determine the bounding rectangle for all the plots

% h = findobj('Type','axes');

% findobj is a 4.2 thing.. if you don't have 4.2 comment out
% the next line and uncomment the following block.

h = findobj(gcf,'Type','axes');  % Change suggested by Stacy J. Hills

max_y=0;
min_y=1;
oldtitle = NaN;
numAxes = length(h);
thePositions = zeros(numAxes,4);
for i=1:numAxes
    pos=get(h(i),'pos');
    thePositions(i,:) = pos;
    if (~strcmp(get(h(i),'Tag'),'suptitle')),
        if (pos(2) < min_y)
            min_y=pos(2)-ff/5*3;
        end;
        if (pos(4)+pos(2) > max_y)
            max_y=pos(4)+pos(2)+ff/5*2;
        end;
    else
        oldtitle = h(i);
    end
end

if max_y > plotregion,
    scale = (plotregion-min_y)/(max_y-min_y);
    for i=1:numAxes
        pos = thePositions(i,:);
        pos(2) = (pos(2)-min_y)*scale+min_y;
        pos(4) = pos(4)*scale-(1-scale)*ff/5*3;
        set(h(i),'position',pos);
    end
end

np = get(gcf,'nextplot');
set(gcf,'nextplot','add');
if ishghandle(oldtitle)
    delete(oldtitle);
end
axes('pos',[0 1 1 1],'visible','off','Tag','suptitle');
ht=text(.5,titleypos-1,str);set(ht,'horizontalalignment','center','fontsize',fs);
set(gcf,'nextplot',np);
axes(haold); %#ok<MAXES>
if nargout,
    hout=ht;
end



