function out = median_nan(x,pct)

if nargin<2
   pct = 0.5; 
end

out = zeros(1,size(x,2));
for jj = 1:size(x,2)
    out(jj) = median_alt(x(~isnan(x(:,jj)),jj),pct);
end


function out = median_alt(x,pct)
x = sort(x);
n = length(x);

idx_flr  = floor(pct*(n+1));
idx_ceil = ceil(pct*(n+1));

out = (x(idx_flr) + x(idx_ceil))/2;


    






