% GET_REG - Get a value from a reg object.
%
% Usage:
% get_reg(Var_object, 'item')
% know items:
% X,Y,x_bar,y_bar,n,k,beta, y_est, resid, s_sqr, var, proj, e_proj, 
% sst, ssr, r_sqr, r_sqr_adj, t, stdev

function out = get_reg(p, item)
    out = eval(['p.',item]);
end