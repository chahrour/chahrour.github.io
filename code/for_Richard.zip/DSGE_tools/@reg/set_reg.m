% SET_REG - Set value in an reg object.
%
% WARNING: Reg object is not recalculated after setting a value.
%
% Usage:
% set_reg(Var_object, 'item', value)
% knonw items:
% X,Y,x_bar,y_bar,n,k,beta, y_est, resid, s_sqr, var, proj, e_proj, 
% sst, ssr, r_sqr, r_sqr_adj, t

function out = set_reg(p, item, value)
    if strcmp('beta', item)
        p.beta = value;
    elseif strcmp('var', item)
        p.var = value;
    elseif strcmp('y_est', item)
        p.y_est = value;
    elseif strcmp('resid', item)
        p.resid = value;
    elseif strcmp('t' , item)
        p.t = value;
    else
        error('Invalid set option.');
    end
    out = p;
end