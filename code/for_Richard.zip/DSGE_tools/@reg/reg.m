% REG - Creates a regression object with given data
%
% This object creates a linear regression with the given data
% preferences.
%
% Usage:
% p = reg(Y,X,Y_label, X_label, print_opt)


function p = reg(Y,X,varargin)
%Default VAR Names



%Handle input args

if ~isempty(varargin)
    if ~isempty(find_exact(varargin{1}, 'to screen to printer no print fast'))
        print_opt = varargin{1};

        %Make variables names
        %warning('No variable names assigned or no data entered.  Variables will named automatically.');
        Y_label = 'Depedent Variable';
        X_label = {'Var1' ,'Var2' ,'Var3', 'Var4', 'Var5', 'Var6', 'Var7' ,'Var8', ...
            'Var9','Var10', 'Var11' ,'Var12', 'Var13', 'Var14', 'Var15', 'Var16','Var17',...
            'Var18' ,'Var19', 'Var20', 'Var21', 'Var22', 'Var23','Var24', 'Var25',
            'Var1' ,'Var2' ,'Var3', 'Var4', 'Var5', 'Var6', 'Var7' ,'Var8', ...
            'Var9','Var10', 'Var11' ,'Var12', 'Var13', 'Var14', 'Var15', 'Var16','Var17',...
            'Var18' ,'Var19', 'Var20', 'Var21', 'Var22', 'Var23','Var24', 'Var25',
            'Var1' ,'Var2' ,'Var3', 'Var4', 'Var5', 'Var6', 'Var7' ,'Var8', ...
            'Var9','Var10', 'Var11' ,'Var12', 'Var13', 'Var14', 'Var15', 'Var16','Var17',...
            'Var18' ,'Var19', 'Var20', 'Var21', 'Var22', 'Var23','Var24', 'Var25',
            'Var1' ,'Var2' ,'Var3', 'Var4', 'Var5', 'Var6', 'Var7' ,'Var8', ...
            'Var9','Var10', 'Var11' ,'Var12', 'Var13', 'Var14', 'Var15', 'Var16','Var17',...
            'Var18' ,'Var19', 'Var20', 'Var21', 'Var22', 'Var23','Var24', 'Var25'};
        number = min(100,size(X,2));
        X_label = X_label(1:number);
        for i = 100:size(X,2)
            X_label = add_str(X_label, ['Variable_',num2str(i)]);
        end
      
    else
        if size(varargin,2) == 1
            Y_label = varargin{1};
            X_label= {};
            for i = 1:size(X,2)
                X_label = add_str(X_label, ['Variable_',num2str(i)]);
            end
            print_opt = 'no print';
        elseif size(varargin,2) == 2
            Y_label = varargin{1};
            X_label = varargin{2};
            print_opt = 'no print';
        else
            Y_label = varargin{1};
            X_label = varargin{2};
            print_opt = varargin{3};


        end
    end
else
    %Make variables names
%    warning('No variable names assigned or no data entered.  Variables will named automatically.');
    Y_label = 'Depedent Variable';
    X_label= {};
    for i = 1:size(X,2)
        X_label{end+1} = ['Variable_',num2str(i)];
    end
    print_opt = 'to screen';
end



%Check incoming data constant
one = 0;
if ~strcmp(print_opt, 'fast')       %Bypass for Fast Regressions
for j = 1:size(X,2)
    if sum(X(:,j))==size(X,1)
        one = 1;
    end
end
if one ~= 1
    %warning('Regression does not contain a constant.');
    add = 0;%input('Enter 1 to include a constant: ');
    if add == 1
        X = [ones(size(X,1),1), X];
        if ~isempty(X_label)
            X_label = concat_cell('const', X_label, 1);
        end
    end
end
end


if ~strcmp(print_opt, 'fast')

    %Creat inv(X'X) for future use
    invXX = inv(X'*X);


    %Unrestricted by Default
    struct.restricted = 0;

    %Save input data
    struct.Y = Y;
    struct.X = X;
    struct.Y_label = Y_label;
    struct.X_label = X_label;

    %Summary Data
    struct.x_bar = mean(X);
    struct.y_bar = mean(Y);
    struct.n = size(X,1);
    struct.k = size(X,2);
  %(X'*Y)

    %Calculate Relevant Values
    struct.beta = (X'*X)\(X'*Y);
    struct.y_est = struct.X*struct.beta;

    struct.resid = struct.Y  - struct.y_est;
    struct.s_sqr = (struct.resid'*struct.resid)/(size(X,1) -size(X,2));
    struct.var = struct.s_sqr*invXX;

    struct.proj = NaN;%X*(invXX)*X';         %Projection Matrix
    struct.e_proj = NaN;%eye(size(struct.proj,1)) - struct.proj; %Residual Maker

    %Wait to calculate partial correlation until we have t stat

    %R squared stuff
    struct.sst = deviation(Y)'*deviation(Y);        %Could be written in numerous ways
    struct.ssr = deviation(struct.y_est)'* deviation(struct.y_est);
    struct.r_sqr = struct.ssr/struct.sst;
    struct.r_sqr_adj = 1 - (struct.n-1)*(1-struct.r_sqr)/(struct.n - struct.k);


    % t-stat stuff
    struct.t = ones(size(struct.var,1),1);
    struct.stdev = ones(size(struct.var,1),1);
    for i = 1:size(struct.var,1)
        struct.t(i) = struct.beta(i)/(struct.var(i,i)).^.5;
        struct.stdev(i) = (struct.var(i,i)).^.5;
    end
    struct.fitted_var  = 0;%diag(struct.X*invXX*struct.X')
    
else
    
    %Fast Reg allows user to ignore expensive calculations
    %Unrestricted by Default
    struct.restricted = 0;

    %Save input data
    struct.Y = Y;
    struct.X = X;
    struct.Y_label = 0;
    struct.X_label = 0;

    %Summary Data
    struct.x_bar = 0;
    struct.y_bar = 0;
    struct.n = 0;
    struct.k = 0;
    
  
    
    struct.beta = (X'*X)\(X'*Y);
   struct.y_est = struct.X*struct.beta;

    struct.resid = struct.Y  - struct.y_est;
   
    struct.s_sqr = 0;
  
    struct.var = 0;
    struct.proj = 0;         %Projection Matrix
    struct.e_proj =0; %Residual Maker
   
    struct.sst = 0;
    struct.ssr = 0;
    struct.r_sqr =0;
    struct.r_sqr_adj =0;

    % t-stat stuff
    struct.t = 0;
    struct.stdev = 0;
    struct.fitted_var  = 0;

    
    %Fields added to keep the fields the constant

end



p = class( struct, 'reg');

if strcmp (print_opt, 'to screen')
    print_reg(p);
elseif strcmp (print_opt, 'to printer')
    pub_reg(p, print_opt);
end
