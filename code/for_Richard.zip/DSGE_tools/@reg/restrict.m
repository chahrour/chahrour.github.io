% RESTRICT - Restrict a regression object using Rx = b form
%
% This function will take a reg object and modify it to give the restricted
% equation. You are asked to enter as many restricitions as you'd likem up to K,
% the number of independent variables).
% 
% You may also simply enter as arguments the matrix R and vector q, if you know the order of variable
% in the regression. To use this option, enter one as the second argument
% in the function call.
%
% Usage:
% restrict(regression, 1) %Prompt for restrictions
% restrict(regression, [ 1 1 1] , 0, [1 0 1], 0) %Test multiple restrictions

function out =  restrict(struct, varargin)

if size(varargin,2) == 1
    if varargin{1} == 1
        %Enter restriction manually
        R = input('Enter the matrix R:');
        q = input ('Enter the matrix q:');
    elseif varargin == 0
        %Test if entire regression is signficant
        R = ones(1,size(reg.beta,1));
        q = 0;
    end
elseif size(varargin,2) ==0
    %Test if entire regression is signficant
    R = ones(1,size(struct.beta,1));
    q = 0;
else
    %try
    for i= 0:(size(varargin,2)/2)-1
        R(i+1,:) = varargin{2*i+1};
        q(i+1) = varargin{2*i+2};
    end
    %         catch
    %             error('Improper input arguments: must input R matrix then q vector.');
    %         end
end



%Calculate Relevant Values - Formulas given by Perron(2002) Notes
X = struct.X;
Y = struct.Y;
%Re-estimate Beta
D = R*inv(X'*X)*R';
unres_beta = struct.beta;
struct.beta = unres_beta  + inv(X'*X)*R'*inv(D)*(q-R*unres_beta);

struct.y_est = struct.X*struct.beta;

struct.resid = struct.Y  - struct.y_est;

%we use the restricted estimate of sigma squared, as per Judge et al,
%(1988)  Not convinced this always makes sense.
unres_var = struct.var ;
struct.s_sqr = (struct.resid'*struct.resid)/(size(X,1) -size(X,2)+size(R,1));
struct.var = struct.s_sqr*inv(X'*X) - struct.s_sqr*inv(X'*X)*R'*inv(D)*R*inv(X'*X);

%These two values are not really correct.  The projection matric idea would
%need to be modified however, since we have limited the column space.  To
%be continued.
struct.proj = X*(inv(X'*X))*X';         %Projection Matrix
struct.e_proj = eye(size(struct.proj,1)) - struct.proj; %Residual Maker


%R squared stuff
struct.sst = deviation(Y)'*deviation(Y);        %Could be written in numerous ways
%struct.ssr = (struct.y_est - mean(Y))'*(struct.y_est - mean(Y));

struct.ssr = deviation(struct.y_est)'* deviation(struct.y_est);
%struct.r_sqr = struct.ssr/struct.sst;
struct.r_sqr = 1-(struct.resid'*struct.resid)/(deviation(Y)'*deviation(Y));
struct.r_sqr_adj = 1 - (struct.n-1)*(1-struct.r_sqr)/(struct.n - struct.k);


% t-stat stuff
struct.t = ones(size(struct.var,1),1);
for i = 1:size(struct.var,1)
    struct.t(i) = struct.beta(i)/(struct.var(i,i)).^.5;
end
struct.fitted_var  = diag(struct.X*inv(struct.X'*struct.X)*struct.X');
struct.restricted = 1;
out = struct;