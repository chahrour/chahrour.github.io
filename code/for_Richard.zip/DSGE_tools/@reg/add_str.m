% ADD_STR - Adds string to cell array of strings
% Usage:
% new_str = add_str(old_cell_array, new_str) or reversed to add to front
function new_cell = add_str(old, new_str)
if iscellstr(old)
    length = size(old,2);
    old{length+1} = new_str;
    new_cell = old;
elseif iscellstr(new_str)       %The reverse case
    new_cell{1} = old;
    for i = 1:size(new_str,2)
    new_cell{i+1} = new_str{i};
    end
else
    new_cell{1} = old;
    new_cell{2} = new_str
    
end