% DW - Gives the durbin watson statistic for the regression.
% Usage:
% [durb, rho] = DW(reg)
% where
% reg = a regression object
% durb = the DW test stat
% row = an estimate of the 1st order autocorrelation coefficient.

function [durb, rho] = DW(regr)
    resid = get_reg(regr, 'resid');
    dif = resid(2:end) - resid(1:end-1);  %Take e(t) - e(t-1);
    sse = sum(resid.^2);                       %Sum Sqr residuals
    durb = sum(dif.^2)/ sse;
    
    %Calc rho using Greene,expression 12-23
    rho = .5 * (2- (resid(1)^2+resid(end)^2)/sse - durb); 
end
    
                                             
                                                      
    
    