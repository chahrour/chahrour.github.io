% FIT_VAR - Returns the variance of the (in sample) fitted values for the regression.
%
% Usage:
% series = fit_var(reg_object)


function series = fit_var(p)

a = get_reg(p, 'fitted_var');
b = get_reg(p, 's_sqr');
resids = get_reg(p, 'resid')

series =[resids, resids./((b*(1-a)).^.5)]
