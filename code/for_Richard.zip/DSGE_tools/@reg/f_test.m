% F_TEST - Performs an f test using Rx = b form
%
%This function will take a reg object and perform the requested f-test.
% The test is performed in the traditional R*beta = q form. 
% You are asked to enter as many restricitions as you'd likem up to K,
% the number of independent variables).
% 
% You may also simply enter the matrix R and vector q, if you know the order of variable
% in the regression. To use this option, enter one as the second argument
% in the function call.
%
% Usage:
% f_test(regression)  %Test significance of entire regression
% f_test(regression, 1) %Prompt for restrictions
% f_test(regression, [ 1 1 1] , 0, [1 0 1], 0) %Test multiple restrictions

function [stat per] = f_test(reg, varargin)

if size(varargin,2) == 1
    if varargin{1} == 1
        %Enter restriction manually
        R{1} = input('Enter the matrix R:');
        q{1} = input ('Enter the matrix q:');
    elseif varargin == 0
        %Test if entire regression is signficant
        R{1} = ones(1,size(reg.beta,1));
        q{1} = 0;
    end
elseif size(varargin,2) ==0
    %Test if entire regression is signficant
    R{1} = ones(1,size(reg.beta,1));
    q{1} = 0;
else
    %try
    for i= 0:(size(varargin,2)/2)-1
        R{i+1} = varargin{2*i+1};
        q{i+1} = varargin{2*i+2};
    end
    %         catch
    %             error('Improper input arguments: must input R matrix then q vector.');
    %         end
end


%Formula from p97 of Greene
df_R = zeros(1,size(R,2));
for i =1:size(R,2);
   
    stat{i} =(1/size(R{i},1)) ;
    b = (R{i}*reg.beta-q{i});
    c = inv(R{i}*(reg.s_sqr*inv(reg.X'*reg.X))*R{i}');
    stat{i} = b'*c*b *stat{i};
    
    %Degrees fredom numerator
% Old == Wrong?
%     temp = R{i}>0;
%     df_R(i)= sum(temp);

df_R(i)= size(R{i},1);
end

%Fix to be safe
stat2 = zeros(1,size(stat,2));
for i = 1:size(stat,2)
    stat2(i) = stat{i};
end

%DF denominator
dfd = reg.n - reg.k;
per = fdis_cdf(stat2, df_R, dfd);