% STD_RESID - Returns the standardized residuals.
%
% Usage:
% series = std_resid(reg_object) 

function series = std_resid(p)

a = get_reg(p, 'fitted_var');
b = get_reg(p, 's_sqr');
resids = get_reg(p, 'resid');

series =[resids./((b*(1-a)).^.5)];
