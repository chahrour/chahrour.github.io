% DEVIATION - Takes a vector or matrix and returns the deviation from the mean
% along columns.
% Usage
% deviation = dev(X)

function dev = deviation(x)

try
    dev = x-mean(x);
catch
    n = size(x,1);
    % Calculate m matrix
    M = eye(n) - (1/n)*ones(n,1)*(ones(1,n));
    dev = M*x;
end