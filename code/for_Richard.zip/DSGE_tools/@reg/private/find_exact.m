%FIND_EXACT - This function searches for an exact string match in a longer 
%string. Thus if two pieces match, but if the second "word" (delimited by a 
%space) contains the first, but is not the same, will return false.
%Usage:
%find_exact('hello', 'hellothere') - returns []
%find_exact('hello', 'hello there hello') - returns [1 12]
function b = find_exact(str1, str2)
b = [];
sz = size(str1,2);
match = findstr(str1, str2);

for i = 1:size(match,2)
    if match(i) == 1 | strcmp(str2(match(i)-1), ' ')
    if match(i)+sz > size(str2,2) | strcmp(str2(match(i)+sz), ' ')
        b = [b, match(i)];
    end
    end
end