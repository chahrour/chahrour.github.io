% QUICK_OLS - Estimate a lagged model using OLS. The model is written as
%
%         y(t) = [x(t) x(t-1) x(t-2) ... x(t-nlag)]*beta + mu(t)
%
% usage
%
% [beta, c, mu] = quick_ols(Y,nlag)
%
% where
%


function [beta, mu,X,beta_full] = quick_ols(Y,XX,nlag,dummy)

%Number of Variables
nvar = size(XX,2);
T = length(XX)-nlag;
const = 1;

if nargin<4
    dummy = [];
end

%*****************
% Arrange Data
%*****************

%Stack lagged X
X = zeros(T, nlag*nvar);
for j =1:nlag
    X(:, (j-1)*nvar+1:j*nvar) = XX(nlag+1-j:end-j,:);
end

%Include a constant in VAR
X = [X, ones(length(X),const),dummy(nlag:end-1,:)];

%Exclude lags from DY
YY = Y(nlag:end-1,:);



%*********************************************
% Regress, get covariance matrix and cholesky
%*********************************************

%VAR coefficients, stderrs, etc
beta = X\YY;

%In case any missing values
for jj = 1:size(YY,2)
   Ytmp = YY(:,jj);
   kp_idx = ~isnan(Ytmp);
   beta(:,jj) = X(kp_idx,:)\Ytmp(kp_idx);
end

mu = YY - X*beta;
omega = (mu'*mu)/(T-1);
beta_full = beta;
beta = beta(1:end-const-(nargin>3),:);

