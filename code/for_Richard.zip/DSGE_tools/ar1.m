function out = ar1(x)

out = nan(1,size(x,2));

for jj =1:size(x,2)
 

    yy = x(2:end,jj);
    xx = [ones(size(x,1)-1,1),x(1:end-1,jj)];

    bb = xx\yy;
 %   bb = inv(xx'*xx)*(xx'*yy)
    out(jj) = bb(2);

end
