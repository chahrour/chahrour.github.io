function out = nancorr(x,y)
x = x(:);
y = y(:);

idx1 = ~isnan(x);
idx2 = ~isnan(y);

idx = (idx1+idx2)==2;

x = x-mean(x(idx));
y = y-mean(y(idx));

out = (x(idx)'*y(idx))/sqrt((x(idx)'*x(idx))*(y(idx)'*y(idx)));

