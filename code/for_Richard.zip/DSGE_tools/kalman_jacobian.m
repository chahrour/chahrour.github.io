% KALMAN_JACOBIAN - Compute the liklihood of the data for a model solved
% in the canonical way. This version also compute the jacobian of the
% liklihood anaytically.
%
% usage
% 
% [LL dLL] = kalman_gh(g,h,eta,R,Y,dsigx,dh,dg,dn,dr)
%
% where the matrices g,h,eta,R come from the model solution
%
%
% x(t+1) = h*x(t) + eta*eps(t+1)
% y(t)   = g*x(t) + w(t)
% cov(w) = R
%
% and Y is a ny-by-nt vector of observations in the data.

function [LL,dLL] = kalman_jacobian(g,h,eta,R,Y,ndrop,dsigx,dh,dg,dn,dr)


%Some parameters to store
nx = size(h,1);
ny = size(g,1);
nt = length(Y);
neps = size(eta,2); 
nparam= size(dr,2);


%Some other things for repeated use
kgg = kron(g,g);
kgh = kron(g,h);
khh = kron(h,h);

iy = eye(ny);
ix = eye(nx);
ixx = eye(nx*nx);
ixy = eye(nx*ny);
iyy = eye(ny*ny);

Txy = commute(nx,ny);
Txx = commute(nx,nx);
Tyx = Txy';

%Some derivatives for repeated use
dgg = kron(kron(ix,Txy),iy)*(kron(ixy,g(:)) + kron(g(:),ixy))*dg;
dhh = kron(kron(ix,Txx),ix)*(kron(ixx,h(:)) + kron(h(:),ixx))*dh;
dgh = kron(kron(ix,Txy),ix)*(kron(ixy,h(:))*dg + kron(g(:),ixx)*dh);
dnn = (ixx+Txx)*kron(ix,eta)*dn;


kici = kron(kron(iy,Tyx),ix);

%Initial value for P matrix (checked against mom.m)
Q = eta*eta';
h_sq = h*h;
h_sqp = h_sq';

crit = 1;
sigx = Q;
sigg = h*Q*h' + Q;
while crit>1e-15
   sigx_new = h_sq*sigx*h_sqp + sigg;
   crit = max(max(abs(sigx_new-sigx)));
   sigx = sigx_new;
end

%Staring the recursion
P10 = sigx;
x10 = zeros(nx,1);
LL = -(nt-ndrop)/2*ny*log(2*pi); %This is the constant term, so not in recursive sum.
dLL = 0;

dP10 = dsigx;
dx10 = zeros(nx,nparam);

%While P10 still changing, update it each time around
j = 1;
crit = 1;

while crit > 1e-18 && j<=nt 
    
   %Forecast errors in y
   yerr = (Y(:,j)-g*x10);                           %y(t,t-1)
   om10 = g*P10*g'+R;                               %Forcast errror of y(t,t-1)
  
   yom = yerr'/om10;
   
   %Compute the derivative of the key terms
   dgx10  = kron(x10',iy)*dg + g*dx10;  %d g*x(t,t-1)
   dgpg_r = kgg*dP10 + kron(P10(:)',iyy)*dgg + dr;%d (gPg'+R)
   dgpg_inv = -(kron(om10',om10)\dgpg_r);

   %Compute the log-liklihood
   if j > ndrop
       LL = LL -1/2*(log_det(om10) + yerr'*yom') ;
       
       %Compute the derivative of the log-liklihood
       dLL = dLL -1/2*(vec(inv(om10))'*dgpg_r -2*yom*dgx10 + kron(yerr',yerr')*dgpg_inv) ; %the rest
   end
   %Iterate derivatives forward...
   hpg = h*P10*g';
   vhpg = vec(hpg);
   dhpg = kron(P10(:)',ixy)*dgh + kgh*dP10;
   dhpghpg = kici*(kron(ixy,vhpg)+kron(vhpg,ixy))*dhpg;
   dP10 = khh*dP10 + kron(vec(P10)', ixx)*dhh - ...
            kron(hpg,hpg)*dgpg_inv - ...
            kron(vec(inv(om10))', ixx)*dhpghpg + ...
            dnn; 
   dx10 = kron(x10',ix)*dh + h*dx10 - (hpg/om10)*dgx10 + kron(yom,ix)*dhpg + kron(yerr',hpg)*dgpg_inv;
  
   %Iterate filter forward
   x10 = h*x10 + h*P10*g'*(om10\yerr);              %X(t+1,t);
   P11 = P10 - P10*g'*(om10\(g*P10));               %Forecast error of x(t,t);
   P10n = h*P11*h' + Q;                             %Forecast error of x(t+1,t);
   
   %Update derivatives for next round, lots of steps to go here  
   crit = max(max(abs(P10n-P10)));
   P10 = P10n;
   
   %And REPEAT the loop
   j = j+1;
 
end

%Once P10 has converged, we cans stop updating the FEV's and some related
%terms
ldetom = log_det(om10);
hP10gp_om = (h*P10*g')/om10;
for ii = j:nt
    
   %Forecast errors in y
   yerr = (Y(:,ii)-g*x10);                           %y(t,t-1)
   yom = yerr'/om10;

   %Compute the derivative of the key terms
   dgx10  = kron(x10',iy)*dg + g*dx10;
   
   if j > ndrop
       %Compute the log-liklihood
       LL = LL -1/2*(ldetom + yerr'*yom');
       
       %Compute the derivative of the log-liklihood
       dLL = dLL -1/2*(vec(inv(om10))'*dgpg_r -2*yom*dgx10 + kron(yerr',yerr')*dgpg_inv) ; %the rest
   end
   
   %Iterate derivatives forward...
   dx10 = kron(x10',ix)*dh + h*dx10 - (hpg/om10)*dgx10 + kron(yom,ix)*dhpg + kron(yerr',hpg)*dgpg_inv;
  
   %Iterate filter forward
   x10 = h*x10 + hP10gp_om*yerr;                     %X(t+1,t);
end

function out = vec(X)
out = X(:);


function out = log_det(M)
try
    C = chol(M);
    V = diag(C);
    out = 2*sum(log(V));
catch
    out = 1000;
end