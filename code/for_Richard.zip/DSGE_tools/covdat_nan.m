function out = covdat_nan(X,j)

X = demean(X')';
nx = size(X,1);
out = zeros(nx,nx);

for ii = 1:nx
    for kk = 1:nx
        tmp = X(ii,1:end-j).*X(kk,j+1:end);
        idx = ~isnan(tmp);
        out(ii,kk) = sum(tmp(idx))/sum(idx);   
    end
end