%Compute the liklihood, to be used for numerical differentiation...

function out = veckal(param,set,S)

[f fx fy fxp fyp eta R set]=model_prog(param,set);

[gx,hx,flag]=gx_hx_alt(fy,fx,fyp,fxp);

nx = size(hx,2);
ny = size(gx,1);

if flag ~= 1
    out = -randn(size(S,1)^2,1);
else
    
    [out] = mom(S*gx,hx,eta*eta');
    %out = vec(hx);
    %out = vec([fxp,fyp,fx,fy]);
end
out = vec(out);


