%Plug in the mean and sttdev you want, and get back the two parameters of the beta distribution

function [shape,scale] = beta_params(mu, stdd)

% options = optimset('fsolve');
% options = optimset(options, 'display', 'off');
% f = @(alph) alph^2*(1-mu)/((alph + alph*(1-mu))^2*(alph + alph*(1-mu)+1))-stdd^2;
% alph = fsolve(f, 1,options);
% bet = alph*(1-mu);


bet = (1-mu)^2*mu/(stdd^2) - (1-mu);

alph = bet*mu/(1-mu);

shape = alph;
scale = bet;


