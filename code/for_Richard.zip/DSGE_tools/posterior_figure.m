function f = posterior_figure(pchain,prior,param_list,varargin)
nparam = size(pchain,1);

f = figure;
set(f, 'paperposition', [.25 .25 10.5 8]);
if nargin>4
    jvec = varargin{2};
else
    jvec = 1:nparam;
end

nparam = length(jvec);
ncol = ceil(sqrt(nparam));
nrow = ceil(nparam/ncol);

nparam

ll = 0;
for j = jvec
    ll = ll+1;
    lbnd = min(prior{j}.xgrid);
    ubnd = max(prior{j}.xgrid);
    [~, dens,xmesh] = kde(pchain(j,:)',1.5^10,lbnd,ubnd);
    s = subplot(nrow,ncol,ll);  hold on
    plot(prior{j}.xgrid, prior{j}.ygrid, '--', 'linewidth', 2);
    plot(xmesh,dens, 'linewidth', 1', 'color', 'r');
    
    %Plot vert lines
    if nargin>3 && ~isempty(varargin{1})
        ylim = get(s, 'ylim');
        plot([varargin{1}(j), varargin{1}(j)], [ylim(1), ylim(2)], 'color', 'k', 'linestyle', '--');
        set(s, 'ylim', [ylim(1), ylim(2)]);
    end
    set(s, 'xlim', [lbnd,ubnd], 'ylim', [0,1.03*max(dens)],'ytick', []);
    
    
    title(param_list{ll}, 'fontsize', 12, 'Interpreter', 'LaTeX');   %New
   % title(param_list{j}, 'fontsize', 14, 'Interpreter', 'LaTeX');

end

%legend('Prior', 'Posterior', 'location', 'NorthEast')