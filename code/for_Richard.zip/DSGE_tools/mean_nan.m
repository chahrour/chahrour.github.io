function out = mean_nan(X)


out = zeros(size(X,1),size(X,2));

for jj = 1:size(X,1)
    for kk = 1:size(X,2)
        idx = ~isnan(X(jj,kk,:));
        out(jj,kk) = mean(X(jj,kk,idx),3);
    end
end