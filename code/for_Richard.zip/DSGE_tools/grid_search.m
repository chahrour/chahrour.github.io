%grid_search(f,start,lb,ub,n)

function [param_final,final,vals,pmat] = grid_search(f,lb,ub,n)

np = length(lb);
grid_vals = cell(1,np);
for jj = 1:np
   grid_vals{jj} = linspace(lb(jj),ub(jj),n); 
end


[grid_vals{:}] = ndgrid(grid_vals{:});

nel = n^np;

pmat = zeros(nel,np);

for jj = 1:np
   pmat(:,jj) = grid_vals{jj}(:); 
end

vals = zeros(1,nel);
parfor jj = 1:nel
   disp(num2str(jj));
   paramv = pmat(jj,:); 
   vals(jj) = f(paramv); 
end

[final,fmin_idx] = min(vals);

param_final = pmat(fmin_idx,:); 


