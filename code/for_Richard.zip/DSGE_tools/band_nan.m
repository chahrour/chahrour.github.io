function [low,high]= band_nan(X)


low = zeros(size(X,1),size(X,2));
high = zeros(size(X,1),size(X,2));
for jj = 1:size(X,1)
    for kk = 1:size(X,2)
        idx = ~isnan(X(jj,kk,:));
        tmp = sort(squeeze(X(jj,kk,idx)));
        low(jj,kk)  = tmp(3);
        high(jj,kk) = tmp(end-2);
    end
end