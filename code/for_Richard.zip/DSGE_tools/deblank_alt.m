function out = deblank_alt(in)

out = deblank(in);

if iscell(out)
out = out{1};
end