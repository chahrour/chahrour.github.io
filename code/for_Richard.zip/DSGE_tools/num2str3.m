function out = num2str3(x,ndec,nchar)

if nargin<2
    ndec = 7;
end
out = sprintf(['%1.' num2str(ndec), 'f\t'], x);

if nargin>2
    out = deblank(out);
    out = [out(1:min(end,nchar)),' '*ones(1,nchar-length(out))];
end

end