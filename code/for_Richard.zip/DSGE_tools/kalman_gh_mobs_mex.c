#include <math.h>
#include "mex.h"
#include "clapack.h"
#include "cblas.h"
#include <stdlib.h>


/* Input Arguments */

#define	G_IN	prhs[0]
#define	H_IN	prhs[1]
#define	eta_IN	prhs[2]
#define	R_IN	prhs[3]
#define	Y_IN	prhs[4]
#define	N_DROP_IN	prhs[5]

/* Output Arguments */

#define	LL_OUT	plhs[0]

#if !defined(MAX)
#define	MAX(A, B)	((A) > (B) ? (A) : (B))
#endif

#if !defined(MIN)
#define	MIN(A, B)	((A) < (B) ? (A) : (B))
#endif
static double p2 = 2*3.141592653589793238462643;

/* Prints an MxN matrix to Screen*/
void printmat_rowmaj(int m, int n, double M[m*n]){
    int x,y;
    int k = 0;
    printf("\n");
    for(x=0;x<m;x++){
        for(y=0;y<n;y++){
            printf("%1.3lf\t", M[k]);
            k++;
        }
        printf("%\n");
    }
    return;
}

/* Prints an MxN matrix to Screen*/
void printmat_colmaj(int m, int n, double M[m*n]){
    int x,y;
    printf("\n");
    for(x=0;x<m;x++){
        for(y=0;y<n;y++){
            printf("%1.7lf\t", M[y*m+x]);
        }
        printf("%\n");
    }
    return;
}

/* Prints an MxN matrix to Screen*/
void print_2darray(int m, int n, double M[m][n]){
    int x,y;
    printf("\n");
    for(x=0;x<m;x++){
        for(y=0;y<n;y++){
            printf("%1.3lf\t", M[x][y]);
        }
        printf("%\n");
    }
    return;
}


/*Prints a dim(N) vector to screen.*/
void print_dvec(int n, double M[]){
    int x;
    printf("\n");
    for(x=0;x<n;x++){
        printf("%1.4lf\t", M[x]);
    }
    printf("\n");
    return;
}

/*Prints a dim(N) vector to screen.*/
void print_ivec(int n, int M[]){
    int x;
    printf("\n");
    for(x=0;x<n;x++){
        printf("%i\t", M[x]);
    }
    printf("\n");
    return;
}

void subset_copy(int start_idx, int nx, double X[], double Y[nx]){
    int i = 0;
    for(i=0;i<nx;i++){
        Y[i] = X[start_idx+i];
    }
}

/*Compute the Determinant of a Pos-Def Matrix*/
double log_det(int nx, double M[nx*nx]){
    
    double out=0;
    
    /*Counters, Temp matrix*/
    int j;
    int nxnx = nx*nx;
    double C[nxnx];
    
    /*LAPACK Input Args*/
    char uplo ={'u'};
    __CLPK_integer n_x = nx;
    __CLPK_integer info;
    
    /*Copy matrix and take cholesky*/
    cblas_dcopy(nxnx, M, 1, C, 1);
    dpotrf_(&uplo, &n_x, C, &n_x, &info);
    
    
    /*Get Sum of log Diagonal */
    for(j=0;j<nx;j++){
        out = out+2*log(C[j*nx+j]);
    }
    
    
    /*Return*/
    return out;
}

/* Repear a matrix over and over*/
int repmat(int n_row, int n_col, int n_rep,double *F_, double *F){
    
    int x;
    int y;
    int n;
    int k;
    
    
    for (n=0;n<n_rep;n++) {
        k = 0;
        for (y=0;y<n_col;y++) {
            for (x=0;x<n_row;x++){
                F_[n*n_row*n_col + k] = F[k];
                /*printf("%lf\n", F[n_col*y + x]);*/
                k++;
            }
        }
    }
    return 0;
}

/*Sum the columns of a matrix*/
int col_sum(int m, int n, double *M_, double *M){
    int i,j;
    
    for (j=0;j<m;j++){
        M[j] = 0;
        for (i=0;i<n;i++)	M[j] += M_[j*m+i];
    }
    return 0;
}

/*Subtract two vectors*/
void v_sub(int n, double *M, double *M2, double *M_out){
    int j;
    for (j=0;j<n;j++) M_out[j] = M[j] - M2[j];
}


void lpack_test(int nx, int ny, int nt, int ndrop, double *G, double *H, double *Q, double *R, double *Y, double ll_tmp[]) {
    
    /*Matric Dimensions*/
    int nxnx = nx*nx;
    int nyny = ny*ny;
    int nxny = nx*ny;
    int one = 1;
    /*Arguments for CLAPACK*/
    __CLPK_integer n_y  = ny;
    __CLPK_integer n_x  = nx;
    __CLPK_integer info = 0;
    char uplo ={'l'};
    
    /*Variables used to compute LL*/
    double ll = 0;
    double detHPR = 0;
    double expval = 0;
    double tmp = 0;
    
    /*Counters Used for Loops*/
    int tt = 1;
    int jj = 1;
    int kk;
    int rr;
    
    double LL = 0;//-.5*nt*ny*log(p2); //Initialize with constant term included.
    
    
    double P10[nxnx];
    double P11[nxnx];
    double P10n[nxnx];
    double hP11[nxnx];
    double om10[nyny];
    double sigg[nxnx];
    double sigx[nxnx];
    double x10[nx];
    double yerr[ny];
    double omyerr[ny];
    double omgP[nxny];
    
    double P10_tmp[nxnx];
    double gP10[nxny]; //the first portion of the multiplication
    double sigg_tmp[nxnx];
    double sigx_tmp[nxnx];
    double sigx_tmp2[nxnx];
    double x10_tmp[nx];
    double yerr_tmp[ny];
    double om10_hold[nyny];
    
    double P10gomy[nx];
    
    
    /*Variables added for missing data functionality*/
    double Gj[ny*nx];
    double Rj[ny*ny];
    double Yj[ny];
    double yerrj[ny];
    double tmpv;
    int nyj;
    __CLPK_integer n_yj;
    /********************************
     * Intialize P0
     * ********************************/
    double crit = 1;
    
    double H_sq[nxnx];
    
    //h_sq = h*h
    cblas_dgemm(CblasColMajor, CblasNoTrans, CblasNoTrans, nx, nx, nx, 1, H, nx, H, nx, 0, H_sq, nx);
    
    
    //sigg = h*Q*h'
    cblas_dcopy(nxnx, Q, 1, sigg, 1); //sigg = Q
    cblas_dgemm(CblasColMajor, CblasNoTrans, CblasNoTrans, nx, nx, nx, 1, H, nx, Q, nx, 0, sigg_tmp, nx); //h*Q
    cblas_dgemm(CblasColMajor, CblasNoTrans, CblasTrans, nx, nx, nx, 1, sigg_tmp, nx, H, nx, 1, sigg, nx);//sigg = h*Q*h +Q
    
    //Loop to get sigx
    cblas_dcopy(nxnx,Q,1,sigx,1);
    
        
    while(jj<1000 && crit > pow(10,-15)){
        cblas_dcopy(nxnx,sigg,1,sigx_tmp,1);
        cblas_dgemm(CblasColMajor, CblasNoTrans, CblasNoTrans, nx, nx, nx, 1, H_sq, nx, sigx, nx, 0, P10_tmp, nx); //h*sigx
        cblas_dgemm(CblasColMajor, CblasNoTrans, CblasTrans, nx, nx, nx, 1, P10_tmp, nx, H_sq, nx, 1, sigx_tmp, nx); //h_sq*sigx*h_sq'+sigg
        
        
        //compute convergence crit
        cblas_dcopy(nxnx,sigx_tmp,1,sigx_tmp2,1);
        cblas_daxpy(nxnx,-1,sigx,1,sigx_tmp2,1); //sigx-sigx_tmp2
        crit = cblas_dasum(nxnx,sigx_tmp2,1);
        //printf("%1.7lf\n", crit);
        //Copy over the new result to sigx
        cblas_dcopy(nxnx,sigx_tmp,1,sigx,1);
        jj++;
    }
   
    //Copy over sigx to P10
    cblas_dcopy(nxnx,sigx,1,P10,1);
    
    //Intialize x0, find a better way
    for (jj=0;jj<nx;jj++){x10[jj]=0;}
    
    /********************************
     * Start the Kalman Filter
     * ********************************/
    int t = 0;
    crit = 1;
    //while (crit > pow(10,-18) && t < nt){
    while (t < nt){
        rr = 0;
        nyj = 0;
        for(kk=0;kk<ny;kk++){
            tmpv = Y[t*ny+kk];
            if (tmpv == tmpv){
                nyj++;
                }
        }

        for(kk=0;kk<ny;kk++){
            tmpv = Y[t*ny+kk]; 
            if (tmpv == tmpv){
                yerrj[rr] = tmpv; //Copy over data
                cblas_dcopy(ny,&R[kk],ny,&Rj[rr],nyj); //Copy over that row of R
                cblas_dcopy(nx,&G[kk],ny,&Gj[rr],nyj); //Copy over that row of G
                rr++; // Index forward the number of valid observations
            }
        }
        nyj = rr;
        n_yj = nyj;
        
        
        if (t>=ndrop){
            LL = LL -.5*nyj*log(p2);  //Constant varies according to number of observations;
        }
        
        //print_ivec(1,&nyj);
        //printmat_colmaj(nyj, 1, yerrj);
        //printmat_colmaj(nyj, nyj,Rj);
        //printmat_colmaj(nyj, nx, Gj);
        
         //yerr = (Y(:,j)-g*x10)
        cblas_dgemv(CblasColMajor, CblasNoTrans, nyj, nx, -1, Gj, nyj, x10, 1, 1, yerrj, 1);
       
        
        //om10 = g*P10*g'+R;
        cblas_dcopy(nyj*nyj,Rj,1,om10,1); //Copy over R
        cblas_dgemm(CblasColMajor, CblasNoTrans, CblasNoTrans, nyj, nx, nx, 1, Gj, nyj, P10, nx, 0, gP10, nyj); //g*P10
        cblas_dgemm(CblasColMajor, CblasNoTrans, CblasTrans, nyj, nyj, nx, 1, gP10, nyj, Gj, nyj, 1, om10, nyj);//sigg = g*P10*g' + R
        
         
        
        cblas_dcopy(nyj*nyj,om10,1,om10_hold,1); //om10_hold = om10
        cblas_dcopy(nyj,yerrj,1,omyerr,1);      //omyerr = yerr
        dposv_(&uplo, &n_yj, &one, om10_hold, &n_yj, omyerr, &n_yj, &info); // omyerr = om10\yerr
      
        if (t>=ndrop){
            //LL = LL -1/2*(log_det(om10) + yerr'*(om10\yerr))
            LL = LL-.5*log_det(nyj,om10);
             cblas_dgemv(CblasColMajor,CblasNoTrans,1,nyj,-.5,yerrj,1,omyerr,1,1,&LL,1); //LL = LL - .5*(yerr'*(om10\yerr)
        }
        
        //x10 = h*x10 + h*P10*g'*(om10\yerr)
        cblas_dgemv(CblasColMajor, CblasTrans, nyj, nx, 1, gP10, nyj, omyerr, 1, 0, P10gomy, 1);//P10*g'*(om10\yerr) -> switched to dgemv from dgemm
        cblas_daxpy(nx,1,x10,1,P10gomy,1); //x10 + P10*g'*(om10\yerr)
        cblas_dgemv(CblasColMajor, CblasNoTrans, nx, nx, 1, H, nx, P10gomy, 1, 0, x10, 1);//x10 = h*x10 + h*P10*g'*(om10\yerr) -> switched to dgemv from dgemm
        
        //P11 = P10 - P10*g'*(om10\(g*P10))
        cblas_dcopy(nxnx,P10,1,P11,1); //P11 = P10
        cblas_dcopy(nx*nyj,gP10,1,omgP,1); //omgP = g*P10
        dposv_(&uplo, &n_yj, &n_x, om10, &n_yj, omgP, &n_yj, &info); // omgP = om10\(g*P10)
        cblas_dgemm(CblasColMajor, CblasTrans, CblasNoTrans, nx, nx, nyj, -1, gP10, nyj, omgP, nyj, 1, P11, nx);//P11 = P10 - P10*g'*(om10\(g*P10))
        //printmat_colmaj(nx,nx,P11);
        
        //P10n = h*P11*h' + Q
        cblas_dcopy(nxnx,Q,1,P10n,1); //Copy over R
        cblas_dgemm(CblasColMajor, CblasNoTrans, CblasNoTrans, nx, nx, nx, 1, H, nx, P11, nx, 0, hP11, nx); //hP11=H*P11
        cblas_dgemm(CblasColMajor, CblasNoTrans, CblasTrans, nx, nx, nx, 1, hP11, nx, H, nx, 1, P10n, nx);//P10n = H*P11*H'+Q
        
        //compute convergence crit
        cblas_daxpy(nxnx,-1,P10n,1,P10,1); //sigx-sigx_tmp2
        crit = cblas_dasum(nxnx,P10,1);
         
        
        //Copy over the new result to sigx
        cblas_dcopy(nxnx,P10n,1,P10,1);
        t++;
    }
    
    
    ll_tmp[0] = LL;
    return;
}



void mexFunction( int nlhs, mxArray *plhs[],
        int nrhs, const mxArray*prhs[] )
        
{
    double *ll_o;
    double *G, *H, *ETA, *R, *Y, *ndropin;
    int nx, ny, nt, neps, ndrop;
    int one = 1;
    
    
    
    /*Check for proper number of arguments */
    
    if (nrhs != 6) {
        mexErrMsgTxt("6 inputs arguments required.");
    }
    
    /* Get Dimensions of Input Arguments*/
    ny = mxGetM(G_IN);
    nx = mxGetM(H_IN);
    nt = mxGetN(Y_IN);
    neps = mxGetN(eta_IN);
    
    /* Create a matrix for the return argument */
    LL_OUT =  mxCreateNumericArray(1, &one, mxDOUBLE_CLASS, mxREAL);
    
    
    /* Assign pointers to the various parameters  */
    ll_o = mxGetPr(LL_OUT);
    
    G = mxGetPr(G_IN);
    H = mxGetPr(H_IN);
    ETA = mxGetPr(eta_IN);
    R = mxGetPr(R_IN);
    Y = mxGetPr(Y_IN);
    ndropin = mxGetPr(N_DROP_IN);
    ndrop = (int) *ndropin;
    
    //Compute Q
    double Q[nx*nx];
    cblas_dgemm(CblasColMajor, CblasNoTrans, CblasTrans, nx, nx, neps, 1, ETA, nx, ETA, nx, 0, Q, nx);//sigg = g*P10*g' + R
        
    /* Do the actual computations in a subroutine*/
    lpack_test(nx,ny,nt,ndrop,G,H,Q,R,Y,ll_o);
    
    return;
    
}