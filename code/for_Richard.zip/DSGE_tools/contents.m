% CONTENTS - List the m-files in a given directory along with comments
%
% usage
%
% void = contents(dirname)
function []=contents(in)

listing = dir(in);

N = length(listing);

%Pad to max length of file name
padn = 0;
for jj = 2:N
    tmp = listing(jj).name;
    try
    if tmp(end-1:end) == '.m'
    padn = max(padn,numel(tmp(1:end-2)));
    end
    catch
    end
end

%Display each m-file
for jj =2:N
    tmp = listing(jj).name; 
    try
    if tmp(end-1:end) == '.m'
       str_tmp = help(tmp);
       str_tmp = strtrim(erase(str_tmp(1:min(50,end)),char(10)));
       str = [pad(tmp(1:end-2),padn),': '  str_tmp];
       disp(str)
    end
    catch
    end
end