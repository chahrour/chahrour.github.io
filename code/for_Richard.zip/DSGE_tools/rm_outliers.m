function out = rm_outliers(x,n)

[~,idx] = sort(abs(x));



out = x;
out(idx(end-n+1:end)) = [];  %Drop n outliers