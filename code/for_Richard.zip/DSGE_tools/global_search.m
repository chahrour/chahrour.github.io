%Time launched
nowstr = datestr(now,'yyyymmddTHHMMSS');
use_ml = 1;


%For reproducibility w or w/o parfoor
rng(101,'twister');%rng(0);
rng_seed = 2*100000*rand(1,ns);

%names from parameter file
nms = pnames;
nms = nms(1:length(lbn));

pmax = cell(1,ns);maxp = zeros(1,ns);vml_pure = zeros(1,ns);flag = zeros(1,ns);
parfor jj = 1:ns
    warning off
    pmax{jj} = zeros(13,1);
    %Search for new max using genetic alg for starting point
   try
        rng(rng_seed(jj));
        [maxp(jj), pmax{jj}, flag(jj)] = sa_search(obj,lbn,ubn);
        f = fopen(['global_tmp_' num2str(jj), '_' nowstr '.txt'], 'w');
        fprint_mat(f, '%1.8f\t', [maxp(jj), flag(jj), pmax{jj}']);
        fclose(f);
        pause(.1);
        %Update output files along the way!
        collect_results(ns,nowstr,nms);
    catch
        disp(['woops on ', num2str(jj)])
    end
end


%Make excel file with results, deleting temporary files
collect_results(ns,nowstr,nms);
for jj = 1:ns
   eval(['!rm -f '  'global_tmp_' num2str(jj), '_' nowstr '.txt']);
end

%Save all results

eval(['save global_results_' nowstr ' pmax maxp']);
[maxp,b] = sort(maxp);
pmax = pmax(b);
param_opt = vec(pmax{1});




