function [Vy,Ve] = vdfilter_rp(B,C,M,lam)
% -------------------------------------------------------------------------
% Compute variance over frequencies lam = [lam1,lam2] when
% the target data have the VAR representation:
%       x(t) = M*(I-BL)^-1*C*e(t)
%
%
% -------------------------------------------------------------------------

% Options
if nargin < 4; lam = [2*pi/32,2*pi/6]; end; % default 6-32 periods

% Initialize
nx = size(B,1);
ne = size(C,2);
I    = eye(nx);

% Compute filtered variances due to each shock
lam1 = lam(1);
lam2 = lam(2);
fy    = @(w) gomega(w,B,C,M,I);
Vy    = 2.*real(integral(fy,lam1,lam2,'arrayvalued',true))    ;

fe    = @(w) gomege(w,B,C,M,I);
Ve   = 2.*real(integral(fe,lam1,lam2,'arrayvalued',true))    ;

end

function out = gomega(w,B,C,M,I)

T1  = M/(I-B.*exp(-1i.*w))*C;
T2  = M/(I-B.*exp(1i.*w ))*C;
out = 1/(2*pi)*(T1*T2.');

end

function out = gomege(w,B,C,M,I)

T1  = (M/(I-B.*exp(-1i.*w))*C).';
T2  = (M/(I-B.*exp(1i.*w ))*C).';
out = 1/(2*pi)*(T1*T2.');

end