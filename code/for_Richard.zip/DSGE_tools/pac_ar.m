function out = pac_ar(ac,pac)

p = length(ac);
q = length(pac);

if isa(ac, 'sym')
y = sym(zeros(1,q));
else 
y = zeros(1,q);
end
y(1) = ac(1);
ynew = y;
for kk = 2:p
    for ii = 1:kk-1
        ynew(ii) = y(ii) - ac(kk)*y(kk-ii);
    end
    ynew(kk) = ac(kk);
    y = ynew;
end

out = y;