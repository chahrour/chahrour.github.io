function [shape,scale] = normal_params(mu,sd)

shape = mu;
scale = sd;