
function [vml,pout,flag] = sa_search(obj,lbn,ubn)

Aeq = [];
beq = [];

obj0 = @(x) sum(obj(x).^2);

%genetic step
options = optimoptions('ga');
options.MaxGenerations =  25;
options.MaxTime        =  50;
options.PopulationSize =  50;
options.Display                  = 'final';
pout = ga(obj0,length(lbn),[],[],Aeq,beq,lbn,ubn,[],options);

%Use lsqnonlin
options = optimoptions('lsqnonlin');
options.Display                  = 'iter';
options.MaxIterations            = 60;
options.OptimalityTolerance      = 2;
options.TolX = 1e-5;
options.FiniteDifferenceStepSize = 100*min(max(5e-7*(ubn-lbn),10*sqrt(eps)),500*sqrt(eps));
options.MaxFunctionEvaluations   = 1e4; 

[pout,vml,~,flag] = lsqnonlin(obj,pout,lbn,ubn,options);

pout = pout(:);

