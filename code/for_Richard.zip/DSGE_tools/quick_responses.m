
load model_object
%dat_idx = [dy0_idx,dc0_idx,di0_idx,r_idx,tby0_idx,ht_idx,hn_idx]; %NOTE: do we want R or RW?
dat_idx = [dy0_idx,dc0_idx,di0_idx]; %NOTE: do we want R or RW?
dat_idx = [dy0_idx,tby0_idx,rer_idx,dht_idx,dhn_idx,dct_idx,dcn_idx];  %Variables from model
dat_idx = [dy0_idx,dc0_idx,di0_idx,dtby0_idx,dht_idx,dhn_idx,h_idx,s_idx];  %Variables from model


vlist = {'DY', 'TBY', 'RER', 'DHT', 'DHN', 'DCT', 'DCN'};
vlist = {'DY', 'DC', 'DI', 'DTBY', 'DHT', 'DHN','H','S'};


[param,set] = parameters;
paramv = struct2array(param);
setv   = struct2array(set);


[f, fx, fy, fxp, fyp, eta]= model_prog(median(paramv,1),setv);
[gx,hx]                   = gx_hx_alt(fy,fx,fyp,fxp);


%% Response Pictures
nper = 12;
csum_idx = [dy0_idx,dc0_idx,di0_idx,dtby0_idx,dht_idx,dhn_idx,gam_idx];
irs = zeros(nper,nx+ny,size(eta,2));
for ss = 1:size(eta,2)
    irs(:,:,ss) = 100*ir(gx,hx,eta(:,ss),nper);
    irs(:,csum_idx,ss) = cumsum(irs(:,csum_idx,ss));
end



irs_idx = [dat_idx,pn_idx,gam_idx,r_idx,thetc_idx];
vlist2 = {vlist{:} 'PN','GAM',  'R','THETC'};
f = figure;
for jj = 1:min(12,length(vlist2))
    s = subplot(3,4,jj);
    
    for ss = 1:size(eta,2)
        plot(irs(:,irs_idx(jj),ss),'linewidth',2); hold on;
    end
    s.XLim = [1,nper];
    title(vlist2{jj});
end
legend({'News', 'X', 'AT', 'AN', 'R','THETC'})