function out = covariance2(x,y,corrmat)

if nargin == 3 && corrmat == 1
    %Correlation Matrix
    stdx = sqrt(nanvar(x));
    stdy = sqrt(nanvar(y));
else
    stdx = ones(size(x,1),1);
    stdy = ones(size(y,1),1);
end

nx = size(x,2);
ny = size(y,2);
out = NaN(nx,ny);
for jj = 1:nx
    for kk = 1:ny

        idx_x = ~isnan(x(:,jj));
        idx_y = ~isnan(y(:,kk));
        idx   = (idx_x + idx_y) == 2;
        N = sum(idx);
        if N > 0
            out(jj,kk) = 1/(N-1)*demean(x(idx,jj))'*demean(y(idx,kk))/(stdx(jj)*stdy(kk));
        end
    end
end



% DEMEAN - De-mean the columns of a matrix X, excluding NaN values.
%
% usage
%
% out = demean(X)



function [out,mu] = demean(X)

t = size(X,1);
n = size(X,2);
out = zeros(t,n);
mu = zeros(1,n);

for j = 1:n
    mu(j) = mean(X(:,j));
    out(:,j) = X(:,j) - mu(j);
end


function out = mean(v)

idx = ~isnan(v);
out = sum(v(idx))./sum(idx);