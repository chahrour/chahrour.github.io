#include <math.h>
#include <mex.h>
#include <lapack.h>
#include <blas.h>
#include <stdlib.h>
#include <complex.h>

/* Input Arguments */
#define	fy_in	prhs[0]
#define	fx_in	prhs[1]
#define	fyp_in	prhs[2]
#define	fxp_in	prhs[3]
#define	stake_in	prhs[4]


/* Output Arguments */
#define	gx	plhs[0]
#define	hx	plhs[1]
#define	flag	plhs[2]


#if !defined(MAX)
#define	MAX(A, B)	((A) > (B) ? (A) : (B))
#endif

#if !defined(MIN)
#define	MIN(A, B)	((A) < (B) ? (A) : (B))
#endif



/* Prints an MxN matrix to Screen*/
void printmat_colmaj(ptrdiff_t m, ptrdiff_t n, double M[m*n]){
    ptrdiff_t x,y;
    printf("\n");
    for(x=0;x<m;x++){
        for(y=0;y<n;y++){
            printf("%1.8lf\t", M[y*m+x]);
        }
        printf("%\n");
    }
    return;
}



/* Prints an MxN matrix to Screen*/
void printmat_colmajc(ptrdiff_t m, ptrdiff_t n, double M[2*m*n]){
    ptrdiff_t x,y;
    printf("\n");
    for(x=0;x<m;x++){
        for(y=0;y<n;y++){
            printf("%1.4lf + %1.4lf i\t", M[2*y*m+2*x],M[2*y*m+2*x+1]);
        }
        printf("%\n");
    }
    return;
}




/*Copy the upper left block of a matrix*/
void UB(ptrdiff_t nk,ptrdiff_t nl, double complex *a, double complex *b){
    ptrdiff_t j,k;
    for (j=0;j<nk;j++){
        for(k=0;k<nk;k++){
            b[nk*j+k]=a[nl*j+k];
        }
    }
}

/*Copy the lower-left off diagonal block of a matrix*/
void LO(ptrdiff_t nk,ptrdiff_t nl, double complex *a, double complex *b){
    ptrdiff_t j,k;
    for (j=0;j<nk;j++){
        for(k=nk;k<nl;k++){
            b[(nl-nk)*j+(k-nk)]=a[nl*j+k];
        }
    }
}


/*Used the select eigenvalues from the QZ decomposition*/
ptrdiff_t select_eig_c(double complex *a, double complex *b)
{
    ptrdiff_t choice;
    
    double stake = 1.0;
    double lz;
    double aa = cabs(a[0]);
    double cc = cabs(b[0]);
    
    choice = cc<(stake*aa);
    
    
    
    return(choice);
}

/*Get the rank of a matrix*/
ptrdiff_t rank_count_c( ptrdiff_t nx,  ptrdiff_t ny, double *a){
    
    ptrdiff_t rk = 0;
    ptrdiff_t i;
    
    char jobu = {'N'};
    char jobvt = {'N'};
    
    double S[MIN(nx,ny)];
    double U[2*nx*ny];
    double VT[2*nx*ny];
    ptrdiff_t lwork=5*MAX(nx,ny);
    double work[2*lwork];
    double A[2*nx*ny];
    double rwork[5*MAX(nx,ny)];
    ptrdiff_t info;
    ptrdiff_t idx1 = 1;
    ptrdiff_t nxny = nx*ny;
    
    zcopy(&nxny,a,&idx1,A,&idx1);
    
    /*SVD of matrix*/
    zgesvd(&jobu, &jobvt,&nx,&ny,A,&nx,S,U,&nx,VT, &nx, work, &lwork,rwork,&info);
    
    /*Compute # of singular values > 0*/
    for (i=0;i<MIN(nx,ny);i++){
        rk = rk+(S[i]>1e-17);
    }
    return rk;
}






void gx_hx(ptrdiff_t ny, ptrdiff_t nx, ptrdiff_t neq, double *fy, double *fx, double *fyp, double *fxp, double *stake, double *g_x, double *h_x, double flg[]) {
       
    
    char blasLeft = 'L';
    char blasUpper = 'U';
    char blasNoTrans = 'N';
    char blasNonUnit = 'N';
    
    
    ptrdiff_t dsize = sizeof(double);
    ptrdiff_t nxy=nx+ny;
    ptrdiff_t nxnx = nx*nx;
    ptrdiff_t neqneq = neq*neq;
    ptrdiff_t nxy_neq = nxy*neq;
    ptrdiff_t nxnq = nx*neq;
    ptrdiff_t nynq = ny*neq;
    ptrdiff_t nk,j,i,rk,nknk;
    
    /*Indexing constants*/
    ptrdiff_t idx1 = 1;
    ptrdiff_t idx2 = 2;
    
    /*A variable equal to minus 1*/
    double scm1 = -1;
    
    /*initialize two complex constants*/
    double one[2];
    one[0] = 1;
    one[1] = 0;
    
    double zero[2];
    zero[0] = 0;
    zero[1] = 0;
    
    
    double A[nxy_neq];
    double B[nxy_neq];
    
   
    /*A = [-fxp -fyp];*/
    dcopy(&nxnq,fxp,&idx1,&A[0],&idx1);
    dcopy(&nynq,fyp,&idx1,&A[nxnq],&idx1);
    dscal(&nxy_neq,&scm1,A,&idx1);
     
    /*B = [fx fy]*/
    dcopy(&nxnq,fx,&idx1,&B[0],&idx1);
    dcopy(&nynq,fy,&idx1,&B[nxnq],&idx1);
    
    /*QZ decomposition*/
    char jvi ={'N'};
    char jvr ={'V'};
    char srt ={'S'};
    ptrdiff_t info;
    ptrdiff_t lwork=8*neq+16+10;
    ptrdiff_t sdim;
    ptrdiff_t bwork[neq];
    
    double *A_c= calloc(2*nxy_neq, dsize);
    dcopy(&nxy_neq,A,&idx1,A_c,&idx2);
   
    double *B_c= calloc(2*nxy_neq, dsize);
    dcopy(&nxy_neq,B,&idx1,B_c,&idx2);
    
    /*Pointer to function for sorting eigenvalues*/ 
    ptrdiff_t (*pt2function_c)(double complex,double complex)=NULL;
    pt2function_c=&select_eig_c;
    
    double alph_c[2*neq];
    double beta_c[2*neq];
    double vsl_c[2*neqneq];
    double vsr_c[2*neqneq];
    double work_c[2*lwork];
    double rwork[8*neq*neq];
   
    zgges(&jvi, &jvr,&srt, *pt2function_c, &neq,A_c,&neq,B_c,&neq,&sdim,alph_c,beta_c,vsl_c,&neq,vsr_c,&neq,work_c,&lwork,rwork,bwork,&info);
 
    /*printmat_colmajc(nxy,neq,A_c);
 printmat_colmajc(nxy,neq,B_c);
 printmat_colmajc(nxy,neq,vsr_c);*/
     
    
    /*nk=sum(abs(diag(t))<stake*abs(diag(s)));*/
    nk = sdim;
    nknk= nk*nk;
    ptrdiff_t neq_nk = neq-nk; 
     
    double s11[2*nknk];
    double t11[2*nknk];
    double z11[2*nknk];
    double z21[2*(neq-nk)*nk];
    double f[2*(neq-nk)*nk];
    double p[2*nknk];
    double dyn[2*nknk];
    double s11_tmp[2*nknk];
    double z11_tmp[2*nknk];
    double z11i[2*nknk];
    ptrdiff_t IPV[nk];
    
    /*z21 = z(nk+1:end,1:nk);
     *z11 = z(1:nk,1:nk);
     */
    UB(nk,neq,vsr_c,z11);
    LO(nk,neq,vsr_c,z21);
    
    /*Compute rank(z11);*/
    rk = rank_count_c(nk,nk,z11);
    
    /*WARNING MESSAGES, COMPUTE FLAG VALUE*/
    if (nk>nx){
        mexWarnMsgTxt("Warning: The Equilibrium is Locally Indeterminate.");
        flg[0] = 2;
    }
    else if (nk<nx){
        mexWarnMsgTxt("Warning: No Local Equilibrium Exists.");
        flg[0] = 0;
    }
    else if (rk<nk){
        mexWarnMsgTxt("Warning: Invertability Condition Violated.");
        flg[0] = 3;
    }
    else {
        flg[0] = 1;
    }
    
    
    double *eye_nk = calloc(2*nknk, dsize);
    
    /*Make eye(nx,nx)*/
    for (j=0;j<nk;j++) eye_nk[2*nk*j+2*j]=1;
    
    /*z11i=inv(z11)*/
    zcopy(&nknk,z11,&idx1,z11_tmp,&idx1);
    zcopy(&nknk,eye_nk,&idx1,z11i,&idx1);
    zgesv(&nk,&nk,z11_tmp,&nk,IPV,z11i,&nk,&info);

    
    /*s11 = s(1:nk,1:nk);*/
    /*t11 = t(1:nk,1:nk);*/
    UB(nk,neq,A_c,s11);
    UB(nk,neq,B_c,t11);
        
    /*dyn=s11\t11*/
    zcopy(&nknk,t11,&idx1,dyn,&idx1);
    zcopy(&nknk,s11,&idx1,s11_tmp,&idx1); 
    
 
    
    ztrsm(&blasLeft, &blasUpper,&blasNoTrans,&blasNonUnit,&nk,&nk,one,s11,&nk,dyn,&nk);
      
    /*p = (z11*dyn*z11i);*/
    zgemm(&blasNoTrans, &blasNoTrans, &nk, &nk, &nk, one, z11, &nk, dyn, &nk, zero, s11_tmp, &nk);
    zgemm(&blasNoTrans, &blasNoTrans, &nk, &nk, &nk, one, s11_tmp, &nk, z11i, &nk, zero, p, &nk);
    
    /*f = real(z21*z11i);*/
    zgemm(&blasNoTrans, &blasNoTrans, &neq_nk, &nk, &nk, one, z21, &neq_nk, z11i, &nk, zero, f, &neq_nk);
    
    /*Copy applicable portion of results to output arguments.  For now, if flag ~= 1, then results are sensless*/
    ptrdiff_t mnn = MIN((neq-nk)*nk,nx*ny);
    ptrdiff_t mnk = MIN(nk*nk,nx*nx); 
   
    dcopy(&mnn,f,&idx2,g_x,&idx1);
    dcopy(&mnk,p,&idx2,h_x,&idx1);
    
    
    /*free statements*/
    free(eye_nk);
    free(A_c);
    free(B_c);
    
    return;
    
}

void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray*prhs[] )

{
    double *g_o, *h_o, *f_o;
    double *fx, *fy, *fxp, *fyp, *stake;
    int nx, ny, neq,j;
    int one = 1;
    
    
    /*mwSize m,n;*/
    
    /*Check for proper number of arguments*/
    if (nrhs == 4)  {
        double stake_def=1.0;
        stake = &stake_def;
        
    }
    else if (nrhs==5){
        stake = mxGetPr(stake_in);
    }
    else{
        mexErrMsgTxt("4 or 5 inputs arguments required.");
    }
    
    
    /* Get Dimensions of Input Arguments*/
    neq = mxGetM(fy_in);
    nx = mxGetN(fx_in);
    ny = mxGetN(fy_in);
    
    /* Create a matrix for the return argument*/
    double dg[2]={ny,nx};
    double dh[2]={nx,nx};
    
    /*gx =mxCreateNumericArray(2,&dg, mxDOUBLE_CLASS, mxREAL);*/
    gx = mxCreateDoubleMatrix(ny,nx,mxREAL);
    hx =  mxCreateDoubleMatrix(nx,nx,mxREAL);
    flag =  mxCreateNumericArray(1, &one, mxDOUBLE_CLASS, mxREAL);
    
    /* Assign pointers to the various parameters*/
    g_o = mxGetPr(gx);
    h_o = mxGetPr(hx);
    f_o = mxGetPr(flag);
    
    fx = mxGetPr(fx_in);
    fy = mxGetPr(fy_in);
    fxp = mxGetPr(fxp_in);
    fyp = mxGetPr(fyp_in);
  
    
    f_o[0] = 4;
    
    for (j=0;j<(neq*nx);j++){
        if ((fx[j]!=fx[j]) || (fxp[j]!=fxp[j])){
             mexErrMsgTxt("Must not contain NaN.");
         }
    }
    
    for (j=0;j<(neq*ny);j++){
        if ((fy[j]!=fy[j]) || (fyp[j]!=fyp[j])){
             mexErrMsgTxt("Must not contain NaN.");
         }
    }
    
 
    /*stake = mxGetPr(stake_in);*/
    
    gx_hx(ny,nx,neq,fy,fx,fyp,fxp,stake,g_o, h_o,f_o);
    
    return;
    free(fx);
    free(fy);
    free(fxp);
    free(fyp);
      
    
    return;
    
}
