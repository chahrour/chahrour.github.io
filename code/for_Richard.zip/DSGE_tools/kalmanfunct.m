function out = kalmanfunct(param,y)


%General eta and epsilon
rho = param(1);
sigu = param(2);
sigeps = param(3);

R = sigeps;
Q = sigu;
sigx = (sigu)./(1-rho^2) ;

%Function to compute the loglik through the kalman filter

T=length(y);

ex=zeros(1,T+1);
ep=cell(1,T+1,1);

ex(:,1)=0;
ep{1}=sigx;
l=zeros(T,1);


for t=1:T
ey = ex(:,t); %step 1
omega = ep{t}+R;
x = ex(:,t) + (ep{t})*(omega^(-1))*(y(t,:)'-ex(:,t)); %step 2
p = ep{t} - ep{t}*(omega^(-1))*ep{t}; %x forecast error
ex(:,t+1) = rho*x; %step 3
ep{t+1} = rho^2*p+Q; %expected x forecast error

l(t) = -(1/2)*log(omega)-(1/2)*(y(t,:)'-ey)'*(omega^(-1))*(y(t,:)'-ey); %-log(2*pi)
%l2(t) = (2*pi)^(-2/2)*(det(omega^(-1)))^(1/2)*exp(-(1/2)*(y(t,:)'-ey)'*(omega^(-1))*(y(t,:)'-ey)); %level
end
L=sum(l);

out = -L;