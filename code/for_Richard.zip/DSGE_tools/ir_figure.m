% IR_FIG - Generate "nice" impulse repsonse figures from a matrix of IR
% data
%
% usage
%
% fig_out = ir_fig(y,bands,var_list, fig_title,lstyle(optional))
%
% where
%
% y = a TxN matrix of impulse responses
% bands
% var_list = name of the variables plotted
% fig_title = Title for entire figure
% lstyle = a line style (eg 'r-*' means red, stared line). '-' is default.



function fig = ir_figure(y, bands, var_list, fig_title, varargin)

%Create figure, set size
fig = figure;
n = length(var_list);
n_slide = size(y,3);  %Are the confidence bands

%Default settings
n_col = ceil(sqrt(n));
n_row = ceil(n/n_col);
lloc  = 'best';  %legend location
llpanel = n_col;
ppos    = [.25, .25, 11,7];
face_alph = 0.4;
ylim     = NaN;
markersize = 4;
ylab = '\% deviation from steady-state';
%Overwright defaults
if length(varargin)>2
    prefs = varargin{3};
    if isfield(prefs,'n_col')
        n_col = prefs.n_col;
    end
    if isfield(prefs,'n_row')
        n_row = prefs.n_row;
    end
    if isfield(prefs,'lloc')
        lloc = prefs.lloc;
    end
    if isfield(prefs,'llpanel')
        llpanel= prefs.llpanel;
    end
    if isfield(prefs,'ppos')
        ppos= prefs.ppos;
    end

    if isfield(prefs,'face_alph')
        face_alph= prefs.face_alph;
    end

    if isfield(prefs,'ylim')
        ylim = prefs.ylim;
    end

    if isfield(prefs,'markersize')
        markersize = prefs.markersize;
    end

    if isfield(prefs,'ylab')
        ylab = prefs.ylab;
    end
end

set(fig, 'PaperOrientation','landscape', 'PaperPosition', ppos);


%Figure dimensions
if size(y,2) > n
    error('Unequal number of columns and variable titles');
end
t = size(y,1);

%Choose Line Style
if ~isempty(varargin)
    lstyle = varargin{1};
else
    lstyle = {'-'};
end

%Plot each IR
tcl = tiledlayout(n_row,n_col);
for j = 1:n
    
    s =nexttile(tcl);
    hold on

    %Shading first
    if ~isempty(bands)
        xx = [1:t,t:-1:1];
        yy = [bands(:,j,1)', fliplr(bands(:,j,2)')];
        %f = fill(xx,yy,'b');
        f = patch(xx,yy,'b');
        set(f, 'FaceColor', [.8,.8,.8]);
        set(f, 'FaceAlpha',  face_alph);
        set(f, 'EdgeColor', [.5,.5,.5]);
        set(f, 'EdgeAlpha',  face_alph);
    end

    p = nan(1,n_slide);
    for k = 1:n_slide

        try
            p(k) = plot([1:t]', y(:,j,k),lstyle{k} , 'linewidth', 2.3,'MarkerFaceColor','w','MarkerSize',markersize);
        catch

            p(k) = plot([1:t]', y(:,j,k),'-k', 'linewidth', 1,'MarkerFaceColor','w','MarkerSize',markersize, 'Color', [.4,.4,.4]);

        end

    end
    plot([1:t]', 0*[1:t]', ':k');
    tt = title(var_list{j}, 'fontsize', 14, 'interpreter', 'latex');

    if j ==1
        xlabel('period','Interpreter', 'latex')
        ylabel(ylab,'Interpreter', 'latex');
    end

    set(s, 'xlim', [1,t]);

    if ~isnan(ylim)
        try
           set(s, 'YLim',ylim(j,:));
        catch
            warning(['prefs.ylim not the right size. Using defaults for remaing plots for series #' num2str(j) '.'] );
        end
    end
    %Don't let zeros look like something...
    ylimtmp = get(s, 'ylim');
    if max(abs(ylimtmp))<10e-10
        set(s, 'ylim', [-10e-9,10e-9]);
    end

    %Legend
    if ~isempty(varargin{2}) && n_slide > 1 && n>=llpanel && j == llpanel 
        l=legend(p,varargin{2}, 'Location', lloc, 'Fontsize', 12, 'interpreter','latex');
    elseif ~isempty(varargin{2}) && n_slide > 1 && n<llpanel
        l=legend(p,varargin{2}, 'Location', lloc, 'Fontsize', 12, 'interpreter','latex');
        try
        l.Layout.Tile = n_row*n_col;     
        catch
        end
    end

end
    

%Title on figure
if ~isempty(fig_title)
    %suptitle(fig,fig_title, 'tex', 16);
end



%SUPTITLE Puts a title above all subplots.
%	SUPTITLE('text', interpreter (optional), fontsize (optional))
%   adds text to the top of the figure
%	above all subplots (a "super title"). Use this function
%	after all subplot commands.

% Drea Thomas 6/15/95 drea@mathworks.com
% Modified by Ryan Chahrour 4-16-2008 to allow interpreter option

% Warning: If the figure or axis units are non-default, this
% will break.

% Parameters used to position the supertitle.
function hout=suptitle(fig, str, varargin)


figure(fig);
% Amount of the figure window devoted to subplots
plotregion = .92;

% Y position of title in normalized coordinates
titleypos  = .95;

% Fontsize for supertitle
fs = get(gcf,'defaultaxesfontsize')+4;

% Fudge factor to adjust y spacing between subplots
fudge=1;

haold = gca;
figunits = get(gcf,'units');

% Get the (approximate) difference between full height (plot + title
% + xlabel) and bounding rectangle.

if (~strcmp(figunits,'pixels')),
    set(gcf,'units','pixels');
    pos = get(gcf,'position');
    set(gcf,'units',figunits);
else
    pos = get(gcf,'position');
end
ff = (fs-4)*1.27*5/pos(4)*fudge;

% The 5 here reflects about 3 characters of height below
% an axis and 2 above. 1.27 is pixels per point.

% Determine the bounding rectange for all the plots

h = findobj(fig,'Type','axes');
max_y=0;
min_y=1;

oldtitle =0;
for i=1:length(h),
    if (~strcmp(get(h(i),'Tag'),'suptitle')),
        pos=get(h(i),'pos');
        if (pos(2) < min_y), min_y=pos(2)-ff/5*3;end;
        if (pos(4)+pos(2) > max_y), max_y=pos(4)+pos(2)+ff/5*2;end;
    else,
        oldtitle = h(i);
    end
end

if max_y > plotregion,
    scale = (plotregion-min_y)/(max_y-min_y);
    for i=1:length(h),
        pos = get(h(i),'position');
        pos(2) = (pos(2)-min_y)*scale+min_y;
        pos(4) = max(.01,pos(4)*scale-(1-scale)*ff/5*3);
        set(h(i),'position',pos);
    end
end

np = get(gcf,'nextplot');
set(gcf,'nextplot','add');
if (oldtitle),
    %delete(oldtitle);
end
ha=axes('pos',[0 1 1 1],'visible','off','Tag','suptitle');
ht=text(.5,titleypos-1,str);
set(ht,'horizontalalignment','center','fontsize',fs);
set(gcf,'nextplot',np);
axes(haold);
if nargout,
    hout=ht;
end

if ~isempty(varargin)
    set(ht, 'interpreter', varargin{1}, 'fontsize', varargin{2});
end


