function out = spzeros(N,M)

out = spalloc(N,M,0);