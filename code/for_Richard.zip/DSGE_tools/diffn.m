% DIFFN - Take difference for N >=1
% i.e. out = x(N+1:end)-x(1:end-N);

function out = diffn(x,N)

out = x(N+1:end)-x(1:end-N);