

function [F_comp,omega,mu,fevd, beta,B] = VECM(Y, param)


%***************************************************************
%Input Parameters
%***************************************************************
nlag = param.nlag;      %Lags, in difference, in VECM
nrank = param.nrank;    %Rank of cointegration
det_ec = param.det_ec;  %Include a constant in VAR
det_var = param.det_var;%Include a constant in cointegration expression?
ttrend = param.ttrend;
nper  = param.nper;     %Number of periods in FEVD
check_rank = param.check_rank;  %Check rank condition

nvar = size(Y,2);


%***************************************************************
%Define key matrices
%***************************************************************
DY = Y(2:end,:)-Y(1:end-1,:);

%Stack lagged X
X = zeros(length(DY)-nlag, nlag*nvar);
for j =1:nlag
    X(:, (j-1)*nvar+1:j*nvar) = DY(nlag+1-j:end-j,:);
end

if det_var
    %Include a constant in VAR?
    X = [X, ones(length(X),1)];
end

if ttrend
    %Include a trend
    X = [X, (1:length(X))'];
end
%Exclude lags from DY
DY = DY(nlag+1:end,:);
YL = Y(nlag+1:end-1,:);

if det_ec
    %Include a constant in EC term?
    YL = [YL, ones(length(YL),1)];
end

T = length(DY);

if nrank>0
    %***************************************************************
    %Estimate Cointegration Vector
    %***************************************************************
    
    %Define key Matrices
    M00 = DY'*DY/T;
    M01 = DY'*YL/T;
    M10 = YL'*DY/T;
    M11 = YL'*YL/T;
    M02 = DY'*X/T;
    M12 = YL'*X/T;
    M20 = X'*DY/T;
    M21 = X'*YL/T;
    M22 = X'*X/T;

    tmp = M22\M20;
    tmp1 = M22\M21;

    S00 = M00 - M02*tmp;
    S01 = M01 - M02*tmp1;
    S11 = M11 - M12*tmp1;

    %Solve Generalized Eigenvalue Problem
    [V,D] = eig(S01'*(S00\S01), S11);
    [waste,idx] = sort(diag(D), 'descend');
    V = V(:,idx);

    %Normalize Eigenvectors
    scl = V'*S11*V;
    for j = 1:nvar
        V(:,j) = V(:,j)/sqrt(scl(j,j));
    end

    %Derive B and alph
    b  = V(:,1:nrank);
    B  = (b(1:nrank,1:nrank)'\b')';
    alph = S01*(B'*S11*B\B')';
    gam = alph*B';

    %Estimate VAR, after removing EC term
    YY = DY-YL*gam';
else
    %***************************************************************
    %Standard VAR
    %***************************************************************
    gam = 0;
    B = 0;
    YY = DY;
end


%VAR coefficients, stderrs, etc
beta = X\YY;
mu = YY - X*beta;
omega = mu'*mu/(T-nvar*nlag - 0*nrank - 1);

%Generate the reduced form LR and companion matrix
beta = beta';
F = cell(1,nlag+1);
F{1} = [eye(nvar)+beta(:,1:nvar) + gam];
for k = 2:nlag
    F{k} = [beta(:,(k-1)*nvar+1:k*nvar) - beta(:,(k-2)*nvar+1:(k-1)*nvar)];
end
F{k+1} = -beta(:,(k-1)*nvar+1:k*nvar);

G = eye(nvar);
for i = 1:nlag
    G = G - beta(:, (i-1)*nvar+1:i*nvar);
end

%Get the companion matrix of the levels form
F_comp = [F{1:end}; eye(nvar*nlag) zeros(nvar*nlag,nvar)];
if nargout <= 3
    return
end
%Get the LR matrix
if nrank>0
    C = null(B')*inv(null(alph')'*G*null(B'))*null(alph')';
else
    C = inv(G);
end

%***************************************************************
%ID Assumptions:
% Based on 
% Breitung, J., Br�ggemann, R. and L�tkepohl, H. ( 2004).
% Structural vector autoregressive modelling and impulse responses
% in H.�L�tkepohl and M.�Kr�tzig (eds), Applied Time Series Econometrics, Cambridge
% University Press.
%***************************************************************

B = param.B;
L = param.L;

nzb = sum(sum(B));  %Number of free parameters B
zb = sum(sum(B==0));
nzl = sum(sum(L));  %Number of free parameters in L
zl = sum(sum(L==0));  


%Some basic checks on validity of restrictions
if (zb+zl) < nvar*(nvar-1)/2
    error('Model unidentified under current restrictions.');
elseif (zb+zl) > nvar*(nvar-1)/2
    warning('Model overidentified under current restrictions.');
end

col_tot = sum([B;L]);
for j = 1:nvar
    if col_tot < nvar+1
        error(['Column ', num2str(j), 'has too many restrictions.']);
    end
end


%Write SR restrictions in Canonical Form
BN = vec(B==0);
skb = 0;
RB = zeros(length(BN), nzb);
for j = 1:length(BN)
    if BN(j)
        skb = skb+1;
    else
        RB(j,j-skb) = 1;
    end
end


%Adding in LR restrictions
[L_r,L_c] = find(L==0);
nlr = length(L_r);
for j =1:nlr

    %Add to list of variables excluded from gamma: pick the last variable
    %in col L_c that is not already excluded from the "free" set in gam
    idx = find(B(:, L_c(j)) == 1, 1,'last');
    vec_idx = nvar*(L_c(j)-1)+idx;
    RB_cols = cumsum(B(:));
    rm_col = RB_cols(vec_idx);
    B_old = B;
    B(idx, L_c(j)) = 0;

    %Now, drop the collumn relating to this variable
    new_cols = except(1:size(RB,2), rm_col);
    RB_new = RB(:,new_cols);

    %Generate the set of coeff linking B(idx,L_c(j)) to other "free"
    %parameters.
    
    row_idx = nvar*(L_c(j)-1)+1:nvar*L_c(j);
    col_idx = sum(sum(B_old(:,1:L_c(j)-1)))+1:sum(sum(B_old(:,1:L_c(j))));
    mat_tmp = RB(row_idx,col_idx);
    cof = C(L_r(j),:)*mat_tmp;
    
    cof = -cof(1:end-1)/cof(end);

    %Now plug into the row for the selected variable
    RB_new(vec_idx,rm_col-length(cof):rm_col-1) = cof;
 
    
    %Now, for any LHS row that depends on the dropped variable, substitute for that
    %variable based on the old relation.
    row_idx = find(RB(:,rm_col));
    row_idx = row_idx(row_idx~=vec_idx);
    RB_new_tmp = RB_new;
    for k = 1:length(row_idx)
       RB_new(row_idx(k),:)=RB(row_idx(k),:)*RB_new_tmp(logical(B_old(:)),:);
    end
    RB = RB_new;


end
B_idx = B;


%***************************************************************
%Optimization Procedure to Solve for Restriced B Matrix
%***************************************************************
maxls = 1;  %Largest Step Size
ord_con = nvar*(nvar-1)/2;   %Min number of restrictions

%Matrices to reuse
A = eye(nvar); RA = [];  %A is fixed in this version
eyekk = eye(nvar^2);     %I
K = commutation(nvar,nvar); %Communation Matrix
RM = [RA, zeros(nvar^2,size(RB,2)); zeros(nvar^2, size(RA,2)), RB];  %Combined Restriction Matrices

%Intial values
if zb == ord_con || zb == ord_con+1 || zb == ord_con-1
    %(Nearly) Only SR restrictions?
    B0 = chol(omega)';
elseif zl == ord_con || zl == ord_con+1 || zl == ord_con-1
    %(Nearly) Only LR restrictions?
    try
        B0 = inv(C)*(chol(C*omega*C')');
    catch
        B0 = rand(nvar);
    end
else
    %Other cases
    try
        B0 = chol(omega)';
    catch
        B0 = rand(nvar);
    end
end

%Put in itial value of B, gamma
gam = zeros(nzb-zl,1);
gam(:)=B0(logical(B));
B = zeros(nvar);
B(:) = RB*gam;

%B
%B0

%Is B full rank?
if rank(B) < nvar
    B = rand(nvar);
end

%The loop
j = 1;
crit = 1;
max_iter = 1000;
while  ((j < max_iter) && (crit > 1e-15)) || (j<3)

    %I matrix
    ba_k_b = kron(inv(inv(B)*A), inv(B'));
    i_k_b = -kron(eye(nvar),inv(B'));
    h = [ ba_k_b; i_k_b];
    Iab = T*h*(eyekk+K)*h' ;
    Igam = RM'*Iab*RM;

    %S matrix
    Sba = T*vec(inv((inv(B)*A)')) - T*kron(omega, eye(nvar))*vec(inv(B)*A);
    Sab = [kron(eye(nvar),inv(B')); -kron(inv(B)*A,inv(B'))]*Sba;
    Sgam = RM'*Sab;

    %Choose Step size
    tmp = (Igam\Sgam);
    len = max(abs(tmp));
    if len>maxls
        lam = maxls/len;
    else
        lam = 1;
    end

    %Update
    gam_new = gam + lam*tmp;
    crit = min(max(max(abs((gam_new-gam)))), max(max(abs((gam_new-gam)./gam))));
    gam = gam_new;
    
    %Use R matrix to creat B (recall A is fixed)
    B(:) = RB*gam; 
    
    j =j+1;
    
end
%vec(B) - RB*B(B_idx(:)~=0)


if j == max_iter
    warning(['Optimization did not converge: convergence crit. is ', num2str(crit)]);
end

%Normalize Sign of B
sgn = sign(diag(B));
for j = 1:length(sgn)
    B(:,j) = sgn(j)*B(:,j);
end

%Checking Rank Condition of Identification (Hamilton, pg 334)
if check_rank

    D = dup_mat(nvar);
    Dp = (D'*D)\D';
    J = [-2*Dp*kron(omega,B)*RB];
    rkj = rank(J);
    condj = cond(J);
    disp(['Optimization stopped at ', num2str(j) ' iterations.']);
    disp(['Convergence criterion is ', num2str(crit),'.']);
    disp(['Rank of J: ', num2str(rkj),'.']);
    disp(['Condition Number of J: ', num2str(condj) '.']);
end

%***************************************************************
%Get the FEVD
%***************************************************************

%Get the MA(infty) representation of the VAR
C = zeros(nvar,nvar,nper);
C(:,:,1) = eye(nvar)*B;
F_prod = F_comp;
for h = 2:nper
    C(:,:,h) = F_prod(1:nvar, 1:nvar)*B;
    F_prod = F_prod*F_comp;
end

%Get the Variance Decomposition
fevd = zeros(nper, nvar^2);
for h = 1:nper
    tmp = sum(C(:,:,1:h).^2,3);
    sig_h = sum(tmp,2);
    for k = 1:nvar
        for j = 1:nvar
            fevd(h,(k-1)*nvar+j) = tmp(k,j)/sig_h(k);
        end
    end
end




%***************************************************************
%DUP_MAT: Duplcation matrix so that vec(M) = D*vech(M);
%***************************************************************
function D = dup_mat(n)

if n == 2
    D = [1 0 0; 0 1 0; 0 1 0; 0 0 1];
else

    tmp1 = ones(n,n);
    tmp2 = tril(tmp1);
    tmp3 = tril(tmp1,-1);
    D = zeros(n^2, n*(n+1)/2);

    D(logical(tmp2(:)),:) = eye(n*(n+1)/2);


    rep_row = find(tmp2(:) ==0);
    rep_col = find(tmp3(logical(tmp2(:))));
    tmp3(logical(tmp3)) = rep_col;
    tmp3 = tmp3';
    rep_col = tmp3(tmp3>0);

    idx = [rep_row,rep_col];
    for j= 1:length(idx)
        D(idx(j,1), idx(j,2))=1;
    end

end


