function [tnstr,tstr,fstr,str_nbind,str_bind] = test_matlabFunction;

fid = fopen('test.m','r');
l = fgetl(fid); %ditch fist line
tcount = 0;
fcount = 0;
dfcount = 0;

tnstr = cell(0,1);
tstr  = cell(0,1);
fstr  = cell(0,1);
str_nbind = cell(0,1);
str_bind = cell(0,1);
for jj = 1:400
    
try  
    l = strtrim(fgetl(fid));

    if length(l)>0 && l(1)=='t'
        tnstr{end+1} = ['double ' l(1:3) ';']; 
        tstr{end+1} = [l(1:5), pow_sym(l(6:end))];
    end
    
    if length(l)>0 && l(1) == 'f'
       fstr{end+1} = ['resid[' num2str(fcount) '] = ' pow_sym(l(5:end))];
       fcount = fcount+1;
    end
    
    
    if length(l)>0 && l(1) == 'd'
        l = [',' l(find(l=='[')+1:find(l==']')-1) ','];
        idx_comma = find(l==',');
        
        for ll = 1:3
                tmp= l(idx_comma(ll)+1:idx_comma(ll+1)-1);
                str_nbind{end+1} = ['dFmat [' num2str(3*(ll-1)+dfcount) '] ='  pow_sym(tmp) , ';'] ;
        end
        
        for ll = 1:4
            tmp= l(idx_comma(ll)+1:idx_comma(ll+1)-1);
            str_bind{end+1} = ['dFmat [' num2str(4*(ll-1)+dfcount) '] ='  pow_sym(tmp) , ';'] ;
        end
        
        dfcount = dfcount+1;
        
        
    end
    
    
    
     catch
        break
    end
end
str_nbind = str_nbind(1:9);