% VAR Parameters
nvar     = size(yxdat,2);
nper     = 41+45;                                                          %Horizon for IR

id_type = 'max';

freq_bc  = [2*pi/32,2*pi/6];  %business cycle variances
freq_uc  = [2*pi/500, pi]  ; %unconditional variances
freq     = freq_uc;


%VECM version of VAR
param.nlag    = 2;          %Lags, in difference, in VECM (lags in levels = nlag + 1)
param.nrank   = nvar-0;     %Rank of cointegration
param.det_var = 1;          %Include a constant in VAR
param.ttrend  = 0;          %Include a time trend?
param.det_ec  = 0;          %Include a constant in cointegration expression?
param.nper    = 32;         %Number of periods in FEVD
param.check_rank = false;  %Check rank condition for Identification (that VAR is locally identified)

%Run the VECM
[B,cp,errs]    = VECM(yxdat,param);
Sig            = cov(errs);
c              = chol(Sig)';

%Select return variables
e5 = selector(5,length(B));
e6 = selector(6,length(B));

%5 yr risk premium annualized
M20 = 1/5*(e5-e6)*(B^1 + B^2 + B^3 + B^4 + B^5 + B^6 + B^7 + B^8 + B^9 + B^10 + B^11 + B^12 + B^13 + B^14 + B^15 + B^16 + B^17 + B^18 + B^19 + B^20);

%This is the baseline ID method
[cnew,C] = id_method0(B,c,M20,freq);

%Construct timeseries of RP shock
struct_errs      = errs*((cnew')^-1);
ts_errs = ts_make(-struct_errs(:,1)*sign(struct_errs(1,1)),4,index(date_range(1),param.nlag+1,4), 'Implied Shock Series');

%Construct RP timeseries
[~,~,XX] = quick_ols(0*yxdat,yxdat,param.nlag+1);  %Clusy way to get the RHS variables in the VAR
rp = M20*XX(:,1:end-1)';
rp_ts = ts_make(rp-mean(rp)+0.062,4,index(date_range(1),param.nlag+1,4), '$E_t[rp_{t,t+20}]$');



rxs = vect(realized_xs,0,[rp_ts.sd,min(realized_xs.ed,date_range(end))]);
rep = vect(rp_ts,0,[rp_ts.sd,min(realized_xs.ed,date_range(end))]);

%R-sqr of forecast for realized
bet_fit = [ones(length(rxs),1),rep]\rxs;
rxs_hat = [ones(length(rxs),1),rep]*bet_fit;
rsqr = var(rxs_hat)/var(rxs);


% Impulse responses
bet = B(1:nvar,:)';
IRpoint = zeros(nper,nvar,nvar);
for jj = 1:nvar
    [IRpoint(:,:,jj)] = quick_IR(bet, nper, cnew(:,jj));
end

%Plot the excess return and the RP shock
ts_plot(ts_errs);
ts_plot(rp_ts,realized_xs);

ts_out('BCCV_rp_output.xls',ts_errs,rp_ts)
%% Main IRs (current Figure 3)
clear prefs
ir_plot = 30;
nvar = 7;
vplot = [1:6];

prefs.ylab = []; 
figure1 = ir_figure(100*IRpoint(1:ir_plot,vplot,1), [], var_names_orig(1:6), [], {'-k'},{'Data'},prefs);
figure1.Units = 'inches';
figure1.OuterPosition = [0.25 0.25 11 8.5];
exportgraphics(figure1, ['ir_figure.pdf']);
