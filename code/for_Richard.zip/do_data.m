% DO_DATA - Import the data for the empirical results
%
% Data imported from St Federal Reserve FRED database using matlab's
% built-in command "fetch" on June 1, 2019

addpath('DSGE_tools')
addpath('ts_box')

date_range  = [195401,201804];


%% Main Quanties
load orig_data/fred_data

%Population Series Smoothed
[~,pop]  = ts_hp(M2Q(ts_fred(qtr.pop)),1600);

%Quarterly Quantities
gdp  = ts_fred(qtr.gdp);
con  = ts_plus(ts_fred(qtr.pcnd), ts_fred(qtr.pcsv)); 
inv  = ts_plus(ts_fred(qtr.gpdi), ts_fred(qtr.pcdg));
ntx  = ts_fred(qtr.ntx);
gin  = ts_fred(qtr.ginv);

defl = ts_base(ts_fred(qtr.def),200902);

%% Per captia & real

%Quantities
gdpv  = ts_div(ts_div(gdp,pop),defl);
conv  = ts_div(ts_div(con,pop),defl);
invv  = ts_div(ts_div(inv,pop),defl);
ntxv  = ts_div(ts_div(ntx,pop),defl);
ginv  = ts_div(ts_div(gin,pop),defl);

%Employment series
emp    = M2Q(ts_fred(mth.emp));
empv   = ts_div(emp,pop);

%Dividends
div = M2Q(ts_fred(mth.div));


%% REAL Stock price series (downloaded from http://www.econ.yale.edu/~shiller/data.htm on June 1, 2019)
%same as BBL use

[a,b] = xlsread('orig_data/ie_data.xlsx','Data');
SP500 = M2Q(ts_make(a(:,8),12,187101)); %Take average of monthly closing price

div2 = a(:,3)./a(:,2); % dividend price ratio
div3 = a(:,4)./a(:,2); % earnings price ratio

div2 = M2Q(ts_make(100*div2,12,187101));
div3 = M2Q(ts_make(100*div3,12,187101));

div_lev = M2Q(ts_make(100*a(:,3),12,187101));
div_lev = ts_div(div_lev, defl);


%% Real stock price series (download from CRISP at WRDS on Aug 5, 2020)
[a,b] = xlsread('orig_data/crisp_nyse_amex_nasdaq.xlsx');  %All stock: col 2, SP500: col 6
stock_level = 1;
for jj = 1:length(a)-1
    stock_level(jj+1) = stock_level(jj)*(1+a(jj+1,2));  %Double check for annualization in WRDS data
end
STOCK = ts_make(stock_level,4,192504, 'STOCK');
STOCK = ts_div(STOCK,defl);  %Do we want to divide by pop?

%% TB3 bond price series (download from CRISP at WRDS on Aug 5, 2020)
[a,b] = xlsread('orig_data/crisp_bonds.xlsx');  %5y: col 2, 90dy: col 4
tb3_level = 1/1.23; 
for jj = 1:length(a)-1
    tb3_level(jj+1) = tb3_level(jj)*(1+a(jj+1,4));  %Double check for annualization in WRDS data
end
TB3 = ts_make(tb3_level,4,192504,'TB3'); TB3_NOM = TB3;
TB3 = ts_div(TB3,defl);  %Do we want to divide by pop?

%% Get realized excess return
realized_stck = log(vect(STOCK,0,[date_range(1),STOCK.ed]));
realized_bnd  = log(vect(TB3,0,[date_range(1),STOCK.ed]));

realized_xs = realized_stck(20:end)-realized_stck(1:end-19) - ... 
              (realized_bnd(20:end)-realized_bnd(1:end-19));

realized_xs = ts_make(realized_xs.*(4/20),4,date_range(1), '$rp_{t,t+20}$');

%% Main VAR variables
yxdat = [
    log(vect(gdpv ,0,date_range)) ...
    log(vect(conv ,0,date_range)) ...
    log(vect(ts_plus(ts_plus(invv,ntxv),ginv),0,date_range))...
    log(vect(empv,0,date_range))...                           
    log(vect(STOCK,0,date_range)) - log(vect(STOCK,-1,date_range)) ...
    log(vect(TB3,0,date_range  )) - log(vect(TB3,-1,date_range  ))...
    (vect(div2,0,date_range))...
    ];
    
var_names_orig = {'Output', 'Cons.', 'Investment', 'Employment','Stock Return','1Q Bond', 'D/P'};


