%Take the value of a structure and put the fields as variables in the
%workspace.
function struct2val(in)

nms = fieldnames(in);

for jj = 1:length(nms)
    assignin('caller',nms{jj},eval(['in.' nms{jj}]));
end