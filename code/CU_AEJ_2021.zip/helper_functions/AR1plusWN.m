function [MAterms,sig,theta,rho] = AR1plusWN(rho,sigAR,sigWN,MAorder)
% compute ARMA(1,1) = AR(1) + white noise 
% inputs are AR1 (rho and sigAR ) and WN (sigWN)
% outputs are ARMA(1,1) characterized by rho,theta,sig


if sigAR == 0
    rho = 0;
end

if sigWN > 0
    theta = roots([rho*sigWN^2,sigAR^2+(1+rho^2)*sigWN^2,rho*sigWN^2]);
else 
    theta = 0;
end


%[~,i]=min(abs(theta)); % pick invertible solution
[~,i]=max(abs(theta)); % pick non-invertible solution

theta = theta(i); 

if abs(theta) > 0
    sig = sqrt(-rho*sigWN^2/theta);
else
    sig = max(sigAR,sigWN); % one of them is zero if theta=0
end


MAterms = rho.^(0:MAorder)*sig;
if MAorder > 0
    MAterms(2:end) = MAterms(2:end) + rho.^(0:MAorder-1)*theta*sig;
end

end

