function MAterms = arma1NtoMA(ar,ma,N,sprm)
% get first N coefficients of MA(inf) representation of ARMA(1,N) process.
% assumes that MA terms start at order 0 (i.e., first element of MA is
% standard deviation of innovation).
% if ma is matrix, rows are lags and columns are shocks

if isvector(ma)
    order = length(ma)-1;
    shocks = 1;
    ma = ma(:);
else    
    [order,shocks ] = size(ma);
    order = order-1;
end


MAterms = szeros([N+1,shocks],sprm);

for ii=0:min(order,N)

MAterms(1+ii:N+1,:) = MAterms(1+ii:N+1,:) + ar.^(0:N-ii).' * ma(ii+1,:);

end


end