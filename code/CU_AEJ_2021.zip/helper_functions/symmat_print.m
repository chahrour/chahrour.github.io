%*******************************************************
% SYMMAT_PRINT:
% Print a symbolic expresison to a evaluateable function.
%*******************************************************
function str = symmat_print(x,varargin)

if nargin > 1 && varargin{1}==1
    str = char_dot(x); %Dot multiply
else
    str = char(x);     %Standard multiply
end

%If a matrix
% if length(x)>1
%     str = str(8:end-1);
% end

%Robusts to later version of matlab (post 2018...)
idxl = find(str=='[', 1,'first');
idxr = find(str==']',1,'last');

if ~isempty(idxl)
    str = str(idxl:idxr);
end

%Make into matlab matrix notation
row_idx = findstr(str, '],');
for j = 1:length(row_idx)
    str(row_idx(j):row_idx(j)+1)='];';
end
