%Symbolic sum command
function out = ssum(x,dim,sprm)

if sprm==0
    out = sum(x,dim);
elseif sprm==1 && dim == 3
   ssize =  size(x);
   out = sym(zeros(ssize(1:2)));
   
   for jj = 1:ssize(3)
       out(:,:) = out(:,:) + x(:,:,jj);
   end
else
    error('This configuration no implemented for symbolic yet.')
end