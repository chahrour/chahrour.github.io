% COVDAT_NAN - compute the (ML) sample auto-covariance at lag j using as 
% much data as is available from the sample: cov(x(t),x(t-j))
%
% usage:
%
% out = covdat_nan(X,j)
%
% where
% 
% X = a matrix where each column is a timeries with latest
% observations ordered last
% J = the number of lags (0 is contemporarnous covariance.)

function out = covdat_nan2new(X,j)

% always compute sample average with all T observations
X = demean(X')';

if sum(vec(isnan(X))) > 0
    warning('Data contains NaN, it should not!')
end

m = size(X,2);

x = X(:,1+j:end);
y = X(:,1:end-j);

% always normalize by T to get consistent COV
out = x*y'/m; 

