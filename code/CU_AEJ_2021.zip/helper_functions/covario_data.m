function  outmat = covario_data(dat,nj,corr_opt)


%Compute moments
if size(dat,3) > 1
    %If already a covariance matrix.
    sigY = dat; 
    nv = size(sigY,1);
else
    %If covariance matrix needs to be computed.
    nv = size(dat,1);
    nt = size(dat,2);
    
    sigY = zeros(nv,nv,nj+1);
    for j = 0:nj
        sigY(:,:,j+1) = 1/(nt-j)*dat(:,1:end-j)*dat(:,1+j:end)';
    end
end

outmat = zeros(nj+1,nv^2);
for k = 1:nv
    for l = 1:nv
        for j = 0:nj
            if corr_opt
                outmat(j+1, l+nv*(k-1)) = sigY(k,l,j+1)/sqrt(sigY(l,l,1)*sigY(k,k,1));
            else
                outmat(j+1, l+nv*(k-1)) = sigY(k,l,j+1);
            end
        end
    end
end

outmat(abs(imag(outmat))>0) = NaN;