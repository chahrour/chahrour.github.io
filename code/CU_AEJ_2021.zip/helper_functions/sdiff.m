%symbolic implementation of diff for 3d matrix
function out = sdiff(X,p1,p2,sprm)

if sprm==0
    out = diff(X,p1,p2);
elseif sprm == 1 && p2 == 3
    out = X(:,:,2:end)-X(:,:,1:end-1);
else
    error('This configuration no implemented for symbolic yet.')
end