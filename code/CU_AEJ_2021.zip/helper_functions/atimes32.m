function Z = atimes32(X,Y)
% postmultiply every 2x2 matrix of 3rd dimension of X with Y

[a,b,c] = size(X);
[d,e] = size(Y);

if b~=d
    error('dimensions of X and Y do not match')
end

Z = reshape(permute(X, [1 3 2]),[a*c b])*Y;
Z = permute(reshape(Z,[a c e]),[1 3 2]);


end