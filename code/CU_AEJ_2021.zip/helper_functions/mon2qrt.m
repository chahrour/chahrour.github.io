function [ d2,t2 ] = mon2qrt( d,t,eop )
% d = data
% t = n*2 matrix of dates in format [year,month]

if nargin<3
    eop=false; % avg is default
end

y = t(:,1); % year
m = t(:,2); % month
q = ceil(m/3); % quarter

T = 4*(y(end)-y(1)) + q(end)-q(1) + 1; % length of data-set

d2 = zeros(T,1);
t2 = zeros(T,2);

m0 = m(1)-(q(1)-1)*3;

for i=1:T
    
    if i==1
        range = (1:4-m0);
    else
        range = (1:3) + (i-1)*3 - (m0-1);
    end
    if i==T;
        range = (range(1):length(d));
    end

    t2(i,:) = [y(range(end)),q(range(end))];
    
    if eop
        d2(i) = d(range(end));
    else
        d2(i) = mean(d(range));
    end
    
   
end


end

