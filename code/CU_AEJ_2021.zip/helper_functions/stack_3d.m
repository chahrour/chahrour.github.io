%STACK_3D - stack the target moment matrix (ny-by-(ny*K)) into a 3Darray
%of ny-by-ny matrices. Includes padding is not using as many variables as
%required size of final matrix
%
%usage
%
%new = stack_3d(in,nvar,pad)
%
%where
%
%in   = the input matrix of moments
%nvar = scalar number of variables in the input matrix
%pad  = scalar number of extra rows/cols add 
function new = stack_3d(in,nvar,pad)

if nargin <3 
    pad = 0;
end

L = size(in,2);
nslice = L/nvar;

new = zeros(nvar+pad,size(in,1)+pad,nslice);
for jj = 1:nslice
   new(:,:,jj) = [in(:,(jj-1)*nvar+(1:nvar)), nan(nvar,pad); nan(pad,nvar+pad)]; 
end