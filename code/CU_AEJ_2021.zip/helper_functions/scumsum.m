%symbolic scumsum
function out = scumsum(X,dim,dir)



if dim == 3 && strcmp(dir, 'reverse')
    for jj = (size(X,3)-1):-1:1
        X(:,:,jj) = X(:,:,jj) + X(:,:,jj+1);
    end
    out = X;
elseif dim == 3 && strcmp(dir, 'forward')
    for jj = 2:size(X,3)
        X(:,:,jj) = X(:,:,jj) + X(:,:,jj-1);
    end
    out = X;
else
    warning('requested functionality not implemented')
end