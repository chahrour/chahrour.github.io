function out = struct2mem(x)

nms = fieldnames(x);

for jj = 1:length(nms)
    eval([nms{jj} '=x.' nms{jj} ';']);
    assignin('caller', nms{jj}, eval(nms{jj}));
end
