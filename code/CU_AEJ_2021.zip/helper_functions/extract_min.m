function [fmin,resid] = extract_min(file)

load(file, 'resid_grid','fmin_grid','n_start','n_tot','n_micro','n_cpy','n_ary')

%Don't consider infeasible cases
fmin_grid(resid_grid>0.05) = inf;

%Min over nstarts
[fmin, idx_min] = min(reshape(fmin_grid,[n_start,n_tot/n_start]));
resid_grid = reshape(resid_grid,[n_start,n_tot/n_start]);
resid = nan(size(fmin));

for jj = 1:size(fmin,2)
    resid(:,jj) = resid_grid(idx_min(jj),jj);
end
    
%Reshape in 2d matrix
fmin = sqrt(-squeeze(reshape(fmin, [n_micro,n_cpy,n_ary])));
resid = -squeeze(reshape(resid, [n_micro,n_cpy,n_ary]));