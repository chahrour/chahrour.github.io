
%Make zeros, symbolic according to parameters sprm
function out = szeros(dims,sprm)

if sprm==1
    out = sym(zeros(dims));
else
    out = zeros(dims);
end