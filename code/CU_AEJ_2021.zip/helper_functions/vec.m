function Y_big = vec(Y)

Y_big = Y(:);

