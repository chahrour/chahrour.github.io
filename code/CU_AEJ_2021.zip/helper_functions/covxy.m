function covxy = covxy(MAx,MAy,lag)

% compute cov(x,y,lag) from to MA-polynomials. For now I assume they are of
% equal order, but could generalize easily.

[nx,ns,order] = size(MAx);
order = order-1;
ny = size(MAy,1);


if true;%order - lag <= 2 % loop seems faster for small problems
   
    tmp = zeros(nx,ny);
    for jj = 0:order-lag
        tmp = tmp + MAx(:,:,1+lag+jj)*MAy(:,:,1+jj).';
    end
    covxy = tmp;
    
    
else % for large problems vectorization seems faster
    
    a = reshape(MAx(:,:,1+lag:end),[nx ns 1 order+1-lag]);
    b = reshape(permute(MAy(:,:,1:end-lag),[2 1 3]),[1 ns ny order+1-lag]);    
    c = reshape(sum(a.*b,2), [nx ny order+1-lag 1]);
    covxy = sum(c,3);
    
end
    


end