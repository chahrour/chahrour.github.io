function [f,ceqm,ceq,ceqa,ceq4,ceq8,ceq12,ceqh,vd,Binfo,Bresid,targ_info,targ_resid,da_info,da_resid] = make_all_ex2(coeff,par,targ_data,targ_dyhat)

xidx = 0;
%% parametrization of macro process

%only need to keep track of tauxh in asymmetric info case (we don't discipline wage otherwise)
if par.ai
    num_tau = 3;%asymmetric info --> 3 wedges [tauc,taup,tauph]->will back out taupf
else
    num_tau = 2;%symmetric info --> 2 wedges [tauc,taup]
end


%aggregate process is free (no loading on TFP,fix wages)
Binfo  = szeros([num_tau,num_tau+1,par.MAorderLHS+1],par.sym);
Bresid = szeros([num_tau,num_tau+1,par.MAorderLHS+1],par.sym);

Bresid(:) = coeff(xidx+(1:numel(Bresid))); xidx = xidx + numel(Bresid);


%% Impose all zeros that we know explicitly from the case
idx = false(size(Binfo));
if num_tau == 2
    idx(1:2,1:3,:) = true;
elseif num_tau == 3 
    idx(1:3,1:4,:) = true;
end
    
   
if par.ai

    % if p observed, there is no firm wedge (subs below)
    if par.pcon  
        idx(3,:,:) = false;
        idx(:,3,:) = false;
    end
    
    %no household wedges
    if par.hhno
        idx(3,:,:) = false;
    end

    %firms and hh see productivity
    if par.hhna && par.fna
        idx(:,4,:) = false;
    end
    
    %hh see productivity
    if par.hhna && ~par.fna
        idx([1,3],4,:) = false;
    end
    
    %if firm observes agg tfp, then joint taux = -hh taux on tfp (no firm
    %loading on tfp) (subs below)
    if  par.fna && ~par.hhna
        idx(3,4,:) = false;
    end
    
end

Binfo(idx) = coeff(xidx+(1:sum(idx(:))));
xidx = xidx+sum(idx(:));

%% Equality case between firm and hh taux
if par.ai && par.pcon % if p observed, there is no firm wedge
    Binfo(3,:,:) = -Binfo(2,:,:);              
elseif par.ai && par.fna && ~par.hhna
    Binfo(3,4,:) = -Binfo(2,4,:);  %if firm observes agg tfp, then joint taux = -hh taux on tfp (no firm loading on tfp)
end


%% Productivity processes
xidx      = xidx+1;
da_info = szeros([1,size(Binfo,2),par.MAorderLHS+1],par.sym);
da_info(1,end,1) =  coeff(xidx);

xidx       = xidx+1;
da_resid = szeros([1,size(Bresid,2),par.MAorderLHS+1],par.sym);
da_resid(1,end,1) =  coeff(xidx);


%% compute macro moments from info wedges
[cMacro,idxMacro,~,targ_info,dy_info] = macroC(Binfo,da_info,par);

%% compute macro moments from resid wedges
[~,~,~,targ_resid,dy_resid] = macroC(Bresid,da_resid,par);

%% data matching 
ceqm = -vec(targ_info+targ_resid-targ_data);
ceq = [];

%% aggregate orthogonality tests

%Wedge cannot depend on A
ceqa = vec(Binfo(:,end,:));

%Lagged observations
ceq4  = vec(Binfo(:,:,5:end));
ceq8  = vec(Binfo(:,:,9:end));
ceq12 = vec(Binfo(:,:,13:end));



%% parametrization of micro process

if ~par.pcon && ~par.hhno
    nn = num_tau;
else
    nn = 2;
end

% tau on tau
tau_tau = reshape(coeff(xidx+(1:nn^2*(par.MAorderRHS+1))),[nn nn par.MAorderRHS+1]);
xidx = xidx + nn^2*(par.MAorderRHS+1);

% tau on z
tau_z = reshape(coeff(xidx+(1:nn*(par.MAorderRHS+1))),[nn 1 par.MAorderRHS+1]);
xidx = xidx + nn*(par.MAorderRHS+1);

% tau on a_ma
tau_w = reshape(coeff(xidx+(1:nn*(par.MAorderRHS+1))),[nn 1 par.MAorderRHS+1]);
xidx = xidx + nn*(par.MAorderRHS+1);

if par.ai && par.pcon
    %No firm wedges at micro level
    tau_tau = [tau_tau ; -tau_tau(2,:,:)];
    tau_z   = [tau_z   ; -tau_z(2,:,:)];
    tau_w   = [tau_w   ; -tau_w(2,:,:)];
elseif par.ai && par.hhno
    %No household wedges at micro level
    tau_tau =   [tau_tau ; 0*tau_tau(2,:,:)];
    tau_z   =   [tau_z   ; 0*tau_z(2,:,:)];
    tau_w   =   [tau_w   ; 0*tau_w(2,:,:)];
end  

% tau loading on mu (persistent component of a)
tau_muh = reshape(coeff(xidx+(1:2*(par.MAorderRHS+1))),[2 1 par.MAorderRHS+1]);% this [tauc, taux]
xidx    = xidx + 2*(par.MAorderRHS+1);

if ~par.ai % symmetric info case: both observe a
       tau_mu  = [tau_muh];
else % asymmetric: hh don't observe a
     if ~par.pcon % firms have wedge (p not in info) and observe a
       tau_muf = reshape(coeff(xidx+(1:1*(par.MAorderRHS+1))),[1 1 par.MAorderRHS+1]); xidx = xidx + 1*(par.MAorderRHS+1);
       tau_mu  = [tau_muh ; tau_muf-tau_muh(2,:,:)];        
    else % firms have no wedge
        tau_mu = [tau_muh ; -tau_muh(2,:,:)];
    end
end

%% compute micro moments
[cMicro,idxMicro] = microC(tau_tau,tau_z,tau_mu,tau_w,par);

%% implementation constraint wrt c,y,w (wrt a is imposed above)
ma = min(par.MAorderLHS,par.MAorderRHS)+1;

if par.MAorderLHS+1 > ma
    cMicro(:,:,par.MAorderLHS+1)=0;
end

if par.MAorderRHS+1 > ma
    cMacro(:,:,par.MAorderLHS+1)=0;
end

if par.ai%asymmetric info

    % taupf = taup + tauph
    cMacro(4,:,:) = cMacro(2,:,:) + cMacro(3,:,:);
    cMicro(4,:,:) = cMicro(2,:,:) + cMicro(3,:,:);
    
    ceq = [ceq;
        %household: c
        vec( cMacro([1 3],idxMacro.dy,1:ma) + cMicro([1 3],idxMicro.dc,1:ma) );
        
        %household: n
        vec( cMacro([1 3],idxMacro.dyhat,1:ma) + cMicro([1 3],idxMicro.dy,1:ma) - cMicro([1 3],idxMicro.da,1:ma) );
        
        %firm: y
        vec( cMacro(4,idxMacro.dy,1:ma) + cMicro(4,idxMicro.dy,1:ma) );
        
        %firm: a
        vec( cMacro(4,idxMacro.da,1:ma)    + cMicro(4,idxMicro.da,1:ma) );
        
        %both: w
        vec( cMacro(1:3,idxMacro.dw,1:ma) + cMicro(1:3,idxMicro.dw,1:ma) );
        
        ];
       
    if par.pcon
        ceq = [ceq;
            
        % impose price constraint only for firms
        vec( cMacro(4,idxMacro.pi,1:ma) + cMacro(4,idxMacro.dy,1:ma)/par.theta  + cMicro(4,idxMicro.dz,1:ma) );
        
        % impose price constraint for everyone -- nope: doesn't work
        % since hh doesnt know y
        %vec( cMacro(1:3,idxMacro.pi,1:ma) + cMacro(1:3,idxMacro.dy,1:ma)/par.theta  + cMicro(1:3,idxMicro.dz,1:ma) );
        ];
    end

else%symmetric info
    
    ceq = [ceq;
        %c
        vec( cMacro(:,idxMacro.dy,1:ma)    + cMicro(:,idxMicro.dc,1:ma) );
        
        %y
        vec( cMacro(:,idxMacro.dy,1:ma)    + cMicro(:,idxMicro.dy,1:ma) );
        
        %a
        vec( cMacro(:,idxMacro.da,1:ma)    + cMicro(:,idxMicro.da,1:ma) );
        
        ];
    
    if par.pcon  
    ceq = [ceq;
        vec( cMacro(:,idxMacro.pi,1:ma) + cMacro(:,idxMacro.dy,1:ma)/par.theta  + cMicro(:,idxMicro.dz,1:ma) );
        ];
    end
end

%% No household
if par.ai
    ceqh = vec(Binfo([1,3],:,:));
    ceqh = [ceqh; vec(tau_tau([1,3],:,:)) ; vec(tau_w([1,3],:,:)) ; vec(tau_mu([1,3],:,:)) ; vec(tau_z([1,3],:,:)) ] ;
else
    ceqh = [];
end

%% objective
% business cycle VD to be implemented, for now max frac of tau_x and tau_h

%just tau x
tau_info  = Binfo(1:2,:,:);
tau_resid = Bresid(1:2,:,:);

Btfp_info  = tau_info ; Btfp_info (:,1:end-1,:) = 0;
Btfp_resid = tau_resid; Btfp_resid(:,1:end-1,:) = 0;

Bnon_info  = tau_info ; Bnon_info(:,end,:)  = 0;
Bnon_resid = tau_resid; Bnon_resid(:,end,:) = 0;


%Unconditional Variances
var_info  = covxy(tau_info,tau_info,0);
var_resid = covxy(tau_resid,tau_resid,0);

var_tfp_info  = covxy(Btfp_info,Btfp_info,0);
var_tfp_resid = covxy(Btfp_resid,Btfp_resid,0);

var_non_info  = covxy(Bnon_info,Bnon_info,0);

var_all = var_info + var_resid;



%% Filtered Variance of GDP
load input_files/fmattmp fmattmp    %Just the BK filter weights
bk_non_info  = sym(0);
bk_all = sym(0);
bk_all_hat = sym(0);

dy_non_info = dy_info; dy_non_info(:,end,:) = 0;

for jj = 0:min(par.MAorderLHS+1,length(fmattmp)-1) 
    bk_non_info  = bk_non_info  + fmattmp(jj+1)*covxy(dy_non_info,dy_non_info,jj);

    bk_all          = bk_all       + fmattmp(jj+1)*targ_data(1,1,jj+1);
    bk_all_hat      = bk_all_hat       + fmattmp(jj+1)*targ_dyhat(1,1,jj+1);
end

%% VD of filterd objective

%Taux/output VD
f     = -diag(bk_non_info);
vd    = bk_non_info/bk_all;
vd(2) = bk_non_info/bk_all_hat;
vd(3) = var_tfp_info(2,2) /var_all(2,2);
vd(4) = var_non_info(1,1) /var_all(1,1);
vd(5) = var_non_info(2,2) /var_all(2,2);

xvec_tmp = symvar(subs(symvar([f;vd(:);Binfo(:);Bresid(:);tau_tau(:);tau_z(:);tau_mu(:);tau_w(:);da_info(:);da_resid(:)]),[par.rho_a, par.rho_z, par.sig_a, par.sig_w, par.sig_z], randn(1,5)));

%% Parameter counting
xidx
disp(['params avail/used/df:  ' num2str([length(coeff),length(xvec_tmp),length(xvec_tmp)-size(ceq,1)])]);


end