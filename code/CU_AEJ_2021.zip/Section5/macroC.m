function [C,idx,varpi,D,dy_full,targ_dyhat] = macroC(tau,da,par)
% C = cov(tau,[dy ; dyhat ; yhat ; pi ; da ])
% D = var([yhat ; pi; da  ])

MAorder = par.MAorderLHS;
num_s = size(tau,2);

%--------------
%note:
%order of variables is tauc, taux , (tauxh)
%order of innovations is (tau, eps )

%% yhat
yhat = par.xi*tau(2,:,:);

%% dyhat (truncated to h MA coeffs, since h+1 doesnt matter for cov with tau
dyhat = yhat;
dyhat(:,:,2:end) = dyhat(:,:,2:end) - dyhat(:,:,1:end-1);

dyhat_full = dyhat;
dyhat_full(:,:,end+1) = -yhat(:,:,end);

%% dy = dyhat + eps
dy = dyhat + da;

da_full = da;
da_full(:,:,end+1) = 0;
dy_full = dyhat_full+da_full;

%% inflation
chat = -tau(1,:,:) + yhat;% c - tauc

pi0 = szeros([1,num_s],par.sym);
for ii = 0:MAorder
       pi0 = pi0 + (1/par.phi)^ii * chat(:,:,ii+1);
end

%MA terms
piMA = chat(:,:,1)-(1-1/par.phi)*pi0;%MA(0)
piMA(:,:,2:MAorder+1)  = chat(:,:,2:end)-chat(:,:,1:end-1);%MA(1:N)
piMA(:,:,end+1) = -chat(:,:,end);%MA(N+1)

%get first N coeffs from ARMA(1,N+1) characterizing inflation
pi = arma1NtoMA(par.phi,-reshape(permute(piMA,[3 2 1]),[MAorder+2,num_s]),MAorder,par.sym);
pi = reshape(pi.',[1 num_s MAorder+1]);

pi_full = pi;
pi_full(:,:,end+1) = 0;

%% dw
if par.ai
    %dtauf = dtaux + dtauxh
    dw = tau(2,:,:) + tau(3,:,:);
    dw(:,:,2:end) = dw(:,:,2:end) - dw(:,:,1:end-1);
    
    %dw = dtauf + pi + eps
    dw = dw + pi + da;  
          
end



%% stack everything into big vector
dB = [dy ; dyhat ; yhat ; pi ; da ];
if par.ai
    dB = [dB; dw]; %No dw here
end

idx.dy    = 1;
idx.dyhat = 2;
idx.yhat  = 3;
idx.pi    = 4;
idx.da    = 5;

if par.ai
    idx.dw = 6;
end


%% compute covariance terms between tau and d(tau,a,z,y,c,w)

C = szeros([size(tau,1),size(dB,1),MAorder+1],par.sym);
for ii = 0:MAorder
    
    C(:,:,ii+1) = covxy(tau,dB,ii);
        
end

%% compute covariance terms between [dy,pi,da] and sometimes [dw] (used for data constraint only, right?)
dB2 = [dy_full ; pi_full; da_full  ]; % equivalent to yhat
 
if par.ai
    dB2 = [dB2];%No dw here
end

D = szeros([size(dB2,1),size(dB2,1),MAorder+1],par.sym);
targ_dyhat = szeros([1,1,MAorder+1],par.sym);
for ii = 0:MAorder+1 
    D(:,:,ii+1) = covxy(dB2,dB2,ii);
    targ_dyhat(:,:,ii+1) = covxy(dyhat_full,dyhat_full,ii);
        
end




%% compute var(pi) (used for exercise 1)
varpi = sum(ssum(pi.*pi,3,par.sym));



end