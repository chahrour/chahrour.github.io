%% Generating Symbolic Outputs

% symbolic objective + constraints
xvec = sym('x',[par.numpars 1],'real');

%---- EX 2 Files
if par.ex == 2
    tic
    par.sym=1;
    [f_,ceqm_,ceq_,ceqa_,ceq4_,ceq8_,ceq12_,ceqh_,vd_] = make_all_ex2(xvec,par,targ_data,targ_dyhat);
    toc
   
    %% Computing input for Qaud-Quad
    tic
    np = par.numpars;
    
    %Variables in workspace for eval (faster than subs)
    for jj = 1:length(xvec); eval([char(xvec(jj)) '=0;']);end
    
    %Objective 
    cobj   = eval(f_); df_ = jacobian(f_,xvec);
    fobj   = eval(df_)';
    Qobj   = sparse(double(jacobian(df_,xvec)));
  
    %Constraints
    ceq_all = 100*[ceqm_;ceq_];
    ncon    = length(ceq_all);

    Hcon    = cell(1,ncon);
    kcon    = cell(1,ncon);
    dcon    = cell(1,ncon);
    %Get quadratic constraint terms
    parfor ii = 1:ncon
        dcon{ii} = ceq_all(ii);
        kcon{ii} = jacobian(ceq_all(ii),xvec).';
        ddtmp_   = jacobian(kcon{ii},xvec);
        Hcon{ii} = sparse(double(ddtmp_));
        disp(num2str(ii))
    end
    toc
    

    %Eliminate terms where possible
    tic
    tmp = double(eval(ceq_all));
    for ii = 1:ncon
        dcon{ii} = tmp(ii);
    end
    kcon  = eval([kcon{:}]);
    
    %Save files
    suff  = [aisuff{par.ai+1} psuff{par.pcon+1}  hhnosuff{par.hhno+1} fnasuff{par.fna+1} hhnasuff{par.hhna+1}];
    kname = ['../auto_generated/kvals' suff '.m'];
    matlabFunction(kcon,'File', kname, 'Optimize', false, 'Vars', {pvec}', 'Sparse',true);
    save(['../auto_generated/qcqp' suff], '*obj', '*con');
    
    vdname = ['../auto_generated/vd' suff '.m'];
    matlabFunction(vd_,'File', vdname, 'Optimize', false, 'Vars', {xvec,pvec}', 'Sparse',true);
  
    toc
end
rehash;