function par = par_count(par)

%---- count parameters for each case

%idio
if ~par.ai
    %symmetric info
    par.numpars = 10*(par.MAorderRHS+1);
elseif par.pcon || par.hhno
    %asymmetric info + either no firm wedge or no hh wedge
    par.numpars = 10*(par.MAorderRHS+1);
else
    %asymetric info + p is not observed
    par.numpars = 18*(par.MAorderRHS+1);
end

%agg param counts
if par.ex==1
    %% Exercise 1
    if ~par.ai
        par.numpars = par.numpars  + 4*(par.MAorderLHS+1);
    elseif  par.ai && (~par.pcon && ~par.hhno)
        par.numpars = par.numpars  + 9*(par.MAorderLHS+1); 
    elseif  par.ai && (par.pcon || par.hhno)
        par.numpars = par.numpars  + 6*(par.MAorderLHS+1);
    end
    
elseif par.ex==2
    %% Exercise 2
    if par.ai == false
        par.numpars = par.numpars  + 2*6*(par.MAorderLHS+1)   + 2;
    elseif par.ai
        if par.pcon
            par.numpars = par.numpars  + (6+12)*(par.MAorderLHS+1)+ 2; 
        elseif ~par.pcon
            if par.hhno
                par.numpars = par.numpars  + (8+12)*(par.MAorderLHS+1) + 2;
            elseif par.fna && par.hhna
                par.numpars = par.numpars  + (2*12-3)*(par.MAorderLHS+1)  + 2;
            elseif par.fna && ~par.hhna
                par.numpars = par.numpars  + (2*12-1)*(par.MAorderLHS+1)  + 2;
            elseif ~par.fna && par.hhna
                par.numpars = par.numpars  + (2*12-2)*(par.MAorderLHS+1)  + 2;
            else
                par.numpars = par.numpars  + 2*12*(par.MAorderLHS+1)  + 2;
            end
        end
    end
end

