t0 = tic;

%% Parameters shared across Section 5 exercises
setup

%% Generate files for 5 cases in SECTION 5 (~20 mins total)
for mm = 1:4
   par = info_par2{mm};
   generate_file 
end

%% Run optimization for 5 cases in SECTION 5 (~2hrs on a quad core)
for mm = 1:5
    par = info_par2{mm};
    if mm == 5
        setup
        par = info_par2{mm};
        pvec_num(1) = 26;     %Rescale local variance so that IID shock generates same local productivity dispersion.
        pvec_num(2:end) = 0;  %Other local shocks off.
    end
    ex2quant
end
toc(t0);

return
%% Run single case by hand
%{
setup
par = info_par2{1}; % select exercise + case here
generate_file
ex2quant; % choose between ex1frontier, ex1comp and ex2quant
%}