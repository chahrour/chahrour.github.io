%****************************************
% SETUP FILES FOR EX2
%****************************************
addpath('../helper_functions');
addpath('../auto_generated')

%---- which exercise?
par.optimize = false;
par.sym      = true;

%---- case naming
exsuff   = {'ex1', 'ex2' };
aisuff   = {'', '_ai' };
psuff    = {'', '_pcon'};
hhnosuff = {'', '_hhno'};
fnasuff  = {'', '_fna'};
hhnasuff = {'', '_hhna'};

%---- deep parameters
par.beta  = 0.99;
par.xi    = 2/3; 
par.theta = 7.5; 
par.phi   = 1.5; 
par.del   = (par.theta^-1 + par.xi^-1 -1)^-1;


%---- relevant parameters, not used yet
par.ai    = NaN; % asymmetric info (hh: c,a,w. firms: y,a,w, and p if par.pcon=1)
par.pcon  = NaN; % p in info set (only for firms if par.ai=1)
par.hhno  = NaN; % no hh wedge at all
par.fna   = NaN; % firm observes agg tfp
par.hhna  = NaN; % hh observe agg tfp

%---- MA order
par.MAorderRHS = 14;%order of micro MA terms (full info horizon)
par.MAorderLHS = 14;%order of macro MA terms (revelation of agg state)

%---- idiosyncratic fundamental shocks (note a is called x in the text!)
syms rho_a sig_a sig_w rho_z sig_z ary cpy
pvec   = [sig_a  sig_w  sig_z  rho_a rho_z ].';

par.sig_a = pvec(1);
par.sig_w = pvec(2);
par.sig_z = pvec(3);
par.rho_a = pvec(4);
par.rho_z = pvec(5);

pvec_num = [5.52, 4.78, 25.04, 0.9764, 0.9764].';
pname    = {'siga', 'sigw', 'sigz', 'rhoaz'};

%----- ex2: generate aggregate data moments from wedges
load input_files/MAest Bdat da_dat  %MAest is MA rep of the estimated wedge process
                         
                         
pardata     = par;
pardata.sym = false;
pardata.ai  = 0  ;
[~,~,~,targ_data,dy,targ_dyhat]   = macroC(Bdat(1:2,:,1:par.MAorderLHS+1),da_dat(:,:,1:par.MAorderLHS+1), pardata);
targ_data = double(targ_data);

%% Cases for EX2

par.ex    = 2;  %1 or 2
par.nom   = 0;

%---- what cases do we want?
info_nms2 = {'asymbase', 'symbase', 'notfp', 'nodemand','nosent'};
info_par2 = cell(1,5);

%---- base
par.ai    = 1; % asymmetric info 
par.pcon  = 0; % p not in info set
par.hhno  = 0; % yes hh wedge 
par.fna   = 0; % firms do not see tfp 
par.hhna  = 0; % hh do not see tfp  
info_par2{1} = par_count(par);

%---- symmetric base
par.ai    = 0; % symmetric info 
par.pcon  = 0; % p not in info set
par.hhno  = 0; % yes hh wedge 
par.fna   = 0; % firms do not see tfp
par.hhna  = 0; % hh do not see tfp  
info_par2{2} = par_count(par);

%---- no tfp uncertainty
par.ai    = 1; % asymmetric info 
par.pcon  = 0; % p not in info set 
par.hhno  = 0; % yes hh wedge
par.fna   = 1; % firms see tfp (requires ai = 1)
par.hhna  = 1; % hh see tfp  (requires ai = 1)
info_par2{3} = par_count(par);

%---- no demand
par.ai    = 1; % asymmetric info
par.pcon  = 1; % p in info set (only for firms since par.ai=1)
par.hhno  = 0; % yes hh wedge
par.fna   = 0; % firms do not see tfp
par.hhna  = 0; % hh do not see tfp  
info_par2{4} = par_count(par);

%---- no sentiment (baseline & will set siga=sigz=0)
par.ai    = 1; % asymmetric info 
par.pcon  = 0; % p not in info set
par.hhno  = 0; % yes hh wedge 
par.fna   = 0; % firms do not see tfp 
par.hhna  = 0; % hh do not see tfp 
info_par2{5} = par_count(par);





