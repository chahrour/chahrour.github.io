
% load data
[frac_bl,res_bl,row_bl]       = extract_min_ex2('../output_files/ex2_ai',.1);           % baseline
[frac_fna,res_fna,row_fna]    = extract_min_ex2('../output_files/ex2',.1);              % common info set baseline
[frac_na,res_na,row_na]       = extract_min_ex2('../output_files/ex2_ai_fna_hhna',.1);  % firms and households observe aggregate TFP
[frac_add,res_add,row_add]    = extract_min_ex2('../output_files/ex2_ai_nsigaz',.1);    % no siga or sigz (akak no sentiments)
[frac_yesp,res_yesp,rho_yesp] = extract_min_ex2('../output_files/ex2_ai_pcon',.1);      % no firm wedges at all

max_max = max(frac_bl);


figure(3)
set(gcf, 'Position', [800,1000,400,300])


opts1 = {'-','Color','r','LineWidth',2};
opts2 = {'.','Color',[.2 .2 1],'MarkerSize',15,'MarkerEdgeColor',[.2 .2 1],'MarkerFaceColor',[.75 .75 1]};
opts3 = {'--','Color',[38 129 58]/255,'MarkerSize',7,'LineWidth',2};
opts4 = {'-','Color',[0 0 .5],'LineWidth',2};
opts5 = {'s','Color',[.2 .2 .2],'MarkerSize',7,'MarkerEdgeColor',[.2 .2 .2],'MarkerFaceColor',[.7 .7 .7]};

load ../output_files/ex2_ai std_gr
h(1)=plot(std_gr,frac_fna./max_max,opts2{:}); hold on
h(2)=plot(std_gr,frac_bl./max_max,opts1{:}); hold on
h(3)=plot(std_gr,frac_na./max_max,opts3{:}); hold on
h(4)=plot(std_gr,frac_add./max_max,opts5{:}); hold on
h(5)=plot(std_gr,frac_yesp./max_max,opts4{:}); hold on

hold off
set(gca, 'XScale', 'log')

legend(h,...
    'symmetric info benchmark',...
    'heterogeneous info benchmark',...    
    'no TFP-driven confidence',...        
    'no sentiment-driven confidence',...
    'no demand uncertainty',...
    'location','eastoutside')

set(gca, ...
  'Box'         , 'off'     , ...
  'TickDir'     , 'out'     , ...
  'TickLength'  , [.02 .02] , ...
  'XMinorTick'  , 'on'      , ...
  'YMinorTick'  , 'on'      , ...
  'YGrid'       , 'on'      , ...
  'XTick'       , [.1,1,10]   , ...
  'LineWidth'   , 1         );



xlabel('Scale of micro shocks')
ylabel('Variance contribution')

