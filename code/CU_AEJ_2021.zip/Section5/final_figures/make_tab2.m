% load data
[frac_bl,res_bl,row_bl]       = extract_min_ex2('../output_files/ex2_ai',.1);           % baseline
[frac_fna,res_fna,row_fna]    = extract_min_ex2('../output_files/ex2',.1);              % common info set baseline
[frac_na,res_na,row_na]       = extract_min_ex2('../output_files/ex2_ai_fna_hhna',.1);  % firms and households observe aggregate TFP
[frac_add,res_add,row_add]    = extract_min_ex2('../output_files/ex2_ai_nsigaz',.1);    % no siga or sigz (akak no sentiments)
[frac_yesp,res_yesp,row_yesp] = extract_min_ex2('../output_files/ex2_ai_pcon',.1);      % no firm wedges at all

max_max = max(frac_bl);

%make table
disp('Table 2 Numbers:')
tab2 = [row_bl;row_fna;row_na;row_add;row_yesp];
tab2(:,1) = tab2(:,1)./max_max;
disp(tab2)

disp(['Section IV.B (~page 34) - share of non-tfp output, if TFP observed: ' num2str(row_na(1)./max_max)]);
disp(['Section IV.B (~page 34) - share of non-tfp output, if no sentiment: ' num2str(row_add(1)./max_max)]);
disp(' ');