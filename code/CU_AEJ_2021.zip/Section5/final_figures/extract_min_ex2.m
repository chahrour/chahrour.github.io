function [fmax,resid_out,row] = extract_min_ex2(file,thresh)

% default tolerance for residual
if nargin<2
    thresh = .05;
end

load(file,'fout','rout','frac_out','flag_out')

% select variable of interest [currently = contribution to non-tfp cycle in y and yhat]
targ = frac_out(1,:,:); 

% check for feasibility
resid = sum(abs(rout));
targ(resid>thresh) = -inf;

[fmax,idx] = max(targ,[],2);

fmax = squeeze(fmax);

%Table 2 output
scl_idx = (length(fmax)-1)/2+1;  %Q. What index captures the baseline scaling of micro moments? A. Halfway point.
row = [frac_out(1,idx(scl_idx),scl_idx), frac_out(1,idx(scl_idx),scl_idx), frac_out(2,idx(scl_idx),scl_idx)];


resid_out = zeros(size(fmax));
for ii=1:size(resid,3)
    resid_out(ii) = resid(1,idx(ii),ii);    
end


end