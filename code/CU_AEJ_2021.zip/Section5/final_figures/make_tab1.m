load ../input_files/MAest.mat mom_tau

ac = [mom_tau(1,1,2)./mom_tau(1,1,1);mom_tau(2,2,2)./mom_tau(2,2,1);0];

tab1 = [sqrt(diag(mom_tau(:,:,1)))/100,ac,  [1,NaN,NaN;
                                          mom_tau(1,2,1)./sqrt(mom_tau(1,1,1)*mom_tau(2,2,1)),1,NaN;
                                          mom_tau(1,3,1)./sqrt(mom_tau(1,1,1)*mom_tau(3,3,1)), mom_tau(2,3,1)./sqrt(mom_tau(2,2,1)*mom_tau(3,3,1)),1]];
disp('Table 1 numbers:')
disp(tab1)
