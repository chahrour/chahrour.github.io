%--- which version
cname  = [aisuff{par.ai+1} psuff{par.pcon+1}  hhnosuff{par.hhno+1} fnasuff{par.fna+1} hhnasuff{par.hhna+1}];

%---- load fixed parameters for loss function
load(['../auto_generated/qcqp' cname], 'Qobj', 'fobj', 'cobj', 'Hcon','dcon');

%---- optimizer parameters
options = optimoptions(@fmincon,'Algorithm','interior-point',...
    'SpecifyObjectiveGradient',true,'SpecifyConstraintGradient',true,...
    'HessianFcn',@(x,lambda)quadhess(x,lambda,Qobj,Hcon));

options.SubproblemAlgorithm = 'cg';
options.CheckGradients = false;
options.OptimalityTolerance = 1e-4;%1e-4;
options.UseParallel = false;

options.Display = 'final';
options.MaxFunctionEvaluations = 1.2*30000;
options.MaxIterations = 1.2*10000;

%---- count parameters needed
par_count(par)

%---- Initial point & bounds
rng(1500);
nstart = 4;8;10;
x0 = (rand(par.numpars,nstart)-.5)/5;
lbnd = -25 + 0*x0(:,1);
ubnd =  25 + 0*x0(:,1);
x0(:,1) = .01;

%---- STD scale grid
std_gr = logspace(log10(.1),log10(10),9);%logspace(log10(.1),log10(10),9);
%std_gr = std_gr(1);
np     = length(std_gr);
rho_gr = repmat(0.9764,[1,np]);


tic
%---- Main loop
ncon     = length(Hcon);
xout     = nan  (par.numpars,nstart,np);
fout     = zeros(1          ,nstart,np);
rout     = zeros(ncon       ,nstart,np);
flag_out = zeros(1          ,nstart,np);
frac_out = zeros(5          ,nstart,np);
time_out = zeros(1          ,nstart,np);

ss_vec = repmat(1:nstart,[1,np]);
jj_vec = vec(repmat((1:np)',[1,nstart])');
for jj = 1:np
    tic
    disp(['Case: ' num2str(jj)])
    parfor ss = 1:nstart
        pvec_tmp      = pvec_num;
        pvec_tmp(1:3) = std_gr(jj)*pvec_num(1:3);
        pvec_tmp(4:5) = rho_gr(jj);
        
        %Only the kvals depend on parameters
        kvals  = full(feval(['kvals'   cname],pvec_tmp));
        kcon   = num2cell(kvals,[1,size(kvals,2)]);
        
        obj_   = @(x)quadobj(x,Qobj,fobj,cobj);
        nlcon_ = @(x)quadconstr(x,Hcon,kcon,dcon);
        
        [xout(:,ss,jj),fout(:,ss,jj),flag_out(:,ss,jj)] = fmincon(obj_,x0(:,ss),[],[],[],[],lbnd,ubnd,nlcon_,options);
        
        [~,rout(:,ss,jj)]   = nlcon_(xout(:,ss,jj));
        frac_out(:,ss,jj)   = feval(['vd' cname],xout(:,ss,jj),pvec_tmp);
        
    end
    
    x0 = xout(:,:,jj);

end

xout     = reshape(xout,[par.numpars,nstart,np]);
fout     = reshape(fout,[1,nstart,np]);
rout     = reshape(rout,[ncon,nstart,np]);
flag_out = reshape(flag_out,[1,nstart,np]);
frac_out = reshape(frac_out,[5,nstart,np]);
toc

%% Getting numbers from make_all_ex2
parout = par;
parout.sym = 0;
parout.sig_a = pvec_num(1);
parout.sig_w = pvec_num(2);
parout.sig_z = pvec_num(3);
parout.rho_a = pvec_num(4);
parout.rho_z = pvec_num(5);

add_on = [];
if pvec_num(3) == 0
    add_on = '_nsigaz';
end
save(['output_files/ex2' cname add_on], 'fout','rout','frac_out','flag_out', 'std_gr','np','rho_gr')


