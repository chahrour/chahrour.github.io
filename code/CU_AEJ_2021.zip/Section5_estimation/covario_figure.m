function f = covario_figure(dat,bands,corr_opt,var_list,fig_title,varargin)

nv = length(var_list);

titles = cell(nv^2,1);
for k = 1:nv
    for l = 1:nv
        % added "\ " to correct spacing in latex (tikz)
        titles{l+nv*(k-1)} = [var_list{1,k} ' \normalfont{vs.}\ '  var_list{1,l}];
    end
end

f = make_figure(dat, bands, titles, corr_opt, fig_title, varargin{1}, varargin{2});

% Make Figure - Based on code of ir_figure.m
%
% usage
%
% fig_out = ir_fig(y,var_list, cor_opt, fig_title, lstyle(optional))
%
% where
%
% y = a TxN matrix of impulse responses
% var_list = name of the variables plotted
% fig_title = Title for entire figure
% lstyle = a cellarray of line style (eg 'r-*' means red, stared line). '-' is default.
% legend = a cellarray of titles for each IR plotted

function fig = make_figure(y, bands, var_list, cor_opt, fig_title,  varargin)
lw = [1.5,1.5,1.5,1.5,1.5,1.5];
%Create figure, set size
fig = figure(4);
set(fig, 'PaperOrientation','landscape', 'PaperPosition', [.25, .25, 10,7]);


%Figure dimensions
n = length(var_list);
n_col = ceil(sqrt(n));
n_row = ceil(n/n_col);
n_slide = size(y,3);  %Are there confidence bands
if size(y,2) ~= n
    error('Unequal number of columns and variable titles');
end
t = size(y,1);

%Choose Line Style
if ~isempty(varargin)
    lstyle = varargin{1};
else
    lstyle = {'-'};
end

%Plot each IR
for j = 1:n
    s = subplot(n_row,n_col,j);
    hold on
    
    %Shading first
    if ~isempty(bands)
        xx = [1:t,t:-1:1];
        yy = [bands(:,j,1)', fliplr(bands(:,j,2)')];
        %f = fill(xx,yy,'b');
        f = patch(xx,yy,'b');
        set(f, 'FaceColor', [.8,.8,.8]);
        set(f, 'FaceAlpha',  .4);
        set(f, 'EdgeColor', [.5,.5,.5]);
        set(f, 'EdgeAlpha',  .4);
        
        
%         f.FaceColor = [.8,.8,.8];
%         f.FaceAlpha = .4;
%         f.EdgeColor = [.5,.5,.5];
%         f.EdgeAlpha = .4;
    end
    
    %Now plots
    cmap = [
        0         0         0
        0         0.4470    0.7410
        0.8500    0.3250    0.0980
        0         0.4470    0.7410
        
        0.9290    0.6940    0.1250
        0.4940    0.1840    0.5560
        0.4660    0.6740    0.1880
        0.3010    0.7450    0.9330
        0.6350    0.0780    0.1840
        ];
    for k = 1:n_slide
        p = plot([1:t]', y(:,j,k), lstyle{k}, 'linewidth', lw(k),'color',cmap(k,:));
    end
    
    plot([1:t]', 0*[1:t]', ':k');
    tt = title(var_list{j}, 'fontsize', 10, 'interpreter', 'latex');

    if j ==1
        %xlabel('j')
        if cor_opt
           % ylabel([ '\rho(x_t, x_{t+j})']);
        else
           % ylabel([ '\sigma(x_t, x_{t+j})']);
        end
    end
    set(s, 'xlim', [1,t],'Xtick', [1:t],'XTickLabel', [0:1:t-1], 'fontsize', 8);
   
    %Legend
    if n_slide > 1 && ~isempty(varargin{2}) && j/n_col == 1
        l=legend(s.Children(end-1:-1:(end-n_slide)),varargin{2}, 'Location', 'NorthEast', 'Fontsize', 10);
    end
end

%Title on figure
if ~isempty(fig_title)
    suptitle(fig_title);
end


function hout=suptitle(str)
%SUPTITLE puts a title above all subplots.
%
%	SUPTITLE('text') adds text to the top of the figure
%	above all subplots (a "super title"). Use this function
%	after all subplot commands.
%
%   SUPTITLE is a helper function for yeastdemo.

%   Copyright 2003-2010 The MathWorks, Inc.


% Warning: If the figure or axis units are non-default, this
% will break.

% Parameters used to position the supertitle.

% Amount of the figure window devoted to subplots
plotregion = .92;

% Y position of title in normalized coordinates
titleypos  = .95;

% Fontsize for supertitle
fs = get(gcf,'defaultaxesfontsize')+4;

% Fudge factor to adjust y spacing between subplots
fudge=1;

haold = gca;
figunits = get(gcf,'units');

% Get the (approximate) difference between full height (plot + title
% + xlabel) and bounding rectangle.

if (~strcmp(figunits,'pixels')),
    set(gcf,'units','pixels');
    pos = get(gcf,'position');
    set(gcf,'units',figunits);
else
    pos = get(gcf,'position');
end
ff = (fs-4)*1.27*5/pos(4)*fudge;

% The 5 here reflects about 3 characters of height below
% an axis and 2 above. 1.27 is pixels per point.

% Determine the bounding rectangle for all the plots

% h = findobj('Type','axes');

% findobj is a 4.2 thing.. if you don't have 4.2 comment out
% the next line and uncomment the following block.

h = findobj(gcf,'Type','axes');  % Change suggested by Stacy J. Hills

max_y=0;
min_y=1;
oldtitle = NaN;
numAxes = length(h);
thePositions = zeros(numAxes,4);
for i=1:numAxes
    pos=get(h(i),'pos');
    thePositions(i,:) = pos;
    if (~strcmp(get(h(i),'Tag'),'suptitle')),
        if (pos(2) < min_y)
            min_y=pos(2)-ff/5*3;
        end;
        if (pos(4)+pos(2) > max_y)
            max_y=pos(4)+pos(2)+ff/5*2;
        end;
    else
        oldtitle = h(i);
    end
end

if max_y > plotregion,
    scale = (plotregion-min_y)/(max_y-min_y);
    for i=1:numAxes
        pos = thePositions(i,:);
        pos(2) = (pos(2)-min_y)*scale+min_y;
        pos(4) = pos(4)*scale-(1-scale)*ff/5*3;
        set(h(i),'position',pos);
    end
end

np = get(gcf,'nextplot');
set(gcf,'nextplot','add');
if ishghandle(oldtitle)
    delete(oldtitle);
end
axes('pos',[0 1 1 1],'visible','off','Tag','suptitle');
ht=text(.5,titleypos-1,str);set(ht,'horizontalalignment','center','fontsize',fs);
set(gcf,'nextplot',np);
axes(haold); %#ok<MAXES>
if nargout,
    hout=ht;
end



