function [sigdat,Vdat,bands,idxv,beta_correct,mu_correct,loss_pure,sigdat_sim] = make_targets(opt,trend,Ydat,Ydat_fd,targ_nms)
nser = size(Ydat,2);

struct2val(opt);

ny_dat = size(Ydat,2);


%**************************************************************************
% TARGET MOMENT ESTIMATES
%**************************************************************************
Ydat = Ydat(sum(~isnan(Ydat),2)==ny_dat,:);
Ydat = demean(Ydat);

%Get actual data-saving moments
sigdat = nan(ny_dat,ny_dat*(K+1)); %use 
for ll = 0:K
    %each bloc is cov(x(t),x(t-lag))
    %normalize by N not N-1 to be consistent with GMM-theory
    sigdat(:,ll*ny_dat+(1:ny_dat))=covdat_nan2new(Ydat',ll);
end


%**************************************************************************
% BOOTSTAP
%**************************************************************************

%Run a quick var on level data (1st differences now)
[beta,c,mu,~,X,YY,bet_const] = quick_var(Ydat_fd,nlag);
mu = demean(mu);
beta_mat = zeros(size(beta,1),size(beta,2),nboot);

%Bias correct original VAR?
for jj = 1:nboot
    ysample = quick_boot(beta,mu,length(Ydat)+2*bk_per,length(Ydat),zeros(nlag,ny_dat));
    beta_mat(:,:,jj) = quick_var(ysample,nlag);
end
beta_correct = 2*beta-mean(beta_mat,3);
cf_correct = companion_form(beta_correct');
YYhat = X*cf_correct';
mu_correct = YY - YYhat(:,1:nser)- repmat(bet_const,[size(X,1),1]);
mu_correct = demean(mu_correct);


%Bootstrap
covmar = zeros(ny_dat,ny_dat*(K+1),nboot);
[~,idxv ] = triuv(ones(size(covmar,1),size(covmar,2)));
idxv = find(idxv);  %Exclude repeated moments


for jj = 1:nboot
    %Bootstrap from VAR
    ysample = quick_boot(beta_correct,mu_correct,length(Ydat)+2*bk_per,length(Ydat),zeros(nlag,ny_dat));
    ysample = cumsum(ysample);  %integrate output;

        %Filter after simulation
        ysample = BK(ysample,bk_min,bk_max,bk_per);
        ysample = ysample(~isnan(ysample(:,1)),:);
 
    
    
    %Compute bootstrapped data-saving moments
    for ll = 0:K
        % normalize by N not N-1 to be consistent with GMM-theory
        covmar(:,ll*ny_dat+(1:ny_dat),jj) = covdat_nan2new(ysample',ll);
    end
end
sigdat_sim = mean(covmar,3);
loss_pure = nan;

%Covariance matrix for simulated moments
Vdat = reshape(covmar,[ny_dat*(ny_dat)*(K+1),nboot]);
Vdat = cov(Vdat(idxv,:)',1); % normalize by N, not by N-1



%**************************************************************************
% PLOT FIGURE
%**************************************************************************
corr_opt = 0;
covdat_sim = zeros(K+1,(ny_dat)^2,nboot);
for jj = 1:nboot
    covdat_sim(:,:,jj)  = covario_data(stack_3d(covmar(:,:,jj),ny_dat,0),K,corr_opt);
end
covdat_sim = sort(covdat_sim,3);
bands = covdat_sim(:,:,max(1,floor(.05*nboot)));
bands(:,:,2) = covdat_sim(:,:,min(ceil(.95*nboot),nboot));


