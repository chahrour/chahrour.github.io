%% download FRED data - last run on 9/28/2017.

com = input('Enter a 1 to import data: ');

if com

    url = 'https://research.stlouisfed.org/fred2/';
    c = fred(url);

    data.gdp  = fetch(c,'GDP');       % gdp
    data.pcnd = fetch(c,'PCND');      % non-durable consumption
    data.pcdg = fetch(c,'PCDG');      % durable goods consumption
    data.pcsv = fetch(c,'PCESV');     % services
    data.fpi = fetch(c,'FPI');        % fixed private investments
%    data.gce = fetch(c,'GCE');        % gov consumption + gross inv
    data.hrs = fetch(c,'HOANBS');     % hours worked
    data.def = fetch(c,'GDPDEF');     % deflator
    data.ffr = fetch(c,'FEDFUNDS');   % fed funds
    data.pop = fetch(c,'CNP16OV');    % population
    data.wag = fetch(c,'COMPRNFB');    % real hour compensation
    close(c);
    
    save 'data/fred_data.mat' data

end