function fmat = make_filter(n,bk_wghts,trend,s,S)
% computes (omega kron omega)*(LsS kron L0S)*F
% INPUTS:
%   n           = number of vars
%   bk_whgts    = BK-weights
%   trend       = location of trend-vars (empty for none)
%   s           = lag of cov that is to be computed (0 = contemp)
%   S           = lags of covariance vector that is multiplied

% infer k from BK_wghts
k  = (length(bk_wghts)-1)/2;

% make M1
M1 = zeros(1,n);
M1(trend)=1;
M1=diag(M1);

% computes sum of bk_weights(0:s-1).
beta_tilde = -fliplr(cumsum(bk_wghts));
%beta_tilde = -beta_tilde-bk_wghts; % flips order of x^k_-k, same as transposing Sig^k)

omega = kron(bk_wghts,eye(n)) + kron(beta_tilde,M1);

% quick-fix to implement first-difference filter
if k == 1
	beta_tilde = [0 1 0];
	omega = kron(bk_wghts,eye(n)-M1) + kron(beta_tilde,M1);
end


L0 = [speye(n*(2*k+1)), spzeros(n*(2*k+1),n*S)];
Ls = [spzeros(n*(2*k+1),n*s), speye(n*(2*k+1)), spzeros(n*(2*k+1),n*(S-s))];

OxO = kron(omega,omega);
LxL = kron(Ls,L0);
F   = construct_Fmat(n,2*k+S+1); 

fmat=OxO*LxL*F;


function F = construct_Fmat(nn,nl)
%
%nn = 5; % number of vars in Sig0
%nl = 4; % one plus number of lags (e.g., for Sig^2k, nl=2k+1)
%
% we want to construct F with dimensions (nl*nn)^2 x nl*nn^2, such that
% vec(Sig^nl) = F* [vec(Sig0); vec(Sig1); ...]
%
% important: sig_ii = cov(x[t],x[t-ii]) so that 
%
% sig^nl = [ Sig0 Sig1 ... ; Sig1' Sig0 ...; ... ] 
%

ptmp = zeros(2,nl*nn*nl*nn);
pstart = 0;
for maincol = 1:nl
    
    for matcol = 1:nn
        
        for mainrow = 1:nl
            
            pos = (maincol-1)*nn^2*nl;
            pos = pos + (matcol-1)*nn*nl;
            pos = pos + (mainrow-1)*nn;
            
            if mainrow <= maincol
                idx_tmp = (nn^2)*(maincol-mainrow) + (nn)*(matcol-1);
                ptmp(:,pstart+(1:nn)) = [pos+(1:nn);idx_tmp+(1:nn)];
                pstart = pstart+nn;
            else
                idx_tmp = (nn^2)*(mainrow-maincol) + (matcol-1);
                ptmp(:,pstart+(1:nn)) = [pos+(1:nn);idx_tmp+(1:nn:nn^2)];
                pstart = pstart+nn;
            end
        end
    end
end

F = sparse(ptmp(1,:),ptmp(2,:),ones(1,length(ptmp)),nl^2*nn^2,nl*nn^2,nn^2*nl^2);


