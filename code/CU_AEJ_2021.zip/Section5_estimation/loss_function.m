% LOSS_FUNCTION - Compute the weighted loss function described in Appendix
% C.1 of the paper

function [out,Yt,At,mod_mom_blck,mod_mom_trunc,mom_tau,meig,out_pure,vd] = loss_function(pvec,opt,set,fmat,sigdat,Wdat,type)

%Filter parameters
nvar   = 4;
K      = opt.K;
bk_per = opt.bk_per;

%Economic Parameters
phi = 1+set.phip; %Taylor coeff
xi = set.xi;   %Xi

%Wedge processes
AR1 = [reshape(pvec(1:4),2,2)',[0;0];0 0 0];
A0  = [pvec(5),0,pvec(6);pvec(7) pvec(8) pvec(9); 0 0 pvec(10)];

meig = max(abs(eig(AR1))); 

%Frequency space to use analytical results
n    = 500;
grid = 2*pi*(0:(n-1))/n;
z    = reshape(exp(-1i.*grid),1,1,n);

%Compute AL0 in freq domain
Af   = zeros(3,3,n);
Yf   = zeros(4,3,n);
for jj = 1:n
      Af(:,:,jj) = (eye(3)-AR1*z(jj))\A0;
end

%To time domain
At = real(ifft(Af,[],3));  

%To sum it
ALphi = sum(At.*reshape(phi.^(0:-1:-(n-1)),[1,1,n]),3);

CGF = zeros(4,4,n);
for jj = 1:n
    
      %hrs = yhat (eq 37)
      Yf(3,:,jj) = [0,xi,0]*Af(:,:,jj);
      
      %dY = (1-L)*yhat + dTFP
      Yf(1,:,jj) = (1-z(jj))*Yf(3,:,jj) + [ 0 0 1]*Af(:,:,jj);
      
      %pi = eq(38)
      Yf(2,:,jj) = [-1 xi 0]*(phi*z(jj)-1)^-1*((1-z(jj))*Af(:,:,jj) -(1-phi^-1)*ALphi);
      
      %Ir = phi*pi
      Yf(4,:,jj) = phi*Yf(2,:,jj);
      
      %Covariance Generating Function
      CGF(:,:,jj) = Yf(:,:,jj)*Yf(:,:,jj)';
end

%Compute moments of model
moms = real(ifft(CGF,[],3));

sigpi = moms(2,2,1);

%Unfiltered moments
mom_block = reshape(moms(:,:,1:2*bk_per+K+2),[nvar,nvar*(2*bk_per+K+2)]);

%Filtered moments
mod_mom_blck = reshape(fmat*mom_block(:),[nvar,nvar*(K+1)]);

%Compute Loss
dev = (triuv(mod_mom_blck)-triuv(sigdat));
out_pure = dev'*Wdat*dev + 10000*(meig>.95)*(meig-.95)^2 + 0*50000*sigpi;

out_pure2 = dev.*diag(Wdat.^(1/2));


%Penalize long horizon IR's
hor_ir  = 32;
pcont   = 30;
pvar    = [32.3964, 0.7726, 0.6505];   %Relative scale based on vol. of output, inflation, interest rate
siz_ir  = 1e-6;
scl_ir  = 1e6;%1e6;

compFj = zeros(size(AR1,1),size(AR1,2),hor_ir+pcont);
compFj(:,:,1) = eye(size(AR1));
for jj = 1:hor_ir+pcont-1
   compFj(:,:,jj+1)= AR1*compFj(:,:,jj); 
end

nwdg  = 3;
Snwdg = selector(1:nwdg, size(AR1,1));  %Selects the long run effects on the four wedges
WW    = diag(vec(pvar.^(-1/2)));  %Weights the rows corresponding to each tau

RL1 = zeros(nwdg^2,pcont);        RL2 = zeros(nwdg^2,pcont);
WL1 = zeros(nwdg^2,nwdg^2,pcont); WL2 = zeros(nwdg^2,nwdg^2,pcont);
L1  = 0;                          L2  = 0;
for jj = 1:pcont
    RL1(:,jj) = (vec(WW*Snwdg*compFj(:,:,end-pcont+jj)*A0)-siz_ir);  %The residuals w/r to .01
    WL1(:,:,jj) = diag(RL1(:,jj)>0);                      %Only taking one side of the quadratic
    L1 = L1 + scl_ir*RL1(:,jj)'*WL1(:,:,jj)*RL1(:,jj);
    
    RL2(:,jj)= (-siz_ir-vec(WW*Snwdg*compFj(:,:,end-pcont+jj)*A0));  %The residuals w/r to .01
    WL2(:,:,jj) = diag(RL2(:,jj)>0);                      %Only taking one side of the quadratic
    L2 = L2 + scl_ir*RL2(:,jj)'*WL2(:,:,jj)*RL2(:,jj);
end

out = out_pure + L1 + L2;

out2 = [out_pure2;sqrt(L1);sqrt(L2)];

if type == 2
    out = out2;
end

if nargout > 1
   
    CGFna = 0*CGF;
    for jj = 1:n
        %moments of Y with only TFP active
        CGFna(:,:,jj) = Yf(:,3,jj)*Yf(:,3,jj)';
    end
    
    %Compute moments of model
    momsna = real(ifft(CGFna,[],3));
    
    %Unfiltered moments
    mom_blockna = reshape(momsna(:,:,1:2*bk_per+K+2),[nvar,nvar*(2*bk_per+K+2)]);
    
    %Filtered moments
    mod_mom_blckna = reshape(fmat*mom_blockna(:),[nvar,nvar*(K+1)]);

    %Variance decomposition
    vd = diag(mod_mom_blckna)./diag(mod_mom_blck); 
    
    
    
   %moments of TAUs
   CGF_tau = zeros(3,3,n);
   for jj = 1:n
      CGF_tau(:,:,jj) =  Af(:,:,jj)*Af(:,:,jj)';
   end
   
   mom_tau= real(ifft(CGF_tau,[],3)); 
   mom_tau = mom_tau(:,:,1:2);
   
   %MA(h) version of DGP
   h = 14;
   Yt = real(ifft(Yf,[],3));
   Yt(:,:,h+2:end) = 0;
   Yf_trunc = fft(Yt,[],3);
   
   CGF_trunc = 0*CGF;
   for jj = 1:n
       CGF_trunc(:,:,jj) = Yf_trunc(:,:,jj)*Yf_trunc(:,:,jj)';
   end
   moms_trunc = real(ifft(CGF_trunc,[],3));
   
   %Unfiltered moments
   mom_block_trunc = reshape(moms_trunc(:,:,1:2*bk_per+K+2),[nvar,nvar*(2*bk_per+K+2)]);
   
   %Filtered moments
   mod_mom_trunc = reshape(fmat*mom_block_trunc(:),[nvar,nvar*(K+1)]);

   dev = (triuv(mod_mom_trunc)-triuv(sigdat));
   
   %eig_pen = 100000*(meig>.85)*(meig-.85)^2;
   out = dev'*Wdat*dev ;
   
end