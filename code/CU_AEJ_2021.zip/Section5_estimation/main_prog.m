addpath('../helper_functions');

%**************************************************************************
% SET UP DATA
%**************************************************************************   
load_data;

targ_nms = {'$y$'  '$\pi$', '$n$', '$ffr$'};
Ydat     = 100*demean([bkgdp, bkpi, bkhrs, bkffr]);
Ydat_fd  = 100*       [dgdp , dpi, dhrs, dffr];
ny_dat   = size(Ydat,2);

%Which of the variables are reported as growth rates from model
trend = [1];

%Matrix mapping moments to BP filtered moments
[~,bk_wghts] = BK(pi,bk_min,bk_max,bk_per);
fmat = zeros(ny_dat^2*(K+1),ny_dat^2*(2*bk_per+K+2));
for kk = 0:K
   fmat(kk*ny_dat^2+(1:ny_dat^2),:) = make_filter(ny_dat,bk_wghts,trend,kk,K+1);
end
fmat = sparse(fmat);

ny_tmp = 1;
fmattmp   = zeros(ny_tmp^2*1,ny_tmp^2*(2*bk_per+2));
for kk = 0:0
   fmattmp(kk*ny_tmp^2+(1:ny_tmp^2),:) = make_filter(ny_tmp,bk_wghts,trend(1),kk,0+1);
end
fmattmp = sparse(fmattmp);

%**************************************************************************
% TARGET MOMENTS & WEIGHTS
%**************************************************************************   
rng(100);  %Random seed
[sigdat,Vdat,bands,idxv,beta,mu] = make_targets(opt,trend,Ydat,Ydat_fd,targ_nms);

%Use diagonals
Wdat = sparse(diag(diag(Vdat)));

%invert to get weights
Wdat =Wdat^-1;

%**************************************************************************
%% DO ESTIMATION
%**************************************************************************   
p0 =  [ -0.901281005251624
   2.106163467455551
  -1.375301749540742
   2.499999965083850
  -1.551100191019311
  -1.362456734290087
  -1.428758228989618
   0.045989302596637
  -1.188440703819773
   0.993280469167037]';


%Initial point and bounds
p0   = 1*p0;
ubnd = 2.5*ones(1,10);
lbnd = -ubnd;

%Scalar loss
obj1 = @(p) loss_function(p,opt,set,fmat,sigdat,Wdat,1);
obj1(p0)

[fopt,Yt,At,mod_mom_blck,mod_mom_trunc,mom_tau,meig,out_pure,vd] = obj1(p0);


%% Confirms p0 is local optimum (value saved from a global search below)
options = optimoptions('fmincon');
options.Display = 'iter';
options.FiniteDifferenceType  ='central';
options.FiniteDifferenceStepSize = 1e-9;
options.MaxFunctionEvaluations = 10000;
pest = fmincon(obj1,p0,[],[],[],[],lbnd,ubnd,[],options);

save estimation_results ny_dat K fopt Yt At mod_mom_blck mod_mom_trunc mom_tau out_pure sigdat bands targ_nms pest vd


%% Moments for Section 5 Exercise

[fopt,Yt,At,mod_mom_blck,mod_mom_trunc,mom_tau,meig,out_pure vd] = obj1(pest);

Bdat   = At(1:2,:,1:33);
da_dat = At(3,:,1:33);

save ../Section5/input_files/MAest Bdat da_dat mom_tau

%Table 1
ac = [mom_tau(1,1,2)./mom_tau(1,1,1);mom_tau(2,2,2)./mom_tau(2,2,1);0];

tab1 = [sqrt(diag(mom_tau(:,:,1)))/100,ac,  [1,NaN,NaN;
                                          mom_tau(1,2,1)./sqrt(mom_tau(1,1,1)*mom_tau(2,2,1)),1,NaN;
                                          mom_tau(1,3,1)./sqrt(mom_tau(1,1,1)*mom_tau(3,3,1)), mom_tau(2,3,1)./sqrt(mom_tau(2,2,1)*mom_tau(3,3,1)),1]];

tab1

%% Search across many starting points (used to get p0 above)
%{
ns  = 12;
rng(10);
rng_seed = 2*100000*rand(1,ns);
opt.type = 'fmincon';
vml = cell(1,ns);
pout = cell(1,ns);
parfor jj = 1:ns
        rng(rng_seed(jj));
        [vml{jj},pout{jj},flag] = sa_search(obj1,obj1,lbnd,ubnd,opt);
end
[a,b] = min(cell2mat(vml));
pest = pout{b};
%}




return
%% Impulse responses (no longer plotted in paper)
figure 
subplot(1,2,1)
plot(squeeze(At(1,1,1:33))); hold on; plot(squeeze(At(2,1,1:33))); legend('TauC', 'TauP');

subplot(1,2,2)
plot(squeeze(At(1,2,1:33))); hold on; plot(squeeze(At(2,2,1:33))); legend('TauC', 'TauP');


f = figure;
s = subplot(3,1,1);
plot([0:32],cumsum(squeeze(Yt(1,3,1:33))), '-k', 'linewidth',2); legend('Output');
xlabel('time'); ylabel('percent'); s.XLim = [0,14];

s = subplot(3,1,2);
plot([0:32],squeeze(Yt(3,3,1:33)), '-k', 'linewidth',2); legend('Hours');
s.XLim = [0,14];

s = subplot(3,1,3);
plot([0:32],cumsum(squeeze(At(3,3,1:33))), '-k', 'linewidth',2); legend('TFP');
s.XLim = [0,14];

saveas(f, 'r3figure.eps','eps')

