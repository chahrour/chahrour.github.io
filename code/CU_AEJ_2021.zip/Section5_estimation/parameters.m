% PARAMETERS - This function returns a parameter structure to use in the model solution.


function [opt,set] = parameters
                                                       

%**************************************************
% COMPUTER SETTINGS
%**************************************************
opt.local     = true;
opt.plot_fig  = true;     %Plot moment figures?
opt.var_adjst = true;     %use bias correction in VAR

    

%Settings for target moments
opt.K        = 8;       % Lags in the target moments
opt.nboot    = 5000;    % Number of bootstrap replications for covariance matrix bootstrap
opt.nlag     = 10;      % Lags in bootstrap VAR
                                     
opt.err_type =0;       %0 use VAR model; 1 use theoretical model.
   
%Baxter-King filter
opt.bk_min = 2;
opt.bk_max = 32;
opt.bk_per = 12;

%*************************************************4
% ECONOMIC ENVIRONMENT
%**************************************************
                 
%Taylor Rule
set.phip = 0.5;      %This really phip-1.
set.xi   = 1/(1.5);  %Frisch elasticity of 2, standard preferences.



