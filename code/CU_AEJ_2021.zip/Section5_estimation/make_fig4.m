%% Figure
load estimation_results

corr_opt = 0;

%Get the covariance from the model for plotting
covdat = zeros(K+1,(ny_dat)^2,1);
covdat(:,:,1) = covario_data(stack_3d(sigdat,ny_dat,0),K,corr_opt);
covdat(:,:,2) = covario_data(stack_3d(mod_mom_blck,ny_dat,0),K,corr_opt);
covdat(:,:,3) = covario_data(stack_3d(mod_mom_trunc,ny_dat,0),K,corr_opt);

%Figure
f = covario_figure(covdat,bands,0,targ_nms,'', {'--', '-b','-.r', ':','-*','-'},{ 'Data', 'Model', 'Model-Trunc'});
set(gcf, 'Position', [1200,1000,400,300])


disp(['Section IV.A (~page 30) - variance decomp, yhat: ' num2str(vd(3))]);
disp(['Section IV.A (~page 30) - variance decomp, y   : ' num2str(vd(1))]);
disp(' ');

