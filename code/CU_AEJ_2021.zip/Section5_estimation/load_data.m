% run get_FredData to download files from Fred

% load data
load 'data/fred_data.mat'

% get time frame of raw data
fields = fieldnames(data);
for i=1:numel(fields)
  [y,m] = datevec(data.(fields{i}).Data(:,1));
  q     = ceil(m/3);
  data.(fields{i}).start = [y(1) q(1)];
  data.(fields{i}).stop  = [y(end) q(end)];
end

% BK parameters
[opt,set] = parameters;
struct2val(opt);

% time frame for filtering (NOTE: t0-quarter should be 1 or 2)
t0 = [1947,1];       % begin date (change as wanted)
t1 = [2016,4];       % end date (change as wanted)
fq = 4;

% time frame for estimation
start = [1960,1];       % begin date (change as wanted)
stop  = [2012,4];       % end date (change as wanted)

% population
s     = data.pop; s.Data(:,2) = s.Data(:,2)-hpfilter(s.Data(:,2),16000);
[y,m] = datevec(s.Data(:,1));               % convert to quarterly
d     = mon2qrt(s.Data(:,2),[y m],true);    %  --
pop   = fit_frame(d,fq,s.start,s.stop,t0,t1);


% deflator + inflation
s   = data.def;
def = fit_frame(s.Data(:,2),fq,s.start,s.stop,t0,t1);

pi   = diff(log(def));
dpi  = fit_frame(diff(pi),fq,t0+[0 2],t1,start,stop);
bkpi = fit_frame(BK(pi,bk_min,bk_max,bk_per),fq,t0+[0 1],t1,start,stop);
pi   = fit_frame(pi,fq,t0+[0 1],t1,start,stop);

% gdp
s = data.gdp;
d = fit_frame(s.Data(:,2),fq,s.start,s.stop,t0,t1);
gdp   = log(d./def./pop);
dgdp  = fit_frame(diff(gdp),fq,t0+[0 1],t1,start,stop);
bkgdp = fit_frame(BK(gdp,bk_min,bk_max,bk_per),fq,t0,t1,start,stop);



% hrs
s = data.hrs;
d = fit_frame(s.Data(:,2),fq,s.start,s.stop,t0,t1);
hrs   = log(d./pop);
dhrs  = fit_frame(diff(hrs),fq,t0+[0 1],t1,start,stop);
bkhrs = fit_frame(BK(hrs,bk_min,bk_max,bk_per),fq,t0,t1,start,stop);
hrs   = fit_frame(hrs,fq,t0,t1,start,stop);


% ffr
s = data.ffr;
[y,m] = datevec(s.Data(:,1));
d     = mon2qrt(s.Data(:,2),[y m],false); % convert to quarterly
d     = fit_frame(d,fq,s.start,s.stop,t0,t1);
ffr   = d./400;
dffr  = fit_frame(diff(ffr),fq,t0+[0 1],t1,start,stop);
bkffr = fit_frame(BK(ffr,bk_min,bk_max,bk_per),fq,t0,t1,start,stop);



