% RUN_ALL - Replicates the full set of results in 
% "Robust Predictions for DSGE Models with Incomplete Information"
% AEJ:Macro
% by Ryan Chahrour and Robert Ulbricht
%
% Last edited: August, 2021


%Warmup
clear all
home_dir = pwd;
addpath('helper_functions');
if ~verLessThan('matlab','9.9')
    error("The code does not run correctly on version R2021a and newer.");
end

%% ************************************************************************
% To Redo Calculations in Section 4 from scratch (~6 hours on 8-core computer)
%**************************************************************************
cd([home_dir,'/Section4'])
main_prog
cd(home_dir)

%% ************************************************************************
% To Redo Estimation in Section 5 (< 1 min)
%**************************************************************************
cd([home_dir,'/Section5_estimation'])
main_prog
cd(home_dir)

%% ************************************************************************
% To Redo Calculations from Section 5 from scratch (~2.5hrs on 8-core computer)
%**************************************************************************
cd([home_dir,'/Section5'])
main_prog
cd(home_dir)