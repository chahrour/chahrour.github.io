% MAKE_ALL_OUTPUTS - Generates the figures and tables used in
% "Robust Predictions for DSGE Models with Incomplete Information"
% AEJ:Macro
% by Ryan Chahrour and Robert Ulbricht
%
% Last edited: August, 2021

%Warmup
clear all
home_dir = pwd;
addpath('helper_functions');

%% ************************************************************************
% Just to make figures using saving computations
%**************************************************************************

warning off

% Results used in Section 4
cd([home_dir,'/Section4/final_figures/']);
make_fig1;    %Figure 1
make_fig2;    %Figure 2


% Result from Section 5 estimation + appendix
cd([home_dir,'/Section5_estimation'])
make_fig4 %Figure 4

% Results used in Section 5
cd([home_dir,'/Section5/final_figures/']);
make_tab1 %Table 1
make_tab2 %Table 2
make_fig3 %Figure 3

%Result from appendix
cd([home_dir,'/Section4/final_figures'])
make_fig5;   

% Return back to start
cd(home_dir)

warning on
return
