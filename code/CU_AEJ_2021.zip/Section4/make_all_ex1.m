function [f,ceq,aa,B,varpi,pglist,par] = make_all_ex1(coeff,par)

xidx = 0;

%% parametrization of macro process

%only need to keep track of tauxh in asymmetric info case (we don't discipline wage otherwise)
if par.ai
    num_tau = 3;%asymmetric info --> 3 wedges
else
    num_tau = 2;%symmetric info --> 2 wedges
end

%aggregate process is free (no loading on TFP,fix wages)
B = szeros([num_tau,num_tau+1,par.MAorderLHS+1],par.sym);
idx = false(size(B));

num_row = (num_tau-par.pcon*par.ai-par.hhno);

idx(1:num_row,1:num_tau,:) = true;
B(idx) = coeff(xidx+(1:(num_row*num_tau)*(par.MAorderLHS+1)));
xidx = xidx + (num_row*num_tau)*(par.MAorderLHS+1);

%fully rigid real wages (effectively shuts down firm-side wedge)
%(if par.nom=true, tauxh is set in macroC.m to fix nominal wage instead)
if par.ai && par.pcon % if p observed, there is no firm wedge
    B(3,:,:) = -B(2,:,:);
elseif  par.ai && par.hhno
    B(3,:,:) = 0;          %no household wedges
end

%% compute macro moments
da_info = szeros([1,size(B,2),par.MAorderLHS+1],par.sym);
[cMacro,idxMacro,varpi] = macroC(B,da_info,par);


%% parametrization of micro process

if ~par.pcon && ~par.hhno
    nn = num_tau;
else
    nn = 2;
end

% tau on tau
tau_tau = reshape(coeff(xidx+(1:nn^2*(par.MAorderRHS+1))),[nn nn par.MAorderRHS+1]);
xidx = xidx + nn^2*(par.MAorderRHS+1);

% tau on z
tau_z = reshape(coeff(xidx+(1:nn*(par.MAorderRHS+1))),[nn 1 par.MAorderRHS+1]);
xidx = xidx + nn*(par.MAorderRHS+1);

% tau on a_ma
tau_w = reshape(coeff(xidx+(1:nn*(par.MAorderRHS+1))),[nn 1 par.MAorderRHS+1]);
xidx = xidx + nn*(par.MAorderRHS+1);

if par.ai && par.pcon
    %No firm wedges at micro level
    tau_tau = [tau_tau ; -tau_tau(2,:,:)];
    tau_z = [tau_z ; -tau_z(2,:,:)];
    tau_w = [tau_w ; -tau_w(2,:,:)];
elseif par.ai && par.hhno
    %No household wedges at micro level
    tau_tau = [tau_tau ; 0*tau_tau(2,:,:)];
    tau_z =   [tau_z   ; 0*tau_z(2,:,:)];
    tau_w =   [tau_w   ; 0*tau_w(2,:,:)];
end


%% impose orthogonality wrt a explicitly
ctauEps = cMacro(:,idxMacro.da,:);%cov(tau,eps)

if par.MAorderLHS < par.MAorderRHS
    ctauEps(:,:,end+(1:(par.MAorderRHS-par.MAorderLHS))) = 0;
end
if par.MAorderLHS > par.MAorderRHS
    ctauEps(:,:,(par.MAorderRHS+2):end)=[];
end
Ys = tau_w;
Ys(:,:,1:end-1) = Ys(:,:,1:end-1) - Ys(:,:,2:end); 
Ys = -(ctauEps + Ys*par.sig_w)/par.sig_a;

% tau on mu (persistent component of a)
if ~par.ai % symmetric info case: both observe a
    tau_mu = par.rho_a*Ys + (1-par.rho_a)*scumsum(Ys,3,'reverse');
else % asymmetric: hh don't observe a
    tau_muh = reshape(coeff(xidx+(1:2*(par.MAorderRHS+1))),[2 1 par.MAorderRHS+1]);% this [tauc, taux]
    xidx = xidx + 2*(par.MAorderRHS+1);
    if ~par.pcon % firms have wedge (p not in info) and observe a
        Ys = Ys(2,:,:) + Ys(3,:,:); % this is firm part
        tau_muf = par.rho_a*Ys + (1-par.rho_a)*scumsum(Ys,3,'reverse');%impose orthog on firm wedge        
        tau_mu = [tau_muh ; tau_muf-tau_muh(2,:,:)];        
    else % firms have no wedge
        tau_mu = [tau_muh ; -tau_muh(2,:,:)];
    end
end

%List parameters at horizons > h
pglist = cell(1,par.MAorderLHS);
for nh0 = 2:par.MAorderLHS+2
    pglist{nh0-1} = [symvar(B(:,:,nh0:end)),symvar(tau_tau(:,:,nh0:end)),symvar(tau_z(:,:,nh0:end)),symvar(tau_mu(:,:,nh0:end)),symvar(tau_w(:,:,nh0:end))];
end

save tmp coeff B tau_tau tau_z tau_mu tau_w pglist

%% compute micro moments
[cMicro,idxMicro] = microC(tau_tau,tau_z,tau_mu,tau_w,par);



%% implementation constraint wrt c,y,w (wrt a is imposed above)

c = []; % no nonlinear inequality constraints

ma = min(par.MAorderLHS,par.MAorderRHS)+1;

if par.MAorderLHS+1 > ma
    cMicro(:,:,par.MAorderLHS+1)=0;
end

if par.MAorderRHS+1 > ma
    cMacro(:,:,par.MAorderLHS+1)=0;
end


if par.ai%asymmetric info

    % tauxf = taux + tauxh
    cMacro(4,:,:) = cMacro(2,:,:) + cMacro(3,:,:);
    cMicro(4,:,:) = cMicro(2,:,:) + cMicro(3,:,:);
    
    ceq = [ 
        %household: c
        vec( cMacro([1 3],idxMacro.dy,1:ma) + cMicro([1 3],idxMicro.dc,1:ma) );
        
        %household: n
        vec( cMacro([1 3],idxMacro.dyhat,1:ma) + cMicro([1 3],idxMicro.dy,1:ma) - cMicro([1 3],idxMicro.da,1:ma) );
                           
        %firm: y
        vec( cMacro(4,idxMacro.dy,1:ma) + cMicro(4,idxMicro.dy,1:ma) );
                       
        %both: w
        vec( cMacro(1:3,idxMacro.dw,1:ma) + cMicro(1:3,idxMicro.dw,1:ma) );
        
        ];
    
    if par.pcon       
        ceq = [
            ceq ; 
            
            % impose price constraint only for firms
            vec( cMacro(4,idxMacro.pi,1:ma) + cMacro(4,idxMacro.dy,1:ma)/par.theta  + cMicro(4,idxMicro.dz,1:ma) );
                   
           ];        
    end
        
else%symmetric info
    
    ceq = [
        %c
        vec( cMacro(:,idxMacro.dy,1:ma)    + cMicro(:,idxMicro.dc,1:ma) );
        
        %y
        vec( cMacro(:,idxMacro.dy,1:ma)    + cMicro(:,idxMicro.dy,1:ma) );
        
        ];
    
    if par.pcon     
        ceq = [
            ceq ;                  
            vec( cMacro(:,idxMacro.pi,1:ma) + cMacro(:,idxMacro.dy,1:ma)/par.theta  + cMicro(:,idxMicro.dz,1:ma) );        
        ];
        
    end
        
        
end
    
%% exercise 1: add autocorrelation and correlation with pi
if par.ex == 1
    ceq = [ceq ; 
        % corr(yhat(t),yhat(t-1)) = target(1)
        cMacro(2,idxMacro.yhat,2) - par.ary_obj*cMacro(2,idxMacro.yhat,1) ;
        
        % corr(yhat(t),pi(t)) = target(2)
        par.xi*cMacro(2,idxMacro.pi,1) - par.cpy_obj*sqrt(par.xi*cMacro(2,idxMacro.yhat,1)*varpi) ;        
                
        ];
        
end

%% objective
f = -par.xi^2*sum(B(2,:,1).^2); % impact variance of yhat

if nargout>3
    
    aa = [tau_tau tau_z tau_mu tau_w];
    
end

xvec = symvar(subs(symvar([f;ceq]),[par.ary_obj, par.cpy_obj, par.rho_a, par.rho_z, par.sig_a, par.sig_w, par.sig_z], ones(1,7)));

%% Parameter counting
disp(['params avail/used/df:  ' num2str([length(coeff),length(xvec),length(xvec)-size(ceq,1)])]);

end