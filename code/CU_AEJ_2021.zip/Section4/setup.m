%****************************************
% SETUP FILES FOR EX1 (SECTION 4)
%****************************************
addpath('../helper_functions');
addpath('../auto_generated')

par.optimize = false;
par.sym      = true;

%---- case naming
exsuff   = {'ex1', 'ex2' };
aisuff   = {'', '_ai' };
psuff    = {'', '_pcon'};
hhnosuff = {'', '_hhno'};
fnasuff  = {'', '_fna'};
hhnasuff = {'', '_hhna'};

%---- deep parameters
par.beta  = 0.99;
par.xi    = 2/3;
par.theta = 7.5; 
par.phi   = 1.5; 
par.del   = (par.theta^-1 + par.xi^-1 -1)^-1;

%---- relevant parameters, not used yet
par.ai    = NaN; % asymmetric info (hh: c,a,w. firms: y,a,w, and p if par.pcon=1)
par.pcon  = NaN; % p in info set (only for firms if par.ai=1)
par.hhno  = NaN; % no hh wedge at all
par.fna   = NaN; % firm observes agg tfp
par.hhna  = NaN; % hh observe agg tfp

%---- MA order
par.MAorderRHS = 14; %order of micro MA terms (full info horizon)
par.MAorderLHS = 14; %order of macro MA terms (revelation of agg state)

%---- idiosyncratic fundamental shocks (note a is called x in the text!)
syms rho_a sig_a sig_w rho_z sig_z ary cpy
pvec   = [sig_a  sig_w  sig_z  rho_a rho_z ].';

par.sig_a = pvec(1);
par.sig_w = pvec(2);
par.sig_z = pvec(3);
par.rho_a = pvec(4);
par.rho_z = pvec(5);

pvec_num = [5.52, 4.78, 25.04, 0.9764, 0.9764].';
pname    = {'siga', 'sigw', 'sigz', 'rhoaz'};

%---- ex1: target moments
avec   = [ary cpy].';
par.ary_obj = ary;% autocorrelation yhat
par.cpy_obj = cpy;% cov(yhat,pi)


%% Cases for EX1

par.ex    = 1;  %1 or 2
par.nom   = 1;

%---- what cases do we want?
info_nms1 = {'base', 'asym', 'nodemand', 'nofirm'};
info_par1 = cell(1,4);

%---- base
par.ai    = 0; % symmetric info 
par.pcon  = 0; % p not in info set 
par.hhno  = 0; % yes hh wedge 
info_par1{1} = par_count(par);

%---- asym
par.ai    = 1; % asymmetric info 
par.pcon  = 0; % p not in info set 
par.hhno  = 0; % yes hh wedge
info_par1{2} = par_count(par);

%---- nodemand
par.ai    = 0; % symmetric info 
par.pcon  = 1; % p in info set 
par.hhno  = 0; % yes hh wedge
info_par1{3} = par_count(par);

%---- nofirm
par.ai    = 1; % asymmetric info
par.pcon  = 1; % p in info set (only for firms since par.ai=1)
par.hhno  = 0; % yes hh wedge 
info_par1{4} = par_count(par);

