function par = par_count(par)

%---- Exercise 1: count parameters for each case

%idio
if ~par.ai
    %symmetric info
    par.numpars = 8*(par.MAorderRHS+1);
    
elseif par.pcon || par.hhno
    %asymmetric info + either no firm wedge or no hh wedge
    par.numpars = 10*(par.MAorderRHS+1);
else
    %asymetric info + p is not observed
    par.numpars = 17*(par.MAorderRHS+1);
end

%agg
if ~par.ai
    par.numpars = par.numpars  + 4*(par.MAorderLHS+1);
elseif  par.ai && (~par.pcon && ~par.hhno)
    par.numpars = par.numpars  + 9*(par.MAorderLHS+1);
elseif  par.ai && (par.pcon || par.hhno)
    par.numpars = par.numpars  + 6*(par.MAorderLHS+1);
end



