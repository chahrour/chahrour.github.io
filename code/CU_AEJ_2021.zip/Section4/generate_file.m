%% Generating Symbolic Outputs

% symbolic objective + constraints
xvec = sym('x',[par.numpars 1],'real');

%---- EX 1 Files
if par.ex == 1
    tic
    par.sym=1;
    [f_,ceq_,aa0,A,varp_,pglist] = make_all_ex1(xvec,par);
    par.sym=0;
    toc
    
    tic
    df_   = jacobian(f_,xvec);
    dceq_ = jacobian(ceq_,xvec);
    toc
    
    tic
    matlabFunction(f_,df_,             'File', ['../auto_generated/objective1' aisuff{par.ai+1} psuff{par.pcon+1} hhnosuff{par.hhno+1} '.m'],  'Vars',{xvec,pvec}, 'Optimize', par.optimize);
    matlabFunction([],ceq_,[],dceq_.', 'File', ['../auto_generated/nlcon1'     aisuff{par.ai+1} psuff{par.pcon+1} hhnosuff{par.hhno+1}  '.m'], 'Vars',{xvec,avec,pvec}, 'Optimize', par.optimize);
    matlabFunction(varp_,              'File', ['../auto_generated/varp1.m'], 'Vars',{xvec,avec,pvec}, 'Optimize', par.optimize);
    toc
    
    %Get linear restriction on parameters to kill higher lags
    pgmat = cell(length(pglist),1);
    for jj = 1:length(pglist)
       [R,jb] = rref(double(jacobian(pglist{jj},xvec)));
       pgmat{jj} = R(1:length(jb),:);
    end
    save(['../auto_generated/pgmat' aisuff{par.ai+1} psuff{par.pcon+1} hhnosuff{par.hhno+1} ], 'pgmat')
end

rehash;