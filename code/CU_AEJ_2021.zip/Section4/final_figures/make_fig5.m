load ../output_files/compare.mat sig_range rho_range n_micro h_range
file_list = {'../output_files/negcompare.mat'                 
            '../output_files/negcompare_ai.mat'
};

f = figure(5); set(gcf, 'Position', [0,175,400,300]);

%Parameter ranges
xrange = [sig_range'/100,sig_range'/100,sig_range'/100,rho_range',rho_range',h_range(1:n_micro)'-1];

plot_opts{1} = {'.','MarkerSize',15,'MarkerEdgeColor',[.2 .2 1],'MarkerFaceColor',[.75 .75 1]};
plot_opts{2} = {'-','Color','r','LineWidth',2};
for jj = 1:length(file_list) %% info cases
    [fmin_base,resid,flag] = extract_min_ex1b(file_list{jj});   
    for kk = 1:6 % comparative static
        s = subplot(2,3,kk);        
        plot(xrange(:,kk),fmin_base(:,kk),plot_opts{jj}{:});        
        hold on;
    end    
end


xlabels = {'$\sigma_x$','$\sigma_\omega$','$\sigma_z$','$\rho_x$','$\rho_z$','$\bar h -1$'};
base_pars = [.0552, .0478,  .2504,  .976,.976, 14];

for kk = 1:6
   
    subplot(2,3,kk)
    
    if kk <= 3
        set(gca,'XScale','log');        
    end
    if (kk == 4) || (kk==5)
        xlim([.5,1])
    end
    if kk == 6
        xlim([5,14])
    end
    
    
    set(gca, ...
      'Box'         , 'off'     , ...
      'TickDir'     , 'out'     , ...
      'TickLength'  , [.02 .02] , ...
      'XMinorTick'  , 'on'      , ...
      'YMinorTick'  , 'on'      , ...
      'YGrid'       , 'on'      , ...            
      'YScale'      , 'log'     , ...
      'YLimSpec'    , 'Tight'   )      

    ylim([1,40])
    if kk==3
        ylim([.1,40])
    end

    xlabel(xlabels{kk},'interpreter','latex');

    hold off

    if kk==6             
       leg=legend('symmtetric info (baseline)','heterogeneous info');
    end
    
end

