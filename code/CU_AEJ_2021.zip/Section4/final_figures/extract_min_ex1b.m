function [fmin,resid,flag,fmin_base] = extract_min_ex1b(file)

load(file,'fmin_grid','resid_grid','fmin_base','n_start','n_tot','flag_grid','n_micro','n_cpy','n_ary','pchg')

%Don't consider infeasible cases
fmin_grid(resid_grid>0.05) = inf;

%Min over nstarts
[fmin, idx_min] = min(reshape(fmin_grid,[n_start,n_tot/n_start]));
resid_grid = reshape(resid_grid,[n_start,n_tot/n_start]);
flag_grid = reshape(flag_grid,[n_start,n_tot/n_start]);
resid = nan(size(fmin));
flag  = nan(size(fmin));

for jj = 1:size(fmin,2)
    resid(:,jj) = resid_grid(idx_min(jj),jj);
    flag(:,jj) = flag_grid(idx_min(jj),jj);
end

%Reshape in 2d matrix
fmin = sqrt(-squeeze(reshape(fmin, [n_micro,n_cpy,n_ary,pchg(end)])));
resid = -squeeze(reshape(resid, [n_micro,n_cpy,n_ary,pchg(end)]));
flag = squeeze(reshape(flag, [n_micro,n_cpy,n_ary,pchg(end)]));

if exist('fmin_base','var')
    fmin_base = sqrt(-fmin_base);
else
    fmin_base = NaN;
end