%% Make the frontier figure
file = '../output_files/frontier';
load(file, 'cpy_grid', 'ary_grid');
[fmin,resid] = extract_min(file);
close all % close any figures saved by accident in file

figure(1); set(gcf, 'Position', [0,1000,400,300])

ncpy = length(cpy_grid);
nary = length(ary_grid);

s=surf(repmat(cpy_grid',[1,nary]),repmat(ary_grid,[ncpy,1]),fmin);

zlim([.1,20]/1)

s.FaceColor = [.95 .95 .95];
s.EdgeColor = [.2 .2 .2];
s.LineWidth = 1;

g = gca;
g.ZGrid = 'off';
g.YGrid = 'off';
g.XGrid = 'off';
g.ZScale = 'log';
g.View = [45 15];

set(gca, ...
  'Box'         , 'off'     , ...
  'TickDir'     , 'out'     , ...
  'TickLength'  , [.02 .02] , ...
  'XMinorTick'  , 'on'      , ...
  'YMinorTick'  , 'on'      , ...
  'ZGrid'       , 'on'      , ...
  'XTick'       , -1:.5:1   , ...
  'YTick'       , -1:.5:1   , ...
  'ZTick'       , [.1,1,10]/1 , ...  
  'LineWidth'   , 1         );

xs = xlabel('$\gamma_{\hat y \pi}$', 'interpreter', 'latex','fontsize',16);
ys = ylabel('$\rho_{\hat y}$', 'interpreter', 'latex','fontsize',16);
zlabel('$\sigma^\mathrm{max}_{\hat y}$', 'interpreter', 'latex','fontsize',16);

disp(['Section III.C (~page 25) - global   sig_ymax: ' num2str(max(max(fmin(10:end,:))))]);
disp(['Section III.C (~page 25) - baseline sig_ymax: ' num2str(fmin(13,end))]);
disp(' ')

