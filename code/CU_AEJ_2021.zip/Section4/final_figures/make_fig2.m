
load ../output_files/compare.mat sig_range rho_range n_micro h_range
file_list = {'../output_files/compare.mat'            
            '../output_files/compare_pcon.mat'       
            '../output_files/compare_ai.mat'
            '../output_files/compare_ai_pcon.mat'};
f = figure(2); set(gcf, 'Position', [400,1000,400,300]);

%Parameter ranges
xrange = [sig_range'/100,sig_range'/100,sig_range'/100,rho_range',rho_range',h_range(1:n_micro)'-1];

plot_opts{1} = {'.','MarkerSize',15,'MarkerEdgeColor',[.2 .2 1],'MarkerFaceColor',[.75 .75 1]};
plot_opts{2} = {'s','MarkerSize',7,'MarkerEdgeColor',[.2 .2 .2],'MarkerFaceColor',[.7 .7 .7]};
plot_opts{3} = {'-','Color','r','LineWidth',2};
plot_opts{4} = {'-','Color',[0 0 .5],'LineWidth',2};
for jj = 1:length(file_list) %% info cases
    [fmin_grid,resid,flag] = extract_min_ex1b(file_list{jj});  
    for kk = 1:6 % comparative static
        s = subplot(2,3,kk);        
        plot(xrange(:,kk),fmin_grid(:,kk),plot_opts{jj}{:});        
        hold on
    end    
end

xlabels = {'$\sigma_x$','$\sigma_\omega$','$\sigma_z$','$\rho_x$','$\rho_z$','$\bar h -1$'};
base_pars = [.0552, .0478,  .2504,  .976,.976, 14];

for kk = 1:6
   
    subplot(2,3,kk)
    
    if kk <= 3
        set(gca,'XScale','log');        
    end
    if (kk == 4) || (kk==5)
        xlim([.5,1])
    end
    if kk == 6
        xlim([5,14])
    end
    
    
    set(gca, ...
      'Box'         , 'off'     , ...
      'TickDir'     , 'out'     , ...
      'TickLength'  , [.02 .02] , ...
      'XMinorTick'  , 'on'      , ...
      'YMinorTick'  , 'on'      , ...
      'YGrid'       , 'on'      , ...            
      'YScale'      , 'log'     , ...
      'YLimSpec'    , 'Tight'   )      

    ylim([.1,20])
    if kk==4
        ylim([.01,20])
    end

    xlabel(xlabels{kk},'interpreter','latex');

    plot(base_pars(kk),1.1025,'xk','LineWidth',1,'MarkerSize',5)
    
    hold off

    if kk==6               
       leg=legend('symmetric info (baseline)','symmetric info (no demand uncertainty)','heterogeneous info','heterogeneous info (no demand uncertainty)');    
    end
    
end

%% Numbers on page 26:

[fmin_grid,resid,flag,fmin_base] = extract_min_ex1b(file_list{1});  

disp(['Section III.C (~page 26) - sig_ymax, low  sigz: ' num2str(fmin_grid(1,3))]);
disp(['Section III.C (~page 26) - sig_ymax, high sigz: ' num2str(fmin_grid(end,3))]);
disp(' ')
disp(['Section III.C (~page 26) - sig_ymax, low  rhoz: ' num2str(fmin_grid(1,5))]);
disp(['Section III.C (~page 26) - sig_ymax, high rhoz: ' num2str(fmin_grid(end,5))]);
disp(' ')


[~,~,~,fmin_base] = extract_min_ex1b(file_list{2});  
disp(['Section III.C (~page 28) - sig_ymax, no demand uncert                  : ' num2str(fmin_base)]);

[~,~,~,fmin_base] = extract_min_ex1b(file_list{3});  
disp(['Section III.C (~page 28) - sig_ymax, hetero info                       : ' num2str(fmin_base)]);

[~,~,~,fmin_base] = extract_min_ex1b(file_list{4});  
disp(['Section III.C (~page 29) - sig_ymax, hetero info, no firm demand uncert: ' num2str(fmin_base)]);

disp(['Section III.C (~page 29) - sig_ymax, h = 10                            : ' num2str(fmin_grid(end-4,end))]);
disp(' ');