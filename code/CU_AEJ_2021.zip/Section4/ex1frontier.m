%% Max variance for given rho(y,pi) and implementability constraints.

%---- optimizer parameters
opts            = optimset('fmincon');
opts.Display    = 'warn';
opts.GradConstr = 'on';
opts.GradObj    = 'on';
opts.DerivativeCheck = 'off';
opts.FinDiffType = 'center';
opts.OptimalityTolerance = 1e-4;
opts.MaxFunEvals = 20000;
opts.MaxIter     = 2500;
opts.SubproblemAlgorithm = 'cg';

%---- Constraint grid

%For frontiers
n_ary = 19;
n_cpy = 19;
ary_grid = linspace(-0.9,0.9,n_ary);
cpy_grid = linspace(-0.9,0.9,n_cpy);


n_micro = 1;


%---- Inital points
n_start = 4;
rng(1500);
x0 = (rand(par.numpars,n_start)-.5)/10;

%We've saved some good starting points, too
load input_files/MA14_starts xstart1 xstart2 xstart3 xstart4
x0(:,1) = xstart1(1:min(length(xstart4),par.numpars));
x0(:,2) = xstart2(1:min(length(xstart4),par.numpars));
%x0(:,3) = xstart3(1:min(length(xstart4),par.numpars));
%x0(:,4) = xstart4(1:min(length(xstart4),par.numpars));
x0(:,3) = .01;

%---- Combine grids to flatten parfor
[nn_start,nn_micro,nn_cpy,nn_ary] = ndgrid(1:n_start,1:n_micro,1:n_cpy,1:n_ary);
nidx = [nn_ary(:)';nn_cpy(:)';nn_micro(:)';nn_start(:)'];

n_tot = size(nidx,2);

%---- Number of constraints
combo_suff = [aisuff{par.ai+1} psuff{par.pcon+1} hhnosuff{par.hhno+1}]
obj_name = ['objective1' combo_suff]; 
con_name = ['nlcon1'   combo_suff ];
[~,n_con,~,dncon] = feval(con_name,x0(:,1),[0;0],pvec_num);
n_con = length(n_con);

%---- Main Loop
tic
poolobj = gcp;
addAttachedFiles(poolobj,{'../auto_generated/'})
updateAttachedFiles(poolobj);

xmin_grid  = nan(length(x0),n_tot);
varpv_grid = nan(1,n_tot);
fmin_grid  = nan(1,n_tot);
resid_grid = nan(1,n_tot);
flag_grid  = nan(1,n_tot);


parfor ii = 1:n_tot
    
    %Target comovements
    y=[ary_grid(nidx(1,ii));...
       cpy_grid(nidx(2,ii))];
    
    %Sub in parameters
    pvec_num_tmp    = pvec_num;

    %Starting point
    xinit = x0(:,nidx(4,ii));

    %To use difference constraints
    obj_ = @(x)feval(obj_name,x);
    con_ = @(x)feval(con_name,x,y,pvec_num_tmp);

    %FMINCON step
    [xmin_grid(:,ii),~,flag_grid(ii)]  = fmincon(obj_,xinit,[],[],[],[],[],[],con_,opts);
    fmin_grid(ii)             = obj_(xmin_grid(:,ii));
    [~,rtmp]                  = con_(xmin_grid(:,ii));
    resid_grid(ii)            = sum(abs(rtmp));
    varpv_grid(ii)            = varp1(xmin_grid(:,ii),y,pvec_num_tmp);
end
toc


%% Save
save(['output_files/frontier' combo_suff],'resid_grid','fmin_grid','n_start','n_tot','n_micro','n_cpy','n_ary','cpy_grid','ary_grid');
