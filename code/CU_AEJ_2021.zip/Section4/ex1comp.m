%% Max variance for given rho(y,pi) and implementability constraints.

%---- optimizer parameters
opts            = optimset('fmincon');
opts.Display    = 'final';
opts.GradConstr = 'on';
opts.GradObj    = 'on';
opts.DerivativeCheck = 'off';
opts.FinDiffType = 'center';
opts.OptimalityTolerance = 1e-4;
opts.MaxFunEvals = 5*20000;
opts.MaxIter     = 2500;
opts.SubproblemAlgorithm = 'cg';

%---- Idio parameters
pchg    = 1:6;  %Which parameter(s) to adjust 
n_p    = length(pchg);  

%---- Constraint grid
n_ary = 1;
n_cpy = 1;
ary_grid = 0.9;
cpy_grid = flip_it*0.3;  %flip_it is sign of p & y correlation

%---- Grid along a micro parameters
n_micro   = 11; %siga,sigw,sigz
rho_range = linspace(.5,.99,n_micro); %for ac's
sig_range = logspace(log10(.01),log10(1),n_micro)*100;
h_range   = min([5:15],par.MAorderRHS+1); %h's to consider; needs to have n_micro elements.
h_range = h_range(1:n_micro);

if isempty(pchg)
    n_micro = 1;
end

%---- Inital points
n_start = 4;8;16; 
rng(1500);
x0      = (rand(par.numpars,n_start)-.5);
x0(:,1) = .01;

%---- Combine grids to flatten parfor
[nn_start,nn_micro,nn_cpy,nn_ary,nn_p] = ndgrid(1:n_start,1:n_micro,1:n_cpy,1:n_ary,pchg);
nidx = [nn_ary(:)';nn_cpy(:)';nn_micro(:)';nn_start(:)';nn_p(:)'];

n_tot = size(nidx,2);

%---- Number of constraints
combo_suff = [aisuff{par.ai+1} psuff{par.pcon+1} hhnosuff{par.hhno+1}];
obj_name = ['objective1' combo_suff  ]; 
con_name = ['nlcon1'   combo_suff ];
[~,n_con,~,dncon] = feval(con_name,x0(:,1),[0;0],pvec_num);
n_con = length(n_con);

%---- Main Loop
tic
poolobj = gcp;
addAttachedFiles(poolobj,{'../auto_generated/'})
updateAttachedFiles(poolobj);

xmin_grid  = nan(length(x0),n_tot);
varpv_grid = nan(1,n_tot);
fmin_grid  = nan(1,n_tot);
resid_grid = nan(1,n_tot);
flag_grid  = nan(1,n_tot);

% load zero restriction to constrain horizon
load(['../auto_generated/pgmat' combo_suff])

%% Solve optimization using baseline parameters
y=[ary_grid;...
    cpy_grid];

xinit = x0(:,1);

%To use difference constraints
obj_ = @(x)feval(obj_name,x);
con_ = @(x)feval(con_name,x,y,pvec_num);
lcon = [];

%FMINCON step
[xmin_base,~,flag_base]  = fmincon(obj_,xinit,[],[],lcon,zeros(size(lcon,1),1),[],[],con_,opts);
fmin_base                = obj_(xmin_base);
[~,rtmp]                 = con_(xmin_base);
resid_base               = sum(abs(rtmp));

%% Work along each grid
parfor ii = 1:n_tot
    
    %Target comovements
    y=[ary_grid(nidx(1,ii));...
       cpy_grid(nidx(2,ii))];
    
    %Sub in parameters
    pvec_num_tmp    = pvec_num;
    lcon = [];%zeros(1,par.numpars);
    if isempty(pchg)
        %Do not change micro params
    elseif nidx(5,ii)<4
        %Update micro parameters (other than AR)
        pvec_num_tmp(nidx(5,ii))   = sig_range(nidx(3,ii));
    elseif nidx(5,ii) == 4
        %Update micro AR parameters
        pvec_num_tmp(4) = rho_range(nidx(3,ii));
     elseif nidx(5,ii) == 5
        %Update micro AR parameters
        pvec_num_tmp(5) = rho_range(nidx(3,ii));   
    elseif nidx(5,ii) == 6
        %Update horizon
        lcon = pgmat{h_range(nidx(3,ii))};
        if size(lcon,1)>0
            lcon = [lcon;lcon(1,:)];  %This solves a bug in matlab's optimizer.
        end
    end
    
    %Starting point
    xinit = x0(:,nidx(4,ii));
    
    %To use difference constraints
    obj_ = @(x)feval(obj_name,x);
    con_ = @(x)feval(con_name,x,y,pvec_num_tmp);

    %FMINCON step
    [xmin_grid(:,ii),~,flag_grid(ii)]  = fmincon(obj_,xinit,[],[],lcon,zeros(size(lcon,1),1),[],[],con_,opts);
    fmin_grid(ii)             = obj_(xmin_grid(:,ii));
    [~,rtmp]                  = con_(xmin_grid(:,ii));
    resid_grid(ii)            = sum(abs(rtmp));
    varpv_grid(ii)            = varp1(xmin_grid(:,ii),y,pvec_num_tmp);
end
toc


%% Save cases
if cpy_grid > 0
    save(['output_files/compare' combo_suff],'fmin_grid','fmin_base','resid_grid','resid_base','n_start','n_tot','flag_grid','n_micro','n_cpy','n_ary','pchg','sig_range', 'rho_range', 'n_micro', 'h_range')
else
    save(['output_files/negcompare' combo_suff],'fmin_grid','fmin_base','resid_grid','resid_base','n_start','n_tot','flag_grid','n_micro','n_cpy','n_ary','pchg','sig_range', 'rho_range', 'n_micro', 'h_range')
end