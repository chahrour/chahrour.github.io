function [C,idx] = microC(tau_tau,tau_z,tau_mu,tau_w,par)

MAorder = par.MAorderRHS;
num_tau = size(tau_tau,1);
num_tau_in = size(tau_tau,2);


%% A(z)

%--------------
%note:
%order of variables is (tau, a , z)
%order of innovations is (tau, z , mu , w)
%where tau is either (tauc,taux) or (tauc,taux,tauxh)

tau = [tau_tau tau_z tau_mu tau_w];
az = szeros([2,3,MAorder+1],par.sym);
az(1,2,:) = par.sig_a*par.rho_a.^(0:MAorder);%a on mu
az(1,3,1) = par.sig_w;                       %a on w
az(2,1,:) = par.sig_z*par.rho_z.^(0:MAorder);%z on z

A = [tau; zeros(2,num_tau_in,MAorder+1) az];

% (1-z)A(z)
dA = A;
dA(:,:,2:end) = dA(:,:,2:end) - dA(:,:,1:end-1);


%% A(beta)

%tau(beta)
tauBeta = zeros(num_tau,3+num_tau_in);
for ii = 0:MAorder
       tauBeta = tauBeta + par.beta^ii * tau(:,:,ii+1);
end

%compute az(beta) in closed form to avoid truncation
azBeta = [ 0 , par.sig_a/(1-par.beta*par.rho_a) , par.sig_w ; %a
        par.sig_z/(1-par.beta*par.rho_z) , 0 , 0 ]; %z

% dA(beta) = (1-beta)*(tau,a,z)(beta)
dABeta = (1-par.beta)*[tauBeta ; zeros(2,num_tau_in) azBeta];


%% dy and dc (only need 1st MAorder coefficients for covariance with tau)

del = 1/(1/par.theta +1/par.xi - 1);

% loading on tauxh in asymmetric info case
if par.ai
    gg = 1;
else 
    gg = 0;
end

%dy
dy = dA(1,:,:)*(-del) + ...
     dA(2,:,:)*del + ...
     dA(3+gg,:,:)*del/par.xi + ...
     dA(4+gg,:,:)*del ;

dy0 = dABeta(1,:)*del + ...
      dABeta(2,:)*(par.xi-del) + ...
      dABeta(3+gg,:)*(1-del/par.xi) + ...
      dABeta(4+gg,:)*(-del) ;

dy(:,:,1) = dy(:,:,1) + dy0;

%dc
dc = dA(1,:,:);%tauc is first row or A
dc(:,:,1) = dc(:,:,1) - dy0/del;

%dw
if par.ai
   dw = dy          *(1/par.xi-1) + ... %y
        dA(3+gg,:,:)*(1-1/par.xi) + ... %a
        dc + ...                        %c
        dA(3,:,:);                      %tauxh
end


%% stack everything into big vector

dB = [dA ; dy ; dc];
if par.ai
    dB = [dB; dw];
end

idx.dtauc = 1;
idx.dtaux = 2;
idx.da = num_tau+1;
idx.dz = num_tau+2;
idx.dy = num_tau+3;
idx.dc = num_tau+4;


if par.ai
    idx.dtauxh = 3;
    idx.dw = num_tau+5;
end

%% compute covariance terms between tau and d(tau,a,z,y,c,w)


C = szeros([num_tau,6+2*gg,MAorder+1],par.sym);
for ii = 0:MAorder
     
    C(:,:,ii+1) = covxy(tau,dB,ii);
          
end



end