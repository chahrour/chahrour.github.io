t0 = tic;

%% Parameters shared across Section 4 exercises
setup

%% Generate files for 5 cases in SECTION 4 (~20 mins total)
for mm = 1:4
    par = info_par1{mm};
    generate_file
end

%% Figure 1 computations: frontier in terms ar(y) & cov(pi,y)  (~2 hours on 8 core)
par = info_par1{1}; %baseline parameters
ex1frontier

%% Figure 2 computations: change one micro paramter at a time (~3 hours on 8 cores)
for mm = 1:4
    flip_it = 1; %positive correlation p & y
    par = info_par1{mm};
    ex1comp
end

%% Figure 5 computations: change one micro paramter at a time (~3 hours on 8 cores)
for mm = 1:4
    flip_it = -1; %negative corr p & y
    par = info_par1{mm};
    ex1comp
end


toc(t0)
%% or run single case by hand
%{
setup
par = info_par1{1}; % select exercise + case here
generate_file
ex1frontier; % choose between ex1frontier, ex1comp
%}
