% SHOOTING_SOLVE - Script for solving the shooting problem for given
% starting point/paramterization. This script relies on user to set the
% right environment parmaeters before calling it.

T = 300*per_p_year;
log_idx = [];


X0 = frac2B(frac_shoot(:),Busd(1),Beur(1),mu_us,mu_eu,mu_rw);
if xstate
    X0(5) = 0.01;
end

%starting value
if ~exist('xshoot_final','var') || length(xshoot_final)~=T
    xshoot = repmat(targ_ss,[1,T]);
else
    disp('using saved start');
    xshoot = xshoot_final;
end

%Log stuff
targ_ss(log_idx,:) = log(targ_ss(log_idx,:));
xshoot (log_idx,:) = log(xshoot (log_idx,:));


shoot_ = @(x) shooting(x,X0,targ_ss,T,log_idx,neq,nstate,[],...
    Busd,Beur,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,Yus,Yeu,Yrw,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);

% SETUP
tic

options = optimoptions('fsolve');
options.Display = 'off';%options.Display = 'iter';
options.MaxIterations = 60;
options.FiniteDifferenceType = 'central';
options.SpecifyObjectiveGradient = true;
options.CheckGradients = false;

% FSOLVE CALL
xfinal_tmp = fsolve(shoot_,xshoot(:),options);

% COMPUTE VARIABLES TO PLOT FROM FLIGHT
[resid_final,~,xshoot_final,dfinal,usd_shrs,usd_use,con_out,tb_out,ep_out,nfa_out,prices_out,delts_out,walras_out,tau_out,taup_out,returns_out,irs_out] = shoot_(xfinal_tmp);

%the final paths
xshoot_final(log_idx,:) = exp(xshoot_final(log_idx,:));
frac_path = [frac_shoot(:),B2frac(xshoot_final(neq+(1:4),:),Busd,Beur,mu_us,mu_eu,mu_rw)];
bond_path = [X0,xshoot_final(neq+(1:4+xstate),:)];

%consumption equivalents for each country in each case
U_flt = NaN(3,2000);
for jj = 1:2000
    if sig ~= 1
        U_flt(:,jj) = bet^(jj-1)*(con_out(:,jj).^(1 - sig))./(1 - sig);
    else
        U_flt(:,jj) = bet^(jj-1)*log(con_out(:,min(jj,T-1)));
    end
    
end
welf = sum(U_flt,2);
cons_equiv  = (exp( (1- bet)*welf));
cons_steady = con_out(:,end);

[resid_sorted, sort_ind] = sort(resid_final);
nvar = neq+nstate;

disp(['FINAL CHANGE: ' num2str(sum(dfinal.^2)) ' || Time taken: ' num2str(toc) ]);

