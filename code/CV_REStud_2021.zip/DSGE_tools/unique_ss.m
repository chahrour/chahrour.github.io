function idx_kp = unique_ss(Xss)


idx_kp = false(1,size(Xss,2));
idx_kp(1) = true;
for jj = 2:length(Xss)
    
    keep = true;
    for kk = find(idx_kp)
        if sum((Xss(1:2,kk) - Xss(1:2,jj)).^2)<1e-8
            keep = false;
        end
    end
    idx_kp(jj) = keep;

end