function args_str = args_string(args)

%Print to string
args_str = char(args);

%Drop brackets
%args_str = args_str(3:end-2);  

%RAC edits for version robustness (replace line &)
args_str(args_str==']')=[];
args_str(args_str=='[')=[];

%Get rid of spaces
args_str= args_str(~isspace(args_str));
