%SUBSTITUTE OUT SOME ARGUMENTS IN A FUNCTION USING THE CALL TO ANOTHER
%FUNCTION

function out = subs(in,sub,tmp, def_sub_nms, call);

fin = fopen(in, 'r');
fsub = fopen(sub, 'r');
fout = fopen(tmp, 'w');

%Get subs line
if nargin ==4
    subsl = [fgetl(fsub),';'];
else
    subsl = call;
end


l1 = fgetl(fin);
l1_tmp = l1;
for jj = 1:length(def_sub_nms)
    
    idx = strfind(l1_tmp,[def_sub_nms{jj}, ',']) ;
    
    if ~isempty(idx)
        l1_tmp(idx:idx+length(def_sub_nms{jj})) = [];
    else
        %check if at end
        idx = strfind(l1_tmp,[def_sub_nms{jj}, ')']) ;
        if ~isempty(idx)
            l1_tmp(idx:idx+length(def_sub_nms{jj})-1) = [];
            disp('Susbstituting last entry, check my work.');
        else
%            warning('empty substitution');
            out = 0;
 %           return
        end
    end
end


fprintf(fout,'%s\n', l1_tmp);
for jj = 1:5
    fprintf(fout,'%s\n', fgetl(fin));
end
fprintf(fout, '%s\n', subsl(9:end));

lrest = fgetl(fin);
while ischar(lrest)
    fprintf(fout, '%s\n', lrest);
    lrest = fgetl(fin);
end

fclose(fout);
if nargin==4
fclose(fsub);
end
fclose(fin);

idx = find(l1_tmp=='=');
out = l1_tmp(idx:end);

copyfile(tmp,in);
