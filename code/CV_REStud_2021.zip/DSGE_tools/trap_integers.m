function out = trap_integers(str)

int_list = '1234567890';

%Locate all numerals
nvec = false(10,length(str));
for jj = 1:10
   nvec(jj,:) = (str==int_list(jj));
end
nvec = sum(nvec);

%Find continguous numeral blocks
dn1 = diff([0,nvec]);
dn2 = diff([nvec,0]);
starts = find(dn1==1);
stops  = find(dn2==-1);


for jj = 1:length(starts)
    num = str(starts(jj):stops(jj));
    
    start_clear = false;
    end_clear   = false;
    
    if starts(jj)==1 || (starts(jj)>1 && str(starts(jj)-1)~='.' && str(starts(jj)-1)~='x' && str(starts(jj)-1)~='y' && str(starts(jj)-1)~='_')
        start_clear = true;
    end
    
    if stops(jj) == length(str) || (stops(jj)<length(str) && str(stops(jj)+1)~='.' && str(stops(jj)+1)~='x' && str(stops(jj)+1)~='y' && str(stops(jj)+1)~='_')
        end_clear = true;
    end
    
 
    if start_clear && end_clear
        str = [str(1:starts(jj)-1), num '.0' str(stops(jj)+1:end)];
        starts = starts+2;
        stops  = stops+2;
    else
        str = [str(1:starts(jj)-1), num  str(stops(jj)+1:end)];
    end
    
end

out = str;