%% FIGURE 5(a): 15% ASYM TRADE WAR - ATTRACTION REGIONS

load saved_results/steady_baseline.mat frac_ss
frac_old = frac_ss;

load saved_results/attraction_region_usrow15 solve_idx_r frac_rw_usd_dense frac_rw_eur_dense frac_ss

f1 = figure;
s = subplot(1,1,1);hold on;
s.XLim = frac_rw_usd_dense([1,end]);
s.YLim = frac_rw_eur_dense([1,end]);
s.FontSize = 14;

fgrid      = frac_rw_usd_dense;
fgrid_flip = fliplr(frac_rw_usd_dense);

np = length(frac_rw_eur_dense);

X2 = zeros(1,np);
Y2 = fliplr(frac_rw_eur_dense);
for jj = 1:length(fgrid)
    X2(jj) = fgrid(find(solve_idx_r(jj,:), 1,'first'));
end


X = [min(fgrid),max(fgrid), max(fgrid),X2,min(fgrid)];
Y = [min(fgrid),min(fgrid), max(fgrid),Y2,min(fgrid)];
p1= patch(X,Y, color_mul);
p1.LineStyle = '-';
p1.LineWidth = .1;

X = [X2,min(fgrid),min(fgrid)];
Y = [Y2,min(fgrid),max(fgrid)];
p3 = fill(X,Y, color_eur);
p3.LineStyle = '-';
p3.LineWidth = .1;


p = scatter(frac_ss(1,[1,3]),frac_ss(2,[1,3]), 'marker', 'o', 'SizeData',75, 'MarkerEdgeColor', [0,0,0], 'MarkerFaceColor', [0 0 0]);
p = scatter(frac_ss(1,2),frac_ss(2,2), 'marker', 'o', 'SizeData', 90, 'MarkerEdgeColor', [0,0,0], 'MarkerFaceColor', [1 1 1]);
p = scatter(frac_old(1,1),frac_old(2,1), 'marker', 'x', 'SizeData', 90, 'MarkerEdgeColor', [0,0,0], 'MarkerFaceColor', [1 1 1]);

xlabel('RW USD bond holdings (fraction of $\bar{B}$)', 'interpreter', 'latex', 'fontsize',18);
ylabel('RW EUR bond holdings (fraction of $\bar{B}$)', 'interpreter', 'latex', 'fontsize',18);


%Add flight path to region
load saved_results/dollar_to_dollar15_transition.mat frac_path
p = plot(frac_path(1,1:55),frac_path(2,1:55), '-k', 'linewidth', 2.5);
a=annotation('arrow', frac_path(1,[35,end]), frac_path(2,[35,end]));
 a.Parent     = gca;
 a.HeadWidth  = 5;
 a.HeadLength = 5;
 a.Color  = [.7,.7,.7]';
 p.Color  = [.7,.7,.7]';

%Add flight path to region
load saved_results/dollar_to_euro15_transition.mat frac_path
p = plot(frac_path(1,1:80),frac_path(2,1:80), '-k', 'linewidth', 2.5);
a=annotation('arrow', frac_path(1,[80,end-5]), frac_path(2,[80,end-5]));
 a.Parent     = gca;
 a.HeadWidth  = 8;
 a.HeadLength = 8;
 a.Color  = [.7,.7,.7]';
 p.Color  = [.7,.7,.7]';
 l = legend([p3,p1],'Euro', 'Indet.', 'location', 'northeast');

 
saveas(f1, 'saved_figures/figure5a.eps', 'epsc')


%% FIGURE 5(b): 30% ASYM TRADEWARE - ATTRACTION REGIONS
load saved_results/steady_baseline frac_ss
frac_old = frac_ss(:,1);

load saved_results/dollar_to_euro_tradewar_transition frac_path
load saved_results/steady_usrowwar30.mat frac_ss


f1 = figure;
s = subplot(1,1,1);hold on;
s.XLim = [.15,.85];
s.YLim = [.15,.85];
s.FontSize = 14;


X = [.15 .85 .85 .15];
Y = [.15 .15 .85 .85];
p3 = fill(X,Y, color_eur);
p3.LineStyle = '-';
p3.LineWidth = .1;

p = scatter(frac_ss(1,:),frac_ss(2,:), 'marker', 'o', 'SizeData',75, 'MarkerEdgeColor', [0,0,0], 'MarkerFaceColor', [0 0 0]);
p = scatter(frac_old(1),frac_old(2), 'marker', 'x', 'SizeData', 90, 'MarkerEdgeColor', [0,0,0], 'MarkerFaceColor', [1 1 1]);

xlabel('RW USD bond holdings (fraction of $\bar{B}$)', 'interpreter', 'latex', 'fontsize',18);
ylabel('RW EUR bond holdings (fraction of $\bar{B}$)', 'interpreter', 'latex', 'fontsize',18);

%Add flight path to region
p = plot(frac_path(1,1:80),frac_path(2,1:80), '-k', 'linewidth', 2.5);
a=annotation('arrow', frac_path(1,[80,end-75]), frac_path(2,[80,end-75]));
a.Parent     = gca;
a.HeadWidth  = 8;
a.HeadLength = 8;
a.Color  = [.7,.7,.7]';
p.Color  = [.7,.7,.7]';


saveas(f1, 'saved_figures/figure5b.eps', 'epsc')