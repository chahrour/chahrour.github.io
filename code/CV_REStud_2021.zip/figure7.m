f1 = static_figure(.75); f1.Children(1).Visible = false;
f2 = static_figure(1.1);


saveas(f1, 'saved_figures/figure7a.eps', 'epsc');

saveas(f2, 'saved_figures/figure7b.eps', 'epsc');
