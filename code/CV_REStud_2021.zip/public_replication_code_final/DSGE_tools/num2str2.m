function out = num2str2(x)

out = sprintf('%1.2e', x);

end