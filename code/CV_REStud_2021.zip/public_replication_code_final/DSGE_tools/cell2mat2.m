function out = cell2mat2(in)

nrow = length(in);
ncol = length(in{1});

out = NaN(nrow,ncol);
for ii = 1:nrow
    for jj = 1:ncol
        if ~isempty(in{ii}{jj})
        out(ii,jj) = in{ii}{jj};
        end
    end
end
