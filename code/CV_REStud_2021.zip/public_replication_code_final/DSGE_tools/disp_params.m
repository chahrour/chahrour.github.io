param_list = {'Busd', 'Beur', 'vepsf',  'phi', 'r', 'sige', 'kap' , 'ah_us'};


for jj = 1:length(param_list)
disp([sprintf('%s       \t', param_list{jj}), ': ', sprintf('%1.13f', eval(param_list{jj}))]);
end

