clc; close all; clear all;

%Add helper functions to the path
setup

%**************************************************************************
% ALL COMPUTATIONS - All results generated here are saved for use in
% figure/tables.
%**************************************************************************

%Do you want to-rerun all computations or use saved results?
scratch = true;  %true=compute everything from scratch; false = use saved results to generate figures

if scratch
    
    %% GENERATE: the mex & automatically generated m-files: ~1.5 min
    simplify_expressions
    
    %% COMPUTE: Steady-states of the baseline and other calibrations: ~1min
    steady_solve
    
    %% COMPUTE: Attraction regions for the baseline model: - ~15 min on 8 cores
    load saved_results/steady_baseline
    attraction_regions
    save saved_results/attraction_region_baseline frac_rw_usd_dense frac_rw_eur_dense solve_indic frac_ss
    
    %% COMPUTE: Attraction regions for the 15% US-ROW trade war: ~80 min on 8 cores
    load saved_results/steady_usrowwar15.mat
    attraction_regions_two
    save saved_results/attraction_region_usrow15 solve_idx_l solve_idx_r frac_rw_usd_dense frac_rw_eur_dense frac_ss

    
    %% COMPUTE: Baseline middle to dollar SS (flight path): <1min
    %  used in Figures 1 & 2
    load saved_results/steady_baseline
    clear xshoot_final
    frac_shoot = frac_ss(:,2);        %leave from middle
    targ_ss    = xspecial_long(:,1);  %land at dollar
    shooting_solve
    save saved_results/sym_to_dollar_transition *out *use *shrs frac_path cons_equiv
    
    %% COMPUTE: Euro emerges but doesn't win (flight path): < 1min
    % used in Figure 3
    load saved_results/steady_baseline
    
    % Introuction of euro
    load saved_results/steady_beforeur frac_ss Beur
    frac_shoot = frac_ss(:,1);        %leave from dollar baseline
    Beur0      = Beur;
    
    % arrive at baseline USD steady
    load saved_results/steady_baseline xspecial_long Beur;
    targ_ss    = xspecial_long(:,1);
    Beur1      = Beur;
    
    %flat paths
    Beur_flat = ones(1,300)*Beur1;
    Beur_prof = ones(1,300)*Beur1;
    
    %profile path
    Beur_prof(1:10) = Beur0 + ((0:9)/10)*(Beur1-Beur0);
    xgrid = 1:length(Beur_prof);
    xhold = [1 2 5 13:length(Beur_prof) ];
    Beur_prof = spline(xhold,Beur_prof(xhold),xgrid);
    
    
    %Starting point
    clear xshoot_final
    
    %recompute ...
    %NOTE: you need to wiggle here (use homotopy), going scale 0 to 1
    scl = linspace(0,1,11);
    for jj = 1:length(scl)
        Beur = scl(jj)*Beur_prof + (1-scl(jj))*Beur_flat;
        shooting_solve
    end
    
    save saved_results/eur_emerges_transition *out *use *shrs frac_path cons_equiv Beur Yeu
    
    %% COMPUTE: Euro takes over (flight path): < 1min
    % used in Figure 3
    clear xshoot_final
    
    % Introuction of euro
    load saved_results/steady_beforeur frac_ss Beur Yeu
    frac_shoot = frac_ss(:,1);        %leave from dollar baseline
    Beur0      = Beur;
    Yeu0       = Yeu;
    
    % arrive at baseline new EUR steady
    load saved_results/steady_baseline.mat Beur Yeu
    Beur1 = Beur;
    Yeu1  = Yeu;
    
    % arrive at baseline new EUR steady
    load saved_results/steady_aftereur frac_ss xspecial_long Beur Yeu
    targ_ss    = xspecial_long(:,1);
    Beur2 = Beur;
    
    
    %Flat paths
    Beur_flat = Beur2*ones(1,300);
    Beur_prof = Beur2*ones(1,300);
    
    
    %Profile paths
    Beur_prof(1:10) = Beur0+((0:9)/10)*(Beur1(end)-Beur0);
    Beur_prof(11:30) = Beur1+((0:19)/20)*(Beur2(end)-Beur1);
    xgrid = 1:length(Beur_prof);
    xhold = [1 2, 13:27, 33:length(Beur_prof) ];
    Beur_prof = spline(xhold,Beur_prof(xhold),xgrid);
    
    
    %Starting point
    xshoot = repmat(targ_ss,[1,300]);
    
    %recompute ...
    %NOTE: you need to wiggle here (use homotopy), going gradually from scale 0 to 1
    %reusing xshoot_final from previous run.
    scl = linspace(0,1,15);
    for jj = 1:length(scl)
        Beur = scl(jj)*Beur_prof + (1-scl(jj))*Beur_flat;
        shooting_solve
    end
    
    save saved_results/eur_takesover_transition *out *use *shrs frac_path cons_equiv Beur Yeu
    
    %% COMPUTE: Growth of ROW mu (flight path): < 1min
    % used in Figure 4
    load saved_results/steady_baseline
    hus = (ah_us - mu_us)/(1-mu_us);
    heu = (ah_eu - mu_eu)/(1-mu_eu);
    
    % Introuction of euro
    load saved_results/steady_beforerw frac_ss mu_us Cus
    frac_shoot = frac_ss(:,1);        %leave from dollar baseline
    mu_us0 = mu_us;
    
    Cus_orig = Cus;
    
    % arrive at baseline USD steady
    load saved_results/steady_baseline xspecial_long mu_us Cus;
    targ_ss  = xspecial_long(:,1);
    mu_usf   = mu_us;
    mu_rwf   = mu_rw;
    ah_usf   = ah_us;
    Cnew_old = log(Cus_orig/Cus);
    
    %profile path
    mu_us = ones(1,300)*mu_usf;
    mu_us(1)  = mu_us0;
    mu_us(2)  = mu_us0;
    mu_us(30) = .25*mu_us0 + .75*mu_usf;
    
    xgrid = 1:length(mu_us);
    xhold = [1 2, 30 60:length(mu_us) ];
    mu_usn = spline(xhold,mu_us(xhold),xgrid);
    mu_rwn = 1-mu_usn-mu_eu;
    mu_eu = mu_eu + 0*mu_us;
    
    ah_usn = hus + (1-hus)*mu_usn;
    ah_eu  = heu + (1-heu)*mu_eu;
    ah_rw  = ah_rw + 0*mu_us;
    
    %Starting point
    clear xshoot_final
    %xshoot = repmat(targ_ss,[1,300]);
    
    %recompute ...
    %NOTE: you need to wiggle here (use homotopy), going scale 0 to 1
    %get the full experiment, reusing xshoot_final from previous run.
    scl = linspace(0,1,11);
    for jj = 1:length(scl)
        ah_us = scl(jj)*ah_usn + (1-scl(jj))*ah_usf;
        mu_us = scl(jj)*mu_usn + (1-scl(jj))*mu_usf;
        mu_rw = scl(jj)*mu_rwn + (1-scl(jj))*mu_rwf;
        shooting_solve
    end
    
    save saved_results/rw_emerges_transition *out *use *shrs frac_path cons_equiv Beur Yeu Brw_* *_final mu_*
    
    %% COMPUTE: 15% US-ROW trade war - flight path from dollar ss to dollar SS: < 1min
    % used in Figure 5
    clear xshoot_final
    
    load saved_results/steady_baseline
    frac_shoot = frac_ss(:,1);        %leave from dollar baseline
    
    load saved_results/steady_usrowwar15.mat tax* xspecial*
    targ_ss    = xspecial_long(:,1);  %land at dollar
    
    shooting_solve
    save saved_results/dollar_to_dollar15_transition *out *use *shrs frac_path cons_equiv
    
    %% COMPUTE: 15% US-ROW trade war - flight path from dollar ss to euro SS: < 1min
    % used in Figure 5
    clear xshoot_final
    
    load saved_results/steady_baseline
    frac_shoot = frac_ss(:,1);        %leave from dollar baseline
    
    load saved_results/steady_usrowwar15.mat tax* xspecial*
    targ_ss    = xspecial_long(:,3);  %land at dollar
    
    shooting_solve
    save saved_results/dollar_to_euro15_transition *out *use *shrs frac_path cons_equiv
    
    %% COMPUTE: 30% US-ROW trade war - flight path from dollar ss to euro ss: < 1min
    % used in Figure 5
    clear xshoot_final
    
    load saved_results/steady_baseline
    frac_shoot = frac_ss(:,1);        %leave from dollar baseline
    
    load saved_results/steady_usrowwar30.mat   tax* xspecial*
    targ_ss    = xspecial_long(:,end);  %land at euro, the only steady-state??
    
    %tax histories
    tax_us_rw  = tax_us_rw+zeros(1,300);
    tax_rw_us  = tax_us_rw+zeros(1,300);
    
    
    %recompute or ...
    shooting_solve
    save saved_results/dollar_to_euro_tradewar_transition  tax* *out *use *shrs frac_path cons_equiv
    
    %% COMPUTE: 30% US-ROW trade war as function of duration, flight to USD: ~2 min
    % used in Figure 6
    Tmax = 40;
    Cequiv_stay = NaN(3,Tmax+1);
    
    %first assume return to dollar
    load saved_results/steady_baseline
    
    frac_shoot = frac_ss(:,1);        %leave from dollar baseline
    targ_ss    = xspecial_long(:,1);
    crit_stay  = NaN(1,Tmax+1);
    %%%
    
    tt = 0;
    
    tax_us_rw  = zeros(1,300);
    tax_rw_us  = zeros(1,300);
    
    tax_us_eu  = zeros(1,300);
    tax_eu_us  = zeros(1,300);
    
    tvec = linspace(0,.30,3);
    clear xshoot_final
    %raise taxes gradually
    for mm = 1:length(tvec)-1
        tax_us_rw(:,1:tt) = tvec(mm+1);
        tax_rw_us(:,1:tt) = tvec(mm+1);
        
        tax_us_eu(:,1:tt) = tvec(mm);
        tax_eu_us(:,1:tt) = tvec(mm);
        
        shooting_solve
        
    end
    
    frac_shoot = frac_ss(:,1);
    
    tax_us_rw(:,1:tt) = tvec(end);
    tax_rw_us(:,1:tt) = tvec(end);
    
    tax_us_eu(:,1:tt) = tvec(end);
    tax_eu_us(:,1:tt) = tvec(end);
    
    shooting_solve
    
    Cequiv_stay(:,tt+1) = cons_equiv;
    
    
    for tt = 1:Tmax
        tax_us_rw  = zeros(1,300);
        tax_rw_us  = zeros(1,300);
        
        tax_us_eu  = zeros(1,300);
        tax_eu_us  = zeros(1,300);
        
        tvec = linspace(0.2,.30,2);
        
        %raise taxes gradually
        for mm = 1:length(tvec)-1
            tax_us_rw(:,1:tt) = tvec(mm+1);
            tax_rw_us(:,1:tt) = tvec(mm+1);
            
            tax_us_eu(:,1:tt) = tvec(mm);
            tax_eu_us(:,1:tt) = tvec(mm);
            
            shooting_solve
            
        end
        %}
        
        frac_shoot = frac_ss(:,1);
        
        tax_us_rw(:,1:tt) = tvec(end);
        tax_rw_us(:,1:tt) = tvec(end);
        
        tax_us_eu(:,1:tt) = tvec(end);
        tax_eu_us(:,1:tt) = tvec(end);
        
        shooting_solve
        
        crit_stay(tt+1) = sum(dfinal.^2)+sum(resid_final.^2);
        if crit_stay(tt+1) >1e-3
            break;
        end
        
        Cequiv_stay(:,tt+1) = cons_equiv;
        tt
    end
    
    %% COMPUTE: 30% US-ROW trade war as function of duration, flight to EUR: ~4 min
    % used in Figure 6
    Cequiv_go   = NaN(3,Tmax+1);
    frac_shoot = frac_ss(:,1);        %leave from dollar baseline
    targ_ss    = xspecial_long(:,3);
    crit_go    = NaN(1,Tmax+1);
    
    %%%
    
    tt = Tmax;
    
    tax_us_rw  = zeros(1,300);
    tax_rw_us  = zeros(1,300);
    
    tax_us_eu  = zeros(1,300);
    tax_eu_us  = zeros(1,300);
    
    tvec = linspace(0,.30,5);
    clear xshoot_final
    
    %Start from middle, raise taxes gradually
    for mm = 1:length(tvec)-1
        
        frac_shoot = frac_ss(:,2);
        
        tax_us_rw(:,1:tt) = tvec(mm+1);
        tax_rw_us(:,1:tt) = tvec(mm+1);
        
        tax_us_eu(:,1:tt) = tvec(mm);
        tax_eu_us(:,1:tt) = tvec(mm);
        
        shooting_solve
    end
    
    frac_shoot = frac_ss(:,2);
    
    tax_us_rw(:,1:tt) = tvec(end);
    tax_rw_us(:,1:tt) = tvec(end);
    
    tax_us_eu(:,1:tt) = tvec(end);
    tax_eu_us(:,1:tt) = tvec(end);
    
    shooting_solve
    
    frac_shoot = frac_ss(:,1);
    shooting_solve
    
    crit_go(tt+1) =sum(dfinal.^2)+sum(resid_final.^2);
    Cequiv_go(:,tt+1) = cons_equiv;
    
    %%%
    for tt = Tmax:-1:1
        tax_us_rw  = zeros(1,300);
        tax_rw_us  = zeros(1,300);
        
        tax_us_eu  = zeros(1,300);
        tax_eu_us  = zeros(1,300);
        
        tvec = 0.30;
        
        tax_us_rw(:,1:tt) = tvec(end);
        tax_rw_us(:,1:tt) = tvec(end);
        
        tax_us_eu(:,1:tt) = tvec(end);
        tax_eu_us(:,1:tt) = tvec(end);
        
        frac_shoot = frac_ss(:,2);
        shooting_solve
        
        frac_shoot = frac_ss(:,1);
        shooting_solve
        
        
        crit_go(tt+1) =sum(dfinal.^2)+sum(resid_final.^2);
        if crit_go(tt+1) >1e-3
            break;
        end
        
        Cequiv_go(:,tt+1) = cons_equiv;
        tt
    end
    save saved_results/tmp_tradewar_transition30 *out *use *shrs frac_path cons_equiv Cequiv_go Cequiv_stay
else
    load saved_results/steady_baseline;
end

%%
%**************************************************************************
% ALL FIGURES - used saved results from above
%**************************************************************************

%Figure 1: attraction regions
figure1

%Figure 2: transition paths from symmetric steady-state
figure2

%Figure 3: introduction of the euro experiments
figure3

%Figure 4: growth of rest-of-wrld
figure4

%Figure 5: atttraction regions under trade war scenarios
figure5

%Figure 6: welfare costs of trade wars
figure6

%Figure 7: picture of best response fucntions for steady-state model (appendix)
figure7

%%
%**************************************************************************
% ALL TABLES
%**************************************************************************
scratch = true;

if scratch
    %% GENERATE: the mex & automatically generated m-files for the case with ROW asset (only used in Table 3)
    simplify_expressions_row
    
    %% Compute the SS values in the case with ROW asset
    steady_solve_row
end

%% Make all of the TABLES
make_all_tables
