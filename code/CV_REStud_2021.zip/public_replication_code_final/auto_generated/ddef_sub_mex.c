

#include <math.h>
#include <mex.h>
#include <lapack.h>
#include <blas.h>
#include <stdlib.h>
#include <string.h>


/* Input Arguments */
#define Cus_eu_in	prhs[0]
#define Cus_rw_in	prhs[1]
#define Ceu_us_in	prhs[2]
#define Ceu_rw_in	prhs[3]
#define Crw_us_in	prhs[4]
#define Crw_eu_in	prhs[5]
#define Crw_row_in	prhs[6]
#define Qusd_in	prhs[7]
#define Qeur_in	prhs[8]
#define Pus_us_in	prhs[9]
#define Pus_eu_in	prhs[10]
#define Pus_in	prhs[11]
#define Peu_eu_in	prhs[12]
#define Peu_us_in	prhs[13]
#define Peu_in	prhs[14]
#define Prw_in	prhs[15]
#define Prw_us_in	prhs[16]
#define Prw_eu_in	prhs[17]
#define m_us_in	prhs[18]
#define m_eu_in	prhs[19]
#define m_rw_in	prhs[20]
#define pim_us_eu__in	prhs[21]
#define pim_us_rw__in	prhs[22]
#define pex_us_eu__in	prhs[23]
#define pim_eu_us__in	prhs[24]
#define pim_eu_rw__in	prhs[25]
#define pex_eu_us__in	prhs[26]
#define pim_rw_us__in	prhs[27]
#define pim_rw_eu__in	prhs[28]
#define pim_rw_row__in	prhs[29]
#define pex_rw_us__in	prhs[30]
#define pex_rw_eu__in	prhs[31]
#define Vusd_in	prhs[32]
#define sbar_rw_in	prhs[33]
#define Brw_usda_in	prhs[34]
#define Brw_eura_in	prhs[35]
#define Bus_usda_in	prhs[36]
#define Beu_eura_in	prhs[37]
#define Beur_in	prhs[38]
#define Busd_in	prhs[39]
#define Prw_rw_in	prhs[40]
#define Xeu_in	prhs[41]
#define Xus_in	prhs[42]
#define Yeu_in	prhs[43]
#define Yrw_in	prhs[44]
#define Yus_in	prhs[45]
#define ah_eu_in	prhs[46]
#define ah_us_in	prhs[47]
#define ah_rw_in	prhs[48]
#define alph_in	prhs[49]
#define bet_in	prhs[50]
#define dtax_eu_us_in	prhs[51]
#define dtax_us_eu_in	prhs[52]
#define dtax_eu_rw_in	prhs[53]
#define dtax_rw_eu_in	prhs[54]
#define dtax_rw_us_in	prhs[55]
#define dtax_us_rw_in	prhs[56]
#define dtax_rw_row_in	prhs[57]
#define eta_in	prhs[58]
#define kap_in	prhs[59]
#define mu_eu_in	prhs[60]
#define mu_us_in	prhs[61]
#define mu_rw_in	prhs[62]
#define omg_in	prhs[63]
#define per_p_year_in	prhs[64]
#define phi_in	prhs[65]
#define phi_eug_in	prhs[66]
#define phi_usg_in	prhs[67]
#define phi_rwg_in	prhs[68]
#define r_in	prhs[69]
#define sig_in	prhs[70]
#define sige_in	prhs[71]
#define tau_in	prhs[72]
#define taup_in	prhs[73]
#define tax_eu_in_in	prhs[74]
#define tax_us_in_in	prhs[75]
#define tax_eu_us_in	prhs[76]
#define tax_us_eu_in	prhs[77]
#define tax_eu_rw_in	prhs[78]
#define tax_rw_eu_in	prhs[79]
#define tax_rw_us_in	prhs[80]
#define tax_us_rw_in	prhs[81]
#define tax_eu_out_in	prhs[82]
#define tax_us_out_in	prhs[83]
#define tax_rw_out_in	prhs[84]
#define tax_rw_row_in	prhs[85]
#define upp_eur_in	prhs[86]
#define upp_usd_in	prhs[87]
#define vepsf_in	prhs[88]
#define vepst_in	prhs[89]
#define z_in	prhs[90]


/* Output Arguments */
#define out plhs[0]


#if !defined(MAX)
#define	MAX(A, B)	((A) > (B) ? (A) : (B))
#endif

#if !defined(MIN)
#define	MIN(A, B)	((A) < (B) ? (A) : (B))
#endif

#define pi  3.141592653589793
  

/* Prints an MxN matrix to Screen*/
void printmat_rowmaj(int m, int n, double M[m*n]){
    int x,y;
    int k = 0;
    printf("\n");
    for(x=0;x<m;x++){
        for(y=0;y<n;y++){
            printf("%1.11lf\t", M[k]);
            k++;
        }
        printf("%\n");
    }
    return;
}


void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray*prhs[] )

{
     /*Values in Loops*/
    double C,H,D_p,K_p,MU,E1,E2,E3,D,K,HL,LAML,GAMtildeL,GAM,A,RW,MUtmp;
    
    double *OUT;
    
     double Cus_eu,Cus_rw,Ceu_us,Ceu_rw,Crw_us,Crw_eu,Crw_row,Qusd,Qeur,Pus_us,Pus_eu,Pus,Peu_eu,Peu_us,Peu,Prw,Prw_us,Prw_eu,m_us,m_eu,m_rw,pim_us_eu_,pim_us_rw_,pex_us_eu_,pim_eu_us_,pim_eu_rw_,pex_eu_us_,pim_rw_us_,pim_rw_eu_,pim_rw_row_,pex_rw_us_,pex_rw_eu_,Vusd,sbar_rw,Brw_usda,Brw_eura,Bus_usda,Beu_eura,Beur,Busd,Prw_rw,Xeu,Xus,Yeu,Yrw,Yus,ah_eu,ah_us,ah_rw,alph,bet,dtax_eu_us,dtax_us_eu,dtax_eu_rw,dtax_rw_eu,dtax_rw_us,dtax_us_rw,dtax_rw_row,eta,kap,mu_eu,mu_us,mu_rw,omg,per_p_year,phi,phi_eug,phi_usg,phi_rwg,r,sig,sige,tau,taup,tax_eu_in,tax_us_in,tax_eu_us,tax_us_eu,tax_eu_rw,tax_rw_eu,tax_rw_us,tax_us_rw,tax_eu_out,tax_us_out,tax_rw_out,tax_rw_row,upp_eur,upp_usd,vepsf,vepst,z;

            
    /*Results*/
    double rsum=1;
    
    
    /*Create output argument*/
    out = mxCreateDoubleMatrix(40,38,mxREAL);

    OUT = mxGetPr(out);
    
    
    /*Counters*/
    long ns, ii,tt;
    
    /*BLAS working memory*/
    ptrdiff_t one = 1;
    ptrdiff_t info = 0;
    long IPIV[4] = {0,1,2,3};

    
    /*Check for proper number of arguments*/
    if (nrhs == 91)  {} else{mexErrMsgTxt(" 91 inputs arguments required.");}

    
    /* Get Dimensions of Input Arguments*/
    ptrdiff_t four  = 4;
    ptrdiff_t three = 3;
         
    /*Parameters intialized*/
    Cus_eu= *mxGetPr(Cus_eu_in);
Cus_rw= *mxGetPr(Cus_rw_in);
Ceu_us= *mxGetPr(Ceu_us_in);
Ceu_rw= *mxGetPr(Ceu_rw_in);
Crw_us= *mxGetPr(Crw_us_in);
Crw_eu= *mxGetPr(Crw_eu_in);
Crw_row= *mxGetPr(Crw_row_in);
Qusd= *mxGetPr(Qusd_in);
Qeur= *mxGetPr(Qeur_in);
Pus_us= *mxGetPr(Pus_us_in);
Pus_eu= *mxGetPr(Pus_eu_in);
Pus= *mxGetPr(Pus_in);
Peu_eu= *mxGetPr(Peu_eu_in);
Peu_us= *mxGetPr(Peu_us_in);
Peu= *mxGetPr(Peu_in);
Prw= *mxGetPr(Prw_in);
Prw_us= *mxGetPr(Prw_us_in);
Prw_eu= *mxGetPr(Prw_eu_in);
m_us= *mxGetPr(m_us_in);
m_eu= *mxGetPr(m_eu_in);
m_rw= *mxGetPr(m_rw_in);
pim_us_eu_= *mxGetPr(pim_us_eu__in);
pim_us_rw_= *mxGetPr(pim_us_rw__in);
pex_us_eu_= *mxGetPr(pex_us_eu__in);
pim_eu_us_= *mxGetPr(pim_eu_us__in);
pim_eu_rw_= *mxGetPr(pim_eu_rw__in);
pex_eu_us_= *mxGetPr(pex_eu_us__in);
pim_rw_us_= *mxGetPr(pim_rw_us__in);
pim_rw_eu_= *mxGetPr(pim_rw_eu__in);
pim_rw_row_= *mxGetPr(pim_rw_row__in);
pex_rw_us_= *mxGetPr(pex_rw_us__in);
pex_rw_eu_= *mxGetPr(pex_rw_eu__in);
Vusd= *mxGetPr(Vusd_in);
sbar_rw= *mxGetPr(sbar_rw_in);
Brw_usda= *mxGetPr(Brw_usda_in);
Brw_eura= *mxGetPr(Brw_eura_in);
Bus_usda= *mxGetPr(Bus_usda_in);
Beu_eura= *mxGetPr(Beu_eura_in);
Beur= *mxGetPr(Beur_in);
Busd= *mxGetPr(Busd_in);
Prw_rw= *mxGetPr(Prw_rw_in);
Xeu= *mxGetPr(Xeu_in);
Xus= *mxGetPr(Xus_in);
Yeu= *mxGetPr(Yeu_in);
Yrw= *mxGetPr(Yrw_in);
Yus= *mxGetPr(Yus_in);
ah_eu= *mxGetPr(ah_eu_in);
ah_us= *mxGetPr(ah_us_in);
ah_rw= *mxGetPr(ah_rw_in);
alph= *mxGetPr(alph_in);
bet= *mxGetPr(bet_in);
dtax_eu_us= *mxGetPr(dtax_eu_us_in);
dtax_us_eu= *mxGetPr(dtax_us_eu_in);
dtax_eu_rw= *mxGetPr(dtax_eu_rw_in);
dtax_rw_eu= *mxGetPr(dtax_rw_eu_in);
dtax_rw_us= *mxGetPr(dtax_rw_us_in);
dtax_us_rw= *mxGetPr(dtax_us_rw_in);
dtax_rw_row= *mxGetPr(dtax_rw_row_in);
eta= *mxGetPr(eta_in);
kap= *mxGetPr(kap_in);
mu_eu= *mxGetPr(mu_eu_in);
mu_us= *mxGetPr(mu_us_in);
mu_rw= *mxGetPr(mu_rw_in);
omg= *mxGetPr(omg_in);
per_p_year= *mxGetPr(per_p_year_in);
phi= *mxGetPr(phi_in);
phi_eug= *mxGetPr(phi_eug_in);
phi_usg= *mxGetPr(phi_usg_in);
phi_rwg= *mxGetPr(phi_rwg_in);
r= *mxGetPr(r_in);
sig= *mxGetPr(sig_in);
sige= *mxGetPr(sige_in);
tau= *mxGetPr(tau_in);
taup= *mxGetPr(taup_in);
tax_eu_in= *mxGetPr(tax_eu_in_in);
tax_us_in= *mxGetPr(tax_us_in_in);
tax_eu_us= *mxGetPr(tax_eu_us_in);
tax_us_eu= *mxGetPr(tax_us_eu_in);
tax_eu_rw= *mxGetPr(tax_eu_rw_in);
tax_rw_eu= *mxGetPr(tax_rw_eu_in);
tax_rw_us= *mxGetPr(tax_rw_us_in);
tax_us_rw= *mxGetPr(tax_us_rw_in);
tax_eu_out= *mxGetPr(tax_eu_out_in);
tax_us_out= *mxGetPr(tax_us_out_in);
tax_rw_out= *mxGetPr(tax_rw_out_in);
tax_rw_row= *mxGetPr(tax_rw_row_in);
upp_eur= *mxGetPr(upp_eur_in);
upp_usd= *mxGetPr(upp_usd_in);
vepsf= *mxGetPr(vepsf_in);
vepst= *mxGetPr(vepst_in);
z= *mxGetPr(z_in);

            
            
    /*Declare MatlabFunction Terms*/
    
                  
    /*Output argument*/
    OUT [0] =-(pow(Cus_eu,-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw)-1.0)*pow(Cus_rw,-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw))*mu_eu*pow(-(Ceu_us*mu_eu+Crw_us*mu_rw+Yus*mu_us*(phi_usg-1.0))/mu_us,ah_us)*(ah_us-1.0))/(mu_eu+mu_rw);
OUT [1] =-(pow(Ceu_us,-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(Ceu_rw,-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw))*ah_eu*mu_us*pow(-(Crw_eu*mu_rw+Cus_eu*mu_us+Yeu*mu_eu*(phi_eug-1.0))/mu_eu,ah_eu-1.0))/mu_eu;
OUT [4] =-mu_us/mu_eu;
OUT [40] =-(pow(Cus_eu,-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(Cus_rw,-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw)-1.0)*mu_rw*pow(-(Ceu_us*mu_eu+Crw_us*mu_rw+Yus*mu_us*(phi_usg-1.0))/mu_us,ah_us)*(ah_us-1.0))/(mu_eu+mu_rw);
OUT [42] =-(pow(Crw_eu,-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_us,-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_row,-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*ah_rw*mu_us*pow(-(Ceu_rw*mu_eu+Cus_rw*mu_us-mu_rw*(Crw_row-Yrw)*(phi_rwg-1.0))/mu_rw,ah_rw-1.0))/mu_rw;
OUT [45] =-mu_us/mu_rw;
OUT [80] =-(pow(Cus_eu,-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(Cus_rw,-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw))*ah_us*mu_eu*pow(-(Ceu_us*mu_eu+Crw_us*mu_rw+Yus*mu_us*(phi_usg-1.0))/mu_us,ah_us-1.0))/mu_us;
OUT [81] =-(pow(Ceu_us,-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw)-1.0)*pow(Ceu_rw,-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw))*mu_us*pow(-(Crw_eu*mu_rw+Cus_eu*mu_us+Yeu*mu_eu*(phi_eug-1.0))/mu_eu,ah_eu)*(ah_eu-1.0))/(mu_us+mu_rw);
OUT [83] =-mu_eu/mu_us;
OUT [121] =-(pow(Ceu_us,-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(Ceu_rw,-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw)-1.0)*mu_rw*pow(-(Crw_eu*mu_rw+Cus_eu*mu_us+Yeu*mu_eu*(phi_eug-1.0))/mu_eu,ah_eu)*(ah_eu-1.0))/(mu_us+mu_rw);
OUT [122] =-(pow(Crw_eu,-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_us,-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_row,-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*ah_rw*mu_eu*pow(-(Ceu_rw*mu_eu+Cus_rw*mu_us-mu_rw*(Crw_row-Yrw)*(phi_rwg-1.0))/mu_rw,ah_rw-1.0))/mu_rw;
OUT [125] =-mu_eu/mu_rw;
OUT [160] =-(pow(Cus_eu,-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(Cus_rw,-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw))*ah_us*mu_rw*pow(-(Ceu_us*mu_eu+Crw_us*mu_rw+Yus*mu_us*(phi_usg-1.0))/mu_us,ah_us-1.0))/mu_us;
OUT [162] =-(pow(Crw_eu,-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_us,-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)-1.0)*pow(Crw_row,-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*mu_us*pow(-(Ceu_rw*mu_eu+Cus_rw*mu_us-mu_rw*(Crw_row-Yrw)*(phi_rwg-1.0))/mu_rw,ah_rw)*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw);
OUT [163] =-mu_rw/mu_us;
OUT [201] =-(pow(Ceu_us,-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(Ceu_rw,-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw))*ah_eu*mu_rw*pow(-(Crw_eu*mu_rw+Cus_eu*mu_us+Yeu*mu_eu*(phi_eug-1.0))/mu_eu,ah_eu-1.0))/mu_eu;
OUT [202] =-(pow(Crw_eu,-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)-1.0)*pow(Crw_us,-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_row,-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*mu_eu*pow(-(Ceu_rw*mu_eu+Cus_rw*mu_us-mu_rw*(Crw_row-Yrw)*(phi_rwg-1.0))/mu_rw,ah_rw)*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw);
OUT [204] =-mu_rw/mu_eu;
OUT [242] =pow(Crw_eu,-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_us,-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_row,-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*ah_rw*pow(-(Ceu_rw*mu_eu+Cus_rw*mu_us-mu_rw*(Crw_row-Yrw)*(phi_rwg-1.0))/mu_rw,ah_rw-1.0)*(phi_rwg-1.0)-(pow(Crw_eu,-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_us,-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_row,-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)-1.0)*mu_rw*pow(-(Ceu_rw*mu_eu+Cus_rw*mu_us-mu_rw*(Crw_row-Yrw)*(phi_rwg-1.0))/mu_rw,ah_rw)*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw);
OUT [245] =phi_rwg-1.0;
OUT [291] =(Bus_usda*Pus_us*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf))/mu_us-pow(Bus_usda,2)*pow(Pus_us,2)*Qusd*1.0/pow(mu_us,2)*pow(upp_usd,2)*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf-1.0)*pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf-1.0);
OUT [293] =-(Pus_us*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf)*(Brw_usda-Busd+Bus_usda))/mu_eu-pow(Pus_us,2)*Qusd*1.0/pow(mu_eu,2)*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf-1.0)*pow(Brw_usda-Busd+Bus_usda,2)*pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf-1.0);
OUT [295] =(Brw_usda*Pus_us*upp_usd*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf))/mu_rw-pow(Brw_usda,2)*pow(Pus_us,2)*Qusd*1.0/pow(mu_rw,2)*pow(upp_usd,2)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf-1.0)*pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf-1.0);
OUT [297] =-(Bus_usda*Pus_us*Xus*m_us*pow(upp_usd,2)*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf-1.0)*pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf-1.0))/mu_us;
OUT [299] =(Pus_us*Xeu*m_eu*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf-1.0)*(Brw_usda-Busd+Bus_usda)*pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf-1.0))/mu_eu;
OUT [301] =-(Brw_usda*Pus_us*m_rw*pow(upp_usd,2)*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf-1.0)*pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf-1.0))/mu_rw;
OUT [303] =m_us*mu_us*((Bus_usda*Pus_us*Xus*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf))/mu_us-pow(Bus_usda,2)*pow(Pus_us,2)*Qusd*Xus*1.0/pow(mu_us,2)*pow(upp_usd,2)*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf-1.0)*pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf-1.0));
OUT [304] =-m_eu*mu_eu*((Pus_us*Xeu*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf)*(Brw_usda-Busd+Bus_usda))/mu_eu+pow(Pus_us,2)*Qusd*Xeu*1.0/pow(mu_eu,2)*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf-1.0)*pow(Brw_usda-Busd+Bus_usda,2)*pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf-1.0));
OUT [305] =m_rw*mu_rw*((Brw_usda*Pus_us*upp_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf))/mu_rw-pow(Brw_usda,2)*pow(Pus_us,2)*Qusd*1.0/pow(mu_rw,2)*pow(upp_usd,2)*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf-1.0)*pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf-1.0));
OUT [332] =-(Peu_eu*upp_eur*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf)*(-Beur+Beu_eura+Brw_eura))/mu_us-pow(Peu_eu,2)*Qeur*1.0/pow(mu_us,2)*pow(upp_eur,2)*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf-1.0)*pow(-Beur+Beu_eura+Brw_eura,2)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf-1.0);
OUT [334] =(Beu_eura*Peu_eu*upp_eur*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf))/mu_eu-pow(Beu_eura,2)*pow(Peu_eu,2)*Qeur*1.0/pow(mu_eu,2)*pow(upp_eur,2)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf-1.0)*pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf-1.0);
OUT [336] =(Brw_eura*Peu_eu*upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf))/mu_rw-pow(Brw_eura,2)*pow(Peu_eu,2)*Qeur*1.0/pow(mu_rw,2)*pow(upp_eur,2)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf-1.0)*pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf-1.0);
OUT [338] =-(Peu_eu*m_us*pow(upp_eur,2)*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf-1.0)*(Xus-1.0)*(-Beur+Beu_eura+Brw_eura)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf-1.0))/mu_us;
OUT [340] =(Beu_eura*Peu_eu*m_eu*pow(upp_eur,2)*(Xeu-1.0)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf-1.0)*pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf-1.0))/mu_eu;
OUT [342] =-(Brw_eura*Peu_eu*m_rw*pow(upp_eur,2)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf-1.0)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)*pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf-1.0))/mu_rw;
OUT [343] =m_us*mu_us*((Peu_eu*upp_eur*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf)*(Xus-1.0)*(-Beur+Beu_eura+Brw_eura))/mu_us+pow(Peu_eu,2)*Qeur*1.0/pow(mu_us,2)*pow(upp_eur,2)*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf-1.0)*(Xus-1.0)*pow(-Beur+Beu_eura+Brw_eura,2)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf-1.0));
OUT [344] =-m_eu*mu_eu*((Beu_eura*Peu_eu*upp_eur*(Xeu-1.0)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf))/mu_eu-pow(Beu_eura,2)*pow(Peu_eu,2)*Qeur*1.0/pow(mu_eu,2)*pow(upp_eur,2)*(Xeu-1.0)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf-1.0)*pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf-1.0));
OUT [345] =m_rw*mu_rw*((Brw_eura*Peu_eu*upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0))/mu_rw-pow(Brw_eura,2)*pow(Peu_eu,2)*Qeur*1.0/pow(mu_rw,2)*pow(upp_eur,2)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf-1.0)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)*pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf-1.0));
OUT [366] =(Pus*pow(Pus_us,-ah_us-1.0)*ah_us*pow(ah_us,ah_us)*(mu_eu+mu_rw)*pow(Pus_eu*(tax_us_eu+1.0),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw),-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw),-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw))*pow(Pus*pow(Pus_us,-ah_us)*pow(ah_us,ah_us)*pow(Pus_eu*(tax_us_eu+1.0),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw),-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw),-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw)),-(mu_eu+mu_rw)/(mu_rw*(ah_us-1.0))-1.0))/(mu_rw*(ah_us-1.0)*(tax_us_rw+1.0));
OUT [371] =(Bus_usda*Qusd*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf))/mu_us-pow(Bus_usda,2)*Pus_us*pow(Qusd,2)*1.0/pow(mu_us,2)*pow(upp_usd,2)*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf-1.0)*pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf-1.0);
OUT [373] =-(Qusd*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf)*(Brw_usda-Busd+Bus_usda))/mu_eu-Pus_us*pow(Qusd,2)*1.0/pow(mu_eu,2)*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf-1.0)*pow(Brw_usda-Busd+Bus_usda,2)*pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf-1.0);
OUT [375] =(Brw_usda*Qusd*upp_usd*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf))/mu_rw-pow(Brw_usda,2)*Pus_us*pow(Qusd,2)*1.0/pow(mu_rw,2)*pow(upp_usd,2)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf-1.0)*pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf-1.0);
OUT [377] =-(Bus_usda*Qusd*Xus*m_us*pow(upp_usd,2)*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf-1.0)*pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf-1.0))/mu_us;
OUT [379] =(Qusd*Xeu*m_eu*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf-1.0)*(Brw_usda-Busd+Bus_usda)*pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf-1.0))/mu_eu;
OUT [381] =-(Brw_usda*Qusd*m_rw*pow(upp_usd,2)*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf-1.0)*pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf-1.0))/mu_rw;
OUT [383] =m_us*mu_us*((Bus_usda*Qusd*Xus*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf))/mu_us-pow(Bus_usda,2)*Pus_us*pow(Qusd,2)*Xus*1.0/pow(mu_us,2)*pow(upp_usd,2)*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf-1.0)*pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf-1.0));
OUT [384] =-m_eu*mu_eu*((Qusd*Xeu*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf)*(Brw_usda-Busd+Bus_usda))/mu_eu+Pus_us*pow(Qusd,2)*Xeu*1.0/pow(mu_eu,2)*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf-1.0)*pow(Brw_usda-Busd+Bus_usda,2)*pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf-1.0));
OUT [385] =m_rw*mu_rw*((Brw_usda*Qusd*upp_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf))/mu_rw-pow(Brw_usda,2)*Pus_us*pow(Qusd,2)*1.0/pow(mu_rw,2)*pow(upp_usd,2)*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf-1.0)*pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf-1.0));
OUT [406] =-(Pus*pow(Pus_us,-ah_us)*pow(ah_us,ah_us)*mu_eu*pow(Pus_eu*(tax_us_eu+1.0),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw)-1.0)*(tax_us_eu+1.0)*pow(-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw),-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw),-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw))*pow(Pus*pow(Pus_us,-ah_us)*pow(ah_us,ah_us)*pow(Pus_eu*(tax_us_eu+1.0),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw),-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw),-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw)),-(mu_eu+mu_rw)/(mu_rw*(ah_us-1.0))-1.0))/(mu_rw*(tax_us_rw+1.0));
OUT [446] =-(pow(Pus_us,-ah_us)*pow(ah_us,ah_us)*(mu_eu+mu_rw)*pow(Pus_eu*(tax_us_eu+1.0),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw),-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw),-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw))*pow(Pus*pow(Pus_us,-ah_us)*pow(ah_us,ah_us)*pow(Pus_eu*(tax_us_eu+1.0),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw),-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw),-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw)),-(mu_eu+mu_rw)/(mu_rw*(ah_us-1.0))-1.0))/(mu_rw*(ah_us-1.0)*(tax_us_rw+1.0));
OUT [487] =(Peu*pow(Peu_eu,-ah_eu-1.0)*ah_eu*pow(ah_eu,ah_eu)*(mu_us+mu_rw)*pow(Peu_us*(tax_eu_us+1.0),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw),-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw),-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw))*pow(Peu*pow(Peu_eu,-ah_eu)*pow(ah_eu,ah_eu)*pow(Peu_us*(tax_eu_us+1.0),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw),-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw),-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw)),-(mu_us+mu_rw)/(mu_rw*(ah_eu-1.0))-1.0))/(mu_rw*(ah_eu-1.0)*(tax_eu_rw+1.0));
OUT [492] =-(Qeur*upp_eur*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf)*(-Beur+Beu_eura+Brw_eura))/mu_us-Peu_eu*pow(Qeur,2)*1.0/pow(mu_us,2)*pow(upp_eur,2)*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf-1.0)*pow(-Beur+Beu_eura+Brw_eura,2)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf-1.0);
OUT [494] =(Beu_eura*Qeur*upp_eur*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf))/mu_eu-pow(Beu_eura,2)*Peu_eu*pow(Qeur,2)*1.0/pow(mu_eu,2)*pow(upp_eur,2)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf-1.0)*pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf-1.0);
OUT [496] =(Brw_eura*Qeur*upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf))/mu_rw-pow(Brw_eura,2)*Peu_eu*pow(Qeur,2)*1.0/pow(mu_rw,2)*pow(upp_eur,2)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf-1.0)*pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf-1.0);
OUT [498] =-(Qeur*m_us*pow(upp_eur,2)*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf-1.0)*(Xus-1.0)*(-Beur+Beu_eura+Brw_eura)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf-1.0))/mu_us;
OUT [500] =(Beu_eura*Qeur*m_eu*pow(upp_eur,2)*(Xeu-1.0)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf-1.0)*pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf-1.0))/mu_eu;
OUT [502] =-(Brw_eura*Qeur*m_rw*pow(upp_eur,2)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf-1.0)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)*pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf-1.0))/mu_rw;
OUT [503] =m_us*mu_us*((Qeur*upp_eur*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf)*(Xus-1.0)*(-Beur+Beu_eura+Brw_eura))/mu_us+Peu_eu*pow(Qeur,2)*1.0/pow(mu_us,2)*pow(upp_eur,2)*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf-1.0)*(Xus-1.0)*pow(-Beur+Beu_eura+Brw_eura,2)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf-1.0));
OUT [504] =-m_eu*mu_eu*((Beu_eura*Qeur*upp_eur*(Xeu-1.0)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf))/mu_eu-pow(Beu_eura,2)*Peu_eu*pow(Qeur,2)*1.0/pow(mu_eu,2)*pow(upp_eur,2)*(Xeu-1.0)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf-1.0)*pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf-1.0));
OUT [505] =m_rw*mu_rw*((Brw_eura*Qeur*upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0))/mu_rw-pow(Brw_eura,2)*Peu_eu*pow(Qeur,2)*1.0/pow(mu_rw,2)*pow(upp_eur,2)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf-1.0)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)*pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf-1.0));
OUT [527] =-(Peu*pow(Peu_eu,-ah_eu)*pow(ah_eu,ah_eu)*mu_us*pow(Peu_us*(tax_eu_us+1.0),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw)-1.0)*(tax_eu_us+1.0)*pow(-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw),-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw),-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw))*pow(Peu*pow(Peu_eu,-ah_eu)*pow(ah_eu,ah_eu)*pow(Peu_us*(tax_eu_us+1.0),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw),-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw),-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw)),-(mu_us+mu_rw)/(mu_rw*(ah_eu-1.0))-1.0))/(mu_rw*(tax_eu_rw+1.0));
OUT [567] =-(pow(Peu_eu,-ah_eu)*pow(ah_eu,ah_eu)*(mu_us+mu_rw)*pow(Peu_us*(tax_eu_us+1.0),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw),-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw),-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw))*pow(Peu*pow(Peu_eu,-ah_eu)*pow(ah_eu,ah_eu)*pow(Peu_us*(tax_eu_us+1.0),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw),-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw),-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw)),-(mu_us+mu_rw)/(mu_rw*(ah_eu-1.0))-1.0))/(mu_rw*(ah_eu-1.0)*(tax_eu_rw+1.0));
OUT [608] =-(pow(Prw_rw,-ah_rw)*pow(ah_rw,ah_rw)*pow(Prw_eu*(tax_rw_eu+1.0),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Prw_us*(tax_rw_us+1.0),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*(mu_eu+mu_us+mu_rw)*pow(Prw*pow(Prw_rw,-ah_rw)*pow(ah_rw,ah_rw)*pow(Prw_eu*(tax_rw_eu+1.0),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Prw_us*(tax_rw_us+1.0),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)),-(mu_eu+mu_us+mu_rw)/(mu_rw*(ah_rw-1.0))-1.0))/(mu_rw*(ah_rw-1.0)*(tax_rw_row+1.0));
OUT [648] =-(Prw*pow(Prw_rw,-ah_rw)*pow(ah_rw,ah_rw)*mu_us*pow(Prw_eu*(tax_rw_eu+1.0),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Prw_us*(tax_rw_us+1.0),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)-1.0)*(tax_rw_us+1.0)*pow(-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Prw*pow(Prw_rw,-ah_rw)*pow(ah_rw,ah_rw)*pow(Prw_eu*(tax_rw_eu+1.0),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Prw_us*(tax_rw_us+1.0),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)),-(mu_eu+mu_us+mu_rw)/(mu_rw*(ah_rw-1.0))-1.0))/(mu_rw*(tax_rw_row+1.0));
OUT [688] =-(Prw*pow(Prw_rw,-ah_rw)*pow(ah_rw,ah_rw)*mu_eu*pow(Prw_eu*(tax_rw_eu+1.0),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)-1.0)*pow(Prw_us*(tax_rw_us+1.0),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*(tax_rw_eu+1.0)*pow(-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Prw*pow(Prw_rw,-ah_rw)*pow(ah_rw,ah_rw)*pow(Prw_eu*(tax_rw_eu+1.0),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Prw_us*(tax_rw_us+1.0),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)),-(mu_eu+mu_us+mu_rw)/(mu_rw*(ah_rw-1.0))-1.0))/(mu_rw*(tax_rw_row+1.0));
OUT [731] =-(Bus_usda*Pus_us*Qusd*Xus*upp_usd*pow(Xus*m_us,1.0/vepsf-1.0)*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf-1.0))/mu_us;
OUT [732] =-(Peu_eu*Qeur*upp_eur*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf-1.0)*pow(-m_us*(Xus-1.0),1.0/vepsf-1.0)*(Xus-1.0)*(-Beur+Beu_eura+Brw_eura))/mu_us;
OUT [737] =Xus*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf)-pow(Xus,2)*m_us*upp_usd*pow(Xus*m_us,1.0/vepsf-1.0)*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf-1.0);
OUT [738] =-upp_eur*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf)*(Xus-1.0)-m_us*upp_eur*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf-1.0)*pow(-m_us*(Xus-1.0),1.0/vepsf-1.0)*pow(Xus-1.0,2);
OUT [743] =mu_us*((Bus_usda*Pus_us*Qusd*Xus*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf))/mu_us+(Peu_eu*Qeur*upp_eur*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf)*(Xus-1.0)*(-Beur+Beu_eura+Brw_eura))/mu_us)-m_us*mu_us*((Bus_usda*Pus_us*Qusd*pow(Xus,2)*upp_usd*pow(Xus*m_us,1.0/vepsf-1.0)*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf-1.0))/mu_us-(Peu_eu*Qeur*upp_eur*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf-1.0)*pow(-m_us*(Xus-1.0),1.0/vepsf-1.0)*pow(Xus-1.0,2)*(-Beur+Beu_eura+Brw_eura))/mu_us);
OUT [773] =(Pus_us*Qusd*Xeu*upp_usd*pow(Xeu*m_eu,1.0/vepsf-1.0)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf-1.0)*(Brw_usda-Busd+Bus_usda))/mu_eu;
OUT [774] =(Beu_eura*Peu_eu*Qeur*upp_eur*pow(-m_eu*(Xeu-1.0),1.0/vepsf-1.0)*(Xeu-1.0)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf-1.0))/mu_eu;
OUT [779] =Xeu*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf)-pow(Xeu,2)*m_eu*upp_usd*pow(Xeu*m_eu,1.0/vepsf-1.0)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf-1.0);
OUT [780] =-upp_eur*(Xeu-1.0)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf)-m_eu*upp_eur*pow(-m_eu*(Xeu-1.0),1.0/vepsf-1.0)*pow(Xeu-1.0,2)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf-1.0);
OUT [784] =-mu_eu*((Pus_us*Qusd*Xeu*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf)*(Brw_usda-Busd+Bus_usda))/mu_eu+(Beu_eura*Peu_eu*Qeur*upp_eur*(Xeu-1.0)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf))/mu_eu)-m_eu*mu_eu*((Beu_eura*Peu_eu*Qeur*upp_eur*pow(-m_eu*(Xeu-1.0),1.0/vepsf-1.0)*pow(Xeu-1.0,2)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf-1.0))/mu_eu-(Pus_us*Qusd*pow(Xeu,2)*upp_usd*pow(Xeu*m_eu,1.0/vepsf-1.0)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf-1.0)*(Brw_usda-Busd+Bus_usda))/mu_eu);
OUT [815] =-(Brw_usda*Pus_us*Qusd*upp_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf-1.0)*pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf-1.0))/mu_rw;
OUT [816] =-(Brw_eura*Peu_eu*Qeur*upp_eur*pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf-1.0)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf-1.0)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0))/mu_rw;
OUT [821] =upp_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf)-m_rw*upp_usd*pow(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0,2)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf-1.0)*pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf-1.0);
OUT [822] =upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)-m_rw*upp_eur*pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf-1.0)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf-1.0)*pow(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0,2);
OUT [825] =mu_rw*((Brw_eura*Peu_eu*Qeur*upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0))/mu_rw+(Brw_usda*Pus_us*Qusd*upp_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf))/mu_rw)-m_rw*mu_rw*((Brw_usda*Pus_us*Qusd*upp_usd*pow(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0,2)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf-1.0)*pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf-1.0))/mu_rw+(Brw_eura*Peu_eu*Qeur*upp_eur*pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf-1.0)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf-1.0)*pow(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0,2))/mu_rw);
OUT [866] =-exp(pim_us_eu_*2.0)*1.0/pow(exp(pim_us_eu_)+1.0,2)+exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0);
OUT [867] =(exp(pim_us_rw_)*(exp(pim_us_eu_*2.0)*1.0/pow(exp(pim_us_eu_)+1.0,2)-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)))/(exp(pim_us_rw_)+1.0);
OUT [868] =-(exp(pex_us_eu_)*(-exp(pim_us_eu_*2.0)*1.0/pow(exp(pim_us_eu_)+1.0,2)+exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)+(exp(pim_us_rw_)*(exp(pim_us_eu_*2.0)*1.0/pow(exp(pim_us_eu_)+1.0,2)-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)))/(exp(pim_us_rw_)+1.0)))/(exp(pex_us_eu_)+1.0);
OUT [869] =exp(pim_us_eu_*2.0)*1.0/pow(exp(pim_us_eu_)+1.0,2)-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-(exp(pim_us_rw_)*(exp(pim_us_eu_*2.0)*1.0/pow(exp(pim_us_eu_)+1.0,2)-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)))/(exp(pim_us_rw_)+1.0)+(exp(pex_us_eu_)*(-exp(pim_us_eu_*2.0)*1.0/pow(exp(pim_us_eu_)+1.0,2)+exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)+(exp(pim_us_rw_)*(exp(pim_us_eu_*2.0)*1.0/pow(exp(pim_us_eu_)+1.0,2)-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)))/(exp(pim_us_rw_)+1.0)))/(exp(pex_us_eu_)+1.0);
OUT [907] =exp(pim_us_rw_*2.0)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0)*1.0/pow(exp(pim_us_rw_)+1.0,2)-(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0);
OUT [908] =-(exp(pex_us_eu_)*(exp(pim_us_rw_*2.0)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0)*1.0/pow(exp(pim_us_rw_)+1.0,2)-(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0)))/(exp(pex_us_eu_)+1.0);
OUT [909] =-exp(pim_us_rw_*2.0)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0)*1.0/pow(exp(pim_us_rw_)+1.0,2)+(exp(pex_us_eu_)*(exp(pim_us_rw_*2.0)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0)*1.0/pow(exp(pim_us_rw_)+1.0,2)-(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0)))/(exp(pex_us_eu_)+1.0)+(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0);
OUT [948] =-exp(pex_us_eu_*2.0)*1.0/pow(exp(pex_us_eu_)+1.0,2)*(-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)+(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0)+1.0)+(exp(pex_us_eu_)*(-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)+(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0)+1.0))/(exp(pex_us_eu_)+1.0);
OUT [949] =exp(pex_us_eu_*2.0)*1.0/pow(exp(pex_us_eu_)+1.0,2)*(-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)+(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0)+1.0)-(exp(pex_us_eu_)*(-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)+(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0)+1.0))/(exp(pex_us_eu_)+1.0);
OUT [990] =-exp(pim_eu_us_*2.0)*1.0/pow(exp(pim_eu_us_)+1.0,2)+exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0);
OUT [991] =(exp(pim_eu_rw_)*(exp(pim_eu_us_*2.0)*1.0/pow(exp(pim_eu_us_)+1.0,2)-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)))/(exp(pim_eu_rw_)+1.0);
OUT [992] =-(exp(pex_eu_us_)*(-exp(pim_eu_us_*2.0)*1.0/pow(exp(pim_eu_us_)+1.0,2)+exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)+(exp(pim_eu_rw_)*(exp(pim_eu_us_*2.0)*1.0/pow(exp(pim_eu_us_)+1.0,2)-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)))/(exp(pim_eu_rw_)+1.0)))/(exp(pex_eu_us_)+1.0);
OUT [993] =exp(pim_eu_us_*2.0)*1.0/pow(exp(pim_eu_us_)+1.0,2)-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-(exp(pim_eu_rw_)*(exp(pim_eu_us_*2.0)*1.0/pow(exp(pim_eu_us_)+1.0,2)-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)))/(exp(pim_eu_rw_)+1.0)+(exp(pex_eu_us_)*(-exp(pim_eu_us_*2.0)*1.0/pow(exp(pim_eu_us_)+1.0,2)+exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)+(exp(pim_eu_rw_)*(exp(pim_eu_us_*2.0)*1.0/pow(exp(pim_eu_us_)+1.0,2)-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)))/(exp(pim_eu_rw_)+1.0)))/(exp(pex_eu_us_)+1.0);
OUT [1031] =exp(pim_eu_rw_*2.0)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0)*1.0/pow(exp(pim_eu_rw_)+1.0,2)-(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0);
OUT [1032] =-(exp(pex_eu_us_)*(exp(pim_eu_rw_*2.0)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0)*1.0/pow(exp(pim_eu_rw_)+1.0,2)-(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0)))/(exp(pex_eu_us_)+1.0);
OUT [1033] =-exp(pim_eu_rw_*2.0)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0)*1.0/pow(exp(pim_eu_rw_)+1.0,2)+(exp(pex_eu_us_)*(exp(pim_eu_rw_*2.0)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0)*1.0/pow(exp(pim_eu_rw_)+1.0,2)-(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0)))/(exp(pex_eu_us_)+1.0)+(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0);
OUT [1072] =-exp(pex_eu_us_*2.0)*1.0/pow(exp(pex_eu_us_)+1.0,2)*(-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)+(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0)+1.0)+(exp(pex_eu_us_)*(-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)+(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0)+1.0))/(exp(pex_eu_us_)+1.0);
OUT [1073] =exp(pex_eu_us_*2.0)*1.0/pow(exp(pex_eu_us_)+1.0,2)*(-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)+(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0)+1.0)-(exp(pex_eu_us_)*(-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)+(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0)+1.0))/(exp(pex_eu_us_)+1.0);
OUT [1114] =-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0);
OUT [1115] =(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0);
OUT [1116] =-(exp(pim_rw_row_)*(-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0);
OUT [1117] =(exp(pex_rw_us_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)))/(exp(pex_rw_us_)+1.0);
OUT [1118] =-(exp(pex_rw_eu_)*(-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)))/(exp(pex_rw_us_)+1.0)))/(exp(pex_rw_eu_)+1.0);
OUT [1119] =exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)-(exp(pex_rw_us_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)))/(exp(pex_rw_us_)+1.0)+(exp(pex_rw_eu_)*(-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)))/(exp(pex_rw_us_)+1.0)))/(exp(pex_rw_eu_)+1.0);
OUT [1155] =exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0);
OUT [1156] =-(exp(pim_rw_row_)*(exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0);
OUT [1157] =(exp(pex_rw_us_)*(-exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)+(exp(pim_rw_row_)*(exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pex_rw_us_)+1.0);
OUT [1158] =-(exp(pex_rw_eu_)*(exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_row_)*(exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)+(exp(pex_rw_us_)*(-exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)+(exp(pim_rw_row_)*(exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pex_rw_us_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pex_rw_eu_)+1.0);
OUT [1159] =-exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)+(exp(pim_rw_row_)*(exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)+(exp(pex_rw_eu_)*(exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_row_)*(exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)+(exp(pex_rw_us_)*(-exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)+(exp(pim_rw_row_)*(exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pex_rw_us_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pex_rw_eu_)+1.0)-(exp(pex_rw_us_)*(-exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)+(exp(pim_rw_row_)*(exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pex_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0);
OUT [1196] =-exp(pim_rw_row_*2.0)*1.0/pow(exp(pim_rw_row_)+1.0,2)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0);
OUT [1197] =(exp(pex_rw_us_)*(exp(pim_rw_row_*2.0)*1.0/pow(exp(pim_rw_row_)+1.0,2)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)))/(exp(pex_rw_us_)+1.0);
OUT [1198] =-(exp(pex_rw_eu_)*(-exp(pim_rw_row_*2.0)*1.0/pow(exp(pim_rw_row_)+1.0,2)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_row_*2.0)*1.0/pow(exp(pim_rw_row_)+1.0,2)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)))/(exp(pex_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)))/(exp(pex_rw_eu_)+1.0);
OUT [1199] =exp(pim_rw_row_*2.0)*1.0/pow(exp(pim_rw_row_)+1.0,2)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0)-(exp(pex_rw_us_)*(exp(pim_rw_row_*2.0)*1.0/pow(exp(pim_rw_row_)+1.0,2)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)))/(exp(pex_rw_us_)+1.0)+(exp(pex_rw_eu_)*(-exp(pim_rw_row_*2.0)*1.0/pow(exp(pim_rw_row_)+1.0,2)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_row_*2.0)*1.0/pow(exp(pim_rw_row_)+1.0,2)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)))/(exp(pex_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)))/(exp(pex_rw_eu_)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0);
OUT [1237] =exp(pex_rw_us_*2.0)*1.0/pow(exp(pex_rw_us_)+1.0,2)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0)-(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0);
OUT [1238] =-(exp(pex_rw_eu_)*(exp(pex_rw_us_*2.0)*1.0/pow(exp(pex_rw_us_)+1.0,2)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0)-(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0)))/(exp(pex_rw_eu_)+1.0);
OUT [1239] =(exp(pex_rw_eu_)*(exp(pex_rw_us_*2.0)*1.0/pow(exp(pex_rw_us_)+1.0,2)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0)-(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0)))/(exp(pex_rw_eu_)+1.0)-exp(pex_rw_us_*2.0)*1.0/pow(exp(pex_rw_us_)+1.0,2)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0)+(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0);
OUT [1278] =(exp(pex_rw_eu_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pex_rw_eu_)+1.0)-exp(pex_rw_eu_*2.0)*1.0/pow(exp(pex_rw_eu_)+1.0,2)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0);
OUT [1279] =-(exp(pex_rw_eu_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pex_rw_eu_)+1.0)+exp(pex_rw_eu_*2.0)*1.0/pow(exp(pex_rw_eu_)+1.0,2)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0);
OUT [1335] =(sqrt(2.0)*Brw_usda*Pus_us*Qusd*m_rw*upp_usd*1.0/sqrt(pi)*exp(pow(sbar_rw,2)*(-1.0/2.0))*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf-1.0)*(z*2.0-1.0)*pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf-1.0)*(-1.0/2.0))/mu_rw;
OUT [1336] =(sqrt(2.0)*Brw_eura*Peu_eu*Qeur*m_rw*upp_eur*1.0/sqrt(pi)*exp(pow(sbar_rw,2)*(-1.0/2.0))*pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf-1.0)*(z*2.0-1.0)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf-1.0))/(mu_rw*2.0);
OUT [1341] =(sqrt(2.0)*m_rw*upp_usd*1.0/sqrt(pi)*exp(pow(sbar_rw,2)*(-1.0/2.0))*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf)*(z*2.0-1.0))/2.0-(sqrt(2.0)*pow(m_rw,2)*upp_usd*1.0/sqrt(pi)*exp(pow(sbar_rw,2)*(-1.0/2.0))*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf-1.0)*(z*2.0-1.0)*pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf-1.0))/2.0;
OUT [1342] =sqrt(2.0)*m_rw*upp_eur*1.0/sqrt(pi)*exp(pow(sbar_rw,2)*(-1.0/2.0))*(z*2.0-1.0)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf)*(-1.0/2.0)+(sqrt(2.0)*pow(m_rw,2)*upp_eur*1.0/sqrt(pi)*exp(pow(sbar_rw,2)*(-1.0/2.0))*pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf-1.0)*(z*2.0-1.0)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf-1.0)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0))/2.0;
OUT [1345] =-m_rw*mu_rw*((sqrt(2.0)*Brw_eura*Peu_eu*Qeur*upp_eur*1.0/sqrt(pi)*exp(pow(sbar_rw,2)*(-1.0/2.0))*(z*2.0-1.0)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf))/(mu_rw*2.0)-(sqrt(2.0)*Brw_usda*Pus_us*Qusd*upp_usd*1.0/sqrt(pi)*exp(pow(sbar_rw,2)*(-1.0/2.0))*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf)*(z*2.0-1.0))/(mu_rw*2.0)+(sqrt(2.0)*Brw_usda*Pus_us*Qusd*m_rw*upp_usd*1.0/sqrt(pi)*exp(pow(sbar_rw,2)*(-1.0/2.0))*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf-1.0)*(z*2.0-1.0)*pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf-1.0))/(mu_rw*2.0)-(sqrt(2.0)*Brw_eura*Peu_eu*Qeur*m_rw*upp_eur*1.0/sqrt(pi)*exp(pow(sbar_rw,2)*(-1.0/2.0))*pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf-1.0)*(z*2.0-1.0)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf-1.0)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0))/(mu_rw*2.0));
OUT [1369] =-1.0/mu_eu;
OUT [1373] =-(Pus_us*Qusd*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf))/mu_eu-pow(Pus_us,2)*pow(Qusd,2)*1.0/pow(mu_eu,2)*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf-1.0)*(Brw_usda-Busd+Bus_usda)*pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf-1.0);
OUT [1375] =(Pus_us*Qusd*upp_usd*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf))/mu_rw-Brw_usda*pow(Pus_us,2)*pow(Qusd,2)*1.0/pow(mu_rw,2)*pow(upp_usd,2)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf-1.0)*pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf-1.0);
OUT [1379] =(Pus_us*Qusd*Xeu*m_eu*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf-1.0)*pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf-1.0))/mu_eu;
OUT [1381] =-(Pus_us*Qusd*m_rw*pow(upp_usd,2)*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf-1.0)*pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf-1.0))/mu_rw;
OUT [1384] =-m_eu*mu_eu*((Pus_us*Qusd*Xeu*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf))/mu_eu+pow(Pus_us,2)*pow(Qusd,2)*Xeu*1.0/pow(mu_eu,2)*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf-1.0)*(Brw_usda-Busd+Bus_usda)*pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf-1.0));
OUT [1385] =m_rw*mu_rw*((Pus_us*Qusd*upp_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf))/mu_rw-Brw_usda*pow(Pus_us,2)*pow(Qusd,2)*1.0/pow(mu_rw,2)*pow(upp_usd,2)*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf-1.0)*pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf-1.0));
OUT [1410] =-1.0/mu_us;
OUT [1412] =-(Peu_eu*Qeur*upp_eur*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf))/mu_us-pow(Peu_eu,2)*pow(Qeur,2)*1.0/pow(mu_us,2)*pow(upp_eur,2)*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf-1.0)*(-Beur+Beu_eura+Brw_eura)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf-1.0);
OUT [1416] =(Peu_eu*Qeur*upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf))/mu_rw-Brw_eura*pow(Peu_eu,2)*pow(Qeur,2)*1.0/pow(mu_rw,2)*pow(upp_eur,2)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf-1.0)*pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf-1.0);
OUT [1418] =-(Peu_eu*Qeur*m_us*pow(upp_eur,2)*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf-1.0)*(Xus-1.0)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf-1.0))/mu_us;
OUT [1422] =-(Peu_eu*Qeur*m_rw*pow(upp_eur,2)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf-1.0)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)*pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf-1.0))/mu_rw;
OUT [1423] =m_us*mu_us*((Peu_eu*Qeur*upp_eur*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf)*(Xus-1.0))/mu_us+pow(Peu_eu,2)*pow(Qeur,2)*1.0/pow(mu_us,2)*pow(upp_eur,2)*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf-1.0)*(Xus-1.0)*(-Beur+Beu_eura+Brw_eura)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf-1.0));
OUT [1425] =m_rw*mu_rw*((Peu_eu*Qeur*upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0))/mu_rw-Brw_eura*pow(Peu_eu,2)*pow(Qeur,2)*1.0/pow(mu_rw,2)*pow(upp_eur,2)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf-1.0)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)*pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf-1.0));
OUT [1449] =-1.0/mu_eu;
OUT [1451] =(Pus_us*Qusd*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf))/mu_us-Bus_usda*pow(Pus_us,2)*pow(Qusd,2)*1.0/pow(mu_us,2)*pow(upp_usd,2)*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf-1.0)*pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf-1.0);
OUT [1453] =-(Pus_us*Qusd*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf))/mu_eu-pow(Pus_us,2)*pow(Qusd,2)*1.0/pow(mu_eu,2)*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf-1.0)*(Brw_usda-Busd+Bus_usda)*pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf-1.0);
OUT [1457] =-(Pus_us*Qusd*Xus*m_us*pow(upp_usd,2)*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf-1.0)*pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf-1.0))/mu_us;
OUT [1459] =(Pus_us*Qusd*Xeu*m_eu*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf-1.0)*pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf-1.0))/mu_eu;
OUT [1463] =m_us*mu_us*((Pus_us*Qusd*Xus*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf))/mu_us-Bus_usda*pow(Pus_us,2)*pow(Qusd,2)*Xus*1.0/pow(mu_us,2)*pow(upp_usd,2)*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf-1.0)*pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf-1.0));
OUT [1464] =-m_eu*mu_eu*((Pus_us*Qusd*Xeu*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf))/mu_eu+pow(Pus_us,2)*pow(Qusd,2)*Xeu*1.0/pow(mu_eu,2)*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf-1.0)*(Brw_usda-Busd+Bus_usda)*pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf-1.0));
OUT [1490] =-1.0/mu_us;
OUT [1492] =-(Peu_eu*Qeur*upp_eur*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf))/mu_us-pow(Peu_eu,2)*pow(Qeur,2)*1.0/pow(mu_us,2)*pow(upp_eur,2)*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf-1.0)*(-Beur+Beu_eura+Brw_eura)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf-1.0);
OUT [1494] =(Peu_eu*Qeur*upp_eur*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf))/mu_eu-Beu_eura*pow(Peu_eu,2)*pow(Qeur,2)*1.0/pow(mu_eu,2)*pow(upp_eur,2)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf-1.0)*pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf-1.0);
OUT [1498] =-(Peu_eu*Qeur*m_us*pow(upp_eur,2)*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf-1.0)*(Xus-1.0)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf-1.0))/mu_us;
OUT [1500] =(Peu_eu*Qeur*m_eu*pow(upp_eur,2)*(Xeu-1.0)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf-1.0)*pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf-1.0))/mu_eu;
OUT [1503] =m_us*mu_us*((Peu_eu*Qeur*upp_eur*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf)*(Xus-1.0))/mu_us+pow(Peu_eu,2)*pow(Qeur,2)*1.0/pow(mu_us,2)*pow(upp_eur,2)*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf-1.0)*(Xus-1.0)*(-Beur+Beu_eura+Brw_eura)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf-1.0));
OUT [1504] =-m_eu*mu_eu*((Peu_eu*Qeur*upp_eur*(Xeu-1.0)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf))/mu_eu-Beu_eura*pow(Peu_eu,2)*pow(Qeur,2)*1.0/pow(mu_eu,2)*pow(upp_eur,2)*(Xeu-1.0)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf-1.0)*pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf-1.0));

                            
                  
}




