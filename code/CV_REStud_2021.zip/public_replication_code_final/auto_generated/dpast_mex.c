

#include <math.h>
#include <mex.h>
#include <lapack.h>
#include <blas.h>
#include <stdlib.h>
#include <string.h>


/* Input Arguments */
#define Cus_eu_in	prhs[0]
#define Cus_rw_in	prhs[1]
#define Ceu_us_in	prhs[2]
#define Ceu_rw_in	prhs[3]
#define Crw_us_in	prhs[4]
#define Crw_eu_in	prhs[5]
#define Crw_row_in	prhs[6]
#define Qusd_in	prhs[7]
#define Qeur_in	prhs[8]
#define Pus_us_in	prhs[9]
#define Pus_eu_in	prhs[10]
#define Pus_in	prhs[11]
#define Peu_eu_in	prhs[12]
#define Peu_us_in	prhs[13]
#define Peu_in	prhs[14]
#define Prw_in	prhs[15]
#define Prw_us_in	prhs[16]
#define Prw_eu_in	prhs[17]
#define m_us_in	prhs[18]
#define m_eu_in	prhs[19]
#define m_rw_in	prhs[20]
#define pim_us_eu__in	prhs[21]
#define pim_us_rw__in	prhs[22]
#define pex_us_eu__in	prhs[23]
#define pim_eu_us__in	prhs[24]
#define pim_eu_rw__in	prhs[25]
#define pex_eu_us__in	prhs[26]
#define pim_rw_us__in	prhs[27]
#define pim_rw_eu__in	prhs[28]
#define pim_rw_row__in	prhs[29]
#define pex_rw_us__in	prhs[30]
#define pex_rw_eu__in	prhs[31]
#define Vusd_in	prhs[32]
#define sbar_rw_in	prhs[33]
#define Brw_usda_in	prhs[34]
#define Brw_eura_in	prhs[35]
#define Bus_usda_in	prhs[36]
#define Beu_eura_in	prhs[37]
#define Cus_eu_p_in	prhs[38]
#define Cus_rw_p_in	prhs[39]
#define Ceu_us_p_in	prhs[40]
#define Ceu_rw_p_in	prhs[41]
#define Crw_us_p_in	prhs[42]
#define Crw_eu_p_in	prhs[43]
#define Crw_row_p_in	prhs[44]
#define Qusd_p_in	prhs[45]
#define Qeur_p_in	prhs[46]
#define Pus_us_p_in	prhs[47]
#define Pus_eu_p_in	prhs[48]
#define Pus_p_in	prhs[49]
#define Peu_eu_p_in	prhs[50]
#define Peu_us_p_in	prhs[51]
#define Peu_p_in	prhs[52]
#define Prw_p_in	prhs[53]
#define Prw_us_p_in	prhs[54]
#define Prw_eu_p_in	prhs[55]
#define m_us_p_in	prhs[56]
#define m_eu_p_in	prhs[57]
#define m_rw_p_in	prhs[58]
#define pim_us_eu__p_in	prhs[59]
#define pim_us_rw__p_in	prhs[60]
#define pex_us_eu__p_in	prhs[61]
#define pim_eu_us__p_in	prhs[62]
#define pim_eu_rw__p_in	prhs[63]
#define pex_eu_us__p_in	prhs[64]
#define pim_rw_us__p_in	prhs[65]
#define pim_rw_eu__p_in	prhs[66]
#define pim_rw_row__p_in	prhs[67]
#define pex_rw_us__p_in	prhs[68]
#define pex_rw_eu__p_in	prhs[69]
#define Vusd_p_in	prhs[70]
#define sbar_rw_p_in	prhs[71]
#define Brw_usda_p_in	prhs[72]
#define Brw_eura_p_in	prhs[73]
#define Bus_usda_p_in	prhs[74]
#define Beu_eura_p_in	prhs[75]
#define Brw_usda_l_in	prhs[76]
#define Brw_eura_l_in	prhs[77]
#define Bus_usda_l_in	prhs[78]
#define Beu_eura_l_in	prhs[79]
#define Busd_in	prhs[80]
#define Beur_in	prhs[81]
#define Yus_in	prhs[82]
#define Yeu_in	prhs[83]
#define Yrw_in	prhs[84]
#define mu_us_in	prhs[85]
#define mu_eu_in	prhs[86]
#define mu_rw_in	prhs[87]
#define ah_us_in	prhs[88]
#define ah_eu_in	prhs[89]
#define ah_rw_in	prhs[90]
#define Busd_l_in	prhs[91]
#define Beur_l_in	prhs[92]
#define Yus_l_in	prhs[93]
#define Yeu_l_in	prhs[94]
#define Yrw_l_in	prhs[95]
#define mu_us_l_in	prhs[96]
#define mu_eu_l_in	prhs[97]
#define mu_rw_l_in	prhs[98]
#define ah_us_l_in	prhs[99]
#define ah_eu_l_in	prhs[100]
#define ah_rw_l_in	prhs[101]
#define Busd_p_in	prhs[102]
#define Beur_p_in	prhs[103]
#define Yus_p_in	prhs[104]
#define Yeu_p_in	prhs[105]
#define Yrw_p_in	prhs[106]
#define mu_us_p_in	prhs[107]
#define mu_eu_p_in	prhs[108]
#define mu_rw_p_in	prhs[109]
#define ah_us_p_in	prhs[110]
#define ah_eu_p_in	prhs[111]
#define ah_rw_p_in	prhs[112]
#define tau_in	prhs[113]
#define taup_in	prhs[114]
#define alph_in	prhs[115]
#define vepsf_in	prhs[116]
#define vepst_in	prhs[117]
#define kap_in	prhs[118]
#define phi_in	prhs[119]
#define r_in	prhs[120]
#define sige_in	prhs[121]
#define phi_usg_in	prhs[122]
#define phi_eug_in	prhs[123]
#define phi_rwg_in	prhs[124]
#define bet_in	prhs[125]
#define sig_in	prhs[126]
#define eta_in	prhs[127]
#define Prw_rw_in	prhs[128]
#define Xus_in	prhs[129]
#define Xeu_in	prhs[130]
#define z_in	prhs[131]
#define upp_usd_in	prhs[132]
#define upp_eur_in	prhs[133]
#define per_p_year_in	prhs[134]
#define omg_in	prhs[135]
#define tax_us_eu_in	prhs[136]
#define tax_us_rw_in	prhs[137]
#define tax_eu_us_in	prhs[138]
#define tax_eu_rw_in	prhs[139]
#define tax_rw_us_in	prhs[140]
#define tax_rw_eu_in	prhs[141]
#define tax_rw_row_in	prhs[142]
#define dtax_us_eu_in	prhs[143]
#define dtax_us_rw_in	prhs[144]
#define dtax_eu_us_in	prhs[145]
#define dtax_eu_rw_in	prhs[146]
#define dtax_rw_us_in	prhs[147]
#define dtax_rw_eu_in	prhs[148]
#define dtax_rw_row_in	prhs[149]
#define tax_us_in_in	prhs[150]
#define tax_us_out_in	prhs[151]
#define tax_eu_in_in	prhs[152]
#define tax_eu_out_in	prhs[153]
#define tax_rw_out_in	prhs[154]


/* Output Arguments */
#define out plhs[0]


#if !defined(MAX)
#define	MAX(A, B)	((A) > (B) ? (A) : (B))
#endif

#if !defined(MIN)
#define	MIN(A, B)	((A) < (B) ? (A) : (B))
#endif

#define pi  3.141592653589793
        
/* Prints an MxN matrix to Screen*/
void printmat_rowmaj(int m, int n, double M[m*n]){
    int x,y,k;
        k = 0;
    printf("\n");
    for(x=0;x<m;x++){
        for(y=0;y<n;y++){
            printf("%1.11lf\t", M[k]);
            k++;
        }
        printf("%\n");
    }
    return;
}


void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray*prhs[] )

{
     /*Values in Loops*/
    double C,H,D_p,K_p,MU,E1,E2,E3,D,K,HL,LAML,GAMtildeL,GAM,A,RW,MUtmp;
    
    double *OUT;
    
    /*variables needed to declare*/
    double Cus ,Ceu ,Crw ,Cus_us ,Ceu_eu ,Crw_rw ,Pus_rw ,Peu_rw ,Prw_row ,Beu_usd ,Bus_eur ,p_us_usd ,p_us_eur ,p_eu_usd ,p_eu_eur ,p_rw_usd ,p_rw_eur ,ph_us_usd ,ph_us_eur ,ph_eu_usd ,ph_eu_eur ,ph_rw_usd ,ph_rw_eur ,m_us_til ,m_eu_til ,m_rw_til ,pim_us_eu ,pim_us_rw ,pex_us_eu ,pex_us_rw ,pim_eu_us ,pim_eu_rw ,pex_eu_us ,pex_eu_rw ,pim_rw_us ,pim_rw_eu ,pim_rw_row ,pex_rw_us ,pex_rw_eu ,pex_rw_row ;

     double Cus_eu,Cus_rw,Ceu_us,Ceu_rw,Crw_us,Crw_eu,Crw_row,Qusd,Qeur,Pus_us,Pus_eu,Pus,Peu_eu,Peu_us,Peu,Prw,Prw_us,Prw_eu,m_us,m_eu,m_rw,pim_us_eu_,pim_us_rw_,pex_us_eu_,pim_eu_us_,pim_eu_rw_,pex_eu_us_,pim_rw_us_,pim_rw_eu_,pim_rw_row_,pex_rw_us_,pex_rw_eu_,Vusd,sbar_rw,Brw_usda,Brw_eura,Bus_usda,Beu_eura,Cus_eu_p,Cus_rw_p,Ceu_us_p,Ceu_rw_p,Crw_us_p,Crw_eu_p,Crw_row_p,Qusd_p,Qeur_p,Pus_us_p,Pus_eu_p,Pus_p,Peu_eu_p,Peu_us_p,Peu_p,Prw_p,Prw_us_p,Prw_eu_p,m_us_p,m_eu_p,m_rw_p,pim_us_eu__p,pim_us_rw__p,pex_us_eu__p,pim_eu_us__p,pim_eu_rw__p,pex_eu_us__p,pim_rw_us__p,pim_rw_eu__p,pim_rw_row__p,pex_rw_us__p,pex_rw_eu__p,Vusd_p,sbar_rw_p,Brw_usda_p,Brw_eura_p,Bus_usda_p,Beu_eura_p,Brw_usda_l,Brw_eura_l,Bus_usda_l,Beu_eura_l,Busd,Beur,Yus,Yeu,Yrw,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,Busd_l,Beur_l,Yus_l,Yeu_l,Yrw_l,mu_us_l,mu_eu_l,mu_rw_l,ah_us_l,ah_eu_l,ah_rw_l,Busd_p,Beur_p,Yus_p,Yeu_p,Yrw_p,mu_us_p,mu_eu_p,mu_rw_p,ah_us_p,ah_eu_p,ah_rw_p,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out;

            
    /*Results*/
    double rsum=1;
    
    /*Create output argument*/
    out = mxCreateDoubleMatrix(38,4,mxREAL);

    OUT = mxGetPr(out);
    
    
    /*Counters*/
    long ns, ii,tt;
    
    /*BLAS working memory*/
    ptrdiff_t one = 1;
    ptrdiff_t info = 0;
    long IPIV[4] = {0,1,2,3};

    
    /*Check for proper number of arguments*/
    if (nrhs == 155)  {} else{mexErrMsgTxt(" 155 inputs arguments required.");}

    
    /* Get Dimensions of Input Arguments*/
    ptrdiff_t four  = 4;
    ptrdiff_t three = 3;
         
    /*Parameters intialized*/
    Cus_eu= *mxGetPr(Cus_eu_in);
Cus_rw= *mxGetPr(Cus_rw_in);
Ceu_us= *mxGetPr(Ceu_us_in);
Ceu_rw= *mxGetPr(Ceu_rw_in);
Crw_us= *mxGetPr(Crw_us_in);
Crw_eu= *mxGetPr(Crw_eu_in);
Crw_row= *mxGetPr(Crw_row_in);
Qusd= *mxGetPr(Qusd_in);
Qeur= *mxGetPr(Qeur_in);
Pus_us= *mxGetPr(Pus_us_in);
Pus_eu= *mxGetPr(Pus_eu_in);
Pus= *mxGetPr(Pus_in);
Peu_eu= *mxGetPr(Peu_eu_in);
Peu_us= *mxGetPr(Peu_us_in);
Peu= *mxGetPr(Peu_in);
Prw= *mxGetPr(Prw_in);
Prw_us= *mxGetPr(Prw_us_in);
Prw_eu= *mxGetPr(Prw_eu_in);
m_us= *mxGetPr(m_us_in);
m_eu= *mxGetPr(m_eu_in);
m_rw= *mxGetPr(m_rw_in);
pim_us_eu_= *mxGetPr(pim_us_eu__in);
pim_us_rw_= *mxGetPr(pim_us_rw__in);
pex_us_eu_= *mxGetPr(pex_us_eu__in);
pim_eu_us_= *mxGetPr(pim_eu_us__in);
pim_eu_rw_= *mxGetPr(pim_eu_rw__in);
pex_eu_us_= *mxGetPr(pex_eu_us__in);
pim_rw_us_= *mxGetPr(pim_rw_us__in);
pim_rw_eu_= *mxGetPr(pim_rw_eu__in);
pim_rw_row_= *mxGetPr(pim_rw_row__in);
pex_rw_us_= *mxGetPr(pex_rw_us__in);
pex_rw_eu_= *mxGetPr(pex_rw_eu__in);
Vusd= *mxGetPr(Vusd_in);
sbar_rw= *mxGetPr(sbar_rw_in);
Brw_usda= *mxGetPr(Brw_usda_in);
Brw_eura= *mxGetPr(Brw_eura_in);
Bus_usda= *mxGetPr(Bus_usda_in);
Beu_eura= *mxGetPr(Beu_eura_in);
Cus_eu_p= *mxGetPr(Cus_eu_p_in);
Cus_rw_p= *mxGetPr(Cus_rw_p_in);
Ceu_us_p= *mxGetPr(Ceu_us_p_in);
Ceu_rw_p= *mxGetPr(Ceu_rw_p_in);
Crw_us_p= *mxGetPr(Crw_us_p_in);
Crw_eu_p= *mxGetPr(Crw_eu_p_in);
Crw_row_p= *mxGetPr(Crw_row_p_in);
Qusd_p= *mxGetPr(Qusd_p_in);
Qeur_p= *mxGetPr(Qeur_p_in);
Pus_us_p= *mxGetPr(Pus_us_p_in);
Pus_eu_p= *mxGetPr(Pus_eu_p_in);
Pus_p= *mxGetPr(Pus_p_in);
Peu_eu_p= *mxGetPr(Peu_eu_p_in);
Peu_us_p= *mxGetPr(Peu_us_p_in);
Peu_p= *mxGetPr(Peu_p_in);
Prw_p= *mxGetPr(Prw_p_in);
Prw_us_p= *mxGetPr(Prw_us_p_in);
Prw_eu_p= *mxGetPr(Prw_eu_p_in);
m_us_p= *mxGetPr(m_us_p_in);
m_eu_p= *mxGetPr(m_eu_p_in);
m_rw_p= *mxGetPr(m_rw_p_in);
pim_us_eu__p= *mxGetPr(pim_us_eu__p_in);
pim_us_rw__p= *mxGetPr(pim_us_rw__p_in);
pex_us_eu__p= *mxGetPr(pex_us_eu__p_in);
pim_eu_us__p= *mxGetPr(pim_eu_us__p_in);
pim_eu_rw__p= *mxGetPr(pim_eu_rw__p_in);
pex_eu_us__p= *mxGetPr(pex_eu_us__p_in);
pim_rw_us__p= *mxGetPr(pim_rw_us__p_in);
pim_rw_eu__p= *mxGetPr(pim_rw_eu__p_in);
pim_rw_row__p= *mxGetPr(pim_rw_row__p_in);
pex_rw_us__p= *mxGetPr(pex_rw_us__p_in);
pex_rw_eu__p= *mxGetPr(pex_rw_eu__p_in);
Vusd_p= *mxGetPr(Vusd_p_in);
sbar_rw_p= *mxGetPr(sbar_rw_p_in);
Brw_usda_p= *mxGetPr(Brw_usda_p_in);
Brw_eura_p= *mxGetPr(Brw_eura_p_in);
Bus_usda_p= *mxGetPr(Bus_usda_p_in);
Beu_eura_p= *mxGetPr(Beu_eura_p_in);
Brw_usda_l= *mxGetPr(Brw_usda_l_in);
Brw_eura_l= *mxGetPr(Brw_eura_l_in);
Bus_usda_l= *mxGetPr(Bus_usda_l_in);
Beu_eura_l= *mxGetPr(Beu_eura_l_in);
Busd= *mxGetPr(Busd_in);
Beur= *mxGetPr(Beur_in);
Yus= *mxGetPr(Yus_in);
Yeu= *mxGetPr(Yeu_in);
Yrw= *mxGetPr(Yrw_in);
mu_us= *mxGetPr(mu_us_in);
mu_eu= *mxGetPr(mu_eu_in);
mu_rw= *mxGetPr(mu_rw_in);
ah_us= *mxGetPr(ah_us_in);
ah_eu= *mxGetPr(ah_eu_in);
ah_rw= *mxGetPr(ah_rw_in);
Busd_l= *mxGetPr(Busd_l_in);
Beur_l= *mxGetPr(Beur_l_in);
Yus_l= *mxGetPr(Yus_l_in);
Yeu_l= *mxGetPr(Yeu_l_in);
Yrw_l= *mxGetPr(Yrw_l_in);
mu_us_l= *mxGetPr(mu_us_l_in);
mu_eu_l= *mxGetPr(mu_eu_l_in);
mu_rw_l= *mxGetPr(mu_rw_l_in);
ah_us_l= *mxGetPr(ah_us_l_in);
ah_eu_l= *mxGetPr(ah_eu_l_in);
ah_rw_l= *mxGetPr(ah_rw_l_in);
Busd_p= *mxGetPr(Busd_p_in);
Beur_p= *mxGetPr(Beur_p_in);
Yus_p= *mxGetPr(Yus_p_in);
Yeu_p= *mxGetPr(Yeu_p_in);
Yrw_p= *mxGetPr(Yrw_p_in);
mu_us_p= *mxGetPr(mu_us_p_in);
mu_eu_p= *mxGetPr(mu_eu_p_in);
mu_rw_p= *mxGetPr(mu_rw_p_in);
ah_us_p= *mxGetPr(ah_us_p_in);
ah_eu_p= *mxGetPr(ah_eu_p_in);
ah_rw_p= *mxGetPr(ah_rw_p_in);
tau= *mxGetPr(tau_in);
taup= *mxGetPr(taup_in);
alph= *mxGetPr(alph_in);
vepsf= *mxGetPr(vepsf_in);
vepst= *mxGetPr(vepst_in);
kap= *mxGetPr(kap_in);
phi= *mxGetPr(phi_in);
r= *mxGetPr(r_in);
sige= *mxGetPr(sige_in);
phi_usg= *mxGetPr(phi_usg_in);
phi_eug= *mxGetPr(phi_eug_in);
phi_rwg= *mxGetPr(phi_rwg_in);
bet= *mxGetPr(bet_in);
sig= *mxGetPr(sig_in);
eta= *mxGetPr(eta_in);
Prw_rw= *mxGetPr(Prw_rw_in);
Xus= *mxGetPr(Xus_in);
Xeu= *mxGetPr(Xeu_in);
z= *mxGetPr(z_in);
upp_usd= *mxGetPr(upp_usd_in);
upp_eur= *mxGetPr(upp_eur_in);
per_p_year= *mxGetPr(per_p_year_in);
omg= *mxGetPr(omg_in);
tax_us_eu= *mxGetPr(tax_us_eu_in);
tax_us_rw= *mxGetPr(tax_us_rw_in);
tax_eu_us= *mxGetPr(tax_eu_us_in);
tax_eu_rw= *mxGetPr(tax_eu_rw_in);
tax_rw_us= *mxGetPr(tax_rw_us_in);
tax_rw_eu= *mxGetPr(tax_rw_eu_in);
tax_rw_row= *mxGetPr(tax_rw_row_in);
dtax_us_eu= *mxGetPr(dtax_us_eu_in);
dtax_us_rw= *mxGetPr(dtax_us_rw_in);
dtax_eu_us= *mxGetPr(dtax_eu_us_in);
dtax_eu_rw= *mxGetPr(dtax_eu_rw_in);
dtax_rw_us= *mxGetPr(dtax_rw_us_in);
dtax_rw_eu= *mxGetPr(dtax_rw_eu_in);
dtax_rw_row= *mxGetPr(dtax_rw_row_in);
tax_us_in= *mxGetPr(tax_us_in_in);
tax_us_out= *mxGetPr(tax_us_out_in);
tax_eu_in= *mxGetPr(tax_eu_in_in);
tax_eu_out= *mxGetPr(tax_eu_out_in);
tax_rw_out= *mxGetPr(tax_rw_out_in);

            
            
    /*Declare MatlabFunction Terms*/
    
    Cus = pow(Cus_eu,-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(Cus_rw,-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(Ceu_us*mu_eu+Crw_us*mu_rw+Yus*mu_us*(phi_usg-1.0))/mu_us,ah_us);
Ceu = pow(Ceu_us,-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(Ceu_rw,-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(Crw_eu*mu_rw+Cus_eu*mu_us+Yeu*mu_eu*(phi_eug-1.0))/mu_eu,ah_eu);
Crw = pow(Crw_eu,-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_us,-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_row,-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(Ceu_rw*mu_eu+Cus_rw*mu_us-mu_rw*(Crw_row-Yrw)*(phi_rwg-1.0))/mu_rw,ah_rw);
Cus_us = -(Ceu_us*mu_eu+Crw_us*mu_rw+Yus*mu_us*(phi_usg-1.0))/mu_us;
Ceu_eu = -(Crw_eu*mu_rw+Cus_eu*mu_us+Yeu*mu_eu*(phi_eug-1.0))/mu_eu;
Crw_rw = -(Ceu_rw*mu_eu+Cus_rw*mu_us-mu_rw*(Crw_row-Yrw)*(phi_rwg-1.0))/mu_rw;
Pus_rw = pow(Pus*pow(Pus_us,-ah_us)*pow(ah_us,ah_us)*pow(Pus_eu*(tax_us_eu+1.0),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw),-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw),-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw)),-(mu_eu+mu_rw)/(mu_rw*(ah_us-1.0)))/(tax_us_rw+1.0);
Peu_rw = pow(Peu*pow(Peu_eu,-ah_eu)*pow(ah_eu,ah_eu)*pow(Peu_us*(tax_eu_us+1.0),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw),-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw),-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw)),-(mu_us+mu_rw)/(mu_rw*(ah_eu-1.0)))/(tax_eu_rw+1.0);
Prw_row = pow(Prw*pow(Prw_rw,-ah_rw)*pow(ah_rw,ah_rw)*pow(Prw_eu*(tax_rw_eu+1.0),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Prw_us*(tax_rw_us+1.0),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)),-(mu_eu+mu_us+mu_rw)/(mu_rw*(ah_rw-1.0)))/(tax_rw_row+1.0);
Beu_usd = -(Brw_usda-Busd+Bus_usda)/mu_eu;
Bus_eur = -(-Beur+Beu_eura+Brw_eura)/mu_us;
p_us_usd = (Bus_usda*Pus_us*Qusd*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf))/mu_us;
p_us_eur = -(Peu_eu*Qeur*upp_eur*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf)*(-Beur+Beu_eura+Brw_eura))/mu_us;
p_eu_usd = -(Pus_us*Qusd*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf)*(Brw_usda-Busd+Bus_usda))/mu_eu;
p_eu_eur = (Beu_eura*Peu_eu*Qeur*upp_eur*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf))/mu_eu;
p_rw_usd = (Brw_usda*Pus_us*Qusd*upp_usd*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf))/mu_rw;
p_rw_eur = (Brw_eura*Peu_eu*Qeur*upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf))/mu_rw;
ph_us_usd = Xus*m_us*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf);
ph_us_eur = -m_us*upp_eur*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf)*(Xus-1.0);
ph_eu_usd = Xeu*m_eu*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf);
ph_eu_eur = -m_eu*upp_eur*(Xeu-1.0)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf);
ph_rw_usd = m_rw*upp_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf);
ph_rw_eur = m_rw*upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0);
m_us_til = m_us*mu_us*((Bus_usda*Pus_us*Qusd*Xus*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf))/mu_us+(Peu_eu*Qeur*upp_eur*pow(pow(-m_us*(Xus-1.0),1.0/vepsf)+pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eura+Brw_eura))/mu_us,1.0/vepsf),-vepsf)*(Xus-1.0)*(-Beur+Beu_eura+Brw_eura))/mu_us);
m_eu_til = -m_eu*mu_eu*((Pus_us*Qusd*Xeu*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Brw_usda-Busd+Bus_usda))/mu_eu,1.0/vepsf),-vepsf)*(Brw_usda-Busd+Bus_usda))/mu_eu+(Beu_eura*Peu_eu*Qeur*upp_eur*(Xeu-1.0)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),-vepsf))/mu_eu);
m_rw_til = m_rw*mu_rw*((Brw_eura*Peu_eu*Qeur*upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),-vepsf)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0))/mu_rw+(Brw_usda*Pus_us*Qusd*upp_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),-vepsf))/mu_rw);
pim_us_eu = exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0);
pim_us_rw = -(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0);
pex_us_eu = (exp(pex_us_eu_)*(-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)+(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0)+1.0))/(exp(pex_us_eu_)+1.0);
pex_us_rw = -exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-(exp(pex_us_eu_)*(-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)+(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0)+1.0))/(exp(pex_us_eu_)+1.0)+(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0)+1.0;
pim_eu_us = exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0);
pim_eu_rw = -(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0);
pex_eu_us = (exp(pex_eu_us_)*(-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)+(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0)+1.0))/(exp(pex_eu_us_)+1.0);
pex_eu_rw = -exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-(exp(pex_eu_us_)*(-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)+(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0)+1.0))/(exp(pex_eu_us_)+1.0)+(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0)+1.0;
pim_rw_us = exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0);
pim_rw_eu = -(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0);
pim_rw_row = (exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0);
pex_rw_us = -(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0);
pex_rw_eu = (exp(pex_rw_eu_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pex_rw_eu_)+1.0);
pex_rw_row = -exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-(exp(pex_rw_eu_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pex_rw_eu_)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0;
        
            
    
                  
    /*Output argument*/
    OUT [4] =Pus*tax_us_in*(mu_eu/(mu_us*mu_eu_l)-mu_rw/(mu_us*mu_rw_l));
OUT [7] =-(Pus_us*(tax_us_in-1.0))/mu_eu_l;
OUT [34] =(Peu*Pus_us_p*bet*(tau/(Brw_usda_l-Busd_l+Bus_usda_l)+mu_eu_l*tau*((Brw_usda-Busd+Bus_usda)/mu_eu-(Brw_usda_l-Busd_l+Bus_usda_l)/mu_eu_l)*1.0/pow(Brw_usda_l-Busd_l+Bus_usda_l,2))*1.0/pow(-ph_eu_usd*r+(mu_eu_l*tau*((Brw_usda-Busd+Bus_usda)/mu_eu-(Brw_usda_l-Busd_l+Bus_usda_l)/mu_eu_l))/(Brw_usda_l-Busd_l+Bus_usda_l)+1.0,2)*(tax_us_in+tax_eu_out-Qusd_p*((pow(mu_eu,2)*taup*pow((Brw_usda-Busd+Bus_usda)/mu_eu-(Brw_usda_p-Busd_p+Bus_usda_p)/mu_eu_p,2)*1.0/pow(Brw_usda-Busd+Bus_usda,2))/2.0-(mu_eu*taup*((Brw_usda-Busd+Bus_usda)/mu_eu-(Brw_usda_p-Busd_p+Bus_usda_p)/mu_eu_p))/(Brw_usda-Busd+Bus_usda))-1.0)*pow((pow(Ceu_us_p,-(mu_us_p*(ah_eu_p-1.0))/(mu_us_p+mu_rw_p))*pow(Ceu_rw_p,-(mu_rw_p*(ah_eu_p-1.0))/(mu_us_p+mu_rw_p))*pow(-(Crw_eu_p*mu_rw_p+Cus_eu_p*mu_us_p+Yeu_p*mu_eu_p*(phi_eug-1.0))/mu_eu_p,ah_eu_p))/Ceu,-sig)*1.0e+2)/(Peu_p*Pus_us*Qusd);
OUT [36] =(Prw*Pus_us_p*bet*(tau/Brw_usda_l+1.0/pow(Brw_usda_l,2)*mu_rw_l*tau*(Brw_usda/mu_rw-Brw_usda_l/mu_rw_l))*1.0/pow(-ph_rw_usd*r+(mu_rw_l*tau*(Brw_usda/mu_rw-Brw_usda_l/mu_rw_l))/Brw_usda_l+1.0,2)*(tax_us_in+tax_rw_out+Qusd_p*((mu_rw*taup*(Brw_usda/mu_rw-Brw_usda_p/mu_rw_p))/Brw_usda-(1.0/pow(Brw_usda,2)*pow(mu_rw,2)*taup*pow(Brw_usda/mu_rw-Brw_usda_p/mu_rw_p,2))/2.0)-1.0)*pow((pow(Crw_eu_p,-(mu_eu_p*(ah_rw_p-1.0))/(mu_eu_p+mu_us_p+mu_rw_p))*pow(Crw_us_p,-(mu_us_p*(ah_rw_p-1.0))/(mu_eu_p+mu_us_p+mu_rw_p))*pow(Crw_row_p,-(mu_rw_p*(ah_rw_p-1.0))/(mu_eu_p+mu_us_p+mu_rw_p))*pow(-(Ceu_rw_p*mu_eu_p+Cus_rw_p*mu_us_p-mu_rw_p*(Crw_row_p-Yrw_p)*(phi_rwg-1.0))/mu_rw_p,ah_rw_p))/Crw,-sig)*1.0e+2)/(Prw_p*Pus_us*Qusd);
OUT [41] =(Peu_eu_p*Pus*bet*(tau/(-Beur_l+Beu_eura_l+Brw_eura_l)+mu_us_l*tau*((-Beur+Beu_eura+Brw_eura)/mu_us-(-Beur_l+Beu_eura_l+Brw_eura_l)/mu_us_l)*1.0/pow(-Beur_l+Beu_eura_l+Brw_eura_l,2))*1.0/pow(-ph_us_eur*r+(mu_us_l*tau*((-Beur+Beu_eura+Brw_eura)/mu_us-(-Beur_l+Beu_eura_l+Brw_eura_l)/mu_us_l))/(-Beur_l+Beu_eura_l+Brw_eura_l)+1.0,2)*(tax_eu_in+tax_us_out-Qeur_p*((pow(mu_us,2)*taup*pow((-Beur+Beu_eura+Brw_eura)/mu_us-(-Beur_p+Beu_eura_p+Brw_eura_p)/mu_us_p,2)*1.0/pow(-Beur+Beu_eura+Brw_eura,2))/2.0-(mu_us*taup*((-Beur+Beu_eura+Brw_eura)/mu_us-(-Beur_p+Beu_eura_p+Brw_eura_p)/mu_us_p))/(-Beur+Beu_eura+Brw_eura))-1.0)*pow((pow(Cus_eu_p,-(mu_eu_p*(ah_us_p-1.0))/(mu_eu_p+mu_rw_p))*pow(Cus_rw_p,-(mu_rw_p*(ah_us_p-1.0))/(mu_eu_p+mu_rw_p))*pow(-(Ceu_us_p*mu_eu_p+Crw_us_p*mu_rw_p+Yus_p*mu_us_p*(phi_usg-1.0))/mu_us_p,ah_us_p))/Cus,-sig)*1.0e+2)/(Peu_eu*Pus_p*Qeur);
OUT [42] =-(Peu_eu*(tax_eu_in-1.0))/mu_us_l;
OUT [45] =Peu*tax_eu_in*(mu_us/(mu_eu*mu_us_l)-mu_rw/(mu_eu*mu_rw_l));
OUT [75] =(Peu_eu_p*Prw*bet*(tau/Brw_eura_l+1.0/pow(Brw_eura_l,2)*mu_rw_l*tau*(Brw_eura/mu_rw-Brw_eura_l/mu_rw_l))*1.0/pow(-ph_rw_eur*r+(mu_rw_l*tau*(Brw_eura/mu_rw-Brw_eura_l/mu_rw_l))/Brw_eura_l+1.0,2)*(tax_eu_in+tax_rw_out+Qeur_p*((mu_rw*taup*(Brw_eura/mu_rw-Brw_eura_p/mu_rw_p))/Brw_eura-(1.0/pow(Brw_eura,2)*pow(mu_rw,2)*taup*pow(Brw_eura/mu_rw-Brw_eura_p/mu_rw_p,2))/2.0)-1.0)*pow((pow(Crw_eu_p,-(mu_eu_p*(ah_rw_p-1.0))/(mu_eu_p+mu_us_p+mu_rw_p))*pow(Crw_us_p,-(mu_us_p*(ah_rw_p-1.0))/(mu_eu_p+mu_us_p+mu_rw_p))*pow(Crw_row_p,-(mu_rw_p*(ah_rw_p-1.0))/(mu_eu_p+mu_us_p+mu_rw_p))*pow(-(Ceu_rw_p*mu_eu_p+Cus_rw_p*mu_us_p-mu_rw_p*(Crw_row_p-Yrw_p)*(phi_rwg-1.0))/mu_rw_p,ah_rw_p))/Crw,-sig)*1.0e+2)/(Peu_eu*Prw_p*Qeur);
OUT [78] =(Pus*Pus_us_p*bet*(Qusd_p*((mu_us*taup*(Bus_usda/mu_us-Bus_usda_p/mu_us_p))/Bus_usda-(1.0/pow(Bus_usda,2)*pow(mu_us,2)*taup*pow(Bus_usda/mu_us-Bus_usda_p/mu_us_p,2))/2.0)-1.0)*(tau/Bus_usda_l+1.0/pow(Bus_usda_l,2)*mu_us_l*tau*(Bus_usda/mu_us-Bus_usda_l/mu_us_l))*1.0/pow(-ph_us_usd*r+(mu_us_l*tau*(Bus_usda/mu_us-Bus_usda_l/mu_us_l))/Bus_usda_l+1.0,2)*pow((pow(Cus_eu_p,-(mu_eu_p*(ah_us_p-1.0))/(mu_eu_p+mu_rw_p))*pow(Cus_rw_p,-(mu_rw_p*(ah_us_p-1.0))/(mu_eu_p+mu_rw_p))*pow(-(Ceu_us_p*mu_eu_p+Crw_us_p*mu_rw_p+Yus_p*mu_us_p*(phi_usg-1.0))/mu_us_p,ah_us_p))/Cus,-sig)*1.0e+2)/(Pus_p*Pus_us*Qusd);
OUT [80] =-Pus_us/mu_us_l+(Pus*mu_eu*tax_us_in)/(mu_us*mu_eu_l);
OUT [83] =-(Pus_us*(tax_us_in-1.0))/mu_eu_l;
OUT [110] =(Peu*Pus_us_p*bet*(tau/(Brw_usda_l-Busd_l+Bus_usda_l)+mu_eu_l*tau*((Brw_usda-Busd+Bus_usda)/mu_eu-(Brw_usda_l-Busd_l+Bus_usda_l)/mu_eu_l)*1.0/pow(Brw_usda_l-Busd_l+Bus_usda_l,2))*1.0/pow(-ph_eu_usd*r+(mu_eu_l*tau*((Brw_usda-Busd+Bus_usda)/mu_eu-(Brw_usda_l-Busd_l+Bus_usda_l)/mu_eu_l))/(Brw_usda_l-Busd_l+Bus_usda_l)+1.0,2)*(tax_us_in+tax_eu_out-Qusd_p*((pow(mu_eu,2)*taup*pow((Brw_usda-Busd+Bus_usda)/mu_eu-(Brw_usda_p-Busd_p+Bus_usda_p)/mu_eu_p,2)*1.0/pow(Brw_usda-Busd+Bus_usda,2))/2.0-(mu_eu*taup*((Brw_usda-Busd+Bus_usda)/mu_eu-(Brw_usda_p-Busd_p+Bus_usda_p)/mu_eu_p))/(Brw_usda-Busd+Bus_usda))-1.0)*pow((pow(Ceu_us_p,-(mu_us_p*(ah_eu_p-1.0))/(mu_us_p+mu_rw_p))*pow(Ceu_rw_p,-(mu_rw_p*(ah_eu_p-1.0))/(mu_us_p+mu_rw_p))*pow(-(Crw_eu_p*mu_rw_p+Cus_eu_p*mu_us_p+Yeu_p*mu_eu_p*(phi_eug-1.0))/mu_eu_p,ah_eu_p))/Ceu,-sig)*1.0e+2)/(Peu_p*Pus_us*Qusd);
OUT [117] =(Peu_eu_p*Pus*bet*(tau/(-Beur_l+Beu_eura_l+Brw_eura_l)+mu_us_l*tau*((-Beur+Beu_eura+Brw_eura)/mu_us-(-Beur_l+Beu_eura_l+Brw_eura_l)/mu_us_l)*1.0/pow(-Beur_l+Beu_eura_l+Brw_eura_l,2))*1.0/pow(-ph_us_eur*r+(mu_us_l*tau*((-Beur+Beu_eura+Brw_eura)/mu_us-(-Beur_l+Beu_eura_l+Brw_eura_l)/mu_us_l))/(-Beur_l+Beu_eura_l+Brw_eura_l)+1.0,2)*(tax_eu_in+tax_us_out-Qeur_p*((pow(mu_us,2)*taup*pow((-Beur+Beu_eura+Brw_eura)/mu_us-(-Beur_p+Beu_eura_p+Brw_eura_p)/mu_us_p,2)*1.0/pow(-Beur+Beu_eura+Brw_eura,2))/2.0-(mu_us*taup*((-Beur+Beu_eura+Brw_eura)/mu_us-(-Beur_p+Beu_eura_p+Brw_eura_p)/mu_us_p))/(-Beur+Beu_eura+Brw_eura))-1.0)*pow((pow(Cus_eu_p,-(mu_eu_p*(ah_us_p-1.0))/(mu_eu_p+mu_rw_p))*pow(Cus_rw_p,-(mu_rw_p*(ah_us_p-1.0))/(mu_eu_p+mu_rw_p))*pow(-(Ceu_us_p*mu_eu_p+Crw_us_p*mu_rw_p+Yus_p*mu_us_p*(phi_usg-1.0))/mu_us_p,ah_us_p))/Cus,-sig)*1.0e+2)/(Peu_eu*Pus_p*Qeur);
OUT [118] =-(Peu_eu*(tax_eu_in-1.0))/mu_us_l;
OUT [121] =-Peu_eu/mu_eu_l+(Peu*mu_us*tax_eu_in)/(mu_eu*mu_us_l);
OUT [149] =(Peu*Peu_eu_p*bet*(Qeur_p*((mu_eu*taup*(Beu_eura/mu_eu-Beu_eura_p/mu_eu_p))/Beu_eura-(1.0/pow(Beu_eura,2)*pow(mu_eu,2)*taup*pow(Beu_eura/mu_eu-Beu_eura_p/mu_eu_p,2))/2.0)-1.0)*(tau/Beu_eura_l+1.0/pow(Beu_eura_l,2)*mu_eu_l*tau*(Beu_eura/mu_eu-Beu_eura_l/mu_eu_l))*1.0/pow(-ph_eu_eur*r+(mu_eu_l*tau*(Beu_eura/mu_eu-Beu_eura_l/mu_eu_l))/Beu_eura_l+1.0,2)*pow((pow(Ceu_us_p,-(mu_us_p*(ah_eu_p-1.0))/(mu_us_p+mu_rw_p))*pow(Ceu_rw_p,-(mu_rw_p*(ah_eu_p-1.0))/(mu_us_p+mu_rw_p))*pow(-(Crw_eu_p*mu_rw_p+Cus_eu_p*mu_us_p+Yeu_p*mu_eu_p*(phi_eug-1.0))/mu_eu_p,ah_eu_p))/Ceu,-sig)*1.0e+2)/(Peu_p*Peu_eu*Qeur);

                            
                  
}




