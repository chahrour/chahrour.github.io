#include <math.h>
#include <mex.h>
#include <lapack.h>
#include <blas.h>
#include <stdlib.h>
#include <string.h>


#if !defined(MAX)
#define	MAX(A, B)	((A) > (B) ? (A) : (B))
#endif

#if !defined(MIN)
#define	MIN(A, B)	((A) < (B) ? (A) : (B))
#endif

#define pi  3.141592653589793
        
/* Prints an MxN matrix to Screen*/
void printmat_rowmaj(int m, int n, double M[m*n]){
    int x,y,k;
    k = 0;
    printf("\n");
    for(x=0;x<m;x++){
        for(y=0;y<n;y++){
            printf("%1.11lf\t", M[k]);
            k++;
        }
        printf("%\n");
    }
    return;
}


void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] )

{

    /*Check for proper number of arguments*/
    if (nrhs == 91)  {} else{mexErrMsgTxt(" 91 inputs arguments required.");}
        
    if (nlhs == 40)  {} else{mexErrMsgTxt(" 40 inputs arguments required.");}

            
    
    /*declare scalar input args*/
    double Cus_eu,Cus_rw,Ceu_us,Ceu_rw,Crw_us,Crw_eu,Crw_row,Qusd,Qeur,Pus_us,Pus_eu,Pus,Peu_eu,Peu_us,Peu,Prw,Prw_us,Prw_eu,m_us,m_eu,m_rw,pim_us_eu_,pim_us_rw_,pex_us_eu_,pim_eu_us_,pim_eu_rw_,pex_eu_us_,pim_rw_us_,pim_rw_eu_,pim_rw_row_,pex_rw_us_,pex_rw_eu_,Vusd,sbar_rw,Brw_usda,Brw_eura,Bus_usda,Beu_eura,Beur,Busd,Prw_rw,Xeu,Xus,Yeu,Yrw,Yus,ah_eu,ah_us,ah_rw,alph,bet,dtax_eu_us,dtax_us_eu,dtax_eu_rw,dtax_rw_eu,dtax_rw_us,dtax_us_rw,dtax_rw_row,eta,kap,mu_eu,mu_us,mu_rw,omg,per_p_year,phi,phi_eug,phi_usg,phi_rwg,r,sig,sige,tau,taup,tax_eu_in,tax_us_in,tax_eu_us,tax_us_eu,tax_eu_rw,tax_rw_eu,tax_rw_us,tax_us_rw,tax_eu_out,tax_us_out,tax_rw_out,tax_rw_row,upp_eur,upp_usd,vepsf,vepst,z;
Cus_eu= mxGetScalar(prhs[0]);
Cus_rw= mxGetScalar(prhs[1]);
Ceu_us= mxGetScalar(prhs[2]);
Ceu_rw= mxGetScalar(prhs[3]);
Crw_us= mxGetScalar(prhs[4]);
Crw_eu= mxGetScalar(prhs[5]);
Crw_row= mxGetScalar(prhs[6]);
Qusd= mxGetScalar(prhs[7]);
Qeur= mxGetScalar(prhs[8]);
Pus_us= mxGetScalar(prhs[9]);
Pus_eu= mxGetScalar(prhs[10]);
Pus= mxGetScalar(prhs[11]);
Peu_eu= mxGetScalar(prhs[12]);
Peu_us= mxGetScalar(prhs[13]);
Peu= mxGetScalar(prhs[14]);
Prw= mxGetScalar(prhs[15]);
Prw_us= mxGetScalar(prhs[16]);
Prw_eu= mxGetScalar(prhs[17]);
m_us= mxGetScalar(prhs[18]);
m_eu= mxGetScalar(prhs[19]);
m_rw= mxGetScalar(prhs[20]);
pim_us_eu_= mxGetScalar(prhs[21]);
pim_us_rw_= mxGetScalar(prhs[22]);
pex_us_eu_= mxGetScalar(prhs[23]);
pim_eu_us_= mxGetScalar(prhs[24]);
pim_eu_rw_= mxGetScalar(prhs[25]);
pex_eu_us_= mxGetScalar(prhs[26]);
pim_rw_us_= mxGetScalar(prhs[27]);
pim_rw_eu_= mxGetScalar(prhs[28]);
pim_rw_row_= mxGetScalar(prhs[29]);
pex_rw_us_= mxGetScalar(prhs[30]);
pex_rw_eu_= mxGetScalar(prhs[31]);
Vusd= mxGetScalar(prhs[32]);
sbar_rw= mxGetScalar(prhs[33]);
Brw_usda= mxGetScalar(prhs[34]);
Brw_eura= mxGetScalar(prhs[35]);
Bus_usda= mxGetScalar(prhs[36]);
Beu_eura= mxGetScalar(prhs[37]);
Beur= mxGetScalar(prhs[38]);
Busd= mxGetScalar(prhs[39]);
Prw_rw= mxGetScalar(prhs[40]);
Xeu= mxGetScalar(prhs[41]);
Xus= mxGetScalar(prhs[42]);
Yeu= mxGetScalar(prhs[43]);
Yrw= mxGetScalar(prhs[44]);
Yus= mxGetScalar(prhs[45]);
ah_eu= mxGetScalar(prhs[46]);
ah_us= mxGetScalar(prhs[47]);
ah_rw= mxGetScalar(prhs[48]);
alph= mxGetScalar(prhs[49]);
bet= mxGetScalar(prhs[50]);
dtax_eu_us= mxGetScalar(prhs[51]);
dtax_us_eu= mxGetScalar(prhs[52]);
dtax_eu_rw= mxGetScalar(prhs[53]);
dtax_rw_eu= mxGetScalar(prhs[54]);
dtax_rw_us= mxGetScalar(prhs[55]);
dtax_us_rw= mxGetScalar(prhs[56]);
dtax_rw_row= mxGetScalar(prhs[57]);
eta= mxGetScalar(prhs[58]);
kap= mxGetScalar(prhs[59]);
mu_eu= mxGetScalar(prhs[60]);
mu_us= mxGetScalar(prhs[61]);
mu_rw= mxGetScalar(prhs[62]);
omg= mxGetScalar(prhs[63]);
per_p_year= mxGetScalar(prhs[64]);
phi= mxGetScalar(prhs[65]);
phi_eug= mxGetScalar(prhs[66]);
phi_usg= mxGetScalar(prhs[67]);
phi_rwg= mxGetScalar(prhs[68]);
r= mxGetScalar(prhs[69]);
sig= mxGetScalar(prhs[70]);
sige= mxGetScalar(prhs[71]);
tau= mxGetScalar(prhs[72]);
taup= mxGetScalar(prhs[73]);
tax_eu_in= mxGetScalar(prhs[74]);
tax_us_in= mxGetScalar(prhs[75]);
tax_eu_us= mxGetScalar(prhs[76]);
tax_us_eu= mxGetScalar(prhs[77]);
tax_eu_rw= mxGetScalar(prhs[78]);
tax_rw_eu= mxGetScalar(prhs[79]);
tax_rw_us= mxGetScalar(prhs[80]);
tax_us_rw= mxGetScalar(prhs[81]);
tax_eu_out= mxGetScalar(prhs[82]);
tax_us_out= mxGetScalar(prhs[83]);
tax_rw_out= mxGetScalar(prhs[84]);
tax_rw_row= mxGetScalar(prhs[85]);
upp_eur= mxGetScalar(prhs[86]);
upp_usd= mxGetScalar(prhs[87]);
vepsf= mxGetScalar(prhs[88]);
vepst= mxGetScalar(prhs[89]);
z= mxGetScalar(prhs[90]);

         
  
    /*Create output arguments*/
    plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[1] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[2] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[3] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[4] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[5] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[6] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[7] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[8] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[9] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[10] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[11] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[12] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[13] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[14] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[15] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[16] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[17] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[18] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[19] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[20] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[21] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[22] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[23] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[24] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[25] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[26] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[27] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[28] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[29] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[30] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[31] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[32] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[33] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[34] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[35] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[36] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[37] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[38] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[39] = mxCreateDoubleMatrix(1,1,mxREAL);

    double *Cus,*Ceu,*Crw,*Cus_us,*Ceu_eu,*Crw_rw,*Pus_rw,*Peu_rw,*Prw_row,*Beu_usd,*Bus_eur,*p_us_usd,*p_us_eur,*p_eu_usd,*p_eu_eur,*p_rw_usd,*p_rw_eur,*ph_us_usd,*ph_us_eur,*ph_eu_usd,*ph_eu_eur,*ph_rw_usd,*ph_rw_eur,*m_us_til,*m_eu_til,*m_rw_til,*pim_us_eu,*pim_us_rw,*pex_us_eu,*pex_us_rw,*pim_eu_us,*pim_eu_rw,*pex_eu_us,*pex_eu_rw,*pim_rw_us,*pim_rw_eu,*pim_rw_row,*pex_rw_us,*pex_rw_eu,*pex_rw_row;
Cus= mxGetPr(plhs[0]);
Ceu= mxGetPr(plhs[1]);
Crw= mxGetPr(plhs[2]);
Cus_us= mxGetPr(plhs[3]);
Ceu_eu= mxGetPr(plhs[4]);
Crw_rw= mxGetPr(plhs[5]);
Pus_rw= mxGetPr(plhs[6]);
Peu_rw= mxGetPr(plhs[7]);
Prw_row= mxGetPr(plhs[8]);
Beu_usd= mxGetPr(plhs[9]);
Bus_eur= mxGetPr(plhs[10]);
p_us_usd= mxGetPr(plhs[11]);
p_us_eur= mxGetPr(plhs[12]);
p_eu_usd= mxGetPr(plhs[13]);
p_eu_eur= mxGetPr(plhs[14]);
p_rw_usd= mxGetPr(plhs[15]);
p_rw_eur= mxGetPr(plhs[16]);
ph_us_usd= mxGetPr(plhs[17]);
ph_us_eur= mxGetPr(plhs[18]);
ph_eu_usd= mxGetPr(plhs[19]);
ph_eu_eur= mxGetPr(plhs[20]);
ph_rw_usd= mxGetPr(plhs[21]);
ph_rw_eur= mxGetPr(plhs[22]);
m_us_til= mxGetPr(plhs[23]);
m_eu_til= mxGetPr(plhs[24]);
m_rw_til= mxGetPr(plhs[25]);
pim_us_eu= mxGetPr(plhs[26]);
pim_us_rw= mxGetPr(plhs[27]);
pex_us_eu= mxGetPr(plhs[28]);
pex_us_rw= mxGetPr(plhs[29]);
pim_eu_us= mxGetPr(plhs[30]);
pim_eu_rw= mxGetPr(plhs[31]);
pex_eu_us= mxGetPr(plhs[32]);
pex_eu_rw= mxGetPr(plhs[33]);
pim_rw_us= mxGetPr(plhs[34]);
pim_rw_eu= mxGetPr(plhs[35]);
pim_rw_row= mxGetPr(plhs[36]);
pex_rw_us= mxGetPr(plhs[37]);
pex_rw_eu= mxGetPr(plhs[38]);
pex_rw_row= mxGetPr(plhs[39]);

    

Cus[0] = pow(-(Ceu_us*mu_eu + Crw_us*mu_rw + Yus*mu_us*(phi_usg - 1.0))/mu_us,ah_us)/(pow(Cus_eu,(mu_eu*(ah_us - 1.0))/(mu_eu + mu_rw))*pow(Cus_rw,(mu_rw*(ah_us - 1.0))/(mu_eu + mu_rw)));
Ceu[0] = pow(-(Crw_eu*mu_rw + Cus_eu*mu_us + Yeu*mu_eu*(phi_eug - 1.0))/mu_eu,ah_eu)/(pow(Ceu_us,(mu_us*(ah_eu - 1.0))/(mu_us + mu_rw))*pow(Ceu_rw,(mu_rw*(ah_eu - 1.0))/(mu_us + mu_rw)));
Crw[0] = pow(-(Ceu_rw*mu_eu + Cus_rw*mu_us - mu_rw*(Crw_row - Yrw)*(phi_rwg - 1.0))/mu_rw,ah_rw)/(pow(Crw_eu,(mu_eu*(ah_rw - 1.0))/(mu_eu + mu_us + mu_rw))*pow(Crw_us,(mu_us*(ah_rw - 1.0))/(mu_eu + mu_us + mu_rw))*pow(Crw_row,(mu_rw*(ah_rw - 1.0))/(mu_eu + mu_us + mu_rw)));
Cus_us[0] = -(Ceu_us*mu_eu + Crw_us*mu_rw + Yus*mu_us*(phi_usg - 1.0))/mu_us;
Ceu_eu[0] = -(Crw_eu*mu_rw + Cus_eu*mu_us + Yeu*mu_eu*(phi_eug - 1.0))/mu_eu;
Crw_rw[0] = -(Ceu_rw*mu_eu + Cus_rw*mu_us - mu_rw*(Crw_row - Yrw)*(phi_rwg - 1.0))/mu_rw;
Pus_rw[0] = 1.0/((tax_us_rw + 1.0)*pow((Pus*pow(ah_us,ah_us)*pow(Pus_eu*(tax_us_eu + 1.0),(mu_eu*(ah_us - 1.0))/(mu_eu + mu_rw)))/(pow(Pus_us,ah_us)*pow(-(mu_eu*(ah_us - 1.0))/(mu_eu + mu_rw),(mu_eu*(ah_us - 1.0))/(mu_eu + mu_rw))*pow(-(mu_rw*(ah_us - 1.0))/(mu_eu + mu_rw),(mu_rw*(ah_us - 1.0))/(mu_eu + mu_rw))),(mu_eu + mu_rw)/(mu_rw*(ah_us - 1.0))));
Peu_rw[0] = 1.0/((tax_eu_rw + 1.0)*pow((Peu*pow(ah_eu,ah_eu)*pow(Peu_us*(tax_eu_us + 1.0),(mu_us*(ah_eu - 1.0))/(mu_us + mu_rw)))/(pow(Peu_eu,ah_eu)*pow(-(mu_us*(ah_eu - 1.0))/(mu_us + mu_rw),(mu_us*(ah_eu - 1.0))/(mu_us + mu_rw))*pow(-(mu_rw*(ah_eu - 1.0))/(mu_us + mu_rw),(mu_rw*(ah_eu - 1.0))/(mu_us + mu_rw))),(mu_us + mu_rw)/(mu_rw*(ah_eu - 1.0))));
Prw_row[0] = 1.0/((tax_rw_row + 1.0)*pow((Prw*pow(ah_rw,ah_rw)*pow(Prw_eu*(tax_rw_eu + 1.0),(mu_eu*(ah_rw - 1.0))/(mu_eu + mu_us + mu_rw))*pow(Prw_us*(tax_rw_us + 1.0),(mu_us*(ah_rw - 1.0))/(mu_eu + mu_us + mu_rw)))/(pow(Prw_rw,ah_rw)*pow(-(mu_eu*(ah_rw - 1.0))/(mu_eu + mu_us + mu_rw),(mu_eu*(ah_rw - 1.0))/(mu_eu + mu_us + mu_rw))*pow(-(mu_us*(ah_rw - 1.0))/(mu_eu + mu_us + mu_rw),(mu_us*(ah_rw - 1.0))/(mu_eu + mu_us + mu_rw))*pow(-(mu_rw*(ah_rw - 1.0))/(mu_eu + mu_us + mu_rw),(mu_rw*(ah_rw - 1.0))/(mu_eu + mu_us + mu_rw))),(mu_eu + mu_us + mu_rw)/(mu_rw*(ah_rw - 1.0))));
Beu_usd[0] = -(Brw_usda - Busd + Bus_usda)/mu_eu;
Bus_eur[0] = -(Beu_eura - Beur + Brw_eura)/mu_us;
p_us_usd[0] = (Bus_usda*Pus_us*Qusd*upp_usd)/(mu_us*pow(pow(Xus*m_us,1.0/vepsf) + pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),vepsf));
p_us_eur[0] = -(Peu_eu*Qeur*upp_eur*(Beu_eura - Beur + Brw_eura))/(mu_us*pow(pow(-m_us*(Xus - 1.0),1.0/vepsf) + pow(-(Peu_eu*Qeur*upp_eur*(Beu_eura - Beur + Brw_eura))/mu_us,1.0/vepsf),vepsf));
p_eu_usd[0] = -(Pus_us*Qusd*upp_usd*(Brw_usda - Busd + Bus_usda))/(mu_eu*pow(pow(Xeu*m_eu,1.0/vepsf) + pow(-(Pus_us*Qusd*upp_usd*(Brw_usda - Busd + Bus_usda))/mu_eu,1.0/vepsf),vepsf));
p_eu_eur[0] = (Beu_eura*Peu_eu*Qeur*upp_eur)/(mu_eu*pow(pow(-m_eu*(Xeu - 1.0),1.0/vepsf) + pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),vepsf));
p_rw_usd[0] = (Brw_usda*Pus_us*Qusd*upp_usd)/(mu_rw*pow(pow(m_rw*(z - (erfc((pow(2.0,1.0/2.0)*sbar_rw)/2.0)*(2.0*z - 1.0))/2.0),1.0/vepsf) + pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),vepsf));
p_rw_eur[0] = (Brw_eura*Peu_eu*Qeur*upp_eur)/(mu_rw*pow(pow(m_rw*((erfc((pow(2.0,1.0/2.0)*sbar_rw)/2.0)*(2.0*z - 1.0))/2.0 - z + 1.0),1.0/vepsf) + pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),vepsf));
ph_us_usd[0] = (Xus*m_us*upp_usd)/pow(pow(Xus*m_us,1.0/vepsf) + pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),vepsf);
ph_us_eur[0] = -(m_us*upp_eur*(Xus - 1.0))/pow(pow(-m_us*(Xus - 1.0),1.0/vepsf) + pow(-(Peu_eu*Qeur*upp_eur*(Beu_eura - Beur + Brw_eura))/mu_us,1.0/vepsf),vepsf);
ph_eu_usd[0] = (Xeu*m_eu*upp_usd)/pow(pow(Xeu*m_eu,1.0/vepsf) + pow(-(Pus_us*Qusd*upp_usd*(Brw_usda - Busd + Bus_usda))/mu_eu,1.0/vepsf),vepsf);
ph_eu_eur[0] = -(m_eu*upp_eur*(Xeu - 1.0))/pow(pow(-m_eu*(Xeu - 1.0),1.0/vepsf) + pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),vepsf);
ph_rw_usd[0] = (m_rw*upp_usd*(z - (erfc((pow(2.0,1.0/2.0)*sbar_rw)/2.0)*(2.0*z - 1.0))/2.0))/pow(pow(m_rw*(z - (erfc((pow(2.0,1.0/2.0)*sbar_rw)/2.0)*(2.0*z - 1.0))/2.0),1.0/vepsf) + pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),vepsf);
ph_rw_eur[0] = (m_rw*upp_eur*((erfc((pow(2.0,1.0/2.0)*sbar_rw)/2.0)*(2.0*z - 1.0))/2.0 - z + 1.0))/pow(pow(m_rw*((erfc((pow(2.0,1.0/2.0)*sbar_rw)/2.0)*(2.0*z - 1.0))/2.0 - z + 1.0),1.0/vepsf) + pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),vepsf);
m_us_til[0] = m_us*mu_us*((Bus_usda*Pus_us*Qusd*Xus*upp_usd)/(mu_us*pow(pow(Xus*m_us,1.0/vepsf) + pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),vepsf)) + (Peu_eu*Qeur*upp_eur*(Xus - 1.0)*(Beu_eura - Beur + Brw_eura))/(mu_us*pow(pow(-m_us*(Xus - 1.0),1.0/vepsf) + pow(-(Peu_eu*Qeur*upp_eur*(Beu_eura - Beur + Brw_eura))/mu_us,1.0/vepsf),vepsf)));
m_eu_til[0] = -m_eu*mu_eu*((Pus_us*Qusd*Xeu*upp_usd*(Brw_usda - Busd + Bus_usda))/(mu_eu*pow(pow(Xeu*m_eu,1.0/vepsf) + pow(-(Pus_us*Qusd*upp_usd*(Brw_usda - Busd + Bus_usda))/mu_eu,1.0/vepsf),vepsf)) + (Beu_eura*Peu_eu*Qeur*upp_eur*(Xeu - 1.0))/(mu_eu*pow(pow(-m_eu*(Xeu - 1.0),1.0/vepsf) + pow((Beu_eura*Peu_eu*Qeur*upp_eur)/mu_eu,1.0/vepsf),vepsf)));
m_rw_til[0] = m_rw*mu_rw*((Brw_eura*Peu_eu*Qeur*upp_eur*((erfc((pow(2.0,1.0/2.0)*sbar_rw)/2.0)*(2.0*z - 1.0))/2.0 - z + 1.0))/(mu_rw*pow(pow(m_rw*((erfc((pow(2.0,1.0/2.0)*sbar_rw)/2.0)*(2.0*z - 1.0))/2.0 - z + 1.0),1.0/vepsf) + pow((Brw_eura*Peu_eu*Qeur*upp_eur)/mu_rw,1.0/vepsf),vepsf)) + (Brw_usda*Pus_us*Qusd*upp_usd*(z - (erfc((pow(2.0,1.0/2.0)*sbar_rw)/2.0)*(2.0*z - 1.0))/2.0))/(mu_rw*pow(pow(m_rw*(z - (erfc((pow(2.0,1.0/2.0)*sbar_rw)/2.0)*(2.0*z - 1.0))/2.0),1.0/vepsf) + pow((Brw_usda*Pus_us*Qusd*upp_usd)/mu_rw,1.0/vepsf),vepsf)));
pim_us_eu[0] = exp(pim_us_eu_)/(exp(pim_us_eu_) + 1.0);
pim_us_rw[0] = -(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_) + 1.0) - 1.0))/(exp(pim_us_rw_) + 1.0);
pex_us_eu[0] = (exp(pex_us_eu_)*((exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_) + 1.0) - 1.0))/(exp(pim_us_rw_) + 1.0) - exp(pim_us_eu_)/(exp(pim_us_eu_) + 1.0) + 1.0))/(exp(pex_us_eu_) + 1.0);
pex_us_rw[0] = (exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_) + 1.0) - 1.0))/(exp(pim_us_rw_) + 1.0) - (exp(pex_us_eu_)*((exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_) + 1.0) - 1.0))/(exp(pim_us_rw_) + 1.0) - exp(pim_us_eu_)/(exp(pim_us_eu_) + 1.0) + 1.0))/(exp(pex_us_eu_) + 1.0) - exp(pim_us_eu_)/(exp(pim_us_eu_) + 1.0) + 1.0;
pim_eu_us[0] = exp(pim_eu_us_)/(exp(pim_eu_us_) + 1.0);
pim_eu_rw[0] = -(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_) + 1.0) - 1.0))/(exp(pim_eu_rw_) + 1.0);
pex_eu_us[0] = (exp(pex_eu_us_)*((exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_) + 1.0) - 1.0))/(exp(pim_eu_rw_) + 1.0) - exp(pim_eu_us_)/(exp(pim_eu_us_) + 1.0) + 1.0))/(exp(pex_eu_us_) + 1.0);
pex_eu_rw[0] = (exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_) + 1.0) - 1.0))/(exp(pim_eu_rw_) + 1.0) - (exp(pex_eu_us_)*((exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_) + 1.0) - 1.0))/(exp(pim_eu_rw_) + 1.0) - exp(pim_eu_us_)/(exp(pim_eu_us_) + 1.0) + 1.0))/(exp(pex_eu_us_) + 1.0) - exp(pim_eu_us_)/(exp(pim_eu_us_) + 1.0) + 1.0;
pim_rw_us[0] = exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0);
pim_rw_eu[0] = -(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) - 1.0))/(exp(pim_rw_eu_) + 1.0);
pim_rw_row[0] = (exp(pim_rw_row_)*((exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) - 1.0))/(exp(pim_rw_eu_) + 1.0) - exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) + 1.0))/(exp(pim_rw_row_) + 1.0);
pex_rw_us[0] = -(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) + (exp(pim_rw_row_)*((exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) - 1.0))/(exp(pim_rw_eu_) + 1.0) - exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) + 1.0))/(exp(pim_rw_row_) + 1.0) - (exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) - 1.0))/(exp(pim_rw_eu_) + 1.0) - 1.0))/(exp(pex_rw_us_) + 1.0);
pex_rw_eu[0] = (exp(pex_rw_eu_)*((exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) + (exp(pim_rw_row_)*((exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) - 1.0))/(exp(pim_rw_eu_) + 1.0) - exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) + 1.0))/(exp(pim_rw_row_) + 1.0) - (exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) - 1.0))/(exp(pim_rw_eu_) + 1.0) - 1.0))/(exp(pex_rw_us_) + 1.0) - exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) - (exp(pim_rw_row_)*((exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) - 1.0))/(exp(pim_rw_eu_) + 1.0) - exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) + 1.0))/(exp(pim_rw_row_) + 1.0) + (exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) - 1.0))/(exp(pim_rw_eu_) + 1.0) + 1.0))/(exp(pex_rw_eu_) + 1.0);
pex_rw_row[0] = (exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) + (exp(pim_rw_row_)*((exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) - 1.0))/(exp(pim_rw_eu_) + 1.0) - exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) + 1.0))/(exp(pim_rw_row_) + 1.0) - (exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) - 1.0))/(exp(pim_rw_eu_) + 1.0) - 1.0))/(exp(pex_rw_us_) + 1.0) - (exp(pex_rw_eu_)*((exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) + (exp(pim_rw_row_)*((exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) - 1.0))/(exp(pim_rw_eu_) + 1.0) - exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) + 1.0))/(exp(pim_rw_row_) + 1.0) - (exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) - 1.0))/(exp(pim_rw_eu_) + 1.0) - 1.0))/(exp(pex_rw_us_) + 1.0) - exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) - (exp(pim_rw_row_)*((exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) - 1.0))/(exp(pim_rw_eu_) + 1.0) - exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) + 1.0))/(exp(pim_rw_row_) + 1.0) + (exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) - 1.0))/(exp(pim_rw_eu_) + 1.0) + 1.0))/(exp(pex_rw_eu_) + 1.0) - exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) - (exp(pim_rw_row_)*((exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) - 1.0))/(exp(pim_rw_eu_) + 1.0) - exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) + 1.0))/(exp(pim_rw_row_) + 1.0) + (exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_) + 1.0) - 1.0))/(exp(pim_rw_eu_) + 1.0) + 1.0;
        
      
                            
                  
}




