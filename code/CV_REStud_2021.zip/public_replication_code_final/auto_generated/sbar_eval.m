function out = sbar_eval(x,xp,xl,log_idx,...
    Busd,Beur,Yus,Yeu,Yrw,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,Busd_l,Beur_l,Yus_l,Yeu_l,Yrw_l,mu_us_l,mu_eu_l,mu_rw_l,ah_us_l,ah_eu_l,ah_rw_l,Busd_p,Beur_p,Yus_p,Yeu_p,Yrw_p,mu_us_p,mu_eu_p,mu_rw_p,ah_us_p,ah_eu_p,ah_rw_p,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out)

x(log_idx) = exp(x(log_idx));

%Time t variables
 Cus_eu=x(1);
 Cus_rw=x(2);
 Ceu_us=x(3);
 Ceu_rw=x(4);
 Crw_us=x(5);
 Crw_eu=x(6);
 Crw_row=x(7);
 Qusd=x(8);
 Qeur=x(9);
 Pus_us=x(10);
 Pus_eu=x(11);
 Pus=x(12);
 Peu_eu=x(13);
 Peu_us=x(14);
 Peu=x(15);
 Prw=x(16);
 Prw_us=x(17);
 Prw_eu=x(18);
 m_us=x(19);
 m_eu=x(20);
 m_rw=x(21);
 pim_us_eu_=x(22);
 pim_us_rw_=x(23);
 pex_us_eu_=x(24);
 pim_eu_us_=x(25);
 pim_eu_rw_=x(26);
 pex_eu_us_=x(27);
 pim_rw_us_=x(28);
 pim_rw_eu_=x(29);
 pim_rw_row_=x(30);
 pex_rw_us_=x(31);
 pex_rw_eu_=x(32);
 Vusd=x(33);
 sbar_rw=x(34);
 Brw_usda=x(35);
 Brw_eura=x(36);
 Bus_usda=x(37);
 Beu_eura=x(38);


%Be sure it's xp and not x;
 Cus_eu_p=xp(1);
 Cus_rw_p=xp(2);
 Ceu_us_p=xp(3);
 Ceu_rw_p=xp(4);
 Crw_us_p=xp(5);
 Crw_eu_p=xp(6);
 Crw_row_p=xp(7);
 Qusd_p=xp(8);
 Qeur_p=xp(9);
 Pus_us_p=xp(10);
 Pus_eu_p=xp(11);
 Pus_p=xp(12);
 Peu_eu_p=xp(13);
 Peu_us_p=xp(14);
 Peu_p=xp(15);
 Prw_p=xp(16);
 Prw_us_p=xp(17);
 Prw_eu_p=xp(18);
 m_us_p=xp(19);
 m_eu_p=xp(20);
 m_rw_p=xp(21);
 pim_us_eu__p=xp(22);
 pim_us_rw__p=xp(23);
 pex_us_eu__p=xp(24);
 pim_eu_us__p=xp(25);
 pim_eu_rw__p=xp(26);
 pex_eu_us__p=xp(27);
 pim_rw_us__p=xp(28);
 pim_rw_eu__p=xp(29);
 pim_rw_row__p=xp(30);
 pex_rw_us__p=xp(31);
 pex_rw_eu__p=xp(32);
 Vusd_p=xp(33);
 sbar_rw_p=xp(34);
 Brw_usda_p=xp(35);
 Brw_eura_p=xp(36);
 Bus_usda_p=xp(37);
 Beu_eura_p=xp(38);


%Be sure it's xp and not x;
 Brw_usda_l=xl(1);
 Brw_eura_l=xl(2);
 Bus_usda_l=xl(3);
 Beu_eura_l=xl(4);


%Shell Residual
out =  sbar_solve(Cus_eu,Cus_rw,Ceu_us,Ceu_rw,Crw_us,Crw_eu,Crw_row,Qusd,Qeur,Pus_us,Pus_eu,Pus,Peu_eu,Peu_us,Peu,Prw,Prw_us,Prw_eu,m_us,m_eu,m_rw,pim_us_eu_,pim_us_rw_,pex_us_eu_,pim_eu_us_,pim_eu_rw_,pex_eu_us_,pim_rw_us_,pim_rw_eu_,pim_rw_row_,pex_rw_us_,pex_rw_eu_,Vusd,sbar_rw,Brw_usda,Brw_eura,Bus_usda,Beu_eura,Cus_eu_p,Cus_rw_p,Ceu_us_p,Ceu_rw_p,Crw_us_p,Crw_eu_p,Crw_row_p,Qusd_p,Qeur_p,Pus_us_p,Pus_eu_p,Pus_p,Peu_eu_p,Peu_us_p,Peu_p,Prw_p,Prw_us_p,Prw_eu_p,m_us_p,m_eu_p,m_rw_p,pim_us_eu__p,pim_us_rw__p,pex_us_eu__p,pim_eu_us__p,pim_eu_rw__p,pex_eu_us__p,pim_rw_us__p,pim_rw_eu__p,pim_rw_row__p,pex_rw_us__p,pex_rw_eu__p,Vusd_p,sbar_rw_p,Brw_usda_p,Brw_eura_p,Bus_usda_p,Beu_eura_p,Brw_usda_l,Brw_eura_l,Bus_usda_l,Beu_eura_l,Busd,Beur,Yus,Yeu,Yrw,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,Busd_l,Beur_l,Yus_l,Yeu_l,Yrw_l,mu_us_l,mu_eu_l,mu_rw_l,ah_us_l,ah_eu_l,ah_rw_l,Busd_p,Beur_p,Yus_p,Yeu_p,Yrw_p,mu_us_p,mu_eu_p,mu_rw_p,ah_us_p,ah_eu_p,ah_rw_p,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);
