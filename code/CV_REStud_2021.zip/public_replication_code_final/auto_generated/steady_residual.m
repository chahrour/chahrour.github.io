function [out,dout] = steady_residual(x,log_idx,...
    Busd,Beur,Yus,Yeu,Yrw,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);

x(log_idx) = exp(x(log_idx));

 Cus_eu=x(1);
 Cus_rw=x(2);
 Ceu_us=x(3);
 Ceu_rw=x(4);
 Crw_us=x(5);
 Crw_eu=x(6);
 Crw_row=x(7);
 Qusd=x(8);
 Qeur=x(9);
 Pus_us=x(10);
 Pus_eu=x(11);
 Pus=x(12);
 Peu_eu=x(13);
 Peu_us=x(14);
 Peu=x(15);
 Prw=x(16);
 Prw_us=x(17);
 Prw_eu=x(18);
 m_us=x(19);
 m_eu=x(20);
 m_rw=x(21);
 pim_us_eu_=x(22);
 pim_us_rw_=x(23);
 pex_us_eu_=x(24);
 pim_eu_us_=x(25);
 pim_eu_rw_=x(26);
 pex_eu_us_=x(27);
 pim_rw_us_=x(28);
 pim_rw_eu_=x(29);
 pim_rw_row_=x(30);
 pex_rw_us_=x(31);
 pex_rw_eu_=x(32);
 Vusd=x(33);
 sbar_rw=x(34);


if nargout > 1
    %With derivative
     [out]  = resid_ss_mex(Cus_eu,Cus_rw,Ceu_us,Ceu_rw,Crw_us,Crw_eu,Crw_row,Qusd,Qeur,Pus_us,Pus_eu,Pus,Peu_eu,Peu_us,Peu,Prw,Prw_us,Prw_eu,m_us,m_eu,m_rw,pim_us_eu_,pim_us_rw_,pex_us_eu_,pim_eu_us_,pim_eu_rw_,pex_eu_us_,pim_rw_us_,pim_rw_eu_,pim_rw_row_,pex_rw_us_,pex_rw_eu_,Vusd,sbar_rw,Busd,Beur,Yus,Yeu,Yrw,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);
     [dout] = dresid_ss_mex(Cus_eu,Cus_rw,Ceu_us,Ceu_rw,Crw_us,Crw_eu,Crw_row,Qusd,Qeur,Pus_us,Pus_eu,Pus,Peu_eu,Peu_us,Peu,Prw,Prw_us,Prw_eu,m_us,m_eu,m_rw,pim_us_eu_,pim_us_rw_,pex_us_eu_,pim_eu_us_,pim_eu_rw_,pex_eu_us_,pim_rw_us_,pim_rw_eu_,pim_rw_row_,pex_rw_us_,pex_rw_eu_,Vusd,sbar_rw,Busd,Beur,Yus,Yeu,Yrw,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);
     [dsub] = ddef_sub_ss_mex(Cus_eu,Cus_rw,Ceu_us,Ceu_rw,Crw_us,Crw_eu,Crw_row,Qusd,Qeur,Pus_us,Pus_eu,Pus,Peu_eu,Peu_us,Peu,Prw,Prw_us,Prw_eu,m_us,m_eu,m_rw,pim_us_eu_,pim_us_rw_,pex_us_eu_,pim_eu_us_,pim_eu_rw_,pex_eu_us_,pim_rw_us_,pim_rw_eu_,pim_rw_row_,pex_rw_us_,pex_rw_eu_,Vusd,sbar_rw,Beur,Busd,Prw_rw,Xeu,Xus,Yeu,Yrw,Yus,ah_eu,ah_us,ah_rw,alph,bet,dtax_eu_us,dtax_us_eu,dtax_eu_rw,dtax_rw_eu,dtax_rw_us,dtax_us_rw,dtax_rw_row,eta,kap,mu_eu,mu_us,mu_rw,omg,per_p_year,phi,phi_eug,phi_usg,phi_rwg,r,sig,sige,tau,taup,tax_eu_in,tax_us_in,tax_eu_us,tax_us_eu,tax_eu_rw,tax_rw_eu,tax_rw_us,tax_us_rw,tax_eu_out,tax_us_out,tax_rw_out,tax_rw_row,upp_eur,upp_usd,vepsf,vepst,z);

     %Chain rule
     dout = dout(:,1:length(x)) + dout(:,length(x)+1:end)*dsub;

     %For log values
     dout(:,log_idx) = dout(:,log_idx)*diag(x(log_idx));

else
    %Without derivative
    [out] = resid_ss_mex(Cus_eu,Cus_rw,Ceu_us,Ceu_rw,Crw_us,Crw_eu,Crw_row,Qusd,Qeur,Pus_us,Pus_eu,Pus,Peu_eu,Peu_us,Peu,Prw,Prw_us,Prw_eu,m_us,m_eu,m_rw,pim_us_eu_,pim_us_rw_,pex_us_eu_,pim_eu_us_,pim_eu_rw_,pex_eu_us_,pim_rw_us_,pim_rw_eu_,pim_rw_row_,pex_rw_us_,pex_rw_eu_,Vusd,sbar_rw,Busd,Beur,Yus,Yeu,Yrw,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);
end







