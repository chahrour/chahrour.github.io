setup

% KEY SAVED FILES
save_me = true;

%This code solves for the steady-state of the model
load saved_results/idx_vars

neq    = 26 + 4*endog_ctry + 8*endog_all;
nstate = 4  + xstate;
s_idx  = 34;
%**************************************************************************
% Parameters
%**************************************************************************
per_p_year = 1;
use_p_year = 8;  %52/6 -> 6 week contracts
upp_usd    = 1*use_p_year/per_p_year;
upp_eur    = upp_usd; 

%No new bond released in steady-state
dBusd  = 0;
dBeur  = 0;

%No changes in Y in steady-state
dYus = 0;
dYeu = 0;
dYrw = 0;

%Calibrated parameters
Beur   = 1.471035591865715;
Busd   = 1.471035591865715;
vepsf  = 0.294493519281979;
phi    = 0.038183884875547;
r      = 0.005000000000000;
sige   = 1.000000000000000e-03;
ah_us  = 0.718387079962791;
ah_eu  = 0.718387079962791;
ah_rw  = 0.718387079962791;
kap    = 0.01;

%Load calibrated parameters (if commented, uses values above)
%load calib_params_new.mat

Busd_l = Busd;
Busd_p = Busd;
Beur_l = Beur;
Beur_p = Beur;



%Fixed parameters
bet    = 0.96^(1/per_p_year); %Discount Factor
sig    = 1.00;                 %IES
eta    = 1;%1.01;                   %Elasiticty of subs. across good.1
alph   = 0.5;                 %Nash share in trade
tau    = 0.04;%0.045;               %Adj. cost of bonds: 20% change in holding costs 10 basis points ((10000*(.05/2)*(.2)^2) = 10)
taup   = 0*tau;               %Internalized adj cost?
vepst  = 0.01; 0.25;           %Matching elasticity in trade
omg    = 1;                   %frac of firm reoptimizing every period
Prw_rw = 1;                   %Numeraire
Xus    = 0.90;                 %US traders use of $
Xeu    = 1 - Xus;             %EU traders use of eur
z      = 0;                   %RW traders exog use of $/eur

mu_us = 1/5;           %Size US
mu_eu = 1/5;           %Size EU
mu_rw = 1-mu_us-mu_eu; %Size RW

Yus =  12/per_p_year*1;     %Endowment GDP
Yeu =  12/per_p_year*1;     %Endowment GDP
Yrw =  12/per_p_year*1;     %Endowment GDP

phi_usg = 0;           %Government share US
phi_eug = 0;           %Government share EU
phi_rwg = 0;           %Government share RW

%Put tarrif everwhere

trf        = 1*0.0; %Common tariff
trf_cap    = 0*0.0001; 

if trf>0
    disp('WARNING: TARIF ON!')
    pause(1)
end

tax_us_eu  = 1*trf;
tax_us_rw  = 1*trf;
tax_eu_us  = 1*trf;
tax_eu_rw  = 0*trf;
tax_rw_us  = 1*trf;
tax_rw_eu  = 0*trf;
tax_rw_row = 0*trf;

tax_us_in  = 1*trf_cap; 
tax_us_out = 0*trf_cap;
tax_eu_in  = 1*trf_cap; 
tax_eu_out = 0*trf_cap; 
tax_rw_out = 0*trf_cap; 

dtax_us_eu=0;
dtax_us_rw=0;
dtax_eu_us=0;
dtax_eu_rw=0;
dtax_rw_us=0;
dtax_rw_eu=0;
dtax_rw_row=0;

mu_us_l = mu_us;
mu_us_p = mu_us;

mu_eu_l = mu_eu;
mu_eu_p = mu_eu;

mu_rw_l = mu_rw;
mu_rw_p = mu_rw;

ah_us_l = ah_us;
ah_eu_l = ah_eu;
ah_rw_l = ah_rw;

ah_us_p = ah_us;
ah_eu_p = ah_eu;
ah_rw_p = ah_rw;

Yus_l = Yus;
Yeu_l = Yeu;
Yrw_l = Yrw;

Yus_p = Yus;
Yeu_p = Yeu;
Yrw_p = Yrw;

%**************************************************************************
% Solving steady-state
%**************************************************************************
options = optimset('fsolve');
options.Display = 'iter';
options.MaxFunEvals = 185000;
options.MaxIter = 5000;
options.TolX = 1e-16;
options.TolFun = 1e-19;
options.DerivativeCheck = 'on';
options.Jacobian = 'on';
options.FinDiffType = 'center';
log_idx = [];

%Initiali values
load input_files/xout xout
x0 = xout;

%The objective
obj = @(x) steady_residual(x,log_idx,...
     Busd,Beur,Yus,Yeu,Yrw,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);

[a,b]  = obj(x0);

[xout,fout,flag] = fsolve(obj,x0, options);
disp(['Max resid at x0: ' num2str2(max(abs(a)))]);
disp(['Max resid at xout: ' num2str2(max(abs(fout)))]);
xout(log_idx) = exp(xout(log_idx));
xfinal        = xout;

save_list = {'bet','kap','r','alph','sige','tau','phi','veps*','*usd*', '*eur*', 'mu*', '*us', '*eu', '*rw', '*_p_*', 'xout', '*_steady','frac_ss','xspecial_long','GDs','TSHRs','Xs','table_dat'};
%% ************************************************************************
% Find steady-states associated baseline calibration
%**************************************************************************
save_str = 'baseline'; %the baseline steady-state

steady_state_finder
disp_params
xspecial(end,:)
if save_me
    disp(' ');
    disp(['Saving as saved_results/steady_' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end


%% ************************************************************************
% Find steady-states associated with a variety of scenarios in the paper
%**************************************************************************

%% the baseline + 15 percent tarrifs between us and row
load saved_results/steady_baseline
save_str = 'usrowwar15';
trf = .15;
tax_us_rw  = trf;
tax_rw_us  = trf;
tax_us_eu  = trf;
tax_eu_us  = trf;
steady_state_finder
disp_params
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end


%% the baseline + 30 percent tarrifs between us and row
load saved_results/steady_baseline
save_str = 'usrowwar30';
trf = .30;
tax_us_rw  = trf;
tax_rw_us  = trf;
tax_us_eu  = trf;
tax_eu_us  = trf;
steady_state_finder
disp_params
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end


%% baseline + Beur*0.6;
load saved_results/steady_baseline
save_str = 'beforeur';
Beur = .6*Beur;

Busd_l = Busd;
Busd_p = Busd;
Beur_l = Beur;
Beur_p = Beur;

steady_state_finder
disp_params
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end

%% baseline + Beur*1.3;
load saved_results/steady_baseline
save_str = 'aftereur';
Beur = 1.3*Beur;

Busd_l = Busd;
Busd_p = Busd;
Beur_l = Beur;
Beur_p = Beur;

steady_state_finder
disp_params
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end


%% baseline + mus/murw change;
load saved_results/steady_baseline
%load saved_results/steady_beforerw xout
xout = [0.7957
    1.3977
    1.3764
    1.3826
    1.4074
    0.8048
    1.4309
    0.9790
    0.9660
    0.7909
    0.8533
    1.6505
    0.7847
    0.8601
    1.8403
    2.4072
    0.8645
    0.8638
    4.8467
    5.8119
    6.7945
   -1.8329
   -0.3419
   -0.9816
   -1.3867
   -0.5346
   -0.4146
   -1.5453
   -1.9788
   -0.7805
   -0.6381
   -0.8485
    0.0016
   -1.6049];

close all
save_str = 'beforerw';
hus = (ah_us - mu_us)/(1-mu_us)
heu = (ah_eu - mu_eu)/(1-mu_eu)

%Fricitonless benchmark
%{
Busd = .01;
Beur = .01;
upp_usd = 5000;
upp_eur = 5000;
r = .000005;
phi = .0001;
kap = 0;
%}
mu_us = .35;
mu_rw = 1-mu_eu-mu_us;
% Yrw   = 12;
% Yrw_l = Yrw;
% Yrw_p = Yrw;
% 
% Yeu   = 12;
% Yeu_l = Yeu;
% Yeu_p = Yeu;

ah_us = hus + (1-hus)*mu_us;
ah_eu = heu + (1-heu)*mu_eu;

mu_us_l = mu_us;
mu_us_p = mu_us;

mu_eu_l = mu_eu;
mu_eu_p = mu_eu;

mu_rw_l = mu_rw;
mu_rw_p = mu_rw;

ah_us_l = ah_us;
ah_eu_l = ah_eu;
ah_rw_l = ah_rw;

ah_us_p = ah_us;
ah_eu_p = ah_eu;
ah_rw_p = ah_rw;

Busd_l = Busd;
Busd_p = Busd;
Beur_l = Beur;
Beur_p = Beur;


steady_state_finder
disp_params
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end

return

%% baseline frictionless
load saved_results/steady_baseline
save_str = 'baseline_nofriction';
hus = (ah_us - mu_us)/(1-mu_us)
heu = (ah_eu - mu_eu)/(1-mu_eu)

%Fricitonless benchmark

Busd = Busd/500;
Beur = Beur/500;
upp_usd = 500*upp_usd;
upp_eur = 500*upp_eur;
r = 1/500*r;
%phi = .001;
%kap = 0.01;
%tau = 0;
%}
mu_us = .2;
mu_rw = 1-mu_eu-mu_us;


ah_us = hus + (1-hus)*mu_us;
ah_eu = heu + (1-heu)*mu_eu;

mu_us_l = mu_us;
mu_us_p = mu_us;

mu_eu_l = mu_eu;
mu_eu_p = mu_eu;

mu_rw_l = mu_rw;
mu_rw_p = mu_rw;

ah_us_l = ah_us;
ah_eu_l = ah_eu;
ah_rw_l = ah_rw;

ah_us_p = ah_us;
ah_eu_p = ah_eu;
ah_rw_p = ah_rw;

Busd_l = Busd;
Busd_p = Busd;
Beur_l = Beur;
Beur_p = Beur;

steady_state_finder
disp_params
close all
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end

%% baseline frictionless + murw/muus change
load saved_results/steady_beforerw_nofriction
save_str = 'beforerw_nofriction';
hus = (ah_us - mu_us)/(1-mu_us)
heu = (ah_eu - mu_eu)/(1-mu_eu)

%Fricitonless benchmark parameters imported above

mu_us = .35;
mu_rw = 1-mu_eu-mu_us;


ah_us = hus + (1-hus)*mu_us;
ah_eu = heu + (1-heu)*mu_eu;

mu_us_l = mu_us;
mu_us_p = mu_us;

mu_eu_l = mu_eu;
mu_eu_p = mu_eu;

mu_rw_l = mu_rw;
mu_rw_p = mu_rw;

ah_us_l = ah_us;
ah_eu_l = ah_eu;
ah_rw_l = ah_rw;

ah_us_p = ah_us;
ah_eu_p = ah_eu;
ah_rw_p = ah_rw;

Busd_l = Busd;
Busd_p = Busd;
Beur_l = Beur;
Beur_p = Beur;

steady_state_finder
disp_params
close all
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end

