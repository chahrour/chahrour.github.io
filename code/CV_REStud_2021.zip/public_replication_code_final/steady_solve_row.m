setup

% KEY SAVED FILES
save_me = true;

%This code solves for the steady-state of the model
load saved_results/idx_vars

neq    = 27 + 4*endog_ctry + 8*endog_all;
nstate = 6  + xstate;
s_idx  = sbar_rw_idx;  %What is the s cutof variable
seq_idx = 35;          %Which equaiton has the s cutof condition

%**************************************************************************
% Parameters
%**************************************************************************
per_p_year = 1;
use_p_year = 8;  %52/8 -> 6.5 week contracts
upp_usd    = 1*use_p_year/per_p_year;
upp_eur    = upp_usd; 

%No new bond released in steady-state
dBusd  = 0;
dBeur  = 0;

%No changes in Y in steady-state
dYus = 0;
dYeu = 0;
dYrw = 0;

%Calibrated parameters
Beur   = 1.3295016325961;
Busd   = 1.3295016325961;
Brow   = 3;
vepsf  = 0.3391426949430;
phi    = 0.0577111703012;
r      = 0.0044999999918;
sige   = 0.0020000000000;
ah_us  = 0.6790181619542;
ah_eu  = 0.6790181619542;
ah_rw  = 0.6790181619542;
kap    = 0.015;

%Load calibrated parameters (if commented, uses values above)
load input_files/calib_params_row
Busd_l = Busd;
Busd_p = Busd;
Beur_l = Beur;
Beur_p = Beur;
Brow_p = Brow;
Brow_l = Brow;

%Fixed parameters
bet    = 0.96^(1/per_p_year); %Discount Factor
sig    = 1.00;                 %IES
eta    = 1.00;%1.01;                   %Elasiticty of subs. across good.1
alph   = 0.5;                 %Nash share in trade
tau    = 0.04;%0.045;               %Adj. cost of bonds: 20% change in holding costs 10 basis points ((10000*(.05/2)*(.2)^2) = 10)
taup   = 0*tau;               %Internalized adj cost?
tau_row = 0.00;               %Cost of hold ROW bonds
vepst  = 0.01; 0.25;           %Matching elasticity in trade
omg    = 1;                   %frac of firm reoptimizing every period
Prw_rw = 1;                   %Numeraire
Xus    = 0.90;                 %US traders use of $
Xeu    = 1 - Xus;             %EU traders use of eur
z      = 0;                   %RW traders exog use of $/eur
zrow   = .01;                 %Usage of ROW asset

mu_us = 1/5;           %Size US
mu_eu = 1/5;           %Size EU
mu_rw = 1-mu_us-mu_eu; %Size RW

Yus =  12/per_p_year*1;     %Endowment GDP
Yeu =  12/per_p_year*1;     %Endowment GDP
Yrw =  12/per_p_year*1;     %Endowment GDP

phi_usg = 0;           %Government share US
phi_eug = 0;           %Government share EU
phi_rwg = 0;           %Government share RW

%Put tarrif everwhere

trf        = 0*0.25; %Common tariff
trf_cap    = 0*0.0001; 

if trf>0
    disp('WARNING: TARIF ON!')
    pause(1)
end

tax_us_eu  = 1*trf;
tax_us_rw  = 1*trf;
tax_eu_us  = 1*trf;
tax_eu_rw  = 0*trf;
tax_rw_us  = 1*trf;
tax_rw_eu  = 0*trf;
tax_rw_row = 0*trf;

% tax_us_eu  = trf;
% tax_us_rw  = trf;
% tax_eu_us  = trf;
% tax_eu_rw  = trf;
% tax_rw_us  = trf;
% tax_rw_eu  = trf;
% tax_rw_row = trf;

tax_us_in  = 1*trf_cap; 
tax_us_out = 0*trf_cap;
tax_eu_in  = 1*trf_cap; 
tax_eu_out = 0*trf_cap; 
tax_rw_out = 0*trf_cap; 

dtax_us_eu=0;
dtax_us_rw=0;
dtax_eu_us=0;
dtax_eu_rw=0;
dtax_rw_us=0;
dtax_rw_eu=0;
dtax_rw_row=0;


%%%%% Comparative statics on parameters 
%Busd  = 1.2*Busd; 
%Beur  = 1.31*Beur;
%r     = .01*r; 
%phi   = 1*phi; 
%kap   = 0.1*kap;
%ah_us = 0.7*ah_us; 
%ah_eu = ah_us; 
%ah_rw = ah_us; 
%vepsf  = 1.5*vepsf; 
%Beur = 1.3*Busd;

%**************************************************************************
% Solving steady-state
%**************************************************************************
options = optimset('fsolve');
options.Display = 'iter';
options.MaxFunEvals = 185000;
options.MaxIter = 5000;
options.TolX = 1e-16;
options.TolFun = 1e-19;
options.DerivativeCheck = 'on';
options.Jacobian = 'on';
options.FinDiffType = 'center';
log_idx = [];

%Initial values by hand
x0 = 0*rand(neq-4,1)+1;
x0([qusd_idx,qeur_idx])         = bet;
x0(13:21)                       = 1;
x0([m_us_idx:m_rw_idx])         = 2; %P home cons good
%x0([pus_im_idx:prw_im_idx])     = .5;  %Probs of importing
%x0([sbar_rw_idx])               = 0; %Cutoffs
%x0([bus_usd_idx:beu_eur_idx])   = 10;
%x0 = x0 + .05*randn(27,1);

%Initial values by saved
% load xout.mat xout
% 
% x0 = xout(1:21);
% 
% if endog_all
%     x0(22:neq-2) = -2; %Want to start with < 1/4 to be safe, exponential transformation to [-inf,inf]
% elseif endog_ctry
%     x0(22:neq-2) = 1/3; %Want to start with < 1/2 to be safe
% end
%x0(neq-1:neq) = xout(end-1:end);
load input_files/xout_row xout
x0 = xout;


%The objective
obj = @(x) steady_residual(x,log_idx,...
    Busd,Beur,Brow,Busd_l,Beur_l,Brow_l,Busd_p,Beur_p,Brow_p,tau,taup,tau_row,alph,vepsf,vepst,kap,phi,r,sige,mu_us,mu_eu,mu_rw,Yus,Yeu,Yrw,phi_usg,phi_eug,phi_rwg,bet,sig,eta,ah_us,ah_eu,ah_rw,Prw_rw,Xus,Xeu,z,zrow,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);

[a,b]  = obj(x0);


[xout,fout,flag] = fsolve(obj,x0, options);
disp(['Max resid at x0: ' num2str2(max(abs(a)))]);
disp(['Max resid at xout: ' num2str2(max(abs(fout)))]);
xout(log_idx) = exp(xout(log_idx));
xfinal        = xout;

save_list = {'bet','kap','r','alph','sige','tau','phi','veps*','*usd*', '*eur*', 'mu*', '*us', '*eu', '*rw', '*_p_*', 'xout', '*_steady','frac_ss','xspecial_long','GDs','TSHRs','Xs','table_dat'};

%% FIND ALL STEADY-STATES
save_str = 'row'; %the baseline steady-state

steady_state_finder_row
disp_params
xspecial(s_idx,:)
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end

