%Create mex file with def_subs step integrated into it.

function [fcall] = sym2mex_double(out_nms,out_val,def_nms,def_val,in_vars,orig_file,dest_file,call_name,outdir)


nnin = length(in_vars);
nnout = length(out_val);


%Make input args
in_decl = ['double '];
in_accs = cell(nnin+1,1);
for jj = 1:nnin
   in_decl = [in_decl, char(in_vars(jj)) ',']; 
   in_accs{jj+1} = [char(in_vars(jj)) '= mxGetScalar(prhs[' num2str(jj-1) ']);'];
end
in_decl(end) = ';';
in_accs{1} = in_decl;
warn_str_in = {['if (nrhs == ' num2str(nnin) ')  {} else{mexErrMsgTxt(" ' num2str(nnin) ' inputs arguments required.");}']};
warn_str_out = {['if (nlhs == ' num2str(nnout) ')  {} else{mexErrMsgTxt(" ' num2str(nnout) ' inputs arguments required.");}']};

%Make def_subs
def_decl = ['double '];
def_comp = cell(2,1);
nndef = length(def_nms);
for jj = 1:nndef
   def_decl = [def_decl, def_nms{jj} ','] ;
   def_comp{jj}   = [def_nms{jj} ' = ' pow_sym(trap_integers(char(def_val{jj}))) ';'];     
end
def_decl(end) = ';';


%Make output args
out_decl   = ['double '];
out_create = cell(nnout,1);
out_point  = cell(nnout,1);
out_comp   = cell(2,1);
for jj = 1:nnout
     out_decl = [out_decl, '*' out_nms{jj} ',']; 
     out_create{jj} = ['plhs[' num2str(jj-1) '] = mxCreateDoubleMatrix(' num2str(size(out_val{jj},1)) ',' num2str(size(out_val{jj},2)) ',mxREAL);'];
     out_point{jj+1} = [out_nms{jj} '= mxGetPr(plhs[' num2str(jj-1) ']);'];
     
     %for each value
     counter = 0;
     size_out = size(out_val{jj});
     for ii = 1:size_out(2)
         for kk = 1:size_out(1)
             out_comp{end+1}   = [out_nms{jj} '[' num2str(counter) '] = ' pow_sym(trap_integers(char(out_val{jj}(kk,ii)))) ';'];
             counter = counter+1;
         end
     end
 end
 out_decl(end) = ';';
 out_point{1} = out_decl;


text_insert_dollar(orig_file, dest_file, {warn_str_in,warn_str_out,in_accs,def_decl,def_comp,out_create,out_point,out_comp});

mex_call = ['mex -largeArrayDims '  dest_file];
if nargin > 8
    mex_call = [mex_call ' -outdir ' outdir ];
end
eval(mex_call);


% make function call
fcall = '[';
for jj = 1:nnout
    fcall = [fcall out_nms{jj}, ','];
end
fcall(end) = ']';

fcall = [fcall '= ' call_name '('];
for jj = 1:nnin
    fcall = [fcall, char(in_vars(jj)) ','];
end
fcall(end) = ')';
fcall = [fcall,';'];