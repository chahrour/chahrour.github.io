%Rewrites text to use pow rather than ^

function txt = pow_sym(txt)


txt= char_undot(txt);


deq_idx = strfind(txt, '==');

if ~isempty(deq_idx)
    txt(deq_idx) = [];
end

jj = find(txt=='^', 1);
while ~isempty(jj)
    
    %********************************
    %EXPONENT
    %********************************
    
    if txt(jj+1)=='('
        pexp = 1;
        plev = 1;
        idx_pow = jj+1;
        while plev>0
            idx_pow = idx_pow+1;
            if txt(idx_pow)=='('
                plev = plev+1;
            elseif txt(idx_pow)==')'
                plev = plev-1;
            end
        end
        pow_exp = txt(jj+2:idx_pow-1);        
    else
        pexp = 0;
        idx_pow = jj+1;
        while idx_pow<=length(txt) && txt(idx_pow)~=' ' && txt(idx_pow)~='*' && txt(idx_pow)~='/' && txt(idx_pow)~=')' && txt(idx_pow)~='+' && txt(idx_pow)~='-' && txt(idx_pow) ~= ';'
            idx_pow = idx_pow+1;
        end
        pow_exp = txt(jj+1:idx_pow-1);
    end
    
    %********************************
    %FIND BASE TERM
    %********************************
    %If close parathesis
    if txt(jj-1) == ')'
        pbase = 1;
        plev = 1;
        idx = jj-1;
        while plev > 0
            idx = idx-1; %Go back one spot
            if txt(idx)==')'
                plev = plev + 1;
            elseif txt(idx)=='('
                plev = plev - 1;
            end
        end
        %Having found the matching parenthsis, replace with pow.
        
        base = txt(idx+1:jj-2);
        
    else
        pbase = 0;
        %Find limits of variable that is exponentiated
        idx = jj-1;
        while idx>0&&txt(idx)~=' '&&txt(idx)~='*' && txt(idx)~='/' && txt(idx)~='(' && txt(idx)~='+' && txt(idx)~='-' 
            idx = idx-1;
        end
        base = txt(idx+1:jj-1);
           
    end
%      pbase
%      base
%     pow_exp
%     pause
    txt_replace = ['pow(' base ',', pow_exp, ')' ];

      
    
    %********************************
    %UPDATESTRING
    %********************************
    text_new = [txt(1:idx-pbase), txt_replace, txt(idx_pow+pexp:end)];
    
    txt = text_new;

    
    jj = find(txt=='^', 1);    
    
end

