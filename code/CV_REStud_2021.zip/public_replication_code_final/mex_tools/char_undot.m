function s = char_undot(s)

idx_dot = s=='.';

idx_drop = idx_dot;
for jj = find(idx_dot)

    if sum(strcmp(s(jj+1), {'*', '^', '/'}))==0
        idx_drop(jj) = false;
    end
end

s(idx_drop) = [];
