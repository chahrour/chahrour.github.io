
%%% Load data
[invshr_exp, invshrexp_str] = xlsread('appendix_data/Invoicing Share.xlsx',2); 
invshr_exp = invshr_exp(1:end-1,:); 

invshr_exp([50],:) = []; %% Drop US

country_list_exp = invshrexp_str(2:end,1); 
country_list_exp([50],:) = []; 

[invshr_imp, invshrimp_str] = xlsread('appendix_data/Invoicing Share.xlsx',3); 
invshr_imp = invshr_imp(1:end-1,:); 

invshr_imp([50],:) = []; %% Drop US 

country_list_imp = invshrimp_str(2:end,1); 
country_list_imp([50],:) = []; 

country_list_same = NaN(length(country_list_imp),1); 

for i = 1:length(country_list_imp)
    country_list_same(i) = strcmp(country_list_imp(i), country_list_exp(i));
end

%%%% Mergin the two -- no Malaysia in imports, and no Morocco in exports

invshr_imp = [invshr_imp(1:29,:); NaN(1,size(invshr_imp,2)); invshr_imp(30:end,:)];
country_list_imp = [country_list_imp(1:29); 'Malaysia'; country_list_imp(30:end)]; 

invshr_exp = [invshr_exp(1:31,:); NaN(1,size(invshr_exp,2)); invshr_exp(32:end,:)];
country_list_exp = [country_list_exp(1:31); 'Morocco'; country_list_exp(32:end)]; 

country_list_same = NaN(length(country_list_imp),1); 

for i = 1:length(country_list_imp)
    country_list_same(i) = strcmp(country_list_imp(i), country_list_exp(i));
end

%%%% Foreign Debt Assets
[ debtassets_data, debtassets_str] = xlsread('appendix_data/DebtAssets_CPIS.xlsx',1); 
debtassets_data = [ NaN(1,size(debtassets_data,2)); debtassets_data];   %%% No data for Algeria in position 1 
debtassets_data = debtassets_data(1:end-1,end-1:-1:1)/1e6;    %%%% order 2001-2019 from left to right

%%%% US Debt Assets 
[ us_debtassets_data, us_debtassets_str] = xlsread('appendix_data/USDebtAssets_CPIS.xlsx',1); 
us_debtassets_data = [ NaN(1,size(us_debtassets_data,2)); us_debtassets_data];   %%% No data for Algeria in position 1
us_debtassets_data = us_debtassets_data(:,end-1:-1:1)/1e6; %%%% order 2001-2019 from left to right

%%%% USD Debt Assets 
[ fx_debtassets_data, fx_debtassets_str] = xlsread('appendix_data/DebtAssets_FXdenom_CPIS.xlsx',1); 
fx_debtassets_data = fx_debtassets_data(5:end-1,2:end)/1e6; 

fx_debtassets_data_array = NaN(size(fx_debtassets_data,1), 19,6);  %%% 19 years, 6 categories of FX denominated bonds 

column_num = 1; 
for i = 1:19
    
    for j = 1:6
        fx_debtassets_data_array(:,20-i,j) = fx_debtassets_data(:,(i-1)*6+j); 
    
    end
end

%%%% GDP 
[ gdp_data, gdp_str] = xlsread('appendix_data/GDP_worldbank.xlsx',1); 
gdp_data = gdp_data(1:end-1,3:end)/1e6; 

%%%% Imports (Total)
[ imports_data, imports_str] = xlsread('appendix_data/Imports_IMF.xlsx',1); 
imports_data = imports_data(1:end-1,end-2:-1:1)/1e6; 

%%%% Exports (Total)
[ exports_data, exports_str] = xlsread('appendix_data/Exports_IMF.xlsx',1); 
exports_data = exports_data(1:end-1,end-2:-1:1)/1e6; 

%%%% US exports
[ us_exports_data, us_exports_str] = xlsread('appendix_data/USExports_Census.xlsx',1); 
us_exports_data = us_exports_data(3:end,3:end)/1e6; 

%%%% US imports
[ us_imports_data, us_imports_str] = xlsread('appendix_data/USImports_Census.xlsx',1); 
us_imports_data = us_imports_data(3:end,3:end)/1e6; 


[lbs_data, lbs_data_str] = xlsread('appendix_data/BIS_locbank.xlsx',2); 
lbs_data = [NaN(2,size(lbs_data,2)); lbs_data]; %%% pad for missing first 2 rows when loading
lbs_data = [lbs_data(1:29,:); NaN(1,size(lbs_data,2)); lbs_data(30:end,:)];  %%% make same ordering as invoice share data 
lbs_data(end,:) = [];   % drop the US



%%% Merge
drop_index = [23; 29; 30; 32; 36];   %%% dropping Ireland, Luxembourg, Malaysia, Morocco and Peru
drop_invshr_countries = country_list_exp(drop_index); %country_list_exp(find(diff(macrodata_pos) > 1)+1);

country_list_exp(drop_index,:) = []; 
country_list_imp = country_list_exp; 

invshr_exp(drop_index,:)   = []; 
invshr_imp(drop_index,:)   = []; 

lbs_data(drop_index,:)   = []; %Drop Luxembourg, Malaysia, Morocco and Peru


drop_index_macro = [23; 29; 31; 35];

debtassets_data(drop_index_macro,:) = []; 
us_debtassets_data(drop_index_macro,:) = []; 
fx_debtassets_data_array(drop_index_macro,:,:) = []; 
gdp_data(drop_index_macro,:) = []; 
imports_data(drop_index_macro,:) = []; 
exports_data(drop_index_macro,:) = []; 
us_exports_data(drop_index_macro,:) = []; 
us_imports_data(drop_index_macro,:) = []; 



euro_dummy = zeros(length(country_list_exp),1); 
euro_dummy([4;5;11; 14; 15;16;17;18;24;26;27;28;29;33;35;36;39  ]) = 1; 

euro_dummy2 = zeros(length(country_list_exp),1); 
euro_dummy2([4;5;  15;16;17;18;24;29;33;39  ]) = 1; 


inv_data_exp = invshr_exp; 
inv_data_imp = invshr_imp; 

start_ind = inv_data_exp(:,10) - 2000; 
start_ind(start_ind < 1) = 1; 
end_ind  = inv_data_exp(:,11) - 2000; 


totalfx_debtassets = NaN(size(gdp_data,1),1); 
gdp = NaN(size(gdp_data,1),1); 
usdenom_debtassets = NaN(size(gdp_data,1),1); 
usdebt_assets = NaN(size(gdp_data,1),1); 

debt_assets = NaN(size(gdp_data,1),1); 
us_imports = NaN(size(gdp_data,1),1); 
us_exports = NaN(size(gdp_data,1),1); 
exports = NaN(size(gdp_data,1),1); 
imports = NaN(size(gdp_data,1),1); 

for i = 1:size(gdp,1)
   
    totalfx_debtassets(i)    = nanmean(sum(fx_debtassets_data_array(i,start_ind(i):end_ind(i),:),3)); 
    gdp(i)                   = nanmean(gdp_data(i,start_ind(i):end_ind(i))); 
    usdenom_debtassets(i)    = nanmean(fx_debtassets_data_array(i,start_ind(i):end_ind(i),6)); 
    usdebt_assets(i)         = nanmean(us_debtassets_data(i,start_ind(i):end_ind(i))); 
    debt_assets(i)           = nanmean(debtassets_data(i,start_ind(i):end_ind(i))); 

    us_imports(i)            = nanmean(us_imports_data(i,start_ind(i):end_ind(i))); 
    us_exports(i)            = nanmean(us_exports_data(i,start_ind(i):end_ind(i))); 
    exports(i)               = nanmean(exports_data(i,start_ind(i):end_ind(i))); 
    imports(i)               = nanmean(imports_data(i,start_ind(i):end_ind(i))); 
    
    %shr_us_debtassets(i)     = nanmean( us_debtassets_data(i,start_ind(i):end_ind(i))./debtassets_data(i,start_ind(i):end_ind(i)));
    %shr_ustrade(i)           = nanmean( (us_exports_data(i,start_ind(i):end_ind(i)) + us_imports_data(i,start_ind(i):end_ind(i)))./(exports_data(i,start_ind(i):end_ind(i)) + imports_data(i,start_ind(i):end_ind(i))));
    
end
%}

%%%


bankliab_tononbank_usd_gdp_gs = lbs_data(:,8)./gdp; 
%shr_bankliab_tononbank_usd_gs = lbs_data(:,8)./lbs_data(:,7); 


usdenom_debtassets_gdp = usdenom_debtassets./gdp;
ustrade_gdp = (us_imports + us_exports)./gdp; 
usdebtassets_gdp  = usdebt_assets./gdp; 


shr_ustrade = (us_exports + us_imports)./(exports + imports); 
shr_us_debtassets = usdebt_assets./debt_assets;
shr_usdenom_debtassets = usdenom_debtassets./totalfx_debtassets; 





invshr_usd_exp  = inv_data_exp(:,2); 
invshr_usd_imp  = inv_data_imp(:,2); 
invshr_usd_exp_fc      = inv_data_exp(:,9); 
invshr_usd_imp_fc      = inv_data_imp(:,9); 

invshr_usd         = invshr_usd_exp.*exports./(exports + imports) + invshr_usd_imp.*imports./(exports + imports); 
invshr_usd_fc      = invshr_usd_exp_fc.*exports./(exports + imports) + invshr_usd_imp_fc.*imports./(exports + imports); 

usdinv_imp      = invshr_usd_imp.*imports; 
usdinv_imp_gdp      = invshr_usd_imp.*imports./gdp; 

usdinv_exp      = invshr_usd_exp.*exports; 
usdinv_exp_gdp      = invshr_usd_exp.*exports./gdp; 
usdinv_trade_gdp = usdinv_imp_gdp + usdinv_exp_gdp;


%% Regressions

%%%% Main 
table_dat = NaN(9,5);


[b,bint,r,~,stats] = regress( invshr_usd, [ones(length(invshr_exp),1), shr_us_debtassets, euro_dummy]); 
b_se = (bint(:,2) - b)/1.96; 
table_dat(1,1)=  b(2);
table_dat(2,1)=  b_se(2);
table_dat(8,1)   =  stats(1);
table_dat(9,1)   =  sum(~isnan(r));

[b,bint,r,~,stats] = regress( invshr_usd(isfinite(shr_us_debtassets)), [ones(length(invshr_exp(isfinite(shr_us_debtassets))),1), shr_ustrade(isfinite(shr_us_debtassets)), euro_dummy(isfinite(shr_us_debtassets))]); 
b_se = (bint(:,2) - b)/1.96; 
table_dat(3,2)=  b(2);
table_dat(4,2)=  b_se(2);
table_dat(8,2)   =  stats(1);
table_dat(9,2)   =  sum(~isnan(r));

[b,bint,r,~,stats] = regress( invshr_usd, [ones(length(invshr_exp),1), shr_us_debtassets, shr_ustrade, euro_dummy]); 
b_se = (bint(:,2) - b)/1.96; 
table_dat([1,3],3)=  b(2:3);
table_dat([2,4],3)=  b_se(2:3);
table_dat(8,3)   =  stats(1);
table_dat(9,3)   =  sum(~isnan(r));

[b,bint,r,~,stats] = regress( invshr_usd, [ones(length(invshr_exp),1), shr_usdenom_debtassets, euro_dummy]); 
b_se = (bint(:,2) - b)/1.96; 
table_dat(5,4)=  b(2);
table_dat(6,4)=  b_se(2);
table_dat(8,4)   =  stats(1);
table_dat(9,4)   =  sum(~isnan(r));

[b,bint,r,~,stats] = regress( invshr_usd, [ones(length(invshr_exp),1), shr_usdenom_debtassets, shr_ustrade, euro_dummy]); 
b_se = (bint(:,2) - b)/1.96;  
table_dat([3,5],5)=  b(2:3);
table_dat([4,6],5)=  b_se(2:3);
table_dat(8,5)   =  stats(1);
table_dat(9,5)   =  sum(~isnan(r));

disp(' ');
disp('*******************************************************************')
disp('Table 6:')
disp('*******************************************************************')


cols = {'', '1','2','3','4','5'};
rows = {'HoldUS','SE', 'TrdUS','SE', 'HoldUSD','SE','EurDum', 'R2', 'N'};

sprint_mat('% 1.2f\t',table_dat,cols,rows);
disp(' ');
%% Appendix Table 7


table_dat = nan(11,4);

[b5,bint,r,~,stats] = regress( bankliab_tononbank_usd_gdp_gs, [ones(length(invshr_exp),1),  usdebtassets_gdp,  ustrade_gdp, euro_dummy]); 
b_se = (bint(:,2) - b5)/1.96;  

table_dat(1:2:3,1)=  b5(2:3);
table_dat(2:2:4,1)=  b_se(2:3);
table_dat(10,1)   =  stats(1);
table_dat(11,1)   =  sum(~isnan(r));

[b5,bint,r,~,stats] = regress( bankliab_tononbank_usd_gdp_gs, [ones(length(invshr_exp),1),  usdenom_debtassets_gdp,  ustrade_gdp, euro_dummy]); 
b_se = (bint(:,2) - b5)/1.96; 

table_dat(3:2:5,2)=  b5(3:-1:2);
table_dat(4:2:6,2)=  b_se(3:-1:2);
table_dat(10,2)   =  stats(1);
table_dat(11,2)   =  sum(~isnan(r));


[b5,bint,r,~,stats] = regress( bankliab_tononbank_usd_gdp_gs, [ones(length(invshr_exp),1),  usdebtassets_gdp,  usdinv_trade_gdp, euro_dummy]); 
b_se = (bint(:,2) - b5)/1.96; 

table_dat([1,7],3)=  b5(2:3);
table_dat([2,8],3)=  b_se(2:3);
table_dat(10,3)   =  stats(1);
table_dat(11,3)   =  sum(~isnan(r));

[b5,bint,r,~,stats] = regress( bankliab_tononbank_usd_gdp_gs, [ones(length(invshr_exp),1),  usdenom_debtassets_gdp,  usdinv_imp_gdp, euro_dummy]); 
b_se = (bint(:,2) - b5)/1.96; 

table_dat([5,7],4)=  b5(2:3);
table_dat([6,8],4)=  b_se(2:3);
table_dat(10,4)   =  stats(1);
table_dat(11,4)   =  sum(~isnan(r));

disp(' ');
disp('*******************************************************************')
disp('Table 7:')
disp('*******************************************************************')

cols = {'', '1','2','3','4'};
rows = {'HoldUS','SE', 'TrdUS','SE', 'HoldUSD','SE', 'USDinv','SE', 'EurDum', 'R2', 'N'};

sprint_mat('% 1.2f\t',table_dat,cols,rows);
