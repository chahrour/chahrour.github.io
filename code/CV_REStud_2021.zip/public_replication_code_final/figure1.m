%% FIGURE 1 : BASELINE - ATTRACTION REGIONS 
load saved_results/sym_to_dollar_transition frac_path
load saved_results/attraction_region_baseline frac_rw_usd_dense frac_rw_eur_dense solve_indic frac_ss


f1 = figure;
%f1.PaperPosition = [.25, .25, 7,7];
s = subplot(1,1,1);hold on;
s.XLim = frac_rw_usd_dense([1,end]);
s.YLim = frac_rw_eur_dense([1,end]);
s.FontSize = 14;
Y1 = fliplr(frac_rw_eur_dense);
X1 = nan(1,length(frac_rw_usd_dense));
for jj = 1:length(X1)
    X1(jj) = frac_rw_usd_dense(find(solve_indic{jj}<1e-5, 1, 'last'));
end

X = [max(frac_rw_usd_dense), X1,min(frac_rw_usd_dense),fliplr(Y1),max(frac_rw_usd_dense)];
Y = [max(frac_rw_eur_dense), Y1,min(frac_rw_eur_dense),fliplr(X1),max(frac_rw_eur_dense)];
p1= patch(X,Y, color_mul);
p1.LineStyle = '-';
p1.LineWidth = .1;

X = [max(frac_rw_usd_dense), X1,max(frac_rw_usd_dense),max(frac_rw_usd_dense)];
Y = [max(frac_rw_eur_dense), Y1,min(frac_rw_eur_dense),max(frac_rw_usd_dense)];
p2 = patch(X,Y, color_usd);
p2.LineStyle = '-';
p2.LineWidth = .1;

X = [fliplr(Y1),min(frac_rw_usd_dense)];
Y = [fliplr(X1),max(frac_rw_eur_dense)];
p3 = fill(X,Y, color_eur);
p3.LineStyle = '-';
p3.LineWidth = .1;

p = scatter(frac_ss(1,[1,3]),frac_ss(2,[1,3]), 'marker', 'o', 'SizeData',75, 'MarkerEdgeColor', [0,0,0], 'MarkerFaceColor', [0 0 0]);
p = scatter(frac_ss(1,2),frac_ss(2,2), 'marker', 'o', 'SizeData', 90, 'MarkerEdgeColor', [0,0,0], 'MarkerFaceColor', [1 1 1]);

xlabel('RW USD bond holdings (fraction of $\bar{B}$)', 'interpreter', 'latex', 'fontsize',18);
ylabel('RW EUR bond holdings (fraction of $\bar{B}$)', 'interpreter', 'latex', 'fontsize',18);


%Add flight path to region
p = plot(frac_path(1,1:70),frac_path(2,1:70), '-k', 'linewidth', 2.5);
a=annotation('arrow', frac_path(1,[end-100,end-75]), frac_path(2,[end-100,end-75]));
a.Parent     = gca;
a.HeadWidth  = 8;
a.HeadLength = 8;
a.Color  = [.7,.7,.7]';
p.Color  = [.7,.7,.7]';
l = legend([p2,p3,p1],'Dollar','Euro', 'Indet.', 'location', 'northeast');
l.FontSize = 14;
saveas(f1, 'saved_figures/figure1.eps', 'epsc')
