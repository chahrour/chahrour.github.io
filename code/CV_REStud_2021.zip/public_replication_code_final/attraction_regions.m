%% make initial grid
frac_rw_usd_dense = linspace(.2,.85,131);
frac_rw_eur_dense = linspace(.2,.85,131);
[grid_rw_usd_dense,grid_rw_eur_dense] = ndgrid(frac_rw_usd_dense,frac_rw_eur_dense);

%% shooting solver settings
T = 220*per_p_year;
%log_idx = [];

options = optimoptions('fsolve');   
options.Display = 'off';
options.MaxIterations = 800;

options.FiniteDifferenceType = 'central';
options.SpecifyObjectiveGradient = true;
options.CheckGradients = false;

solve_indic = cell(length(frac_rw_usd_dense),1);
bond_path   = cell(length(frac_rw_usd_dense),1);
polc_path   = cell(length(frac_rw_usd_dense),1);

for jj = 1:length(bond_path(:))
    bond_path{jj} = nan(4,10);
end

%ALWAYS LANDING AT
eq_idx = 3;%Euro steady
targ_ss = xspecial_long(:,eq_idx);  
    
 
%% crawl the diagonal
for ii_parf = 1:length(frac_rw_eur_dense)
    disp(num2str(ii_parf));
    
    ii = length(frac_rw_eur_dense)+1-ii_parf;
    
    solve_indic{ii_parf} = NaN(1,length(frac_rw_usd_dense));
    bond_path{ii_parf} = cell(1,length(frac_rw_usd_dense));
    polc_path{ii_parf} = cell(1,length(frac_rw_usd_dense));
    
    %initial starting point
    if ii_parf == 1
        xshoot_final = repmat(targ_ss,[1,T]);
    end
    
    %FLYING FROM:
    frac_shoot = [frac_rw_usd_dense(ii),frac_rw_eur_dense(ii),0.90,0.90]; %leaning dollar
    X0 = frac2B(frac_shoot(:),Busd,Beur,mu_us,mu_eu,mu_rw);
    
    %SHOOT
    shoot_ = @(x) shooting(x,X0,targ_ss,T,log_idx,neq,nstate,[],...
            Busd,Beur,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,Yus,Yeu,Yrw,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);

    % Solve the shoot
    [xshoot_final,fval] = fsolve(shoot_,xshoot_final(:),options);
    
    [~,~,~,dfinal] = shoot_(xshoot_final);
    
    xshoot_final=reshape(xshoot_final,[neq+nstate,T]);
    
    % Store results
    xshoot_final(log_idx,:) = exp(xshoot_final(log_idx,:));
    polc_path{ii_parf}{ii_parf} = xshoot_final ;
    
    if sum(fval.^2) + sum(dfinal.^2)>1e-5
        error('missed on diagonal, try again');
    end
    
end


%% Now try to creep to the right
options.MaxIterations = 30;
options.Display = 'final';
parfor ii_parf = 1:length(frac_rw_eur_dense)
    
    %To make parfor happy
    ii = length(frac_rw_eur_dense)+1-ii_parf;
    
    %initial starting point
    xshoot_final = polc_path{ii_parf}{ii_parf};
    
    %try to drift right
    jj = ii;
    crit =0;
    
    while crit<1 && jj<=length(frac_rw_usd_dense)
        
        
        %FLYING FROM:
        frac_shoot = [frac_rw_usd_dense(jj),frac_rw_eur_dense(ii),0.90,0.90]; %leaning dollar
        X0 = frac2B(frac_shoot(:),Busd,Beur,mu_us,mu_eu,mu_rw);
        

        % starting point
        xshoot = xshoot_final;
        
        shoot_ = @(x) shooting(x,X0,targ_ss,T,log_idx,neq,nstate,[],...
            Busd,Beur,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,Yus,Yeu,Yrw,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);

        % Solve the shoot
        [xshoot_final,fval] = fsolve(shoot_,xshoot(:),options);
       
        [~,~,~,dfinal] = shoot_(xshoot_final);
        
        xshoot_final=reshape(xshoot_final,[neq+nstate,T]);
        
        %the final paths
        xshoot_final(log_idx,:) = exp(xshoot_final(log_idx,:));
        bond_path{ii_parf}{jj} = [frac_shoot(:),B2frac(xshoot_final(neq+(1:4),:),Busd,Beur,mu_us,mu_eu,mu_rw)];
        bond_path_tmp = [X0,xshoot_final(neq+(1:4+xstate),:)];
        
        solve_indic{ii_parf}(jj) = sum(fval.^2);
     
        crit = sum(fval.^2)+sum(dfinal.^2);
        jj = jj+1;
    end
    
end


