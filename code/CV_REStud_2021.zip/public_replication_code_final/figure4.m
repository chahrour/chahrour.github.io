%% FIGURE 4: RW EMERGES FLIGHT PATH

f = figure;
f.PaperPosition = [.25, .25, 11,5.3];
load saved_results/steady_baseline per_p_year


load saved_results/rw_emerges_transition *_out usd_use usd_shrs Brw_usd xshoot_final mu_*


Brw_usdv = xshoot_final(35,:);
Brw_eurv = xshoot_final(36,:);

yrs=200;
xgrid = (0:per_p_year:per_p_year*(yrs-1))/per_p_year;
yidx  = 1:per_p_year:per_p_year*yrs;


s = subplot(2,2,1);
plot(xgrid,mu_us(:,yidx)','linewidth' ,2.5); hold on;
plot(xgrid,mu_rw(:,yidx)','linewidth' ,2.5,'Color',color_eu,'LineStyle',ls_eu);
title('Size')
xlabel('years')
legend('\mu_{us}', '\mu_{rw}');
hold on
s.FontSize = 12;
s.XLim = [0,60];
s.XTick = [0:15:60];
s.XTickLabels = [1960:15:2020];

s = subplot(2,2,2);
plot(xgrid,usd_use(yidx),'linewidth' ,2.5,'color',color_rw, 'LineStyle', ls_rw);
title('USD use by RW firms (X_{rw})')
xlabel('years')
s.FontSize = 12;
s.XLim = [0,60];
s.XTick = [0:15:60];
s.XTickLabels = [1960:15:2020];

s = subplot(2,2,3);
plot(xgrid,ep_out(1,yidx)','linewidth' ,2.5); hold on;
title(['r^$ - r^' char(8364) ' (%)'])
xlabel('years')
s.YLim = [0,2.25];
s.FontSize = 12;
s.XLim = [0,60];
s.XTick = [0:15:60];
s.XTickLabels = [1960:15:2020];
s.YLim = [.5,1.6];

s=subplot(2,2,4);
plot(xgrid,Brw_usdv(yidx),'linewidth' ,2.5,'color',color_rw, 'LineStyle', ls_rw);hold on;
title('RW USD bond holdings');
s.YLim = [0,2.25];
s.FontSize = 12;
s.XLim = [0,60];
s.XTick = [0:15:60];
s.XTickLabels = [1960:15:2020];
s.YLim = [.7,1.2];

saveas(f,'saved_figures/figure4.eps', 'epsc');

