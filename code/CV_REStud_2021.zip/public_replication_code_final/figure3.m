%% FIGURE 3: EMERGENCE/DOMINANCE OF EURO - FLIGHT PATH
f = figure;
f.PaperPosition = [.25, .25, 11,8];
load saved_results/steady_beforeur cons_steady per_p_year Busd

yrs=41;
xgrid = (0:per_p_year:per_p_year*(yrs-1))/per_p_year;
yidx  = 1:per_p_year:per_p_year*yrs;
ls = {'-', '-.'};
for j = 1:2
    
    if j == 1
        load saved_results/eur_emerges_transition *_out usd_use usd_shrs Beur
    else
        load saved_results/eur_takesover_transition *_out usd_use usd_shrs Beur
    end
    
  
    s = subplot(3,2,1);
    plot(xgrid,Beur(:,yidx)'./Busd,'linewidth' ,2.5,'LineStyle', ls{j}); hold on;
    if j == 2
        title('EZ safe assets/US safe assets')
        xlabel('years')
        s.XTick = [0,10,20,30,40];    s.XTickLabel = [1996, 2007, 2017, 2017+10, 2017+20];
        s.FontSize = 12;
        legend('EUR introduction', 'EUR continued growth', 'location', 'southeast')
    end
    
    s = subplot(3,2,2);
    plot(xgrid,usd_use(yidx),'linewidth' ,2.5,'LineStyle', ls{j});   hold on;
    if j == 2
        title('USD use by RW firms (X_{rw})')
        xlabel('years')
        s.XTick = [0,10,20,30,40];    s.XTickLabel = [1996, 2007, 2017, 2017+10, 2017+20];
        s.FontSize = 12;
    end
    
    s = subplot(3,2,3);
    plot(xgrid,ep_out(1,yidx)','linewidth' ,2.5,'LineStyle', ls{j}); hold on;
    if j == 2
        hold on;plot(xgrid,0*xgrid,':k');
        title(['r^$ - r^' char(8364) ' (%)'])
        xlabel('years')
        s.YLim = [-2.25,2];
        s.XTick = [0,10,20,30,40];    s.XTickLabel = [1996, 2007, 2017, 2017+10, 2017+20];
        s.FontSize = 12;
    end
    
    s=subplot(3,2,4);
    plot(xgrid,usd_shrs(3,yidx),'linewidth',2.5,'LineStyle', ls{j});    hold on;
    if j == 2
        title('RW USD bond portfolio share')
        xlabel('years')
        s.XTick = [0,10,20,30,40];    s.XTickLabel = [1996, 2007, 2017, 2017+10, 2017+20];
        s.FontSize = 12;
    end

    s=subplot(3,2,5);
    plot(xgrid,nfa_out(1,yidx)','linewidth' ,2.5,'LineStyle', ls{j}); hold on;
    if j == 2
        title('US net foreign assets')
        xlabel('years')
        s.XTick = [0,10,20,30,40];    s.XTickLabel = [1996, 2007, 2017, 2017+10, 2017+20];
        s.FontSize = 12;
    end
    
    s=subplot(3,2,6);
    plot(xgrid,100*log(con_out(1,yidx)./cons_steady(1,1)),'linewidth' ,2.5,'LineStyle', ls{j});hold on;
    if j == 2
        hold on; plot(xgrid,0*xgrid,':k');
        title('US cons. relative to intial s.s. (%)')
        xlabel('years')
        s.XTick = [0,10,20,30,40];    s.XTickLabel = [1996, 2007, 2017, 2017+10, 2017+20];
        s.FontSize = 12;
        s.YLim = [-2.5, .1];
    end
end

saveas(f,'saved_figures/figure3.eps', 'epsc');
