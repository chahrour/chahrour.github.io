%Find steady-state by trying different initial asset usages

%Grid to try
ntest = 51;
sgrid = linspace(-4,4,ntest);

%Starting values
x0test = xout(:);
x0test(log_idx) = log(xout(log_idx));

%Optimizer options
ss_opt = optimoptions('lsqnonlin');
ss_opt.CheckGradients = false;
ss_opt.SpecifyObjectiveGradient = true;
ss_opt.Display = 'none';

ss_opt2 = optimoptions('fsolve');
ss_opt2.MaxFunEvals = 1000;
ss_opt2.Display = 'none';

f0        = zeros(1,ntest);
fout      = zeros(neq,ntest);
fout2     = nan  (neq,ntest);
xspecial1 = zeros(neq,ntest);
for mm = 1:ntest
    
    flag = nan;
    try
        %Fix sbar, solve for remaning values
        obj_2 = @(x) obj2([x;sgrid(mm)],log_idx,neq,...
            Busd,Beur,Yus,Yeu,Yrw,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);
        [xtmp,f0(mm)] = lsqnonlin(obj_2,x0test(1:neq-1),[],[],ss_opt);
        
        
        if f0(mm)<.01
            obj = @(x) 100*steady_residual(x,log_idx,...
                Busd,Beur,Yus,Yeu,Yrw,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);
            
            
            fout(:,mm) = obj([xtmp;sgrid(mm)]);
            [xspecial1(:,mm),fout2(:,mm),flag] = fsolve(obj,[xtmp;sgrid(mm)],ss_opt2);
        end
    catch
        disp('oopsy')
    end
    disp(['Pt ' sprintf('%i\t',mm), '|resid: ', sprintf('%1.1e',sum(abs(fout2(:,mm)))), '|flag: ', num2str(flag)]);
end

%%

disp('Hey man, here are the steady states I found!')

%Keep only unique steady-states
xspecial  = xspecial1(:,sum(abs(fout2))<1e-10);
[~,idx]   = sort(xspecial(end,:),'ascend');
xspecial  = xspecial(:,idx);
idx_kp    = unique_ss(xspecial(11:12,:));
xspecial  = xspecial(:,idx_kp);
xspecial(log_idx,:) = exp(xspecial(log_idx,:));




%% DISPALAY INFO ON STEADY-STATES

table_dat = zeros(2,9);
xspecial_long = zeros(size(xspecial,1)+nstate,size(xspecial,2));
frac_ss = zeros(4,size(xspecial,2));
tmp = zeros(1,size(xspecial,2));
cons_steady = zeros(3,size(xspecial,2));
for jj = size(xspecial,2):-1:1
    xout = xspecial(:,jj);
    expand_steady
    
    disp_steady
    
    xspecial_long([1:neq],jj)   = xout;
    Xrw = z +(1-2*z)*(1-normcdf(xout(end)));
    
    BBX = [mu_rw*Brw_usd, mu_rw*Brw_eur, mu_us*Bus_usd,mu_eu*Beu_eur,Xrw]';
    
    cons_steady(:,jj) = [Cus,Ceu,Crw];
    
    xspecial_long(neq+(1:nstate),jj) = BBX(1:nstate);
    tmp(jj) = walras_residual(xspecial_long(:,jj),xspecial_long(:,jj),xspecial_long(neq+(1:nstate),jj),log_idx,...
        Busd,Beur,Yus,Yeu,Yrw,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,Busd_l,Beur_l,Yus_l,Yeu_l,Yrw_l,mu_us_l,mu_eu_l,mu_rw_l,ah_us_l,ah_eu_l,ah_rw_l,Busd_p,Beur_p,Yus_p,Yeu_p,Yrw_p,mu_us_p,mu_eu_p,mu_rw_p,ah_us_p,ah_eu_p,ah_rw_p,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);
    
    %frac_ss(:,jj)         = [Brw_usd*mu_rw/Busd, Brw_eur*mu_rw/Beur, Bus_usd*mu_us/(Busd*(1-Brw_usd*mu_rw/Busd)), Beu_eur*mu_eu/(Beur*(1-Brw_eur*mu_rw/Beur))]';
    frac_ss(:,jj) = B2frac(xspecial_long(neq+(1:4),jj),Busd,Beur,mu_us,mu_eu,mu_rw);
    
    table_dat(1,(jj-1)*3+(1:3)) = [Xus,Xeu,Xrw];
    table_dat(2,(jj-1)*3+(1:3)) = EPs;
    table_dat(3,(jj-1)*3+(1:3)) = 100*IRs(1:3);
    table_dat(4,(jj-1)*3+(1:3)) = NFAs;
    table_dat(5,(jj-1)*3+(1:3)) = GROSSs(1,:);
    
    table_dat(6,(jj-1)*3+(1:3)) = 100*TBs;
    
end


%%
try
    %save symmetric ss
    if abs(xspecial(end,2))<1e-7
        xout = xspecial(:,2);
        %save xout_tmp xout
    else
        error('no Asymmetric ss');
    end
catch
    disp('no Asymmetric ss');
end


%%
%**************************************************************************
% Compute linear policies
%**************************************************************************
%Initial linear policies
pol_mat = xspecial_long;
nss     = size(pol_mat,2);
hx_cell = cell(1,nss);
gx_cell = cell(1,nss);
ss_use  = false(1,nss);
for jj = 1:nss
    
    pol_mat(log_idx,jj) = log(pol_mat(log_idx,jj));
    
    [a,d_f,d_futr,dfrac_waste,d_past] = dynamic_residual(pol_mat(:,jj),pol_mat(:,jj),pol_mat(neq+(1:nstate),jj),log_idx,neq,...
        Busd,Beur,Yus,Yeu,Yrw,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,Busd_l,Beur_l,Yus_l,Yeu_l,Yrw_l,mu_us_l,mu_eu_l,mu_rw_l,ah_us_l,ah_eu_l,ah_rw_l,Busd_p,Beur_p,Yus_p,Yeu_p,Yrw_p,mu_us_p,mu_eu_p,mu_rw_p,ah_us_p,ah_eu_p,ah_rw_p,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);
        
    if sum(abs(a))>1e-11
        disp('Uhoh')
        pause
    end
    
    %To accomodate t+1 states, phew!
    fx = [d_past;zeros(nstate,nstate)];
    fy = [d_f(:,1:neq),zeros(neq+nstate,nstate);zeros(nstate,neq),-eye(nstate)];
    fxp =[d_f(:,neq+(1:nstate));eye(nstate)];
    fyp =[d_futr;zeros(nstate,neq+nstate)];
    
    
    [gx,hx,flag] = gx_hx_alt(fy,fx,fyp,fxp,1.00000000);
    eigg = nan;
    if ~isempty(hx) && ~isnan(hx(1))
        eigg = sort(abs(eig(hx)));
    end
    
    if flag == 1 && max(max(abs(hx)))<1e8
        %Only use the locally determinant SS
        ss_use(jj) = true;
    end
    
    disp(['Steady-state ' num2str(jj) '|resid: ' num2str2(sum(abs(a))) '|flag: ' num2str(flag), '|eig: ' num2str(eigg(end),'%1.6f')])
    
    hx_cell{jj} = hx;
    gx_cell{jj} = gx;
end

%% Objective function for fixed sbar.

function [out,dout] = obj2(x,log_idx,neq,...
    Busd,Beur,Yus,Yeu,Yrw,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);


[out,dout]  = steady_residual(x,log_idx,...
    Busd,Beur,Yus,Yeu,Yrw,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);

out = out(1:neq-1);
dout = dout(1:neq-1,1:neq-1);

end


