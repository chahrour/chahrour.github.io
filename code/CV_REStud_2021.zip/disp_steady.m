% DISP_STEADY - display statistics from steady-state calculations

sfor = '%1.3f|';
disp( ' ')
disp( '******************************************************')
disp( '                  STEADY STATE                        ')
disp( '******************************************************')
disp( '                 US      EU    ROW ')
disp(['GDP            : ' sprintf(sfor, GDPs)]);
disp(['Prices Idx     : ' sprintf(sfor, Ps)]);
disp(['Delta USD      : ' sprintf(sfor, delta_bonds([1,3,5])*100)]);
disp(['Delta EUR      : ' sprintf(sfor, delta_bonds([2,4,6])*100)]);
disp(['Bs USD         : ' sprintf(sfor, Bs([1,3,5]))]);
disp(['Bs EUR         : ' sprintf(sfor, Bs([2,4,6]))]);
disp(['Firm measure   : ' sprintf(sfor, [m_us,m_eu,m_rw])]);
disp(['Xs             : ' sprintf(sfor, Xs)]);

disp(' ')
disp(['C agg          : ' sprintf(sfor, Cs)]);
disp(['US C from      : ' sprintf(sfor, CUSs)]);
disp(['EU C from      : ' sprintf(sfor, CEUs)]);
disp(['RW C from      : ' sprintf(sfor, CRWs)]);


disp(' ')
disp(['Trade shar     : ' sprintf(sfor, TSHRs)]);
disp(['T.B.           : ' sprintf(sfor, TBs*100)]);

disp(' ')
disp(['NFA            : ' sprintf(sfor, NFAs)]);
disp(['Gross F. Ass.  : ' sprintf(sfor, GROSSs(1,:))]);
disp(['Gross F. Lia.  : ' sprintf(sfor, GROSSs(2,:))]);
disp(['Home Bias      : ' sprintf(sfor, HMBSs)]);
disp(['Gross Dom Debt : ' sprintf(sfor, GDs)]);

disp(' ')
disp(['Rus/Reu        : ' sprintf(sfor, [Rusd, Reur])]);
disp(['Rgb-Rus        : ' sprintf(sfor,100*( per_p_year*(1/bet -1)-[Rusd,Reur]))]);
disp(['Ex. Priv.      : ' sprintf(sfor, EPs)]);
disp(['Impl.  Re      : ' sprintf(sfor, 100*IRs)]);

disp(' ')
disp(['$ Fnd Prbs     : ' sprintf(sfor, FR_PROBs(1,:))]);
disp(['e Fnd Prbs     : ' sprintf(sfor, FR_PROBs(2,:))]);

disp(['Exp Prbs fm US : ' sprintf(sfor, TR_PROBs(1,:))]);
disp(['Exp Prbs fm EU : ' sprintf(sfor, TR_PROBs(2,:))]);
disp(['Exp Prbs fm RW : ' sprintf(sfor, TR_PROBs(3,:))]);

disp(['Imp Prbs to US : ' sprintf(sfor, TR_PROBs(4,:))]);
disp(['Imp Prbs to EU : ' sprintf(sfor, TR_PROBs(5,:))]);
disp(['Imp Prbs to RW : ' sprintf(sfor, TR_PROBs(6,:))]);


PTRADs(isnan(PTRADs)) = 0;
disp(['US P trade with: ' sprintf(sfor, PTRADs(1,:))]);
disp(['EU P trade with: ' sprintf(sfor, PTRADs(2,:))]);
disp(['RW P trade with: ' sprintf(sfor, PTRADs(3,:))]);


disp( ' ');
disp(['Markup US good : ' sprintf(sfor, [Pus_us, Peu_us, Prw_us]./Pus_us)])
disp(['Markup EU good : ' sprintf(sfor, [Pus_eu, Peu_eu, Prw_eu]./Peu_eu)])
disp(['Markup RW good : ' sprintf(sfor, [Pus_rw, Peu_rw, Prw_row]./Prw_rw)])
