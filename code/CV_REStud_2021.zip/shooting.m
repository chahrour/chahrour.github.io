% SHOOTING - computes the residuals of model equilibrium conditions for a
% given conjecture of the path of the economy.


function [resid,dF,xshoot,dfinal,usd_shrs,usd_use,con_out,tb_out,ep_out,nfa_out,prices_out,delts_out,walras_out,tau_out,taup_out,returns_out,irs_out] = shooting(xin,X0,YXT,T,log_idx,neq,nstate,dF0,...
    Busd,Beur,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,Yus,Yeu,Yrw,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);


nvar = neq+nstate;

xshoot = reshape(xin,[nvar,T]);

%Compute residuals
resid = NaN(nvar,T);
if isempty(dF0)
    dF   = spalloc(numel(resid),numel(resid),nvar^2);
else
    dF   = dF0;
end


%Parameters that change, unpack
uppv_idx = length(upp_usd)>1;
upp_usd  = upp_usd(1);
upp_eur  = upp_eur(1);

Busd_idx = length(Busd)>1;
Beur_idx = length(Beur)>1;
Busdv    = Busd;
Beurv    = Beur;

Busd_l = Busd;
Beur_l = Beur;
Busd_p = Busd;
Beur_p = Beur;

mu_idx = length(mu_us)>1;
mu_usv = mu_us;
mu_euv = mu_eu;
mu_rwv = mu_rw;

mu_us_l = mu_us;
mu_us_p = mu_us;

mu_eu_l = mu_eu;
mu_eu_p = mu_eu;

mu_rw_l = mu_rw;
mu_rw_p = mu_rw;


ah_usv = ah_us;
ah_euv = ah_eu;
ah_rwv = ah_rw;

ah_us_l = ah_us;
ah_us_p = ah_us;

ah_eu_l = ah_eu;
ah_eu_p = ah_eu;

ah_rw_l = ah_rw;
ah_rw_p = ah_rw;


dtax_us_eu = 0;
dtax_us_rw = 0;
dtax_eu_us = 0;
dtax_eu_rw = 0;
dtax_rw_us = 0;
dtax_rw_eu = 0;
dtax_rw_row = 0;

tax_us_eu_idx = length(tax_us_eu)>1;
tax_us_euv    =        tax_us_eu;

tax_us_rw_idx = length(tax_us_rw)>1;
tax_us_rwv    =        tax_us_rw;

tax_eu_us_idx = length(tax_eu_us)>1;
tax_eu_usv    =        tax_eu_us;

tax_eu_rw_idx = length(tax_eu_rw)>1;
tax_eu_rwv    =        tax_eu_rw;

tax_rw_us_idx = length(tax_rw_us)>1;
tax_rw_usv    =        tax_rw_us;

tax_rw_eu_idx = length(tax_rw_eu)>1;
tax_rw_euv    =        tax_rw_eu;

tax_rw_row_idx = length(tax_rw_row)>1;
tax_rw_rowv    =        tax_rw_row;

Yus_idx = length(Yus) > 1;
Yusv = Yus;

Yeu_idx = length(Yeu) > 1;
Yeuv = Yeu;

Yrw_idx = length(Yrw) > 1;
Yrwv = Yrw;

Yus_p = Yus; Yus_l = Yus;
Yeu_p = Yeu; Yeu_l = Yeu;
Yrw_p = Yrw; Yrw_l = Yrw;


if nargout > 4
    usd_shrs = zeros(3,T-1);
    usd_use  = zeros(1,T-1);
    con_out  = zeros(3,T-1);
    tb_out   = zeros(3,T-1);
    nfa_out  = zeros(3,T-1);
    ep_out   = zeros(1,T-1);
    prices_out = zeros(2,3,T-1);
    delts_out = zeros(6,T-1);
    walras_out = zeros(1,T-1);
    tau_out = zeros(2,3,T-1);
    taup_out = zeros(2,3,T-1);
    returns_out = zeros(2,T-1);
    irs_out = zeros(4,T-1);
end



for jj = 1:T-1
    eqidx  = (jj-1)*nvar+ (1:nvar);
    vidx   = (jj-1)*nvar+ (1:(2*nvar));
    vs_idx = (jj-2)*nvar + (neq+(1:nstate));
    
    %Past bonds
    if Busd_idx
        Busd   = Busdv(jj+1);
        Busd_l = Busdv(jj);
        Busd_p = Busdv(min(jj+2,end));
    end
    
    if Beur_idx
        Beur   = Beurv(jj+1);
        Beur_l = Beurv(jj);
        Beur_p = Beurv(min(jj+2,end));
    end
 
    if uppv_idx
        upp_usd = uppv_usd(jj);
        upp_eur = uppv_eur(jj);
    end
    
    if Yrw_idx
        Yrw   = Yrwv(jj+1);
        Yrw_l = Yrwv(jj);
        Yrw_p = Yrwv(min(jj+2,end));
    end
    
    if mu_idx
      mu_us   = mu_usv(jj+1);
      mu_us_l = mu_usv(jj);
      mu_us_p = mu_usv(min(jj+2,end));
      
      mu_eu   = mu_euv(jj+1);
      mu_eu_l = mu_euv(jj);
      mu_eu_p = mu_euv(min(jj+2,end));
      
      mu_rw   = mu_rwv(jj+1);
      mu_rw_l = mu_rwv(jj);
      mu_rw_p = mu_rwv(min(jj+2,end));
      
      ah_us   = ah_usv(jj+1);
      ah_us_l = ah_usv(jj);
      ah_us_p = ah_usv(min(jj+2,end));
      
      ah_eu   = ah_euv(jj+1);
      ah_eu_l = ah_euv(jj);
      ah_eu_p = ah_euv(min(jj+2,end));
      
      ah_rw   = ah_rwv(jj+1);
      ah_rw_l = ah_rwv(jj);
      ah_rw_p = ah_rwv(min(jj+2,end));
    end
    
    if tax_us_eu_idx
        tax_us_eu = tax_us_euv(jj);
    end
    
    if tax_us_rw_idx
        tax_us_rw = tax_us_rwv(jj);
    end
    
    if tax_eu_us_idx
        tax_eu_us = tax_eu_usv(jj);
    end
    
    if tax_eu_rw_idx
        tax_eu_rw = tax_eu_rwv(jj);
    end
    
    
    if tax_rw_us_idx
        tax_rw_us = tax_rw_usv(jj);
    end
    
    if tax_rw_eu_idx
        tax_rw_eu = tax_rw_euv(jj);
    end
    
    if tax_rw_row_idx
        tax_rw_row = tax_rw_rowv(jj);
    end

    [resid(:,jj),dft,dfp,~,dfl] = dynamic_residual(xshoot(:,jj),xshoot(:,jj+1),X0,log_idx,neq,...
        Busd,Beur,Yus,Yeu,Yrw,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,Busd_l,Beur_l,Yus_l,Yeu_l,Yrw_l,mu_us_l,mu_eu_l,mu_rw_l,ah_us_l,ah_eu_l,ah_rw_l,Busd_p,Beur_p,Yus_p,Yeu_p,Yrw_p,mu_us_p,mu_eu_p,mu_rw_p,ah_us_p,ah_eu_p,ah_rw_p,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);

    
    dF(eqidx,vidx) = dF(eqidx,vidx) + [dft,dfp];
    
    
    if jj >1
        dF(eqidx,vs_idx) = dF(eqidx,vs_idx) + dfl;
    end
    
    if nargout > 4
        [usd_shrs(:,jj),usd_use(:,jj),con_out(:,jj),tb_out(:,jj),ep_out(jj),nfa_out(:,jj),~,prices_out(:,:,jj),~,delts_out(:,jj),walras_out(jj),tau_out(:,:,jj), taup_out(:,:,jj),returns_out(:,jj),irs_out(:,jj)] =   dynamic_responses(xshoot(:,jj),xshoot(:,jj+1),X0,log_idx,neq,...
       Busd,Beur,Yus,Yeu,Yrw,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,Busd_l,Beur_l,Yus_l,Yeu_l,Yrw_l,mu_us_l,mu_eu_l,mu_rw_l,ah_us_l,ah_eu_l,ah_rw_l,Busd_p,Beur_p,Yus_p,Yeu_p,Yrw_p,mu_us_p,mu_eu_p,mu_rw_p,ah_us_p,ah_eu_p,ah_rw_p,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);

  end
    
    %Update state for next round
    X0 = xshoot(end-nstate+1:end,jj);
end


resid(:,T) = xshoot(:,end)-YXT;
dF(end-nvar+1:end,end-nvar+1:end) = eye(nvar);



%% Scaling
resid = 1000*resid(:);
dF    = 1000*dF;

%To test if economy has converged at the end.
dfinal = 10*(xshoot(nvar-nstate+1:nvar,end-1) - xshoot(nvar-nstate+1:nvar,end));


