%**************************************************************************
% SYMBOLIC VERSION OF EQUILIBRIUM CONDITIONS FOR QUANTITATIVE MODEL IN
% CHAHROUR AND VALCHEV "TRADE FINANCE AND THE DURABILITY OF THE DOLLAR"
%
% MODIFICATION WITH ROW ASSET WITH DOWNWARD SLOPING DEMAND
%
% NOTES: for mex reasons, sym variables CANNOT contain any numbers in their
% names
%
%**************************************************************************


%recompute symbolic math
redo_main   = 1;
redo_defsb  = 1;
redo_extra  = 1;
redo_bonds  = 1;

%Optimize symoblic expressions
optimize    = false;

%distribution of theta shock
sdist = @(t) normcdf(t);

tic

%For ss (= 0) or for dynamics (= 1)
ver_run  = {'steady-state', 'dynamic model'};
for solve_dyn = [1,0]
    
    disp(['Simplifying ' ver_run{solve_dyn+1} ' ...']);
    
    %**************************************************************************
    %Symbolic defs
    %**************************************************************************
    
    %Country Size
    syms mu_us mu_eu mu_rw
    
    %Firm measures
    syms m_us m_eu m_rw
    
    %Funding choice
    syms Xus Xeu Xrw
    
    %Idiosyncratic preference shock params
    syms sige sbar_us sbar_eu sbar_rw Vusd
    
    %Matching function elasticities and level shift
    syms vepsf vepst
    
    %trading values/wholesale price
    syms alph kap pw_us pw_eu pw_rw
    
    %funding cost
    syms r
    
    %funding probs
    syms p_us_usd p_us_eur
    syms p_eu_usd p_eu_eur
    syms p_rw_usd p_rw_eur
    
    %hh-side funding probs
    syms ph_us_usd ph_us_eur
    syms ph_eu_usd ph_eu_eur
    syms ph_rw_usd ph_rw_eur
    
    %Importer/exporter funding probs
    syms pus_im  peu_im prw_im
    
    %Prob of visiting each country
    syms p_us_eu p_us_rw
    syms p_eu_us p_eu_rw
    syms p_rw_us p_rw_eu p_rw_rw
    
    %New probs
    syms pim_us_eu pim_us_rw
    syms pex_us_eu pex_us_rw
    
    syms pim_us_eu_ pim_us_rw_ pex_us_eu_
    
    syms pim_eu_us pim_eu_rw
    syms pex_eu_us pex_eu_rw
    
    syms pim_eu_us_ pim_eu_rw_ pex_eu_us_
    
    syms pim_rw_us pim_rw_eu pim_rw_row
    syms pex_rw_us pex_rw_eu pex_rw_row
    
    syms pim_rw_us_ pim_rw_eu_ pim_rw_row_ pex_rw_us_ pex_rw_eu_
    
    %matching finding probabilities
    syms pie_us_eu  pie_us_rw
    syms pie_eu_us  pie_eu_rw
    syms pie_rw_us  pie_rw_eu pie_rw_rw
    
    syms pei_us_eu  pei_us_rw
    syms pei_eu_us  pei_eu_rw
    syms pei_rw_us  pei_rw_eu pei_rw_rw
    
    %exogenous currency guys
    syms z zrow
    
    %uses per period
    syms upp_usd upp_eur
    
    %entry cost
    syms phi
    
    %Preference parameters
    syms bet sig eta
    
    %Bond supplies and prices
    syms Busd   Beur   Brow
    syms Busd_l Beur_l Brow_l
    syms Busd_p Beur_p Brow_p
    syms Qusd   Qeur   Qrow
    %syms dBusd dBeur
    
    %Adjustment cost
    syms tau taup tau_row
    
    %taxes on imports
    syms tax_us_eu tax_us_rw
    syms tax_eu_us tax_eu_rw
    syms tax_rw_us tax_rw_eu tax_rw_row
    
    
    syms dtax_us_eu dtax_us_rw
    syms dtax_eu_us dtax_eu_rw
    syms dtax_rw_us dtax_rw_eu dtax_rw_row
    
    %capital flow taxes
    syms tax_us_in tax_us_out
    syms tax_eu_in tax_eu_out
    syms tax_rw_out
    
    %US variables
    syms Cus_us Cus_eu Cus_rw Pus Pus_us Pus_eu Pus_rw Bus_usd Bus_eur Bus_row Yus Gus
    
    %EU variables
    syms Ceu_eu Ceu_us Ceu_rw Peu Peu_eu Peu_us Peu_rw Beu_usd Beu_eur Beu_row Yeu Geu
    
    %RW variables
    syms Crw_rw Crw_row Crw_us Crw_eu Prw Prw_eu Prw_us Prw_row Brw_usd Brw_eur Brw_row Yrw Grw Prw_rw Xrw_lg
    
    %Pref Parameters
    syms ah_us ah_eu ah_rw
    syms wus_eu wus_rw
    syms weu_us weu_rw
    syms wrw_us wrw_eu wrw_row
    
    %Goverment spending share
    syms phi_usg phi_eug phi_rwg
    
    %Endowment changes
    syms dYus dYeu dYrw
    
    %Calvo parameter for reset currency
    syms omg
    
    %Periods per year
    syms per_p_year;
    
    %Eventually fix repetition of this with shell model
    jump_vars    = [Cus_eu, Cus_rw, Ceu_us, Ceu_rw, Crw_us Crw_eu Crw_row, Qusd, Qeur,Qrow,...
        Pus_us, Pus_eu, Pus, Peu_eu, Peu_us, Peu, Prw, Prw_us, Prw_eu, m_us, m_eu, m_rw];
    
    jump_vars = [jump_vars, pim_us_eu_ pim_us_rw_ pex_us_eu_,...
        pim_eu_us_ pim_eu_rw_ pex_eu_us_,...
        pim_rw_us_ pim_rw_eu_ pim_rw_row_ pex_rw_us_ pex_rw_eu_...
        ,Vusd,sbar_rw];
    
    
    if solve_dyn
        state_vars   = [Brw_usd, Brw_eur, Bus_usd, Beu_eur, Bus_row, Beu_row, Xrw];
        if ~xstate
            state_vars = state_vars(1:end-1);
        end
    else
        state_vars   = [];
    end
    
    jump_prime   = make_prime(jump_vars);
    state_lag    = make_lag(state_vars);
    state_prime  = make_prime(state_vars);
    vcombo_ss    = [jump_vars,state_vars];
    
    %Track all the input arguments to main solver
    clear *_idx
    make_index(vcombo_ss);
    save saved_results/idx_vars *_idx
    
    
    param_list = [Busd Beur Brow ...   %Bonds Supply at time t
        Busd_l Beur_l Brow_l ... %Bond Supply at time t-1
        Busd_p Beur_p Brow_p ... %Bond Supply at time t+1
        tau       ...   %Adjusmtent costs
        taup      ...   %Coef. on forward looking portion of adj. cost
        tau_row   ...   %Cost of holding ROW bond
        alph      ...   %nash bargain
        vepsf vepst ... %Matching fcns
        kap phi r...    %Trade game
        sige ...        %ido prefs
        mu_us mu_eu mu_rw ...%country size
        Yus Yeu Yrw   ...    %endowments
        phi_usg phi_eug phi_rwg ... %government spending shares
        bet sig eta ...%Preferences
        ah_us ah_eu ah_rw ...% wus_eu wus_rw weu_us weu_rw wrw_us wrw_eu wrw_row...%More preferences
        Prw_rw  ... %Numeraire
        Xus Xeu ... %us,eu cutoffs
        z,zrow       ... %exogenous fraction using each currency.
        upp_usd upp_eur    ... %uses-per-period
        per_p_year ...
        omg      ... %chance I reset currency today
        tax_us_eu tax_us_rw tax_eu_us tax_eu_rw tax_rw_us tax_rw_eu tax_rw_row ... %Import taxes
        dtax_us_eu dtax_us_rw ...             %Import Tax growth
        dtax_eu_us dtax_eu_rw ...
        dtax_rw_us dtax_rw_eu dtax_rw_row...
        tax_us_in tax_us_out tax_eu_in tax_eu_out tax_rw_out]; %Capital flow taxes
    
    args_param_str = args_string(param_list);
    
    
    %**************************************************************************
    % BUNCH OF DEFINITIONS FROM GE
    %**************************************************************************
    
    %Trade flow direction
    
    %US
    pim_us_eu  = (1                                    )*pim_us_eu_;
    pim_us_rw  = (1 - pim_us_eu                        )*pim_us_rw_;
    pex_us_eu  = (1 - pim_us_eu - pim_us_rw            )*pex_us_eu_;
    pex_us_rw  = (1 - pim_us_eu - pim_us_rw - pex_us_eu);
    
    %EU
    pim_eu_us  = (1                                    )*pim_eu_us_;
    pim_eu_rw  = (1 - pim_eu_us                        )*pim_eu_rw_;
    pex_eu_us  = (1 - pim_eu_us - pim_eu_rw            )*pex_eu_us_;
    pex_eu_rw  = (1 - pim_eu_us - pim_eu_rw - pex_eu_us);
    
    
    %ROW
    pim_rw_us   = (1                                    )*pim_rw_us_;
    pim_rw_eu   = (1 - pim_rw_us                        )*pim_rw_eu_;
    pim_rw_row  = (1 - pim_rw_us - pim_rw_eu            )*pim_rw_row_;
    
    pex_rw_us  = (1 - pim_rw_us - pim_rw_eu - pim_rw_row                        )*pex_rw_us_;
    pex_rw_eu  = (1 - pim_rw_us - pim_rw_eu - pim_rw_row - pex_rw_us            )*pex_rw_eu_;
    pex_rw_row = (1 - pim_rw_us - pim_rw_eu - pim_rw_row - pex_rw_us - pex_rw_eu);
    
    
    %Convert to levels, to keep between 0 and 1
    plev = [pim_us_eu_ pim_us_rw_ pex_us_eu_...
        pim_eu_us_ pim_eu_rw_ pex_eu_us_...
        pim_rw_us_ pim_rw_eu_ pim_rw_row_ pex_rw_us_ pex_rw_eu_];
    pexp = exp(plev)./(1+exp(plev));
    
    
    pim_us_eu = subs(pim_us_eu,plev,pexp);
    pim_us_rw = subs(pim_us_rw,plev,pexp);
    pex_us_eu = subs(pex_us_eu,plev,pexp);
    pex_us_rw = subs(pex_us_rw,plev,pexp);
    
    pim_eu_us = subs(pim_eu_us,plev,pexp);
    pim_eu_rw = subs(pim_eu_rw,plev,pexp);
    pex_eu_us = subs(pex_eu_us,plev,pexp);
    pex_eu_rw = subs(pex_eu_rw,plev,pexp);
    
    pim_rw_us  = subs(pim_rw_us,plev,pexp);
    pim_rw_eu  = subs(pim_rw_eu,plev,pexp);
    pim_rw_row = subs(pim_rw_row,plev,pexp);
    
    pex_rw_us  = subs(pex_rw_us,plev,pexp);
    pex_rw_eu  = subs(pex_rw_eu,plev,pexp);
    pex_rw_row = subs(pex_rw_row,plev,pexp);

    
    wus_eu  = mu_eu/(mu_eu+mu_rw);
    wus_rw  = mu_rw/(mu_eu+mu_rw);
    weu_us  = mu_us/(mu_us+mu_rw);
    weu_rw  = mu_rw/(mu_us+mu_rw);
    wrw_us  = mu_us/(mu_us+mu_eu+mu_rw);
    wrw_eu  = mu_eu/(mu_us+mu_eu+mu_rw);
    wrw_row = mu_rw/(mu_us+mu_eu+mu_rw);
    
    
    %Redefine sbar in units of SD of idio noise (moved to later)
    if solve_dyn == 0 || ~xstate
        Xrw = z +(1-2*z)*(1-sdist(sbar_rw));
    end
    
    Cus_us  = 1/mu_us*((1-phi_usg)*mu_us*Yus          - mu_rw*Crw_us - mu_eu*Ceu_us);
    Ceu_eu  = 1/mu_eu*((1-phi_eug)*mu_eu*Yeu          - mu_us*Cus_eu - mu_rw*Crw_eu);
    Crw_rw  = 1/mu_rw*((1-phi_rwg)*mu_rw*(Yrw-Crw_row) - mu_us*Cus_rw - mu_eu*Ceu_rw);
    
    
    % CD aggregation
    cons_us = ah_us^ah_us*((1-ah_us)*wus_eu)^((1-ah_us)*wus_eu)*((1-ah_us)*wus_rw)^((1-ah_us)*wus_rw);
    cons_eu = ah_eu^ah_eu*((1-ah_eu)*weu_us)^((1-ah_eu)*weu_us)*((1-ah_eu)*weu_rw)^((1-ah_eu)*weu_rw);
    cons_rw = ah_rw^ah_rw*((1-ah_rw)*wrw_us)^((1-ah_rw)*wrw_us)*((1-ah_rw)*wrw_eu)^((1-ah_rw)*wrw_eu)*((1-ah_rw)*wrw_row)^((1-ah_rw)*wrw_row);
    
    Cus = 1/cons_us*Cus_us^(ah_us)*Cus_eu^((1-ah_us)*wus_eu)*Cus_rw^((1-ah_us)*wus_rw);
    Ceu = 1/cons_eu*Ceu_eu^(ah_eu)*Ceu_us^((1-ah_eu)*weu_us)*Ceu_rw^((1-ah_eu)*weu_rw);
    Crw = 1/cons_rw*Crw_rw^(ah_rw)*Crw_us^((1-ah_rw)*wrw_us)*Crw_eu^((1-ah_rw)*wrw_eu)*Crw_row^((1-ah_rw)*wrw_row);
    
    Pus_rw  = 1/(1+tax_us_rw) *(Pus*(Pus_us)^-ah_us*((1+tax_us_eu)*Pus_eu)^-((1-ah_us)*wus_eu))^(1/((1-ah_us)*wus_rw));
    Peu_rw  = 1/(1+tax_eu_rw) *(Peu*(Peu_eu)^-ah_eu*((1+tax_eu_us)*Peu_us)^-((1-ah_eu)*weu_us))^(1/((1-ah_eu)*weu_rw));
    Prw_row = 1/(1+tax_rw_row)*(Prw*(Prw_rw)^-ah_rw*((1+tax_rw_us)*Prw_us)^-((1-ah_rw)*wrw_us)*((1+tax_rw_eu)*Prw_eu)^-((1-ah_rw)*wrw_eu))^(1/((1-ah_rw)*wrw_row));
    
    
    %STEADY STATE ONLY
    %Steady-state substitutions
    
    if solve_dyn
        Brw_row = 1/mu_rw*(Brow  - mu_us*Bus_row - mu_eu*Beu_row);
        Beu_usd = 1/mu_eu*(Busd  - mu_us*Bus_usd - mu_rw*Brw_usd);
        Bus_eur = 1/mu_us*(Beur  - mu_eu*Beu_eur - mu_rw*Brw_eur);
    else
        Bus_row = Brow*(m_us*zrow)/(mu_us*m_us*zrow + mu_eu*m_eu*zrow + mu_rw*m_rw*zrow);
        Beu_row = Brow*(m_eu*zrow)/(mu_us*m_us*zrow + mu_eu*m_eu*zrow + mu_rw*m_rw*zrow);
        Brw_row = Brow*(m_rw*zrow)/(mu_us*m_us*zrow + mu_eu*m_eu*zrow + mu_rw*m_rw*zrow);
        
        Bus_usd = Busd*(m_us*Xus)/(mu_us*m_us*Xus + mu_eu*m_eu*Xeu + mu_rw*m_rw*Xrw);
        Beu_usd = Busd*(m_eu*Xeu)/(mu_us*m_us*Xus + mu_eu*m_eu*Xeu + mu_rw*m_rw*Xrw);
        Brw_usd = Busd*(m_rw*Xrw)/(mu_us*m_us*Xus + mu_eu*m_eu*Xeu + mu_rw*m_rw*Xrw);
        
        Bus_eur = Beur*(m_us*(1-Xus))/(mu_us*m_us*(1-Xus) + mu_eu*m_eu*(1-Xeu) + mu_rw*m_rw*(1-Xrw));
        Beu_eur = Beur*(m_eu*(1-Xeu))/(mu_us*m_us*(1-Xus) + mu_eu*m_eu*(1-Xeu) + mu_rw*m_rw*(1-Xrw));
        Brw_eur = Beur*(m_rw*(1-Xrw))/(mu_us*m_us*(1-Xus) + mu_eu*m_eu*(1-Xeu) + mu_rw*m_rw*(1-Xrw));
    end
    
    Cus_p = subs(Cus,jump_vars, jump_prime);
    Ceu_p = subs(Ceu,jump_vars, jump_prime);
    Crw_p = subs(Crw,jump_vars, jump_prime);
    
    %Expected changes in taxes
    taxt = [tax_us_eu tax_us_rw tax_eu_us tax_eu_rw tax_rw_us tax_rw_eu tax_rw_row];
    dtax = [ dtax_us_eu dtax_us_rw ...
        dtax_eu_us dtax_eu_rw ...
        dtax_rw_us dtax_rw_eu dtax_rw_row];
    
    Cus_p = subs(Cus_p,taxt, taxt+dtax);
    Ceu_p = subs(Ceu_p,taxt, taxt+dtax);
    Crw_p = subs(Crw_p,taxt, taxt+dtax);
    
    Pus_p  = subs(Pus,jump_vars, jump_prime);
    Peu_p  = subs(Peu,jump_vars, jump_prime);
    Prw_p  = subs(Prw,jump_vars, jump_prime);
    
    Pus_p = subs(Pus_p,taxt, taxt+dtax);
    Peu_p = subs(Peu_p,taxt, taxt+dtax);
    Prw_p = subs(Prw_p,taxt, taxt+dtax);
    
    Qusd_p  = subs(Qusd,jump_vars, jump_prime);
    Qeur_p  = subs(Qeur,jump_vars, jump_prime);
    Qrow_p  = subs(Qrow,jump_vars, jump_prime);
    
    Brw_usd_p = subs(Brw_usd,state_vars,state_prime);
    Brw_eur_p = subs(Brw_eur,state_vars,state_prime);
    Brw_row_p = subs(Brw_row,state_vars,state_prime);
    
    Beu_usd_p = subs(Beu_usd,[state_vars,Busd],[state_prime,Busd_p]); %extra variable to allow bond timeseries
    Beu_eur_p = subs(Beu_eur,state_vars,state_prime);
    Beu_row_p = subs(Beu_row,state_vars,state_prime);
    
    Bus_usd_p = subs(Bus_usd,state_vars,state_prime);
    Bus_eur_p = subs(Bus_eur,[state_vars,Beur],[state_prime,Beur_p]); %extra variable to allow bond timeseries
    Bus_row_p = subs(Bus_row,state_vars,state_prime);
    
    
    Brw_usd_l = subs(Brw_usd,state_vars,state_lag);
    Brw_eur_l = subs(Brw_eur,state_vars,state_lag);
    Brw_row_l = subs(Brw_row,state_vars,state_lag);
    
    Beu_usd_l = subs(Beu_usd,[state_vars,Busd],[state_lag,Busd_l]);
    Beu_eur_l = subs(Beu_eur,state_vars,state_lag);
    Beu_row_l = subs(Beu_row,state_vars,state_lag);
    
    
    Bus_usd_l = subs(Bus_usd,state_vars,state_lag);
    Bus_eur_l = subs(Bus_eur,[state_vars,Beur],[state_lag,Beur_l]);
    Bus_row_l = subs(Bus_row,state_vars,state_lag);
    
    %adjusmtent costs in bond holdings
    tau_us_usd = tau*(Bus_usd-Bus_usd_l)/Bus_usd_l;
    tau_eu_usd = tau*(Beu_usd-Beu_usd_l)/Beu_usd_l;
    tau_rw_usd = tau*(Brw_usd-Brw_usd_l)/Brw_usd_l;
    
    
    tau_us_eur = tau*(Bus_eur-Bus_eur_l)/Bus_eur_l;
    tau_eu_eur = tau*(Beu_eur-Beu_eur_l)/Beu_eur_l;
    tau_rw_eur = tau*(Brw_eur-Brw_eur_l)/Brw_eur_l;
    
    tau_us_row = tau*(Bus_row-Bus_row_l)/Bus_row_l;
    tau_eu_row = tau*(Beu_row-Beu_row_l)/Beu_row_l;
    tau_rw_row = tau*(Brw_row-Brw_row_l)/Brw_row_l;
    
    tau_us_usd_p = taup*(Bus_usd_p - Bus_usd)/Bus_usd + taup/2*((Bus_usd_p - Bus_usd)/Bus_usd)^2;
    tau_eu_usd_p = taup*(Beu_usd_p - Beu_usd)/Beu_usd + taup/2*((Beu_usd_p - Beu_usd)/Beu_usd)^2;
    tau_rw_usd_p = taup*(Brw_usd_p - Brw_usd)/Brw_usd + taup/2*((Brw_usd_p - Brw_usd)/Brw_usd)^2;
    
    
    tau_us_eur_p = taup*(Bus_eur_p - Bus_eur)/Bus_eur + taup/2*((Bus_eur_p - Bus_eur)/Bus_eur)^2;
    tau_eu_eur_p = taup*(Beu_eur_p - Beu_eur)/Beu_eur + taup/2*((Beu_eur_p - Beu_eur)/Beu_eur)^2;
    tau_rw_eur_p = taup*(Brw_eur_p - Brw_eur)/Brw_eur + taup/2*((Brw_eur_p - Brw_eur)/Brw_eur)^2;
    
    %Note: no tau_p is set up here.
    tau_us_row_p = 0;
    tau_eu_row_p = 0;
    tau_rw_row_p = 0;
    
    %What unit do bonds pay
    Pusd = Pus_us;
    Peur = Peu_eu;
    Prow = Prw_rw;
    
    Pusd_p = Pus_us_p;
    Peur_p = Peu_eu_p;
    Prow_p = Prw_rw;  %Since numeraire
    
    
    %**************************************************************************
    %Matching functions -> endogenous probabilities
    %**************************************************************************
    
    
    %Use current bonds
    p_us_usd  = upp_usd*Pusd*Bus_usd*Qusd/(((upp_usd*Pusd*Bus_usd*Qusd)^(1/vepsf) + (m_us*Xus    )^(1/vepsf))^vepsf);  %prob of us firm search dollars getting a match
    p_us_eur  = upp_eur*Peur*Bus_eur*Qeur/(((upp_eur*Peur*Bus_eur*Qeur)^(1/vepsf) + (m_us*(1-Xus))^(1/vepsf))^vepsf);  %prob of us firm search euro getting a match
    
    p_eu_usd  = upp_usd*Pusd*Beu_usd*Qusd/(((upp_usd*Pusd*Beu_usd*Qusd)^(1/vepsf) + (m_eu*Xeu    )^(1/vepsf))^vepsf);  %prob of eu firm search dollars getting a match
    p_eu_eur  = upp_eur*Peur*Beu_eur*Qeur/(((upp_eur*Peur*Beu_eur*Qeur)^(1/vepsf) + (m_eu*(1-Xeu))^(1/vepsf))^vepsf);  %prob of eu firm search euro getting a match
    
    p_rw_usd  = upp_usd*Pusd*Brw_usd*Qusd/(((upp_usd*Pusd*Brw_usd*Qusd)^(1/vepsf) + (m_rw*Xrw    )^(1/vepsf))^vepsf);  %prob of rw firm search dollars getting a match
    p_rw_eur  = upp_eur*Peur*Brw_eur*Qeur/(((upp_eur*Peur*Brw_eur*Qeur)^(1/vepsf) + (m_rw*(1-Xrw))^(1/vepsf))^vepsf);  %prob of rw firm search euro getting a match
    
    ph_us_usd = upp_usd*(m_us*Xus    )/(((upp_usd*Pusd*Bus_usd*Qusd)^(1/vepsf) + (m_us*Xus    )^(1/vepsf))^vepsf);  %prob of us hh search dollars getting a match
    ph_us_eur = upp_eur*(m_us*(1-Xus))/(((upp_eur*Peur*Bus_eur*Qeur)^(1/vepsf) + (m_us*(1-Xus))^(1/vepsf))^vepsf);  %prob of us hh search euro getting a match
    ph_us_row = upp_eur*(m_us*zrow   )/(((upp_eur*Prow*Bus_row*Qrow)^(1/vepsf) + (m_us*zrow   )^(1/vepsf))^vepsf);  %prob of us hh search euro getting a match
    
    ph_eu_usd = upp_usd*(m_eu*Xeu    )/(((upp_usd*Pusd*Beu_usd*Qusd)^(1/vepsf) + (m_eu*Xeu    )^(1/vepsf))^vepsf);  %prob of eu hh search dollars getting a match
    ph_eu_eur = upp_eur*(m_eu*(1-Xeu))/(((upp_eur*Peur*Beu_eur*Qeur)^(1/vepsf) + (m_eu*(1-Xeu))^(1/vepsf))^vepsf);  %prob of eu hh search euro getting a match
    ph_eu_row = upp_eur*(m_eu*zrow   )/(((upp_eur*Prow*Beu_row*Qrow)^(1/vepsf) + (m_eu*zrow   )^(1/vepsf))^vepsf);  %prob of us hh search euro getting a match
    
    ph_rw_usd = upp_usd*(m_rw*Xrw    )/(((upp_usd*Pusd*Brw_usd*Qusd)^(1/vepsf) + (m_rw*Xrw    )^(1/vepsf))^vepsf);  %prob of rw hh search dollars getting a match
    ph_rw_eur = upp_eur*(m_rw*(1-Xrw))/(((upp_eur*Peur*Brw_eur*Qeur)^(1/vepsf) + (m_rw*(1-Xrw))^(1/vepsf))^vepsf);  %prob of rw hh search euro getting a match
    ph_rw_row = upp_eur*(m_rw*zrow   )/(((upp_eur*Prow*Brw_row*Qrow)^(1/vepsf) + (m_rw*zrow   )^(1/vepsf))^vepsf);  %prob of us hh search euro getting a match
    
    m_us_til = mu_us*m_us*(Xus*p_us_usd + (1-Xus)*p_us_eur);  %measure of US firms with funding
    m_eu_til = mu_eu*m_eu*(Xeu*p_eu_usd + (1-Xeu)*p_eu_eur);  %measure of EU firms with funding
    m_rw_til = mu_rw*m_rw*(Xrw*p_rw_usd + (1-Xrw)*p_rw_eur);  %measure of RW firms with funding
    
    if solve_dyn==1 && xstate
        syms Xrw_l Xrw Xrw_p
        xlev = [Xrw_l,Xrw,Xrw_p];
        xexp = [exp(Xrw_l)/(1+exp(Xrw_l)),exp(Xrw)/(1+exp(Xrw)),exp(Xrw_p)/(1+exp(Xrw_p))];
        
        p_rw_usd   = subs(p_rw_usd , xlev,xexp);
        p_rw_eur   = subs(p_rw_eur , xlev,xexp);
        ph_rw_usd  = subs(ph_rw_usd, xlev,xexp);
        ph_rw_eur  = subs(ph_rw_eur, xlev,xexp);
        m_rw_til   = subs(m_rw_til , xlev,xexp);
        
    end
    
    
    
    %Uzawa-style
    bet_us = bet+tau_row*(Pusd*(Busd-Bus_usd)+Peur*(Beur-Bus_eur)+Prow*(Brow-Bus_row));
    bet_eu = bet+tau_row*(Pusd*(Busd-Beu_usd)+Peur*(Beur-Beu_eur)+Prow*(Brow-Beu_row));
    bet_rw = bet+tau_row*(Pusd*(Busd-Brw_usd)+Peur*(Beur-Brw_eur)+Prow*(Brow-Brw_row));
    
    
    %**************************************************************************
    % DEFERRED SUBSTITUIONS
    %**************************************************************************
    def_sub_nms = {'Cus','Ceu','Crw','Cus_us', 'Ceu_eu', 'Crw_rw','Pus_rw','Peu_rw','Prw_row',...
        'Beu_usd', 'Bus_eur', 'Brw_row'...'Bus_usd', 'Beu_eur',%
        'p_us_usd','p_us_eur','p_eu_usd','p_eu_eur', 'p_rw_usd', 'p_rw_eur',...
        'ph_us_usd','ph_us_eur','ph_us_row',...
        'ph_eu_usd','ph_eu_eur','ph_eu_row',...
        'ph_rw_usd','ph_rw_eur','ph_rw_row',...
        'm_us_til','m_eu_til','m_rw_til'};
    
    
    
    def_sub_nms = [def_sub_nms,{'pim_us_eu','pim_us_rw','pex_us_eu','pex_us_rw',...
        'pim_eu_us','pim_eu_rw','pex_eu_us','pex_eu_rw',...
        'pim_rw_us','pim_rw_eu','pim_rw_row','pex_rw_us','pex_rw_eu', 'pex_rw_row'}];
    
    if ~xstate && ~solve_dyn
        % def_sub_nms = [def_sub_nms,{'Xrw'}];
    end
    
    if ~solve_dyn
        def_sub_nms = [def_sub_nms, {'Bus_usd','Beu_eur','Brw_usd','Brw_eur','Bus_row', 'Beu_row'}];
    end
    
    nsub = length(def_sub_nms);def_sub_val = cell(1, nsub);def_sub_syms = cell(1,nsub);def_sub_sym = sym(zeros(1,nsub));
    for jj = 1:length(def_sub_sym)
        def_sub_val{jj} = eval(def_sub_nms{jj});%simplify(eval(def_sub_nms{jj}),'IgnoreAnalyticConstraints',true);
        eval(['syms ' def_sub_nms{jj}]);
        def_sub_sym(jj) = eval(def_sub_nms{jj});
    end
    
    args_def    = sym_args([symvar([def_sub_val{:}]),param_list], vcombo_ss);
    
    
    if redo_defsb
        if solve_dyn == 0
            
            %Def subs function
            def_sub_ss_call = sym2mex(def_sub_nms,def_sub_val,[vcombo_ss,args_def],'tofill_files/def_sub_ss_tofill.c','auto_generated/def_sub_ss_mex.c', 'def_sub_ss_mex','auto_generated');
            
            %Derivate there-of
            ddef_sub_val = jacobian([def_sub_val{:}],[vcombo_ss]);
            ddef_sub_ss_call = sym2mex({'dsub'},{ddef_sub_val},[vcombo_ss,args_def],'tofill_files/def_sub_ss_tofill.c','auto_generated/ddef_sub_ss_mex.c', 'ddef_sub_ss_mex','auto_generated');
            
        else
            matlabFunction(def_sub_val{:}, 'File', 'auto_generated/def_sub.m', 'Outputs', def_sub_nms, 'Vars',[vcombo_ss,args_def], 'Optimize', optimize);
            matlabFunction(jacobian([def_sub_val{:}],[vcombo_ss]), 'File', 'auto_generated/ddef_sub.m', 'Outputs', {'ddeff'}, 'Vars',[vcombo_ss,args_def], 'Optimize', optimize);
            matlabFunction(jacobian([def_sub_val{:}],[state_lag]), 'File', 'auto_generated/ddef_sub_lag.m', 'Outputs', {'ddeff_lag'}, 'Vars',[vcombo_ss,args_def], 'Optimize', optimize);
            
            def_sub_call = sym2mex(def_sub_nms,def_sub_val,[vcombo_ss,args_def],'tofill_files/def_sub_ss_tofill.c','auto_generated/def_sub_mex.c', 'def_sub_mex','auto_generated');
            
            
        end
    end
    
    %**************************************************************************
    % TRADE MODEL
    %**************************************************************************
    
    %Fixed trade entry costs;
    fc_us = phi*Pus;
    fc_eu = phi*Peu;
    fc_rw = phi*Prw;
    
    fr_usd = r;
    fr_eur = r;
    
    %Trading market matching, how many in each market
    mei_us_eu = pex_us_eu*m_us_til;
    mei_us_rw = pex_us_rw*m_us_til;
    
    mei_eu_us = pex_eu_us*m_eu_til;
    mei_eu_rw = pex_eu_rw*m_eu_til;
    
    mei_rw_us = pex_rw_us*m_rw_til;
    mei_rw_eu = pex_rw_eu*m_rw_til;
    mei_rw_rw = pex_rw_row*m_rw_til;
    
    
    mie_us_eu = pim_us_eu*m_us_til;
    mie_us_rw = pim_us_rw*m_us_til;
    
    mie_eu_us = pim_eu_us*m_eu_til;
    mie_eu_rw = pim_eu_rw*m_eu_til;
    
    mie_rw_us = pim_rw_us*m_rw_til;
    mie_rw_eu = pim_rw_eu*m_rw_til;
    mie_rw_rw = pim_rw_row*m_rw_til;
    
    %Dollar densities in each country
    Xus_til = Xus*p_us_usd/(Xus*p_us_usd + (1-Xus)*p_us_eur);   %fraction of funded US firms with dollars
    Xeu_til = Xeu*p_eu_usd/(Xeu*p_eu_usd + (1-Xeu)*p_eu_eur);   %fraction of funded EU firms with dollars
    Xrw_til = Xrw*p_rw_usd/(Xrw*p_rw_usd + (1-Xrw)*p_rw_eur);   %fraction of funded RW firms with dollars
    
    %trade matching
    trd_match= @(x) 1/((1+x^(1/vepst))^vepst);
    
    pie_us_eu = trd_match(mie_us_eu/mei_eu_us);
    pie_us_rw = trd_match(mie_us_rw/mei_rw_us);
    
    pie_eu_us = trd_match(mie_eu_us/mei_us_eu);
    pie_eu_rw = trd_match(mie_eu_rw/mei_rw_eu);
    
    pie_rw_us = trd_match(mie_rw_us/mei_us_rw);
    pie_rw_eu = trd_match(mie_rw_eu/mei_eu_rw);
    pie_rw_rw = trd_match(mie_rw_rw/mei_rw_rw);
    
    pei_us_eu = trd_match(mei_us_eu/mie_eu_us);
    pei_us_rw = trd_match(mei_us_rw/mie_rw_us);
    
    pei_eu_us = trd_match(mei_eu_us/mie_us_eu);
    pei_eu_rw = trd_match(mei_eu_rw/mie_rw_eu);
    
    pei_rw_us = trd_match(mei_rw_us/mie_us_rw);
    pei_rw_eu = trd_match(mei_rw_eu/mie_eu_rw);
    pei_rw_rw = trd_match(mei_rw_rw/mie_rw_rw);
    
    
    %**************************************************************************
    % "WHOLESALE" TRADE PRICES
    %**************************************************************************
    
    PWus_eu    = Peu_eu + (1-alph)*(Pus_eu - Peu_eu);
    PWus_rw    = Prw_rw + (1-alph)*(Pus_rw - Prw_rw);
    
    PWeu_us    = Pus_us + (1-alph)*(Peu_us - Pus_us);
    PWeu_rw    = Prw_rw + (1-alph)*(Peu_rw - Prw_rw);
    
    PWrw_us    = Pus_us + (1-alph)*(Prw_us - Pus_us);
    PWrw_eu    = Peu_eu + (1-alph)*(Prw_eu - Peu_eu);
    PWrw_row   = Prw_rw + (1-alph)*(Prw_row - Prw_rw);
    
    %**************************************************************************
    % US Payoffs
    %**************************************************************************
    
    %US firms:
    %first ling e.g. - importer profits of US firms importing from EU using dollars
    PIus_eu_usd =  pie_us_eu*(1-alph)/PWus_eu*((Pus_eu - Peu_eu) - kap*PWus_eu*(1-Xeu_til));
    PIus_rw_usd =  pie_us_rw*(1-alph)/PWus_rw*((Pus_rw - Prw_rw) - kap*PWus_rw*(1-Xrw_til));
    
    PIus_eu_eur =  pie_us_eu*(1-alph)/PWus_eu*((Pus_eu - Peu_eu) - kap*PWus_eu*(Xeu_til));
    PIus_rw_eur =  pie_us_rw*(1-alph)/PWus_rw*((Pus_rw - Prw_rw) - kap*PWus_rw*(Xrw_til));
    
    PEus_eu_usd =  pei_us_eu*alph/PWeu_us*((Peu_us - Pus_us) - kap*PWeu_us*(1-Xeu_til));
    PEus_rw_usd =  pei_us_rw*alph/PWrw_us*((Prw_us - Pus_us) - kap*PWrw_us*(1-Xrw_til));
    
    PEus_eu_eur =  pei_us_eu*alph/PWeu_us*((Peu_us - Pus_us) - kap*PWeu_us*(Xeu_til));
    PEus_rw_eur =  pei_us_rw*alph/PWrw_us*((Prw_us - Pus_us) - kap*PWrw_us*(Xrw_til));
    
    
    %EU firms
    PIeu_us_usd =  pie_eu_us*(1-alph)/PWeu_us*((Peu_us - Pus_us) - kap*PWeu_us*(1-Xus_til));
    PIeu_rw_usd =  pie_eu_rw*(1-alph)/PWeu_rw*((Peu_rw - Prw_rw) - kap*PWeu_rw*(1-Xrw_til));
    
    PIeu_us_eur =  pie_eu_us*(1-alph)/PWeu_us*((Peu_us - Pus_us) - kap*PWeu_us*(Xus_til));
    PIeu_rw_eur =  pie_eu_rw*(1-alph)/PWeu_rw*((Peu_rw - Prw_rw) - kap*PWeu_rw*(Xrw_til));
    
    PEeu_us_usd =  pei_eu_us*alph/PWus_eu*((Pus_eu - Peu_eu) - kap*PWus_eu*(1-Xus_til));
    PEeu_rw_usd =  pei_eu_rw*alph/PWrw_eu*((Prw_eu - Peu_eu) - kap*PWrw_eu*(1-Xrw_til));
    
    PEeu_us_eur =  pei_eu_us*alph/PWus_eu*((Pus_eu - Peu_eu) - kap*PWus_eu*(Xus_til));
    PEeu_rw_eur =  pei_eu_rw*alph/PWrw_eu*((Prw_eu - Peu_eu) - kap*PWrw_eu*(Xrw_til));
    
    
    
    %ROW firms
    PIrw_us_usd =  pie_rw_us*(1-alph)/PWrw_us *((Prw_us - Pus_us) - kap*PWrw_us *(1-Xus_til));
    PIrw_eu_usd =  pie_rw_eu*(1-alph)/PWrw_eu *((Prw_eu - Peu_eu) - kap*PWrw_eu *(1-Xeu_til));
    PIrw_rw_usd =  pie_rw_rw*(1-alph)/PWrw_row*((Prw_row - Prw_rw) - kap*PWrw_row*(1-Xrw_til));
    
    PIrw_us_eur =  pie_rw_us*(1-alph)/PWrw_us *((Prw_us - Pus_us) - kap*PWrw_us *(Xus_til));
    PIrw_eu_eur =  pie_rw_eu*(1-alph)/PWrw_eu *((Prw_eu - Peu_eu) - kap*PWrw_eu *(Xeu_til));
    PIrw_rw_eur =  pie_rw_rw*(1-alph)/PWrw_row*((Prw_row - Prw_rw) - kap*PWrw_row*(Xrw_til));
    
    PErw_us_usd =  pei_rw_us*alph/PWus_rw *((Pus_rw - Prw_rw)  - kap*PWus_rw *(1-Xus_til));
    PErw_eu_usd =  pei_rw_eu*alph/PWeu_rw *((Peu_rw - Prw_rw)  - kap*PWeu_rw *(1-Xeu_til));
    PErw_rw_usd =  pei_rw_rw*alph/PWrw_row*((Prw_row - Prw_rw) - kap*PWrw_row*(1-Xrw_til));
    
    PErw_us_eur =  pei_rw_us*alph/PWus_rw *((Pus_rw - Prw_rw)  - kap*PWus_rw *(Xus_til));
    PErw_eu_eur =  pei_rw_eu*alph/PWeu_rw *((Peu_rw - Prw_rw)  - kap*PWeu_rw *(Xeu_til));
    PErw_rw_eur =  pei_rw_rw*alph/PWrw_row*((Prw_row - Prw_rw) - kap*PWrw_row*(Xrw_til));
    
    %**************************************************************************
    % COMBINED PAYOFFS
    %**************************************************************************
    
    %US
    Pi_us_usd = p_us_usd*(pim_us_eu*PIus_eu_usd + pim_us_rw*PIus_rw_usd + ...
        pex_us_eu*PEus_eu_usd + pex_us_rw*PEus_rw_usd - fr_usd) - fc_us;
    
    Pi_us_eur = p_us_eur*(pim_us_eu*PIus_eu_eur + pim_us_rw*PIus_rw_eur + ...
        pex_us_eu*PEus_eu_eur + pex_us_rw*PEus_rw_eur - fr_eur) - fc_us;
    
    %EU
    Pi_eu_usd = p_eu_usd*(pim_eu_us*PIeu_us_usd + pim_eu_rw*PIeu_rw_usd + ...
        pex_eu_us*PEeu_us_usd + pex_eu_rw*PEeu_rw_usd - fr_usd) - fc_eu;
    
    Pi_eu_eur = p_eu_eur*(pim_eu_us*PIeu_us_eur + pim_eu_rw*PIeu_rw_eur + ...
        pex_eu_us*PEeu_us_eur + pex_eu_rw*PEeu_rw_eur - fr_eur) - fc_eu;
    
    %RW
    Pi_rw_usd = p_rw_usd*(pim_rw_us*PIrw_us_usd + pim_rw_eu*PIrw_eu_usd + pim_rw_row*PIrw_rw_usd + ...
        pex_rw_us*PErw_us_usd + pex_rw_eu*PErw_eu_usd + pex_rw_row*PErw_rw_usd - fr_usd) - fc_rw;
    
    Pi_rw_eur = p_rw_eur*(pim_rw_us*PIrw_us_eur + pim_rw_eu*PIrw_eu_eur + pim_rw_row*PIrw_rw_eur + ...
        pex_rw_us*PErw_us_eur + pex_rw_eu*PErw_eu_eur + pex_rw_row*PErw_rw_eur - fr_eur) - fc_rw;
    
    
    
    %**************************************************************************
    % KAP COSTS
    %**************************************************************************
    MMus_usd = Xus*p_us_usd*(...
        (1-alph)*(pim_us_eu*pie_us_eu*(1-Xeu_til) + pim_us_rw*pie_us_rw*(1-Xrw_til))+...
        alph    *(pex_us_eu*pei_us_eu*(1-Xeu_til) + pex_us_rw*pei_us_rw*(1-Xrw_til)));
    
    MMus_eur = (1-Xus)*p_us_eur*(...
        (1-alph)*(pim_us_eu*pie_us_eu*(Xeu_til) + pim_us_rw*pie_us_rw*(Xrw_til))+...
        alph    *(pex_us_eu*pei_us_eu*(Xeu_til) + pex_us_rw*pei_us_rw*(Xrw_til)));
    
    MMus = m_us*(MMus_usd + MMus_eur)*kap;
    
    
    MMeu_usd = Xeu*p_eu_usd*(...
        (1-alph)*(pim_eu_us*pie_eu_us*(1-Xus_til) + pim_eu_rw*pie_eu_rw*(1-Xrw_til))+...
        alph    *(pex_eu_us*pei_eu_us*(1-Xus_til) + pex_eu_rw*pei_eu_rw*(1-Xrw_til)));
    
    MMeu_eur = (1-Xeu)*p_eu_eur*(...
        (1-alph)*(pim_eu_us*pie_eu_us*(Xus_til) + pim_eu_rw*pie_eu_rw*(Xrw_til))+...
        alph    *(pex_eu_us*pei_eu_us*(Xus_til) + pex_eu_rw*pei_eu_rw*(Xrw_til)));
    
    MMeu = m_eu*(MMeu_usd + MMeu_eur)*kap;
    
    
    
    MMrw_usd = Xrw*p_rw_usd*(...
        (1-alph)*(pim_rw_us*pie_rw_us*(1-Xus_til) + pim_rw_eu*pie_rw_eu*(1-Xeu_til) + pim_rw_row*pie_rw_rw*(1-Xrw_til))+...
        alph    *(pex_rw_us*pei_rw_us*(1-Xus_til) + pex_rw_eu*pei_rw_eu*(1-Xeu_til) + pex_rw_row*pei_rw_rw*(1-Xrw_til)));
    
    MMrw_eur = (1-Xrw)*p_rw_eur*(...
        (1-alph)*(pim_rw_us*pie_rw_us*(Xus_til) + pim_rw_eu*pie_rw_eu*(Xeu_til) + pim_rw_row*pie_rw_rw*(Xrw_til))+...
        alph    *(pex_rw_us*pei_rw_us*(Xus_til) + pex_rw_eu*pei_rw_eu*(Xeu_til) + pex_rw_row*pei_rw_rw*(Xrw_til)));
    
    
    MMrw = m_rw*(MMrw_usd + MMrw_eur)*kap;
    
    %**************************************************************************
    % Tariffs Collected
    %**************************************************************************
    UStariff = tax_us_eu*Pus_eu*Cus_eu + tax_us_rw*Pus_rw*Cus_rw;
    EUtariff = tax_eu_us*Peu_us*Ceu_us + tax_eu_rw*Peu_rw*Ceu_rw;
    RWtariff = tax_rw_us*Prw_us*Crw_us + tax_rw_eu*Prw_eu*Crw_eu + tax_rw_row*Prw_row*Crw_row;
    
    %**************************************************************************
    % Capital Flow Tax Collected
    %**************************************************************************
    
    USoutflow_tax = tax_us_out*Peu*Bus_eur_l;
    EUoutflow_tax = tax_eu_out*Pus*Beu_usd_l;
    RWoutflow_tax = tax_rw_out*(Pus*Brw_usd_l + Peu*Brw_eur_l);
    
    USinflow_tax = tax_us_in*Pus*( Beu_usd_l*mu_eu/mu_us + Brw_usd_l*mu_rw/mu_us);
    EUinflow_tax = tax_eu_in*Peu*( Bus_eur_l*mu_us/mu_eu + Brw_eur_l*mu_rw/mu_eu);
    
    %**************************************************************************
    % US/EU Cutoff Choices
    %**************************************************************************
    Vdef   = Vusd - (Pi_rw_usd - Pi_rw_eur)*(1-bet_rw*(1-omg)) - bet_rw*(1-omg)*Vusd_p;
    CUT_rw =        (Pi_rw_usd - Pi_rw_eur)*(1-bet_rw*(1-omg)) + bet_rw*(1-omg)*Vusd_p + sbar_rw*sige;
    
    sbar_solve_ = -1/sige*(Pi_rw_usd - Pi_rw_eur);
    %**************************************************************************
    % PROFITS
    %**************************************************************************
    PROFus_pc = m_us*(Xus*Pi_us_usd + (1-Xus)*Pi_us_eur);
    PROFeu_pc = m_eu*(Xeu*Pi_eu_usd + (1-Xeu)*Pi_eu_eur);
    PROFrw_pc = m_rw*(Xrw*Pi_rw_usd + (1-Xrw)*Pi_rw_eur);
    
    %**************************************************************************
    % ENTRY CONDITION
    %**************************************************************************
    ENTRY_us = Xus*Pi_us_usd + (1-Xus)*Pi_us_eur;
    ENTRY_eu = Xeu*Pi_eu_usd + (1-Xeu)*Pi_eu_eur;
    ENTRY_rw = Xrw*Pi_rw_usd + (1-Xrw)*Pi_rw_eur;
    
    
    %**************************************************************************
    % US im/ex & us/eu/row probability choice
    %**************************************************************************
    
    
    %US nps
    np_us_usd1 = PIus_eu_usd-PIus_rw_usd;
    np_us_eur1 = PIus_eu_eur-PIus_rw_eur;
    np_us1     = Xus*np_us_usd1 + (1-Xus)*np_us_eur1;
    
    np_us_usd2 = PEus_eu_usd-PEus_rw_usd;
    np_us_eur2 = PEus_eu_eur-PEus_rw_eur;
    np_us2     = Xus*np_us_usd2 + (1-Xus)*np_us_eur2;
    
    np_us_usd3 = PEus_eu_usd-PIus_eu_usd;
    np_us_eur3 = PEus_eu_eur-PIus_eu_eur;
    np_us3     = Xus*np_us_usd3 + (1-Xus)*np_us_eur3;
    
    %EU nps
    np_eu_usd1 = PIeu_us_usd-PIeu_rw_usd;
    np_eu_eur1 = PIeu_us_eur-PIeu_rw_eur;
    np_eu1     = Xeu*np_eu_usd1 + (1-Xeu)*np_eu_eur1;
    
    np_eu_usd2 = PEeu_us_usd-PEeu_rw_usd;
    np_eu_eur2 = PEeu_us_eur-PEeu_rw_eur;
    np_eu2     = Xeu*np_eu_usd2 + (1-Xeu)*np_eu_eur2;
    
    np_eu_usd3 = PEeu_us_usd-PIeu_us_usd;
    np_eu_eur3 = PEeu_us_eur-PIeu_us_eur;
    np_eu3     = Xeu*np_eu_usd3 + (1-Xeu)*np_eu_eur3;
    
    %RW nps
    np_rw_usd1 = PIrw_us_usd-PIrw_eu_usd;
    np_rw_eur1 = PIrw_us_eur-PIrw_eu_eur;
    np_rw1     = Xrw*np_rw_usd1 + (1-Xrw)*np_rw_eur1;
    
    np_rw_usd2 = PIrw_eu_usd-PIrw_rw_usd;
    np_rw_eur2 = PIrw_eu_eur-PIrw_rw_eur;
    np_rw2     = Xrw*np_rw_usd2 + (1-Xrw)*np_rw_eur2;
    
    np_rw_usd3 = PErw_us_usd-PErw_eu_usd;
    np_rw_eur3 = PErw_us_eur-PErw_eu_eur;
    np_rw3     = Xrw*np_rw_usd3 + (1-Xrw)*np_rw_eur3;
    
    np_rw_usd4 = PErw_eu_usd-PErw_rw_usd;
    np_rw_eur4 = PErw_eu_eur-PErw_rw_eur;
    np_rw4     = Xrw*np_rw_usd4 + (1-Xrw)*np_rw_eur4;
    
    np_rw_usd5 = PErw_eu_usd-PIrw_eu_usd;
    np_rw_eur5 = PErw_eu_eur-PIrw_eu_eur;
    np_rw5     = Xrw*np_rw_usd5 + (1-Xrw)*np_rw_eur5;
    
    
    
    nps_ = [np_us1 np_us2 np_us3,...
        np_eu1 np_eu2 np_eu3,...
        np_rw1 np_rw2 np_rw3 np_rw4,np_rw5];
    
    
    
    %**************************************************************************
    % DELTAs to output to shell model
    %**************************************************************************
    del_us_usd = ph_us_usd*r;
    del_us_eur = ph_us_eur*r;
    del_us_row = ph_us_row*r;
    
    del_eu_usd = ph_eu_usd*r;
    del_eu_eur = ph_eu_eur*r;
    del_eu_row = ph_eu_row*r;
    
    
    del_rw_usd = ph_rw_usd*r;
    del_rw_eur = ph_rw_eur*r;
    del_rw_row = ph_rw_row*r;
    
    
    %**************************************************************************
    % Import Quantities Per Capita
    %**************************************************************************
    IMPus_eu = m_us*pim_us_eu*(Xus*p_us_usd +(1-Xus)*p_us_eur)*(pie_us_eu*1/PWus_eu);
    IMPus_rw = m_us*pim_us_rw*(Xus*p_us_usd +(1-Xus)*p_us_eur)*(pie_us_rw*1/PWus_rw);
    
    IMPeu_us = m_eu*pim_eu_us*(Xeu*p_eu_usd +(1-Xeu)*p_eu_eur)*(pie_eu_us*1/PWeu_us);
    IMPeu_rw = m_eu*pim_eu_rw*(Xeu*p_eu_usd +(1-Xeu)*p_eu_eur)*(pie_eu_rw*1/PWeu_rw);
    
    IMPrw_us = m_rw*pim_rw_us*(Xrw*p_rw_usd +(1-Xrw)*p_rw_eur)*(pie_rw_us*1/PWrw_us);
    IMPrw_eu = m_rw*pim_rw_eu*(Xrw*p_rw_usd +(1-Xrw)*p_rw_eur)*(pie_rw_eu*1/PWrw_eu);
    IMPrw_rw = m_rw*pim_rw_row*(Xrw*p_rw_usd +(1-Xrw)*p_rw_eur)*(pie_rw_rw*1/PWrw_row);
    
    %**************************************************************************
    % GENERATE FUNCTIONS THAT DESCRIBE INDIFFERENCE CONDITIONS
    %**************************************************************************
    if xstate && solve_dyn
        sbar_cond = Xrw - (1-omg)*Xrw_l - omg*(z +(1-2*z)*(1-sdist(sbar_rw)));
    else
        sbar_cond = [];
    end
    
    PINDS = [ENTRY_us,ENTRY_eu,ENTRY_rw,nps_,sbar_cond,100*Vdef,100*CUT_rw];
    
    %**************************************************************************
    %US equations
    %**************************************************************************
    fus = sym([]);
    fus(end+1) = ((1-ah_us)*wus_eu/ah_us)^(1/eta)*(Cus_us/Cus_eu)^(1/eta) - ((1+tax_us_eu)*Pus_eu)/Pus_us;
    fus(end+1) = ((1-ah_us)*wus_rw/ah_us)^(1/eta)*(Cus_us/Cus_rw)^(1/eta) - ((1+tax_us_rw)*Pus_rw)/Pus_us;
    fus(end+1) = Pus_us*Cus_us + Pus_eu*Cus_eu + Pus_rw*Cus_rw + Pusd*(Busd_l/mu_us) + Pusd*Bus_usd*Qusd*(1 - del_us_usd) + Peur*Bus_eur*Qeur*(1 - del_us_eur) + Prow*Bus_row*Qrow*(1-0*del_us_row)...
        - (1-phi_usg)*Pus_us*Yus - Pusd*Qusd*Busd/mu_us  - Pusd*Bus_usd_l - Peur*Bus_eur_l*(1 - tax_eu_in) - Prow*Bus_row_l - PROFus_pc - m_us*fc_us - MMus - USinflow_tax;
    
    us_euler = sym([]);
    us_euler(end+1) = 1-bet_us*(Cus_p/Cus)^(-sig)*(Pus/Pus_p)*(Pusd_p/Pusd)* ( 1 + Qusd_p*tau_us_usd_p)/( Qusd*(1 + tau_us_usd - del_us_usd) );
    us_euler(end+1) = 1-bet_us*(Cus_p/Cus)^(-sig)*(Pus/Pus_p)*(Peur_p/Peur)* ( 1 + Qeur_p*tau_us_eur_p)/( Qeur*(1 + tau_us_eur - del_us_eur) );
    us_euler(end+1) = 1-bet_us*(Cus_p/Cus)^(-sig)*(Pus/Pus_p)*(Prow_p/Prow)* ( 1 + Qrow_p*tau_us_row_p)/( Qrow*(1 + tau_us_row - del_us_row) );
    
    
    %**************************************************************************
    %EU equations
    %**************************************************************************
    feu = sym([]);
    feu(end+1) = ((1-ah_eu)*weu_us/ah_eu)^(1/eta)*(Ceu_eu/Ceu_us)^(1/eta) - ((1+tax_eu_us)*Peu_us)/Peu_eu;
    feu(end+1) = ((1-ah_eu)*weu_rw/ah_eu)^(1/eta)*(Ceu_eu/Ceu_rw)^(1/eta) - ((1+tax_eu_rw)*Peu_rw)/Peu_eu;
    feu(end+1) = Peu_us*Ceu_us + Peu_eu*Ceu_eu + Peu_rw*Ceu_rw + Peur*(Beur_l/mu_eu) + Pusd*Beu_usd*Qusd*(1 - del_eu_usd) + Peur*Beu_eur*Qeur*(1 - del_eu_eur) + Prow*Beu_row*Qrow*(1 - 0*del_eu_row) ...
        - (1-phi_eug)*Peu_eu*Yeu - Peur*Qeur*Beur/mu_eu - Pusd*Beu_usd_l*(1 - tax_us_in) - Peur*Beu_eur_l - Prow*Beu_row_l - PROFeu_pc - m_eu*fc_eu - MMeu - EUinflow_tax;
    
    eu_euler = sym([]);
    eu_euler(end+1) = 1- bet_eu*(Ceu_p/Ceu)^(-sig)*(Peu/Peu_p)*(Pusd_p/Pusd)*( 1 + Qusd_p*tau_eu_usd_p)/(Qusd*(1 + tau_eu_usd - del_eu_usd) );
    eu_euler(end+1) = 1- bet_eu*(Ceu_p/Ceu)^(-sig)*(Peu/Peu_p)*(Peur_p/Peur)*( 1 + Qeur_p*tau_eu_eur_p)/(Qeur*(1 + tau_eu_eur - del_eu_eur) );
    eu_euler(end+1) = 1- bet_eu*(Ceu_p/Ceu)^(-sig)*(Peu/Peu_p)*(Prow_p/Prow)*( 1 + Qrow_p*tau_eu_row_p)/(Qrow*(1 + tau_eu_row - del_eu_row) );
    
    
    
    %**************************************************************************
    %RW equations
    %**************************************************************************
    frw = sym([]);
    frw(end+1) = ((1-ah_rw)*wrw_row/ah_rw)^(1/eta)*(Crw_rw/Crw_row)^(1/eta) - ((1+tax_rw_row)*Prw_row)/Prw_rw;
    frw(end+1) = ((1-ah_rw)*wrw_us /ah_rw)^(1/eta)*(Crw_rw/Crw_us )^(1/eta) - ((1+tax_rw_us)*Prw_us)/Prw_rw;
    frw(end+1) = ((1-ah_rw)*wrw_eu /ah_rw)^(1/eta)*(Crw_rw/Crw_eu )^(1/eta) - ((1+tax_rw_eu)*Prw_eu)/Prw_rw;
    
    %RW buget set, not inclued b.c. walras' law
    walras_ = Prw_rw*Crw_rw + Prw_us*Crw_us + Prw_eu*Crw_eu + Prw_row*Crw_row + Prow*(Brow_l/mu_rw) + Pusd*Brw_usd*Qusd*(1 - del_rw_usd) + Peur*Brw_eur*Qeur*(1 - del_rw_eur) + Prow*Brw_row*Qrow*(1 - 0*del_rw_row) ...
        - (1-phi_rwg)*Prw_rw*Yrw - Prow*Qrow*Brow/mu_rw - Pusd*Brw_usd_l - Peur*Brw_eur_l - Prow*Brw_row_l - PROFrw_pc - m_rw*fc_rw - MMrw;
    
    rw_euler = sym([]);
    rw_euler(end+1) = 1- bet_rw*(Crw_p/Crw)^(-sig)*(Prw/Prw_p)*(Pusd_p/Pusd)*( 1  + Qusd_p*tau_rw_usd_p)/(Qusd*(1 + tau_rw_usd - del_rw_usd) );
    rw_euler(end+1) = 1- bet_rw*(Crw_p/Crw)^(-sig)*(Prw/Prw_p)*(Peur_p/Peur)*( 1  + Qeur_p*tau_rw_eur_p)/(Qeur*(1 + tau_rw_eur - del_rw_eur) );
    rw_euler(end+1) = 1- bet_rw*(Crw_p/Crw)^(-sig)*(Prw/Prw_p)*(Prow_p/Prow)*( 1  + Qrow_p*tau_rw_row_p)/(Qrow*(1 + tau_rw_row - del_rw_row) );
    
    
    %**************************************************************************
    %Market Clearing Equations
    %**************************************************************************
    fmc = sym([]);
    fmc(end+1) = Cus_eu  - IMPus_eu;
    fmc(end+1) = Cus_rw  - IMPus_rw;
    
    fmc(end+1) = Ceu_us  - IMPeu_us;
    fmc(end+1) = Ceu_rw  - IMPeu_rw;
    
    fmc(end+1) = Crw_us  - IMPrw_us;
    fmc(end+1) = Crw_eu  - IMPrw_eu;
    fmc(end+1) = Crw_row - IMPrw_rw;
    
    
    if solve_dyn==1 && xstate
        syms Xrw_l Xrw Xrw_p
        xlev = [Xrw_l,Xrw,Xrw_p];
        xexp = [exp(Xrw_l)/(1+exp(Xrw_l)),exp(Xrw)/(1+exp(Xrw)),exp(Xrw_p)/(1+exp(Xrw_p))];
        
        fmc      = subs(fmc,xlev,xexp);
        PINDS    = subs(PINDS, xlev,xexp);
        fus      = subs(fus, xlev,xexp);
        feu      = subs(feu, xlev,xexp);
        frw      = subs(frw, xlev,xexp);
        us_euler = subs(us_euler,xlev,xexp);
        rw_euler = subs(rw_euler,xlev,xexp);
        eu_euler = subs(eu_euler,xlev,xexp);
    end
    
    %**************************************************************************
    %Make Symbolic Residul Vector
    %**************************************************************************
    if solve_dyn
        fcombo_dyn = transpose([fus,feu,frw,fmc,100*us_euler,100*eu_euler,100*rw_euler,PINDS]); %Use to have 100's here on eulers
        dpres      = jacobian(fcombo_dyn,[jump_vars,state_vars,def_sub_sym]);
        dfutr      = [jacobian(fcombo_dyn,jump_prime),jacobian(fcombo_dyn,state_prime)];
        dpast      = jacobian(fcombo_dyn,state_lag);
        dpast_def  = jacobian(fcombo_dyn,def_sub_sym);
    else
        fcombo     = transpose([fus,feu,frw,fmc,100*us_euler,PINDS]); fcombo_ss = subs(fcombo,[jump_prime,state_lag,state_prime],[jump_vars,state_vars,state_vars]);
        dfcombo_ss = jacobian(fcombo_ss,[jump_vars,state_vars,def_sub_sym]);
    end
    
    %% make frac(B's)
    
    frac_ = sym(zeros(4,1));
    frac_(1) = Brw_usd*mu_rw/Busd;
    frac_(2) = Brw_eur*mu_rw/Beur;
    frac_(3) = Bus_usd*mu_us./(Busd*(1-frac_(1)));
    frac_(4) = Beu_eur*mu_eu./(Beur*(1-frac_(2)));
    Bvec = [Brw_usd,Brw_eur,Bus_usd,Beu_eur];
    dfrac_ = jacobian(frac_,Bvec);
    
    
    syms frac_rw_usd frac_rw_eur frac_us_usd frac_eu_eur
    B_ = sym(zeros(4,1));
    B_(1) = frac_rw_usd*Busd/mu_rw;
    B_(2) = frac_rw_eur*Beur/mu_rw;
    B_(3) = frac_us_usd*(1-frac_rw_usd)*Busd/mu_us;
    B_(4) = frac_eu_eur*(1-frac_rw_eur)*Beur/mu_eu;
    
    if redo_bonds && solve_dyn == 1
        matlabFunction(frac_ , 'File', 'auto_generated/B2frac.m', 'Outputs', {'out'}, 'Vars',{Bvec.',Busd,Beur,mu_us,mu_eu,mu_rw}, 'Optimize', optimize);
        matlabFunction(dfrac_, 'File', 'auto_generated/dfrac.m', 'Outputs', {'out'}, 'Vars',symvar(dfrac_), 'Optimize', optimize);
        matlabFunction(B_    , 'File', 'auto_generated/frac2B.m', 'Outputs', {'out'}, 'Vars',{[frac_rw_usd; frac_rw_eur; frac_us_usd; frac_eu_eur],Busd,Beur,mu_us,mu_eu,mu_rw}, 'Optimize', optimize);
    end
    
    %% THINGS TO COMPUTE
    
    %Interest rates
    Rusd = 1/Qusd - 1;
    Reur = 1/Qeur - 1;
    
    %DELTAS
    delts_ = [del_us_usd,del_eu_usd,del_rw_usd;
        del_us_eur,del_eu_eur,del_rw_eur;
        del_us_row,del_eu_row,del_rw_row];
    
    %BOND HOLDINGS
    bonds_ = [Bus_usd Beu_usd Brw_usd;
        Bus_eur Beu_eur Brw_usd;
        Bus_row Beu_row Brw_row];
    
    %BETS
    bets_  = [bet_us, bet_eu, bet_rw];
    
    %PRICES
    prices_ = [Pus Peu Prw;...
        Pus_us,Peu_eu,Prw_rw];
    
    %GROSS ASSET POSITIONS
    gross_ = [(Peur*Bus_eur*Qeur+Prow*Bus_row*Qrow)/(per_p_year*Pus_us*Yus)      , (Pusd*Beu_usd*Qusd+Prow*Beu_row*Qrow)  /(per_p_year*Peu_eu*Yeu)          ,(Pusd*Brw_usd*Qusd + Peur*Brw_eur*Qeur)/(per_p_year*Prw_rw*Yrw);...
        Pusd*(Beu_usd*mu_eu+Brw_usd*mu_rw)*Qusd    /(per_p_year*Pus_us*Yus*mu_us), Peur*(Bus_eur*mu_us+Brw_eur*mu_rw)*Qeur/(per_p_year*Peu_eu*Yeu*mu_eu)    ,Prow*(Bus_row*mu_us+Beu_row*mu_eu)*Qrow/(per_p_year*Prw_rw*Yrw*mu_rw)];
    
    %Trade share
    ts_ = [(PWus_eu*Cus_eu*mu_us + PWeu_us*Ceu_us*mu_eu + PWus_rw*Cus_rw*mu_us + PWrw_us*Crw_us*mu_rw)/(mu_us*Pus_us*Yus),...
        (PWus_eu*Cus_eu*mu_us + PWeu_us*Ceu_us*mu_eu + PWeu_rw*Ceu_rw*mu_eu + PWrw_eu*Crw_eu*mu_rw)/(mu_eu*Peu_eu*Yeu),...
        (PWrw_us*Crw_us*mu_rw + PWrw_eu*Crw_eu*mu_rw + 2*PWrw_row*Crw_row*mu_rw + PWus_rw*Cus_rw*mu_us + PWeu_rw*Ceu_rw*mu_eu)/(mu_rw*Prw_rw*Yrw)]; %Note 3rd term is special
    
    %Trade balance
    tb_ = [(PWeu_us*Ceu_us*mu_eu + PWrw_us*Crw_us*mu_rw - PWus_eu*Cus_eu*mu_us - PWus_rw*Cus_rw*mu_us)/(mu_us*Pus_us*Yus)...
        (PWus_eu*Cus_eu*mu_us + PWrw_eu*Crw_eu*mu_rw - PWeu_us*Ceu_us*mu_eu - PWeu_rw*Ceu_rw*mu_eu)/(mu_eu*Peu_eu*Yeu)...
        (PWeu_rw*Ceu_rw*mu_eu + PWus_rw*Cus_rw*mu_us + PWrw_row*Crw_row*mu_rw - PWrw_us*Crw_us*mu_rw - PWrw_eu*Crw_eu*mu_rw - PWrw_row*Crw_row*mu_rw)/(mu_rw*Prw_rw*Yrw) ];
    
    %Home bias in portfolios #CHECK ROSEN!#
    sh_us_usd   = Pusd*Bus_usd*Qusd/(Peur*Bus_eur*Qeur + Pusd*Bus_usd*Qusd + Prow*Bus_row*Qrow);
    sh_eu_usd   = Pusd*Beu_usd*Qusd/(Peur*Beu_eur*Qeur + Pusd*Beu_usd*Qusd + Prow*Beu_row*Qrow);
    sh_rw_usd   = Pusd*Brw_usd*Qusd/(Peur*Brw_eur*Qeur + Pusd*Brw_usd*Qusd + Prow*Brw_row*Qrow);
    
    sh_us_eur   = Peur*Bus_eur*Qeur/(Peur*Bus_eur*Qeur + Pusd*Bus_usd*Qusd + Prow*Bus_row*Qrow);
    sh_eu_eur   = Peur*Beu_eur*Qeur/(Peur*Beu_eur*Qeur + Pusd*Beu_usd*Qusd + Prow*Beu_row*Qrow);
    sh_rw_eur   = Peur*Brw_eur*Qeur/(Peur*Brw_eur*Qeur + Pusd*Brw_usd*Qusd + Prow*Brw_row*Qrow);
    
    sh_us_row   = 1-sh_us_usd-sh_us_eur;
    sh_eu_row   = 1-sh_eu_usd-sh_eu_eur;
    sh_rw_row   = 1-sh_rw_usd-sh_rw_eur;
    
    sh_wrld_usd = Pusd*(Busd)*Qusd/(Peur*(Beur)*Qeur  + Pusd*(Busd)*Qusd + Prow*Brow*Qrow);
    sh_wrld_eur = Peur*(Beur)*Qeur/(Pusd*(Busd)*Qusd  + Peur*(Beur)*Qeur + Prow*Brow*Qrow);
    sh_wrld_row = Prow*(Brow)*Qrow/(Pusd*(Busd)*Qusd  + Peur*(Beur)*Qeur + Prow*Brow*Qrow);
    
    home_bias_ = [1 - (sh_us_eur+sh_us_row)/(sh_wrld_eur+sh_wrld_row), 1 - (sh_eu_usd+sh_eu_row)/(sh_wrld_usd+sh_wrld_row),1 - (sh_rw_usd+sh_rw_eur)/(sh_wrld_usd+sh_wrld_eur)];
    
    usd_shr_ = [sh_us_usd,sh_eu_usd,sh_rw_usd];
    
    %EP
    EP_ = -100*((1+Rusd)^per_p_year - (1+Reur)^per_p_year);
    
    %Gross debts
    GD_ = [Pusd*Qusd*Busd/(per_p_year*mu_us*Pus_us*Yus), Peur*Qeur*Beur/(per_p_year*mu_eu*Peu_eu*Yeu),Prow*Qrow*Brow/(per_p_year*mu_rw*Prw_rw*Yrw)];
    
    %Implied revenue (what if all my assets and liabilities earned a counterfactual
    %interest rate)
    IR_    = ((Reur*Peur*Bus_eur*mu_us*Qeur - Rusd*Pusd*(Beu_usd*mu_eu+Brw_usd*mu_rw)*Qusd)-(1/bet-1)*(Peur*Bus_eur*mu_us*Qeur-Pusd*(Beu_usd*mu_eu+Brw_usd*mu_rw)*Qusd))./(mu_us*Pus_us*Yus);
    IR_(2) = ((Rusd*Pusd*Beu_usd*mu_eu*Qusd - Reur*Peur*(Bus_eur*mu_us+Brw_eur*mu_rw)*Qeur)-(1/bet-1)*(Pusd*Beu_usd*mu_eu*Qusd-Peur*(Bus_eur*mu_us+Brw_eur*mu_rw)*Qeur))./(mu_eu*Peu_eu*Yeu);
    IR_(3) = NaN;
    
    %Funding probs
    fund_probs_ = [p_us_usd p_eu_usd p_rw_usd; p_us_eur p_eu_eur p_rw_eur];
    
    %Trade matching probs
    tr_probs_ = [0      , pei_us_eu, pei_us_rw;
        pei_eu_us, 0        , pei_eu_rw;
        pei_rw_us, pei_rw_eu, pei_rw_rw;
        0        , pie_us_eu, pie_us_rw;
        pie_eu_us, 0        , pie_eu_rw;
        pie_rw_us, pie_rw_eu, pie_rw_rw; ];
    
    tr_probs_  = subs(tr_probs_, plev,pexp);
    
    PTRAD_ = [NaN      , pim_us_eu, pim_us_rw , NaN      , pex_us_eu  ,pex_us_rw;...
        pim_eu_us, NaN      , pim_eu_rw , pex_eu_us, NaN        ,pex_eu_rw;...
        pim_rw_us, pim_rw_eu, pim_rw_row, pex_rw_us, pex_rw_eu  ,pex_rw_row];
    
    PTRAD_  = subs(PTRAD_, plev,pexp);
    
    tau_ = [tau_us_usd tau_eu_usd tau_rw_usd; tau_us_eur tau_eu_eur tau_rw_eur];
    taup_ = [tau_us_usd_p tau_eu_usd_p tau_rw_usd_p; tau_us_eur_p tau_eu_eur_p tau_rw_eur_p];
    
    returns_ = [ Pusd_p/Pusd*(1/Qusd) Peur_p/Peur*(1/Qeur) Prow_p/Prow*(1/Qrow) ];
    
    %Net payoffs of visintg US/EU for EU firms
    %nps_ = [np_us, np_eu, np_rw1, np_rw2]./phi;
    
    
    %% Redo main
    if redo_main
        if solve_dyn
            
            vars_dyn = [jump_vars,state_vars,jump_prime,state_prime,state_lag];
            
            matlabFunction(sbar_solve_, 'File', 'auto_generated/sbar_solve.m', 'Outputs', {'out1'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            function_subs_mex('auto_generated/sbar_solve.m', def_sub_call, 'auto_generated/temp.text', def_sub_nms);
            
            matlabFunction(walras_, 'File', 'auto_generated/walras.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            function_subs_mex('auto_generated/walras.m', def_sub_call, 'auto_generated/temp.text', def_sub_nms);
            
            matlabFunction(fcombo_dyn, 'File', 'auto_generated/resid_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            function_subs_mex('auto_generated/resid_dyn.m', def_sub_call, 'auto_generated/temp.text', def_sub_nms);

            matlabFunction(dpres, 'File', 'auto_generated/dpres.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            function_subs_mex('auto_generated/dpres.m', def_sub_call, 'auto_generated/temp.text', def_sub_nms);
            
            matlabFunction(dfutr, 'File', 'auto_generated/dprlg.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            function_subs_mex('auto_generated/dprlg.m', def_sub_call, 'auto_generated/temp.text', def_sub_nms);
            
            matlabFunction(dpast, 'File', 'auto_generated/dpast.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            function_subs_mex('auto_generated/dpast.m', def_sub_call, 'auto_generated/temp.text', def_sub_nms);
            
            matlabFunction(dpast_def, 'File', 'auto_generated/dpast_def.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            function_subs_mex('auto_generated/dpast_def.m', def_sub_call, 'auto_generated/temp.text', def_sub_nms);
            
            %Outpute for "impulse responses"
            matlabFunction(usd_shr_, 'File', 'auto_generated/usd_shr_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            matlabFunction(Xrw, 'File', 'auto_generated/XRW_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            matlabFunction([Cus,Ceu,Crw].', 'File', 'auto_generated/cons_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            matlabFunction(tb_, 'File', 'auto_generated/tb_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            matlabFunction(gross_(1,:)-gross_(2,:), 'File', 'auto_generated/NFA_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            matlabFunction(EP_, 'File', 'auto_generated/EP_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            matlabFunction(bonds_, 'File', 'auto_generated/bonds_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            matlabFunction(prices_, 'File', 'auto_generated/prices_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            matlabFunction(ts_, 'File', 'auto_generated/tshare_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            matlabFunction(delts_, 'File', 'auto_generated/delts_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            matlabFunction(walras_, 'File', 'auto_generated/walras_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            
            matlabFunction(tau_, 'File', 'auto_generated/tau_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            matlabFunction(taup_, 'File', 'auto_generated/taup_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            matlabFunction(returns_, 'File', 'auto_generated/return_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list], 'Optimize', optimize);
            
            
            
        else
            resid_ss_call = sym2mex_double({'out'},{fcombo_ss},def_sub_nms,def_sub_val,[jump_vars,state_vars,param_list],'tofill_files/double_tofill.c','auto_generated/resid_ss_mex.c', 'resid_ss_mex', 'auto_generated');
            dresid_ss_call = sym2mex_double({'dout'},{dfcombo_ss},def_sub_nms,def_sub_val,[jump_vars,state_vars,param_list],'tofill_files/double_tofill.c','auto_generated/dresid_ss_mex.c', 'dresid_ss_mex','auto_generated');
            
        end
    end
    
    %% Redo Extra
    if redo_extra && solve_dyn == 0
        matlabFunction(delts_, 'File', 'auto_generated/delts.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list], 'Optimize', false);
        matlabFunction(bonds_, 'File', 'auto_generated/bonds.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list], 'Optimize', false);
        matlabFunction(prices_, 'File', 'auto_generated/prices.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list], 'Optimize', false);
        matlabFunction(gross_, 'File', 'auto_generated/gross.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list], 'Optimize', false);
        matlabFunction(ts_   , 'File', 'auto_generated/ts.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list], 'Optimize', false);
        matlabFunction(tb_   , 'File', 'auto_generated/tb.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list], 'Optimize', false);
        matlabFunction(home_bias_, 'File', 'auto_generated/home_bias.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list], 'Optimize', false);
        matlabFunction(EP_   , 'File', 'auto_generated/EP.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list], 'Optimize', false);
        matlabFunction(Xrw   , 'File', 'auto_generated/XRW.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list], 'Optimize', false);
        matlabFunction(GD_   , 'File', 'auto_generated/GD.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list], 'Optimize', false);
        matlabFunction(IR_   , 'File', 'auto_generated/IR.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list], 'Optimize', false);
        matlabFunction(fund_probs_, 'File', 'auto_generated/fund_probs.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list], 'Optimize', false);
        matlabFunction(tr_probs_  , 'File', 'auto_generated/tr_probs.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list], 'Optimize', false);
        matlabFunction(nps_   , 'File', 'auto_generated/nps.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list], 'Optimize', false);
        matlabFunction(PTRAD_   , 'File', 'auto_generated/PTRAD.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list], 'Optimize', false);
        matlabFunction(bets_   , 'File', 'auto_generated/BETTA.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list], 'Optimize', false);
        
    end
    
    
    %% Redo steady_residual.m and expand_steady.m
    endog_str = []; endog_futr = []; endog_past = [];
    endog_ss_vars = [jump_vars,state_vars];
    endog_futr_vars = [jump_prime,state_prime];
    endog_past_vars = state_lag;
    for jj = 1:length(state_lag)
        endog_past = [endog_past ' ' char(state_lag(jj)) '=xl(' num2str(jj) ');' sprintf('%s\n', '')];
    end
    
    for jj = 1:length(endog_ss_vars)
        endog_str  = [endog_str ' ' char(endog_ss_vars(jj)) '=x(' num2str(jj) ');' sprintf('%s\n', '')];
        endog_futr = [endog_futr ' ' char(endog_futr_vars(jj)) '=xp(' num2str(jj) ');' sprintf('%s\n', '')];
    end
    dfrac_str = args_string(symvar(dfrac_));
    def_args_str   = args_string([vcombo_ss,args_def]);
    def_outs_str   = args_string(def_sub_sym);
    args_endog_str = args_string(endog_ss_vars);
    args_prlg_str  = args_string([endog_ss_vars,endog_futr_vars,endog_past_vars]);
    
    if solve_dyn == 0
        text_insert('tofill_files/steady_residual.text', 'auto_generated/steady_residual.m', {endog_str,args_endog_str,args_param_str,def_args_str});
        text_insert('tofill_files/expand_steady.text'  , 'auto_generated/expand_steady.m'  , {endog_str,args_endog_str,args_param_str,def_args_str,def_outs_str});
    else
        text_insert('tofill_files/dynamic_residual.text', 'auto_generated/dynamic_residual.m', {endog_str,endog_futr,endog_past,args_prlg_str,args_param_str,def_args_str,dfrac_str});
        text_insert('tofill_files/dynamic_responses.text', 'auto_generated/dynamic_responses.m', {endog_str,endog_futr,endog_past,args_prlg_str,args_param_str,def_args_str,def_outs_str});
        text_insert('tofill_files/sbar_eval.txt', 'auto_generated/sbar_eval.m', {endog_str,endog_futr,endog_past,args_prlg_str,args_param_str,def_args_str,dfrac_str});
        text_insert('tofill_files/walras_residual.text', 'auto_generated/walras_residual.m', {endog_str,endog_futr,endog_past,args_prlg_str,args_param_str,def_args_str,def_outs_str});
    end
    
    %Deliver mex version of code, much faster!
    if solve_dyn
        convert_to_mex
    end
    
end
toc

