%%%%% 17/8/2017 -- _v2 uses the Q notation

function [out,dout,dout_futr,dout_frac,dout_past] = dynamic_residual(x,xp,xl,log_idx,neq,...
    Busd,Beur,Brow,Busd_l,Beur_l,Brow_l,Busd_p,Beur_p,Brow_p,tau,taup,tau_row,alph,vepsf,vepst,kap,phi,r,sige,mu_us,mu_eu,mu_rw,Yus,Yeu,Yrw,phi_usg,phi_eug,phi_rwg,bet,sig,eta,ah_us,ah_eu,ah_rw,Prw_rw,Xus,Xeu,z,zrow,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out)

x(log_idx) = exp(x(log_idx));
xp(log_idx) = exp(xp(log_idx));

log_idx_past = log_idx(log_idx>neq)-neq; %Get only the states that are logged
xl(log_idx_past) = exp(xl(log_idx_past));


%Time t variables
 Cus_eu=x(1);
 Cus_rw=x(2);
 Ceu_us=x(3);
 Ceu_rw=x(4);
 Crw_us=x(5);
 Crw_eu=x(6);
 Crw_row=x(7);
 Qusd=x(8);
 Qeur=x(9);
 Qrow=x(10);
 Pus_us=x(11);
 Pus_eu=x(12);
 Pus=x(13);
 Peu_eu=x(14);
 Peu_us=x(15);
 Peu=x(16);
 Prw=x(17);
 Prw_us=x(18);
 Prw_eu=x(19);
 m_us=x(20);
 m_eu=x(21);
 m_rw=x(22);
 pim_us_eu_=x(23);
 pim_us_rw_=x(24);
 pex_us_eu_=x(25);
 pim_eu_us_=x(26);
 pim_eu_rw_=x(27);
 pex_eu_us_=x(28);
 pim_rw_us_=x(29);
 pim_rw_eu_=x(30);
 pim_rw_row_=x(31);
 pex_rw_us_=x(32);
 pex_rw_eu_=x(33);
 Vusd=x(34);
 sbar_rw=x(35);
 Brw_usd=x(36);
 Brw_eur=x(37);
 Bus_usd=x(38);
 Beu_eur=x(39);
 Bus_row=x(40);
 Beu_row=x(41);


%Be sure it's xp and not x;
 Cus_eu_p=xp(1);
 Cus_rw_p=xp(2);
 Ceu_us_p=xp(3);
 Ceu_rw_p=xp(4);
 Crw_us_p=xp(5);
 Crw_eu_p=xp(6);
 Crw_row_p=xp(7);
 Qusd_p=xp(8);
 Qeur_p=xp(9);
 Qrow_p=xp(10);
 Pus_us_p=xp(11);
 Pus_eu_p=xp(12);
 Pus_p=xp(13);
 Peu_eu_p=xp(14);
 Peu_us_p=xp(15);
 Peu_p=xp(16);
 Prw_p=xp(17);
 Prw_us_p=xp(18);
 Prw_eu_p=xp(19);
 m_us_p=xp(20);
 m_eu_p=xp(21);
 m_rw_p=xp(22);
 pim_us_eu__p=xp(23);
 pim_us_rw__p=xp(24);
 pex_us_eu__p=xp(25);
 pim_eu_us__p=xp(26);
 pim_eu_rw__p=xp(27);
 pex_eu_us__p=xp(28);
 pim_rw_us__p=xp(29);
 pim_rw_eu__p=xp(30);
 pim_rw_row__p=xp(31);
 pex_rw_us__p=xp(32);
 pex_rw_eu__p=xp(33);
 Vusd_p=xp(34);
 sbar_rw_p=xp(35);
 Brw_usd_p=xp(36);
 Brw_eur_p=xp(37);
 Bus_usd_p=xp(38);
 Beu_eur_p=xp(39);
 Bus_row_p=xp(40);
 Beu_row_p=xp(41);


%Be sure it's xp and not x;
 Brw_usd_l=xl(1);
 Brw_eur_l=xl(2);
 Bus_usd_l=xl(3);
 Beu_eur_l=xl(4);
 Bus_row_l=xl(5);
 Beu_row_l=xl(6);



%Shell Residual
out =  resid_dyn_mex(Cus_eu,Cus_rw,Ceu_us,Ceu_rw,Crw_us,Crw_eu,Crw_row,Qusd,Qeur,Qrow,Pus_us,Pus_eu,Pus,Peu_eu,Peu_us,Peu,Prw,Prw_us,Prw_eu,m_us,m_eu,m_rw,pim_us_eu_,pim_us_rw_,pex_us_eu_,pim_eu_us_,pim_eu_rw_,pex_eu_us_,pim_rw_us_,pim_rw_eu_,pim_rw_row_,pex_rw_us_,pex_rw_eu_,Vusd,sbar_rw,Brw_usd,Brw_eur,Bus_usd,Beu_eur,Bus_row,Beu_row,Cus_eu_p,Cus_rw_p,Ceu_us_p,Ceu_rw_p,Crw_us_p,Crw_eu_p,Crw_row_p,Qusd_p,Qeur_p,Qrow_p,Pus_us_p,Pus_eu_p,Pus_p,Peu_eu_p,Peu_us_p,Peu_p,Prw_p,Prw_us_p,Prw_eu_p,m_us_p,m_eu_p,m_rw_p,pim_us_eu__p,pim_us_rw__p,pex_us_eu__p,pim_eu_us__p,pim_eu_rw__p,pex_eu_us__p,pim_rw_us__p,pim_rw_eu__p,pim_rw_row__p,pex_rw_us__p,pex_rw_eu__p,Vusd_p,sbar_rw_p,Brw_usd_p,Brw_eur_p,Bus_usd_p,Beu_eur_p,Bus_row_p,Beu_row_p,Brw_usd_l,Brw_eur_l,Bus_usd_l,Beu_eur_l,Bus_row_l,Beu_row_l,Busd,Beur,Brow,Busd_l,Beur_l,Brow_l,Busd_p,Beur_p,Brow_p,tau,taup,tau_row,alph,vepsf,vepst,kap,phi,r,sige,mu_us,mu_eu,mu_rw,Yus,Yeu,Yrw,phi_usg,phi_eug,phi_rwg,bet,sig,eta,ah_us,ah_eu,ah_rw,Prw_rw,Xus,Xeu,z,zrow,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%             Output
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if nargout > 1
    dout = dpres_mex(Cus_eu,Cus_rw,Ceu_us,Ceu_rw,Crw_us,Crw_eu,Crw_row,Qusd,Qeur,Qrow,Pus_us,Pus_eu,Pus,Peu_eu,Peu_us,Peu,Prw,Prw_us,Prw_eu,m_us,m_eu,m_rw,pim_us_eu_,pim_us_rw_,pex_us_eu_,pim_eu_us_,pim_eu_rw_,pex_eu_us_,pim_rw_us_,pim_rw_eu_,pim_rw_row_,pex_rw_us_,pex_rw_eu_,Vusd,sbar_rw,Brw_usd,Brw_eur,Bus_usd,Beu_eur,Bus_row,Beu_row,Cus_eu_p,Cus_rw_p,Ceu_us_p,Ceu_rw_p,Crw_us_p,Crw_eu_p,Crw_row_p,Qusd_p,Qeur_p,Qrow_p,Pus_us_p,Pus_eu_p,Pus_p,Peu_eu_p,Peu_us_p,Peu_p,Prw_p,Prw_us_p,Prw_eu_p,m_us_p,m_eu_p,m_rw_p,pim_us_eu__p,pim_us_rw__p,pex_us_eu__p,pim_eu_us__p,pim_eu_rw__p,pex_eu_us__p,pim_rw_us__p,pim_rw_eu__p,pim_rw_row__p,pex_rw_us__p,pex_rw_eu__p,Vusd_p,sbar_rw_p,Brw_usd_p,Brw_eur_p,Bus_usd_p,Beu_eur_p,Bus_row_p,Beu_row_p,Brw_usd_l,Brw_eur_l,Bus_usd_l,Beu_eur_l,Bus_row_l,Beu_row_l,Busd,Beur,Brow,Busd_l,Beur_l,Brow_l,Busd_p,Beur_p,Brow_p,tau,taup,tau_row,alph,vepsf,vepst,kap,phi,r,sige,mu_us,mu_eu,mu_rw,Yus,Yeu,Yrw,phi_usg,phi_eug,phi_rwg,bet,sig,eta,ah_us,ah_eu,ah_rw,Prw_rw,Xus,Xeu,z,zrow,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);
    dx    = ddef_sub_mex(Cus_eu,Cus_rw,Ceu_us,Ceu_rw,Crw_us,Crw_eu,Crw_row,Qusd,Qeur,Qrow,Pus_us,Pus_eu,Pus,Peu_eu,Peu_us,Peu,Prw,Prw_us,Prw_eu,m_us,m_eu,m_rw,pim_us_eu_,pim_us_rw_,pex_us_eu_,pim_eu_us_,pim_eu_rw_,pex_eu_us_,pim_rw_us_,pim_rw_eu_,pim_rw_row_,pex_rw_us_,pex_rw_eu_,Vusd,sbar_rw,Brw_usd,Brw_eur,Bus_usd,Beu_eur,Bus_row,Beu_row,Beur,Beur_l,Beur_p,Brow,Brow_l,Brow_p,Busd,Busd_l,Busd_p,Prw_rw,Xeu,Xus,Yeu,Yrw,Yus,ah_eu,ah_us,ah_rw,alph,bet,dtax_eu_us,dtax_us_eu,dtax_eu_rw,dtax_rw_eu,dtax_rw_us,dtax_us_rw,dtax_rw_row,eta,kap,mu_eu,mu_us,mu_rw,omg,per_p_year,phi,phi_eug,phi_usg,phi_rwg,r,sig,sige,tau,taup,tau_row,tax_eu_in,tax_us_in,tax_eu_us,tax_us_eu,tax_eu_rw,tax_rw_eu,tax_rw_us,tax_us_rw,tax_eu_out,tax_us_out,tax_rw_out,tax_rw_row,upp_eur,upp_usd,vepsf,vepst,z,zrow);
    dout = dout(:,1:length(x)) + dout(:,length(x)+1:end)*dx;  %Chain rule
    dout(:,log_idx) = dout(:,log_idx)*diag(x(log_idx));
end

if nargout > 2
    %Future derivatives
    dout_futr = dprlg_mex(Cus_eu,Cus_rw,Ceu_us,Ceu_rw,Crw_us,Crw_eu,Crw_row,Qusd,Qeur,Qrow,Pus_us,Pus_eu,Pus,Peu_eu,Peu_us,Peu,Prw,Prw_us,Prw_eu,m_us,m_eu,m_rw,pim_us_eu_,pim_us_rw_,pex_us_eu_,pim_eu_us_,pim_eu_rw_,pex_eu_us_,pim_rw_us_,pim_rw_eu_,pim_rw_row_,pex_rw_us_,pex_rw_eu_,Vusd,sbar_rw,Brw_usd,Brw_eur,Bus_usd,Beu_eur,Bus_row,Beu_row,Cus_eu_p,Cus_rw_p,Ceu_us_p,Ceu_rw_p,Crw_us_p,Crw_eu_p,Crw_row_p,Qusd_p,Qeur_p,Qrow_p,Pus_us_p,Pus_eu_p,Pus_p,Peu_eu_p,Peu_us_p,Peu_p,Prw_p,Prw_us_p,Prw_eu_p,m_us_p,m_eu_p,m_rw_p,pim_us_eu__p,pim_us_rw__p,pex_us_eu__p,pim_eu_us__p,pim_eu_rw__p,pex_eu_us__p,pim_rw_us__p,pim_rw_eu__p,pim_rw_row__p,pex_rw_us__p,pex_rw_eu__p,Vusd_p,sbar_rw_p,Brw_usd_p,Brw_eur_p,Bus_usd_p,Beu_eur_p,Bus_row_p,Beu_row_p,Brw_usd_l,Brw_eur_l,Bus_usd_l,Beu_eur_l,Bus_row_l,Beu_row_l,Busd,Beur,Brow,Busd_l,Beur_l,Brow_l,Busd_p,Beur_p,Brow_p,tau,taup,tau_row,alph,vepsf,vepst,kap,phi,r,sige,mu_us,mu_eu,mu_rw,Yus,Yeu,Yrw,phi_usg,phi_eug,phi_rwg,bet,sig,eta,ah_us,ah_eu,ah_rw,Prw_rw,Xus,Xeu,z,zrow,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);

    %For logged variable derivatives
    dout_futr(:,log_idx)= dout_futr(:,log_idx)*diag(xp(log_idx));
end

if nargout > 3
    dout_frac = dfrac(Beu_eur,Beur,Brw_eur,Brw_usd,Bus_usd,Busd,mu_eu,mu_rw,mu_us);
end

if nargout > 4
    %Past derivatives
    dout_past = dpast_mex(Cus_eu,Cus_rw,Ceu_us,Ceu_rw,Crw_us,Crw_eu,Crw_row,Qusd,Qeur,Qrow,Pus_us,Pus_eu,Pus,Peu_eu,Peu_us,Peu,Prw,Prw_us,Prw_eu,m_us,m_eu,m_rw,pim_us_eu_,pim_us_rw_,pex_us_eu_,pim_eu_us_,pim_eu_rw_,pex_eu_us_,pim_rw_us_,pim_rw_eu_,pim_rw_row_,pex_rw_us_,pex_rw_eu_,Vusd,sbar_rw,Brw_usd,Brw_eur,Bus_usd,Beu_eur,Bus_row,Beu_row,Cus_eu_p,Cus_rw_p,Ceu_us_p,Ceu_rw_p,Crw_us_p,Crw_eu_p,Crw_row_p,Qusd_p,Qeur_p,Qrow_p,Pus_us_p,Pus_eu_p,Pus_p,Peu_eu_p,Peu_us_p,Peu_p,Prw_p,Prw_us_p,Prw_eu_p,m_us_p,m_eu_p,m_rw_p,pim_us_eu__p,pim_us_rw__p,pex_us_eu__p,pim_eu_us__p,pim_eu_rw__p,pex_eu_us__p,pim_rw_us__p,pim_rw_eu__p,pim_rw_row__p,pex_rw_us__p,pex_rw_eu__p,Vusd_p,sbar_rw_p,Brw_usd_p,Brw_eur_p,Bus_usd_p,Beu_eur_p,Bus_row_p,Beu_row_p,Brw_usd_l,Brw_eur_l,Bus_usd_l,Beu_eur_l,Bus_row_l,Beu_row_l,Busd,Beur,Brow,Busd_l,Beur_l,Brow_l,Busd_p,Beur_p,Brow_p,tau,taup,tau_row,alph,vepsf,vepst,kap,phi,r,sige,mu_us,mu_eu,mu_rw,Yus,Yeu,Yrw,phi_usg,phi_eug,phi_rwg,bet,sig,eta,ah_us,ah_eu,ah_rw,Prw_rw,Xus,Xeu,z,zrow,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);
    dout_past_def = dpast_def_mex(Cus_eu,Cus_rw,Ceu_us,Ceu_rw,Crw_us,Crw_eu,Crw_row,Qusd,Qeur,Qrow,Pus_us,Pus_eu,Pus,Peu_eu,Peu_us,Peu,Prw,Prw_us,Prw_eu,m_us,m_eu,m_rw,pim_us_eu_,pim_us_rw_,pex_us_eu_,pim_eu_us_,pim_eu_rw_,pex_eu_us_,pim_rw_us_,pim_rw_eu_,pim_rw_row_,pex_rw_us_,pex_rw_eu_,Vusd,sbar_rw,Brw_usd,Brw_eur,Bus_usd,Beu_eur,Bus_row,Beu_row,Cus_eu_p,Cus_rw_p,Ceu_us_p,Ceu_rw_p,Crw_us_p,Crw_eu_p,Crw_row_p,Qusd_p,Qeur_p,Qrow_p,Pus_us_p,Pus_eu_p,Pus_p,Peu_eu_p,Peu_us_p,Peu_p,Prw_p,Prw_us_p,Prw_eu_p,m_us_p,m_eu_p,m_rw_p,pim_us_eu__p,pim_us_rw__p,pex_us_eu__p,pim_eu_us__p,pim_eu_rw__p,pex_eu_us__p,pim_rw_us__p,pim_rw_eu__p,pim_rw_row__p,pex_rw_us__p,pex_rw_eu__p,Vusd_p,sbar_rw_p,Brw_usd_p,Brw_eur_p,Bus_usd_p,Beu_eur_p,Bus_row_p,Beu_row_p,Brw_usd_l,Brw_eur_l,Bus_usd_l,Beu_eur_l,Bus_row_l,Beu_row_l,Busd,Beur,Brow,Busd_l,Beur_l,Brow_l,Busd_p,Beur_p,Brow_p,tau,taup,tau_row,alph,vepsf,vepst,kap,phi,r,sige,mu_us,mu_eu,mu_rw,Yus,Yeu,Yrw,phi_usg,phi_eug,phi_rwg,bet,sig,eta,ah_us,ah_eu,ah_rw,Prw_rw,Xus,Xeu,z,zrow,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);

    dx_past = ddef_sub_lag(Cus_eu,Cus_rw,Ceu_us,Ceu_rw,Crw_us,Crw_eu,Crw_row,Qusd,Qeur,Qrow,Pus_us,Pus_eu,Pus,Peu_eu,Peu_us,Peu,Prw,Prw_us,Prw_eu,m_us,m_eu,m_rw,pim_us_eu_,pim_us_rw_,pex_us_eu_,pim_eu_us_,pim_eu_rw_,pex_eu_us_,pim_rw_us_,pim_rw_eu_,pim_rw_row_,pex_rw_us_,pex_rw_eu_,Vusd,sbar_rw,Brw_usd,Brw_eur,Bus_usd,Beu_eur,Bus_row,Beu_row,Beur,Beur_l,Beur_p,Brow,Brow_l,Brow_p,Busd,Busd_l,Busd_p,Prw_rw,Xeu,Xus,Yeu,Yrw,Yus,ah_eu,ah_us,ah_rw,alph,bet,dtax_eu_us,dtax_us_eu,dtax_eu_rw,dtax_rw_eu,dtax_rw_us,dtax_us_rw,dtax_rw_row,eta,kap,mu_eu,mu_us,mu_rw,omg,per_p_year,phi,phi_eug,phi_usg,phi_rwg,r,sig,sige,tau,taup,tau_row,tax_eu_in,tax_us_in,tax_eu_us,tax_us_eu,tax_eu_rw,tax_rw_eu,tax_rw_us,tax_us_rw,tax_eu_out,tax_us_out,tax_rw_out,tax_rw_row,upp_eur,upp_usd,vepsf,vepst,z,zrow);

    %Chain rule
     dout_past = dout_past + dout_past_def*dx_past;

    log_idx_past = log_idx(log_idx>neq)-neq; %Get only the states that are logged
    dout_past(:,log_idx_past) = dout_past(:,log_idx_past)*diag(xl(log_idx_past));
end






