

#include <math.h>
#include <mex.h>
#include <lapack.h>
#include <blas.h>
#include <stdlib.h>
#include <string.h>


/* Input Arguments */
#define Cus_eu_in	prhs[0]
#define Cus_rw_in	prhs[1]
#define Ceu_us_in	prhs[2]
#define Ceu_rw_in	prhs[3]
#define Crw_us_in	prhs[4]
#define Crw_eu_in	prhs[5]
#define Crw_row_in	prhs[6]
#define Qusd_in	prhs[7]
#define Qeur_in	prhs[8]
#define Qrow_in	prhs[9]
#define Pus_us_in	prhs[10]
#define Pus_eu_in	prhs[11]
#define Pus_in	prhs[12]
#define Peu_eu_in	prhs[13]
#define Peu_us_in	prhs[14]
#define Peu_in	prhs[15]
#define Prw_in	prhs[16]
#define Prw_us_in	prhs[17]
#define Prw_eu_in	prhs[18]
#define m_us_in	prhs[19]
#define m_eu_in	prhs[20]
#define m_rw_in	prhs[21]
#define pim_us_eu__in	prhs[22]
#define pim_us_rw__in	prhs[23]
#define pex_us_eu__in	prhs[24]
#define pim_eu_us__in	prhs[25]
#define pim_eu_rw__in	prhs[26]
#define pex_eu_us__in	prhs[27]
#define pim_rw_us__in	prhs[28]
#define pim_rw_eu__in	prhs[29]
#define pim_rw_row__in	prhs[30]
#define pex_rw_us__in	prhs[31]
#define pex_rw_eu__in	prhs[32]
#define Vusd_in	prhs[33]
#define sbar_rw_in	prhs[34]
#define Brw_usd_in	prhs[35]
#define Brw_eur_in	prhs[36]
#define Bus_usd_in	prhs[37]
#define Beu_eur_in	prhs[38]
#define Bus_row_in	prhs[39]
#define Beu_row_in	prhs[40]
#define Cus_eu_p_in	prhs[41]
#define Cus_rw_p_in	prhs[42]
#define Ceu_us_p_in	prhs[43]
#define Ceu_rw_p_in	prhs[44]
#define Crw_us_p_in	prhs[45]
#define Crw_eu_p_in	prhs[46]
#define Crw_row_p_in	prhs[47]
#define Qusd_p_in	prhs[48]
#define Qeur_p_in	prhs[49]
#define Qrow_p_in	prhs[50]
#define Pus_us_p_in	prhs[51]
#define Pus_eu_p_in	prhs[52]
#define Pus_p_in	prhs[53]
#define Peu_eu_p_in	prhs[54]
#define Peu_us_p_in	prhs[55]
#define Peu_p_in	prhs[56]
#define Prw_p_in	prhs[57]
#define Prw_us_p_in	prhs[58]
#define Prw_eu_p_in	prhs[59]
#define m_us_p_in	prhs[60]
#define m_eu_p_in	prhs[61]
#define m_rw_p_in	prhs[62]
#define pim_us_eu__p_in	prhs[63]
#define pim_us_rw__p_in	prhs[64]
#define pex_us_eu__p_in	prhs[65]
#define pim_eu_us__p_in	prhs[66]
#define pim_eu_rw__p_in	prhs[67]
#define pex_eu_us__p_in	prhs[68]
#define pim_rw_us__p_in	prhs[69]
#define pim_rw_eu__p_in	prhs[70]
#define pim_rw_row__p_in	prhs[71]
#define pex_rw_us__p_in	prhs[72]
#define pex_rw_eu__p_in	prhs[73]
#define Vusd_p_in	prhs[74]
#define sbar_rw_p_in	prhs[75]
#define Brw_usd_p_in	prhs[76]
#define Brw_eur_p_in	prhs[77]
#define Bus_usd_p_in	prhs[78]
#define Beu_eur_p_in	prhs[79]
#define Bus_row_p_in	prhs[80]
#define Beu_row_p_in	prhs[81]
#define Brw_usd_l_in	prhs[82]
#define Brw_eur_l_in	prhs[83]
#define Bus_usd_l_in	prhs[84]
#define Beu_eur_l_in	prhs[85]
#define Bus_row_l_in	prhs[86]
#define Beu_row_l_in	prhs[87]
#define Busd_in	prhs[88]
#define Beur_in	prhs[89]
#define Brow_in	prhs[90]
#define Busd_l_in	prhs[91]
#define Beur_l_in	prhs[92]
#define Brow_l_in	prhs[93]
#define Busd_p_in	prhs[94]
#define Beur_p_in	prhs[95]
#define Brow_p_in	prhs[96]
#define tau_in	prhs[97]
#define taup_in	prhs[98]
#define tau_row_in	prhs[99]
#define alph_in	prhs[100]
#define vepsf_in	prhs[101]
#define vepst_in	prhs[102]
#define kap_in	prhs[103]
#define phi_in	prhs[104]
#define r_in	prhs[105]
#define sige_in	prhs[106]
#define mu_us_in	prhs[107]
#define mu_eu_in	prhs[108]
#define mu_rw_in	prhs[109]
#define Yus_in	prhs[110]
#define Yeu_in	prhs[111]
#define Yrw_in	prhs[112]
#define phi_usg_in	prhs[113]
#define phi_eug_in	prhs[114]
#define phi_rwg_in	prhs[115]
#define bet_in	prhs[116]
#define sig_in	prhs[117]
#define eta_in	prhs[118]
#define ah_us_in	prhs[119]
#define ah_eu_in	prhs[120]
#define ah_rw_in	prhs[121]
#define Prw_rw_in	prhs[122]
#define Xus_in	prhs[123]
#define Xeu_in	prhs[124]
#define z_in	prhs[125]
#define zrow_in	prhs[126]
#define upp_usd_in	prhs[127]
#define upp_eur_in	prhs[128]
#define per_p_year_in	prhs[129]
#define omg_in	prhs[130]
#define tax_us_eu_in	prhs[131]
#define tax_us_rw_in	prhs[132]
#define tax_eu_us_in	prhs[133]
#define tax_eu_rw_in	prhs[134]
#define tax_rw_us_in	prhs[135]
#define tax_rw_eu_in	prhs[136]
#define tax_rw_row_in	prhs[137]
#define dtax_us_eu_in	prhs[138]
#define dtax_us_rw_in	prhs[139]
#define dtax_eu_us_in	prhs[140]
#define dtax_eu_rw_in	prhs[141]
#define dtax_rw_us_in	prhs[142]
#define dtax_rw_eu_in	prhs[143]
#define dtax_rw_row_in	prhs[144]
#define tax_us_in_in	prhs[145]
#define tax_us_out_in	prhs[146]
#define tax_eu_in_in	prhs[147]
#define tax_eu_out_in	prhs[148]
#define tax_rw_out_in	prhs[149]


/* Output Arguments */
#define out plhs[0]


#if !defined(MAX)
#define	MAX(A, B)	((A) > (B) ? (A) : (B))
#endif

#if !defined(MIN)
#define	MIN(A, B)	((A) < (B) ? (A) : (B))
#endif

#define pi  3.141592653589793
        
/* Prints an MxN matrix to Screen*/
void printmat_rowmaj(int m, int n, double M[m*n]){
    int x,y,k;
        k = 0;
    printf("\n");
    for(x=0;x<m;x++){
        for(y=0;y<n;y++){
            printf("%1.11lf\t", M[k]);
            k++;
        }
        printf("%\n");
    }
    return;
}


void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray*prhs[] )

{
     /*Values in Loops*/
    double C,H,D_p,K_p,MU,E1,E2,E3,D,K,HL,LAML,GAMtildeL,GAM,A,RW,MUtmp;
    
    double *OUT;
    
    /*variables needed to declare*/
    double Cus ,Ceu ,Crw ,Cus_us ,Ceu_eu ,Crw_rw ,Pus_rw ,Peu_rw ,Prw_row ,Beu_usd ,Bus_eur ,Brw_row ,p_us_usd ,p_us_eur ,p_eu_usd ,p_eu_eur ,p_rw_usd ,p_rw_eur ,ph_us_usd ,ph_us_eur ,ph_us_row ,ph_eu_usd ,ph_eu_eur ,ph_eu_row ,ph_rw_usd ,ph_rw_eur ,ph_rw_row ,m_us_til ,m_eu_til ,m_rw_til ,pim_us_eu ,pim_us_rw ,pex_us_eu ,pex_us_rw ,pim_eu_us ,pim_eu_rw ,pex_eu_us ,pex_eu_rw ,pim_rw_us ,pim_rw_eu ,pim_rw_row ,pex_rw_us ,pex_rw_eu ,pex_rw_row ;

     double Cus_eu,Cus_rw,Ceu_us,Ceu_rw,Crw_us,Crw_eu,Crw_row,Qusd,Qeur,Qrow,Pus_us,Pus_eu,Pus,Peu_eu,Peu_us,Peu,Prw,Prw_us,Prw_eu,m_us,m_eu,m_rw,pim_us_eu_,pim_us_rw_,pex_us_eu_,pim_eu_us_,pim_eu_rw_,pex_eu_us_,pim_rw_us_,pim_rw_eu_,pim_rw_row_,pex_rw_us_,pex_rw_eu_,Vusd,sbar_rw,Brw_usd,Brw_eur,Bus_usd,Beu_eur,Bus_row,Beu_row,Cus_eu_p,Cus_rw_p,Ceu_us_p,Ceu_rw_p,Crw_us_p,Crw_eu_p,Crw_row_p,Qusd_p,Qeur_p,Qrow_p,Pus_us_p,Pus_eu_p,Pus_p,Peu_eu_p,Peu_us_p,Peu_p,Prw_p,Prw_us_p,Prw_eu_p,m_us_p,m_eu_p,m_rw_p,pim_us_eu__p,pim_us_rw__p,pex_us_eu__p,pim_eu_us__p,pim_eu_rw__p,pex_eu_us__p,pim_rw_us__p,pim_rw_eu__p,pim_rw_row__p,pex_rw_us__p,pex_rw_eu__p,Vusd_p,sbar_rw_p,Brw_usd_p,Brw_eur_p,Bus_usd_p,Beu_eur_p,Bus_row_p,Beu_row_p,Brw_usd_l,Brw_eur_l,Bus_usd_l,Beu_eur_l,Bus_row_l,Beu_row_l,Busd,Beur,Brow,Busd_l,Beur_l,Brow_l,Busd_p,Beur_p,Brow_p,tau,taup,tau_row,alph,vepsf,vepst,kap,phi,r,sige,mu_us,mu_eu,mu_rw,Yus,Yeu,Yrw,phi_usg,phi_eug,phi_rwg,bet,sig,eta,ah_us,ah_eu,ah_rw,Prw_rw,Xus,Xeu,z,zrow,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out;

            
    /*Results*/
    double rsum=1;
    
    /*Create output argument*/
    out = mxCreateDoubleMatrix(41,1,mxREAL);

    OUT = mxGetPr(out);
    
    
    /*Counters*/
    long ns, ii,tt;
    
    /*BLAS working memory*/
    ptrdiff_t one = 1;
    ptrdiff_t info = 0;
    long IPIV[4] = {0,1,2,3};

    
    /*Check for proper number of arguments*/
    if (nrhs == 150)  {} else{mexErrMsgTxt(" 150 inputs arguments required.");}

    
    /* Get Dimensions of Input Arguments*/
    ptrdiff_t four  = 4;
    ptrdiff_t three = 3;
         
    /*Parameters intialized*/
    Cus_eu= *mxGetPr(Cus_eu_in);
Cus_rw= *mxGetPr(Cus_rw_in);
Ceu_us= *mxGetPr(Ceu_us_in);
Ceu_rw= *mxGetPr(Ceu_rw_in);
Crw_us= *mxGetPr(Crw_us_in);
Crw_eu= *mxGetPr(Crw_eu_in);
Crw_row= *mxGetPr(Crw_row_in);
Qusd= *mxGetPr(Qusd_in);
Qeur= *mxGetPr(Qeur_in);
Qrow= *mxGetPr(Qrow_in);
Pus_us= *mxGetPr(Pus_us_in);
Pus_eu= *mxGetPr(Pus_eu_in);
Pus= *mxGetPr(Pus_in);
Peu_eu= *mxGetPr(Peu_eu_in);
Peu_us= *mxGetPr(Peu_us_in);
Peu= *mxGetPr(Peu_in);
Prw= *mxGetPr(Prw_in);
Prw_us= *mxGetPr(Prw_us_in);
Prw_eu= *mxGetPr(Prw_eu_in);
m_us= *mxGetPr(m_us_in);
m_eu= *mxGetPr(m_eu_in);
m_rw= *mxGetPr(m_rw_in);
pim_us_eu_= *mxGetPr(pim_us_eu__in);
pim_us_rw_= *mxGetPr(pim_us_rw__in);
pex_us_eu_= *mxGetPr(pex_us_eu__in);
pim_eu_us_= *mxGetPr(pim_eu_us__in);
pim_eu_rw_= *mxGetPr(pim_eu_rw__in);
pex_eu_us_= *mxGetPr(pex_eu_us__in);
pim_rw_us_= *mxGetPr(pim_rw_us__in);
pim_rw_eu_= *mxGetPr(pim_rw_eu__in);
pim_rw_row_= *mxGetPr(pim_rw_row__in);
pex_rw_us_= *mxGetPr(pex_rw_us__in);
pex_rw_eu_= *mxGetPr(pex_rw_eu__in);
Vusd= *mxGetPr(Vusd_in);
sbar_rw= *mxGetPr(sbar_rw_in);
Brw_usd= *mxGetPr(Brw_usd_in);
Brw_eur= *mxGetPr(Brw_eur_in);
Bus_usd= *mxGetPr(Bus_usd_in);
Beu_eur= *mxGetPr(Beu_eur_in);
Bus_row= *mxGetPr(Bus_row_in);
Beu_row= *mxGetPr(Beu_row_in);
Cus_eu_p= *mxGetPr(Cus_eu_p_in);
Cus_rw_p= *mxGetPr(Cus_rw_p_in);
Ceu_us_p= *mxGetPr(Ceu_us_p_in);
Ceu_rw_p= *mxGetPr(Ceu_rw_p_in);
Crw_us_p= *mxGetPr(Crw_us_p_in);
Crw_eu_p= *mxGetPr(Crw_eu_p_in);
Crw_row_p= *mxGetPr(Crw_row_p_in);
Qusd_p= *mxGetPr(Qusd_p_in);
Qeur_p= *mxGetPr(Qeur_p_in);
Qrow_p= *mxGetPr(Qrow_p_in);
Pus_us_p= *mxGetPr(Pus_us_p_in);
Pus_eu_p= *mxGetPr(Pus_eu_p_in);
Pus_p= *mxGetPr(Pus_p_in);
Peu_eu_p= *mxGetPr(Peu_eu_p_in);
Peu_us_p= *mxGetPr(Peu_us_p_in);
Peu_p= *mxGetPr(Peu_p_in);
Prw_p= *mxGetPr(Prw_p_in);
Prw_us_p= *mxGetPr(Prw_us_p_in);
Prw_eu_p= *mxGetPr(Prw_eu_p_in);
m_us_p= *mxGetPr(m_us_p_in);
m_eu_p= *mxGetPr(m_eu_p_in);
m_rw_p= *mxGetPr(m_rw_p_in);
pim_us_eu__p= *mxGetPr(pim_us_eu__p_in);
pim_us_rw__p= *mxGetPr(pim_us_rw__p_in);
pex_us_eu__p= *mxGetPr(pex_us_eu__p_in);
pim_eu_us__p= *mxGetPr(pim_eu_us__p_in);
pim_eu_rw__p= *mxGetPr(pim_eu_rw__p_in);
pex_eu_us__p= *mxGetPr(pex_eu_us__p_in);
pim_rw_us__p= *mxGetPr(pim_rw_us__p_in);
pim_rw_eu__p= *mxGetPr(pim_rw_eu__p_in);
pim_rw_row__p= *mxGetPr(pim_rw_row__p_in);
pex_rw_us__p= *mxGetPr(pex_rw_us__p_in);
pex_rw_eu__p= *mxGetPr(pex_rw_eu__p_in);
Vusd_p= *mxGetPr(Vusd_p_in);
sbar_rw_p= *mxGetPr(sbar_rw_p_in);
Brw_usd_p= *mxGetPr(Brw_usd_p_in);
Brw_eur_p= *mxGetPr(Brw_eur_p_in);
Bus_usd_p= *mxGetPr(Bus_usd_p_in);
Beu_eur_p= *mxGetPr(Beu_eur_p_in);
Bus_row_p= *mxGetPr(Bus_row_p_in);
Beu_row_p= *mxGetPr(Beu_row_p_in);
Brw_usd_l= *mxGetPr(Brw_usd_l_in);
Brw_eur_l= *mxGetPr(Brw_eur_l_in);
Bus_usd_l= *mxGetPr(Bus_usd_l_in);
Beu_eur_l= *mxGetPr(Beu_eur_l_in);
Bus_row_l= *mxGetPr(Bus_row_l_in);
Beu_row_l= *mxGetPr(Beu_row_l_in);
Busd= *mxGetPr(Busd_in);
Beur= *mxGetPr(Beur_in);
Brow= *mxGetPr(Brow_in);
Busd_l= *mxGetPr(Busd_l_in);
Beur_l= *mxGetPr(Beur_l_in);
Brow_l= *mxGetPr(Brow_l_in);
Busd_p= *mxGetPr(Busd_p_in);
Beur_p= *mxGetPr(Beur_p_in);
Brow_p= *mxGetPr(Brow_p_in);
tau= *mxGetPr(tau_in);
taup= *mxGetPr(taup_in);
tau_row= *mxGetPr(tau_row_in);
alph= *mxGetPr(alph_in);
vepsf= *mxGetPr(vepsf_in);
vepst= *mxGetPr(vepst_in);
kap= *mxGetPr(kap_in);
phi= *mxGetPr(phi_in);
r= *mxGetPr(r_in);
sige= *mxGetPr(sige_in);
mu_us= *mxGetPr(mu_us_in);
mu_eu= *mxGetPr(mu_eu_in);
mu_rw= *mxGetPr(mu_rw_in);
Yus= *mxGetPr(Yus_in);
Yeu= *mxGetPr(Yeu_in);
Yrw= *mxGetPr(Yrw_in);
phi_usg= *mxGetPr(phi_usg_in);
phi_eug= *mxGetPr(phi_eug_in);
phi_rwg= *mxGetPr(phi_rwg_in);
bet= *mxGetPr(bet_in);
sig= *mxGetPr(sig_in);
eta= *mxGetPr(eta_in);
ah_us= *mxGetPr(ah_us_in);
ah_eu= *mxGetPr(ah_eu_in);
ah_rw= *mxGetPr(ah_rw_in);
Prw_rw= *mxGetPr(Prw_rw_in);
Xus= *mxGetPr(Xus_in);
Xeu= *mxGetPr(Xeu_in);
z= *mxGetPr(z_in);
zrow= *mxGetPr(zrow_in);
upp_usd= *mxGetPr(upp_usd_in);
upp_eur= *mxGetPr(upp_eur_in);
per_p_year= *mxGetPr(per_p_year_in);
omg= *mxGetPr(omg_in);
tax_us_eu= *mxGetPr(tax_us_eu_in);
tax_us_rw= *mxGetPr(tax_us_rw_in);
tax_eu_us= *mxGetPr(tax_eu_us_in);
tax_eu_rw= *mxGetPr(tax_eu_rw_in);
tax_rw_us= *mxGetPr(tax_rw_us_in);
tax_rw_eu= *mxGetPr(tax_rw_eu_in);
tax_rw_row= *mxGetPr(tax_rw_row_in);
dtax_us_eu= *mxGetPr(dtax_us_eu_in);
dtax_us_rw= *mxGetPr(dtax_us_rw_in);
dtax_eu_us= *mxGetPr(dtax_eu_us_in);
dtax_eu_rw= *mxGetPr(dtax_eu_rw_in);
dtax_rw_us= *mxGetPr(dtax_rw_us_in);
dtax_rw_eu= *mxGetPr(dtax_rw_eu_in);
dtax_rw_row= *mxGetPr(dtax_rw_row_in);
tax_us_in= *mxGetPr(tax_us_in_in);
tax_us_out= *mxGetPr(tax_us_out_in);
tax_eu_in= *mxGetPr(tax_eu_in_in);
tax_eu_out= *mxGetPr(tax_eu_out_in);
tax_rw_out= *mxGetPr(tax_rw_out_in);

            
            
    /*Declare MatlabFunction Terms*/
    
    Cus = pow(Cus_eu,-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(Cus_rw,-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw))*pow(ah_us,-ah_us)*pow(-(Ceu_us*mu_eu+Crw_us*mu_rw+Yus*mu_us*(phi_usg-1.0))/mu_us,ah_us)*pow(-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw),(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw));
Ceu = pow(Ceu_us,-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(Ceu_rw,-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw))*pow(ah_eu,-ah_eu)*pow(-(Crw_eu*mu_rw+Cus_eu*mu_us+Yeu*mu_eu*(phi_eug-1.0))/mu_eu,ah_eu)*pow(-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw),(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw));
Crw = pow(Crw_eu,-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_us,-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_row,-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(ah_rw,-ah_rw)*pow(-(Ceu_rw*mu_eu+Cus_rw*mu_us-mu_rw*(Crw_row-Yrw)*(phi_rwg-1.0))/mu_rw,ah_rw)*pow(-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw));
Cus_us = -(Ceu_us*mu_eu+Crw_us*mu_rw+Yus*mu_us*(phi_usg-1.0))/mu_us;
Ceu_eu = -(Crw_eu*mu_rw+Cus_eu*mu_us+Yeu*mu_eu*(phi_eug-1.0))/mu_eu;
Crw_rw = -(Ceu_rw*mu_eu+Cus_rw*mu_us-mu_rw*(Crw_row-Yrw)*(phi_rwg-1.0))/mu_rw;
Pus_rw = pow(Pus*pow(Pus_us,-ah_us)*pow(Pus_eu*(tax_us_eu+1.0),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw)),-(mu_eu+mu_rw)/(mu_rw*(ah_us-1.0)))/(tax_us_rw+1.0);
Peu_rw = pow(Peu*pow(Peu_eu,-ah_eu)*pow(Peu_us*(tax_eu_us+1.0),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw)),-(mu_us+mu_rw)/(mu_rw*(ah_eu-1.0)))/(tax_eu_rw+1.0);
Prw_row = pow(Prw*pow(Prw_rw,-ah_rw)*pow(Prw_eu*(tax_rw_eu+1.0),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Prw_us*(tax_rw_us+1.0),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)),-(mu_eu+mu_us+mu_rw)/(mu_rw*(ah_rw-1.0)))/(tax_rw_row+1.0);
Beu_usd = -(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us)/mu_eu;
Bus_eur = -(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw)/mu_us;
Brw_row = -(-Brow+Beu_row*mu_eu+Bus_row*mu_us)/mu_rw;
p_us_usd = Bus_usd*Pus_us*Qusd*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf);
p_us_eur = -(Peu_eu*Qeur*upp_eur*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf)*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us;
p_eu_usd = -(Pus_us*Qusd*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf)*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu;
p_eu_eur = Beu_eur*Peu_eu*Qeur*upp_eur*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf);
p_rw_usd = Brw_usd*Pus_us*Qusd*upp_usd*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf);
p_rw_eur = Brw_eur*Peu_eu*Qeur*upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf);
ph_us_usd = Xus*m_us*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf);
ph_us_eur = -m_us*upp_eur*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf)*(Xus-1.0);
ph_us_row = m_us*upp_eur*zrow*pow(pow(m_us*zrow,1.0/vepsf)+pow(Bus_row*Prw_rw*Qrow*upp_eur,1.0/vepsf),-vepsf);
ph_eu_usd = Xeu*m_eu*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf);
ph_eu_eur = -m_eu*upp_eur*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)*(Xeu-1.0);
ph_eu_row = m_eu*upp_eur*zrow*pow(pow(m_eu*zrow,1.0/vepsf)+pow(Beu_row*Prw_rw*Qrow*upp_eur,1.0/vepsf),-vepsf);
ph_rw_usd = m_rw*upp_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf);
ph_rw_eur = m_rw*upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0);
ph_rw_row = m_rw*upp_eur*zrow*pow(pow(m_rw*zrow,1.0/vepsf)+pow(-(Prw_rw*Qrow*upp_eur*(-Brow+Beu_row*mu_eu+Bus_row*mu_us))/mu_rw,1.0/vepsf),-vepsf);
m_us_til = m_us*mu_us*(Bus_usd*Pus_us*Qusd*Xus*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf)+(Peu_eu*Qeur*upp_eur*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf)*(Xus-1.0)*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us);
m_eu_til = -m_eu*mu_eu*(Beu_eur*Peu_eu*Qeur*upp_eur*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)*(Xeu-1.0)+(Pus_us*Qusd*Xeu*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf)*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu);
m_rw_til = m_rw*mu_rw*(Brw_eur*Peu_eu*Qeur*upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+Brw_usd*Pus_us*Qusd*upp_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf));
pim_us_eu = exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0);
pim_us_rw = -(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0);
pex_us_eu = (exp(pex_us_eu_)*(-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)+(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0)+1.0))/(exp(pex_us_eu_)+1.0);
pex_us_rw = -exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-(exp(pex_us_eu_)*(-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)+(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0)+1.0))/(exp(pex_us_eu_)+1.0)+(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0)+1.0;
pim_eu_us = exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0);
pim_eu_rw = -(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0);
pex_eu_us = (exp(pex_eu_us_)*(-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)+(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0)+1.0))/(exp(pex_eu_us_)+1.0);
pex_eu_rw = -exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-(exp(pex_eu_us_)*(-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)+(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0)+1.0))/(exp(pex_eu_us_)+1.0)+(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0)+1.0;
pim_rw_us = exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0);
pim_rw_eu = -(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0);
pim_rw_row = (exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0);
pex_rw_us = -(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0);
pex_rw_eu = (exp(pex_rw_eu_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pex_rw_eu_)+1.0);
pex_rw_row = -exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-(exp(pex_rw_eu_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pex_rw_eu_)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0;
        
            
    
                  
    /*Output argument*/
    OUT [0] =pow(Cus_us/Cus_eu,1.0/eta)*pow(-(mu_eu*(ah_us-1.0))/(ah_us*(mu_eu+mu_rw)),1.0/eta)-(Pus_eu*(tax_us_eu+1.0))/Pus_us;
OUT [1] =pow(Cus_us/Cus_rw,1.0/eta)*pow(-(mu_rw*(ah_us-1.0))/(ah_us*(mu_eu+mu_rw)),1.0/eta)-(Pus_rw*(tax_us_rw+1.0))/Pus_us;
OUT [2] =m_us*(Xus*(Pus*phi+p_us_usd*(r+(pim_us_eu*pow(pow((m_us_til*pim_us_eu)/(m_eu_til*pex_eu_us),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Peu_eu+Pus_eu+kap*(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)))/(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))+(pim_us_rw*pow(pow((m_us_til*pim_us_rw)/(m_rw_til*pex_rw_us),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Prw_rw+Pus_rw+kap*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0))))/(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0))-(alph*pex_us_eu*pow(pow((m_us_til*pex_us_eu)/(m_eu_til*pim_eu_us),1.0/vepst)+1.0,-vepst)*(Peu_us-Pus_us+kap*(Pus_us-(Peu_us-Pus_us)*(alph-1.0))*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)))/(Pus_us-(Peu_us-Pus_us)*(alph-1.0))-(alph*pex_us_rw*pow(pow((m_us_til*pex_us_rw)/(m_rw_til*pim_rw_us),1.0/vepst)+1.0,-vepst)*(Prw_us-Pus_us+kap*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*(Pus_us-(Prw_us-Pus_us)*(alph-1.0))))/(Pus_us-(Prw_us-Pus_us)*(alph-1.0))))-(Xus-1.0)*(Pus*phi+p_us_eur*(r+(alph*pex_us_rw*pow(pow((m_us_til*pex_us_rw)/(m_rw_til*pim_rw_us),1.0/vepst)+1.0,-vepst)*(-Prw_us+Pus_us+(kap*p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Pus_us-(Prw_us-Pus_us)*(alph-1.0)))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))/(Pus_us-(Prw_us-Pus_us)*(alph-1.0))-(pim_us_eu*pow(pow((m_us_til*pim_us_eu)/(m_eu_til*pex_eu_us),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Peu_eu-Pus_eu+(Xeu*kap*p_eu_usd*(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0)))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))))/(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))-(pim_us_rw*pow(pow((m_us_til*pim_us_rw)/(m_rw_til*pex_rw_us),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Prw_rw-Pus_rw+(kap*p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0)))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))/(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0))+(alph*pex_us_eu*pow(pow((m_us_til*pex_us_eu)/(m_eu_til*pim_eu_us),1.0/vepst)+1.0,-vepst)*(-Peu_us+Pus_us+(Xeu*kap*p_eu_usd*(Pus_us-(Peu_us-Pus_us)*(alph-1.0)))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))))/(Pus_us-(Peu_us-Pus_us)*(alph-1.0)))))-Bus_row_l*Prw_rw-Bus_usd_l*Pus_us+Cus_eu*Pus_eu+Cus_us*Pus_us+Cus_rw*Pus_rw+Bus_row*Prw_rw*Qrow-Pus*m_us*phi+Pus*tax_us_in*((-Busd_l+Brw_usd_l*mu_rw+Bus_usd_l*mu_us)/mu_us-(Brw_usd_l*mu_rw)/mu_us)+(Busd_l*Pus_us)/mu_us+Pus_us*Yus*(phi_usg-1.0)+kap*m_us*(p_us_eur*(Xus-1.0)*(alph*((Xeu*p_eu_usd*pex_us_eu*pow(pow((m_us_til*pex_us_eu)/(m_eu_til*pim_eu_us),1.0/vepst)+1.0,-vepst))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))+(p_rw_usd*pex_us_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow((m_us_til*pex_us_rw)/(m_rw_til*pim_rw_us),1.0/vepst)+1.0,-vepst))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)))-(alph-1.0)*((Xeu*p_eu_usd*pim_us_eu*pow(pow((m_us_til*pim_us_eu)/(m_eu_til*pex_eu_us),1.0/vepst)+1.0,-vepst))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))+(p_rw_usd*pim_us_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow((m_us_til*pim_us_rw)/(m_rw_til*pex_rw_us),1.0/vepst)+1.0,-vepst))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))+Xus*p_us_usd*(alph*(pex_us_eu*pow(pow((m_us_til*pex_us_eu)/(m_eu_til*pim_eu_us),1.0/vepst)+1.0,-vepst)*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)+pex_us_rw*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*pow(pow((m_us_til*pex_us_rw)/(m_rw_til*pim_rw_us),1.0/vepst)+1.0,-vepst))-(pim_us_eu*pow(pow((m_us_til*pim_us_eu)/(m_eu_til*pex_eu_us),1.0/vepst)+1.0,-vepst)*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)+pim_us_rw*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*pow(pow((m_us_til*pim_us_rw)/(m_rw_til*pex_rw_us),1.0/vepst)+1.0,-vepst))*(alph-1.0)))-(Busd*Pus_us*Qusd)/mu_us-(Peu_eu*(tax_eu_in-1.0)*(-Beur_l+Beu_eur_l*mu_eu+Brw_eur_l*mu_rw))/mu_us-Bus_eur*Peu_eu*Qeur*(ph_us_eur*r-1.0)-Bus_usd*Pus_us*Qusd*(ph_us_usd*r-1.0);
OUT [3] =pow(Ceu_eu/Ceu_us,1.0/eta)*pow(-(mu_us*(ah_eu-1.0))/(ah_eu*(mu_us+mu_rw)),1.0/eta)-(Peu_us*(tax_eu_us+1.0))/Peu_eu;
OUT [4] =pow(Ceu_eu/Ceu_rw,1.0/eta)*pow(-(mu_rw*(ah_eu-1.0))/(ah_eu*(mu_us+mu_rw)),1.0/eta)-(Peu_rw*(tax_eu_rw+1.0))/Peu_eu;
OUT [5] =m_eu*(Xeu*(Peu*phi+p_eu_usd*(r+(pim_eu_us*pow(pow((m_eu_til*pim_eu_us)/(m_us_til*pex_us_eu),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Peu_us-Pus_us+kap*(Pus_us-(Peu_us-Pus_us)*(alph-1.0))*((Xus*p_us_usd)/(Xus*p_us_usd-p_us_eur*(Xus-1.0))-1.0)))/(Pus_us-(Peu_us-Pus_us)*(alph-1.0))+(pim_eu_rw*pow(pow((m_eu_til*pim_eu_rw)/(m_rw_til*pex_rw_eu),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Peu_rw-Prw_rw+kap*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))))/(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))-(alph*pex_eu_us*pow(pow((m_eu_til*pex_eu_us)/(m_us_til*pim_us_eu),1.0/vepst)+1.0,-vepst)*(-Peu_eu+Pus_eu+kap*(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))*((Xus*p_us_usd)/(Xus*p_us_usd-p_us_eur*(Xus-1.0))-1.0)))/(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))-(alph*pex_eu_rw*pow(pow((m_eu_til*pex_eu_rw)/(m_rw_til*pim_rw_eu),1.0/vepst)+1.0,-vepst)*(-Peu_eu+Prw_eu+kap*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))))/(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))))-(Xeu-1.0)*(Peu*phi+p_eu_eur*(r+(alph*pex_eu_rw*pow(pow((m_eu_til*pex_eu_rw)/(m_rw_til*pim_rw_eu),1.0/vepst)+1.0,-vepst)*(Peu_eu-Prw_eu+(kap*p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0)))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))/(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))-(pim_eu_us*pow(pow((m_eu_til*pim_eu_us)/(m_us_til*pex_us_eu),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Peu_us+Pus_us+(Xus*kap*p_us_usd*(Pus_us-(Peu_us-Pus_us)*(alph-1.0)))/(Xus*p_us_usd-p_us_eur*(Xus-1.0))))/(Pus_us-(Peu_us-Pus_us)*(alph-1.0))-(pim_eu_rw*pow(pow((m_eu_til*pim_eu_rw)/(m_rw_til*pex_rw_eu),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Peu_rw+Prw_rw+(kap*p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0)))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))/(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))+(alph*pex_eu_us*pow(pow((m_eu_til*pex_eu_us)/(m_us_til*pim_us_eu),1.0/vepst)+1.0,-vepst)*(Peu_eu-Pus_eu+(Xus*kap*p_us_usd*(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0)))/(Xus*p_us_usd-p_us_eur*(Xus-1.0))))/(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0)))))-Beu_eur_l*Peu_eu-Beu_row_l*Prw_rw+Ceu_eu*Peu_eu+Ceu_us*Peu_us+Ceu_rw*Peu_rw+Beu_row*Prw_rw*Qrow-Peu*m_eu*phi+Peu*tax_eu_in*((-Beur_l+Beu_eur_l*mu_eu+Brw_eur_l*mu_rw)/mu_eu-(Brw_eur_l*mu_rw)/mu_eu)+(Beur_l*Peu_eu)/mu_eu+Peu_eu*Yeu*(phi_eug-1.0)+kap*m_eu*(p_eu_eur*(Xeu-1.0)*(alph*((Xus*p_us_usd*pex_eu_us*pow(pow((m_eu_til*pex_eu_us)/(m_us_til*pim_us_eu),1.0/vepst)+1.0,-vepst))/(Xus*p_us_usd-p_us_eur*(Xus-1.0))+(p_rw_usd*pex_eu_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow((m_eu_til*pex_eu_rw)/(m_rw_til*pim_rw_eu),1.0/vepst)+1.0,-vepst))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)))-(alph-1.0)*((Xus*p_us_usd*pim_eu_us*pow(pow((m_eu_til*pim_eu_us)/(m_us_til*pex_us_eu),1.0/vepst)+1.0,-vepst))/(Xus*p_us_usd-p_us_eur*(Xus-1.0))+(p_rw_usd*pim_eu_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow((m_eu_til*pim_eu_rw)/(m_rw_til*pex_rw_eu),1.0/vepst)+1.0,-vepst))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))+Xeu*p_eu_usd*(alph*(pex_eu_us*pow(pow((m_eu_til*pex_eu_us)/(m_us_til*pim_us_eu),1.0/vepst)+1.0,-vepst)*((Xus*p_us_usd)/(Xus*p_us_usd-p_us_eur*(Xus-1.0))-1.0)+pex_eu_rw*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*pow(pow((m_eu_til*pex_eu_rw)/(m_rw_til*pim_rw_eu),1.0/vepst)+1.0,-vepst))-(pim_eu_us*pow(pow((m_eu_til*pim_eu_us)/(m_us_til*pex_us_eu),1.0/vepst)+1.0,-vepst)*((Xus*p_us_usd)/(Xus*p_us_usd-p_us_eur*(Xus-1.0))-1.0)+pim_eu_rw*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*pow(pow((m_eu_til*pim_eu_rw)/(m_rw_til*pex_rw_eu),1.0/vepst)+1.0,-vepst))*(alph-1.0)))-(Beur*Peu_eu*Qeur)/mu_eu-(Pus_us*(tax_us_in-1.0)*(-Busd_l+Brw_usd_l*mu_rw+Bus_usd_l*mu_us))/mu_eu-Beu_eur*Peu_eu*Qeur*(ph_eu_eur*r-1.0)-Beu_usd*Pus_us*Qusd*(ph_eu_usd*r-1.0);
OUT [6] =pow(Crw_rw/Crw_row,1.0/eta)*pow(-(mu_rw*(ah_rw-1.0))/(ah_rw*(mu_eu+mu_us+mu_rw)),1.0/eta)-(Prw_row*(tax_rw_row+1.0))/Prw_rw;
OUT [7] =pow(Crw_rw/Crw_us,1.0/eta)*pow(-(mu_us*(ah_rw-1.0))/(ah_rw*(mu_eu+mu_us+mu_rw)),1.0/eta)-(Prw_us*(tax_rw_us+1.0))/Prw_rw;
OUT [8] =pow(Crw_rw/Crw_eu,1.0/eta)*pow(-(mu_eu*(ah_rw-1.0))/(ah_rw*(mu_eu+mu_us+mu_rw)),1.0/eta)-(Prw_eu*(tax_rw_eu+1.0))/Prw_rw;
OUT [9] =Cus_eu-(m_us*pim_us_eu*(Xus*p_us_usd-p_us_eur*(Xus-1.0))*pow(pow((m_us_til*pim_us_eu)/(m_eu_til*pex_eu_us),1.0/vepst)+1.0,-vepst))/(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0));
OUT [10] =Cus_rw-(m_us*pim_us_rw*(Xus*p_us_usd-p_us_eur*(Xus-1.0))*pow(pow((m_us_til*pim_us_rw)/(m_rw_til*pex_rw_us),1.0/vepst)+1.0,-vepst))/(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0));
OUT [11] =Ceu_us-(m_eu*pim_eu_us*(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))*pow(pow((m_eu_til*pim_eu_us)/(m_us_til*pex_us_eu),1.0/vepst)+1.0,-vepst))/(Pus_us-(Peu_us-Pus_us)*(alph-1.0));
OUT [12] =Ceu_rw-(m_eu*pim_eu_rw*(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))*pow(pow((m_eu_til*pim_eu_rw)/(m_rw_til*pex_rw_eu),1.0/vepst)+1.0,-vepst))/(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0));
OUT [13] =Crw_us-(m_rw*pim_rw_us*pow(pow((m_rw_til*pim_rw_us)/(m_us_til*pex_us_rw),1.0/vepst)+1.0,-vepst)*(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)))/(Pus_us-(Prw_us-Pus_us)*(alph-1.0));
OUT [14] =Crw_eu-(m_rw*pim_rw_eu*pow(pow((m_rw_til*pim_rw_eu)/(m_eu_til*pex_eu_rw),1.0/vepst)+1.0,-vepst)*(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)))/(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0));
OUT [15] =Crw_row-(m_rw*pim_rw_row*pow(pow(pim_rw_row/pex_rw_row,1.0/vepst)+1.0,-vepst)*(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)))/(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0));
OUT [16] =(Pus*Pus_us_p*(Qusd_p*((1.0/pow(Bus_usd,2)*taup*pow(Bus_usd-Bus_usd_p,2))/2.0-(taup*(Bus_usd-Bus_usd_p))/Bus_usd)+1.0)*(bet+tau_row*(Peu_eu*(Beur+(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw)/mu_us)+Prw_rw*(Brow-Bus_row)+Pus_us*(Busd-Bus_usd)))*pow((pow(Cus_eu_p,-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(Cus_rw_p,-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw))*pow(ah_us,-ah_us)*pow(-(Ceu_us_p*mu_eu+Crw_us_p*mu_rw+Yus*mu_us*(phi_usg-1.0))/mu_us,ah_us)*pow(-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw),(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw)))/Cus,-sig)*-1.0e+2)/(Pus_p*Pus_us*Qusd*(-ph_us_usd*r+(tau*(Bus_usd-Bus_usd_l))/Bus_usd_l+1.0))+1.0e+2;
OUT [17] =(Peu_eu_p*Pus*(bet+tau_row*(Peu_eu*(Beur+(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw)/mu_us)+Prw_rw*(Brow-Bus_row)+Pus_us*(Busd-Bus_usd)))*(Qeur_p*((pow(mu_us,2)*taup*pow((-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw)/mu_us-(-Beur_p+Beu_eur_p*mu_eu+Brw_eur_p*mu_rw)/mu_us,2)*1.0/pow(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw,2))/2.0-(mu_us*taup*((-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw)/mu_us-(-Beur_p+Beu_eur_p*mu_eu+Brw_eur_p*mu_rw)/mu_us))/(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))+1.0)*pow((pow(Cus_eu_p,-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(Cus_rw_p,-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw))*pow(ah_us,-ah_us)*pow(-(Ceu_us_p*mu_eu+Crw_us_p*mu_rw+Yus*mu_us*(phi_usg-1.0))/mu_us,ah_us)*pow(-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw),(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw)))/Cus,-sig)*-1.0e+2)/(Peu_eu*Pus_p*Qeur*(-ph_us_eur*r+(mu_us*tau*((-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw)/mu_us-(-Beur_l+Beu_eur_l*mu_eu+Brw_eur_l*mu_rw)/mu_us))/(-Beur_l+Beu_eur_l*mu_eu+Brw_eur_l*mu_rw)+1.0))+1.0e+2;
OUT [18] =(Pus*(bet+tau_row*(Peu_eu*(Beur+(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw)/mu_us)+Prw_rw*(Brow-Bus_row)+Pus_us*(Busd-Bus_usd)))*pow((pow(Cus_eu_p,-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(Cus_rw_p,-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw))*pow(ah_us,-ah_us)*pow(-(Ceu_us_p*mu_eu+Crw_us_p*mu_rw+Yus*mu_us*(phi_usg-1.0))/mu_us,ah_us)*pow(-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw),(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw)))/Cus,-sig)*-1.0e+2)/(Pus_p*Qrow*(-ph_us_row*r+(tau*(Bus_row-Bus_row_l))/Bus_row_l+1.0))+1.0e+2;
OUT [19] =(Peu*Pus_us_p*(bet+tau_row*(Pus_us*(Busd+(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us)/mu_eu)+Peu_eu*(Beur-Beu_eur)-Prw_rw*(Beu_row-Brow)))*(Qusd_p*((pow(mu_eu,2)*taup*pow((-Busd+Brw_usd*mu_rw+Bus_usd*mu_us)/mu_eu-(-Busd_p+Brw_usd_p*mu_rw+Bus_usd_p*mu_us)/mu_eu,2)*1.0/pow(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us,2))/2.0-(mu_eu*taup*((-Busd+Brw_usd*mu_rw+Bus_usd*mu_us)/mu_eu-(-Busd_p+Brw_usd_p*mu_rw+Bus_usd_p*mu_us)/mu_eu))/(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))+1.0)*pow((pow(Ceu_us_p,-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(Ceu_rw_p,-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw))*pow(ah_eu,-ah_eu)*pow(-(Crw_eu_p*mu_rw+Cus_eu_p*mu_us+Yeu*mu_eu*(phi_eug-1.0))/mu_eu,ah_eu)*pow(-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw),(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw)))/Ceu,-sig)*-1.0e+2)/(Peu_p*Pus_us*Qusd*(-ph_eu_usd*r+(mu_eu*tau*((-Busd+Brw_usd*mu_rw+Bus_usd*mu_us)/mu_eu-(-Busd_l+Brw_usd_l*mu_rw+Bus_usd_l*mu_us)/mu_eu))/(-Busd_l+Brw_usd_l*mu_rw+Bus_usd_l*mu_us)+1.0))+1.0e+2;
OUT [20] =(Peu*Peu_eu_p*(Qeur_p*((1.0/pow(Beu_eur,2)*taup*pow(Beu_eur-Beu_eur_p,2))/2.0-(taup*(Beu_eur-Beu_eur_p))/Beu_eur)+1.0)*(bet+tau_row*(Pus_us*(Busd+(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us)/mu_eu)+Peu_eu*(Beur-Beu_eur)-Prw_rw*(Beu_row-Brow)))*pow((pow(Ceu_us_p,-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(Ceu_rw_p,-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw))*pow(ah_eu,-ah_eu)*pow(-(Crw_eu_p*mu_rw+Cus_eu_p*mu_us+Yeu*mu_eu*(phi_eug-1.0))/mu_eu,ah_eu)*pow(-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw),(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw)))/Ceu,-sig)*-1.0e+2)/(Peu_p*Peu_eu*Qeur*(-ph_eu_eur*r+(tau*(Beu_eur-Beu_eur_l))/Beu_eur_l+1.0))+1.0e+2;
OUT [21] =(Peu*(bet+tau_row*(Pus_us*(Busd+(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us)/mu_eu)+Peu_eu*(Beur-Beu_eur)-Prw_rw*(Beu_row-Brow)))*pow((pow(Ceu_us_p,-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(Ceu_rw_p,-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw))*pow(ah_eu,-ah_eu)*pow(-(Crw_eu_p*mu_rw+Cus_eu_p*mu_us+Yeu*mu_eu*(phi_eug-1.0))/mu_eu,ah_eu)*pow(-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw),(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw)))/Ceu,-sig)*-1.0e+2)/(Peu_p*Qrow*(-ph_eu_row*r+(tau*(Beu_row-Beu_row_l))/Beu_row_l+1.0))+1.0e+2;
OUT [22] =(Prw*Pus_us_p*(Qusd_p*((1.0/pow(Brw_usd,2)*taup*pow(Brw_usd-Brw_usd_p,2))/2.0-(taup*(Brw_usd-Brw_usd_p))/Brw_usd)+1.0)*(bet+tau_row*(Prw_rw*(Brow+(-Brow+Beu_row*mu_eu+Bus_row*mu_us)/mu_rw)+Peu_eu*(Beur-Brw_eur)-Pus_us*(Brw_usd-Busd)))*pow((pow(Crw_eu_p,-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_us_p,-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_row_p,-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(ah_rw,-ah_rw)*pow(-(Ceu_rw_p*mu_eu+Cus_rw_p*mu_us-mu_rw*(Crw_row_p-Yrw)*(phi_rwg-1.0))/mu_rw,ah_rw)*pow(-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)))/Crw,-sig)*-1.0e+2)/(Prw_p*Pus_us*Qusd*(-ph_rw_usd*r+(tau*(Brw_usd-Brw_usd_l))/Brw_usd_l+1.0))+1.0e+2;
OUT [23] =(Peu_eu_p*Prw*(Qeur_p*((1.0/pow(Brw_eur,2)*taup*pow(Brw_eur-Brw_eur_p,2))/2.0-(taup*(Brw_eur-Brw_eur_p))/Brw_eur)+1.0)*(bet+tau_row*(Prw_rw*(Brow+(-Brow+Beu_row*mu_eu+Bus_row*mu_us)/mu_rw)+Peu_eu*(Beur-Brw_eur)-Pus_us*(Brw_usd-Busd)))*pow((pow(Crw_eu_p,-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_us_p,-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_row_p,-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(ah_rw,-ah_rw)*pow(-(Ceu_rw_p*mu_eu+Cus_rw_p*mu_us-mu_rw*(Crw_row_p-Yrw)*(phi_rwg-1.0))/mu_rw,ah_rw)*pow(-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)))/Crw,-sig)*-1.0e+2)/(Peu_eu*Prw_p*Qeur*(-ph_rw_eur*r+(tau*(Brw_eur-Brw_eur_l))/Brw_eur_l+1.0))+1.0e+2;
OUT [24] =(Prw*(bet+tau_row*(Prw_rw*(Brow+(-Brow+Beu_row*mu_eu+Bus_row*mu_us)/mu_rw)+Peu_eu*(Beur-Brw_eur)-Pus_us*(Brw_usd-Busd)))*pow((pow(Crw_eu_p,-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_us_p,-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_row_p,-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(ah_rw,-ah_rw)*pow(-(Ceu_rw_p*mu_eu+Cus_rw_p*mu_us-mu_rw*(Crw_row_p-Yrw)*(phi_rwg-1.0))/mu_rw,ah_rw)*pow(-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)))/Crw,-sig)*-1.0e+2)/(Prw_p*Qrow*(-ph_rw_row*r+(mu_rw*tau*((-Brow+Beu_row*mu_eu+Bus_row*mu_us)/mu_rw-(-Brow+Beu_row_l*mu_eu+Bus_row_l*mu_us)/mu_rw))/(-Brow+Beu_row_l*mu_eu+Bus_row_l*mu_us)+1.0))+1.0e+2;
OUT [25] =-Xus*(Pus*phi+p_us_usd*(r+(pim_us_eu*pow(pow((m_us_til*pim_us_eu)/(m_eu_til*pex_eu_us),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Peu_eu+Pus_eu+kap*(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)))/(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))+(pim_us_rw*pow(pow((m_us_til*pim_us_rw)/(m_rw_til*pex_rw_us),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Prw_rw+Pus_rw+kap*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0))))/(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0))-(alph*pex_us_eu*pow(pow((m_us_til*pex_us_eu)/(m_eu_til*pim_eu_us),1.0/vepst)+1.0,-vepst)*(Peu_us-Pus_us+kap*(Pus_us-(Peu_us-Pus_us)*(alph-1.0))*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)))/(Pus_us-(Peu_us-Pus_us)*(alph-1.0))-(alph*pex_us_rw*pow(pow((m_us_til*pex_us_rw)/(m_rw_til*pim_rw_us),1.0/vepst)+1.0,-vepst)*(Prw_us-Pus_us+kap*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*(Pus_us-(Prw_us-Pus_us)*(alph-1.0))))/(Pus_us-(Prw_us-Pus_us)*(alph-1.0))))+(Xus-1.0)*(Pus*phi+p_us_eur*(r+(alph*pex_us_rw*pow(pow((m_us_til*pex_us_rw)/(m_rw_til*pim_rw_us),1.0/vepst)+1.0,-vepst)*(-Prw_us+Pus_us+(kap*p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Pus_us-(Prw_us-Pus_us)*(alph-1.0)))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))/(Pus_us-(Prw_us-Pus_us)*(alph-1.0))-(pim_us_eu*pow(pow((m_us_til*pim_us_eu)/(m_eu_til*pex_eu_us),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Peu_eu-Pus_eu+(Xeu*kap*p_eu_usd*(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0)))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))))/(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))-(pim_us_rw*pow(pow((m_us_til*pim_us_rw)/(m_rw_til*pex_rw_us),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Prw_rw-Pus_rw+(kap*p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0)))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))/(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0))+(alph*pex_us_eu*pow(pow((m_us_til*pex_us_eu)/(m_eu_til*pim_eu_us),1.0/vepst)+1.0,-vepst)*(-Peu_us+Pus_us+(Xeu*kap*p_eu_usd*(Pus_us-(Peu_us-Pus_us)*(alph-1.0)))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))))/(Pus_us-(Peu_us-Pus_us)*(alph-1.0))));
OUT [26] =-Xeu*(Peu*phi+p_eu_usd*(r+(pim_eu_us*pow(pow((m_eu_til*pim_eu_us)/(m_us_til*pex_us_eu),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Peu_us-Pus_us+kap*(Pus_us-(Peu_us-Pus_us)*(alph-1.0))*((Xus*p_us_usd)/(Xus*p_us_usd-p_us_eur*(Xus-1.0))-1.0)))/(Pus_us-(Peu_us-Pus_us)*(alph-1.0))+(pim_eu_rw*pow(pow((m_eu_til*pim_eu_rw)/(m_rw_til*pex_rw_eu),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Peu_rw-Prw_rw+kap*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))))/(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))-(alph*pex_eu_us*pow(pow((m_eu_til*pex_eu_us)/(m_us_til*pim_us_eu),1.0/vepst)+1.0,-vepst)*(-Peu_eu+Pus_eu+kap*(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))*((Xus*p_us_usd)/(Xus*p_us_usd-p_us_eur*(Xus-1.0))-1.0)))/(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))-(alph*pex_eu_rw*pow(pow((m_eu_til*pex_eu_rw)/(m_rw_til*pim_rw_eu),1.0/vepst)+1.0,-vepst)*(-Peu_eu+Prw_eu+kap*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))))/(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))))+(Xeu-1.0)*(Peu*phi+p_eu_eur*(r+(alph*pex_eu_rw*pow(pow((m_eu_til*pex_eu_rw)/(m_rw_til*pim_rw_eu),1.0/vepst)+1.0,-vepst)*(Peu_eu-Prw_eu+(kap*p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0)))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))/(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))-(pim_eu_us*pow(pow((m_eu_til*pim_eu_us)/(m_us_til*pex_us_eu),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Peu_us+Pus_us+(Xus*kap*p_us_usd*(Pus_us-(Peu_us-Pus_us)*(alph-1.0)))/(Xus*p_us_usd-p_us_eur*(Xus-1.0))))/(Pus_us-(Peu_us-Pus_us)*(alph-1.0))-(pim_eu_rw*pow(pow((m_eu_til*pim_eu_rw)/(m_rw_til*pex_rw_eu),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Peu_rw+Prw_rw+(kap*p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0)))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))/(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))+(alph*pex_eu_us*pow(pow((m_eu_til*pex_eu_us)/(m_us_til*pim_us_eu),1.0/vepst)+1.0,-vepst)*(Peu_eu-Pus_eu+(Xus*kap*p_us_usd*(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0)))/(Xus*p_us_usd-p_us_eur*(Xus-1.0))))/(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))));
OUT [27] =-(Prw*phi+p_rw_eur*(r-(pim_rw_row*pow(pow(pim_rw_row/pex_rw_row,1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Prw_rw-Prw_row+(kap*p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0)))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))/(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))-(pim_rw_eu*pow(pow((m_rw_til*pim_rw_eu)/(m_eu_til*pex_eu_rw),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Peu_eu-Prw_eu+(Xeu*kap*p_eu_usd*(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0)))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))))/(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))-(pim_rw_us*pow(pow((m_rw_til*pim_rw_us)/(m_us_til*pex_us_rw),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Prw_us+Pus_us+(Xus*kap*p_us_usd*(Pus_us-(Prw_us-Pus_us)*(alph-1.0)))/(Xus*p_us_usd-p_us_eur*(Xus-1.0))))/(Pus_us-(Prw_us-Pus_us)*(alph-1.0))+(alph*pex_rw_row*pow(pow(pex_rw_row/pim_rw_row,1.0/vepst)+1.0,-vepst)*(Prw_rw-Prw_row+(kap*p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0)))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))/(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))+(alph*pex_rw_eu*pow(pow((m_rw_til*pex_rw_eu)/(m_eu_til*pim_eu_rw),1.0/vepst)+1.0,-vepst)*(-Peu_rw+Prw_rw+(Xeu*kap*p_eu_usd*(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0)))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))))/(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))+(alph*pex_rw_us*pow(pow((m_rw_til*pex_rw_us)/(m_us_til*pim_us_rw),1.0/vepst)+1.0,-vepst)*(Prw_rw-Pus_rw+(Xus*kap*p_us_usd*(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0)))/(Xus*p_us_usd-p_us_eur*(Xus-1.0))))/(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0))))*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)-(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Prw*phi+p_rw_usd*(r+(pim_rw_eu*pow(pow((m_rw_til*pim_rw_eu)/(m_eu_til*pex_eu_rw),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Peu_eu+Prw_eu+kap*(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)))/(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))+(pim_rw_us*pow(pow((m_rw_til*pim_rw_us)/(m_us_til*pex_us_rw),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Prw_us-Pus_us+kap*(Pus_us-(Prw_us-Pus_us)*(alph-1.0))*((Xus*p_us_usd)/(Xus*p_us_usd-p_us_eur*(Xus-1.0))-1.0)))/(Pus_us-(Prw_us-Pus_us)*(alph-1.0))-(alph*pex_rw_row*pow(pow(pex_rw_row/pim_rw_row,1.0/vepst)+1.0,-vepst)*(-Prw_rw+Prw_row+kap*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))))/(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))-(alph*pex_rw_eu*pow(pow((m_rw_til*pex_rw_eu)/(m_eu_til*pim_eu_rw),1.0/vepst)+1.0,-vepst)*(Peu_rw-Prw_rw+kap*(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)))/(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))-(alph*pex_rw_us*pow(pow((m_rw_til*pex_rw_us)/(m_us_til*pim_us_rw),1.0/vepst)+1.0,-vepst)*(-Prw_rw+Pus_rw+kap*(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0))*((Xus*p_us_usd)/(Xus*p_us_usd-p_us_eur*(Xus-1.0))-1.0)))/(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0))+(pim_rw_row*pow(pow(pim_rw_row/pex_rw_row,1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Prw_rw+Prw_row+kap*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))))/(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))));
OUT [28] =-((pow(pow((m_us_til*pim_us_eu)/(m_eu_til*pex_eu_us),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Peu_eu-Pus_eu+(Xeu*kap*p_eu_usd*(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0)))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))))/(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))-(pow(pow((m_us_til*pim_us_rw)/(m_rw_til*pex_rw_us),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Prw_rw-Pus_rw+(kap*p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0)))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))/(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0)))*(Xus-1.0)-Xus*((pow(pow((m_us_til*pim_us_eu)/(m_eu_til*pex_eu_us),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Peu_eu+Pus_eu+kap*(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)))/(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))-(pow(pow((m_us_til*pim_us_rw)/(m_rw_til*pex_rw_us),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Prw_rw+Pus_rw+kap*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0))))/(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0)));
OUT [29] =((alph*pow(pow((m_us_til*pex_us_eu)/(m_eu_til*pim_eu_us),1.0/vepst)+1.0,-vepst)*(-Peu_us+Pus_us+(Xeu*kap*p_eu_usd*(Pus_us-(Peu_us-Pus_us)*(alph-1.0)))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))))/(Pus_us-(Peu_us-Pus_us)*(alph-1.0))-(alph*pow(pow((m_us_til*pex_us_rw)/(m_rw_til*pim_rw_us),1.0/vepst)+1.0,-vepst)*(-Prw_us+Pus_us+(kap*p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Pus_us-(Prw_us-Pus_us)*(alph-1.0)))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))/(Pus_us-(Prw_us-Pus_us)*(alph-1.0)))*(Xus-1.0)+Xus*((alph*pow(pow((m_us_til*pex_us_eu)/(m_eu_til*pim_eu_us),1.0/vepst)+1.0,-vepst)*(Peu_us-Pus_us+kap*(Pus_us-(Peu_us-Pus_us)*(alph-1.0))*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)))/(Pus_us-(Peu_us-Pus_us)*(alph-1.0))-(alph*pow(pow((m_us_til*pex_us_rw)/(m_rw_til*pim_rw_us),1.0/vepst)+1.0,-vepst)*(Prw_us-Pus_us+kap*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*(Pus_us-(Prw_us-Pus_us)*(alph-1.0))))/(Pus_us-(Prw_us-Pus_us)*(alph-1.0)));
OUT [30] =Xus*((alph*pow(pow((m_us_til*pex_us_eu)/(m_eu_til*pim_eu_us),1.0/vepst)+1.0,-vepst)*(Peu_us-Pus_us+kap*(Pus_us-(Peu_us-Pus_us)*(alph-1.0))*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)))/(Pus_us-(Peu_us-Pus_us)*(alph-1.0))+(pow(pow((m_us_til*pim_us_eu)/(m_eu_til*pex_eu_us),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Peu_eu+Pus_eu+kap*(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)))/(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0)))+(Xus-1.0)*((alph*pow(pow((m_us_til*pex_us_eu)/(m_eu_til*pim_eu_us),1.0/vepst)+1.0,-vepst)*(-Peu_us+Pus_us+(Xeu*kap*p_eu_usd*(Pus_us-(Peu_us-Pus_us)*(alph-1.0)))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))))/(Pus_us-(Peu_us-Pus_us)*(alph-1.0))+(pow(pow((m_us_til*pim_us_eu)/(m_eu_til*pex_eu_us),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Peu_eu-Pus_eu+(Xeu*kap*p_eu_usd*(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0)))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))))/(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0)));
OUT [31] =-((pow(pow((m_eu_til*pim_eu_us)/(m_us_til*pex_us_eu),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Peu_us+Pus_us+(Xus*kap*p_us_usd*(Pus_us-(Peu_us-Pus_us)*(alph-1.0)))/(Xus*p_us_usd-p_us_eur*(Xus-1.0))))/(Pus_us-(Peu_us-Pus_us)*(alph-1.0))-(pow(pow((m_eu_til*pim_eu_rw)/(m_rw_til*pex_rw_eu),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Peu_rw+Prw_rw+(kap*p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0)))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))/(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0)))*(Xeu-1.0)-Xeu*((pow(pow((m_eu_til*pim_eu_us)/(m_us_til*pex_us_eu),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Peu_us-Pus_us+kap*(Pus_us-(Peu_us-Pus_us)*(alph-1.0))*((Xus*p_us_usd)/(Xus*p_us_usd-p_us_eur*(Xus-1.0))-1.0)))/(Pus_us-(Peu_us-Pus_us)*(alph-1.0))-(pow(pow((m_eu_til*pim_eu_rw)/(m_rw_til*pex_rw_eu),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Peu_rw-Prw_rw+kap*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))))/(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0)));
OUT [32] =((alph*pow(pow((m_eu_til*pex_eu_us)/(m_us_til*pim_us_eu),1.0/vepst)+1.0,-vepst)*(Peu_eu-Pus_eu+(Xus*kap*p_us_usd*(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0)))/(Xus*p_us_usd-p_us_eur*(Xus-1.0))))/(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))-(alph*pow(pow((m_eu_til*pex_eu_rw)/(m_rw_til*pim_rw_eu),1.0/vepst)+1.0,-vepst)*(Peu_eu-Prw_eu+(kap*p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0)))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))/(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0)))*(Xeu-1.0)+Xeu*((alph*pow(pow((m_eu_til*pex_eu_us)/(m_us_til*pim_us_eu),1.0/vepst)+1.0,-vepst)*(-Peu_eu+Pus_eu+kap*(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))*((Xus*p_us_usd)/(Xus*p_us_usd-p_us_eur*(Xus-1.0))-1.0)))/(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))-(alph*pow(pow((m_eu_til*pex_eu_rw)/(m_rw_til*pim_rw_eu),1.0/vepst)+1.0,-vepst)*(-Peu_eu+Prw_eu+kap*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))))/(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0)));
OUT [33] =Xeu*((alph*pow(pow((m_eu_til*pex_eu_us)/(m_us_til*pim_us_eu),1.0/vepst)+1.0,-vepst)*(-Peu_eu+Pus_eu+kap*(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))*((Xus*p_us_usd)/(Xus*p_us_usd-p_us_eur*(Xus-1.0))-1.0)))/(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))+(pow(pow((m_eu_til*pim_eu_us)/(m_us_til*pex_us_eu),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Peu_us-Pus_us+kap*(Pus_us-(Peu_us-Pus_us)*(alph-1.0))*((Xus*p_us_usd)/(Xus*p_us_usd-p_us_eur*(Xus-1.0))-1.0)))/(Pus_us-(Peu_us-Pus_us)*(alph-1.0)))+(Xeu-1.0)*((alph*pow(pow((m_eu_til*pex_eu_us)/(m_us_til*pim_us_eu),1.0/vepst)+1.0,-vepst)*(Peu_eu-Pus_eu+(Xus*kap*p_us_usd*(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0)))/(Xus*p_us_usd-p_us_eur*(Xus-1.0))))/(Peu_eu+(Peu_eu-Pus_eu)*(alph-1.0))+(pow(pow((m_eu_til*pim_eu_us)/(m_us_til*pex_us_eu),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Peu_us+Pus_us+(Xus*kap*p_us_usd*(Pus_us-(Peu_us-Pus_us)*(alph-1.0)))/(Xus*p_us_usd-p_us_eur*(Xus-1.0))))/(Pus_us-(Peu_us-Pus_us)*(alph-1.0)));
OUT [34] =(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*((pow(pow((m_rw_til*pim_rw_eu)/(m_eu_til*pex_eu_rw),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Peu_eu+Prw_eu+kap*(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)))/(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))-(pow(pow((m_rw_til*pim_rw_us)/(m_us_til*pex_us_rw),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Prw_us-Pus_us+kap*(Pus_us-(Prw_us-Pus_us)*(alph-1.0))*((Xus*p_us_usd)/(Xus*p_us_usd-p_us_eur*(Xus-1.0))-1.0)))/(Pus_us-(Prw_us-Pus_us)*(alph-1.0)))-((pow(pow((m_rw_til*pim_rw_eu)/(m_eu_til*pex_eu_rw),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Peu_eu-Prw_eu+(Xeu*kap*p_eu_usd*(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0)))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))))/(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))-(pow(pow((m_rw_til*pim_rw_us)/(m_us_til*pex_us_rw),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Prw_us+Pus_us+(Xus*kap*p_us_usd*(Pus_us-(Prw_us-Pus_us)*(alph-1.0)))/(Xus*p_us_usd-p_us_eur*(Xus-1.0))))/(Pus_us-(Prw_us-Pus_us)*(alph-1.0)))*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0);
OUT [35] =-((pow(pow(pim_rw_row/pex_rw_row,1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Prw_rw-Prw_row+(kap*p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0)))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))/(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))-(pow(pow((m_rw_til*pim_rw_eu)/(m_eu_til*pex_eu_rw),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Peu_eu-Prw_eu+(Xeu*kap*p_eu_usd*(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0)))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))))/(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0)))*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*((pow(pow(pim_rw_row/pex_rw_row,1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Prw_rw+Prw_row+kap*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))))/(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))-(pow(pow((m_rw_til*pim_rw_eu)/(m_eu_til*pex_eu_rw),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Peu_eu+Prw_eu+kap*(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)))/(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0)));
OUT [36] =((alph*pow(pow((m_rw_til*pex_rw_eu)/(m_eu_til*pim_eu_rw),1.0/vepst)+1.0,-vepst)*(-Peu_rw+Prw_rw+(Xeu*kap*p_eu_usd*(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0)))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))))/(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))-(alph*pow(pow((m_rw_til*pex_rw_us)/(m_us_til*pim_us_rw),1.0/vepst)+1.0,-vepst)*(Prw_rw-Pus_rw+(Xus*kap*p_us_usd*(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0)))/(Xus*p_us_usd-p_us_eur*(Xus-1.0))))/(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0)))*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)-(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*((alph*pow(pow((m_rw_til*pex_rw_eu)/(m_eu_til*pim_eu_rw),1.0/vepst)+1.0,-vepst)*(Peu_rw-Prw_rw+kap*(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)))/(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))-(alph*pow(pow((m_rw_til*pex_rw_us)/(m_us_til*pim_us_rw),1.0/vepst)+1.0,-vepst)*(-Prw_rw+Pus_rw+kap*(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0))*((Xus*p_us_usd)/(Xus*p_us_usd-p_us_eur*(Xus-1.0))-1.0)))/(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0)));
OUT [37] =((alph*pow(pow(pex_rw_row/pim_rw_row,1.0/vepst)+1.0,-vepst)*(Prw_rw-Prw_row+(kap*p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0)))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))/(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))-(alph*pow(pow((m_rw_til*pex_rw_eu)/(m_eu_til*pim_eu_rw),1.0/vepst)+1.0,-vepst)*(-Peu_rw+Prw_rw+(Xeu*kap*p_eu_usd*(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0)))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))))/(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0)))*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)-(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*((alph*pow(pow(pex_rw_row/pim_rw_row,1.0/vepst)+1.0,-vepst)*(-Prw_rw+Prw_row+kap*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))))/(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))-(alph*pow(pow((m_rw_til*pex_rw_eu)/(m_eu_til*pim_eu_rw),1.0/vepst)+1.0,-vepst)*(Peu_rw-Prw_rw+kap*(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)))/(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0)));
OUT [38] =-((alph*pow(pow((m_rw_til*pex_rw_eu)/(m_eu_til*pim_eu_rw),1.0/vepst)+1.0,-vepst)*(-Peu_rw+Prw_rw+(Xeu*kap*p_eu_usd*(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0)))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))))/(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))+(pow(pow((m_rw_til*pim_rw_eu)/(m_eu_til*pex_eu_rw),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Peu_eu-Prw_eu+(Xeu*kap*p_eu_usd*(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0)))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))))/(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0)))*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*((alph*pow(pow((m_rw_til*pex_rw_eu)/(m_eu_til*pim_eu_rw),1.0/vepst)+1.0,-vepst)*(Peu_rw-Prw_rw+kap*(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)))/(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))+(pow(pow((m_rw_til*pim_rw_eu)/(m_eu_til*pex_eu_rw),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Peu_eu+Prw_eu+kap*(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)))/(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0)));
OUT [39] =Vusd*1.0e+2-((bet+tau_row*(Prw_rw*(Brow+(-Brow+Beu_row*mu_eu+Bus_row*mu_us)/mu_rw)+Peu_eu*(Beur-Brw_eur)-Pus_us*(Brw_usd-Busd)))*(omg-1.0)+1.0)*(p_rw_eur*(r-(pim_rw_row*pow(pow(pim_rw_row/pex_rw_row,1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Prw_rw-Prw_row+(kap*p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0)))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))/(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))-(pim_rw_eu*pow(pow((m_rw_til*pim_rw_eu)/(m_eu_til*pex_eu_rw),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Peu_eu-Prw_eu+(Xeu*kap*p_eu_usd*(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0)))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))))/(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))-(pim_rw_us*pow(pow((m_rw_til*pim_rw_us)/(m_us_til*pex_us_rw),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Prw_us+Pus_us+(Xus*kap*p_us_usd*(Pus_us-(Prw_us-Pus_us)*(alph-1.0)))/(Xus*p_us_usd-p_us_eur*(Xus-1.0))))/(Pus_us-(Prw_us-Pus_us)*(alph-1.0))+(alph*pex_rw_row*pow(pow(pex_rw_row/pim_rw_row,1.0/vepst)+1.0,-vepst)*(Prw_rw-Prw_row+(kap*p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0)))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))/(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))+(alph*pex_rw_eu*pow(pow((m_rw_til*pex_rw_eu)/(m_eu_til*pim_eu_rw),1.0/vepst)+1.0,-vepst)*(-Peu_rw+Prw_rw+(Xeu*kap*p_eu_usd*(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0)))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))))/(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))+(alph*pex_rw_us*pow(pow((m_rw_til*pex_rw_us)/(m_us_til*pim_us_rw),1.0/vepst)+1.0,-vepst)*(Prw_rw-Pus_rw+(Xus*kap*p_us_usd*(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0)))/(Xus*p_us_usd-p_us_eur*(Xus-1.0))))/(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0)))-p_rw_usd*(r+(pim_rw_eu*pow(pow((m_rw_til*pim_rw_eu)/(m_eu_til*pex_eu_rw),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Peu_eu+Prw_eu+kap*(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)))/(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))+(pim_rw_us*pow(pow((m_rw_til*pim_rw_us)/(m_us_til*pex_us_rw),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Prw_us-Pus_us+kap*(Pus_us-(Prw_us-Pus_us)*(alph-1.0))*((Xus*p_us_usd)/(Xus*p_us_usd-p_us_eur*(Xus-1.0))-1.0)))/(Pus_us-(Prw_us-Pus_us)*(alph-1.0))-(alph*pex_rw_row*pow(pow(pex_rw_row/pim_rw_row,1.0/vepst)+1.0,-vepst)*(-Prw_rw+Prw_row+kap*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))))/(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))-(alph*pex_rw_eu*pow(pow((m_rw_til*pex_rw_eu)/(m_eu_til*pim_eu_rw),1.0/vepst)+1.0,-vepst)*(Peu_rw-Prw_rw+kap*(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)))/(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))-(alph*pex_rw_us*pow(pow((m_rw_til*pex_rw_us)/(m_us_til*pim_us_rw),1.0/vepst)+1.0,-vepst)*(-Prw_rw+Pus_rw+kap*(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0))*((Xus*p_us_usd)/(Xus*p_us_usd-p_us_eur*(Xus-1.0))-1.0)))/(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0))+(pim_rw_row*pow(pow(pim_rw_row/pex_rw_row,1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Prw_rw+Prw_row+kap*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))))/(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))))*1.0e+2+Vusd_p*(bet+tau_row*(Prw_rw*(Brow+(-Brow+Beu_row*mu_eu+Bus_row*mu_us)/mu_rw)+Peu_eu*(Beur-Brw_eur)-Pus_us*(Brw_usd-Busd)))*(omg-1.0)*1.0e+2;
OUT [40] =sbar_rw*sige*1.0e+2+((bet+tau_row*(Prw_rw*(Brow+(-Brow+Beu_row*mu_eu+Bus_row*mu_us)/mu_rw)+Peu_eu*(Beur-Brw_eur)-Pus_us*(Brw_usd-Busd)))*(omg-1.0)+1.0)*(p_rw_eur*(r-(pim_rw_row*pow(pow(pim_rw_row/pex_rw_row,1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Prw_rw-Prw_row+(kap*p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0)))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))/(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))-(pim_rw_eu*pow(pow((m_rw_til*pim_rw_eu)/(m_eu_til*pex_eu_rw),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Peu_eu-Prw_eu+(Xeu*kap*p_eu_usd*(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0)))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))))/(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))-(pim_rw_us*pow(pow((m_rw_til*pim_rw_us)/(m_us_til*pex_us_rw),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Prw_us+Pus_us+(Xus*kap*p_us_usd*(Pus_us-(Prw_us-Pus_us)*(alph-1.0)))/(Xus*p_us_usd-p_us_eur*(Xus-1.0))))/(Pus_us-(Prw_us-Pus_us)*(alph-1.0))+(alph*pex_rw_row*pow(pow(pex_rw_row/pim_rw_row,1.0/vepst)+1.0,-vepst)*(Prw_rw-Prw_row+(kap*p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0)))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))))/(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))+(alph*pex_rw_eu*pow(pow((m_rw_til*pex_rw_eu)/(m_eu_til*pim_eu_rw),1.0/vepst)+1.0,-vepst)*(-Peu_rw+Prw_rw+(Xeu*kap*p_eu_usd*(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0)))/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))))/(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))+(alph*pex_rw_us*pow(pow((m_rw_til*pex_rw_us)/(m_us_til*pim_us_rw),1.0/vepst)+1.0,-vepst)*(Prw_rw-Pus_rw+(Xus*kap*p_us_usd*(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0)))/(Xus*p_us_usd-p_us_eur*(Xus-1.0))))/(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0)))-p_rw_usd*(r+(pim_rw_eu*pow(pow((m_rw_til*pim_rw_eu)/(m_eu_til*pex_eu_rw),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Peu_eu+Prw_eu+kap*(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)))/(Peu_eu+(Peu_eu-Prw_eu)*(alph-1.0))+(pim_rw_us*pow(pow((m_rw_til*pim_rw_us)/(m_us_til*pex_us_rw),1.0/vepst)+1.0,-vepst)*(alph-1.0)*(Prw_us-Pus_us+kap*(Pus_us-(Prw_us-Pus_us)*(alph-1.0))*((Xus*p_us_usd)/(Xus*p_us_usd-p_us_eur*(Xus-1.0))-1.0)))/(Pus_us-(Prw_us-Pus_us)*(alph-1.0))-(alph*pex_rw_row*pow(pow(pex_rw_row/pim_rw_row,1.0/vepst)+1.0,-vepst)*(-Prw_rw+Prw_row+kap*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))))/(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))-(alph*pex_rw_eu*pow(pow((m_rw_til*pex_rw_eu)/(m_eu_til*pim_eu_rw),1.0/vepst)+1.0,-vepst)*(Peu_rw-Prw_rw+kap*(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))*((Xeu*p_eu_usd)/(Xeu*p_eu_usd-p_eu_eur*(Xeu-1.0))-1.0)))/(Prw_rw-(Peu_rw-Prw_rw)*(alph-1.0))-(alph*pex_rw_us*pow(pow((m_rw_til*pex_rw_us)/(m_us_til*pim_us_rw),1.0/vepst)+1.0,-vepst)*(-Prw_rw+Pus_rw+kap*(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0))*((Xus*p_us_usd)/(Xus*p_us_usd-p_us_eur*(Xus-1.0))-1.0)))/(Prw_rw+(Prw_rw-Pus_rw)*(alph-1.0))+(pim_rw_row*pow(pow(pim_rw_row/pex_rw_row,1.0/vepst)+1.0,-vepst)*(alph-1.0)*(-Prw_rw+Prw_row+kap*((p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))/(p_rw_eur*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+p_rw_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0))-1.0)*(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))))/(Prw_rw+(Prw_rw-Prw_row)*(alph-1.0))))*1.0e+2-Vusd_p*(bet+tau_row*(Prw_rw*(Brow+(-Brow+Beu_row*mu_eu+Bus_row*mu_us)/mu_rw)+Peu_eu*(Beur-Brw_eur)-Pus_us*(Brw_usd-Busd)))*(omg-1.0)*1.0e+2;

                            
                  
}




