

#include <math.h>
#include <mex.h>
#include <lapack.h>
#include <blas.h>
#include <stdlib.h>
#include <string.h>


/* Input Arguments */
#define Cus_eu_in	prhs[0]
#define Cus_rw_in	prhs[1]
#define Ceu_us_in	prhs[2]
#define Ceu_rw_in	prhs[3]
#define Crw_us_in	prhs[4]
#define Crw_eu_in	prhs[5]
#define Crw_row_in	prhs[6]
#define Qusd_in	prhs[7]
#define Qeur_in	prhs[8]
#define Qrow_in	prhs[9]
#define Pus_us_in	prhs[10]
#define Pus_eu_in	prhs[11]
#define Pus_in	prhs[12]
#define Peu_eu_in	prhs[13]
#define Peu_us_in	prhs[14]
#define Peu_in	prhs[15]
#define Prw_in	prhs[16]
#define Prw_us_in	prhs[17]
#define Prw_eu_in	prhs[18]
#define m_us_in	prhs[19]
#define m_eu_in	prhs[20]
#define m_rw_in	prhs[21]
#define pim_us_eu__in	prhs[22]
#define pim_us_rw__in	prhs[23]
#define pex_us_eu__in	prhs[24]
#define pim_eu_us__in	prhs[25]
#define pim_eu_rw__in	prhs[26]
#define pex_eu_us__in	prhs[27]
#define pim_rw_us__in	prhs[28]
#define pim_rw_eu__in	prhs[29]
#define pim_rw_row__in	prhs[30]
#define pex_rw_us__in	prhs[31]
#define pex_rw_eu__in	prhs[32]
#define Vusd_in	prhs[33]
#define sbar_rw_in	prhs[34]
#define Brw_usd_in	prhs[35]
#define Brw_eur_in	prhs[36]
#define Bus_usd_in	prhs[37]
#define Beu_eur_in	prhs[38]
#define Bus_row_in	prhs[39]
#define Beu_row_in	prhs[40]
#define Beur_in	prhs[41]
#define Beur_l_in	prhs[42]
#define Beur_p_in	prhs[43]
#define Brow_in	prhs[44]
#define Brow_l_in	prhs[45]
#define Brow_p_in	prhs[46]
#define Busd_in	prhs[47]
#define Busd_l_in	prhs[48]
#define Busd_p_in	prhs[49]
#define Prw_rw_in	prhs[50]
#define Xeu_in	prhs[51]
#define Xus_in	prhs[52]
#define Yeu_in	prhs[53]
#define Yrw_in	prhs[54]
#define Yus_in	prhs[55]
#define ah_eu_in	prhs[56]
#define ah_us_in	prhs[57]
#define ah_rw_in	prhs[58]
#define alph_in	prhs[59]
#define bet_in	prhs[60]
#define dtax_eu_us_in	prhs[61]
#define dtax_us_eu_in	prhs[62]
#define dtax_eu_rw_in	prhs[63]
#define dtax_rw_eu_in	prhs[64]
#define dtax_rw_us_in	prhs[65]
#define dtax_us_rw_in	prhs[66]
#define dtax_rw_row_in	prhs[67]
#define eta_in	prhs[68]
#define kap_in	prhs[69]
#define mu_eu_in	prhs[70]
#define mu_us_in	prhs[71]
#define mu_rw_in	prhs[72]
#define omg_in	prhs[73]
#define per_p_year_in	prhs[74]
#define phi_in	prhs[75]
#define phi_eug_in	prhs[76]
#define phi_usg_in	prhs[77]
#define phi_rwg_in	prhs[78]
#define r_in	prhs[79]
#define sig_in	prhs[80]
#define sige_in	prhs[81]
#define tau_in	prhs[82]
#define taup_in	prhs[83]
#define tau_row_in	prhs[84]
#define tax_eu_in_in	prhs[85]
#define tax_us_in_in	prhs[86]
#define tax_eu_us_in	prhs[87]
#define tax_us_eu_in	prhs[88]
#define tax_eu_rw_in	prhs[89]
#define tax_rw_eu_in	prhs[90]
#define tax_rw_us_in	prhs[91]
#define tax_us_rw_in	prhs[92]
#define tax_eu_out_in	prhs[93]
#define tax_us_out_in	prhs[94]
#define tax_rw_out_in	prhs[95]
#define tax_rw_row_in	prhs[96]
#define upp_eur_in	prhs[97]
#define upp_usd_in	prhs[98]
#define vepsf_in	prhs[99]
#define vepst_in	prhs[100]
#define z_in	prhs[101]
#define zrow_in	prhs[102]


/* Output Arguments */
#define out plhs[0]


#if !defined(MAX)
#define	MAX(A, B)	((A) > (B) ? (A) : (B))
#endif

#if !defined(MIN)
#define	MIN(A, B)	((A) < (B) ? (A) : (B))
#endif

#define pi  3.141592653589793
  

/* Prints an MxN matrix to Screen*/
void printmat_rowmaj(int m, int n, double M[m*n]){
    int x,y,k;
    k = 0;
    printf("\n");
    for(x=0;x<m;x++){
        for(y=0;y<n;y++){
            printf("%1.11lf\t", M[k]);
            k++;
        }
        printf("%\n");
    }
    return;
}


void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray*prhs[] )

{
     /*Values in Loops*/
    double C,H,D_p,K_p,MU,E1,E2,E3,D,K,HL,LAML,GAMtildeL,GAM,A,RW,MUtmp;
    
    double *OUT;
    
     double Cus_eu,Cus_rw,Ceu_us,Ceu_rw,Crw_us,Crw_eu,Crw_row,Qusd,Qeur,Qrow,Pus_us,Pus_eu,Pus,Peu_eu,Peu_us,Peu,Prw,Prw_us,Prw_eu,m_us,m_eu,m_rw,pim_us_eu_,pim_us_rw_,pex_us_eu_,pim_eu_us_,pim_eu_rw_,pex_eu_us_,pim_rw_us_,pim_rw_eu_,pim_rw_row_,pex_rw_us_,pex_rw_eu_,Vusd,sbar_rw,Brw_usd,Brw_eur,Bus_usd,Beu_eur,Bus_row,Beu_row,Beur,Beur_l,Beur_p,Brow,Brow_l,Brow_p,Busd,Busd_l,Busd_p,Prw_rw,Xeu,Xus,Yeu,Yrw,Yus,ah_eu,ah_us,ah_rw,alph,bet,dtax_eu_us,dtax_us_eu,dtax_eu_rw,dtax_rw_eu,dtax_rw_us,dtax_us_rw,dtax_rw_row,eta,kap,mu_eu,mu_us,mu_rw,omg,per_p_year,phi,phi_eug,phi_usg,phi_rwg,r,sig,sige,tau,taup,tau_row,tax_eu_in,tax_us_in,tax_eu_us,tax_us_eu,tax_eu_rw,tax_rw_eu,tax_rw_us,tax_us_rw,tax_eu_out,tax_us_out,tax_rw_out,tax_rw_row,upp_eur,upp_usd,vepsf,vepst,z,zrow;

            
    /*Results*/
    double rsum=1;
    
    
    /*Create output argument*/
    out = mxCreateDoubleMatrix(44,41,mxREAL);

    OUT = mxGetPr(out);
    
    
    /*Counters*/
    long ns, ii,tt;
    
    /*BLAS working memory*/
    ptrdiff_t one = 1;
    ptrdiff_t info = 0;
    long IPIV[4] = {0,1,2,3};

    
    /*Check for proper number of arguments*/
    if (nrhs == 103)  {} else{mexErrMsgTxt(" 103 inputs arguments required.");}

    
    /* Get Dimensions of Input Arguments*/
    ptrdiff_t four  = 4;
    ptrdiff_t three = 3;
         
    /*Parameters intialized*/
    Cus_eu= *mxGetPr(Cus_eu_in);
Cus_rw= *mxGetPr(Cus_rw_in);
Ceu_us= *mxGetPr(Ceu_us_in);
Ceu_rw= *mxGetPr(Ceu_rw_in);
Crw_us= *mxGetPr(Crw_us_in);
Crw_eu= *mxGetPr(Crw_eu_in);
Crw_row= *mxGetPr(Crw_row_in);
Qusd= *mxGetPr(Qusd_in);
Qeur= *mxGetPr(Qeur_in);
Qrow= *mxGetPr(Qrow_in);
Pus_us= *mxGetPr(Pus_us_in);
Pus_eu= *mxGetPr(Pus_eu_in);
Pus= *mxGetPr(Pus_in);
Peu_eu= *mxGetPr(Peu_eu_in);
Peu_us= *mxGetPr(Peu_us_in);
Peu= *mxGetPr(Peu_in);
Prw= *mxGetPr(Prw_in);
Prw_us= *mxGetPr(Prw_us_in);
Prw_eu= *mxGetPr(Prw_eu_in);
m_us= *mxGetPr(m_us_in);
m_eu= *mxGetPr(m_eu_in);
m_rw= *mxGetPr(m_rw_in);
pim_us_eu_= *mxGetPr(pim_us_eu__in);
pim_us_rw_= *mxGetPr(pim_us_rw__in);
pex_us_eu_= *mxGetPr(pex_us_eu__in);
pim_eu_us_= *mxGetPr(pim_eu_us__in);
pim_eu_rw_= *mxGetPr(pim_eu_rw__in);
pex_eu_us_= *mxGetPr(pex_eu_us__in);
pim_rw_us_= *mxGetPr(pim_rw_us__in);
pim_rw_eu_= *mxGetPr(pim_rw_eu__in);
pim_rw_row_= *mxGetPr(pim_rw_row__in);
pex_rw_us_= *mxGetPr(pex_rw_us__in);
pex_rw_eu_= *mxGetPr(pex_rw_eu__in);
Vusd= *mxGetPr(Vusd_in);
sbar_rw= *mxGetPr(sbar_rw_in);
Brw_usd= *mxGetPr(Brw_usd_in);
Brw_eur= *mxGetPr(Brw_eur_in);
Bus_usd= *mxGetPr(Bus_usd_in);
Beu_eur= *mxGetPr(Beu_eur_in);
Bus_row= *mxGetPr(Bus_row_in);
Beu_row= *mxGetPr(Beu_row_in);
Beur= *mxGetPr(Beur_in);
Beur_l= *mxGetPr(Beur_l_in);
Beur_p= *mxGetPr(Beur_p_in);
Brow= *mxGetPr(Brow_in);
Brow_l= *mxGetPr(Brow_l_in);
Brow_p= *mxGetPr(Brow_p_in);
Busd= *mxGetPr(Busd_in);
Busd_l= *mxGetPr(Busd_l_in);
Busd_p= *mxGetPr(Busd_p_in);
Prw_rw= *mxGetPr(Prw_rw_in);
Xeu= *mxGetPr(Xeu_in);
Xus= *mxGetPr(Xus_in);
Yeu= *mxGetPr(Yeu_in);
Yrw= *mxGetPr(Yrw_in);
Yus= *mxGetPr(Yus_in);
ah_eu= *mxGetPr(ah_eu_in);
ah_us= *mxGetPr(ah_us_in);
ah_rw= *mxGetPr(ah_rw_in);
alph= *mxGetPr(alph_in);
bet= *mxGetPr(bet_in);
dtax_eu_us= *mxGetPr(dtax_eu_us_in);
dtax_us_eu= *mxGetPr(dtax_us_eu_in);
dtax_eu_rw= *mxGetPr(dtax_eu_rw_in);
dtax_rw_eu= *mxGetPr(dtax_rw_eu_in);
dtax_rw_us= *mxGetPr(dtax_rw_us_in);
dtax_us_rw= *mxGetPr(dtax_us_rw_in);
dtax_rw_row= *mxGetPr(dtax_rw_row_in);
eta= *mxGetPr(eta_in);
kap= *mxGetPr(kap_in);
mu_eu= *mxGetPr(mu_eu_in);
mu_us= *mxGetPr(mu_us_in);
mu_rw= *mxGetPr(mu_rw_in);
omg= *mxGetPr(omg_in);
per_p_year= *mxGetPr(per_p_year_in);
phi= *mxGetPr(phi_in);
phi_eug= *mxGetPr(phi_eug_in);
phi_usg= *mxGetPr(phi_usg_in);
phi_rwg= *mxGetPr(phi_rwg_in);
r= *mxGetPr(r_in);
sig= *mxGetPr(sig_in);
sige= *mxGetPr(sige_in);
tau= *mxGetPr(tau_in);
taup= *mxGetPr(taup_in);
tau_row= *mxGetPr(tau_row_in);
tax_eu_in= *mxGetPr(tax_eu_in_in);
tax_us_in= *mxGetPr(tax_us_in_in);
tax_eu_us= *mxGetPr(tax_eu_us_in);
tax_us_eu= *mxGetPr(tax_us_eu_in);
tax_eu_rw= *mxGetPr(tax_eu_rw_in);
tax_rw_eu= *mxGetPr(tax_rw_eu_in);
tax_rw_us= *mxGetPr(tax_rw_us_in);
tax_us_rw= *mxGetPr(tax_us_rw_in);
tax_eu_out= *mxGetPr(tax_eu_out_in);
tax_us_out= *mxGetPr(tax_us_out_in);
tax_rw_out= *mxGetPr(tax_rw_out_in);
tax_rw_row= *mxGetPr(tax_rw_row_in);
upp_eur= *mxGetPr(upp_eur_in);
upp_usd= *mxGetPr(upp_usd_in);
vepsf= *mxGetPr(vepsf_in);
vepst= *mxGetPr(vepst_in);
z= *mxGetPr(z_in);
zrow= *mxGetPr(zrow_in);

            
            
    /*Declare MatlabFunction Terms*/
    
                  
    /*Output argument*/
    OUT [0] =-(pow(Cus_eu,-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw)-1.0)*pow(Cus_rw,-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw))*pow(ah_us,-ah_us)*mu_eu*pow(-(Ceu_us*mu_eu+Crw_us*mu_rw+Yus*mu_us*(phi_usg-1.0))/mu_us,ah_us)*(ah_us-1.0)*pow(-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw),(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw)))/(mu_eu+mu_rw);
OUT [1] =-(pow(Ceu_us,-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(Ceu_rw,-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw))*ah_eu*pow(ah_eu,-ah_eu)*mu_us*pow(-(Crw_eu*mu_rw+Cus_eu*mu_us+Yeu*mu_eu*(phi_eug-1.0))/mu_eu,ah_eu-1.0)*pow(-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw),(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw)))/mu_eu;
OUT [4] =-mu_us/mu_eu;
OUT [44] =-(pow(Cus_eu,-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(Cus_rw,-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw)-1.0)*pow(ah_us,-ah_us)*mu_rw*pow(-(Ceu_us*mu_eu+Crw_us*mu_rw+Yus*mu_us*(phi_usg-1.0))/mu_us,ah_us)*(ah_us-1.0)*pow(-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw),(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw)))/(mu_eu+mu_rw);
OUT [46] =-(pow(Crw_eu,-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_us,-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_row,-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*ah_rw*pow(ah_rw,-ah_rw)*mu_us*pow(-(Ceu_rw*mu_eu+Cus_rw*mu_us-mu_rw*(Crw_row-Yrw)*(phi_rwg-1.0))/mu_rw,ah_rw-1.0)*pow(-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)))/mu_rw;
OUT [49] =-mu_us/mu_rw;
OUT [88] =-(pow(Cus_eu,-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(Cus_rw,-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw))*ah_us*pow(ah_us,-ah_us)*mu_eu*pow(-(Ceu_us*mu_eu+Crw_us*mu_rw+Yus*mu_us*(phi_usg-1.0))/mu_us,ah_us-1.0)*pow(-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw),(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw)))/mu_us;
OUT [89] =-(pow(Ceu_us,-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw)-1.0)*pow(Ceu_rw,-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw))*pow(ah_eu,-ah_eu)*mu_us*pow(-(Crw_eu*mu_rw+Cus_eu*mu_us+Yeu*mu_eu*(phi_eug-1.0))/mu_eu,ah_eu)*(ah_eu-1.0)*pow(-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw),(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw)))/(mu_us+mu_rw);
OUT [91] =-mu_eu/mu_us;
OUT [133] =-(pow(Ceu_us,-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(Ceu_rw,-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw)-1.0)*pow(ah_eu,-ah_eu)*mu_rw*pow(-(Crw_eu*mu_rw+Cus_eu*mu_us+Yeu*mu_eu*(phi_eug-1.0))/mu_eu,ah_eu)*(ah_eu-1.0)*pow(-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw),(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw)))/(mu_us+mu_rw);
OUT [134] =-(pow(Crw_eu,-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_us,-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_row,-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*ah_rw*pow(ah_rw,-ah_rw)*mu_eu*pow(-(Ceu_rw*mu_eu+Cus_rw*mu_us-mu_rw*(Crw_row-Yrw)*(phi_rwg-1.0))/mu_rw,ah_rw-1.0)*pow(-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)))/mu_rw;
OUT [137] =-mu_eu/mu_rw;
OUT [176] =-(pow(Cus_eu,-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(Cus_rw,-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw))*ah_us*pow(ah_us,-ah_us)*mu_rw*pow(-(Ceu_us*mu_eu+Crw_us*mu_rw+Yus*mu_us*(phi_usg-1.0))/mu_us,ah_us-1.0)*pow(-(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(-(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw),(mu_rw*(ah_us-1.0))/(mu_eu+mu_rw)))/mu_us;
OUT [178] =-(pow(Crw_eu,-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_us,-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)-1.0)*pow(Crw_row,-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(ah_rw,-ah_rw)*mu_us*pow(-(Ceu_rw*mu_eu+Cus_rw*mu_us-mu_rw*(Crw_row-Yrw)*(phi_rwg-1.0))/mu_rw,ah_rw)*(ah_rw-1.0)*pow(-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)))/(mu_eu+mu_us+mu_rw);
OUT [179] =-mu_rw/mu_us;
OUT [221] =-(pow(Ceu_us,-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(Ceu_rw,-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw))*ah_eu*pow(ah_eu,-ah_eu)*mu_rw*pow(-(Crw_eu*mu_rw+Cus_eu*mu_us+Yeu*mu_eu*(phi_eug-1.0))/mu_eu,ah_eu-1.0)*pow(-(mu_us*(ah_eu-1.0))/(mu_us+mu_rw),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(-(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw),(mu_rw*(ah_eu-1.0))/(mu_us+mu_rw)))/mu_eu;
OUT [222] =-(pow(Crw_eu,-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)-1.0)*pow(Crw_us,-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_row,-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(ah_rw,-ah_rw)*mu_eu*pow(-(Ceu_rw*mu_eu+Cus_rw*mu_us-mu_rw*(Crw_row-Yrw)*(phi_rwg-1.0))/mu_rw,ah_rw)*(ah_rw-1.0)*pow(-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)))/(mu_eu+mu_us+mu_rw);
OUT [224] =-mu_rw/mu_eu;
OUT [266] =pow(Crw_eu,-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_us,-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_row,-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*ah_rw*pow(ah_rw,-ah_rw)*pow(-(Ceu_rw*mu_eu+Cus_rw*mu_us-mu_rw*(Crw_row-Yrw)*(phi_rwg-1.0))/mu_rw,ah_rw-1.0)*(phi_rwg-1.0)*pow(-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))-(pow(Crw_eu,-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_us,-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Crw_row,-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)-1.0)*pow(ah_rw,-ah_rw)*mu_rw*pow(-(Ceu_rw*mu_eu+Cus_rw*mu_us-mu_rw*(Crw_row-Yrw)*(phi_rwg-1.0))/mu_rw,ah_rw)*(ah_rw-1.0)*pow(-(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(-(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw),(mu_rw*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)))/(mu_eu+mu_us+mu_rw);
OUT [269] =phi_rwg-1.0;
OUT [320] =Bus_usd*Pus_us*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf)-pow(Bus_usd,2)*pow(Pus_us,2)*Qusd*pow(upp_usd,2)*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf-1.0);
OUT [322] =-(Pus_us*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf)*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu-pow(Pus_us,2)*Qusd*1.0/pow(mu_eu,2)*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf-1.0)*pow(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us,2)*pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf-1.0);
OUT [324] =Brw_usd*Pus_us*upp_usd*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf)-pow(Brw_usd,2)*pow(Pus_us,2)*Qusd*pow(upp_usd,2)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf-1.0);
OUT [326] =-Bus_usd*Pus_us*Xus*m_us*pow(upp_usd,2)*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf-1.0);
OUT [329] =(Pus_us*Xeu*m_eu*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf-1.0)*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us)*pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf-1.0))/mu_eu;
OUT [332] =-Brw_usd*Pus_us*m_rw*pow(upp_usd,2)*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf-1.0);
OUT [335] =m_us*mu_us*(Bus_usd*Pus_us*Xus*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf)-pow(Bus_usd,2)*pow(Pus_us,2)*Qusd*Xus*pow(upp_usd,2)*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf-1.0));
OUT [336] =-m_eu*mu_eu*((Pus_us*Xeu*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf)*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu+pow(Pus_us,2)*Qusd*Xeu*1.0/pow(mu_eu,2)*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf-1.0)*pow(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us,2)*pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf-1.0));
OUT [337] =m_rw*mu_rw*(Brw_usd*Pus_us*upp_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf)-pow(Brw_usd,2)*pow(Pus_us,2)*Qusd*pow(upp_usd,2)*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf-1.0));
OUT [365] =-(Peu_eu*upp_eur*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf)*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us-pow(Peu_eu,2)*Qeur*1.0/pow(mu_us,2)*pow(upp_eur,2)*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf-1.0)*pow(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw,2)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf-1.0);
OUT [367] =Beu_eur*Peu_eu*upp_eur*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)-pow(Beu_eur,2)*pow(Peu_eu,2)*Qeur*pow(upp_eur,2)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf-1.0);
OUT [369] =Brw_eur*Peu_eu*upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)-pow(Brw_eur,2)*pow(Peu_eu,2)*Qeur*pow(upp_eur,2)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf-1.0);
OUT [371] =-(Peu_eu*m_us*pow(upp_eur,2)*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf-1.0)*(Xus-1.0)*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf-1.0))/mu_us;
OUT [374] =Beu_eur*Peu_eu*m_eu*pow(upp_eur,2)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*(Xeu-1.0)*pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf-1.0);
OUT [377] =-Brw_eur*Peu_eu*m_rw*pow(upp_eur,2)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)*pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf-1.0);
OUT [379] =m_us*mu_us*((Peu_eu*upp_eur*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf)*(Xus-1.0)*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us+pow(Peu_eu,2)*Qeur*1.0/pow(mu_us,2)*pow(upp_eur,2)*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf-1.0)*(Xus-1.0)*pow(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw,2)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf-1.0));
OUT [380] =-m_eu*mu_eu*(Beu_eur*Peu_eu*upp_eur*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)*(Xeu-1.0)-pow(Beu_eur,2)*pow(Peu_eu,2)*Qeur*pow(upp_eur,2)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*(Xeu-1.0)*pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf-1.0));
OUT [381] =m_rw*mu_rw*(Brw_eur*Peu_eu*upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)-pow(Brw_eur,2)*pow(Peu_eu,2)*Qeur*pow(upp_eur,2)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)*pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf-1.0));
OUT [416] =-Bus_row*Prw_rw*m_us*pow(upp_eur,2)*zrow*pow(pow(m_us*zrow,1.0/vepsf)+pow(Bus_row*Prw_rw*Qrow*upp_eur,1.0/vepsf),-vepsf-1.0)*pow(Bus_row*Prw_rw*Qrow*upp_eur,1.0/vepsf-1.0);
OUT [419] =-Beu_row*Prw_rw*m_eu*pow(upp_eur,2)*zrow*pow(pow(m_eu*zrow,1.0/vepsf)+pow(Beu_row*Prw_rw*Qrow*upp_eur,1.0/vepsf),-vepsf-1.0)*pow(Beu_row*Prw_rw*Qrow*upp_eur,1.0/vepsf-1.0);
OUT [422] =(Prw_rw*m_rw*pow(upp_eur,2)*zrow*pow(pow(m_rw*zrow,1.0/vepsf)+pow(-(Prw_rw*Qrow*upp_eur*(-Brow+Beu_row*mu_eu+Bus_row*mu_us))/mu_rw,1.0/vepsf),-vepsf-1.0)*(-Brow+Beu_row*mu_eu+Bus_row*mu_us)*pow(-(Prw_rw*Qrow*upp_eur*(-Brow+Beu_row*mu_eu+Bus_row*mu_us))/mu_rw,1.0/vepsf-1.0))/mu_rw;
OUT [446] =(Pus*pow(Pus_us,-ah_us-1.0)*ah_us*(mu_eu+mu_rw)*pow(Pus_eu*(tax_us_eu+1.0),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(Pus*pow(Pus_us,-ah_us)*pow(Pus_eu*(tax_us_eu+1.0),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw)),-(mu_eu+mu_rw)/(mu_rw*(ah_us-1.0))-1.0))/(mu_rw*(ah_us-1.0)*(tax_us_rw+1.0));
OUT [452] =Bus_usd*Qusd*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf)-pow(Bus_usd,2)*Pus_us*pow(Qusd,2)*pow(upp_usd,2)*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf-1.0);
OUT [454] =-(Qusd*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf)*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu-Pus_us*pow(Qusd,2)*1.0/pow(mu_eu,2)*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf-1.0)*pow(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us,2)*pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf-1.0);
OUT [456] =Brw_usd*Qusd*upp_usd*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf)-pow(Brw_usd,2)*Pus_us*pow(Qusd,2)*pow(upp_usd,2)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf-1.0);
OUT [458] =-Bus_usd*Qusd*Xus*m_us*pow(upp_usd,2)*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf-1.0);
OUT [461] =(Qusd*Xeu*m_eu*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf-1.0)*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us)*pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf-1.0))/mu_eu;
OUT [464] =-Brw_usd*Qusd*m_rw*pow(upp_usd,2)*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf-1.0);
OUT [467] =m_us*mu_us*(Bus_usd*Qusd*Xus*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf)-pow(Bus_usd,2)*Pus_us*pow(Qusd,2)*Xus*pow(upp_usd,2)*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf-1.0));
OUT [468] =-m_eu*mu_eu*((Qusd*Xeu*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf)*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu+Pus_us*pow(Qusd,2)*Xeu*1.0/pow(mu_eu,2)*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf-1.0)*pow(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us,2)*pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf-1.0));
OUT [469] =m_rw*mu_rw*(Brw_usd*Qusd*upp_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf)-pow(Brw_usd,2)*Pus_us*pow(Qusd,2)*pow(upp_usd,2)*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf-1.0));
OUT [490] =-(Pus*pow(Pus_us,-ah_us)*mu_eu*pow(Pus_eu*(tax_us_eu+1.0),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw)-1.0)*(tax_us_eu+1.0)*pow(Pus*pow(Pus_us,-ah_us)*pow(Pus_eu*(tax_us_eu+1.0),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw)),-(mu_eu+mu_rw)/(mu_rw*(ah_us-1.0))-1.0))/(mu_rw*(tax_us_rw+1.0));
OUT [534] =-(pow(Pus_us,-ah_us)*(mu_eu+mu_rw)*pow(Pus_eu*(tax_us_eu+1.0),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw))*pow(Pus*pow(Pus_us,-ah_us)*pow(Pus_eu*(tax_us_eu+1.0),(mu_eu*(ah_us-1.0))/(mu_eu+mu_rw)),-(mu_eu+mu_rw)/(mu_rw*(ah_us-1.0))-1.0))/(mu_rw*(ah_us-1.0)*(tax_us_rw+1.0));
OUT [579] =(Peu*pow(Peu_eu,-ah_eu-1.0)*ah_eu*(mu_us+mu_rw)*pow(Peu_us*(tax_eu_us+1.0),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(Peu*pow(Peu_eu,-ah_eu)*pow(Peu_us*(tax_eu_us+1.0),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw)),-(mu_us+mu_rw)/(mu_rw*(ah_eu-1.0))-1.0))/(mu_rw*(ah_eu-1.0)*(tax_eu_rw+1.0));
OUT [585] =-(Qeur*upp_eur*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf)*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us-Peu_eu*pow(Qeur,2)*1.0/pow(mu_us,2)*pow(upp_eur,2)*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf-1.0)*pow(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw,2)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf-1.0);
OUT [587] =Beu_eur*Qeur*upp_eur*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)-pow(Beu_eur,2)*Peu_eu*pow(Qeur,2)*pow(upp_eur,2)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf-1.0);
OUT [589] =Brw_eur*Qeur*upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)-pow(Brw_eur,2)*Peu_eu*pow(Qeur,2)*pow(upp_eur,2)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf-1.0);
OUT [591] =-(Qeur*m_us*pow(upp_eur,2)*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf-1.0)*(Xus-1.0)*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf-1.0))/mu_us;
OUT [594] =Beu_eur*Qeur*m_eu*pow(upp_eur,2)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*(Xeu-1.0)*pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf-1.0);
OUT [597] =-Brw_eur*Qeur*m_rw*pow(upp_eur,2)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)*pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf-1.0);
OUT [599] =m_us*mu_us*((Qeur*upp_eur*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf)*(Xus-1.0)*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us+Peu_eu*pow(Qeur,2)*1.0/pow(mu_us,2)*pow(upp_eur,2)*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf-1.0)*(Xus-1.0)*pow(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw,2)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf-1.0));
OUT [600] =-m_eu*mu_eu*(Beu_eur*Qeur*upp_eur*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)*(Xeu-1.0)-pow(Beu_eur,2)*Peu_eu*pow(Qeur,2)*pow(upp_eur,2)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*(Xeu-1.0)*pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf-1.0));
OUT [601] =m_rw*mu_rw*(Brw_eur*Qeur*upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)-pow(Brw_eur,2)*Peu_eu*pow(Qeur,2)*pow(upp_eur,2)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)*pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf-1.0));
OUT [623] =-(Peu*pow(Peu_eu,-ah_eu)*mu_us*pow(Peu_us*(tax_eu_us+1.0),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw)-1.0)*(tax_eu_us+1.0)*pow(Peu*pow(Peu_eu,-ah_eu)*pow(Peu_us*(tax_eu_us+1.0),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw)),-(mu_us+mu_rw)/(mu_rw*(ah_eu-1.0))-1.0))/(mu_rw*(tax_eu_rw+1.0));
OUT [667] =-(pow(Peu_eu,-ah_eu)*(mu_us+mu_rw)*pow(Peu_us*(tax_eu_us+1.0),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw))*pow(Peu*pow(Peu_eu,-ah_eu)*pow(Peu_us*(tax_eu_us+1.0),(mu_us*(ah_eu-1.0))/(mu_us+mu_rw)),-(mu_us+mu_rw)/(mu_rw*(ah_eu-1.0))-1.0))/(mu_rw*(ah_eu-1.0)*(tax_eu_rw+1.0));
OUT [712] =-(pow(Prw_rw,-ah_rw)*pow(Prw_eu*(tax_rw_eu+1.0),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Prw_us*(tax_rw_us+1.0),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*(mu_eu+mu_us+mu_rw)*pow(Prw*pow(Prw_rw,-ah_rw)*pow(Prw_eu*(tax_rw_eu+1.0),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Prw_us*(tax_rw_us+1.0),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)),-(mu_eu+mu_us+mu_rw)/(mu_rw*(ah_rw-1.0))-1.0))/(mu_rw*(ah_rw-1.0)*(tax_rw_row+1.0));
OUT [756] =-(Prw*pow(Prw_rw,-ah_rw)*mu_us*pow(Prw_eu*(tax_rw_eu+1.0),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Prw_us*(tax_rw_us+1.0),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)-1.0)*(tax_rw_us+1.0)*pow(Prw*pow(Prw_rw,-ah_rw)*pow(Prw_eu*(tax_rw_eu+1.0),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Prw_us*(tax_rw_us+1.0),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)),-(mu_eu+mu_us+mu_rw)/(mu_rw*(ah_rw-1.0))-1.0))/(mu_rw*(tax_rw_row+1.0));
OUT [800] =-(Prw*pow(Prw_rw,-ah_rw)*mu_eu*pow(Prw_eu*(tax_rw_eu+1.0),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)-1.0)*pow(Prw_us*(tax_rw_us+1.0),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*(tax_rw_eu+1.0)*pow(Prw*pow(Prw_rw,-ah_rw)*pow(Prw_eu*(tax_rw_eu+1.0),(mu_eu*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw))*pow(Prw_us*(tax_rw_us+1.0),(mu_us*(ah_rw-1.0))/(mu_eu+mu_us+mu_rw)),-(mu_eu+mu_us+mu_rw)/(mu_rw*(ah_rw-1.0))-1.0))/(mu_rw*(tax_rw_row+1.0));
OUT [848] =-Bus_usd*Pus_us*Qusd*Xus*upp_usd*pow(Xus*m_us,1.0/vepsf-1.0)*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0);
OUT [849] =-(Peu_eu*Qeur*upp_eur*pow(-m_us*(Xus-1.0),1.0/vepsf-1.0)*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf-1.0)*(Xus-1.0)*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us;
OUT [854] =Xus*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf)-pow(Xus,2)*m_us*upp_usd*pow(Xus*m_us,1.0/vepsf-1.0)*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0);
OUT [855] =-upp_eur*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf)*(Xus-1.0)-m_us*upp_eur*pow(-m_us*(Xus-1.0),1.0/vepsf-1.0)*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf-1.0)*pow(Xus-1.0,2);
OUT [856] =upp_eur*zrow*pow(pow(m_us*zrow,1.0/vepsf)+pow(Bus_row*Prw_rw*Qrow*upp_eur,1.0/vepsf),-vepsf)-m_us*upp_eur*pow(zrow,2)*pow(m_us*zrow,1.0/vepsf-1.0)*pow(pow(m_us*zrow,1.0/vepsf)+pow(Bus_row*Prw_rw*Qrow*upp_eur,1.0/vepsf),-vepsf-1.0);
OUT [863] =mu_us*(Bus_usd*Pus_us*Qusd*Xus*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf)+(Peu_eu*Qeur*upp_eur*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf)*(Xus-1.0)*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us)-m_us*mu_us*(Bus_usd*Pus_us*Qusd*pow(Xus,2)*upp_usd*pow(Xus*m_us,1.0/vepsf-1.0)*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)-(Peu_eu*Qeur*upp_eur*pow(-m_us*(Xus-1.0),1.0/vepsf-1.0)*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf-1.0)*pow(Xus-1.0,2)*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us);
OUT [894] =(Pus_us*Qusd*Xeu*upp_usd*pow(Xeu*m_eu,1.0/vepsf-1.0)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf-1.0)*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu;
OUT [895] =Beu_eur*Peu_eu*Qeur*upp_eur*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*pow(-m_eu*(Xeu-1.0),1.0/vepsf-1.0)*(Xeu-1.0);
OUT [901] =Xeu*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf)-pow(Xeu,2)*m_eu*upp_usd*pow(Xeu*m_eu,1.0/vepsf-1.0)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf-1.0);
OUT [902] =-upp_eur*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)*(Xeu-1.0)-m_eu*upp_eur*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*pow(-m_eu*(Xeu-1.0),1.0/vepsf-1.0)*pow(Xeu-1.0,2);
OUT [903] =upp_eur*zrow*pow(pow(m_eu*zrow,1.0/vepsf)+pow(Beu_row*Prw_rw*Qrow*upp_eur,1.0/vepsf),-vepsf)-m_eu*upp_eur*pow(zrow,2)*pow(m_eu*zrow,1.0/vepsf-1.0)*pow(pow(m_eu*zrow,1.0/vepsf)+pow(Beu_row*Prw_rw*Qrow*upp_eur,1.0/vepsf),-vepsf-1.0);
OUT [908] =-mu_eu*(Beu_eur*Peu_eu*Qeur*upp_eur*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)*(Xeu-1.0)+(Pus_us*Qusd*Xeu*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf)*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu)-m_eu*mu_eu*(Beu_eur*Peu_eu*Qeur*upp_eur*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*pow(-m_eu*(Xeu-1.0),1.0/vepsf-1.0)*pow(Xeu-1.0,2)-(Pus_us*Qusd*pow(Xeu,2)*upp_usd*pow(Xeu*m_eu,1.0/vepsf-1.0)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf-1.0)*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu);
OUT [940] =-Brw_usd*Pus_us*Qusd*upp_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf-1.0);
OUT [941] =-Brw_eur*Peu_eu*Qeur*upp_eur*pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf-1.0)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0);
OUT [948] =upp_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf)-m_rw*upp_usd*pow(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0,2)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf-1.0);
OUT [949] =upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)-m_rw*upp_eur*pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf-1.0)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*pow(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0,2);
OUT [950] =upp_eur*zrow*pow(pow(m_rw*zrow,1.0/vepsf)+pow(-(Prw_rw*Qrow*upp_eur*(-Brow+Beu_row*mu_eu+Bus_row*mu_us))/mu_rw,1.0/vepsf),-vepsf)-m_rw*upp_eur*pow(zrow,2)*pow(m_rw*zrow,1.0/vepsf-1.0)*pow(pow(m_rw*zrow,1.0/vepsf)+pow(-(Prw_rw*Qrow*upp_eur*(-Brow+Beu_row*mu_eu+Bus_row*mu_us))/mu_rw,1.0/vepsf),-vepsf-1.0);
OUT [953] =mu_rw*(Brw_eur*Peu_eu*Qeur*upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)+Brw_usd*Pus_us*Qusd*upp_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf))-m_rw*mu_rw*(Brw_usd*Pus_us*Qusd*upp_usd*pow(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0,2)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf-1.0)+Brw_eur*Peu_eu*Qeur*upp_eur*pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf-1.0)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*pow(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0,2));
OUT [998] =-exp(pim_us_eu_*2.0)*1.0/pow(exp(pim_us_eu_)+1.0,2)+exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0);
OUT [999] =(exp(pim_us_rw_)*(exp(pim_us_eu_*2.0)*1.0/pow(exp(pim_us_eu_)+1.0,2)-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)))/(exp(pim_us_rw_)+1.0);
OUT [1000] =-(exp(pex_us_eu_)*(-exp(pim_us_eu_*2.0)*1.0/pow(exp(pim_us_eu_)+1.0,2)+exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)+(exp(pim_us_rw_)*(exp(pim_us_eu_*2.0)*1.0/pow(exp(pim_us_eu_)+1.0,2)-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)))/(exp(pim_us_rw_)+1.0)))/(exp(pex_us_eu_)+1.0);
OUT [1001] =exp(pim_us_eu_*2.0)*1.0/pow(exp(pim_us_eu_)+1.0,2)-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-(exp(pim_us_rw_)*(exp(pim_us_eu_*2.0)*1.0/pow(exp(pim_us_eu_)+1.0,2)-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)))/(exp(pim_us_rw_)+1.0)+(exp(pex_us_eu_)*(-exp(pim_us_eu_*2.0)*1.0/pow(exp(pim_us_eu_)+1.0,2)+exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)+(exp(pim_us_rw_)*(exp(pim_us_eu_*2.0)*1.0/pow(exp(pim_us_eu_)+1.0,2)-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)))/(exp(pim_us_rw_)+1.0)))/(exp(pex_us_eu_)+1.0);
OUT [1043] =exp(pim_us_rw_*2.0)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0)*1.0/pow(exp(pim_us_rw_)+1.0,2)-(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0);
OUT [1044] =-(exp(pex_us_eu_)*(exp(pim_us_rw_*2.0)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0)*1.0/pow(exp(pim_us_rw_)+1.0,2)-(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0)))/(exp(pex_us_eu_)+1.0);
OUT [1045] =-exp(pim_us_rw_*2.0)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0)*1.0/pow(exp(pim_us_rw_)+1.0,2)+(exp(pex_us_eu_)*(exp(pim_us_rw_*2.0)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0)*1.0/pow(exp(pim_us_rw_)+1.0,2)-(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0)))/(exp(pex_us_eu_)+1.0)+(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0);
OUT [1088] =-exp(pex_us_eu_*2.0)*1.0/pow(exp(pex_us_eu_)+1.0,2)*(-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)+(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0)+1.0)+(exp(pex_us_eu_)*(-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)+(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0)+1.0))/(exp(pex_us_eu_)+1.0);
OUT [1089] =exp(pex_us_eu_*2.0)*1.0/pow(exp(pex_us_eu_)+1.0,2)*(-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)+(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0)+1.0)-(exp(pex_us_eu_)*(-exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)+(exp(pim_us_rw_)*(exp(pim_us_eu_)/(exp(pim_us_eu_)+1.0)-1.0))/(exp(pim_us_rw_)+1.0)+1.0))/(exp(pex_us_eu_)+1.0);
OUT [1134] =-exp(pim_eu_us_*2.0)*1.0/pow(exp(pim_eu_us_)+1.0,2)+exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0);
OUT [1135] =(exp(pim_eu_rw_)*(exp(pim_eu_us_*2.0)*1.0/pow(exp(pim_eu_us_)+1.0,2)-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)))/(exp(pim_eu_rw_)+1.0);
OUT [1136] =-(exp(pex_eu_us_)*(-exp(pim_eu_us_*2.0)*1.0/pow(exp(pim_eu_us_)+1.0,2)+exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)+(exp(pim_eu_rw_)*(exp(pim_eu_us_*2.0)*1.0/pow(exp(pim_eu_us_)+1.0,2)-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)))/(exp(pim_eu_rw_)+1.0)))/(exp(pex_eu_us_)+1.0);
OUT [1137] =exp(pim_eu_us_*2.0)*1.0/pow(exp(pim_eu_us_)+1.0,2)-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-(exp(pim_eu_rw_)*(exp(pim_eu_us_*2.0)*1.0/pow(exp(pim_eu_us_)+1.0,2)-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)))/(exp(pim_eu_rw_)+1.0)+(exp(pex_eu_us_)*(-exp(pim_eu_us_*2.0)*1.0/pow(exp(pim_eu_us_)+1.0,2)+exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)+(exp(pim_eu_rw_)*(exp(pim_eu_us_*2.0)*1.0/pow(exp(pim_eu_us_)+1.0,2)-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)))/(exp(pim_eu_rw_)+1.0)))/(exp(pex_eu_us_)+1.0);
OUT [1179] =exp(pim_eu_rw_*2.0)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0)*1.0/pow(exp(pim_eu_rw_)+1.0,2)-(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0);
OUT [1180] =-(exp(pex_eu_us_)*(exp(pim_eu_rw_*2.0)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0)*1.0/pow(exp(pim_eu_rw_)+1.0,2)-(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0)))/(exp(pex_eu_us_)+1.0);
OUT [1181] =-exp(pim_eu_rw_*2.0)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0)*1.0/pow(exp(pim_eu_rw_)+1.0,2)+(exp(pex_eu_us_)*(exp(pim_eu_rw_*2.0)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0)*1.0/pow(exp(pim_eu_rw_)+1.0,2)-(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0)))/(exp(pex_eu_us_)+1.0)+(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0);
OUT [1224] =-exp(pex_eu_us_*2.0)*1.0/pow(exp(pex_eu_us_)+1.0,2)*(-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)+(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0)+1.0)+(exp(pex_eu_us_)*(-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)+(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0)+1.0))/(exp(pex_eu_us_)+1.0);
OUT [1225] =exp(pex_eu_us_*2.0)*1.0/pow(exp(pex_eu_us_)+1.0,2)*(-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)+(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0)+1.0)-(exp(pex_eu_us_)*(-exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)+(exp(pim_eu_rw_)*(exp(pim_eu_us_)/(exp(pim_eu_us_)+1.0)-1.0))/(exp(pim_eu_rw_)+1.0)+1.0))/(exp(pex_eu_us_)+1.0);
OUT [1270] =-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0);
OUT [1271] =(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0);
OUT [1272] =-(exp(pim_rw_row_)*(-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0);
OUT [1273] =(exp(pex_rw_us_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)))/(exp(pex_rw_us_)+1.0);
OUT [1274] =-(exp(pex_rw_eu_)*(-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)))/(exp(pex_rw_us_)+1.0)))/(exp(pex_rw_eu_)+1.0);
OUT [1275] =exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)-(exp(pex_rw_us_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)))/(exp(pex_rw_us_)+1.0)+(exp(pex_rw_eu_)*(-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)+exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_*2.0)*1.0/pow(exp(pim_rw_us_)+1.0,2)-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)))/(exp(pex_rw_us_)+1.0)))/(exp(pex_rw_eu_)+1.0);
OUT [1315] =exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0);
OUT [1316] =-(exp(pim_rw_row_)*(exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0);
OUT [1317] =(exp(pex_rw_us_)*(-exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)+(exp(pim_rw_row_)*(exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pex_rw_us_)+1.0);
OUT [1318] =-(exp(pex_rw_eu_)*(exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_row_)*(exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)+(exp(pex_rw_us_)*(-exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)+(exp(pim_rw_row_)*(exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pex_rw_us_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pex_rw_eu_)+1.0);
OUT [1319] =-exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)+(exp(pim_rw_row_)*(exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)+(exp(pex_rw_eu_)*(exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_row_)*(exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)+(exp(pex_rw_us_)*(-exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)+(exp(pim_rw_row_)*(exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pex_rw_us_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pex_rw_eu_)+1.0)-(exp(pex_rw_us_)*(-exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)+(exp(pim_rw_row_)*(exp(pim_rw_eu_*2.0)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0)*1.0/pow(exp(pim_rw_eu_)+1.0,2)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)))/(exp(pex_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0);
OUT [1360] =-exp(pim_rw_row_*2.0)*1.0/pow(exp(pim_rw_row_)+1.0,2)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0);
OUT [1361] =(exp(pex_rw_us_)*(exp(pim_rw_row_*2.0)*1.0/pow(exp(pim_rw_row_)+1.0,2)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)))/(exp(pex_rw_us_)+1.0);
OUT [1362] =-(exp(pex_rw_eu_)*(-exp(pim_rw_row_*2.0)*1.0/pow(exp(pim_rw_row_)+1.0,2)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_row_*2.0)*1.0/pow(exp(pim_rw_row_)+1.0,2)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)))/(exp(pex_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)))/(exp(pex_rw_eu_)+1.0);
OUT [1363] =exp(pim_rw_row_*2.0)*1.0/pow(exp(pim_rw_row_)+1.0,2)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0)-(exp(pex_rw_us_)*(exp(pim_rw_row_*2.0)*1.0/pow(exp(pim_rw_row_)+1.0,2)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)))/(exp(pex_rw_us_)+1.0)+(exp(pex_rw_eu_)*(-exp(pim_rw_row_*2.0)*1.0/pow(exp(pim_rw_row_)+1.0,2)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_row_*2.0)*1.0/pow(exp(pim_rw_row_)+1.0,2)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)))/(exp(pex_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)))/(exp(pex_rw_eu_)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0);
OUT [1405] =exp(pex_rw_us_*2.0)*1.0/pow(exp(pex_rw_us_)+1.0,2)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0)-(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0);
OUT [1406] =-(exp(pex_rw_eu_)*(exp(pex_rw_us_*2.0)*1.0/pow(exp(pex_rw_us_)+1.0,2)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0)-(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0)))/(exp(pex_rw_eu_)+1.0);
OUT [1407] =(exp(pex_rw_eu_)*(exp(pex_rw_us_*2.0)*1.0/pow(exp(pex_rw_us_)+1.0,2)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0)-(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0)))/(exp(pex_rw_eu_)+1.0)-exp(pex_rw_us_*2.0)*1.0/pow(exp(pex_rw_us_)+1.0,2)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0)+(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0);
OUT [1450] =(exp(pex_rw_eu_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pex_rw_eu_)+1.0)-exp(pex_rw_eu_*2.0)*1.0/pow(exp(pex_rw_eu_)+1.0,2)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0);
OUT [1451] =-(exp(pex_rw_eu_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pex_rw_eu_)+1.0)+exp(pex_rw_eu_*2.0)*1.0/pow(exp(pex_rw_eu_)+1.0,2)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pex_rw_us_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)-(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)-1.0))/(exp(pex_rw_us_)+1.0)-(exp(pim_rw_row_)*(-exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0))/(exp(pim_rw_row_)+1.0)+(exp(pim_rw_eu_)*(exp(pim_rw_us_)/(exp(pim_rw_us_)+1.0)-1.0))/(exp(pim_rw_eu_)+1.0)+1.0);
OUT [1512] =sqrt(2.0)*Brw_usd*Pus_us*Qusd*m_rw*upp_usd*1.0/sqrt(pi)*exp(pow(sbar_rw,2)*(-1.0/2.0))*(z*2.0-1.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf-1.0)*(-1.0/2.0);
OUT [1513] =(sqrt(2.0)*Brw_eur*Peu_eu*Qeur*m_rw*upp_eur*1.0/sqrt(pi)*exp(pow(sbar_rw,2)*(-1.0/2.0))*pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf-1.0)*(z*2.0-1.0)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0))/2.0;
OUT [1520] =(sqrt(2.0)*m_rw*upp_usd*1.0/sqrt(pi)*exp(pow(sbar_rw,2)*(-1.0/2.0))*(z*2.0-1.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf))/2.0-(sqrt(2.0)*pow(m_rw,2)*upp_usd*1.0/sqrt(pi)*exp(pow(sbar_rw,2)*(-1.0/2.0))*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(z*2.0-1.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf-1.0))/2.0;
OUT [1521] =sqrt(2.0)*m_rw*upp_eur*1.0/sqrt(pi)*exp(pow(sbar_rw,2)*(-1.0/2.0))*(z*2.0-1.0)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)*(-1.0/2.0)+(sqrt(2.0)*pow(m_rw,2)*upp_eur*1.0/sqrt(pi)*exp(pow(sbar_rw,2)*(-1.0/2.0))*pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf-1.0)*(z*2.0-1.0)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0))/2.0;
OUT [1525] =m_rw*mu_rw*((sqrt(2.0)*Brw_usd*Pus_us*Qusd*upp_usd*1.0/sqrt(pi)*exp(pow(sbar_rw,2)*(-1.0/2.0))*(z*2.0-1.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf))/2.0-(sqrt(2.0)*Brw_eur*Peu_eu*Qeur*upp_eur*1.0/sqrt(pi)*exp(pow(sbar_rw,2)*(-1.0/2.0))*(z*2.0-1.0)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf))/2.0-(sqrt(2.0)*Brw_usd*Pus_us*Qusd*m_rw*upp_usd*1.0/sqrt(pi)*exp(pow(sbar_rw,2)*(-1.0/2.0))*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*(z*2.0-1.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf-1.0))/2.0+(sqrt(2.0)*Brw_eur*Peu_eu*Qeur*m_rw*upp_eur*1.0/sqrt(pi)*exp(pow(sbar_rw,2)*(-1.0/2.0))*pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf-1.0)*(z*2.0-1.0)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0))/2.0);
OUT [1549] =-mu_rw/mu_eu;
OUT [1554] =-(Pus_us*Qusd*mu_rw*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf))/mu_eu-pow(Pus_us,2)*pow(Qusd,2)*1.0/pow(mu_eu,2)*mu_rw*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf-1.0)*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us)*pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf-1.0);
OUT [1556] =Pus_us*Qusd*upp_usd*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf)-Brw_usd*pow(Pus_us,2)*pow(Qusd,2)*pow(upp_usd,2)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf-1.0);
OUT [1561] =(Pus_us*Qusd*Xeu*m_eu*mu_rw*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf-1.0)*pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf-1.0))/mu_eu;
OUT [1564] =-Pus_us*Qusd*m_rw*pow(upp_usd,2)*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf-1.0);
OUT [1568] =-m_eu*mu_eu*((Pus_us*Qusd*Xeu*mu_rw*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf))/mu_eu+pow(Pus_us,2)*pow(Qusd,2)*Xeu*1.0/pow(mu_eu,2)*mu_rw*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf-1.0)*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us)*pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf-1.0));
OUT [1569] =m_rw*mu_rw*(Pus_us*Qusd*upp_usd*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf)-Brw_usd*pow(Pus_us,2)*pow(Qusd,2)*pow(upp_usd,2)*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0)*pow(pow(m_rw*(z-(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0),1.0/vepsf)+pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(Brw_usd*Pus_us*Qusd*upp_usd,1.0/vepsf-1.0));
OUT [1594] =-mu_rw/mu_us;
OUT [1597] =-(Peu_eu*Qeur*mu_rw*upp_eur*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf))/mu_us-pow(Peu_eu,2)*pow(Qeur,2)*1.0/pow(mu_us,2)*mu_rw*pow(upp_eur,2)*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf-1.0)*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf-1.0);
OUT [1601] =Peu_eu*Qeur*upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)-Brw_eur*pow(Peu_eu,2)*pow(Qeur,2)*pow(upp_eur,2)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf-1.0);
OUT [1603] =-(Peu_eu*Qeur*m_us*mu_rw*pow(upp_eur,2)*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf-1.0)*(Xus-1.0)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf-1.0))/mu_us;
OUT [1609] =-Peu_eu*Qeur*m_rw*pow(upp_eur,2)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)*pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf-1.0);
OUT [1611] =m_us*mu_us*((Peu_eu*Qeur*mu_rw*upp_eur*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf)*(Xus-1.0))/mu_us+pow(Peu_eu,2)*pow(Qeur,2)*1.0/pow(mu_us,2)*mu_rw*pow(upp_eur,2)*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf-1.0)*(Xus-1.0)*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf-1.0));
OUT [1613] =m_rw*mu_rw*(Peu_eu*Qeur*upp_eur*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)-Brw_eur*pow(Peu_eu,2)*pow(Qeur,2)*pow(upp_eur,2)*pow(pow(m_rw*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0),1.0/vepsf)+pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*(-z+(erfc((sqrt(2.0)*sbar_rw)/2.0)*(z*2.0-1.0))/2.0+1.0)*pow(Brw_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf-1.0));
OUT [1637] =-mu_us/mu_eu;
OUT [1640] =Pus_us*Qusd*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf)-Bus_usd*pow(Pus_us,2)*pow(Qusd,2)*pow(upp_usd,2)*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf-1.0);
OUT [1642] =-(Pus_us*Qusd*mu_us*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf))/mu_eu-pow(Pus_us,2)*pow(Qusd,2)*1.0/pow(mu_eu,2)*mu_us*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf-1.0)*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us)*pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf-1.0);
OUT [1646] =-Pus_us*Qusd*Xus*m_us*pow(upp_usd,2)*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf-1.0);
OUT [1649] =(Pus_us*Qusd*Xeu*m_eu*mu_us*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf-1.0)*pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf-1.0))/mu_eu;
OUT [1655] =m_us*mu_us*(Pus_us*Qusd*Xus*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf)-Bus_usd*pow(Pus_us,2)*pow(Qusd,2)*Xus*pow(upp_usd,2)*pow(pow(Xus*m_us,1.0/vepsf)+pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf),-vepsf-1.0)*pow(Bus_usd*Pus_us*Qusd*upp_usd,1.0/vepsf-1.0));
OUT [1656] =-m_eu*mu_eu*((Pus_us*Qusd*Xeu*mu_us*upp_usd*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf))/mu_eu+pow(Pus_us,2)*pow(Qusd,2)*Xeu*1.0/pow(mu_eu,2)*mu_us*pow(upp_usd,2)*pow(pow(Xeu*m_eu,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf),-vepsf-1.0)*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us)*pow(-(Pus_us*Qusd*upp_usd*(-Busd+Brw_usd*mu_rw+Bus_usd*mu_us))/mu_eu,1.0/vepsf-1.0));
OUT [1682] =-mu_eu/mu_us;
OUT [1685] =-(Peu_eu*Qeur*mu_eu*upp_eur*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf))/mu_us-pow(Peu_eu,2)*pow(Qeur,2)*mu_eu*1.0/pow(mu_us,2)*pow(upp_eur,2)*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf-1.0)*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf-1.0);
OUT [1687] =Peu_eu*Qeur*upp_eur*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)-Beu_eur*pow(Peu_eu,2)*pow(Qeur,2)*pow(upp_eur,2)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf-1.0);
OUT [1691] =-(Peu_eu*Qeur*m_us*mu_eu*pow(upp_eur,2)*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf-1.0)*(Xus-1.0)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf-1.0))/mu_us;
OUT [1694] =Peu_eu*Qeur*m_eu*pow(upp_eur,2)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*(Xeu-1.0)*pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf-1.0);
OUT [1699] =m_us*mu_us*((Peu_eu*Qeur*mu_eu*upp_eur*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf)*(Xus-1.0))/mu_us+pow(Peu_eu,2)*pow(Qeur,2)*mu_eu*1.0/pow(mu_us,2)*pow(upp_eur,2)*pow(pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf-1.0)*(Xus-1.0)*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw)*pow(-(Peu_eu*Qeur*upp_eur*(-Beur+Beu_eur*mu_eu+Brw_eur*mu_rw))/mu_us,1.0/vepsf-1.0));
OUT [1700] =-m_eu*mu_eu*(Peu_eu*Qeur*upp_eur*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf)*(Xeu-1.0)-Beu_eur*pow(Peu_eu,2)*pow(Qeur,2)*pow(upp_eur,2)*pow(pow(-m_eu*(Xeu-1.0),1.0/vepsf)+pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf),-vepsf-1.0)*(Xeu-1.0)*pow(Beu_eur*Peu_eu*Qeur*upp_eur,1.0/vepsf-1.0));
OUT [1727] =-mu_us/mu_rw;
OUT [1736] =-Prw_rw*Qrow*m_us*pow(upp_eur,2)*zrow*pow(pow(m_us*zrow,1.0/vepsf)+pow(Bus_row*Prw_rw*Qrow*upp_eur,1.0/vepsf),-vepsf-1.0)*pow(Bus_row*Prw_rw*Qrow*upp_eur,1.0/vepsf-1.0);
OUT [1742] =(Prw_rw*Qrow*m_rw*mu_us*pow(upp_eur,2)*zrow*pow(pow(m_rw*zrow,1.0/vepsf)+pow(-(Prw_rw*Qrow*upp_eur*(-Brow+Beu_row*mu_eu+Bus_row*mu_us))/mu_rw,1.0/vepsf),-vepsf-1.0)*pow(-(Prw_rw*Qrow*upp_eur*(-Brow+Beu_row*mu_eu+Bus_row*mu_us))/mu_rw,1.0/vepsf-1.0))/mu_rw;
OUT [1771] =-mu_eu/mu_rw;
OUT [1783] =-Prw_rw*Qrow*m_eu*pow(upp_eur,2)*zrow*pow(pow(m_eu*zrow,1.0/vepsf)+pow(Beu_row*Prw_rw*Qrow*upp_eur,1.0/vepsf),-vepsf-1.0)*pow(Beu_row*Prw_rw*Qrow*upp_eur,1.0/vepsf-1.0);
OUT [1786] =(Prw_rw*Qrow*m_rw*mu_eu*pow(upp_eur,2)*zrow*pow(pow(m_rw*zrow,1.0/vepsf)+pow(-(Prw_rw*Qrow*upp_eur*(-Brow+Beu_row*mu_eu+Bus_row*mu_us))/mu_rw,1.0/vepsf),-vepsf-1.0)*pow(-(Prw_rw*Qrow*upp_eur*(-Brow+Beu_row*mu_eu+Bus_row*mu_us))/mu_rw,1.0/vepsf-1.0))/mu_rw;

                            
                  
}




