% Attraction_regions_two - compute attraction regions by trying to shoot
% steady-state from many different starting points. 
%
% This versions DOES NOT make use of symmetry assumption.
%
% Step 0: we confirm that in bottom-right converges to Euro steady-state.
% So best case for USD is region of multiplicity, it can never be unqiue. 
% We thus only need to check when we can reach the US steady-state from
% other points.

% Step 1: we crawl along the right edge of the figure to the US. Success
% tells us the right boundry of the figure is in the indetermancy region.
% 
% Step 2: crawl from right to left. When no solution going to USD can be
% found, we've detected the edge of the multiplicty region.


%% make initial grid
load saved_results/steady_usrowwar15.mat

np = 131;
frac_rw_usd_dense = linspace(.2,.85,np);
frac_rw_eur_dense = linspace(.2,.85,np);
[grid_rw_usd_dense,grid_rw_eur_dense] = ndgrid(frac_rw_usd_dense,frac_rw_eur_dense);

%% shooting solver settings
T = 200*per_p_year;

options = optimoptions('fsolve');   
options.Display = 'off';
options.MaxIterations = 800;

options.FiniteDifferenceType = 'central';
options.SpecifyObjectiveGradient = true;
options.CheckGradients = false;

solve_indic = cell(length(frac_rw_usd_dense),1);
bond_path   = cell(length(frac_rw_usd_dense),1);
polc_path   = cell(length(frac_rw_usd_dense),1);

for jj = 1:length(bond_path(:))
    bond_path{jj} = nan(4,10);
end

%% STEP0 - Start in bottom-right and confirm EUR
eq_idx = 3;%Euro steady
targ_ss = xspecial_long(:,eq_idx);
xshoot_final = repmat(targ_ss,[1,T]);
frac_shoot = [frac_rw_usd_dense(end),frac_rw_eur_dense(1),0.90,0.90];
X0 = frac2B(frac_shoot(:),Busd,Beur,mu_us,mu_eu,mu_rw);
%SHOOT
shoot_ = @(x) shooting(x,X0,targ_ss,T,log_idx,neq,nstate,[],...
    Busd,Beur,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,Yus,Yeu,Yrw,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);

% Solve the shoot
[xshoot_final,fval] = fsolve(shoot_,xshoot_final(:),options);
[~,~,~,dfinal] = shoot_(xshoot_final);
xshoot_final=reshape(xshoot_final,[neq+nstate,T]);

disp(['Confirming bottom-right to Euro: ' num2str(sum(fval.^2))])
 

%% STEP1: Crawl along right side shooting for US
solve_indic_right = cell(np,1);
polc_path_right   = cell(np,1);

%ALWAYS LANDING AT
eq_idx = 1;%Euro steady
targ_ss = xspecial_long(:,eq_idx);  
ii = np;
for jj = 1:np
    
    disp(num2str(jj));
    
    %initial starting point
    if jj == 1
        xshoot_final = repmat(targ_ss,[1,T]);
    end
    
    %FLYING FROM:
    frac_shoot = [frac_rw_usd_dense(ii),frac_rw_eur_dense(jj),0.90,0.90]; %leaning dollar
    X0 = frac2B(frac_shoot(:),Busd,Beur,mu_us,mu_eu,mu_rw);
    
    %SHOOT
    shoot_ = @(x) shooting(x,X0,targ_ss,T,log_idx,neq,nstate,[],...
            Busd,Beur,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,Yus,Yeu,Yrw,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);

    % Solve the shoot
    [xshoot_final,fval] = fsolve(shoot_,xshoot_final(:),options);
    [~,~,~,dfinal] = shoot_(xshoot_final);
    xshoot_final=reshape(xshoot_final,[neq+nstate,T]);
    
    % Store results
    xshoot_final(log_idx,:) = exp(xshoot_final(log_idx,:));
    polc_path_right{jj}{ii}        = xshoot_final ;
    
    if sum(fval.^2) + sum(dfinal.^2)>1e-5
        error('missed on diagonal, try again');
    else
        solve_indic_right{jj}{ii} = sum(fval.^2) + sum(dfinal.^2);
    end
    
end

%% Step 2: Now crawl right->left, shoorting for US
options.MaxIterations = 30;
parfor jj = 1:np
    
    disp(num2str(jj));
    %initial starting point
    xshoot_final = polc_path_right{jj}{np};
    
    for ii = np-1:-1:1
        
        
        %FLYING FROM:
        frac_shoot = [frac_rw_usd_dense(ii),frac_rw_eur_dense(jj),0.90,0.90]; %leaning dollar
        X0 = frac2B(frac_shoot(:),Busd,Beur,mu_us,mu_eu,mu_rw);
        
        %SHOOT
        shoot_ = @(x) shooting(x,X0,targ_ss,T,log_idx,neq,nstate,[],...
            Busd,Beur,mu_us,mu_eu,mu_rw,ah_us,ah_eu,ah_rw,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,Yus,Yeu,Yrw,phi_usg,phi_eug,phi_rwg,bet,sig,eta,Prw_rw,Xus,Xeu,z,upp_usd,upp_eur,per_p_year,omg,tax_us_eu,tax_us_rw,tax_eu_us,tax_eu_rw,tax_rw_us,tax_rw_eu,tax_rw_row,dtax_us_eu,dtax_us_rw,dtax_eu_us,dtax_eu_rw,dtax_rw_us,dtax_rw_eu,dtax_rw_row,tax_us_in,tax_us_out,tax_eu_in,tax_eu_out,tax_rw_out);

        % Solve the shoot
        [xshoot_final,fval] = fsolve(shoot_,xshoot_final(:),options);
        
        [~,~,~,dfinal] = shoot_(xshoot_final);
        
        xshoot_final=reshape(xshoot_final,[neq+nstate,T]);
        
        % Store results
        xshoot_final(log_idx,:) = exp(xshoot_final(log_idx,:));
        polc_path_right{jj}{ii}        = xshoot_final ;
        
        crit = sum(fval.^2) + sum(dfinal.^2);
        solve_indic_right{jj}{ii} = crit;
        if crit > 1
            break;
        end
        
    end
end

%% The key index variables
solve_idx_r = rot90((cell2mat2(solve_indic_right).'<1));
