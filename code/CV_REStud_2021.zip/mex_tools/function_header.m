function str_ss = function_header(fid,str_ss,args1,args2)

for jj = 1:length(args1)
    fprintf(fid, '%s\n', [char(args1(jj)) , '= x(' num2str(jj) ');']);
    str_ss = [str_ss, char(args1(jj)), ','];
end
for jj = 1:length(args2)
    str_ss = [str_ss, char(args2(jj)), ','];
end
str_ss = [str_ss(1:end-1), ');'];
fprintf(fid, '%s\n', str_ss);
