%% Make ddef_subs_mex
[headstr,dclstr,ptrstr,tdecl,tterms,out_mat] = import_matlabFunction('ddef_sub.m');

warn_str = {['if (nrhs == ' num2str(length(headstr)) ')  {} else{mexErrMsgTxt(" ' num2str(length(headstr)) ' inputs arguments required.");}']};
out_str = {['out = mxCreateDoubleMatrix(' num2str(length(def_sub_val)) ',' num2str(length(vcombo_ss)),',mxREAL);']};

text_insert_dollar('tofill_files/ddefsub_tofill.c', 'auto_generated/ddef_sub_mex.c', {headstr,dclstr,out_str,warn_str,ptrstr,tdecl,tterms,out_mat});
   
mex auto_generated/ddef_sub_mex.c -outdir auto_generated

%% Make dpres_mex
[~,~,~,def_tdecl,def_tterms,~,def_comps,def_decl] = import_matlabFunction('def_sub.m');

[headstr,dclstr,ptrstr,tdecl,tterms,out_mat,~] = import_matlabFunction('dpres.m');

warn_str = {['if (nrhs == ' num2str(length(headstr)) ')  {} else{mexErrMsgTxt(" ' num2str(length(headstr)) ' inputs arguments required.");}']};
out_str = {['out = mxCreateDoubleMatrix(' num2str(length(fcombo_dyn)) ',' num2str(length([jump_vars,state_vars,def_sub_sym])),',mxREAL);']};

text_insert_dollar('tofill_files/dpres_tofill.c', 'auto_generated/dpres_mex.c', {headstr,def_decl,dclstr,out_str,warn_str,ptrstr,tdecl,def_tterms,def_comps,tterms,out_mat});

mex auto_generated/dpres_mex.c -outdir auto_generated

%% Make resid_dyn
[~,~,~,def_tdecl,def_tterms,~,def_comps,def_decl] = import_matlabFunction('def_sub.m');

[headstr,dclstr,ptrstr,tdecl,tterms,out_mat,~] = import_matlabFunction('resid_dyn.m');

warn_str = {['if (nrhs == ' num2str(length(headstr)) ')  {} else{mexErrMsgTxt(" ' num2str(length(headstr)) ' inputs arguments required.");}']};
out_str = {['out = mxCreateDoubleMatrix(' num2str(length(fcombo_dyn)) ',1,mxREAL);']};

text_insert_dollar('tofill_files/resid_dyn_tofill.c', 'auto_generated/resid_dyn_mex.c', {headstr,def_decl,dclstr,out_str,warn_str,ptrstr,tdecl,def_tterms,def_comps,tterms,out_mat});

mex auto_generated/resid_dyn_mex.c -outdir auto_generated

%% Make dprlg
[~,~,~,def_tdecl,def_tterms,~,def_comps,def_decl] = import_matlabFunction('def_sub.m');

[headstr,dclstr,ptrstr,tdecl,tterms,out_mat,~] = import_matlabFunction('dprlg.m');

warn_str = {['if (nrhs == ' num2str(length(headstr)) ')  {} else{mexErrMsgTxt(" ' num2str(length(headstr)) ' inputs arguments required.");}']};
out_str = {['out = mxCreateDoubleMatrix(' num2str(length(fcombo_dyn)) ',' num2str(length([jump_vars,state_vars])),',mxREAL);']};

text_insert_dollar('tofill_files/dprlg_tofill.c', 'auto_generated/dprlg_mex.c', {headstr,def_decl,dclstr,out_str,warn_str,ptrstr,tdecl,def_tterms,def_comps,tterms,out_mat});

mex auto_generated/dprlg_mex.c -outdir auto_generated

%% Make dpast
[~,~,~,def_tdecl,def_tterms,~,def_comps,def_decl] = import_matlabFunction('def_sub.m');

[headstr,dclstr,ptrstr,tdecl,tterms,out_mat,~] = import_matlabFunction('dpast.m');

warn_str = {['if (nrhs == ' num2str(length(headstr)) ')  {} else{mexErrMsgTxt(" ' num2str(length(headstr)) ' inputs arguments required.");}']};
out_str = {['out = mxCreateDoubleMatrix(' num2str(length(fcombo_dyn)) ',' num2str(length([state_vars])),',mxREAL);']};

text_insert_dollar('tofill_files/dpast_tofill.c', 'auto_generated/dpast_mex.c', {headstr,def_decl,dclstr,out_str,warn_str,ptrstr,tdecl,def_tterms,def_comps,tterms,out_mat});

mex auto_generated/dpast_mex.c -outdir auto_generated

%% Make dpast_def
[~,~,~,def_tdecl,def_tterms,~,def_comps,def_decl] = import_matlabFunction('def_sub.m');

[headstr,dclstr,ptrstr,tdecl,tterms,out_mat,~] = import_matlabFunction('dpast_def.m');

warn_str = {['if (nrhs == ' num2str(length(headstr)) ')  {} else{mexErrMsgTxt(" ' num2str(length(headstr)) ' inputs arguments required.");}']};
out_str = {['out = mxCreateDoubleMatrix(' num2str(length(fcombo_dyn)) ',' num2str(length(def_sub_sym)),',mxREAL);']};

text_insert_dollar('tofill_files/dpast_tofill.c', 'auto_generated/dpast_def_mex.c', {headstr,def_decl,dclstr,out_str,warn_str,ptrstr,tdecl,def_tterms,def_comps,tterms,out_mat});

mex auto_generated/dpast_def_mex.c -outdir auto_generated

