% SPRINT_MAT - Print a matrix to cvx format
%
% where
%
% format = the data format, eg, '%3.2f\t'
% mat = the matrix
% varargin = the column titles

function fid = sprint_mat(format, mat, cols,rows)

ss = size(mat);

%If cols included
if nargin>2
    str = [];
   if nargin>3
       if length(cols)>ss(2)
           str = [str,sprintf('%s\t',cols{1})];
           cols = cols(2:end);
       else
           str = [str, sprintf('\t')];
       end
   end
   
   for cc = 1:ss(2)
      str = [str,' ', cols{cc}, sprintf('\t') ' ']; 
   end
  
   disp(str)
end

for rr = 1:ss(1)
    
    str = [];
    if nargin>3
       str = [str,rows{rr},sprintf('\t')];
    end
    str = [str,sprintf(format,mat(rr,:))]; 
     
    idx = strfind(str,'NaN');
    for ii = 1:length(idx)
       str(idx(ii):idx(ii)+2) = '   '; 
    end
   
    disp(str)
end





