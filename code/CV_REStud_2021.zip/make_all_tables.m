%% Table 1: Fixed Parameters

%load saved
load saved_results/steady_baseline

cols = {'Param', 'Val'};
rows = {'Bet', 'mu_us', 'kap', 'fee', 'nu', 'Xus', 'Xez', 'alph', 'sig', 'veps', 'sigtht','tau'};

table_dat = [bet;mu_us;kap;r;upp_usd;Xus;Xeu;alph;1;vepst;sige^2;tau];

disp('*******************************************************************')
disp('Table 1: ')
disp('*******************************************************************')

sprint_mat('% 1.3f \t',table_dat,cols,rows)
disp(' ')

%% Table 2: Calibrated parameters
load saved_results/steady_baseline
disp(' ')
disp('*******************************************************************')
disp('Table 2:');
disp('*******************************************************************')

table_dat = [[.6;.55;.80;1.1],[GDs(1);TSHRs(3);Xs(3);Prw_eu/Peu_eu]];
disp('2a: ')
cols = {'Cncpt', 'Data','Model'};
rows = {'D/GDP', 'Tr/GDPm', 'USD%', 'IMKP'};
sprint_mat('% 1.3f \t',table_dat,cols,rows)



disp(' ')
disp('2b: ')
cols = {'Param', 'Val'};
rows = {'B', 'ah', 'vepsf', 'phi'};
sprint_mat('% 1.3f \t',[Busd;ah_us;vepsf;phi],cols,rows)
disp(' ')

%% Table 3:
disp(' ');
disp('*******************************************************************')
disp('Table 3:')
disp('*******************************************************************')

%Pane a: Baseline steady-state
load saved_results/steady_baseline.mat
disp('3a:')

cols = {'US', 'EZ', 'RW','US', 'EZ', 'RW','US', 'EZ', 'RW'};
rows = {'Xj','ExPrv','Sein','NFA','GFA','TB'};
table_dat(2,[2,3,5,6,8,9]) = NaN;
sprint_mat('% 1.2f\t',table_dat,cols,rows)

%Panel b: Steady-state with ROW asset

load saved_results/steady_row
disp(' ')
disp('3b:')
cols = {'US', 'EZ', 'RW','US', 'EZ', 'RW','US', 'EZ', 'RW'};
rows = {'ExPrv','NFA','GFA','TB'};
table_dat(2,[2,3,5,6,8,9]) = NaN;
sprint_mat('% 1.2f\t',table_dat,cols,rows)
disp(' ');

%% Table 4: Welfare Comparisons
disp(' ');
disp('*******************************************************************')
disp('Table 4:');
disp('*******************************************************************')

table_dat = NaN(2,3);

%Transition from middle to dollar
load saved_results/steady_baseline cons_steady
cons_ref = cons_steady(:,2); %symmetric baseline cons
table_dat(1,1:3) = cons_steady(:,1); % dollar ss cons

load saved_results/sym_to_dollar_transition.mat cons_equiv
table_dat(2,1:3) = cons_equiv;
table_dat(:,1:3) = 100*(table_dat(:,1:3)./cons_ref'-1);


cols = {'US', 'EZ','RW'};
rows = {'ss', 'trans'};
sprint_mat('% 1.2f\t',table_dat,cols,rows);
disp(' ');

%% Table 5: Welfare under trade war scenarios
disp(' ');
disp('*******************************************************************')
disp('Table 5:')
disp('*******************************************************************')

table_dat = NaN(2,3);
load saved_results/steady_baseline cons_steady
cons_ref = cons_steady(:,1); %symmetric baseline cons

load saved_results/dollar_to_dollar15_transition cons_equiv
table_dat(1,1:3) = cons_equiv;

table_dat(1,1:3) = 100*(table_dat(1,1:3)./cons_ref'-1);

load saved_results/dollar_to_euro15_transition cons_equiv
table_dat(2,1:3) = cons_equiv;

table_dat(2,1:3) = 100*(table_dat(2,1:3)./cons_ref'-1);

cols = {'US', 'EZ','RW'};
rows = {'$Wins', 'EuWins'};
sprint_mat('% 1.2f\t',table_dat,cols,rows);
disp(' ');
%% APPENDIX TABLES
appendix_tables
