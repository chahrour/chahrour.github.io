% SETUP - call before running any of the other programs

clear; %clc;

addpath('auto_generated');
addpath('DSGE_tools');
addpath('mex_tools');

%Timing: use lagged bonds (= 0) or current bonds (= 1)
timing  = 1;

%Include a state variable Xrw
xstate = false;

%endog choice of which country to trade with
endog_ctry = false;

%If country + im/ex are jointly optimal (supercedes above)
endog_all = true;

if endog_ctry && endog_all
    error('You can''t be in two places at once!')
end

%Color palette for plotting
clrs =   [[255,60,0]*.9
    255,120,25
    0 0 0
    [0,  0,255 ]*.9
    0,128,255 ]./255;

clist =   [ [0,  89,255 ]*.9
    [89,255,89]*0.9
    [255,89,0]*.9
    255,120,50        ]./255;

color_usd = .8*[0, 0.2, 1]+.2*[1, 0.5, 0];
color_eur = .2*[0, 0.2, 1]+.8*[1, 0.5, 0];
color_mul = [.9,.9,.9];%.7*[0, 0.2, 1]+.7*[1, 0.5, 0];

color_us  = [   0         0.4470    0.7410]; 
color_eu  = [   0.8500    0.3250    0.0980]; ls_eu = '-.';
color_rw  = [   0.9290    0.6940    0.1250]; ls_rw = '--';

return
%% Open the key files
try
    edit setup
    edit simplify_expressions
    edit steady_solve
    edit calibration_finder
    edit make_all_figures
    edit make_all_tables
    edit shooting_solve
    edit shooting
    
    edit steady_state_finder
    edit global_solve
    edit regions_fancy
    edit flows_fancy
    
catch
    disp('No editor available')
end