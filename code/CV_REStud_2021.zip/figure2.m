%% FIGURE 2: BASELINE - FLIGHT PATH FROM MIDDLE TO DOLLAR SS
load saved_results/steady_baseline cons_steady per_p_year 
load saved_results/sym_to_dollar_transition  *out *use *shrs frac_path cons_equiv

yrs= 50;
max_year = 40;
f2 = figure;
f2.PaperPosition = [.25, .25, 11,8];

xgrid = (0:per_p_year:per_p_year*(yrs-1))/per_p_year;
yidx  = 1:per_p_year:per_p_year*yrs;

s=subplot(3,2,1);

plot(xgrid,100*log(con_out(1,yidx)./cons_steady(1,2)).','linewidth' ,2.5,'Color',color_us); hold on;
plot(xgrid,100*log(con_out(2,yidx)./cons_steady(2,2)).','linewidth' ,2.5, 'Color', color_eu, 'LineStyle',ls_eu); hold on;
plot(xgrid,0*xgrid, ':k');
title('Cons. relative to intial s.s. (%)')
xlabel('years')
s.XLim = [0,max_year];
s.YLim = [-.75,.75];
s.FontSize = 12;

s= subplot(3,2,2);
p1 = plot([-1 -2],[-1,-2],'linewidth' ,2.5,'Color',color_us); hold on;
p2 = plot([-1 -2],[-1,-2],'linewidth' ,2.5,'Color',color_eu,'Linestyle',ls_eu);
p3 = plot(xgrid,usd_use(yidx),'linewidth' ,2.5,'Color',color_rw, 'LineStyle', ls_rw);
title('USD use by RW firms (X_{rw})')
xlabel('years')
s.YLim = [0.5, .9];
s.XLim = [0,max_year];
s.FontSize = 12;
legend('US', 'EZ', 'RW','Location', 'southeast')


s= subplot(3,2,3);
plot(xgrid,ep_out(1,yidx)','linewidth' ,2.5)
title(['r^' char(8364) ' - r^$ (%)'])
xlabel('years')
s.YLim = [0,1.6];
s.XLim = [0,max_year];
s.FontSize = 12;

s=subplot(3,2,4);
plot(xgrid,usd_shrs(1,yidx)','linewidth' ,2.5,'Color',color_us); hold on;
plot(xgrid,usd_shrs(2,yidx)','linewidth' ,2.5,'Color',color_eu,'Linestyle',ls_eu);
plot(xgrid,usd_shrs(3,yidx)','linewidth' ,2.5,'Color',color_rw,'Linestyle',ls_rw);
title('USD bond portfolio share')
xlabel('years')
s.XLim = [0,max_year];
s.FontSize = 12;

s=subplot(3,2,5);
plot(xgrid,nfa_out(1,yidx)','linewidth' ,2.5, 'Color', color_us)
title('US net foreign assets')
xlabel('years')
s.XLim = [0,max_year];
s.FontSize = 12;

s=subplot(3,2,6);
plot(xgrid,nfa_out(2,yidx),'linewidth' ,2.5, 'Color',color_eu,'LineStyle',ls_eu);
title('EZ net foreign assets')
xlabel('years')
s.XLim = [0,max_year];
s.FontSize = 12;

saveas(f2, 'saved_figures/figure2.eps', 'epsc')