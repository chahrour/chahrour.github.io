%% FIGURE 6: US-ROW TRADE WAR AS FCN OF TIME
load saved_results/steady_baseline cons_steady
load saved_results/tmp_tradewar_transition30 Cequiv*
Tmax = length(Cequiv_stay)-1;
ceq_stay = 100*(Cequiv_stay./cons_steady(:,1)-1);
ceq_go   = 100*(Cequiv_go./cons_steady(:,1)-1);

f1 = figure;
f1.PaperPosition = [0 0 11 5];
f1.PaperSize     = [4,10];

s = subplot(1,3,1);
plot(0:Tmax,ceq_stay(1,:), 'linewidth', 2.5); hold on
plot(0:Tmax,ceq_go(1,1:Tmax+1), 'linewidth',2.5, 'LineStyle', ls_eu);
s.YLim = [-4,1];
s.XLim = [1,40];
s.XTick = [1, 10, 20, 30, 40]; 
s.YTick = [-4,-3,-2,-1,0,1,2];
s.FontSize = 12; 
title('US');

legend('Dollar in long run', 'Euro in long run');
xlabel('years');
ylabel('cons. equivalent');

s = subplot(1,3,2);
plot(0:Tmax,ceq_stay(2,:), 'linewidth', 2.5); hold on
plot(0:Tmax,ceq_go(2,1:Tmax+1), 'linewidth',2.5, 'LineStyle', ls_eu);
s.YLim = [-4,1];
s.YTick = [-4,-3,-2,-1,0,1,2];
s.XLim = [1,40];
s.XTick = [1, 10, 20, 30, 40]; 
s.FontSize = 12; 
xlabel('years');
ylabel('cons. equivalent');
title('EZ');

s = subplot(1,3,3);
plot(0:Tmax,ceq_stay(3,:), 'linewidth', 2.5); hold on
plot(0:Tmax,ceq_go(3,1:Tmax+1), 'linewidth',2.5, 'LineStyle', ls_eu);
s.YLim = [-4,1];
s.YTick = [-4,-3,-2,-1,0,1,2];
s.XLim = [1,40];
s.XTick = [1, 10, 20, 30, 40]; 
s.FontSize = 12; 
xlabel('years');
ylabel('cons. equivalent');
title('RW');

saveas(f1, 'saved_figures/figure6.eps', 'epsc');

