#include <math.h>
#include <mex.h>
#include <lapack.h>
#include <blas.h>
#include <stdlib.h>
#include <string.h>


#if !defined(MAX)
#define	MAX(A, B)	((A) > (B) ? (A) : (B))
#endif

#if !defined(MIN)
#define	MIN(A, B)	((A) < (B) ? (A) : (B))
#endif

#define pi  3.141592653589793
        
/* Prints an MxN matrix to Screen*/
void printmat_rowmaj(int m, int n, double M[m*n]){
    int x,y,k;
        k = 0;
    printf("\n");
    for(x=0;x<m;x++){
        for(y=0;y<n;y++){
            printf("%1.11lf\t", M[k]);
            k++;
        }
        printf("%\n");
    }
    return;
}


void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] )

{

    /*Check for proper number of arguments*/
    if (nrhs == 15)  {} else{mexErrMsgTxt(" 15 inputs arguments required.");}
        
    if (nlhs == 2)  {} else{mexErrMsgTxt(" 2 inputs arguments required.");}

            
    
    /*declare scalar input args*/
    double x1_1,x2_1,x3_1,x1_2,x2_2,x3_2,x1_3,x2_3,x3_3,y1_1,y2_1,y1_2,y2_2,y1_3,y2_3;
x1_1= mxGetScalar(prhs[0]);
x2_1= mxGetScalar(prhs[1]);
x3_1= mxGetScalar(prhs[2]);
x1_2= mxGetScalar(prhs[3]);
x2_2= mxGetScalar(prhs[4]);
x3_2= mxGetScalar(prhs[5]);
x1_3= mxGetScalar(prhs[6]);
x2_3= mxGetScalar(prhs[7]);
x3_3= mxGetScalar(prhs[8]);
y1_1= mxGetScalar(prhs[9]);
y2_1= mxGetScalar(prhs[10]);
y1_2= mxGetScalar(prhs[11]);
y2_2= mxGetScalar(prhs[12]);
y1_3= mxGetScalar(prhs[13]);
y2_3= mxGetScalar(prhs[14]);

         
  
    /*Create output arguments*/
    plhs[0] = mxCreateDoubleMatrix(3,3,mxREAL);
plhs[1] = mxCreateDoubleMatrix(1,1,mxREAL);

    double *tmp1,*tmp2;
tmp1= mxGetPr(plhs[0]);
tmp2= mxGetPr(plhs[1]);

    

tmp1[0] = (2.0*(x2_2*x3_3 - x2_3*x3_2))/(x1_2*x2_3 - x1_3*x2_2 + 2.0*x1_1*x2_2*x3_3 - 2.0*x1_1*x2_3*x3_2 - 2.0*x1_2*x2_1*x3_3 + 2.0*x1_2*x2_3*x3_1 + 2.0*x1_3*x2_1*x3_2 - 2.0*x1_3*x2_2*x3_1);
tmp1[1] = (x2_3 - 2.0*x2_1*x3_3 + 2.0*x2_3*x3_1)/(x1_2*x2_3 - x1_3*x2_2 + 2.0*x1_1*x2_2*x3_3 - 2.0*x1_1*x2_3*x3_2 - 2.0*x1_2*x2_1*x3_3 + 2.0*x1_2*x2_3*x3_1 + 2.0*x1_3*x2_1*x3_2 - 2.0*x1_3*x2_2*x3_1);
tmp1[2] = -(x2_2 - 2.0*x2_1*x3_2 + 2.0*x2_2*x3_1)/(x1_2*x2_3 - x1_3*x2_2 + 2.0*x1_1*x2_2*x3_3 - 2.0*x1_1*x2_3*x3_2 - 2.0*x1_2*x2_1*x3_3 + 2.0*x1_2*x2_3*x3_1 + 2.0*x1_3*x2_1*x3_2 - 2.0*x1_3*x2_2*x3_1);
tmp1[3] = -(2.0*(x1_2*x3_3 - x1_3*x3_2))/(x1_2*x2_3 - x1_3*x2_2 + 2.0*x1_1*x2_2*x3_3 - 2.0*x1_1*x2_3*x3_2 - 2.0*x1_2*x2_1*x3_3 + 2.0*x1_2*x2_3*x3_1 + 2.0*x1_3*x2_1*x3_2 - 2.0*x1_3*x2_2*x3_1);
tmp1[4] = -(x1_3 - 2.0*x1_1*x3_3 + 2.0*x1_3*x3_1)/(x1_2*x2_3 - x1_3*x2_2 + 2.0*x1_1*x2_2*x3_3 - 2.0*x1_1*x2_3*x3_2 - 2.0*x1_2*x2_1*x3_3 + 2.0*x1_2*x2_3*x3_1 + 2.0*x1_3*x2_1*x3_2 - 2.0*x1_3*x2_2*x3_1);
tmp1[5] = (x1_2 - 2.0*x1_1*x3_2 + 2.0*x1_2*x3_1)/(x1_2*x2_3 - x1_3*x2_2 + 2.0*x1_1*x2_2*x3_3 - 2.0*x1_1*x2_3*x3_2 - 2.0*x1_2*x2_1*x3_3 + 2.0*x1_2*x2_3*x3_1 + 2.0*x1_3*x2_1*x3_2 - 2.0*x1_3*x2_2*x3_1);
tmp1[6] = (2.0*(x1_2*x2_3 - x1_3*x2_2))/(x1_2*x2_3 - x1_3*x2_2 + 2.0*x1_1*x2_2*x3_3 - 2.0*x1_1*x2_3*x3_2 - 2.0*x1_2*x2_1*x3_3 + 2.0*x1_2*x2_3*x3_1 + 2.0*x1_3*x2_1*x3_2 - 2.0*x1_3*x2_2*x3_1);
tmp1[7] = -(2.0*(x1_1*x2_3 - x1_3*x2_1))/(x1_2*x2_3 - x1_3*x2_2 + 2.0*x1_1*x2_2*x3_3 - 2.0*x1_1*x2_3*x3_2 - 2.0*x1_2*x2_1*x3_3 + 2.0*x1_2*x2_3*x3_1 + 2.0*x1_3*x2_1*x3_2 - 2.0*x1_3*x2_2*x3_1);
tmp1[8] = (2.0*(x1_1*x2_2 - x1_2*x2_1))/(x1_2*x2_3 - x1_3*x2_2 + 2.0*x1_1*x2_2*x3_3 - 2.0*x1_1*x2_3*x3_2 - 2.0*x1_2*x2_1*x3_3 + 2.0*x1_2*x2_3*x3_1 + 2.0*x1_3*x2_1*x3_2 - 2.0*x1_3*x2_2*x3_1);
tmp2[0] = 1.0 - erfc((pow(2.0,1.0/2.0)*y1_1)/2.0)/2.0;
        
      
                            
                  
}




