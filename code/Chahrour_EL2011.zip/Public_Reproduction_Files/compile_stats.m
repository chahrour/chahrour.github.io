% COMPILE_STATS - Compile stats from series filtered via multiple filteres
%
% usage:
%
% outfile = compile_stats(file_list, param)
%
% where 
% 
% file_list =  a cell_array containing the .mat files with the price objects
%            that met standards for inclusion.
% param = an object with parameters for the statistics, see make_all.m for
%         options.
%
% outfile = a

function outfile = compile_stats(file_list, params)

outfile = [params.save_kind '_' params.med_alg '_' num2str(params.mobs) '_' num2str(params.skip_per) '_' num2str(params.J) '_' num2str(params.K)];
n_file = length(file_list);

%Compute price-change hazard function for how many period from last price
%change (this procedure is not fully debugged, and the figure does not
%appear in the paper).
n_p = 25;

disp(' ');
disp('Compiling statistics:');

for j = 1:n_file


    %Get stat names (based on variable names in price_statistics) and the
    %filter list
    stat_list = {'per_at_ref', 'frac_rev', 'stddev', 'd_stddev', 'per_above_ref', 'per_below_ref', ...
        'mag_above', 'mag_below', 'per_change', 'per_up', 'per_down', 'nobs', 'ntot'};
    filter_list = {'none', 'NS', 'Mid', 'EJR', 'RAC'};

    if j==1 && strcmp(params.med_alg, 'median')
        for ii = 1:length(stat_list)
            for kk = 1:length(filter_list)
                str = [stat_list{ii} '_' filter_list{kk}, '= [];'];
                eval(str);
            end
        end
    end

    out = get_stats(file_list{j}, filter_list, params);
        
    %Calculate product group medians
    for ii = 1:length(stat_list)
        
        
        for kk = 1:length(filter_list)
            switch(params.med_alg)
                case('median-median')
                    str1 = [stat_list{ii} '_' filter_list{kk}, '(j,1) = median(non_nan(out.', filter_list{kk},'.', stat_list{ii}, '));'];
                    str2 = [stat_list{ii} '_' filter_list{kk}, '_g(j,1) = median(non_nan(out.', filter_list{kk},'.', stat_list{ii}, '));'];
                case('weighted_median')
                    str1 = [stat_list{ii} '_' filter_list{kk}, '(j,1) =  weighted_median (out.', filter_list{kk},'.', stat_list{ii},', out.none.exp_shr', ');'];
                    str2 = [stat_list{ii} '_' filter_list{kk}, '_g(j,1) =  weighted_median (out.', filter_list{kk},'.', stat_list{ii},', out.none.exp_shr', ');'];
                case('median')
                    str1 = [stat_list{ii} '_' filter_list{kk}, '= [' stat_list{ii} '_' filter_list{kk}, '; non_nan(out.', filter_list{kk},'.', stat_list{ii}, ')''];'];
                    str2 = [stat_list{ii} '_' filter_list{kk}, '_g(j,1) = median(non_nan(out.', filter_list{kk},'.', stat_list{ii}, '));'];
            end
            eval(str1);
            eval(str2);
        end
    end
    
    
    
%     %Compute prob of price increase for each # of days since sale 
%     for kk = 1:length(filter_list)
% 
%         eval(['temp = out.', filter_list{kk},  ';']);
%         
%         %Preallocate space for speed
%         n_obs = length(out.RAC.up);
%         ni_obs = zeros(n_obs+1,1);
%         for ll = 1:n_obs
%             ni_obs(ll+1) = length(temp.nd_since{ll});
%         end
%         ni_obs= cumsum(ni_obs);
%         nd_since = nan(ni_obs(end),1);
%         up = nd_since;
%         down = nd_since;
% 
%         
%         %Stack all the change/days since sale obs
%         for ll = 1:length(out.RAC.up)
%                         nd_since((ni_obs(ll)+1):ni_obs(ll+1)) = temp.nd_since{ll};
%                         up((ni_obs(ll)+1):ni_obs(ll+1)) = temp.up{ll};
%                         down((ni_obs(ll)+1):ni_obs(ll+1)) = temp.down{ll};
%         end
% 
%         %Compute probabilties in a crude way
%         uniq = unique(nd_since);
%         pup = nan(n_p,1);
%         pdwn = nan(n_p,1);
%         n = pdwn;
%         for ll = 1:n_p
%             idx = (nd_since == uniq(ll));
%             n(ll) = sum(idx);
%             pup(ll) = sum(up(idx))/sum(idx);
%             pdwn(ll) = sum(down(idx))/sum(idx);
%         end
%          
%         %Store results
%         eval(['prob_ups.', filter_list{kk}, '(:,j) = pup;']);
%         eval(['prob_dwn.', filter_list{kk}, '(:,j) = pdwn;']);
%     end
    

end

savex(outfile, 'out');




%*****************************************************************
% GET_STATS - Use "eval" command to get stats for a list of files.
%*****************************************************************
function out = get_stats(file, filter_list, params)

file_dat = [params.data_dir file, '_', params.save_kind, '_', num2str(params.mobs), '.mat'];
file_stat = [params.data_dir file, '_', params.save_kind, '_', num2str(params.mobs), '_',num2str(params.skip_per), '_stat.mat'];    

if params.recompile_stats || ~exist(file_stat)
    disp(['Recompiling statistics from: ', file_dat]);
    eval(['load ', file_dat]);


    for kk = 1:length(filter_list)
        eval(['out.', filter_list{kk}, ' = price_statistics(keep_products, filter_list{kk}, params);']);
    end
    eval(['save ', file_stat, ' out']);
else
    disp(['Using saved statistics from: ', file_stat]);
    eval(['load ', file_dat]);
    eval(['load ', file_stat]);
end
    
%*****************************************************************
% NON_NAN - Get non-NaN values from a vector or matrix
%*****************************************************************
   
function out = non_nan(data)

out = data( ~isnan(data));




%*****************************************************************
% WEIGHTED_MEDIAN
%*****************************************************************
  
function out = weighted_median(vals,wght)

%Drop nans
nnan = ~isnan(vals);

if sum(nnan) == 0;
    out = NaN;
    return;
end

vals = vals(nnan);
wght  = wght(nnan);

%Sort things
[sorted_vals,b] = sort(vals);
sorted_exp = wght(b);


cum_exp = cumsum(sorted_exp);
sorted_exp >= cum_exp/2;
median_idx = find(cum_exp >= cum_exp(end)/2,1);

out = sorted_vals(median_idx);

