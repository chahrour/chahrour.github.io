% EXTRACT_AND_SAVE: Load the original Dominicks data files.
% Creates price objects for use with these programs, dropping those with
% too many missing observations.
%
% usage:
%
% extract_and_save(file_list, params)
%
% where
%
% file_list = cellarray of file names to load and save
% params = see make_all.m for relevant options
%
%

function extract_and_save(file_list, params)

disp('Creating and saving files:');
for j = 1:length(file_list)
    load_dom_data(file_list{j}, params);
end



%********************************************************************
% LOAD_DOM_DATA - Subfunction for loading data for a particular file.
%********************************************************************

function load_dom_data(file, params)

%Use this for a test run excluding huge numbers of obersvations
max_obs = params.max_obs;

%The _all files have every price series in the dataset already in the
%appropriate object format for this.  The summary files contain only
%"valid" observations; suffixes describe how observations have been excluded.
outfile_all = [params.data_dir, file, '_all.mat'];
outfile_sum = [params.data_dir, file, '_', params.save_kind, '_', num2str(params.mobs), '.mat'];



if exist(outfile_sum, 'file') && ~params.redo_sum
    %File excluding "invalid observations" exists, do nothing
    disp(['Using saved summary file: ' outfile_sum]);
    return


elseif (exist(outfile_all, 'file') && ~exist(outfile_sum, 'file')) || params.redo_sum

    %The _full.mat file exsits, but not the summary file
    disp (['Using saved full observations file: ', outfile_all]);
    load(outfile_all);

else

    %Must generate the _full.mat files from the flat (column matrix) .mat
    %files

    eval(['load ', params.data_dir, file, '.mat'])
    data = data(~isnan(data(:,1)),:);

    %Create Product-Store Structures
    j = 1;
    ii = 1;
    kk = 1;

    %Make a general product object
    product.store = 1;
    product.upc = 1;
    product.weeks = 1;
    product.price = 1;
    product.exp = 1;
    product.bundle = 1;
    product.ok = 1;

    %Some inconsistencies in the col defs of the data
    if strcmp(file, 'wtti') || strcmp(file, 'wptw')
        p_idx = 5;
        bndl_idx = 6;

    else
        p_idx = 6;
        bndl_idx = 5;
    end


    %Initial product
    p = product;
    products = {};
    products = cell(100000,1);
    while j < length(data) && kk < max_obs

        if data(j,2) ~= p.store || data(j,1) ~= p.upc

            %save old product, putting in NaN where there are missing values
            weeks_temp = p.weeks;
            price_temp = p.price;
            exp_temp = p.exp;
            p.weeks = 1:weeks_temp(end);
            p.price = NaN*p.weeks;
            p.exp = 0*p.weeks;
            p.price(weeks_temp) = price_temp;
            p.price(p.price == 0) = NaN;
            p.price(p.ok~=1) = NaN; %Ditch the "garbage"
            p.exp(weeks_temp) = exp_temp;
            p.rows(2)  = j-1;
            products{kk} = p;

            %New product
            kk = kk+1;
            p = product;
            p.store = data(j,2);
            p.upc = data(j,1);
            p.id = kk;
            p.rows(1) = j;
            ii = 1;
        end

        %Storeing each obs for the product
        p.bundle(ii) = data(j, bndl_idx);
        p.price(ii) = data(j,p_idx)/p.bundle(ii);
        p.weeks(ii) = data(j,3);
        p.exp(ii) = sum(data(j,4).*p.price(ii)/p.bundle(ii));  %Weird way of getting quantity
        p.ok(ii) = data(j,8);
        j = j+1;
        ii = ii+1;
    end

    %Drop the initial blank obs
    %size(products)
    products = products(2:kk-1);
    keep_products = {};

    %Save the full list of products
    eval(['save ', params.data_dir, file,'_all  products']);
end



%**************************************************************************
% Given a file with every observation, filter for valid series according to
% selected criterion
%**************************************************************************


switch params.save_kind

    case( '100obs')
        %Require 100 Observations to be included

        kk = 1;
        for jj = 1:length(products)
            if sum(~isnan(products{jj}.price)) > 100
                keep_products{kk} = products{jj};
                kk = kk+1;
            end
        end

    case( 'EJR')
        %Permit up to a certain number of missing observations in a
        %quarter

        kk = 1;
        tot_exp = 0;

        %Min OBS for  EJR save
        min_obs = 13 - params.mobs;

        %Save products with relatively full histories
        for jj = 1:length(products)
            temp = keep_EJR(products{jj}, min_obs);
            tot_exp = tot_exp + sum(temp.exp);
            if temp.nq > 5
                keep_products{kk} = temp;
                kk = kk+1;
            end
        end

        %Get expenditure shares
        for kk = 1:length(keep_products)
            keep_products{kk}.exp_shr = sum(keep_products{kk}.exp)/tot_exp;
        end

    case( 'no_mobs')

        %Keep the PORTION OF THE SERIES with no missing observations
        %for a certain period
        kk =1 ;
        tot_exp = 0;
        for jj = 1:length(products)
            [a,b] = find_nNaN(products{jj}.price);

            if max(a) > 75
                [waste, idx] = max(a);
                t_product = products{jj};
                %t_product.price = str{idx};
                t_product.price = products{jj}.price(b(idx,1):b(idx,2));
                t_product.weeks = products{jj}.weeks(b(idx,:));
                tot_exp = tot_exp + sum(t_product.exp);
                keep_products{kk} = t_product;
                kk = kk+1;
            end
        end

        for kk = 1:length(keep_products)
            keep_products{kk}.exp_shr = sum(keep_products{kk}.exp)/tot_exp;
        end

    otherwise
        error('Inavlid keep style');
end


disp ([num2str(length(keep_products)), ' observations saved in ' outfile_sum]);
eval(['save ', outfile_sum, '  keep_products']);






%***********************************************************************
%KEEP EJR - Find longest sequence with at least min_obs valid observations in
%each quarter.
%************************************************************************
function prod = keep_EJR(prod, min_obs)

end_wk = prod.weeks(end);

%Bracket each quarter
quarters = [1:13:end_wk]';
t = length(prod.price);
valid_q = 0*quarters;

%For each quarter determine if valid
for j = 1:size(quarters,1)
    q_dat = prod.price(quarters(j):min(t, quarters(j)+12));
    obs = sum(~isnan(q_dat));
    valid_q(j) = obs>=min_obs;
end

[ct,idx] = find_nzero_seq(valid_q);
if isempty(idx)
    prod.nq = 0;
else
    [lgth, max_idx] = max(ct);
    start_pt = quarters(idx(max_idx,1));
    end_pt = min(t,quarters(idx(max_idx,2))+12);

    prod.weeks = [start_pt, end_pt];
    prod.price =  prod.price(start_pt:end_pt);
    prod.exp =  prod.exp(start_pt:end_pt);
    prod.nq = lgth;
end


%***********************************************************************
%FIND_NNAN_PRICE - Finds the non-NaN sequences
%***********************************************************************

function [str_size, str_idx] = find_nNaN(data)

nzd = ~isnan(data);
idx1 = find((nzd - [0, nzd(1:end-1)])>0);
idx2 = find(([nzd(2:end) 0] - nzd)<0);

str_size = (1+idx2)-idx1;
str_idx = [idx1', idx2'];



%***********************************************************************
%FIND_NZERO_SEQ - Find the nonzero sequences
%***********************************************************************

function [str_size, str_idx] = find_nzero_seq(data)

nzd = data'~=0;
idx1 = find((nzd - [0, nzd(1:end-1)])>0);
idx2 = find(([nzd(2:end) 0] - nzd)<0);

str_size = (1+idx2)-idx1;
str_idx = [idx1', idx2'];


    