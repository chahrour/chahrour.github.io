function out = medianc(varargin)

nc = length(varargin);
out = zeros(1,nc);
for j = 1:length(varargin)
    out(j) = median(varargin{j});
end
