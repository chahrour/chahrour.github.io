function sample_products(file, params,n)


file_dat = [params.data_dir file, '_', params.save_kind, '_', num2str(params.mobs), '.mat'];
eval(['load ', file_dat]);


nn = length(keep_products);


idx = ceil(nn*rand(n,1));

for j = 1:n
  disp(['Product #',  num2str(idx(j))]);
  f = price_figure(keep_products{idx(j)}, 'Tester', params,0);
  pause
  close(f)
end
