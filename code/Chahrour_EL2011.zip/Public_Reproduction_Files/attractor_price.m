% ATTRACTOR_PRICE: Computes the attractor price according to algorithm
% described in Chahrour, "Sales and Price Spikes in Retail Scanner Data"
%
% usage
%
% attr_price = attractor_price(dat, freq)
%
% where
%
% dat = the price series to be filtered
% freq = the window width. Can only support a odd window length (for
%        symmetry)
%
% attr_price = the filtered attactor price


function  attr_price = attractor_price(dat, param)

freq = param.freq;

%Easier to use freq-1 throughout, window is still the inputed width
freq = freq-1;

%Sample length
T = length(dat);

%Initialize attractor price
attr_price = NaN(T,1);

%Some Counters
vals = unique(dat);
counter2 = 0*vals;

%Intial Window
bnds = [1, freq/2];

for t = 1:T

    

    %*******************************************************************
    % FIRST PASS:
    % Use a rolling window to get "candidate" attractor price.
    %*******************************************************************


    %Roll the window forward 1 period, considering that we may be at
    %the beginning or end of the sample.
    old_bnd = bnds;

    if bnds(2)-bnds(1)<freq && bnds(2)<T
        %Starting period
        bnds(2) = bnds(2)+1;
    elseif bnds(2) == T
        %End Period
        bnds(1) = bnds(1)+1;
    else
        %Middle Period
        bnds = bnds+1;
    end



    % FIND MOST COMMON PRICE (MODE) IN WINDOW


    %NEW METHOD:
    %Update the mode with the elements that have changed - much faster way to compute
    %mode in each window

    %Get data in window
    q_dat = dat(bnds(1):bnds(2), :);

    %Minimun number of observations
    min_obs = freq/2+1;%max([freq/2+1,length(q_dat) - param.mobs]);
    
    
    %For first period...

    %Establish the number of times each value appears in the first window
    if t == 1
        counter2 =0*vals;
        for k = 1:size(counter2,1)
            counter2(k) = sum(q_dat == vals(k));
        end
        counter2 = counter2(~isnan(vals));
        vals = vals(~isnan(vals));
    end

    %For subsequent periods...

    %Subtract the item that fell out of window
    if bnds(1) > 1
        m_idx = vals == dat(bnds(1)-1);
        counter2(m_idx) = counter2(m_idx)-1;
    end

    %Add the new item to counter
    if  t > 1 && old_bnd(2) < T
        p_idx = vals ==dat(bnds(2));
        counter2(p_idx) = counter2(p_idx)+1;
    end

    %If too many missing obs, skip ahead, otherwise check for ties
    if sum(~isnan(q_dat)) < min_obs
        attr_price(t) = NaN;
        continue
    else
        
        %Find mode and check for tie
        [max_occur, max_value] = max(counter2);
        max_idx = counter2 == max_occur;
        n_argmax = sum(max_idx);
        
        if n_argmax >1
            %Break Ties
            win_tie = find(max(row_eq(ones(n_argmax,1)*q_dat', vals(max_idx))),1);
            attr_price(t) = q_dat(win_tie);
        else
            %Mode in window
            attr_price(t) = vals(max_value);
        end
    end


    

    %******************************************************************
    % TRANSITIONS:
    % Refine attractor according to the various cases
    %******************************************************************

    if t > 1 && (attr_price(t) ~= attr_price(t-1)) && ~isnan(attr_price(t-1))

        old = attr_price(t-1);
        new = attr_price(t);

        %Find first and last occurence of new price
        first_occur = bnds(1) -1 + find(q_dat == new,1);
        last_occur = find(dat(1:bnds(2)) == old);
        last_occur = last_occur(end);


        if last_occur >= t && first_occur > t

            % CASE A:
            % Transistion occurs too soon.
            attr_price(t) = old;


            %disp(['A', num2str(t)]);
        elseif last_occur<t && first_occur < t && last_occur<first_occur

            % CASE B:
            % Transition occurs too late.
            attr_price(last_occur+1:t-1) = new;

            
            %disp(['B', num2str(t)]);

        elseif last_occur>= first_occur

            % CASE C:
            % New and old prices overlap, pick the price that occurs
            % most often in the period of overlap.

            q_dat = dat(first_occur:last_occur, :);
            n_obs = size(q_dat,1);
            counter =zeros(1, n_obs);
            for k = 1:n_obs
                counter(k) = sum(q_dat(k)==q_dat);
            end

            [rf_count, ref_idx] = max(counter);
            attr_price(first_occur:last_occur) = q_dat(ref_idx);

            %disp(['C', num2str(t)]);
        else

            % CASE D:
            % Period where non-ref price movement obscures true attractor price at
            % a transition.  Place transition at first pt when price is closer to
            % new attactor than old.

            q_dat = dat(last_occur:first_occur, :);


            m4_idx = find( abs(q_dat-new) < abs(q_dat-old) ,1);
            attr_price(last_occur:last_occur+m4_idx-2) = old;
            attr_price(last_occur+m4_idx-1:first_occur) = new;
            
            %disp(['D', num2str(t)]);
        end
    end
end

if param.drop_ends == 1
    attr_price([1:(param.freq-1)/2, (end-(param.freq-1)/2+1):end]) = NaN;
end

%********************************************
%ROW_EQ - Utility Function
%********************************************
function out = row_eq(mat, col)

col_mat = col*ones(1,size(mat,2));
out = mat == col_mat;
