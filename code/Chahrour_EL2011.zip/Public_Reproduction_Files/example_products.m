%EXAMPLE_PRODUCTS - Make product-figures shown in the paperls


%County Line Coby Jack
eval(['load ', params.data_dir, 'wche_EJR_1']);
price_figure(keep_products{351}, 'Cheese',params, 1)

%Miller Genuine Draft 6-Pck
eval(['load ', params.data_dir, 'wber_EJR_1']);
price_figure(keep_products{843}, 'Beer',  params,0)

