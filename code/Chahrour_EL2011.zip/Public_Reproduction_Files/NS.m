function new_dat = NS(orig, param)

dat = orig;


%Parameters
L = param.L;%4;
K = param.K;%4;
J = param.J;%6;

%Initialize
np = length(dat);
new_dat = 0*dat;
new_dat(1) = dat(1);
for j = 2:length(dat)
    idx = [];
    %All te special info I need to do the if statement
    setA = dat(min(j+1,np):min(j+J, np));
    idx = find(new_dat(j-1) == setA);  %The first time r_t-1 shows up again


    setB = [dat(j: min(j+L, np))];
    [pmax, tmax] = max(setB);

    setC = dat(j+tmax:min(j+tmax-1+L, np));


    %Steps 0 & 1
    if dat(j) >= new_dat(j-1)
        new_dat(j) = dat(j);

        %Step 2
    elseif ~isempty(idx) && (sum(dat(j:j+idx(1)) > new_dat(j-1)) == 0)
        new_dat(j) = new_dat(j-1);

        %Step 3
    elseif length(unique(setB)) >=K
        new_dat(j) = dat(j);

        %Step 4
    elseif ~isempty(find(pmax == setC))
        new_dat(j) = pmax;

        %Step 5
    else
        new_dat(j) = dat(j);
    end
end

if param.drop_ends == 1
    new_dat([1:(param.freq-1)/2, (end-(param.freq-1)/2+1):end]) = NaN;
end
