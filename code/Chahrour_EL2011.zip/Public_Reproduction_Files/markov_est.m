%Estimate Markov Chain
 
function markov = markov_est(price, ref_price, chg_idx);
    nd = sum(chg_idx>0);

    %For estimating Markov Chain, under EJR ref
    ref_ref = 0;
    ref_non = 0;
    non_ref = 0;
    non_non = 0;
    for kk = 1:nd
        %ref_price
        if price(chg_idx(kk)-1) == ref_price(chg_idx(kk)-1) && price(chg_idx(kk))== ref_price(chg_idx(kk))
            % Reference to Reference
            ref_ref = ref_ref+1;
        elseif  price(chg_idx(kk)-1) == ref_price(chg_idx(kk)-1) && price(chg_idx(kk))~= ref_price(chg_idx(kk))
            % Reference to Non-reference
            ref_non = ref_non+1;
           
        elseif price(chg_idx(kk)-1) ~= ref_price(chg_idx(kk)-1) && price(chg_idx(kk))== ref_price(chg_idx(kk))
            % Non-Reference to reference
            non_ref = non_ref+1;
            
        elseif  price(chg_idx(kk)-1) ~= ref_price(chg_idx(kk)-1) && ~price(chg_idx(kk))~= ref_price(chg_idx(kk))
            % Non-Reference to Non-reference
            non_non = non_non+1;
        end
          
    end
    p_rr = ref_ref/(ref_ref+ref_non);
    p_rn = ref_non/(ref_ref+ref_non);
    p_nn = non_non/(non_non + non_ref);
    p_nr = non_ref/(non_non + non_ref);
    markov = [p_rr p_rn; p_nr p_nn];