%Master File for all the steps of making the figures

addpath(genpath([cd, '/latex/']))

params.save_kind = 'EJR';                 %Select sample based on # of missing obs per EJR quarter
params.mobs = 1;                          %# of missings obs permitted per EJR quarter
params.med_alg = 'median-median';         %'median', 'weighted_mediam' (by expenditure)
params.max_obs = inf;                     %Set to a number like 100 to test_run code
params.data_dir = [cd_parent(3), 'scanner_data/data_files/'];   %Directory where datafiles are stored
params.redo_sum = false;                  %Redo the summary file (exclusion of observations w/ missing values)
params.recompile_stats = true;            %Recompile category statistics from scratch?
params.dest_dir = [cd_parent, 'tester/']; %Where to save figures, etc
params.drop_ends = 0;                     %Drop partial EJR Quarters

%List of files to include
file_list = {'wana', 'wbat','wtti', 'wber', 'wbjc', 'wcso','wtna','wcer', 'wche', 'wcig',  'wcoo', ...
    'wcra', 'wdid', 'wfsf','wfec', 'wfrd','wfre', 'wfrj',  'wgro', ...
    'wlnd', 'woat', 'wptw', 'wrfj','wsha', 'wsna', ...
    'wsoa', 'wsdr','wtbr',  'wtpa',  };




file_desc = {'Analgesics', 'Bath Soap', 'Bathroom Tissues', 'Beer', 'Bottled Juices', 'Canned Soup', ...
             'Canned Tuna', 'Cererals', 'Cheeses', 'Cigarettes', 'Cookies', 'Crackers', 'Dish Detergent',...
             'Fabric Softeners', 'Front-End Candies', 'Frozen Dinners', 'Frozen Entrees', 'Frozen Juices', ...
             'Grooming Products', 'Laundry Detergents', 'Oatmeal', 'Paper Towels', 'Refrigerated Juices', ...
             'Shampoos', 'Snack Crackers', 'Soaps,' ,'Soft Drinks', 'Toothbrushes', 'Toothpastes'};
         
%Try with these first!
file_list = {'wana', 'wbat', 'wtti'};  
file_desc = {'Analgesics', 'Bath Soap', 'Bathroom Tissues'};

%Load all the data (takes a long time!)
extract_and_save(file_list, params);


%****************************************
% WEEKLY VERSION
%*****************************************
params.L = 4;
params.K = 4;
params.J = 6;
params.freq = 13;
params.skip_per = 1;



%Calculate statistics and save the results (saving occurs inside of compile_stats!)
outfile = compile_stats(file_list, params);

%Make figures
make_tables(outfile, file_desc, params)

%The example products from the paper
%example_products

%*******************************************
% MONTHLY VERSION
%*******************************************
% params.L = 2;
% params.K = 2;
% params.J = 2;
% params.freq = 5;

params.L = 1;
params.K = 1;
params.J = 2;
params.freq = 5;
params.skip_per = 4;

%Calculate statistics and save the results (saving occurs inside of compile_stats!)
outfile = compile_stats(file_list, params);

%Make figures
make_tables(outfile, file_desc, params)
