function [out,idx] = week2month(dat,param)

nt = length(dat);

idx = 1:4:nt;

for j = 1:3
    nans = find(isnan(dat(idx)));
    
    idx(nans) = idx(nans)+1;
    if idx(end) > nt
        idx = idx(1:end-1);
    end
end

%Drop partial EJR periods
ntm = length(idx);
idx = idx(1:param.freq*floor(ntm/param.freq));

out = dat(idx)';
