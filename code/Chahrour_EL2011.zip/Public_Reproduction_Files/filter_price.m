% FILTER_PRICE:  Filter prices according to various procedures
%
% usage
%
% [attr_price,dat] = filter_price(dat, method, figure(optional))
%
% where
%
% dat = the series to be filtered
% method = 'NS' - Nakamura-Steinsson sale filter
%          'Mid' - Midgrigan/Neilson sales filter
%          'EJR' - Eichenbaum, Jaimovich, Rebelo reference price filter
%          'RAC' - Chahrour Price Filter
%
% attr_price = filtered price series
% dat = unfiltered price series

function  [attr_price,dat] = filter_price(dat, method, param)



%Which filter do you want?
if strcmp('none', method)
    attr_price = dat;
    if param.drop_ends == 1
        attr_price([1:(param.freq-1)/2, (end-(param.freq-1)/2+1):end]) = NaN;
    end
elseif strcmp('Mid', method)
    attr_price = Neilsen_MK(dat, param);
elseif strcmp('NS', method)
    attr_price = NS(dat, param);
elseif strcmp('EJR', method);
    attr_price = reference_price(dat, param);
elseif strcmp('RAC', method)
    attr_price = attractor_price(dat, param);
else
    error('Invalid price filter method');
end

%Put NaN when not actual price is observed
attr_price(isnan(dat)) = NaN;

