% REFERENCE_PRICE - Computes the reference price based on Eichenbuam,
% Jaimovich and Rebelo, "Reference Prices and Nominal Regidities."
%
%
% usage:
%
% ref_price = reference_price(dat, freq)
%
% where
% 
% dat = a price series to be filtered
% freq = the window-width to use for the reference price period
%
% ref_price = the filtered reference price series
%
%
%
% NOTES: It is not clear from the paper whether the they use a calendar
% definition of quarters, or simply break the series in to 13-week periods.
% For simplicity, this program does the latter. This also reduces the
% number of partial quarters for which a reference price is computed.
function ref_price = reference_price(dat, param);

freq = param.freq;   %Length of Quarter Window
mobs = param.mobs;   %Permissible Missing Obs

%Intialize Ref_price
ref_price = NaN*0*dat;

%Number of period
T = length(dat);

for j = 1:freq:T
    
    q_dat = dat(j:min(j+freq-1, T), :);
    
    if sum(~isnan(q_dat)) < (freq-mobs)
         %Throw out quarters w. more than 1 missing observation
        ref_price(j:j + freq-1,:) = NaN;
    else
        %Count the number of times each price appears
        nc = length(q_dat);
        counter = zeros(1,nc);
        for k = 1:nc
            counter(k) = sum(q_dat(k) == q_dat); 
        end
        %Take the most often observed price
        [rf_count, ref_idx] = max(counter);
        ref_price(j:j + freq-1) = q_dat(ref_idx);
    end
end

%Truncate if last period is a partial quarter
ref_price = ref_price(1:T);



if param.drop_ends == 1
    ref_price([1:(param.freq-1)/2, (end-(param.freq-1)/2+1):end]) = NaN;
end




