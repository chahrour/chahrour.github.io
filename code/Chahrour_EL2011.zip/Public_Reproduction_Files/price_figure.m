%Figure for comparing price


function out = price_figure(obj, title, param,circ)



out = figure;


if param.skip_per == 1
    price = obj.price';
    weeks= obj.weeks(1):obj.weeks(end)';
elseif param.skip_per ==4
    [price,idx] = week2month(obj.price,param);
    weeks= obj.weeks(1):obj.weeks(end);
    
    weeks = weeks(idx)';
end



ejr = filter_price(price, 'EJR', param);
rac = filter_price(price, 'RAC', param);
ns  = filter_price(price, 'NS' , param);
mid = filter_price(price, 'Mid', param);


LW = 1.5;
PL = '--*';
PA ='-k';
LL = 'southeast';
FS = 12;

N1 = {'Nakamura-Steinsson', 'AC Neilsen/KM', 'EJR Reference', 'Chahrour'};
D1{1} = ns;
D1{2} = mid;
D1{3} = ejr;
D1{4} = rac;

for j = 1:4
    s = subplot(2,2,j);
    plot(weeks,D1{j},PA, 'linewidth',LW);
    hold on
    plot(weeks,price, PL, 'linewidth',1, 'color', [.4 .4 .4]);
    
    if j == 3 && circ
        rectangle('Position', [148 2.4 12 .26], 'Curvature', [1 1], 'linewidth', 2, 'edgecolor', [1 0 0])
    end
    legend(N1{j},'Actual Price','location',LL);
    xlabel('Week', 'fontsize', FS);
    ylabel('Price', 'fontsize', FS);
    set(s, 'XLim', weeks([1,end]));
end



set(out, 'PaperOrientation', 'landscape', 'PaperPosition', [.25 .25 10.5 8]);

%saveas(out, [param.dest_dir, title, '.eps'], 'epsc');
