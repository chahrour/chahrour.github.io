

function new_dat = Neilsen_MK(orig, param)

dat = orig;
sale_dur = param.J;


for k = 1:sale_dur

    %Initliaze first period price
    new_dat = 0*dat;
    new_dat(1) = dat(1);

    for j = 2: length(dat)

        %Guess that non-sale price is the price
        new_dat(j) = dat(j);

        %Case of price cut
        if dat(j)<dat(j-1)
            %Check for reversal of price cut within sale_dur weeks
            j_bar = find(dat(j+1:min(j+sale_dur, length(dat)))>dat(j));

            %If price cut reversed, replace intervening prices with the j-1
            %price
            if ~isempty(j_bar)
                new_dat(j:j+j_bar(1)) = dat(j-1);
            end
        end
    end

    dat = new_dat;

end



if param.drop_ends == 1
    new_dat([1:(param.freq-1)/2, (end-(param.freq-1)/2+1):end]) = NaN;
end
