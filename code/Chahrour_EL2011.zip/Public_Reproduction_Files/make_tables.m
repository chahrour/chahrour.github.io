%MAKE_FIGURES - Script for exporting latex figures for "Sales and Price
%Spikes in Retail Scanner Data"



function make_figures(data_file, file_desc, params)

dest_dir = params.dest_dir;
if params.skip_per > 1
    suffix = '_Q';
    term = 'Monthly';
    add_cap = [' (Pseudo-monthly Data)'];
else
    term = 'Weekly';
    suffix = '';
    add_cap = '';
end

eval(['load ', data_file]);

label1 = {'blank', 'Nakamura-Steinsson', 'AC Neilsen/KM', 'EJR Reference', 'Chahrour'};
label2 = {'blank', 'Unfiltered Price', 'Nakamura-Steinsson', 'AC Neilsen/KM', 'EJR Reference', 'Chahrour'};
%Table 1 - Levels
%[per at ref, frac of exp at ref, % price abovee, % price below, % changes up, % changes down]
table1_mat = [median([per_at_ref_NS per_at_ref_Mid per_at_ref_EJR per_at_ref_RAC]); ...
              median([frac_rev_NS frac_rev_Mid frac_rev_EJR frac_rev_RAC]);...
              medianc(per_above_ref_NS, per_above_ref_Mid, per_above_ref_EJR, per_above_ref_RAC);...
              medianc(per_below_ref_NS, per_below_ref_Mid, per_below_ref_EJR, per_below_ref_RAC);...
              medianc(per_up_NS, per_up_Mid, per_up_EJR, per_up_RAC);...
              medianc(per_down_NS, per_down_Mid, per_down_EJR, per_down_RAC)];
table1 = ltable(table1_mat, label1,...
                            {'Frac of Price Obs. at Attractor Price', 'Frac of Expenditure at Attractor Price', 'Frac of Non-Attractor Prices above Attractor Price', 'Frac of Non-Attractor Prices below Attractor Price',...
                            'Frac of Attractor Price Changes which are Increases', 'Frac of Attractor Price Changes which are Decreases'}, ['Basic Statistics' add_cap], 'table1_format',[dest_dir 'table1' suffix]);
         
        
%Table 2 - Volatility
%[stddev of log-levels, stddev of log-changes]
table2_mat = [median([stddev_none stddev_NS stddev_Mid stddev_EJR stddev_RAC]); ...
              median([d_stddev_none d_stddev_NS d_stddev_Mid d_stddev_EJR d_stddev_RAC])];

          
table2 = ltable(table2_mat, label2,...
                            {'$\sigma$(log-level)', '$\sigma$(log-change)'}, ['Price Volatility' add_cap], 'table2_format',[dest_dir 'table2' suffix]);

%Table 3 - Sales and Spikess
table3_mat = 100*[medianc(mag_below_NS, mag_below_Mid, mag_below_EJR, mag_below_RAC);...
                0,0, medianc(mag_above_EJR, mag_above_RAC)];
table3 = ltable(table3_mat, label1,...
                            {'Average Sale (\%)', 'Average Spike (\%)'}, ['Sales and Price Spikes' add_cap], 'table3_format', [dest_dir 'table3' suffix]);



%Table 4 - Persitence
%[Weekly Prob of Price Change, Peristence]
table4_mat = median([per_change_none per_change_NS per_change_Mid per_change_EJR per_change_RAC]);
table4_mat = [100*table4_mat; table4_mat.^-1./(13/params.skip_per)];          
table4 = ltable(table4_mat, label2,{[term ' Prob of Price Change (\%)'], 'Implied Duration (Quarters)'}, ['Price Persistence' add_cap], 'table4_format',[dest_dir 'table4' suffix]);


%Table 5 - Appendix
%[Weekly Prob of Price Change, Peristence]

table5_mat = [ 100*per_at_ref_EJR_g 100*per_at_ref_RAC_g 100*per_below_ref_EJR_g 100*per_below_ref_RAC_g 100*per_above_ref_EJR_g 100*per_above_ref_RAC_g 100*mag_below_EJR_g 100*mag_below_RAC_g 100*mag_above_EJR_g 100*mag_above_RAC_g per_change_EJR_g.^-1/13 per_change_RAC_g.^-1./(13/params.skip_per) nobs_none_g];         
table5 = ltable(table5_mat, {'blank' 'EJR' 'RC' 'EJR' 'RC' 'EJR' 'RC' 'EJR' 'RC' 'EJR' 'RC'  'EJR' 'RC' 'blank'},...
                            file_desc, ['Disaggregated Results'  add_cap], 'table5_format', [dest_dir 'table5' suffix]);



table6_mat = [ ntot_none_g ntot_NS_g ntot_Mid_g ntot_EJR_g ntot_RAC_g];         
table6 = ltable(table6_mat, label2,...
                            file_desc, ['Total Periods w/ Valid Observations'  add_cap], 'table6_format',[dest_dir 'table6' suffix]);




%Creates compilable .tex file with 'insert' command for tables 
make_file([dest_dir 'tables' suffix], 'file_format', ['table1' suffix], ['table2' suffix], ['table3' suffix], ['table4' suffix], ['table5' suffix],['table6' suffix]);



