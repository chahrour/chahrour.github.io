% This script creates a table of artificial data as a test of the matlab-latex
% package.


%**************************************************************
% EXAMPLE 1
%**************************************************************

%Data
data = [100 2 3 4; 4 3 2 1]; %Fake Data
data(:,:,2) = [.01 .05 .1 4;.01 .5 .001 1]; %Second panel of data give p-values


%Tiles
vert = {'Row1'  'Row2'; kill_dollar('Comment $$ 2') 'Comment 2'}';
horiz ={'Titles' 'Comment' 'Col1' 'Col2' 'Col3' 'Col4'};

%Creates .text file with table - can use \insert{} command
table1 = ltable(data, horiz,vert, 'Table Caption','table_format_file','testfile');

%Creates compilable .tex file with 'insert' command for tables 
make_file('testfile', 'file_format', 'testfile');

%Print .tex file to pdf.  Requires latex command be in your path.
output('testfile', '/usr/texbin/pdflatex');

%Take a moment to check on the tex file and the compiled file
pause

%**************************************************************
% EXAMPLE 2
%**************************************************************
%Text only table
vert = {'Row1'  'Row2'; 'Comment 1' 'Comment 2'}';
horiz ={'Titles' 'Comment'};
data = [];


%Override the format file preferences
prefs.vert_lines = 1;  
prefs.headers = 1;

%Now, as before
table1 = ltable(data, horiz,vert, 'Table Caption','table_format_file', 'testfile',prefs);
make_file('testfile', 'file_format', 'testfile');
output('testfile', '/usr/texbin/pdflatex');
