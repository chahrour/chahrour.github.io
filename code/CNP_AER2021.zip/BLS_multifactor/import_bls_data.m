load_file = 'indprod11-2.xlsx';

%% Load CNP sector definitions
[~,~,c] = xlsread('../cnp_sectors', 'multi_corres');
cnp_names = c(2:end,1);
c = string_it(c(2:end,2:end));
nsec = size(c,1);

[~,~,d] = xlsread('../cnp_sectors', 'CNP Sectors (Summary)');
d = string_it(d);

%% Map KLEMS sectors to their rows in the table (since used in all other sheets)
incl_titl = cell(size(c,1),1);
for ss = 1:nsec
    %for each included subsector
    idx = 1;
    idx2 = 2;
    while idx<=size(c,2) && ~strcmp(c(ss,idx), 'NaN')
        incl_tmp = d(strncmp(c{ss,idx},d(:,2),length(c{ss,idx})),1);
        for jj = 1:length(incl_tmp)
            cnp_names(ss,idx2) = incl_tmp(jj);
            idx2 = idx2+1;
        end
        idx = idx+1;
    end
end

%% Create matrix for weighting subs-sectors in each CNP sector
[gdp_mil_in,titles] = xlsread(load_file, 'Gross Output','A3:AG65');
usum = zeros(nsec,63); %sum the right rows for each CNP sector
nt = size(gdp_mil_in,2);
for ss = 1:nsec
    for ii = 2:size(cnp_names,2)
        if isempty(cnp_names{ss,ii});break;end
        idx_incl = strcmpi(cnp_names(ss,ii),titles);
        usum(ss,:) = usum(ss,:)+idx_incl';
    end
end

% Create a matrix that sums with gross weights based on nominal output for each period
wsum = zeros(nsec,63,nt);
usum = logical(usum);
for tt = 1:nt
    for ss = 1:nsec
        wsum(ss,:,tt) = usum(ss,:).*gdp_mil_in(:,tt)'./sum(gdp_mil_in(usum(ss,:),tt));
    end
end

gross_late = usum*gdp_mil_in;


%% Gross output quantity indexes
[gdp_late_in] = xlsread(load_file, 'Gross Output_Quantity','A3:AG65');
gdp_late = zeros(nsec,nt);
for tt = 1:nt
    gdp_late(:,tt) = wsum(:,:,tt)*gdp_late_in(:,tt);
end

%% Labor quantity indexes
[labor_late_in] = xlsread(load_file, 'Labor Input_Quantity','A3:AG65');
labor_late = zeros(nsec,nt);
for tt = 1:nt
    labor_late(:,tt) = wsum(:,:,tt)*labor_late_in(:,tt);
end

%% Labor Compensation in Millions
[comp_late_in1] = xlsread(load_file, 'Labor_NoCol Compensation','A3:AG65');
[comp_late_in2] = xlsread(load_file, 'Labor_Col Compensation','A3:AG65');
comp_late_in = comp_late_in1 + comp_late_in2;
comp_late = usum*comp_late_in;

%% VA Million
[va_late_in] = xlsread(load_file, 'Value Added','A3:AG65');
va_late = usum*va_late_in;

%% TFP indexes
[tfp_late_in] = xlsread(load_file, 'Integrated MFP Index','A3:AG65');
tfp_late = zeros(nsec,nt);
for tt = 1:nt
    tfp_late(:,tt) = wsum(:,:,tt)*tfp_late_in(:,tt);
end


%% Save_output

%Transpose. Cols are sectors, rows are years.
gdp       = gdp_late';
tfp       = tfp_late';
labor     = labor_late';
comp      = comp_late';
gross_mil = gross_late';
va_mil    = va_late';  

%Drop G
gdp       = gdp  (:,1:nsec-1);
tfp       = tfp  (:,1:nsec-1);
labor     = labor(:,1:nsec-1);
comp      = comp (:,1:nsec-1);
gross_mil = gross_mil(:,1:nsec-1);
va_mil    = va_mil   (:,1:nsec-1);
nms = cnp_names(1:nsec-1,1)';

gdp_cell   = [num2cell([NaN;(1987:1:2018)']),[nms;num2cell(gdp)]];
tfp_cell   = [num2cell([NaN;(1987:1:2018)']),[nms;num2cell(tfp)]];
labor_cell = [num2cell([NaN;(1987:1:2018)']),[nms;num2cell(labor)]];
gross_cell = [num2cell([NaN;(1987:1:2018)']),[nms;num2cell(gross_mil)]];

writecell(gdp_cell  ,'../output_files/multifactor_output.xlsx', 'Sheet','Output (index)');
writecell(tfp_cell  ,'../output_files/multifactor_output.xlsx', 'Sheet','TFP (index)');
writecell(labor_cell,'../output_files/multifactor_output.xlsx', 'Sheet','Labor (index)');
writecell(gross_cell,'../output_files/multifactor_output.xlsx', 'Sheet','Output (gross millions)');

save ../output_files/tfp tfp

