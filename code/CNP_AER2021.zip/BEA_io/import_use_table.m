%% Load CNP sector definitions
[~,~,c] = xlsread('../cnp_sectors', 'use_corres');
snames = c(2:end-1,1);
c = string_it(c(2:end,2:end));

%Drop G
c = c(1:end-1,:) ;
nsec = length(c);

fname = ['../output_files/IO', num2str(nsec)];

bea_dates = 2007;   %2007 benchmark tables is our benchmark
nt        = length(bea_dates);

IOgr      = zeros(nsec,nsec,nt);
tot_mat   = zeros(nsec,1   ,nt);
tot_lab   = zeros(nsec,1   ,nt);
tot_out   = zeros(nsec,1   ,nt);
tot_fin   = zeros(nsec,1   ,nt);
tot_im    = zeros(nsec,1   ,nt);
tot_ex    = zeros(nsec,1   ,nt);
gshr_bea = zeros(nt,nsec);

%% For each period in dataset
for tt = 1:nt
    
    % Load direct requirements tables
    dstr = num2str(bea_dates(tt));
    
    %Load IO table for each year
    [a,b] = xlsread('IOUse.xlsx', dstr, 'A6:BU79');
    
    %Load totals stats for each sector
    [tot_inter]  = xlsread('IOUse.xlsx', dstr, 'C83:BU83');
    [tot_comp]   = xlsread('IOUse.xlsx', dstr, 'C84:BU84');
    [tot_va  ]   = xlsread('IOUse.xlsx', dstr, 'C87:BU87');
    
    %ALL Final Uses
    [tot_final ]  = xlsread('IOUse.xlsx', dstr, 'CU8:CU78');
    
    %Imports
    [tot_imp ]  = xlsread('IOUse.xlsx', dstr, 'CF8:CF78');
    tot_imp = -[tot_imp;0;0]; %Imports come as negative numbers
    tot_imp(isnan(tot_imp)) = 0;
   
    %Exports
    [tot_exp ]  = xlsread('IOUse.xlsx', dstr, 'CE8:CE78');
    tot_exp = [tot_exp;0;0];  
    tot_exp(isnan(tot_exp)) = 0;
    
    %Gross output
    [tot_output] = xlsread('IOUse.xlsx', dstr, 'C90:BU90');
    
    %codes for sectors that use the input
    dest_codes = deblank2(b(1,3:end));
    
    %codes for sector providing the input
    orig_codes = deblank2(b(3:end-1,1));
    
    %Blanks are just zeros
    a = a(1:71,1:71); a(isnan(a))=0;
    
    % find matching cols/rows for each sector
    orig_tot = 0;
    dest_tot = 0;
    dest_keep = zeros(nsec,71);
    orig_keep = zeros(nsec,71);
    %for each sector
    for ss = 1:nsec
        
        %for subsector includes in the Atalay sector
        idx = 1;
        while idx<=size(c,2) && ~strcmp(c(ss,idx), 'NaN')
            
            %find matching sectors
            dest_keep(ss,:) = dest_keep(ss,:)+strncmp(c{ss,idx},dest_codes,length(c{ss,idx}));
            orig_keep(ss,:) = orig_keep(ss,:)+strncmp(c{ss,idx},orig_codes(1:71),length(c{ss,idx}))';
            
            idx = idx+1;
        end
        dest_tot = dest_tot + dest_keep(ss,:);
        orig_tot = orig_tot + orig_keep(ss,:);
    end
    
    
    % Construct IO matrix, rows are inputs, cols are dest sector
    for jj = 1:nsec
        %Compute BEA total intermediate: includes used inputs and non-comparable imports
        tot_mat(jj,:,tt) = sum(tot_inter(logical(dest_keep(jj,:))));
        
        %Compute BEA total labor
        tot_lab(jj,:,tt) = sum(tot_comp((logical(dest_keep(jj,:)))));
        
        %Compute BEA gross output
        tot_out(jj,:,tt) = sum(tot_output((logical(dest_keep(jj,:)))));
        
        %Compute BEA use in final goods
        tot_fin(jj,:,tt) =  nansum(tot_final((logical(dest_keep(jj,:)))));
        
        %Compute BEA exports
        tot_ex(jj,:,tt)  =  nansum(tot_exp((logical(dest_keep(jj,:)))));
        
        %Compute BEA imports 
        tot_im(jj,:,tt)  =  nansum(tot_imp((logical(dest_keep(jj,:)))));
        
        %Compute inputs for each sector
        for ii = 1:nsec
            IOgr(ii,jj,tt) = sum(sum(a(logical(orig_keep(ii,:)),logical(dest_keep(jj,:)))));
        end
    end
    
    %Gross shares, measured two ways (including capital income, and excluding it)
    gshr_bea(tt,:)  = (tot_out(:,:,tt)')./sum(tot_out(:,:,tt));
    
    IOgr(:,:,tt) = IOgr(:,:,tt)';  % so rows are destination, cols are origin sector
end

%%
inter_used    = sum(IOgr,2);                  %Intermediates used by each sector.
inter_abs     = sum(IOgr,1);                 %Total intermediate absorption in each sector
gross_out     = tot_out + tot_im - tot_ex;    %Total overall absorption  in each sector
kap_shr       = zeros(size(tot_lab));         %Baseline model assumes zero capital share.


% Sum numbers over all years
alphi_sec   = sum(inter_used ,3)./sum(gross_out,3);
alphk_sec   = sum(kap_shr,3)./sum(gross_out,3);
alph_sec    = alphi_sec + alphk_sec;
A           = diag(sum(gross_out,3))\sum(IOgr,3);

%Shares in final absorbtion
bet         = sum(gross_out,3)-sum(inter_abs,3)';
bet         = bet./sum(bet);

%For main paper calibration
save(fname, 'A', 'bet*', 'alphi_sec', 'alphk_sec', 'alph_sec');

