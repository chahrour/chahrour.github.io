% %% Basic Macro Time-series and including some labor market series
% clear mth qtr
% url = 'https://fred.stlouisfed.org/';
% c = fred(url);
% 
% %Main BEA Series
% qtr.gdp  = fetch(c,'GDP');       % gdp
% qtr.def = fetch(c,'GDPDEF');     % deflator
% 
% %BLS Population
% qtr.pop = fetch(c,'CNP16OV');    % noninstitutional population
% 
% %Employment Measures (BLS: Productivity and Costs)
% qtr.hrs   = fetch(c,'HOANBS');      %hours worked
% 
% date_loaded = datestr(today);
% 
% close(c);
% 
% save ../output_files/gdp_hrs_raw.mat qtr date_loaded

%% Use previously-save data from FRED

load ../output_files/gdp_hrs_raw

%Population Series Smoothed
[~,pop]  = ts_hp(M2Q(ts_fred(qtr.pop)),1600);

%Quarterly Quantities
gdp  = ts_fred(qtr.gdp);
defl = ts_fred(qtr.def);
hrs  = ts_fred(qtr.hrs);

%Real GDP
gdpv     = ts_div(gdp,defl);

%Annual data
dates_a = [198701,201801];

%Annual gdp-per-capita
gdp_pca =  ts_log(Q2A(ts_div(   gdpv  ,pop)));
hrsa    =  ts_log(Q2A(ts_div(   hrs   ,pop)));

%Annual average GDP/ Hours
gdp_a  = vect(gdp_pca,0,dates_a);
hrs_a  = vect(hrsa   ,0,dates_a);

save ../output_files/gdp_hrs gdp_a hrs_a pop


 
