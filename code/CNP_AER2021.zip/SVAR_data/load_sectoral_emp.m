%% Load employement by sector from CES via FRED

[~,~,raw]  = xlsread('../cnp_sectors.xlsx','ces_corres');
raw        = raw(5:end,1:4);
sector_emp = cell(1,29);
for jj = 1:29
    sector_emp{jj} = ts_make(zeros(726,1),12,196001, 'Sector X');
end


%% Get sectoral labor market series from FRED
% clear mth qtr
% url = 'https://fred.stlouisfed.org/';
% c = fred(url);
% 
% sec_sv = cell(size(raw,1),1);
% 
% for jj = 1:size(raw,1)
%     tmp = raw{jj,4};
%     if ~isnan(tmp)
%     sec_sv{jj} = ts_fred(fetch(c,tmp));
%     end
% end
% close(c);
% 
% save ../output_files/sector_labor_raw sec_sv

%% Use saved FRED data
load ../output_files/sector_labor_raw
mnf = sector_emp{1};
% Load and add new data
for jj = 1:size(raw,1)
    tmp = raw{jj,4};
    if ~isnan(tmp)
        sec_tmp = sec_sv{jj};
        
        sector_emp{raw{jj,2}} = ts_plus(sector_emp{raw{jj,2}},sec_tmp);
        
        if strcmp(raw{jj,4}(1:min(end,7)),'CES6054'); %|| strcmp(raw{jj,4}(1:3),'USW') || strcmp(raw{jj,4}(1:3),'UST')
            mnf = ts_plus(mnf,sec_tmp);
        end
    end
        
end
% Sector 21 (other trans) needs to subtract 20 (motor vehicles)
sector_emp{21} = ts_minus(sector_emp{21},sector_emp{20});

%Make everything quaterly
for jj = 1:29
   sector_emp{jj} = M2Q(sector_emp{jj}); 
end


