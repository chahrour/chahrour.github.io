
%% Loads the news data
[a,b] = xlsread('data_news_all_with_sectors_and_filter.xlsx');
a =[nan(1,size(a,2)+1);nan(size(a,1),1),a(:,:)];  %pad a to be same dimensions as b


%Drop all rows for dummy_merg = 0 and dummy_us = 0
pp_mrg  = logical((a(:,end-1) == 1).*(a(:,10)==1));
a       = a(pp_mrg,:);
b       = b(pp_mrg,:);

%% Generate weights, etc

pp_list = {'nytf', 'j',   'usat',  'bstngb', 'atjc', 'cgaz', };
pp_wghts = [.25,.25,.25,1/12,1/12,1/12];  %Weights for each paper

pp_fil  = a(:,end) == 1; %filtered


weights_all  = cell(6,29);
weights_filt = cell(6,29);
for jj = 1:6 %For each paper
    
    pp_idx = strcmp(b(:,8), pp_list{jj});  %Which paper?
    tmp1 = make_news_wghts(a(pp_idx                 ,:));
    tmp2 = make_news_wghts(a(logical(pp_idx.*pp_fil),:));
    
    for ii = 1:29  %Store results for each sector
        weights_all{jj,ii}  = tmp1{ii};
        weights_filt{jj,ii} = tmp2{ii};
    end
    
end

%% Average accross papers


%ALL PAPERS NOT FILTERED
wghts_all = cell(1,29); wghts_all_filt = cell(1,29); wghts_ny_j_filt = cell(1,29);
for ii = 1:29
    wghts_all{ii} = ts_waverage(pp_wghts,weights_all{:,ii});
end

%ALL PAPERS FILTERED
for ii= 1:29
    wghts_all_filt{ii} = ts_waverage(pp_wghts,weights_filt{:,ii}) ;
end

%NYTIMES + WSJ FILTERED
for ii = 1:29
    wghts_ny_j_filt{ii} = ts_waverage(pp_wghts(1:2),weights_filt{1:2,ii}) ;
end



%% Function - make news weights
function [wghtv,herfv,gniv] = make_news_wghts(a)

%set by hand, get 'em right
nsector = 29;
nq = length(1988:2018)*4;

%initialize
herf = zeros(nq,1);
gni  = zeros(nq,1);
wght = zeros(nq,29);
ctr  = 1;
for yy = 1988:2018
    
    %select the right year
    a_tmp   = a(a(:,9) == yy,:);
    
    %for each quarter
    for qq = 1:3:10
        
        %select the right quarter
        idx_qq = (floor((a_tmp(:,5)-yy*10000)/100))==qq;
        a_tmp2 = a_tmp(idx_qq,:);
        
        %sum all mentions of each sector
        ct_sector = zeros(1,nsector);
        for ii = 1:nsector
            ct_sector(ii) = sum(a_tmp2(a_tmp2(:,16) == ii,2));
        end
        
        %news weights
        wght(ctr,:) = ct_sector./sum(ct_sector);
        
        %herfendahl index
        herf(ctr) = sum((ct_sector./sum(ct_sector)).^2);
        
        %gini coefficient
        [ct_ord,ct_idx] = sort(ct_sector, 'ascend');
        %gni(ctr) = gini(1/nsector*ones(1,nsector),ct_ord);  %Can add sector weights
        ctr = ctr+1;
        
    end
end
herfv = ts_make(herf, 4,198801, 'Herf. of News');
gniv  = ts_make(gni , 4,198801, 'Gini of News');

wghtv = cell(1,nsector);
for ii = 1:nsector
    wghtv{ii} = ts_make(wght(:,ii),4,198801, ['Sector ', num2str(ii) ' wght']);
end

end