% LOAD_ALL:  Parent file for loading all the data from the various
% sources to generate the data for the VAR-based exercise in Section 7 of
% the paper.
%
% The data come from 4 different places
%
% (1) Current employment survery (CES) from BLS via FRED
% (2) Michigan Consumer Survery from Univ. of Michigan
% (3) SPF data from Philly Fed
% (4) News coverage data from us.


%% (1) Load the CES data from FRED
load_sectoral_emp

%% (2) Load the MICHIGAN SURVEY data downloaded from http: ...
[a,b]= xlsread('Michigan/redbk23.xls');
good = M2Q(ts_make(a(75:end,2),12,197801, 'Good News Heard')) ;
bad  = M2Q(ts_make(a(75:end,3),12,197801, 'Bad News Heard')) ;
notn = ts_hp(M2Q(ts_make(a(75:end,4),12,197801, 'No News Heard')),160000) ; %Effectively linear detrend
indx = M2Q(ts_make(a(75:end,5),12,197801, 'Index News Heard')) ;

%% (3) SPF data for VAR
start_ = 196804;
end_   = 202001;

% Growth Forecasts
[a,b]     = xlsread('SPF/medianGrowth.xlsx','RGDP');
cast_delt = ts_make(a(:,3)/400,4,196804, 'SPF median real GDP growth');

% FORECAST ERROR USING Nth Release
[a,b]      = xlsread('SPF/routput.xlsx','DATA');

dgdp_r3    = ts_make(a(:,3)/400,4,196503);
nce_rgdp_3 = ts_minus(dgdp_r3,cast_delt);
dgdp_r3    = 400*vect(dgdp_r3,0,[start_,end_]);
nce_r3     = 400*vect(nce_rgdp_3,0,[start_,end_]);

var_data = [nce_r3,dgdp_r3];

%% (4) Load the news data and generate news weights, dispersion measures, etc
load_news_data

%% (5) Construct non-representativeness timseries
make_nonrep

%% (6) Save everything
var_desc = {'gdpv   '        , 'Real GDP'; 
            'pop'            , 'Populatiom, with rebasing jumps smoothed using HP filter per advice of Peter Ireland';
            'wghts_all'      , 'News weights using all papers, no filter';
            'wghts_all_filt' , 'News weights using all papers, with filter';
            'wghts_ny_j_filt', 'News weights using all WSJ & NY times, with filter';
            'notn'           , 'News heard index Michigan Consumer Survey';
            'dev_emp_w'      , 'TV news weighted employment growth less TV share weighted employment growth'; 
            'dev_emp_wn'     , 'News heard-scaled TV news weighted employment growth less TV share weighted employment growth';
            };
save ../output_files/var_data var_data nce_r3 dgdp_r3 dev_emp_w dev_emp_wn var_desc wghts* notn


