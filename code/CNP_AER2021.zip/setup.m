% SETUP - arrange path for running the replication codes.
%
% >> setup


%Add some simple helper functions
addpath('helper_functions');

%Add a set of tools for manipulating time-series data
addpath('ts_box')