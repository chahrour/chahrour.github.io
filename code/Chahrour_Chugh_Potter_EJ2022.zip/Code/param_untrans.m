function param = param_untrans(param)

