% MODEL - File providing the symbolic equilibrium conditions of Chahrour,
% Chugh, Potter (2022)
%
% usage:
%
% mod = model_linear(param, set)
%
% where
%
% param = a parameters object, created in parmeters.m
% set = a settings object, also created in parameters.m
%
% NOTES: This program, which generates the model matrices in cannonical form,
%        requires the MATLAB symbolic toolbox! The algorithms used to solve
%        the model, however, are numerical, and require no additonal m-files
%        beyond those that appear in this directory.
%



function [mod] = model(param,set)

%Name of text files
mod.fname   = 'model_prog.m';
mod.ss_call = 'model_ss.m';

%Declare parameters symbols: parameters are values to be estimated
param_list = fieldnames(param);
syms(param_list{1:end});
for j = 1:length(param_list)
    eval(['PARAM(j) = ',param_list{j} ,';']);
end
PARAM

%Declare setting symbols: symbols are values that are "fixed"
set_list = fieldnames(set);
syms(set_list{1:end});
for j = 1:length(set_list)
    eval(['SET(j) = ',set_list{j} ,';']);
end
SET

[Xss,Yss] = model_ss(param,set);
%Add in aggregate variables
syms N C S F I Q VN PN QN PHIN GDP R W DY DC DN DI DU DUN DR UN DW GAMX GAMZ A CHIN BB KAP KAPL DWO OM1 OM2 WSURP WSHR DYLO DCLO DNLO DILO DUNLO DVN
syms K EPG  EPZ EPN EPB EPW GAMXL GAMZL AL CHINL BBL GDPL WL CL NL IL RL UL DWL DWLL DWLLL WLL UNL EPGL EPAL EPZL EPNL EPBL EPP PSIIL PSII DYL DCL DNL DIL DUNL VNL
syms DGG G DG GL 
syms DWX WX WXL
syms WNY
syms DTFPU PT DPT PTL WNB WDK VF WDKL WNBL
syms A BB VFL DVF 
syms PHIN VNLL VNF OMEGP CHIN MC INFL


EPP   = sym('EPP', [1,set.nmax]);
EPP_p = make_prime(EPP);


Y = [N C S F I VN PN QN GDP W R KAP DY DC DN DI UN DGG DG DVN DW  DTFPU PT DPT WNB WDK VF DVF WSURP WSHR WNY PHIN VNF MC INFL OMEGP WX]; %DW1 DW2 DW3 DW4 DW5 DW6 DW7 DV1 DV2
X = [K GAMX PSII G A BB CHIN GAMXL CL NL IL WL GDPL GL VNL VNLL KAPL EPP PTL WDKL WNBL AL VFL WXL DWX ];

ny = length(Y)    ; nx = length(X);
YP = make_prime(Y); XP = make_prime(X);
make_index([Y,X]);

[1:nx;X]
[1:ny;Y]
TAU = taul;
TAU_p = taul;

%Matching function
match = @(vn,s,chi,epn) chi*vn^epn*s^(1-epn);

%***********************************
% MODEL EQUATIONS
%***********************************

%Marginal utility of consumption
Uc     =               (C   - psii*PSII*F  ^jrthet*GAMX    )^-sig;
Uc_p   =               (C_p - psii*PSII_p*F_p^jrthet*GAMX_p)^-sig;

%Marginal utility of participation
Uf     =              -(C   - psii*PSII*F  ^jrthet*GAMX    )^-sig*psii*PSII  *GAMX  *jrthet*F  ^(jrthet-1);
Uf_p   =              -(C_p - psii*PSII_p*F_p^jrthet*GAMX_p)^-sig*psii*PSII_p*GAMX_p*jrthet*F_p^(jrthet-1);

%Stochastic discount factor
OMEG_p = Uc_p/Uc*GAMX^-sig;

%Vacancy adjustment costs
vcf   = @(xv1,xv2) an2/2*(xv1/xv2-1)^2;       % Adjustment cost function
vcf_d = @(xv1,xv2) an2*(xv1/xv2-1);           % Derivative

%Capital FOC
f(1) = 1 - bet*BB_p/BB*OMEG_p*(R_p + 1 - delt0);  

%Labor supply condition
f(end+1) = (-Uf/Uc) - (1-TAU)*W*PN - (1-PN)*KAP - PN*bet*BB_p/BB*(1-lamn)*OMEG_p*((1-PN_p)/PN_p)*GAMX*(-Uf_p/Uc_p - KAP_p);    %FOC for F

%Firm FOC: V
f(end+1) = PHIN  - GAMX/QN*(an+vcf(VN,VNL)+vcf_d(VN,VNL)*(VN/VNL) - bet*BB_p/BB*OMEG_p*GAMX_p*vcf_d(VN_p,VN)*(VN_p/VN)^2);

%Firm FOC: N
f(end+1) = PHIN - (1-alph)*A*(K/N)^alph*GAMX^(1-alph) + W - bet*BB_p/BB*OMEG_p*(PHIN_p*(1-lamn)*GAMX);

%Firm value (for stock prices)
f(end+1) = VF - (GDP - W*N - (an+vcf(VN,VNL))*VN*GAMX - R*K ) - bet*BB_p/BB*OMEG_p*(VF_p*GAMX);

%Firm FOC: K
f(end+1) = R - alph*A*(K/(GAMX*N))^(alph-1);

%LOM: Employment
f(end+1) = N - (1-lamn)*NL - match(VN,S,CHIN*chin,epn);

%Match rate: Households
f(end+1) = PN - match(VN,S,CHIN*chin,epn)/S;

%Match rate: Firms
f(end+1) = QN - match(VN,S,CHIN*chin,epn)/VN;

%LOM: Capital
f(end+1) = K_p*GAMX - I - (1 - delt0)*K;

%Aggregate resource constraint
f(end+1) = A*(K)^alph*(GAMX*N)^(1-alph) - C - I*(1) - gbar*G - (an+vcf(VN,VNL))*GAMX*VN;

%Output
f(end+1) = GDP - A*(K)^alph*(GAMX*N)^(1-alph);

%Unemployment rate
f(end+1) = UN*(N+S-match(VN,S,CHIN*chin,epn)) - (S-match(VN,S,CHIN*chin,epn));

%Labor force definition
f(end+1) = F - (N + S - match(VN,  S,  CHIN*chin,  epn)); 

%Workers' outside option
f(end+1) = KAP - kap*W*(1-TAU);                                         

%Gov't spending trend (adjusts to long-run level)
f(end+1) = DGG - GAMXL;    
 
%Firm marginal cost (for inflation response)
f(end+1) = MC - (log((1-alph)^(-1)*((1-alph)/alph)^alph) + (1-alph)*(log(W)-log(GAMX)) + alph*log(R));  %Log(MC)

%NK Phillips curve (for inflation response)
f(end+1) = INFL - ( bet*INFL_p + mccoef*MC );

%*******************************
% EXOGENOUS PROCESSES
%*******************************

%The MA terms for TFP growth
for jj = 1:set.nmax-1
    f(end+1) = log(EPP_p(jj+1))- log(EPP(jj));
end
f(end+1) = log(EPP_p(1));
f(end+1) = log(GAMX_p/gamx) - rhox*log(GAMX/gamx) - phix1*log(EPP(1)) - phix2*log(EPP(2)) - phix3*log(EPP(3)) - phix4*log(EPP(4)) - phix7*sigxn*log(EPP(7))-phix8*sigxn*log(EPP(8));
f(end+1) = log(PSII_p)      - rhop*log(PSII)       ;
f(end+1) = log(G_p)         - rhog*log(G)          ;
f(end+1) = log(A_p)         - rhoa*log(A)          ;
f(end+1) = log(BB_p)        - rhob*log(BB)         ;
f(end+1) = log(CHIN_p)      - rhoc*log(CHIN);


%*******************************
% WAGE DEFINITIONS
%*******************************

%The NB wage process
WNB_tmp = ((1-etan)*KAP + etan*((1-alph)*A*(K/N)^alph*GAMX^(1-alph)...
    + (1-lamn)*GAMX*bet*BB_p/BB*OMEG_p*PN_p*PHIN_p))/((1-etan)*(1-TAU)+etan);

f(end+1) = WNB - WNB_tmp^wpt*(WNBL*gamx/GAMXL)^(1-wpt);

%DHK structural wage process
f(end+1) = PT - (GDP - R*K - (an+vcf(VN,VNL))*GAMX*VN)/N;
f(end+1) = WDK - omeg0*PT^wpt*(WDKL/GAMXL)^(1-wpt);

%Reduced form wage elements, only affect economy if agno is on
%(so that nash=dhkw=0)
f(end+1) = log(DWX_p) + phixr*log(WX*gamx/GAMX) - sym('phix_c',[1,set.nmax])*log(EPP.');

%The wage equation, which is active depends on parameter
f(end+1) = log(W) - agno*log(WX*wbar) ...
                  - nash*log(WNB) ...
                  - dhkw*log(WDK);

%*******************************
% ADJUSTED-TFP ANALOG
%*******************************
f(end+1) = DTFPU - GAMX^(1-alph)*A/AL;

%*******************************
% SHARE VARIABLES
%*******************************
f(end+1) = WSURP - (W*(1-TAU)-KAP + (1-lamn)*bet*GAMX*BB_p/BB*OMEG_p*(1-PN_p)*WSURP_p);
f(end+1) = WSHR  - WSURP/(WSURP+PHIN);
f(end+1) = WNY   - W*N/GDP;

%*******************************
% LINKING EQUATIONS
%*******************************
f(end+1) = GAMXL_p  - GAMX;
f(end+1) = WL_p     - W;
f(end+1) = CL_p     - C;
f(end+1) = NL_p     - N;
f(end+1) = IL_p     - I;
f(end+1) = GDPL_p   - GDP;
f(end+1) = GL_p     - G;
f(end+1) = VNL_p    - VN;
f(end+1) = VNLL_p   - VNL;
f(end+1) = KAPL_p   - KAP;
f(end+1) = PTL_p    - PT;
f(end+1) = VFL_p    - VF;
f(end+1) = WXL_p    - WX;
f(end+1) = DWX      - GAMXL/gamx*WX/WXL;
f(end+1) = WDKL_p   - WDK;
f(end+1) = WNBL_p   - WNB;
f(end+1) = AL_p     - A;
f(end+1) = OMEG_p   - OMEGP;

%*************************************
% GROWTH DEFINITIONS FOR MEASUREMENT
%*************************************
f(end+1) = DY   - GAMXL*GDP/GDPL;
f(end+1) = DC   - GAMXL*C/CL;
f(end+1) = DW   - GAMXL*W/WL;
f(end+1) = DI   - GAMXL*(I+(an+vcf(VN,VNL))*GAMX*VN)/(IL+(an+vcf(VNL,VNLL))*GAMXL*VNL);  %Measured investment growth includes the relative price.
f(end+1) = DPT  - GAMXL*PT/PTL;
f(end+1) = DVF  - (GAMXL*VF/VFL)^lev_fact;
f(end+1) = DG   - DGG*G/GL;
f(end+1) = DN   - N/NL;
f(end+1) = DVN  - VN/VNL;
f(end+1) = VNF  - VN/F;

%*****************************************
%EXTRA EQUATIONS TO DETERMINE NUMERICAL SS
%*****************************************
disp(['Number of equations: ' num2str(length(f))])
disp(['Number of variables: ' num2str(length(X) + length(Y))])

%Log-linear approx
xlog = ones(1,length(X)); xlog = logical(xlog);
ylog = ones(1,length(Y)); ylog(mc_idx) = 0; ylog(infl_idx) = 0; ylog(vnf_idx) = 0; ylog(pn_idx) = 0; ylog(un_idx) = 0; ylog(vn_idx) = 0;  ylog(wshr_idx) = 0; ylog(wny_idx) = 0;  ylog = logical(ylog);
log_var = [X(xlog) Y(ylog) XP(xlog) YP(ylog)];

mod.f     = subs(f, log_var, exp(log_var));
mod.X     = X;
mod.XP    = XP;
mod.Y     = Y;
mod.YP    = YP;
mod.xlog  = xlog;
mod.ylog  = ylog;
mod.PARAM = PARAM;
mod.param = param;
mod.SET   = SET;
mod.set   = set;
mod.Xss   = Xss;
mod.Yss   = Yss;
mod.adiff = false; %Include anaylytical derivatives?

%Standard Errors
mod.shck = sym(zeros(length(X),7));
mod.shck(gamx_idx-ny,1)  = sigxs;  %Surprise TFP growth (not used in this paper)
mod.shck(chin_idx -ny,2) = sigc;
mod.shck(g_idx   -ny,3)  = sigg; 
mod.shck(psii_idx-ny,4)  = sigp;
mod.shck(bb_idx  -ny,5)  = sigb;
mod.shck(a_idx-ny   ,6)  = siga;
mod.shck(epp1_idx-ny,7)  = 1;     %News TFP growth, SD in TFP equation
 
%Baseline
mod.shck(dwx_idx-ny,7) = phix_c0;
    
%Measurement Error (none in this paper)
mod.me = sym(zeros(length(Y)));

%Derivatives using numerical toolbox
mod = anal_deriv(mod);

%Save index variables for use in main_prog
!rm -f v_idx.mat
save v_idx *_idx

