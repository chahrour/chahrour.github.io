load var_results_2x ir_bs ir_wghts nper other_idx ir_other ir_other2
load v_idx.mat  

%% Get fixed (set) and estimated (param) parameters
nmax                         = set.nmax;
[yss,xss,param,set]          = model_ss(param,set);
paramv                       = param_untrans(struct2array(param)');
setv                         = struct2array(set);


%% The optimization step
ir_ob = @(paramv) ir_obj(paramv,setv,ir_bs,ir_wghts,dtfpu_idx,dy_idx,dc_idx,di_idx,dn_idx,dvf_idx,dw_idx);

V = vec(ir_wghts(1:50,1:6));

options                        = optimoptions('lsqnonlin');
options.Display                = 'off';
options.OptimalityTolerance    = 1e-10;
options.StepTolerance          = 1e-10;
options.FunctionTolerance      = 1e-10;
options.MaxFunctionEvaluations = 12500;

param0      = paramv;
[param_opt,fval,residual,exitflag,output,lmult,Jac]   = lsqnonlin(ir_ob,param0,lbnd,ubnd,options);

se_final    = diag((Jac'*Jac).^-.5);
param_final = assign_params(param,param_opt);

loss0       = sum(ir_ob(param0).^2);
loss_final  = sum(ir_ob(param_opt).^2);

[loss0,loss_final]
display_change(param,param_final)



%% Save results for plotting/tables
paramv                        = struct2array(param_final);
setv                          = struct2array(set);
[f, fx, fy, fxp, fyp, eta]    = model_prog(paramv,setv);
[gx,hx]                       = gx_hx_alt(fy,fx,fyp,fxp);
iry1                          = ir(gx,hx,eta(:,7),nper);  %7 is the news shock
iry2                          = ir(gx,hx,eta(:,6),nper);  %6 is the surp shock
[~,irp_f,irp_s] = ir_ob(paramv);

%Other IRS
irp_other = zeros(nper,length(other_idx),2);

%Data
irp_other(:,:,2) = ir_other(:,:,1);
irp_other2(:,:,2) = ir_other2(:,:,1);

%Model (news)
irp_other(:,1,1) = cumsum(iry1(:,dvn_idx)) - iry1(:,f_idx);  %log(Vacancies/Labor Force)
irp_other(:,2,1) = cumsum(iry1(:,dn_idx));
irp_other(:,3,1) = iry1(:,un_idx);
irp_other(:,4,1) = iry1(:,f_idx);
irp_other(:,5,1) = iry1(:,pn_idx);
irp_other(:,6,1) = iry1(:,pn_idx);

%Model (unexp)
irp_other2(:,1,1) = cumsum(iry2(:,dvn_idx)) - iry2(:,f_idx);  %log(Vacancies/Labor Force)
irp_other2(:,2,1) = cumsum(iry2(:,dn_idx));
irp_other2(:,3,1) = iry2(:,un_idx);
irp_other2(:,4,1) = iry2(:,f_idx);
irp_other2(:,5,1) = iry2(:,pn_idx);
irp_other2(:,6,1) = iry2(:,pn_idx);

if set.agno
    save agno_results param_final set gx hx eta iry1 iry2 loss_final se_final irp_f irp_s irp_other infl_idx
elseif set.dhkw
    save flow_results param_final set gx hx eta iry1 iry2 loss_final se_final irp_f irp_s irp_other infl_idx
elseif set.nash
    save nash_results param_final set gx hx eta iry1 iry2 loss_final se_final irp_f irp_s irp_other infl_idx
end

