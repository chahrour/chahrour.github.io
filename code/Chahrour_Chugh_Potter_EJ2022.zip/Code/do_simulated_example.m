%Inshck_nmsibility test
load model_object ny *idx modl
load flow_results
load formatted_data yxdat

%IRs from model
ir_data = irp_f(:,[1,2,3,4,5,6],1);

%The variables and shocks for the simulation
gxp = gx([dtfpu_idx,dy_idx,dc_idx,di_idx,dn_idx,dvf_idx],:); nvar = size(gxp,1);

%The first shock (surprise-perm tfp) is not on.
eta_tmp = eta(:,[2,3,4,5,6,7]);
eta_tmp(:,1) =  1*eta_tmp(:,1);          %Matching
eta_tmp(:,2) = -1*eta_tmp(:,2);          %Govt spending
eta_tmp(:,3) = -1*eta_tmp(:,3);          %Labor supply
eta_tmp(:,4) = -1*eta_tmp(:,4);          %Demand
eta_tmp(:,5) =  1*eta_tmp(:,5);          %Temp TFP
eta_tmp(:,6) =  1*eta_tmp(:,6);          %News

shck_nms = {'Matching', 'Gov. Spending', 'Labor Supply', 'Discount Factor', 'Surprise TFP', 'News TFP'}';
horiz ={'Shock' 'TFP' 'Y' 'C' 'I' 'N' 'NYSE'};

% Impulse responses
csum_idx = [1 2 3 4 5,6]; nh = 80;%30;
iry = zeros(nh,size(gxp,1),size(eta_tmp,2));
for jj = 1:size(eta_tmp,2)
    [~,iry(:,:,jj)] = ir(gxp,hx,eta_tmp(:,jj),nh);
    iry(:,csum_idx,jj) = cumsum(iry(:,csum_idx,jj));
end
sigY = mom(gx,hx,eta_tmp*eta_tmp');

% Theoretical VD
lam = [2*pi/500,2*pi/2];
vd_tab = vdfilter_orig(gx([dtfpu_idx,dy_idx,dc_idx,di_idx,dn_idx,dvf_idx],:),hx,eta_tmp,lam,[],1);


%%
%Filename
filename = [dest_dir, 'eer_vd1_theory'];

%Creates .text file with table - can use \insert{} command
prefs.label = 'eer_vd_theory';
[table1, prefs] = ltable(vd_tab, horiz, shck_nms, 'Variance decompositions of theoretical variables','table_format_file_vd_suitability',filename,prefs);





%%
                                            
clear param
% VAR Parameters
nper     = 500;                     % Max horizon for IR

%ID of shock 1
targ_var1 = [1];                    %Variable to target in yxsim
kmin1     = 20;                     %Starting period to include in maximand
kmax1     = 80;                     %Last period to include in maximization
norm_idx1 =  1 ;                    %Sign normalized for what variable's response
hor_idx1  =  25;                    %Horizon of normalization

%ID of shock 2
targ_var2 = [1];                                                         
kmin2     = 0;
kmax2     = 0;
norm_idx2 = 1;   
hor_idx2  = 0;   

 
%% ID Procedure for long sample point estimate
rng(0)
N = 100000;
yxsim = sim_dat(gxp,hx,eta_tmp,N+100,100);      %GXP, not GX...affects which variables are here.
yxsim= yxsim(1:nvar,:)';
yxsim(:,csum_idx) = cumsum(yxsim(:,csum_idx));

[B,c,errs] = quick_var(yxsim,4); B = companion_form(B');
[cnew, struct_errs,q2] = identify_shocks(B,c,errs,targ_var1,targ_var2,kmin1,kmin2,kmax1,kmax2,norm_idx1,norm_idx2,hor_idx1,hor_idx2);

%Coeff matrix
bet = B(1:nvar,:)';

% Impulse responses
ir_sim = zeros(nper,nvar,nvar);

%Impulse responses
for jj = 1:nvar
    [ir_sim(:,:,jj)] = quick_IR(bet, nper, cnew(:,jj));
end


%% Run bootstrap
nboot = 2500;
rng_seed = linspace(10,2^31,5000);  %So that we use consistent seeds in parfor
T = 1*size(yxdat,1);

%Preallocate
ir_boot1 = zeros(nper,nvar,nboot); ir_boot2 = zeros(nper,nvar,nboot);ir_boot_ks = zeros(nper,nvar,nboot);
corr_n = zeros(nboot,1);
nn = 1;
n = 1;
while nn <= nboot
    rng(rng_seed(n));
    
    yxsamp = sim_dat(gxp,hx,eta_tmp,T+100,100); 
    yxsamp = yxsamp(1:nvar,:)';
    yxsamp(:,csum_idx) = cumsum(yxsamp(:,csum_idx));    
      
    %vshare procedure
    [B_n,c_n,errs_n] = quick_var(yxsamp,4); B_n = companion_form(B_n');
    if max(abs(eig(B_n))) < .999999 %&& rcond(B_n) > 1e-9
        
      
        [c_n] = identify_shocks(B_n,c_n,errs_n,targ_var1,targ_var2,kmin1,kmin2,kmax1,kmax2,norm_idx1,norm_idx2,hor_idx1,hor_idx2,q2);
        
        cks_n = identify_shocks_ks(B_n,c_n,errs_n,targ_var1,norm_idx1,hor_idx1);
        
        %Impulse responses
        [ir_boot1(:,:,nn)] = quick_IR(B_n(1:nvar,:)', nper, c_n(:,1));
                [ir_boot2(:,:,nn)] = quick_IR(B_n(1:nvar,:)', nper, c_n(:,2));

        [ir_boot_ks(:,:,nn)] = quick_IR(B_n(1:nvar,:)', nper, cks_n(:,1));

        %disp(num2str([n,nn]))
        nn = nn+1;
        
    end
    n = n+1;


end


%% FIGURES

ir_range = 40;

%News
ir_point1        = ir_data(:,1:nvar,1);
ir_point1(:,:,2) = ir_sim(1:size(ir_data,1),:,1);
ir_point1(:,:,3) = mean(ir_boot1(1:size(ir_data,1),:,:),3);
ir_point1(:,:,4) = mean(ir_boot_ks(1:size(ir_data,1),:,:),3);

ir_sim_bands1        = percentile3(ir_boot1,.16) ;
ir_sim_bands1(:,:,2) = percentile3(ir_boot1,.84) ;
ir_sim_bands1(:,:,3) = percentile3(ir_boot1,.05) ;
ir_sim_bands1(:,:,4) = percentile3(ir_boot1,.95) ;

% Quantities Figure
figure1 = ir_figure_tlp(ir_point1(1:ir_range,:,:), ir_sim_bands1(1:ir_range,:,:), var_names(1:6), [], {'-k','--g', '-.b',':'},{'True DGP', 'Population', 'Finite Samp. - CCP', 'Finite Samp. - KS'});
saveas(figure1, [dest_dir,'simulation_var.eps'], 'epsc');

