function param = param_trans(param)

