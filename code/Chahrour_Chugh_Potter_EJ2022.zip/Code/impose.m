%Impose a zero impact in the  max-share repsonse.

%sa - index of the variable to max share of
%sb - the variable to impose the zero on
%Ahat - size(beta,1)*nvar matrix based on choleski of shocks

function qout = impose(sa,sb,B,Ahat,kmin,kmax)
sa = selector(sa,size(B,1));
sb = selector(sb,size(B,2));

%Startin point
[~,S0]  = objective(eye(size(Ahat,2)),sa,B,Ahat,kmin,kmax);
[q1,D]  = eig(S0(1:end,1:end));                                           %Get eigenstuffs
[~,idx] = sort(diag(D), 'descend');                                     %Get order of eigenvalues
qout      = q1(:,idx); 



qout = fmincon(@(q)objective(q,sa,B,Ahat,kmin,kmax),qout(:,1),[],[],sb*Ahat,0,[],[],@(q)nleq(q));

end

function [out,S] = objective(q,sa,B,Ahat,kmin,kmax)

%Compute S (forecast error variance at k horizons)
S = 0;
for ll = kmin:kmax
    tmp = sa*B^ll*Ahat*q;
    S = S + tmp'*tmp;
end
out = -S;
end


function [neq,eq]= nleq(q)

neq = [];
eq  = q'*q-1;

end