load formatted_data

clear set;
%Latex
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');
set(groot,'defaultAxesTickLabelInterpreter','latex');  

% VAR Parameters
nvar     = size(yxdat,2);
nwage    = size(wage_all,2);
nper     = 500;                     % Max horizon for IR

%ID of shock 1
targ_var1 = [1];                    %Variable to target in yxdat
kmin1     = 20;                     %Starting period to include in maximand
kmax1     = 80;                     %Last period to include in maximization
norm_idx1 =  1 ;                    %Sign normalized for what variable's response
hor_idx1  =  25;                    %Horizon of normalization

%ID of shock 2
targ_var2 = [1];                                                         
kmin2     = 0;
kmax2     = 0;
norm_idx2 = 1;   
hor_idx2  = 0;   


%Estimate VAR
nlag = 4;
[B,c,errs] = quick_var(yxdat,nlag); B = companion_form(B');
[Bwage,errs_w,XX,YY] = quick_ols(wage_all,yxdat,nlag);
C = zeros(size(B,1),nvar); C(1:nvar, 1:nvar) = c;
Sig = c*c';

%% ID Procedure for point estimate
[cnew, struct_errs,q2] = identify_shocks(B,c,errs,targ_var1,targ_var2,kmin1,kmin2,kmax1,kmax2,norm_idx1,norm_idx2,hor_idx1,hor_idx2);

%Impulse responses
ir_bs = zeros(nper,nvar,nvar); 
ir_wg = zeros(nper,size(wage_all,2),nvar);
bet = B(1:nvar,:)';
for jj = 1:nvar
    %All nvar shocks
    [ir_bs(:,:,jj),~,ir_wg(:,:,jj)] = quick_IR(bet, nper, cnew(:,jj),Bwage');
end
%Store two ID'ed shocks
ir_bs1 = ir_bs(:,:,1); ir_bs2 = ir_bs(:,:,2);
ir_wg1 = ir_wg(:,:,1); ir_wg2 = ir_wg(:,:,2);




%% FEVD of two ID'ed shocks
vshrs1        = cumsum(ir_bs1.^2)./cumsum(sum(ir_bs(:,:,:).^2,3));                          %FEVD of PC#1 shock
vshrs2        = cumsum(ir_bs2.^2)./cumsum(sum(ir_bs(:,:,:).^2,3));                          %FEVD of PC#1 shock

tfp_news = ir_bs1(1:200,1);
tfp_surp = ir_bs2(1:200,1);
save tfp_surp tfp_surp tfp_news


%% Run bootstrap
nboot = 2500; 
rng_seed = linspace(10,2^31,nboot);  %So that we use consistent seeds in parfor
T = size(yxdat,1);

%Preallocate
ir_boot1 = zeros(nper,nvar,nboot);ir_boot2 = zeros(nper,nvar,nboot);
ir_boot_wage1 = zeros(nper,nwage,nboot);ir_boot_wage2 = zeros(nper,nwage,nboot);
delb = zeros(1,nboot);

%Asym correction for process to simulate from
Sig_kil                = zeros(size(B));
Sig_kil(1:nvar,1:nvar) = Sig;
[Bkil,dela]            = asybc(B,Sig_kil,T,nlag,nvar);
abs_eig                = NaN(1,nboot);
%Bkil = B;
parfor nn = 1:nboot
    rng(rng_seed(nn),'twister');
    
    yxsamp = quick_boot(Bkil(1:nvar,:)',errs,length(yxdat)+nlag,150,zeros(nlag,nvar));
    
    %Symthetic wage series
    [~, ~,Xsamp] = quick_ols(0*yxsamp,yxsamp,nlag);

    wgsamp = Xsamp(:,1:end-1)*Bwage + errs_w(randsample(T-nlag,T,'true'),:);
    
    %Drop extra laggs of yxsamp
    yxsamp = yxsamp(nlag+1:end,:);
    
    %Restimate
    [B_n,ctmp_n,mu_n] = quick_var(yxsamp,nlag); B_n = companion_form(B_n');
    [Bwage_n]         = quick_ols(wgsamp,yxsamp,nlag);

    %ID procedure
    c_n = identify_shocks(B_n,ctmp_n,errs,targ_var1,targ_var2,kmin1,kmin2,kmax1,kmax2,norm_idx1,norm_idx2,hor_idx1,hor_idx2,q2);

    %Impulse responses
    [ir_tmp1,~,ir_boot_wage1(:,:,nn)] = quick_IR(B_n(1:nvar,:)', nper, c_n(:,1),Bwage_n');
    [ir_tmp2,~,ir_boot_wage2(:,:,nn)] = quick_IR(B_n(1:nvar,:)', nper, c_n(:,2),Bwage_n');
    
    %Sign re-normalization
    d1 = norm(-ir_tmp1(kmin1+1:kmax1+1,1)-ir_bs1(kmin1+1:kmax1+1,1))-norm(ir_tmp1(kmin1+1:kmax1+1,1)-ir_bs1(kmin1+1:kmax1+1,1));
    d2 = norm(-ir_tmp2(kmin2+1:kmax2+1,1)-ir_bs2(kmin2+1:kmax2+1,1))-norm(ir_tmp2(kmin2+1:kmax2+1,1)-ir_bs2(kmin2+1:kmax2+1,1));
    
    ir_boot1(:,:,nn) = sign(d1)*ir_tmp1;
    ir_boot_wage1(:,:,nn) = sign(d1)*ir_boot_wage1(:,:,nn);
    ir_boot2(:,:,nn) = sign(d2)*ir_tmp2;
    ir_boot_wage2(:,:,nn) = sign(d2)*ir_boot_wage2(:,:,nn);
    
    
    disp(num2str(nn))
end

%Weights for estimation
ir_wghts = std(ir_boot1,[],3).^-1;


%% MAIN VARIABLES FIGURES
ir_range = 40;

% Quantities Figure
ir_bands1        = percentile3(ir_boot1,.05) - percentile3(ir_boot1,.5) + ir_bs1;
ir_bands1(:,:,2) = percentile3(ir_boot1,.95) - percentile3(ir_boot1,.5) + ir_bs1;
ir_bands1(:,:,3) = percentile3(ir_boot1,.16) - percentile3(ir_boot1,.5) + ir_bs1;
ir_bands1(:,:,4) = percentile3(ir_boot1,.84) - percentile3(ir_boot1,.5) + ir_bs1;

ir_bands2        = percentile3(ir_boot2,.05) - percentile3(ir_boot2,.5) + ir_bs2;
ir_bands2(:,:,2) = percentile3(ir_boot2,.95) - percentile3(ir_boot2,.5) + ir_bs2;
ir_bands2(:,:,3) = percentile3(ir_boot2,.16) - percentile3(ir_boot2,.5) + ir_bs2;
ir_bands2(:,:,4) = percentile3(ir_boot2,.84) - percentile3(ir_boot2,.5) + ir_bs2;
ir_bs2(:,:,2) = 0;
ir_bs2(:,1,2) = .79.*[.91.^([0:499]')]; %ir_bs2(1,1,1)


%% Wages Figures
wage_idx = 1:19;

ir_bands_wage1        = percentile3(ir_boot_wage1,.05) - percentile3(ir_boot_wage1,.5) + ir_wg1;
ir_bands_wage1(:,:,2) = percentile3(ir_boot_wage1,.95) - percentile3(ir_boot_wage1,.5) + ir_wg1;
ir_bands_wage1(:,:,3) = percentile3(ir_boot_wage1,.16) - percentile3(ir_boot_wage1,.5) + ir_wg1;
ir_bands_wage1(:,:,4) = percentile3(ir_boot_wage1,.84) - percentile3(ir_boot_wage1,.5) + ir_wg1;
ir_bands_avg1         = nanmean(ir_bands_wage1(:,wage_idx,:),2);

ir_bands_wage2        = percentile3(ir_boot_wage2,.05) - percentile3(ir_boot_wage2,.5) + ir_wg2;
ir_bands_wage2(:,:,2) = percentile3(ir_boot_wage2,.95) - percentile3(ir_boot_wage2,.5) + ir_wg2;
ir_bands_wage2(:,:,3) = percentile3(ir_boot_wage2,.16) - percentile3(ir_boot_wage2,.5) + ir_wg2;
ir_bands_wage2(:,:,4) = percentile3(ir_boot_wage2,.84) - percentile3(ir_boot_wage2,.5) + ir_wg2;
ir_bands_avg2         = nanmean(ir_bands_wage2(:,wage_idx,:),2);


%% Other labor market variable
other_idx = 20:25;

ir_other1       = ir_wg1(:,other_idx,:);
ir_bands_other1 = ir_bands_wage1(:,other_idx,:) ;
other_nms       = wage_names(other_idx);

ir_other2       = ir_wg2(:,other_idx,:);
ir_bands_other2 = ir_bands_wage2(:,other_idx,:) ;
other_nms       = wage_names(other_idx);


%% Tech variables
tech_idx = 26:28;

ir_tech1  = ir_wg1(:,tech_idx,:);
ir_bands_tech1 = ir_bands_wage1(:,tech_idx,:) ;
tech_nms = wage_names(tech_idx);

ir_tech2  = ir_wg2(:,tech_idx,:);
ir_bands_tech2 = ir_bands_wage2(:,tech_idx,:) ;
tech_nms = wage_names(tech_idx);


%% Save results (saved in run_all)
ir_other = ir_other1;
ir_bands = ir_bands1;
ir_bands_wg = ir_bands_wage1;
ir_bands_other = ir_bands_other1;
