ir_range = 40;
aprefs.ylab = {'\% dev. from steady-state',[],[],'percentage points',[],[]};
load model_object *idx 





%% **************************************************************************
% VAR Results - Baseline
%**************************************************************************

% Quantities Figure (full sample)
load var_results_2x
figure1 = ir_figure_tlp(ir_bs(1:ir_range,1:6,1), ir_bands(1:ir_range,1:6,:), var_names(1:6), [], {'-k','-g', '-g'},{'Data', 'Bootstrap Mode'});
saveas(figure1, [dest_dir,'figure_var.eps'], 'epsc');

% Quantities Figure (short sample)
load var_results_2x_short
figure1a = ir_figure_tlp(ir_bs(1:ir_range,1:6,1), ir_bands(1:ir_range,1:6,:), var_names(1:6), [], {'-k','-g', '-g'},{'Data', 'Bootstrap Mode'});
saveas(figure1a, [dest_dir,'figure_var_short.eps'], 'epsc');

%Wages Figure
load var_results_2x
wage_idx = 1:19;
ir_bands_avg = nanmean(ir_bands_wage1(:,wage_idx,:),2);
ir_plot_wage = ir_wg1(:,wage_idx,1);
ir_plot_wage(:,20) = nanmean(ir_wg1(:,wage_idx,1),2);
figure2 = ir_figure_tlp(ir_plot_wage(1:ir_range,:,:),[ir_bands_wage1(1:ir_range,wage_idx,:),ir_bands_avg(1:ir_range,:,:)], wage_names([wage_idx,end]), [], {'-k','-g','-b'},{'Data'},[5,4]);
figure(figure2);
for jj = 1:length(figure2.Children)
    figure2.Children(jj).YLim = 1*[-1,1];
end
figure2.PaperOrientation = 'Portrait';
figure2.PaperSize = [11,15];
figure2.PaperPosition = [.25,.25,12,15];
saveas(figure2, [dest_dir,'figure2.eps'], 'epsc');

%Technology measures Figure
figure3 = ir_figure_tlp(ir_tech1(1:ir_range,:,1),ir_bands_tech1(1:ir_range,:,:),tech_nms,[], {'-k','-g','-b'},{'Data'},[1,3]);
figure3.PaperPosition = [.25,.25,10,4];
saveas(figure3, [dest_dir,'auxvars.eps'], 'epsc');





%% **************************************************************************
% Different TFP measures
%**************************************************************************

load var_results_2x
r_baseline = ir_bs(1:ir_range,1:6,1);
load var_results_2x_lp
r_lp = ir_bs(1:ir_range,1:6,1);
load var_results_2x_unadj
r_unadj = ir_bs(1:ir_range,1:6,1);
r_all(:,:,1)=r_baseline;
r_all(:,:,2)=r_unadj;
r_all(:,:,3)=r_lp;

figure1=ir_figure_tlp(r_all(:,:,1:3), ir_bands(1:ir_range,1:6,:), var_names(1:6), [], {'-k','-.r',':b','--c'},{'Baseline','Raw TFP','Labor Productivity'});
saveas(figure1,[dest_dir,'figure_var_tfp.eps'],'epsc');





%% **************************************************************************
% Alternative ID strategies
%**************************************************************************

%Full sample
load var_results_ccp_18
r_baseline_18 = ir_bs(1:ir_range,1:6,1);
load var_results_bbl_18
r_bbl_18(:,:,1) = r_baseline_18;
r_bbl_18(:,:,2) = ir_bs(1:ir_range,1:6,1);
load var_results_ks_18
r_ks_18(:,:,1) = r_baseline_18;
r_ks_18(:,:,2) = ir_bs(1:ir_range,1:6,1);

%2012 sample
load var_results_ccp_12
r_baseline_12 = ir_bs(1:ir_range,1:6,1);
load var_results_bbl_12
r_bbl_12(:,:,1) = r_baseline_12;
r_bbl_12(:,:,2) = ir_bs(1:ir_range,1:6,1);
load var_results_ks_12
r_ks_12(:,:,1) = r_baseline_12;
r_ks_12(:,:,2) = ir_bs(1:ir_range,1:6,1);

%2007 sample
load var_results_ccp_07
r_baseline_07 = ir_bs(1:ir_range,1:6,1);
load var_results_bbl_07
r_bbl_07(:,:,1) = r_baseline_07;
r_bbl_07(:,:,2) = ir_bs(1:ir_range,1:6,1);
load var_results_ks_07
r_ks_07(:,:,1) = r_baseline_07;
r_ks_07(:,:,2) = ir_bs(1:ir_range,1:6,1);

%Plot
tfpcompare = NaN(40,2,3);
tfpcompare(:,3,[1 2]) = r_ks_18(:,1,:);
tfpcompare(:,3,[1 3]) = r_bbl_18(:,1,:);

tfpcompare(:,2,[1 2]) = r_ks_12(:,1,:);
tfpcompare(:,2,[1 3]) = r_bbl_12(:,1,:);

tfpcompare(:,1,[1 2]) = r_ks_07(:,1,:);
tfpcompare(:,1,[1 3]) = r_bbl_07(:,1,:);

prefs.ylab = {'\% dev. from steady-state', [],[] }; %Ylabel
prefs.ylim = [-.1, -.1, -.1; .6 .6 .6];  %Ylim for each subplot
prefs.lloc = 'northeast';           %Legend, where it goes
prefs.pp   = [.25, .25, 11,4];      %paper position
prefs.tsz  = 14;                    %Subplot title fontsize
figure1    = ir_figure_tlp(tfpcompare, [], {'2007 sample','2012 sample','2018 sample'}, [], {'-k','--b','-.r','-c'},{'Baseline','KS ident. ($\underline{k}=0,\bar{k}=80$)','BBL ident. ($\underline{k}=\bar{k}=20$ + ZIR)'},[1,3],prefs);

saveas(figure1,[dest_dir,'figure_compare_lit.eps'],'epsc');





%% **************************************************************************
% Model - Agnostic Waeg
%**************************************************************************
load var_results_2x ir_bands var_names other_nms ir_other ir_bs ir_bands_other
load agno_results irp_f irp_other

irp_f(:,:,2) = ir_bs(1:size(irp_f,1),:,1);
irp_other(:,:,2) = ir_other(1:size(irp_other,1),:,1);

figure1_q_agno = ir_figure_tlp(irp_f(1:ir_range,:,1:2),ir_bands(1:ir_range,:,:), var_names(1:6), [], {'-k','--k','--k', '--k'},{ 'Model','Data'});
saveas(figure1_q_agno, [dest_dir,'figure1_q_agno.eps'], 'epsc');

figure1_other_agno = ir_figure_tlp(irp_other(1:ir_range,:,1:2),ir_bands_other(1:ir_range,:,:), other_nms , [], {'-k','--k','--k', '--k'},{ 'Model','Data'},[2,3],aprefs);
saveas(figure1_other_agno, [dest_dir,'figure1_other_agno.eps'], 'epsc');





%% **************************************************************************
% Model - Flow wage
%**************************************************************************
load var_results_2x ir_bands var_names other_nms ir_other ir_bs ir_bands_other
load flow_results irp_f irp_other

irp_f(:,:,2) = ir_bs(1:size(irp_f,1),:,1);
irp_other(:,:,2) = ir_other(1:size(irp_other,1),:,1);


figure1_q_flow = ir_figure_tlp(irp_f(1:ir_range,:,1:2),ir_bands(1:ir_range,:,:), var_names(1:6), [], {'-k','--k','--k', '--k'},{ 'Model','Data'});
saveas(figure1_q_flow, [dest_dir,'figure1_q_flow.eps'], 'epsc');

figure1_other_flow = ir_figure_tlp(irp_other(1:ir_range,:,1:2),ir_bands_other(1:ir_range,:,:), other_nms, [], {'-k','--k','--k', '--k'},{ 'Model','Data'},[2,3],aprefs);
saveas(figure1_other_flow, [dest_dir,'figure1_other_flow.eps'], 'epsc');





%% **************************************************************************
% Model - Nash bargaining
%**************************************************************************
load var_results_2x ir_bands var_names other_nms ir_other ir_bs ir_bands_other
load nash_results irp_f irp_other

irp_f(:,:,2) = ir_bs(1:size(irp_f,1),:,1);
irp_other(:,:,2) = ir_other(1:size(irp_other,1),:,1);

figure1 = ir_figure_tlp(irp_f(1:ir_range,:,1:2),ir_bands(1:ir_range,:,:), var_names(1:6), [], {'-k','--k','--k', '--k'},{ 'Model','Data'});
saveas(figure1, [dest_dir,'figure1_q_nash.eps'], 'epsc');

figure1_other_nash = ir_figure_tlp(irp_other(1:ir_range,:,1:2),ir_bands_other(1:ir_range,:,:), other_nms , [], {'-k','--k','--k', '--k'},{ 'Model','Data'},[2,3],aprefs);
saveas(figure1_other_nash, [dest_dir,'figure1_other_nash.eps'], 'epsc');





%% **************************************************************************
% Inflation
%**************************************************************************
load agno_results iry1 infl_idx
inflr(:,1) = 4*iry1(1:ir_range,infl_idx);
load flow_results iry1 infl_idx
inflr(:,2) = 4*iry1(1:ir_range,infl_idx);

figure
plot(inflr(:,1),'o-k','LineWidth',1.4);
hold on;
plot(inflr(:,2),'x-k','LineWidth',1.4);
xlabel('period','FontSize',12);
xticks([10 20 30 40])
yline(0,':k');
ylabel('Implied inflation (\% dev. from steady-state)','FontSize',12);
ylim([-0.4,0.1])
legend('Agnostic wage','Flow-based wage','FontSize',14);
saveas(gcf, [dest_dir,'figure_model_inflation.eps'], 'epsc');





%% **************************************************************************
% Wages
%**************************************************************************
load var_results_2x
load model_object *idx
load agno_results iry1
wagno     = iry1(:,w_idx)      +cumsum([0;iry1(1:end-1,gamx_idx)]);

load nash_results iry1
wnb       = iry1(:,w_idx)      +cumsum([0;iry1(1:end-1,gamx_idx)]);

load flow_results iry1
wdk_act   = iry1(:,w_idx)      +cumsum([0;iry1(1:end-1,gamx_idx)]);

pp = zeros(1,3);
f   = figure;
s   = subplot(1,1,1);
for jj = wage_idx
    plot(ir_wg(:,jj,1), '-', 'Color', [.85,.85,.85], 'LineWidth',1.5); hold on;
end

pp(1) = plot(wagno, '-vk', 'LineWidth',2,'MarkerSize',4);

s.XLim = [1,ir_range];
plot([1,ir_range], [0,0], ':k');

%sparse figure
legend(pp(1),'Agnostic Wage');
saveas(f, [dest_dir, 'figure3_alt.eps'], 'epsc');

%Busy figure
pp(2) = plot(wdk_act, '-xk', 'LineWidth',2);
pp(3) = plot(wnb, '--k', 'LineWidth',2);
%pp(4) = plot(mean(ir_wg(:,wage_idx,1),2), '-k', 'LineWidth',2.5); 
pp(4) = plot(mean(ir_wg(:,1,1),2), '-k', 'LineWidth',2.5); 
legend(pp,'Agnostic Wage', 'Flow Wage', 'Nash Wage', 'Data - Comp./Hr.');
saveas(f, [dest_dir, 'figure3.eps'], 'epsc');





%% **************************************************************************
% Surprise TFP
%**************************************************************************
load var_results_2x
load flow_results

%Second shock
irp_s(:,:,2) = ir_bs2(1:size(irp_s,1),1:6);

%Wage
irw_s        = iry2(1:ir_range,w_idx)      +cumsum([0;iry2(1:ir_range-1,gamx_idx)]);
irw_s(:,:,2) = nanmean(ir_wg2(1:ir_range,wage_idx,1),2);


%Paper figure
newbnds = NaN(ir_range,4,4);
newbnds(:,[1 3 4],:) = ir_bands2(1:ir_range,[1 5 2],:);
newbnds(:,2,:) = ir_bands_avg2(1:ir_range,:,:);
newir = NaN(ir_range,4,2);
newir(:,[1 3 4],:) = irp_s(1:ir_range,[1 5 2],1:2);
newir(:,2,:) = irw_s;
figure_surprise = ir_figure_tlp(newir,newbnds, {'TFP','Wage','Employment','Output'}, [], {'-k','--k','--k', '--k'},{ 'Model','Data'});
figure_surprise.Children(2).YLim = [-0.5,0.5];
%figure_surprise.Children(4).YLim = [-0.4,1];
%figure_surprise.Children(1).YLim = [-0.4,1];
%figure_surprise.Children(4).YLim = [-0.5,1];
%figure_surprise.Children(5).YLim = [-0.5,1];
saveas(figure_surprise, [dest_dir, 'figure_surp.eps'], 'epsc');





%% **************************************************************************
% Beveridge curve
%**************************************************************************
do_bev





%% **************************************************************************
% Suitability
%**************************************************************************
do_simulated_example

