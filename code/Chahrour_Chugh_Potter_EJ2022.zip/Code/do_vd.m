
load formatted_data
load var_results_2x

%% for ks vd rather than baseline
% load ks_results cnew_ks B_ks
% B = B_ks;
% cnew = cnew_ks
%%

nvar = size(yxdat,2);

%Freq.
lam_mr  = [2*pi/32,2*pi/6];
lam_lr  = [2*pi/80,2*pi/32];
lam_vlr = [2*pi/500,2*pi/80];
lam_6_32    = [2*pi/32,2*pi/6];
lam_32_100  = [2*pi/100,2*pi/32];
lam_80_1000 = [2*pi/1000,2*pi/80];
lam_100_500 = [2*pi/500,2*pi/100];

%Compute
A      = eye(size(B,1));
C      = zeros(size(B,1));
C(1:nvar,1:nvar)=cnew;
[shares_mr,variances_mr]   = vdfilter_orig(A,B,C,lam_mr,[],0);
[shares_lr,variances_lr]   = vdfilter_orig(A,B,C,lam_lr,[],0);
[shares_vlr,variances_vlr] = vdfilter_orig(A,B,C,lam_vlr,[],0);
[shares_6_32,variances_6_32]       = vdfilter_orig(A,B,C,lam_6_32,[],0);
[shares_32_100,variances_32_100]   = vdfilter_orig(A,B,C,lam_32_100,[],0);
[shares_80_1000,variances_80_1000] = vdfilter_orig(A,B,C,lam_80_1000,[],0);
[shares_100_500,variances_100_500] = vdfilter_orig(A,B,C,lam_100_500,[],0);

%Tiles
vert = {'Business Cycle (6-32)' 'Medium run (32-100)' 'Long run (100-500)'}';
horiz ={'Frequency (Quarters)' 'TFP' 'Y' 'C' 'I' 'N' 'NYSE'};

%Filename
filename = [dest_dir, 'eer_vd'];

%Creates .text file with table - can use \insert{} command
[table1, prefs] = ltable([shares_6_32(1,1:6);shares_32_100(1,1:6);shares_100_500(1,1:6)], horiz, vert, 'Variance decompositions of VAR variables','table_format_file_vd',filename);

%[table1, prefs] = ltable([shares_6_32(1,1:6);shares_32_100(1,1:6);shares_100_500(1,1:6)], horiz, vert, 'Variance decompositions of VAR variables (Kurmann-Sims identification approach)','table_format_file_vd',filename);


%Creates compilable .tex file with 'insert' command for tables 
make_file(filename, 'file_format', filename);


[shares_6_32(1,1:6);shares_32_100(1,1:6);shares_100_500(1,1:6)]



%VD in time domain
vshrs_td    = cumsum(ir_bs(:,:,1).^2)./cumsum(sum(ir_bs(:,:,:).^2,3));                          %FEVD of PC#1 shock
vshrs_td_0  = vshrs_td(1,:);
vshrs_td_4  = vshrs_td(5,:);
vshrs_td_8  = vshrs_td(9,:);
vshrs_td_12 = vshrs_td(13,:);
vshrs_td_16 = vshrs_td(17,:);
vshrs_td_20 = vshrs_td(21,:);
vshrs_td_40 = vshrs_td(41,:);
vshrs_td_80 = vshrs_td(81,:);
vshrs_td_200 = vshrs_td(201,:);
vshrs_table = [vshrs_td_0;vshrs_td_4;vshrs_td_8;vshrs_td_12;vshrs_td_16;vshrs_td_20;vshrs_td_40;vshrs_td_80;vshrs_td_200];
[vshrs_td_0;vshrs_td_4;vshrs_td_20;vshrs_td_40;vshrs_td_80]
vert2 = {'0' '4' '8' '12' '16' '20' '40' '80' '200'}';
horiz2 = {'Horizon'  'TFP' 'Y' 'C' 'I' 'N' 'NYSE'};
filename2 = [dest_dir,'eer_vd_td'];
[table2,prefs2] = ltable(vshrs_table,horiz2,vert2, 'Variance decomposition of VAR variables (time domain)','table_format_file_vd_td',filename2);
make_file(filename2,'file_format',filename2);



%% What's below were check because surprised at difference in VD for FD and Time Domain. But they check out.
%{
%% Check the VD
Cone = C; Cone(:,2:end) = 0;
N        = 2500;
lam_grid = 2*pi*(0:(N-1))/N; lam_idx = ((lam_grid>2*pi/32) + (lam_grid<2*pi/6))==2;
zgrid    = exp(-1i.*lam_grid);
FFall    = zeros(size(B,1),size(B,2),N);
FFone    = FFall;
for ii = 1:N
    alltmp = inv(eye(size(B))-B*zgrid(ii))*C;
    onetmp = inv(eye(size(B))-B*zgrid(ii))*Cone;
    
    FFall(:,:,ii) = alltmp*alltmp';
    FFone(:,:,ii) = onetmp*onetmp';
end


FFa = real(ifft(FFall(:,:,lam_idx),[],3));
FFo = real(ifft(FFone(:,:,lam_idx),[],3));
diag(FFo(:,:,1))./diag(FFa(:,:,1))


%% IRs
IRs = zeros(size(B,1),size(C,1),500); CVa = zeros(size(B,1),size(B,2),500);
IRs(:,:,1) = C;
CVa(:,:,1)  = C*C';
CVo(:,:,1)  = C(:,1)*C(:,1)';
for ii = 2:500
  IRs(:,:,ii) = B*IRs(:,:,ii-1); 
  CVa(:,:,ii) =IRs(:,:,ii)*IRs(:,:,ii)';
  CVo(:,:,ii) =IRs(:,1,ii)*IRs(:,1,ii)';
end

tmpo = cumsum(CVo,3);
tmpa = cumsum(CVa,3);


tmp = tmpo./tmpa;

diag(tmpo(:,:,50))./diag(tmpa(:,:,50))

figure
plot(squeeze(tmp(6,6,:)))


hold on
plot(vshrs_td(:,6))
%}
