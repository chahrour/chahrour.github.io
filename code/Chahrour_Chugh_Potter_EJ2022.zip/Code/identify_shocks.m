function [c_out,errs_out,q2] = identify_shocks(B,c,errs,targ_var1,targ_var2,kmin1,kmin2,kmax1,kmax2,norm_idx1,norm_idx2,hor_idx1,hor_idx2,q2_init)
 
kmax = max(kmax1,kmax2);
nvar = size(c,1);

%% THE FIRST SHOCK


%IR's of choleski shocks at each horizon
Rtil = zeros(size(c,1),size(c,2),kmax+1);
tmp = eye(size(B));
for jj = 0:kmax
    Rtil(:,:,jj+1) = tmp(1:nvar,1:nvar)*c;
    tmp = B*tmp;
end

%Compute S for relevant horizons
S = zeros(nvar,nvar);
% for ll = 0:kmin1-1
%     S = S - 2*Rtil(targ_var1,:,ll+1)'*Rtil(targ_var1,:,ll+1);
% end

for ll = kmin1:kmax1
    S = S + Rtil(targ_var1,:,ll+1)'*Rtil(targ_var1,:,ll+1);
end

%FD identification
% C = zeros(size(B,1),nvar); 
% C(1:nvar, 1:nvar) = c;
% [tmp1,S] = vdfilter(B,C,[1 2],[2*pi/500,2*pi/40]);

%Do PCA on S
[q1,D]  = eig(S(1:end,1:end));                                          %Get eigenstuffs
[~,idx] = sort(diag(D), 'descend');                                     %Get order of eigenvalues
q1      = q1(:,idx(1));                                                 %Re-order eigenvectors in descending order of eigenvalues

%Sign flip of q1
tmp = B^hor_idx1; 
tmp = tmp(1:nvar,1:nvar)*c*q1;
q1  = sign(tmp(norm_idx1))*q1;

%% THE SECOND SHOCK

%Compute S (forecast error variance at k horizons)
S = zeros(nvar,nvar);
for ll = kmin2:kmax2
   S = S + Rtil(targ_var2,:,ll+1)'*Rtil(targ_var2,:,ll+1);
end

%Numerical step
if nargin < 14
   q2_init = ones(nvar,1); 
end

q2 = findq2_num(S,q1,q2_init);

%Sign flip of q2
tmp = B^hor_idx2; 
tmp = tmp(1:nvar,1:nvar)*c*q2;
q2  = sign(tmp(norm_idx2))*q2;

% Impulse responses
ww       = null([q1,q2]');
c_out    = c*[q1,q2,ww];
errs_out = errs/(c_out');


