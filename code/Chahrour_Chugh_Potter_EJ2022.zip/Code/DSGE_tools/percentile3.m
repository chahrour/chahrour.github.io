function out = percentile3(X,per)

n   = size(X,3);
np  = round(per*n);
X   = sort(X, 3,'ascend');
out = X(:,:,np);
