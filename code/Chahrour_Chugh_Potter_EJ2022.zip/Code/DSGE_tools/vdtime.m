function S = vdtime(B,C,targ_var,kmin,kmax)

nvar = size(C,2);
%Get the forcast errors of the Choleskied shocks
Rtil = zeros(size(C,1),nvar,kmax);
for jj = 1:kmax+1
    Rtil(:,:,jj) = B^(jj-1)*C;%tmp(1:nvar,1:nvar)*c;
end

%Compute S (forecast error variance at k horizons)
S = zeros(nvar,nvar);
for ll = kmin:kmax
    S = S + Rtil(targ_var,:,ll+1)'*Rtil(targ_var,:,ll+1);
end
