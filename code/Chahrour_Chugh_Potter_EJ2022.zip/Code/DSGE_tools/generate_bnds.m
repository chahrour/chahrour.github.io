function [lb,ub] = generate_bnds(varargin)

%parmeters from parameters.m
if nargin>0
    [param,set] = parameters(varargin{1});
else
    [param,set] = parameters();
end
paramv = struct2array(param);
setv = struct2array(set);
np = length(paramv);
pnm = fieldnames(param);
lb = zeros(1,np);
ub = zeros(1,np);


%Priors from prior_listing.m
paramp = bnds_listing;
parampc = struct2cell(paramp);
lnm  = fieldnames(paramp);



for j = 1:np

   idx = strcmp(pnm{j},lnm);
   
   lb(j) = parampc{idx}{4};
   ub(j) = parampc{idx}{5};
  
    
end




