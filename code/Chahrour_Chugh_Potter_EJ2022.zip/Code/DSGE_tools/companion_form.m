function out = companion_form(bet)

ny = size(bet,1);
nl = size(bet,2)/ny;

out = [bet;[eye(ny*(nl-1)),zeros(ny*(nl-1),ny)]];