%This function accepts a fid and returns the next format argument
%from the file.  See commented file below for an example of what we refer 
%to as an argument or format file.
%Usage:
%arg = next_arg(fid)

function arg = next_arg(fid)
    first = 'Nothing';
    while isempty(first) || (first(1) ~= '>') 
        if ~ischar(first)
            error ('Attemp to get argument from beyond end of file.');
        else
            first = fgetl(fid);
        end
    end
    arg = first(2:end);
end

% Sampel Argument File - table_format
%
% This file is used to enter format commands for the latex ouput function in 
% in development.  Every line beginning with a '>' represents aa argument  
% Any amount of space/type can be placed inbetween lines, but arguments must 
% remain in their original order.  Arguments must not extend beyond one line.
% 
% Table will include lines after the each nth col given by the matrix below:
% >[1 5]
% 
% Table will include horizontal lines after each nth row,
% line after titles is always included
% >[ 2 3]
% 
% Make table left(l) or center(c) justified
% >l