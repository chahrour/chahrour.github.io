% LTABLE -  Makes a table given a data matric, titles, and a format file.
%
% Usage:
% [flag, table_obj]  = ltable(data, horiz_axis, vertical_axis, caption, format_file, file name, man_opts)
% where
% data = a data matrix in the form you wish it to appear in the table.
%        Use the matlab key NaN where ever you desire to have a blank
%        entry.
% horiz_axis = the titles that are to appear at the top of the table.
%        given as an object array  - {'title 1', 'title',...}
%        Use my key string 'blank' wherever you wish to have no title.
%        Do not over the look the multi-col option in the format file
%        if you wish to use one title for multiple columns or whish to
%        have more than one row of titles.  Be sure to include the title
%        for the left most col where you wil put the...
% vertical_axis = the titles that will go along the left side, in the
%        same format as above.
% caption = what follows the table number - a string
%        ie: Table 1: Detrended GDP 1990 - 2000
% format_file: the name (or path_name if not in current directory)
%         of the format file for the table.
% outfile_name: the name of the outputed file
% man_opts: manually set table options.
% file name: Enter string for file name for output


function [flag,p,format] = ltable(data, hor_axis, vert_axis, caption, format_file, file_name, varargin)

%Keeps track of format file used in creating table.
if isempty(varargin)>0
    format = table_format(format_file);
else
    format = table_format(format_file, varargin{1});
end

p.format_file = format.file;

%Vertical Text Columns?
format.xtra_vert = size(vert_axis,2)-1;
longtab = 0;%size(vert_axis,1)>25; %tables continued on another page

nw = size(vert_axis,2) + size(data,2);

txt = {};    %Is the object array that keeps track of the file text
i = 1;          %Index keeps track of where in array we are.

%caption is chart title
%center expression give the number of cols of data.
if strcmp(format.pages,'no')
   % txt{i} = '\thispagestyle{empty}';
    i = i+1;
end

%Landscape table?
if strcmp(format.landscape, 'yes')
    txt{i} = '\begin{landscape}';
    i = i+1;
end

if ~longtab
    txt{i} = '\begin{table}';
end
i = i+1;

txt{i} = format.text_size;
i = i+1;

% Add buffers between top and botom of titles
txt{i} = ['\newcommand\T{\rule{0pt}{', format.buff_up, 'ex}}'];
i = i+1;
txt{i} = ['\newcommand\B{\rule[-',format.buff_down, 'ex]{0pt}{0pt}}'];
i = i+1;
txt{i} = '\begin{center}';
i = i+1;
if ~longtab && ~isempty(caption)
    txt{i} =  ['\caption{' caption '} \vspace{.1in}'];
elseif ~isempty(caption)
    txt{i} = ['\topcaption{' caption ,'}'];
end
i = i+1;



if ~longtab
    txt{i}  =['\begin{tabular}{',make_just(data,format),'}  \hline \hline '];
else
    txt{i} = '\xentrystretch{-.1}';    %Adds Hor Titles
    i = i+1;
    txt{i} = ['\tablehead{\hline' titles(hor_axis,format), ' \hline }'];    %Adds Hor Titles
    i = i+1;
    
    txt{i} = ['\tabletail{\hline \multicolumn{', num2str(nw), '} {|c|} {{ Continued on next page ...}} \\ \hline}']; 
    i = i+1;
    txt{i} = ['\begin{xtabular}{',make_just(data,format),'}  \hline '];
end
i = i+1;
txt{i}= ' ';
i = i+1;

if ~longtab
    %Add any multicolumn material
    for j = 1:size(format.multicol,2) -1
        txt{i} = make_multi(j, format);
        i = i+1;
    end
    txt{i} = [titles(hor_axis,format), ' \hline \hline '];    %Adds Hor Titles
    i = i+1;
end

%Concatenates remaining text/data
temp = add_data(data, vert_axis, format);
txt(i:size(temp,2)+i-1) = temp;
i = size(txt,2)+1;

%Closes table
txt{i} = '';
i = i+1;
if ~longtab
    txt{i} = '\end{tabular}';
else
    txt{i} = '\end{xtabular}';
end
i = i+1;
txt{i} = ['\label{', format.label, '}'];
i = i+1;
txt{i} = '\end{center}';
i = i+1;

if ~isempty(format.note)
    txt{i} = ['\tiny{\textit{Note: }' format.note '}'];
    i = i+1;
end

if ~longtab
    txt{i} = '\end{table}';
end
i = i+1;
if strcmp(format.landscape, 'yes')
    txt{i} = '\end{landscape}';
    i = i+1;
end
p.text = txt;

%Put table in .text file
flag = output_table(p,file_name);

%*************************************************************************
% OUTPUT_TABLE - Takes a table object and prints it to file filename.
%*************************************************************************
function flag = output_table(table, filename)

try
    fid = fopen([filename,'.text'], 'w');
    for i = 1:size(table.text,2)
        fprintf(fid, '%s\n',table.text{i});
    end
    fclose(fid);
    flag = 1;
catch 
    warning('Table file was not produced.');
    flag = 0;
end
    





%*************************************************************************
% TITLES - Takes an array of data and put the &'s and tabs in the line
%*************************************************************************
function w = titles(input, f)
%w = ['\hline \hline'];
w = [];
if size(input,2) == 1
    w = [w, style(lout(input{1}),f.text_style,f.font_size), '\\'];

else
    for j = 1:size(input,1)
        for i = 1:size(input,2)-1
            w = [w,style(lout(input{j,i}),f.text_style,f.font_size),'   & '];
        end
        w = [w, style(lout(input{j,i+1}),f.text_style,f.font_size), '\T \B \\'];
    end
end



%*************************************************************************
% ADD_DATA: Takes vertical titles and the data and formats
% them correctly.
%*************************************************************************
function out_str = add_data( data, vert_axis, format)

nrow = size(vert_axis,1);
nslide = size(data,3);
ndcol = size(data,2);
ntcol = size(vert_axis,2)-1;

%Hold aside p-values if need be
if nslide >1
    format.std_err = 1;
    pvalues = data(:,:,2);
    data = data(:,:,1);
else
    format.std_err = 0;
end

%Keep track of which lines and rows to use
line_index = 1;
row_index = 1;

%Keeps track of rows not being used
elim_rows = 0;

%Keeps track of which entry to use nect in object array
array_index = 1;

%Keeping track of headers and parenthesis
[header format.headers] = next_entry( format.headers);
[row_parens, format.parens_row] = next_entry(format.parens_row);
if header == -1
    no_header = 1;      %If there are no headers we ingnore header
    % alignment prefs
else
    no_header = 0;
end


%Convert shading info to matrix

if strcmp(format.row_shade, 'even')
    row_shade = (2:2:size(data,1));
elseif strcmp (format.row_shade, 'odd')
    row_shade = (1:2:size(data,1));
elseif ischar(format.row_shade);
    row_shade = str2num(format.row_shade);
else
    row_shade = format.row_shade;
end

%Allow a secondary col of text
if ntcol > 0
    col_text = vert_axis(:,2:end);
    vert_axis = vert_axis(:,1);
end


%Allows different allignments for row titles
for i = 1:nrow
    p =[];
    star = [];

    %So that we can reuse the parens info every row
    temp_parens = format.parens;
    [parens temp_parens] = next_entry(temp_parens);


    %For rows that have bold group headings
    if i == header
        p = style(lout(vert_axis{i}),format.header_style,'') ;
        [header format.headers] = next_entry(format.headers);
    else
        if no_header == 1               %In case there are NO headers

            p = vert_axis{i};
        else
            if strcmp(format.nonheader, 'indent')
                p = ['\hspace{5pt}',lout(vert_axis{i})];
            else
                p = ['\multicolumn {1}{|',format.nonheader,'|}{',lout(vert_axis{i}),'}'];
            end
        end

    end


    %Add in additional text columns, if any
    for j = 1:ntcol
        p = [p, '& ', lout(col_text{i,j})];
    end


    %Add in data, if any
    for j =1:ndcol

        star = [];
        %Enter data into rows
        %Put in char's for parenthesis is desired
        if j == parens || i == row_parens             %If col is supposed to have parenthesis
            enclose = 1;
            if  i == row_parens && j == size(data,2)
                [row_parens, format.parens_row] = next_entry(format.parens_row);
            else
                [parens, temp_parens] = next_entry(temp_parens);
            end
        else
            enclose = 0;
        end


        %Put P-value info for *'s
        if (format.std_err > 0 )   %Data contains p-values
            %If row is odd

            if pvalues(i,j) <= format.three_star
                star = '***';
            elseif pvalues(i,j) <= format.two_star
                star = '**';
            elseif pvalues(i,j) <= format.one_star
                star = '*';
            else
                star= [];
            end

        end

        if format.std_err == 10 %Data contains t and p-values

            if mod(i,3)==2          %If row is a 2nd row row
                elim_rows = 2;

                if data(i+1,j) <= format.three_star
                    star = '***';
                elseif data(i+1,j) <= format.two_star
                    star = '**';
                elseif data(i+1,j) <= format.one_star
                    star = '*';
                else
                    star= [];
                end
            end
        end
        if elim_rows == 1
            %Then we are 1 row past a t-stat row, so don't at p-values
        else

            p = [p,'    &', lout(data(i,j), ['%',format.digits,'.', num2str(format.decimals(min(length(format.decimals),j))),'f'],enclose), star];
            elim_rows = max(elim_rows-1, 0);
        end

    end


    %Add newline
    p = [p,'\T   \\'];

    if row_index <= size(row_shade, 2) && i==row_shade(row_index)
        shade = '\rowcolor [gray] {.9}';
        row_index = row_index+1;
    else
        shade = [];
    end

    if i<nrow && line_index<= size(format.horiz_lines,2) && i == format.horiz_lines(line_index)-1
        %Add data and line
        out_str{array_index} = [shade, p,'\hline'];
        array_index = array_index+1;
        line_index = line_index + 1;
    elseif i<nrow
        out_str{array_index} = [shade, p];
        array_index = array_index+1;
    else
        %Add bottom line and data
        out_str{array_index} = [shade, p, '\hline'];
    end
end

%*************************************************************************
% MAKE_JUST - This function makes the string of c's l's  or r's  that
% determines where the lines appear in the figure.
%*************************************************************************
function vert_lines = make_just(data,format)
%vert_lines = '|';
vert_lines = '';
first_time = 1;                 %Keeps track so that we may align first col dif't than others

if length(format.justify) == 1
   format.justify(2:size(data,2) + format.xtra_vert+1) = format.justify ;
end

%Counter keeps track of whch entry in lines vector is next
last_line = 0;
for i=1:size(format.vert_lines,2)
    
    for count =last_line:format.vert_lines(i)-1
        if first_time == 1

            vert_lines = [vert_lines, format.vert_just];

        else
            vert_lines = [vert_lines, format.justify(i)];
        end
        first_time = 0;
    end
    last_line = format.vert_lines(i);
    vert_lines = [vert_lines, '|'];
end


for j = (last_line):size(data,2)+format.xtra_vert
    vert_lines = [vert_lines, format.justify(j+1)]; 
end


%*************************************************************************
% MAKE_MULTI - Implement multicolumn commands
%*************************************************************************
function output = make_multi(i, format)
remains = 'temp';
output = [];
%Use to insert starting left line in figure
%This is ugly programming
first_line = '';
while ~isempty(format.multicol{i})

    [word format.multicol{i}]= next_tok(format.multicol{i});
    [size format.multicol{i}] = next_tok(format.multicol{i});
    [cent format.multicol{i}] = next_tok(format.multicol{i});
    output = [output, '\multicolumn {', size,'} {',first_line, cent,'} {',style(lout(word),format.multicol_text,''),'}    &'];
    first_line = [];
end
output = [ output(1:end-1), '\T \\'];

%*************************************************************************
% GET_PARENS - Helper function returns ( and ) if needed.
%*************************************************************************
function par = get_parens(enclose,n)
if enclose ==1
    if n == 1
        par = '(';
    else
        par = ')';
    end
else
    par = [];
end


