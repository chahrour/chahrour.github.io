load formatted_data

%Latex
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');
set(groot,'defaultAxesTickLabelInterpreter','latex');  

% VAR Parameters
nvar     = size(yxdat,2);
nwage    = size(wage_all,2);
nper     = 500; %Horizon for IR
kmin     = 20;
kmax     = 80;                                                          %Periods to include in maximization

targ_var = [1];         %Variable(s) to target in yxdat
norm_idx = 1;           %Which variable to normalize IR sign
hor_idx  = 25;          %Which horizon to normalize IR sign


%Estimate VAR
nlag = 4;
[B,c,errs] = quick_var(yxdat,nlag); B = companion_form(B');
[Bwage,errs_w,XX,YY] = quick_ols(wage_all,yxdat,nlag);
C = zeros(size(B,1),nvar); C(1:nvar, 1:nvar) = c;

%Do PCA on S
S       = vdtime(B,C,targ_var,kmin,kmax);
[q1,D]  = eig(S(1:end,1:end));               %Get eigenstuffs
[~,idx] = sort(diag(D), 'descend');          %Get order of eigenvalues
q1      = q1(:,idx);                         %Re-order eigenvectors in descending order of eigenvalues








%Construct shock
cnew = c;
cnew(1:end,1:end) = cnew(1:end,1:end)*q1;
tmp = B^hor_idx; tmp = tmp(1:nvar,1:nvar)*cnew(1:end,1);
cnew(1:end,1) = sign(tmp(norm_idx,1))*cnew(1:end,1);

struct_errs = errs*(cnew^-1);

% Impulse responses
ir_bs = zeros(nper,nvar,nvar);
ir_wg = zeros(nper,size(wage_all,2),nvar);
for jj = 1:nvar
    [ir_bs(:,:,jj),~,ir_wg(:,:,jj)] = quick_IR(B(1:nvar,:)', nper, cnew(:,jj),Bwage');
end

