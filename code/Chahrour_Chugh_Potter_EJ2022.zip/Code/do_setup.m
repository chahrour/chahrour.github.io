
clear set;

%Where to save files
dest_dir = 'figures_output/';

%Latex
set(groot,'defaulttextinterpreter','latex');
set(groot,'defaultLegendInterpreter','latex');
set(groot,'defaultAxesTickLabelInterpreter','latex');

%Set up paths
addpath('ts_box')                       %Time series objects for intuitive manipulation of timeseries data
addpath('DSGE_tools')                   %Variety of computational tools for solving/evalauating DSGE models 
addpath('latex')                        %Latex toos for automatically generating latex tables
addpath('latex/helper_funcs')

 