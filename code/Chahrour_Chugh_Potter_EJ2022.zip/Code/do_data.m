% DATA FOR QUANTITATIVE ECONOMICS
%
%Data imported from St Federal Reserve FRED database using MATLAB's
%built-in command "fetch" 

date_ranged = date_range;
date_ranged(1) = index(date_range(1),-1,4);

%% BEA National Accounts and Wage Data (downloaded on 12/10/2019)
[a1,b1] = xlsread('data/Section2All_xls.xlsx', 'T20200A-Q');
[a2,b2] = xlsread('data/Section2All_xls.xlsx', 'T20200B-Q');
a1(end,:) = []; a2(end,:) = []; % no government


a = [a1(1:4,:),a2(1:4,:)];
bea_all = ts_make(a(1,:),4,194701);  %All private + govt


%% FRED SERIES
load data/fred_data

%% Main Quanties

%Population Series Smoothed
[~,pop]  = ts_hp(M2Q(ts_fred(qtr.pop)),1600);

%GDP deflator
defl = ts_fred(qtr.def);

%Quarterly Quantities
gdp  = ts_fred(qtr.gdp);
con  = ts_plus(ts_fred(qtr.pcnd), ts_fred(qtr.pcsv));
inv  = ts_plus(ts_fred(qtr.gpdi), ts_fred(qtr.pcdg));

%Per captia & real
gdpv  = ts_div(ts_div(gdp        ,pop),defl);
conv  = ts_div(ts_div(con        ,pop),defl);
invv  = ts_div(ts_div(inv        ,pop),defl);
pcdgv = ts_div(ts_div(ts_fred(qtr.pcdg),pop),defl);

%Employment series
emp = M2Q(ts_fred(mth.emp));
lft = M2Q(ts_fred(mth.lft));
urt = M2Q(ts_fred(mth.urt));

%Hours
hrs     = ts_fred(qtr.hrs);            

%Just per-capita
hrsv  = ts_div(hrs,pop);
empv  = ts_div(emp,pop);
lfpv  = ts_div(lft,pop);

%BEA Compe-per-hour
bea_cmp_hr = ts_div(bea_all,ts_times(hrs,defl));

%% Real Hourly Earnings BLS - CES (M2Q and deflate)
for jj = 1:length(ern_list)
    ces_tmp = ts_fill(ts_div(M2Q(ts_fred(getfield(mth, ern_list{jj,3}))),defl),date_range);
    assignin('base', ern_list{jj,3}, ces_tmp);
end

%% Real Hourly Compensation BLS - LPC (deflate)
for jj = 1:length(comp_list)
    lpc_tmp = ts_div(ts_fred(getfield(qtr, comp_list{jj,3})),defl);
    assignin('base', comp_list{jj,3}, lpc_tmp);
end

%% CPS
cps_ern = ts_fill(ts_div(ts_fred(qtr.cps_ern),defl),date_range);

%% Basu House wages
[a,b]   = xlsread('data/wages.xlsx');
ucst    = ts_fill(ts_make(a(:,4),4,196501, 'User Cost: Basu-House'),date_range);                

%B-H wages are detrended, here we use bea cmp to add back the low frequency
%trend, so that our treatment of B-H wages is consistent with our treatment
%of other wage series.
ymp      = bea_cmp_hr;
ymp.dat  = log(ymp.dat);
[~,trnd] = ts_hp(ymp,160000);
ucst     = ts_plus(ucst,trnd);
ucst.dat = exp(ucst.dat);

%% TFP SERIES (produced on Sept. 5, 2019)
[a,~]      = xlsread('data/quarterly_tfp_update.xlsx', 'quarterly');              
dtfp       = 1/400*a(:,13);                                             
dtfpun     = 1/400*a(:,11);
dutil      = 1/400*a(:,12);
dlp        = 1/400*a(:,5);
dtfp(1)    = 0; %inital normalization of tfp to 0 in log-levels
dtfpun(1)  = 0;
dutil(1)   = 0;
dlp(1)     = 0;
tfpv      = ts_make(exp(cumsum(dtfp)),4,194701);
tfpunv    = ts_make(exp(cumsum(dtfpun)),4,194701);
utilv     = ts_make(exp(cumsum(dutil)),4,194701);
lpv       = ts_make(exp(cumsum(dlp)),4,194701);

%% Nominal Stock price series (download from CRISP at WRDS on June 4, 2019)
[a,b] = xlsread('data/wrds_crisp.xlsx');
nyse_level = 1.473255;
for jj = 1:length(a)-1
    nyse_level(jj+1) = nyse_level(jj)*(1+a(jj+1,2));
end
NYSE = ts_make(nyse_level,4,192504);
NYSE = ts_div(ts_div(NYSE,defl),pop);

%% Additional auxiliary variables

% Help wanted
[a] = xlsread('data/CompositeHWI.xlsx', 'Sheet1');  %Updated by RAC on March 22, 2022
vcn  = ts_fill(M2Q(ts_make(a(:,3),12,195101, 'Barnichon')),date_range);
vcn.dat = 100*vcn.dat*0.035/nanmean(vcn.dat); %To match the JOLTS average level*100

%R&D
aux_rnd     = ts_div(ts_div(ts_fred(qtr.rnd),pop),defl);    %Real per capita R&D expenditures (Kurmann and Sims, 2020)

%Job-finding probability (Unemployment data)
ulev    = ts_fred(mth.ulev);
ulev_st = ts_fred(mth.ulev_st);
aux_jfr = ts_div(ts_plus(ts_minus(ts_lag(ulev,1),ulev),ulev_st),ts_lag(ulev));
aux_jfr.dat = 1-((1-aux_jfr.dat).^3);
aux_jfr = M2Q(aux_jfr);
ulev_q = ts_div(M2Q(ulev),pop);

%Job-finding probability (JOLTS - total nonfarm)
aux_jfr_jolts = ts_div(ts_fred(mth.hires_nfm),ts_plus(ts_fred(mth.ulev),ts_fred(mth.hires_nfm)));         %Definition of p analogous to paper (p = M/S = M/(U+M))
aux_jfr_jolts.dat = 1-((1-aux_jfr_jolts.dat).^3); 
aux_jfr_jolts = ts_fill(M2Q(aux_jfr_jolts),date_range);

%New innovation measures
[a,b]       = xlsread('data/auxdata_baronschmidt.xlsx','Data');            
aux_std1    = ts_fill(ts_make(a(:,3),4,196001, 'Baron & Schmidt, Baseline count'),date_range);                
aux_std2    = ts_fill(ts_make(a(:,4),4,196001, 'Baron & Schmidt, Only first versions'),date_range);                
aux_std3    = ts_fill(ts_make(a(:,5),4,196001, 'Baron & Schmidt, Reference-weighted count'),date_range);                
aux_std4    = ts_fill(ts_make(a(:,6),4,196001, 'Baron & Schmidt, Page-weighted count'),date_range);                

%% Stack Data
wage_all = [];
wage_names = {};

wage_all(:,end+1) = log(vect(bea_cmp_hr ,0,date_range));
wage_names{end+1} = 'Comp/Hour - BEA';

cps_ern = ts_fill(cps_ern,date_range);
wage_all(:,end+1) = log(vect(cps_ern,0,date_range));
wage_names{end+1} = 'Med. Wkly. Earnings - CPS';

ucst = ts_fill(ucst,date_range);
wage_all(:,end+1) = log(vect(ucst,0,date_range));
wage_names{end+1} = 'New Hire Wage - B\&H';


for jj = 1:length(ern_list)
    tmp_wage = ts_fill(eval(ern_list{jj,3}),date_range);
    wage_all = [wage_all, log(vect(tmp_wage,0,date_range))];
    wage_names{end+1} = ern_list{jj,2};
end
  
%The new stuff
wage_all = [wage_all,log(vect(vcn,0,date_range))];
wage_names{end+1} = 'Vacancies';

wage_all = [wage_all,log(vect(hrsv ,0,date_range)) ];
wage_names{end+1} = 'Hours';

wage_all = [wage_all,(vect(urt,0,date_range)./100)];
wage_names{end+1} = 'Unemployment';

wage_all = [wage_all,log(vect(lfpv,0,date_range))];
wage_names{end+1} = 'Labor Force Part.';

wage_all = [wage_all,(vect(aux_jfr,0,date_range))];
wage_names{end+1} = 'JFP - Unemployment data';

wage_all = [wage_all,(vect(aux_jfr_jolts,0,date_range))];
wage_names{end+1} = 'JFP - JOLTS'; % (total nonfarm)

wage_all = [wage_all,log(vect(aux_std1,0,date_range))];
wage_names{end+1} = 'Tech Standards';

wage_all = [wage_all,log(vect(aux_rnd,0,date_range))];
wage_names{end+1} = 'R\&D';

wage_all = [wage_all,4*(log(vect(defl,0,date_range))-log(vect(defl,-1,date_range)))];
wage_names{end+1} = 'Inflation';

%Main data matrix
yxdat = [...
    log(vect(tfpv ,0,date_range)) ...
    log(vect(gdpv ,0,date_range)) ...
    log(vect(conv ,0,date_range)) ...
    log(vect(invv ,0,date_range)) ...
    log(vect(empv ,0,date_range)) ...
    log(vect(NYSE,0,date_range)) ...
    ];

%Alternative measures
if exist('alt_tfp','var')
    if alt_tfp==1; yxdat(:,1) = log(vect(lpv    ,0,date_range)); end
    if alt_tfp==2; yxdat(:,1) = log(vect(tfpunv ,0,date_range)); end
end

%Rescale
yxdat    = 100*yxdat;
wage_all = 100*wage_all;

%Name and save
wage_names{end+1} = 'Average';
var_names = {'TFP', 'Output','Consumption','Investment','Employment','Stock Price'};
save formatted_data urt vcn wage_names var_names yxdat wage_all