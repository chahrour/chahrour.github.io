%STEADY_STATE_FINDER - Find steady-state by trying different initial asset usages

assemble_params

%First get a steady-state
obj = @(x) steady_residual(x,log_idx,ssargs{:});

[xout,fout,flag] = fsolve(obj,xout(1:ny), options);

if sum(abs(fout))>1e-9
%    error('Baseline SS finder solve failed.')
end
disp(['Max resid at x0: ' num2str2(max(abs(obj(xout))))]);
disp(['Max resid at xout: ' num2str2(max(abs(fout)))]);
xout(log_idx) = exp(xout(log_idx));

%Grid to try
ntest = 29;
sgrid = linspace(-4,4,ntest);

[sgrd_aa,sgrd_bb] = ndgrid(sgrid,sgrid);

sgrd_aa = sgrd_aa(:);
sgrd_bb = sgrd_bb(:);

x0test = xout;
x0test(log_idx) = log(xout(log_idx));

%Optimizer options
ss_opt = optimoptions('lsqnonlin');
ss_opt.CheckGradients = false;
ss_opt.SpecifyObjectiveGradient = true;
ss_opt.Display = 'none';

ss_opt2 = optimoptions('fsolve');
ss_opt2.MaxFunEvals = 300;
ss_opt2.Display = 'none';
ss_opt2.SpecifyObjectiveGradient = true;

f0        = zeros(1    ,ntest^2);
fout      = zeros(ny+1,ntest^2);
fout2     = zeros(ny+1,ntest^2)+inf;
xspecial1 = zeros(ny,ntest^2);
parfor mm = 1:ntest^2
    warning off
    flag = nan;
    try
        flag = -1; %Default flag for no solve
        %Fix sbar, solve for remaning values
        obj_2 = @(x) obj2([x;sgrd_aa(mm);sgrd_bb(mm)],log_idx,ny,ssargs{:})
        [xtmp,f0(mm)] = lsqnonlin(obj_2,x0test(1:ny-2),[],[],ss_opt);
       
        
        if f0(mm)<1
            obj = @(x) steady_residual(x,log_idx,ssargs{:})
            
            fout(:,mm) = obj([xtmp;sgrd_aa(mm);sgrd_bb(mm)]);
            [xspecial1(:,mm),fout2(:,mm),flag] = fsolve(obj,[xtmp;sgrd_aa(mm);sgrd_bb(mm)],ss_opt2);
        end
    catch
        flag = -2; %Flag for error occured
    end
    if mod(mm,20) == 0
    disp(['Pt ' sprintf('%i\t',mm), '|resid: ', sprintf('%1.1e',sum(abs(fout2(:,mm)))), '|flag: ', num2str(flag)]);
    end
end


%%

disp('Hey man, here are the steady states I found!')

%Keep only unique steady-states
xspecial  = xspecial1(:,sum(abs(fout2))<1e-8);
[~,idx]   = sort(xspecial(end,:),'ascend');
xspecial  = xspecial(:,idx);
idx_kp    = unique_ss(xspecial(end-1:end,:));
xspecial  = xspecial(:,idx_kp);
xspecial(log_idx,:) = exp(xspecial(log_idx,:));

%% DISPALAY INFO ON STEADY-STATES

table_dat = zeros(7,12);
xspecial_long = zeros(size(xspecial,1)+nx,size(xspecial,2));
frac_ss = zeros(nx,size(xspecial,2));
tmp = zeros(1,size(xspecial,2));
cons_steady = zeros(4,size(xspecial,2));
Xrw_all = zeros(2,size(xspecial,2));
CCs = cell(3,size(xspecial,2));
for jj = size(xspecial,2):-1:1
    xout = xspecial(:,jj);
    expand_steady
    
    disp_steady
    
    xspecial_long(1:ny,jj)   = xout;
    BBX = [mu_aa*Baa_usd,mu_bb*Bbb_usd,...
           mu_aa*Baa_chy,mu_bb*Bbb_chy, ...
           mu_us*Bus_usd, ...
           mu_ch*Bch_chy,...
           mu_us*Bus_row,mu_ch*Bch_row,mu_aa*Baa_row...
         ]';
    xspecial_long(ny+(1:nx),jj) = BBX(1:nx);
    
    steady_stats;  %Store table info for steady-state

end


%%
try
    %save symmetric ss
    if abs(xspecial(end,2))<1e-7
        xout = xspecial(:,2);
        %save xout_tmp xout
    else
        error('no Asymmetric ss');
    end
catch
    disp('no Asymmetric ss');
end


%%
%**************************************************************************
% Compute linear policies
%**************************************************************************
%Initial linear policies
pol_mat = xspecial_long;
nss     = size(pol_mat,2);
hx_cell = cell(1,nss);
gx_cell = cell(1,nss);
ss_use  = false(1,nss);
for jj = 1:nss
    
    pol_mat(log_idx,jj) = log(pol_mat(log_idx,jj));
    
    [a,d_f,d_futr,dfrac_waste,d_past] = dynamic_residual(pol_mat(:,jj),pol_mat(:,jj),pol_mat(ny+(1:nx),jj),log_idx,ny,dynargs{:});
    
    if sum(abs(a))>1e-8
        disp('Uhoh')
        pause
    end
    
    %To accomodate t+1 states, phew!
    fx = [d_past;zeros(nx,nx)];
    fy = [d_f(:,1:ny),zeros(ny+nx,nx);zeros(nx,ny),-eye(nx)];
    fxp =[d_f(:,ny+(1:nx));eye(nx)];
    fyp =[d_futr;zeros(nx,ny+nx)];
    
    
    [gx,hx,flag] = gx_hx_alt(fy,fx,fyp,fxp,1.00000000);
    eigg = nan;
    if ~isempty(hx) && ~isnan(hx(1))
        eigg = sort(abs(eig(hx)));
    end
    
    if flag == 1 && max(max(abs(hx)))<1e8
        %Only use the locally determinant SS
        ss_use(jj) = true;
    end
    
    disp(['Steady-state ' num2str(jj) '|resid: ' num2str2(sum(abs(a))) '|flag: ' num2str(flag), '|eig: ' num2str(eigg(end),'%1.6f') '|usd use:' num2str(Xrw_all(:,jj)','%1.2f ')])
    
    hx_cell{jj} = hx;
    gx_cell{jj} = gx;
end



%% 




%% Objective function for fixed sbar.

function [out,dout] = obj2(x,log_idx,nvarss,varargin)

[out,dout]  = steady_residual(x,log_idx,varargin{:});
out = out(1:end-2);
dout = dout(1:end-2,1:nvarss-2);


end


