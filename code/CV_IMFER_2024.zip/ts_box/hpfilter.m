function [cout,gout]=hpfilter(data,s)
% ---------------------------------------------------------------------%
%  HPFILTER                                                            %
%   y=data series, c=deviations from trend (i.e., 'cyclical' data),    %
%   t=HP trend, s=smoothing parameter (eg, 1600 for std quarterly HP). %
% ---------------------------------------------------------------------%

% use 1600 per default
if nargin < 2 || s < 0; 
  s = 1600;
end

% get rid of nan's
y=data(~isnan(data));

y = y(:); % make y a column vector
T = length(y); 

% setup FOCs
d = spdiags(repmat(s*[1,-4,6,-4,1]+[0,0,1,0,0],T,1),-2:2,T,T); 

d(1,1:3)             = s*[1,-2,1]     + [1,0,0]; 
d(2,1:4)             = s*[-2, 5,-4,1] + [0,1,0,0]; 
d(end-1,(end-3):end) = s*[1, -4,5,-2] + [0,0,1,0]; 
d(end,(end-2):end)   = s*[1,-2,1]     + [0,0,1]; 

% solve the system of equations
g = d\y; 
c = y-g; 

% put back into orgiginal format
cout = data; cout(~isnan(data))=c;
gout = data; gout(~isnan(data))=g;