%Convert eg 194805 to year 1948 and month 5

function [yr,per] = date_split(date_in,nper)

if nargin < 2
    nper = 4;
end

%How many digets to get rid of
sper = max(2,length(num2str(nper)));

yr = floor(date_in/10^sper);

per = date_in-yr*10^sper;