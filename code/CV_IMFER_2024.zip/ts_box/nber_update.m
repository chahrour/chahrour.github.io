url = 'https://fred.stlouisfed.org/';
c = fred(url);

nber = fetch(c,'USRECD');  

NBER = D2M_Fred(nber.Data);

%Fill in NaN into future
NBER.dat(end+1:end+24) = NaN;
NBER.ed = index(NBER.ed,24,12);

save NBER_rec NBER