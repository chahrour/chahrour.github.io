%**************************************************************************
% SYMBOLIC VERSION OF EQUILIBRIUM CONDITIONS FOR QUANTITATIVE MODEL IN
% CHAHROUR AND VALCHEV "TRADE FINANCE AND THE DURABILITY OF THE DOLLAR"
%
% NOTES: for mex reasons, sym variables CANNOT contain any numbers in their
% names
%
setup

%recompute symbolic math (set to zero to save time)
redo_main   = 1;
redo_defsb  = 1;
redo_extra  = 1;
redo_bonds  = 1;

prefs_type = 1;  %0 = mu_i, 1 = mu_^(1/eta)


%Optimize symoblic expressions
optimize    = false;

%distribution of theta shock
sdist = @(t) normcdf(t);
%sdist = @(t) tcdf(t,10);
%sdist = @(t) unifcdf(t,-.5,.5); 
tic

%For ss (= 0) or for dynamics (= 1)
ver_run  = {'steady-state', 'dynamic model'};
for solve_dyn = [1,0]
    
    disp(' ');
    disp(['Simplifying ' ver_run{solve_dyn+1} ' ...']);
    
    %**************************************************************************
    %Symbolic defs
    %**************************************************************************
    
    %Country Size
    syms mu_us   mu_ch   mu_aa   mu_bb
    syms mu_us_p mu_ch_p mu_aa_p mu_bb_p
    syms mu_us_l mu_ch_l mu_aa_l mu_bb_l
    
    %Firm measures
    syms m_us m_ch m_aa m_bb
    
    %Funding choice
    syms Xus Xch Xaa Xbb fXaa fXbb
    
    %Idiosyncratic preference shock params
    syms sige sbar_us sbar_ch sbar_aa sbar_bb Vusd
    
    %Matching function elasticities and level shift
    syms vepsf vepst
    
    %trading values/wholesale price
    syms alph kap pw_us pw_ch pw_aa pw_bb
    
    %funding cost
    syms r
    
    %funding probs
    syms p_us_usd p_us_chy
    syms p_ch_usd p_ch_chy
    syms p_aa_usd p_aa_chy
    syms p_bb_usd p_bb_chy
    
    %hh-side funding probs
    syms ph_us_usd ph_us_chy
    syms ph_ch_usd ph_ch_chy
    syms ph_aa_usd ph_aa_chy
    syms ph_bb_usd ph_bb_chy

    %US import/export probs
    syms pim_us_ch pim_us_aa pim_us_bb
    syms pex_us_ch pex_us_aa pex_us_bb
    
    syms pim_us_ch_ pim_us_aa_ pim_us_bb_ pex_us_ch_ pex_us_aa_  %pex_us_bb_ excluded because sums to 1
    
    %CH import/export probs
    syms pim_ch_us pim_ch_aa pim_ch_bb
    syms pex_ch_us pex_ch_aa pex_ch_bb
    
    syms pim_ch_us_ pim_ch_aa_ pim_ch_bb_ pex_ch_us_ pex_ch_bb_  %pex_ch_aa_ excluded because sums to 1
    
    %Regiona A import/export probs
    syms pim_aa_us pim_aa_ch pim_aa_aa pim_aa_bb
    syms pex_aa_us pex_aa_ch pex_aa_aa pex_aa_bb
    
    syms pim_aa_us_ pim_aa_ch_ pim_aa_rowa_ pim_aa_rowb_ pex_aa_us_ pex_aa_ch_ pex_aa_rowa_ %pex_aa_bb excluded because sums to 1
    
    
    %Regiona B import/export probs
    syms pim_bb_us pim_bb_ch pim_bb_aa pim_bb_bb
    syms pex_bb_us pex_bb_ch pex_bb_aa pex_bb_bb
    
    syms pim_bb_us_ pim_bb_ch_ pim_bb_rowa_ pim_bb_rowb_ pex_bb_us_ pex_bb_ch_ pex_bb_rowb_ %pex_bb_aa excluded because sums to 1
    
    %exogenous currency guys
    syms zusd_aa zusd_bb zchy_aa zchy_bb zrow
    
    %uses per period
    syms upp_usd upp_chy 
    
    % santion parameters
    syms sanc_usd_bb sanc_usd_ch chi  %hitting matching function
    syms btau_ch_usd btau_aa_usd btau_bb_usd  btau_us_chy btau_aa_chy btau_bb_chy     %hitting liquidity earnings
    
    %entry cost
    syms phi
    
    %Preference parameters
    syms bet sig eta
    
    %Bond supplies and prices
    syms Busd   Bchy Baa Bbb
    syms Busd_l Bchy_l
    syms Busd_p Bchy_p
    syms Qusd   Qchy Qrow
    
    %Adjustment cost
    syms tau taup
    
    %taxes on imports
    syms tax_us_ch tax_us_aa tax_us_bb
    syms tax_ch_us tax_ch_aa tax_ch_bb
    syms tax_aa_us tax_aa_ch tax_aa_rowa tax_aa_rowb
    syms tax_bb_us tax_bb_ch tax_bb_rowa tax_bb_rowb
     
    %taxes on exports
    syms etax_ch_us etax_aa_us etax_bb_us ...%Export taxes US
        etax_us_ch etax_aa_ch etax_bb_ch ... %Export taxes CH
        etax_us_aa etax_ch_aa etax_bb_aa ... %Export taxes Region A
        etax_us_bb etax_ch_bb etax_aa_bb     %Export taxes Region B
     
    %taxes on financing costs
    syms xtax_ch_usd xtax_aa_usd xtax_bb_usd 
    syms xtax_us_chy xtax_aa_chy xtax_bb_chy

    %fixed bonds parameters (sanctions experiments)
    syms BBbb_usd
        
    %US variables
    syms Cus_us Cus_ch Cus_rowa Cus_rowb 
    syms Pus_us Pus_ch Pus_rowa Pus_rowb Pus
    syms Bus_usd Bus_chy Yus Yus_p Yus_l Gus
    
    %CH variables
    syms Cch_ch Cch_us Cch_rowa Cch_rowb 
    syms Pch_ch Pch_us Pch_rowa Pch_rowb Pch
    syms Bch_usd Bch_chy Ych Ych_p Ych_l Gch
    
    %Regiona A variables
    syms Caa_aa Caa_us Caa_ch Caa_rowa Caa_rowb 
    syms Paa_aa Paa_us Paa_ch Paa_rowa Paa_rowb Paa
    syms Baa_usd Baa_chy Yaa Yaa_p Yaa_l Gaa
    
    %Regiona b variables
    syms Cbb_bb Cbb_us Cbb_ch Cbb_rowa Cbb_rowb 
    syms Pbb_bb Pbb_us Pbb_ch Pbb_rowa Pbb_rowb Pbb
    syms Bbb_usd Bbb_chy Ybb Ybb_p Ybb_l Gbb
    
    %Aggregate (no per-capita) bonds
    syms Bus_usda Bus_chya Bch_usda Bch_chya Baa_usda Baa_chya Bbb_usda Bbb_chya Bus_rowa Bch_rowa Baa_rowa Bbb_rowa
    
    %Pref Parameters
    syms a_us   a_ch   a_aa   a_bb
    syms a_us_p a_ch_p a_aa_p a_bb_p
    syms a_us_l a_ch_l a_aa_l a_bb_l
    
    %Goverment spending share
    syms phi_usg phi_chg phi_aag phi_bbg
    
    %Endowment changes
    syms dYus dYch dYaa dYbb
    
    %Calvo parameter for reset currency
    syms omg
    
    %Periods per year
    syms per_p_year;
    
    %Fix X
    syms fixx
    
    %Eventually fix repetition of this with shell model
    jump_vars    = [        Cus_ch,   Cus_rowa Cus_rowb, ...
        Cch_us,           Cch_rowa Cch_rowb, ...
        Caa_us, Caa_ch  , Caa_rowa Caa_rowb,...
        Cbb_us, Cbb_ch  , Cbb_rowa Cbb_rowb,...
        Qusd, Qchy,Qrow,...
        Pus_us,         Pus_ch,              Pus_rowb  Pus,...
        Pch_ch, Pch_us,          Pch_rowa  ,           Pch,...
        Paa_aa,          Paa_ch,  Paa_rowa  , Paa_rowb Paa,... %Paa_aa is numeraire
        Pbb_bb, Pbb_us,          Pbb_rowa  , Pbb_rowb  Pbb,...
        m_us, m_ch, m_aa m_bb];
    
    jump_vars    = [        Cus_ch,   Cus_rowa Cus_rowb, ...
        Cch_us,           Cch_rowa Cch_rowb, ...
        Caa_us, Caa_ch  , Caa_rowa Caa_rowb,...
        Cbb_us, Cbb_ch  , Cbb_rowa Cbb_rowb,...
        Qusd, Qchy, Qrow,...
        Pus_us,         Pus_ch,              Pus_rowb  Pus_rowa,...
        Pch_ch, Pch_us,          Pch_rowa  ,           Pch_rowb,...
        Paa_aa,          Paa_ch,  Paa_rowa  , Paa_rowb Paa_us,... %Paa_aa is numeraire
        Pbb_bb, Pbb_us,          Pbb_rowa  , Pbb_rowb  Pbb_ch,...
        m_us, m_ch, m_aa m_bb];
    
    plev = [        pim_us_ch_ pim_us_aa_ pim_us_bb_ pex_us_ch_ pex_us_aa_,...
        pim_ch_us_ pim_ch_aa_ pim_ch_bb_ pex_ch_us_ pex_ch_bb_,...
        pim_aa_us_ pim_aa_ch_ pim_aa_rowa_ pim_aa_rowb_ pex_aa_us_ pex_aa_ch_ pex_aa_rowa_ ...
        pim_bb_us_ pim_bb_ch_ pim_bb_rowa_ pim_bb_rowb_ pex_bb_us_ pex_bb_ch_ pex_bb_rowb_];
                
    jump_vars = [jump_vars, plev, sbar_aa sbar_bb];
 
    
    if solve_dyn
        state_vars   = [Baa_usda, Bbb_usda,...
                        Baa_chya, Bbb_chya,...
                        Bus_usda,  ... %Residual Bus_chya   
                        Bch_chya, ... %Residual Bch_usda
                        Bus_rowa, Bch_rowa Baa_rowa  %Residual Bbb_rowa   
                        ];              
    else
        state_vars   = [];
    end
    
    jump_prime   = make_prime(jump_vars);
    state_lag    = make_lag(state_vars);
    state_prime  = make_prime(state_vars);
    vcombo_ss    = [jump_vars,state_vars];
    
    %Track all the input arguments to main solver
    clear *_idx
    nx = length(state_vars);
    ny = length(jump_vars);
    make_index(vcombo_ss);
    if solve_dyn
    save saved_results/idx_vars *_idx nx ny
    end
    
    syms Pnumer %dummy cargument below to remove
    param_list = [
        tau       ...   %Adjusmtent costs
        taup      ...   %Coef. on forward looking portion of adj. cost
        alph      ...   %nash bargain
        vepsf vepst ... %Matching fcns
        kap phi r...    %Trade game
        sige ...        %ido prefs
        phi_usg phi_chg phi_aag phi_bbg ... %government spending shares
        bet sig eta ...%Preferences
        Pnumer  ... %Numeraire
        Xus Xch ... %us,eu cutoffs
        zrow ...
        upp_usd upp_chy sanc_usd_bb sanc_usd_ch chi btau_ch_usd btau_aa_usd btau_bb_usd  btau_us_chy btau_aa_chy btau_bb_chy ... %uses-per-period & matching tech
        per_p_year ...        %Periods-per-year
         fXaa fXbb fixx... %Fix X exogenously
        Baa Bbb %Fixed ROW bond supplies
        ]; 
    
     %zusd_aa zusd_bb zchy_aa zchy_bb zrow       ... %exogenous fraction using each currency.
         
            %tax_us_ch tax_us_aa tax_us_bb ... %Import taxes US
        %tax_ch_us tax_ch_aa tax_ch_bb ... %Import taxes CH
        %tax_aa_us tax_aa_ch tax_aa_rowa tax_aa_rowb ... %Import taxes Region A
        %tax_bb_us tax_bb_ch tax_bb_rowa tax_bb_rowb ... %Import taxes Region B
%                 etax_ch_us etax_aa_us etax_bb_us ... %Export taxes US
%         etax_us_ch etax_aa_ch etax_bb_ch ... %Export taxes CH
%         etax_us_aa etax_ch_aa etax_bb_aa ... %Export taxes Region A
%         etax_us_bb etax_ch_bb etax_aa_bb ... %Export taxes Region B

%xtax_ch_usd xtax_aa_usd xtax_bb_usd ... %USD usage taxes
%        xtax_us_chy xtax_aa_chy xtax_bb_chy ... %CHY usage taxes
       
    
     %Paramters that can change over time
     
    taxt = [tax_us_ch tax_us_aa tax_us_bb ... %Import taxes US
        tax_ch_us tax_ch_aa tax_ch_bb ... %Import taxes CH
        tax_aa_us tax_aa_ch tax_aa_rowa tax_aa_rowb ... %Import taxes Region A
        tax_bb_us tax_bb_ch tax_bb_rowa tax_bb_rowb ... %Import taxes Region B
        etax_ch_us etax_aa_us etax_bb_us ... %Export taxes US
        etax_us_ch etax_aa_ch etax_bb_ch ... %Export taxes CH
        etax_us_aa etax_ch_aa etax_bb_aa ... %Export taxes Region A
        etax_us_bb etax_ch_bb etax_aa_bb ... %Export taxes Region B
        xtax_ch_usd xtax_aa_usd xtax_bb_usd ... %USD usage taxes
        xtax_us_chy xtax_aa_chy xtax_bb_chy ... %CHY usage taxes
       ];  
        
    
    %% Parameters that we vary in experiments over time.
    param_listt = [Busd  ,Bchy  ,Yus  ,Ych  ,Yaa, Ybb, mu_us  ,mu_ch  ,mu_aa, mu_bb, a_us, a_ch, a_aa, a_bb, BBbb_usd, zusd_aa zusd_bb zchy_aa zchy_bb taxt]; %Time-t versions
    param_listp = make_prime(param_listt);
    param_listl = make_lag(param_listt); %T-1 versions
    
    param_list_ss = [param_listt,param_list];
    param_list_dy = [param_listt,param_listl,param_listp,param_list];
    
    args_param_ss = args_string(param_list_ss);
    args_param_dy = args_string(param_list_dy);
    
    %This is all just to make arguments automatically populate if order
    %changes
    str_param_ss = ['ssargs = {'];
    for ii = 1:length(param_list_ss)
        str_param_ss = [str_param_ss,char(param_list_ss(ii)), ','];
    end
    str_param_ss(end:end+1) = '};';
    
    str_param_dy = ['dynargs = {'];
    for ii = 1:length(param_list_dy)
        str_param_dy = [str_param_dy,char(param_list_dy(ii)), ','];
    end
    str_param_dy(end:end+1) = '};';
    
    disp(str_param_ss)
    disp(str_param_dy)
    
    str_param_ss_tocopy = ['% Copy this to calibration_finder subfunction:' newline '% ' str_param_ss(11:end-2),');'];
    str_param_dy_tocopy = ['% Copy this to calibration_finder2 subfunction:' newline '% ' str_param_dy(12:end-2),');'];
    text_insert('tofill_files/assemble_params.text', 'auto_generated/assemble_params.m', {str_param_ss,str_param_dy,str_param_ss_tocopy,str_param_dy_tocopy});
    
    
    
    disp('This is copied to prime_up.m')
    str_prime = [];
    str_shoot1 = [];
    str_shoot2 = [];
    for ii = 1:length(param_listt)
       str1 = [ char(param_listp(ii)) ' = ' char(param_listt(ii)) ';' newline];
       str2 = [ char(param_listl(ii)) ' = ' char(param_listt(ii)) ';'];
       str_prime  = [str_prime,newline,str1,str2];
       
       str_shoot1 = [str_shoot1, char(param_listt(ii)) 'v = zeros(1,T+2); ' char(param_listt(ii)) 'v(:) = '  char(param_listt(ii)) ';' newline  ];
       str_shoot2 = [ str_shoot2  char(param_listt(ii)) '   = '    char(param_listt(ii)) 'v(jj+1);' newline];
       str_shoot2 = [ str_shoot2  char(param_listt(ii)) '_l = '    char(param_listt(ii)) 'v(jj);' newline];
       str_shoot2 = [ str_shoot2  char(param_listt(ii)) '_p = '    char(param_listt(ii)) 'v(jj+2);' newline newline];
    end
    disp(str_prime)
    disp(str_shoot1)
    disp(str_shoot2)
    text_insert('tofill_files/prime_up.text', 'auto_generated/prime_up.m', {str_prime});
    
   

    
    %%
    %**************************************************************************
    % BUNCH OF DEFINITIONS FROM GE
    %**************************************************************************
    
    %Trade flow direction (transformation so prob variables are between 0 and 1
    
    %US
    pim_us_ch  = (1                                                             )*pim_us_ch_;
    pim_us_aa  = (1 - pim_us_ch                                                 )*pim_us_aa_;
    pim_us_bb  = (1 - pim_us_ch - pim_us_aa                                     )*pim_us_bb_;
    pex_us_ch  = (1 - pim_us_ch - pim_us_aa - pim_us_bb                         )*pex_us_ch_;
    pex_us_aa  = (1 - pim_us_ch - pim_us_aa - pim_us_bb - pex_us_ch             )*pex_us_aa_;
    pex_us_bb  = (1 - pim_us_ch - pim_us_aa - pim_us_bb - pex_us_ch - pex_us_aa );
    
    %CH
    pim_ch_us  = (1                                                             )*pim_ch_us_;
    pim_ch_bb  = (1 - pim_ch_us                                                 )*pim_ch_bb_;
    pim_ch_aa  = (1 - pim_ch_us - pim_ch_bb                                     )*pim_ch_aa_;
    pex_ch_us  = (1 - pim_ch_us - pim_ch_bb - pim_ch_aa                         )*pex_ch_us_;
    pex_ch_bb  = (1 - pim_ch_us - pim_ch_bb - pim_ch_aa - pex_ch_us             )*pex_ch_bb_;
    pex_ch_aa  = (1 - pim_ch_us - pim_ch_bb - pim_ch_aa - pex_ch_us - pex_ch_bb );
    
    
    %Region A
    pim_aa_us  = (1                                                              )*pim_aa_us_;
    pim_aa_ch  = (1 - pim_aa_us                                                  )*pim_aa_ch_;
    pim_aa_aa  = (1 - pim_aa_us - pim_aa_ch                                      )*pim_aa_rowa_;
    pim_aa_bb  = (1 - pim_aa_us - pim_aa_ch - pim_aa_aa                          )*pim_aa_rowb_;
  
    
    pex_aa_us  = (1 - pim_aa_us - pim_aa_ch - pim_aa_aa - pim_aa_bb                                       )*pex_aa_us_;
    pex_aa_ch  = (1 - pim_aa_us - pim_aa_ch - pim_aa_aa - pim_aa_bb - pex_aa_us                           )*pex_aa_ch_;
    pex_aa_aa  = (1 - pim_aa_us - pim_aa_ch - pim_aa_aa - pim_aa_bb - pex_aa_us - pex_aa_ch               )*pex_aa_rowa_;
    pex_aa_bb  = (1 - pim_aa_us - pim_aa_ch - pim_aa_aa - pim_aa_bb - pex_aa_us - pex_aa_ch - pex_aa_aa   );
    
    %Region B
    pim_bb_us  = (1                                                              )*pim_bb_us_;
    pim_bb_ch  = (1 - pim_bb_us                                                  )*pim_bb_ch_;
    pim_bb_bb  = (1 - pim_bb_us - pim_bb_ch                                      )*pim_bb_rowb_;
    pim_bb_aa  = (1 - pim_bb_us - pim_bb_ch - pim_bb_bb                          )*pim_bb_rowa_;
  
    
    pex_bb_us  = (1 - pim_bb_us - pim_bb_ch - pim_bb_bb - pim_bb_aa                                       )*pex_bb_us_;
    pex_bb_ch  = (1 - pim_bb_us - pim_bb_ch - pim_bb_bb - pim_bb_aa - pex_bb_us                           )*pex_bb_ch_;
    pex_bb_bb  = (1 - pim_bb_us - pim_bb_ch - pim_bb_bb - pim_bb_aa - pex_bb_us - pex_bb_ch               )*pex_bb_rowb_;
    pex_bb_aa  = (1 - pim_bb_us - pim_bb_ch - pim_bb_bb - pim_bb_aa - pex_bb_us - pex_bb_ch - pex_bb_bb   );


    %Transform p_ variables so that probabilities remain between 0 and 1
    pexp = exp(plev)./(1+exp(plev));
    
    ptrans = {'pim_us_ch', 'pim_us_aa', 'pim_us_bb', 'pex_us_ch', 'pex_us_aa', 'pex_us_bb',...
              'pim_ch_us', 'pim_ch_aa', 'pim_ch_bb', 'pex_ch_us', 'pex_ch_aa', 'pex_ch_bb',...
              'pim_aa_us', 'pim_aa_ch', 'pim_aa_aa', 'pim_aa_bb', 'pex_aa_us', 'pex_aa_ch', 'pex_aa_aa', 'pex_aa_bb',...
              'pim_bb_us', 'pim_bb_ch', 'pim_bb_aa', 'pim_bb_bb', 'pex_bb_us', 'pex_bb_ch', 'pex_bb_aa', 'pex_bb_bb'};
    
            
    for ii = 1:length(ptrans)
       eval([ptrans{ii}, '= subs(' ptrans{ii}, ',plev,pexp);']);
    end

    %Temp thing for error checking
    ptransv = [pim_us_ch, pim_us_aa, pim_us_bb, pex_us_ch, pex_us_aa, pex_us_bb,...
              pim_ch_us, pim_ch_aa, pim_ch_bb, pex_ch_us, pex_ch_aa, pex_ch_bb,...
              pim_aa_us, pim_aa_ch, pim_aa_aa, pim_aa_bb, pex_aa_us, pex_aa_ch, pex_aa_aa, pex_aa_bb,...
              pim_bb_us, pim_bb_ch, pim_bb_aa, pim_bb_bb, pex_bb_us, pex_bb_ch, pex_bb_aa, pex_bb_bb];
    
          
   matlabFunction(ptransv.', 'File', 'auto_generated/ptransv.m',  'Vars',{plev}, 'Optimize', optimize);
       % end error check here  
   
    
    
    mu_us_ch  = mu_ch/(mu_ch + mu_aa + mu_bb);
    mu_us_aa  = mu_aa/(mu_ch + mu_aa + mu_bb);
    mu_us_bb  = mu_bb/(mu_ch + mu_aa + mu_bb);
    
    mu_ch_us  = mu_us/(mu_us + mu_aa + mu_bb);
    mu_ch_aa  = mu_aa/(mu_us + mu_aa + mu_bb);
    mu_ch_bb  = mu_bb/(mu_us + mu_aa + mu_bb);
    
    
    world_mass = (mu_us + mu_ch + mu_aa + mu_bb);
    mu_aa_us  = mu_us/world_mass;
    mu_aa_ch  = mu_ch/world_mass;
    mu_aa_aa  = mu_aa/world_mass;
    mu_aa_bb  = mu_bb/world_mass;
    
    mu_bb_us  = mu_us/world_mass;
    mu_bb_ch  = mu_ch/world_mass;
    mu_bb_aa  = mu_aa/world_mass;
    mu_bb_bb  = mu_bb/world_mass;
    
    %Redefine sbar in units of SD of idio noise (moved to later)
    if solve_dyn == 0 || ~xstate
        Xaa = zusd_aa +(1-zusd_aa-zchy_aa)*(1-sdist(sbar_aa));
        Xbb = zusd_bb +(1-zusd_bb-zchy_bb)*(1-sdist(sbar_bb));
    end
    
    %Home consumption as residual
    Cus_us  = 1/mu_us*((1-phi_usg)*mu_us*Yus           -       0      - mu_ch*Cch_us - mu_aa*Caa_us   - mu_bb*Cbb_us);
    Cch_ch  = 1/mu_ch*((1-phi_chg)*mu_ch*Ych           - mu_us*Cus_ch -    0         - mu_aa*Caa_ch   - mu_bb*Cbb_ch);
    Caa_aa  = 1/mu_aa*((1-phi_aag)*mu_aa*Yaa           - mu_us*Cus_rowa - mu_ch*Cch_rowa - mu_aa*Caa_rowa - mu_bb*Cbb_rowa);
    Cbb_bb  = 1/mu_bb*((1-phi_bbg)*mu_bb*Ybb           - mu_us*Cus_rowb - mu_ch*Cch_rowb - mu_aa*Caa_rowb - mu_bb*Cbb_rowb);
    
    % CD aggregation
    us_shares = [a_us, (1-a_us)*[         mu_us_ch,mu_us_aa,mu_us_bb]];
    ch_shares = [a_ch, (1-a_ch)*[mu_ch_us,         mu_ch_aa,mu_ch_bb]];
    aa_shares = [a_aa, (1-a_aa)*[mu_aa_us,mu_aa_ch,mu_aa_aa,mu_aa_bb]];
    bb_shares = [a_bb, (1-a_bb)*[mu_bb_us,mu_bb_ch,mu_bb_aa,mu_bb_bb]];
    
    tax_us = [0                  tax_us_ch, tax_us_aa,  tax_us_bb];
    tax_ch = [0        tax_ch_us            tax_ch_aa   tax_ch_bb];
    tax_aa = [0        tax_aa_us tax_aa_ch  tax_aa_rowa tax_aa_rowb];
    tax_bb = [0        tax_bb_us tax_bb_ch  tax_bb_rowa tax_bb_rowb];
    
    
    % CD aggregation
    
    cons_us = prod(us_shares.^us_shares);
    cons_ch = prod(ch_shares.^ch_shares);
    cons_aa = prod(aa_shares.^aa_shares);
    cons_bb = prod(bb_shares.^bb_shares);
    
    %{
    Cus = prod([Cus_us,       Cus_ch, Cus_rowa  ,Cus_rowb].^us_shares);
    Cch = prod([Cch_ch,Cch_us,        Cch_rowa  ,Cch_rowb].^ch_shares);
    Caa = prod([Caa_aa,Caa_us,Caa_ch, Caa_rowa  ,Caa_rowb].^aa_shares);
    Cbb = prod([Cbb_bb,Cbb_us,Cbb_ch, Cbb_rowa  ,Cbb_rowb].^bb_shares);
    
    %Note this is fancy for def subs...necessary?
    %Pus_rw  = 1/(1+tax_us_rw) *(Pus*cons_us*(Pus_us)^-(ah_us)*((1+tax_us_eu)*Pus_eu)^-((1-ah_us)*wus_eu))^(1/((1-ah_us)*wus_rw));
    
%     Pus_rowa = 1/(1+tax_us_aa)*(Pus*cons_us*prod([Pus_us,(1+tax_us_ch)*Pus_ch,(1+tax_us_bb)  *Pus_rowb].^-us_shares([1,2,4])))^(1/us_shares(3));
%     Pch_rowb = 1/(1+tax_ch_bb)*(Pch*cons_ch*prod([Pch_ch,(1+tax_ch_us)*Pch_us,(1+tax_ch_aa)  *Pch_rowa].^-ch_shares([1,2,3])))^(1/ch_shares(4));
%     Paa_us   = 1/(1+tax_aa_us)*(Paa*cons_aa*prod([Paa_aa,(1+tax_aa_ch)*Paa_ch,(1+tax_aa_rowa)*Paa_rowa,(1+tax_aa_rowb)*Paa_rowb].^-aa_shares([1,3,4,5])))^(1/aa_shares(2));
%     Pbb_ch   = 1/(1+tax_bb_ch)*(Pbb*cons_bb*prod([Pbb_bb,(1+tax_bb_us)*Pbb_us,(1+tax_bb_rowa)*Pbb_rowa,(1+tax_bb_rowb)*Pbb_rowb].^-bb_shares([1,2,4,5])))^(1/bb_shares(3));
%    
    %This is the straight-forward way
   Pus =     1/cons_us*prod( [Pus_us,                       (1+tax_us_ch)*Pus_ch, (1+tax_us_aa  )*Pus_rowa  , (1+tax_us_bb  )*Pus_rowb].^us_shares);
   Pch =     1/cons_ch*prod( [Pch_ch, (1+tax_ch_us)*Pch_us,                       (1+tax_ch_aa  )*Pch_rowa  , (1+tax_ch_bb  )*Pch_rowb].^ch_shares);
   Paa =     1/cons_aa*prod( [Paa_aa, (1+tax_aa_us)*Paa_us, (1+tax_aa_ch)*Paa_ch, (1+tax_aa_rowa)*Paa_rowa  , (1+tax_aa_rowb)*Paa_rowb].^aa_shares);
   Pbb =     1/cons_bb*prod( [Pbb_bb, (1+tax_bb_us)*Pbb_us, (1+tax_bb_ch)*Pbb_ch, (1+tax_bb_rowa)*Pbb_rowa  , (1+tax_bb_rowb)*Pbb_rowb].^bb_shares);
   

    
    %}
    
    % CES aggregation
    if prefs_type == 0
        Cus = sum(us_shares.*([Cus_us,       Cus_ch, Cus_rowa  ,Cus_rowb].^((eta-1)/eta)))^(eta/(eta-1));
        Cch = sum(ch_shares.*([Cch_ch,Cch_us,        Cch_rowa  ,Cch_rowb].^((eta-1)/eta)))^(eta/(eta-1));
        Caa = sum(aa_shares.*([Caa_aa,Caa_us,Caa_ch, Caa_rowa  ,Caa_rowb].^((eta-1)/eta)))^(eta/(eta-1));
        Cbb = sum(bb_shares.*([Cbb_bb,Cbb_us,Cbb_ch, Cbb_rowa  ,Cbb_rowb].^((eta-1)/eta)))^(eta/(eta-1));
    else
        Cus = sum(us_shares.^(1/eta).*([Cus_us,       Cus_ch, Cus_rowa  ,Cus_rowb].^((eta-1)/eta)))^(eta/(eta-1));
        Cch = sum(ch_shares.^(1/eta).*([Cch_ch,Cch_us,        Cch_rowa  ,Cch_rowb].^((eta-1)/eta)))^(eta/(eta-1));
        Caa = sum(aa_shares.^(1/eta).*([Caa_aa,Caa_us,Caa_ch, Caa_rowa  ,Caa_rowb].^((eta-1)/eta)))^(eta/(eta-1));
        Cbb = sum(bb_shares.^(1/eta).*([Cbb_bb,Cbb_us,Cbb_ch, Cbb_rowa  ,Cbb_rowb].^((eta-1)/eta)))^(eta/(eta-1));
        
    end

%     Pus = (sum(us_shares.*((1+tax_us).*[Pus_us,Pus_ch,Pus_rowa,Pus_rowb]).^(1-eta)))^(1/(1-eta));
%     Pch = (sum(ch_shares.*((1+tax_ch).*[Pch_ch,Pch_us,Pch_rowa,Pch_rowb]).^(1-eta)))^(1/(1-eta));
%     Paa = (sum(aa_shares.*((1+tax_aa).*[Paa_aa,Paa_us,Paa_ch, Paa_rowa,Paa_rowb]).^(1-eta)))^(1/(1-eta));
%     Pbb = (sum(bb_shares.*((1+tax_bb).*[Pbb_bb,Pbb_us,Pbb_ch, Pbb_rowa,Pbb_rowb]).^(1-eta)))^(1/(1-eta));
%    

    %{
    Pus_rowa = ((Pus^(1-eta) - sum(us_shares([1,2,4]  ).^eta.*((1+tax_us([1,2,4]))  .*[Pus_us,Pus_ch,Pus_rowb]         ).^(1-eta)))/(us_shares(3)^eta*(1+tax_us(3))^(1-eta)))^(1/(1-eta));
    Pch_rowb = ((Pch^(1-eta) - sum(ch_shares([1,2,3]  ).^eta.*((1+tax_ch([1,2,3]))  .*[Pch_ch,Pch_us,Pch_rowa]         ).^(1-eta)))/(ch_shares(4)^eta*(1+tax_ch(4))^(1-eta)))^(1/(1-eta));
    Paa_us   = ((Paa^(1-eta) - sum(aa_shares([1,3 4 5]).^eta.*((1+tax_aa([1,3 4 5])).*[Paa_aa,Paa_ch,Paa_rowa Paa_rowb]).^(1-eta)))/(aa_shares(2)^eta*(1+tax_aa(2))^(1-eta)))^(1/(1-eta));
    Pbb_ch   = ((Pbb^(1-eta) - sum(bb_shares([1,2 4 5]).^eta.*((1+tax_bb([1,2 4 5])).*[Pbb_bb,Pbb_us,Pbb_rowa Pbb_rowb]).^(1-eta)))/(bb_shares(3)^eta*(1+tax_bb(3))^(1-eta)))^(1/(1-eta));
    %}
    
    %This is the straight-forward way
    if prefs_type == 0
        Pus = (sum(us_shares.^eta.*((1+tax_us).*[Pus_us,Pus_ch,Pus_rowa,Pus_rowb]).^(1-eta)))^(1/(1-eta));
        Pch = (sum(ch_shares.^eta.*((1+tax_ch).*[Pch_ch,Pch_us,Pch_rowa,Pch_rowb]).^(1-eta)))^(1/(1-eta));
        Paa = (sum(aa_shares.^eta.*((1+tax_aa).*[Paa_aa,Paa_us,Paa_ch, Paa_rowa,Paa_rowb]).^(1-eta)))^(1/(1-eta));
        Pbb = (sum(bb_shares.^eta.*((1+tax_bb).*[Pbb_bb,Pbb_us,Pbb_ch, Pbb_rowa,Pbb_rowb]).^(1-eta)))^(1/(1-eta));
    else
        Pus = (sum(us_shares.*((1+tax_us).*[Pus_us,Pus_ch,Pus_rowa,Pus_rowb]).^(1-eta)))^(1/(1-eta));
        Pch = (sum(ch_shares.*((1+tax_ch).*[Pch_ch,Pch_us,Pch_rowa,Pch_rowb]).^(1-eta)))^(1/(1-eta));
        Paa = (sum(aa_shares.*((1+tax_aa).*[Paa_aa,Paa_us,Paa_ch, Paa_rowa,Paa_rowb]).^(1-eta)))^(1/(1-eta));
        Pbb = (sum(bb_shares.*((1+tax_bb).*[Pbb_bb,Pbb_us,Pbb_ch, Pbb_rowa,Pbb_rowb]).^(1-eta)))^(1/(1-eta));
    end
    
    %}

    price_solve = [Pus_rowa,Pch_rowb,Paa_us,Pbb_ch];
    matlabFunction(price_solve.', 'File', 'auto_generated/price_sol.m',  'Vars',symvar(price_solve), 'Optimize', optimize);
   
   
    %Link between aggs and per-capita values
    Bus_usd = Bus_usda/mu_us;
    Bch_chy = Bch_chya/mu_ch;
    
    Bus_row = Bus_rowa/mu_us;
    Bch_row = Bch_rowa/mu_ch;
    
    Baa_usd = Baa_usda/mu_aa;
    Baa_chy = Baa_chya/mu_aa;
    Baa_row = Baa_rowa/mu_aa;
    
    Bbb_usd = Bbb_usda/mu_bb;
    Bbb_chy = Bbb_chya/mu_bb;
    

    
    if solve_dyn
        %Dynamic mode: use market clearing to eliminate vars
        Bbb_row = 1/mu_bb*(Baa + Bbb  - mu_us*Bus_row - mu_ch*Bch_row - mu_aa*Baa_row);
        Bch_usd = 1/mu_ch*(Busd       - mu_us*Bus_usd - mu_aa*Baa_usd - mu_bb*(Bbb_usd+BBbb_usd)); %Note change for effective USD supply, given sanctions on some
        Bus_chy = 1/mu_us*(Bchy       - mu_ch*Bch_chy - mu_aa*Baa_chy - mu_bb*Bbb_chy);
    else
        %Steady-state: Use SS euler equations to drop bonds
        Bus_row = (Baa+Bbb)*(m_us*zrow)/(mu_us*m_us*zrow + mu_ch*m_ch*zrow + mu_aa*m_aa*zrow + mu_bb*m_bb*zrow);
        Bch_row = (Baa+Bbb)*(m_ch*zrow)/(mu_us*m_us*zrow + mu_ch*m_ch*zrow + mu_aa*m_aa*zrow + mu_bb*m_bb*zrow);
        Baa_row = (Baa+Bbb)*(m_aa*zrow)/(mu_us*m_us*zrow + mu_ch*m_ch*zrow + mu_aa*m_aa*zrow + mu_bb*m_bb*zrow);
        Bbb_row = (Baa+Bbb)*(m_bb*zrow)/(mu_us*m_us*zrow + mu_ch*m_ch*zrow + mu_aa*m_aa*zrow + mu_bb*m_bb*zrow);
        
        den_usd = (mu_us*m_us*Xus + sanc_usd_ch*mu_ch*m_ch*Xch + mu_aa*m_aa*Xaa + sanc_usd_bb*mu_bb*m_bb*Xbb);
        Bus_usd = (Busd-mu_bb*BBbb_usd)*(m_us*Xus)/den_usd ;
        Bch_usd = (Busd-mu_bb*BBbb_usd)*(sanc_usd_ch*m_ch*Xch)/den_usd ;
        Baa_usd = (Busd-mu_bb*BBbb_usd)*(m_aa*Xaa)/den_usd ;
        Bbb_usd = (Busd-mu_bb*BBbb_usd)*(sanc_usd_bb*m_bb*Xbb)/den_usd ;
        
        Bus_chy = Bchy*(m_us*(1-Xus))/(mu_us*m_us*(1-Xus) + mu_ch*m_ch*(1-Xch) + mu_aa*m_aa*(1-Xaa) + mu_bb*m_bb*(1-Xbb));
        Bch_chy = Bchy*(m_ch*(1-Xch))/(mu_us*m_us*(1-Xus) + mu_ch*m_ch*(1-Xch) + mu_aa*m_aa*(1-Xaa) + mu_bb*m_bb*(1-Xbb));
        Baa_chy = Bchy*(m_aa*(1-Xaa))/(mu_us*m_us*(1-Xus) + mu_ch*m_ch*(1-Xch) + mu_aa*m_aa*(1-Xaa) + mu_bb*m_bb*(1-Xbb));
        Bbb_chy = Bchy*(m_bb*(1-Xbb))/(mu_us*m_us*(1-Xus) + mu_ch*m_ch*(1-Xch) + mu_aa*m_aa*(1-Xaa) + mu_bb*m_bb*(1-Xbb));
        
    end
   
    %Generate future values of subbed-out variables
    Cus_p = subs(Cus,[jump_vars,param_listt],  [jump_prime,param_listp]);
    Cch_p = subs(Cch,[jump_vars,param_listt],  [jump_prime,param_listp]);
    Caa_p = subs(Caa,[jump_vars,param_listt],  [jump_prime,param_listp]);
    Cbb_p = subs(Cbb,[jump_vars,param_listt],  [jump_prime,param_listp]);
    
    Pus_p = subs(Pus,[jump_vars,param_listt],  [jump_prime,param_listp]);
    Pch_p = subs(Pch,[jump_vars,param_listt],  [jump_prime,param_listp]);
    Paa_p = subs(Paa,[jump_vars,param_listt],  [jump_prime,param_listp]);
    Pbb_p = subs(Pbb,[jump_vars,param_listt],  [jump_prime,param_listp]);
    
    %% Make current and past states and adjustment costs (used to code explicitly)
    totBbb_usd = Bbb_usd + BBbb_usd;
    
    Bbb_usd_l = subs(Bbb_usd,[state_vars,taxt,param_listt],[state_prime,taxt,param_listp]); %Needed special treatment to declare because totBbb_usd ~= Bbb_usd in list below
    
    Blist = {'Bus_usd','Bch_usd','Baa_usd','totBbb_usd','Bus_chy','Bch_chy','Baa_chy','Bbb_chy','Bus_row','Bch_row','Baa_row','Bbb_row'};     %Note change totBB for fixed BB proportion 
    for ii = 1:length(Blist)
       eval([Blist{ii}, '_p = subs(' Blist{ii}, ',[state_vars,taxt,param_listt],[state_prime,taxt,param_listp]);']);
       eval([Blist{ii}, '_l = subs(' Blist{ii}, ',[state_vars,taxt,param_listt],[state_lag,taxt,param_listl]);']);
       if true %ii <=8
            tmp = ['tau_' Blist{ii}(end-5:end) '   = tau* (' Blist{ii} ' - ' Blist{ii} '_l)/' Blist{ii} '_l;'];
       else
           %No adj cost on ROW bonds
           %tmp = ['tau_' Blist{ii}(2:end) '  = 0;'];
       end
       disp(tmp)
       eval(tmp);
   
       %taup*(Bus_usd_p - Bus_usd)/Bus_usd + taup/2*((Bus_usd_p - Bus_usd)/Bus_usd)^2
       tmp = ['tau_' Blist{ii}(end-5:end) '_p = taup*(' Blist{ii} '_p - ' Blist{ii} ')/' Blist{ii} ' + taup/2*((' Blist{ii} '_p - ' Blist{ii} ')/' Blist{ii} ')^2;'];
       disp(tmp)
       eval(tmp)
    end
    
    
 
    %%
    %What unit do bonds pay?
    Pusd = Pus_us;
    Pchy = Pch_ch;
    
    Pusd_p = Pus_us_p;
    Pchy_p = Pch_ch_p;
    
   
    %**************************************************************************
    %Matching functions -> endogenous probabilities
    %**************************************************************************
    
    %Current bonds to funding probs
    ph_us_usd = chi*upp_usd*(m_us*Xus    )/(((upp_usd*Pusd*Bus_usd*Qusd)^(1/vepsf) + (m_us*Xus    )^(1/vepsf))^vepsf);  %prob of us hh search dollars getting a match
    ph_us_chy = chi*upp_chy*(m_us*(1-Xus))/(((upp_chy*Pchy*Bus_chy*Qchy)^(1/vepsf) + (m_us*(1-Xus))^(1/vepsf))^vepsf);  %prob of us hh search euro getting a match
    ph_us_row = chi*upp_usd*(m_us*zrow   )/(((upp_usd*     Bus_row*Qrow)^(1/vepsf) + (m_us*zrow   )^(1/vepsf))^vepsf);  %prob of us hh search dollars getting a match
    
    
    ph_ch_usd = chi*sanc_usd_ch*upp_usd   *(m_ch*Xch    )/(((upp_usd*Pusd*Bch_usd*Qusd)^(1/vepsf) + (m_ch*Xch*sanc_usd_ch)^(1/vepsf))^vepsf);  %prob of ch hh search dollars getting a match
    ph_ch_chy = chi*            upp_chy   *(m_ch*(1-Xch))/(((upp_chy*Pchy*Bch_chy*Qchy)^(1/vepsf) + (m_ch*(1-Xch)        )^(1/vepsf))^vepsf);  %prob of ch hh search euro getting a match
    ph_ch_row = chi*            upp_usd   *(m_ch*zrow   )/(((upp_usd*     Bch_row*Qrow)^(1/vepsf) + (m_ch*zrow           )^(1/vepsf))^vepsf);  %prob of us hh search dollars getting a match
    
    
    ph_aa_usd = chi*upp_usd*(m_aa*Xaa    )/(((upp_usd*Pusd*Baa_usd*Qusd)^(1/vepsf) + (m_aa*Xaa    )^(1/vepsf))^vepsf);  %prob of aa hh search dollars getting a match
    ph_aa_chy = chi*upp_chy*(m_aa*(1-Xaa))/(((upp_chy*Pchy*Baa_chy*Qchy)^(1/vepsf) + (m_aa*(1-Xaa))^(1/vepsf))^vepsf);  %prob of aa hh search euro getting a match
    ph_aa_row = chi*upp_usd*(m_aa*zrow   )/(((upp_usd*     Baa_row*Qrow)^(1/vepsf) + (m_aa*zrow   )^(1/vepsf))^vepsf);  %prob of us hh search dollars getting a match
    
    
    ph_bb_usd = chi*sanc_usd_bb*upp_usd*(m_bb*Xbb    )/(((upp_usd*Pusd*Bbb_usd*Qusd)^(1/vepsf) + (m_bb*Xbb*sanc_usd_bb)^(1/vepsf))^vepsf);  %prob of bb hh search dollars getting a match
    ph_bb_chy = chi*            upp_chy*(m_bb*(1-Xbb))/(((upp_chy*Pchy*Bbb_chy*Qchy)^(1/vepsf) + (m_bb*(1-Xbb)        )^(1/vepsf))^vepsf);  %prob of bb hh search euro getting a match
    ph_bb_row = chi*            upp_usd*(m_bb*zrow   )/(((upp_usd*     Bbb_row*Qrow)^(1/vepsf) + (m_bb*zrow           )^(1/vepsf))^vepsf);  %prob of us hh search dollars getting a match
    

    p_us_usd = chi*upp_usd*(Pusd*Bus_usd*Qusd)/(((upp_usd*Pusd*Bus_usd*Qusd)^(1/vepsf) + (m_us*Xus    )^(1/vepsf))^vepsf);  %prob of us hh search dollars getting a match
    p_us_chy = chi*upp_chy*(Pchy*Bus_chy*Qchy)/(((upp_chy*Pchy*Bus_chy*Qchy)^(1/vepsf) + (m_us*(1-Xus))^(1/vepsf))^vepsf);  %prob of us hh search euro getting a match
    
    p_ch_usd = chi*sanc_usd_ch*upp_usd*(Pusd*Bch_usd*Qusd)/(((upp_usd   *Pusd*Bch_usd*Qusd)^(1/vepsf) + (m_ch*Xch*sanc_usd_ch    )^(1/vepsf))^vepsf);  %prob of ch hh search dollars getting a match
    p_ch_chy = chi*            upp_chy*(Pchy*Bch_chy*Qchy)/(((upp_chy   *Pchy*Bch_chy*Qchy)^(1/vepsf) + (m_ch*(1-Xch)            )^(1/vepsf))^vepsf);  %prob of ch hh search euro getting a match
    
    p_aa_usd = chi*upp_usd*(Pusd*Baa_usd*Qusd)/(((upp_usd*Pusd*Baa_usd*Qusd)^(1/vepsf) + (m_aa*Xaa    )^(1/vepsf))^vepsf);  %prob of aa hh search dollars getting a match
    p_aa_chy = chi*upp_chy*(Pchy*Baa_chy*Qchy)/(((upp_chy*Pchy*Baa_chy*Qchy)^(1/vepsf) + (m_aa*(1-Xaa))^(1/vepsf))^vepsf);  %prob of aa hh search euro getting a match

    p_bb_usd = chi*sanc_usd_bb*upp_usd*(Pusd*Bbb_usd*Qusd)/(((upp_usd*Pusd*Bbb_usd*Qusd)^(1/vepsf) + (m_bb*Xbb*sanc_usd_bb    )^(1/vepsf))^vepsf);  %prob of bb hh search dollars getting a match
    p_bb_chy = chi*            upp_chy*(Pchy*Bbb_chy*Qchy)/(((upp_chy*Pchy*Bbb_chy*Qchy)^(1/vepsf) + (m_bb*(1-Xbb)            )^(1/vepsf))^vepsf);  %prob of bb hh search euro getting a match


    %Active and funded firms
    m_us_til = mu_us*m_us*(Xus*p_us_usd + (1-Xus)*p_us_chy);  %measure of US firms with funding
    m_ch_til = mu_ch*m_ch*(Xch*p_ch_usd + (1-Xch)*p_ch_chy);  %measure of EU firms with funding
    m_aa_til = mu_aa*m_aa*(Xaa*p_aa_usd + (1-Xaa)*p_aa_chy);  %measure of AA firms with funding
    m_bb_til = mu_bb*m_bb*(Xbb*p_bb_usd + (1-Xbb)*p_bb_chy);  %measure of AA firms with funding
   
    %**************************************************************************
    % Q. What is all this def_sub stuff below?
    % A. "def_sub" = "deferred substitution"
    % This is our way of using the sybolic toolbox to substitute out as many
    % variables as possible, without making the symbolic expressions too
    % complicated. Suppose you have a variable y = f(x) and many equilibrium
    % conditions G(y) where y appear repeatedly. If I substitute in G(y(x)),
    % then evaluating G(x) will implicitly evaluate y(x) many times, which is
    % wasteful. So, instead, we keep track of the y(x) later compile things so
    % that y(x) is evaluated once and then substituted in the right places as
    % many times as it's used.
    %**************************************************************************
   
    pfirms = who('p_*');   %Length should be 8
    phhlds = who('ph_*');  %Legnth should be 8
     def_sub_nms = {'Cus'   , 'Cch'   , 'Caa'   , 'Cbb',...
                    'Cus_us', 'Cch_ch', 'Caa_aa', 'Cbb_bb',...
                    'Pus_rowa', 'Pch_rowb', 'Paa_us', 'Pbb_ch'...
                    'Bch_usd', 'Bus_chy'...'Bus_usd', 'Beu_eur',%
                    pfirms{:}, phhlds{:}...
        'm_us_til','m_ch_til','m_aa_til','m_bb_til', ...
        ptrans{:}}; 
    
     def_sub_nms = {'Cus'   , 'Cch'   , 'Caa'   , 'Cbb',...
                    'Cus_us', 'Cch_ch', 'Caa_aa', 'Cbb_bb',...
                    'Pus', 'Pch', 'Paa', 'Pbb'...
                    'Bch_usd', 'Bus_chy','Bbb_row' ...'Bus_usd', 'Beu_eur',%
                    pfirms{:}, phhlds{:}...
        'm_us_til','m_ch_til','m_aa_til','m_bb_til', ...
        ptrans{:}};%All those probabilities of import/export and where
    
 
    
    if ~xstate && ~solve_dyn
        % def_sub_nms = [def_sub_nms,{'Xrw'}];
    end
    
    if ~solve_dyn
        def_sub_nms = [def_sub_nms, {'Bus_usd','Bch_chy','Baa_usd','Baa_chy','Bbb_usd','Bbb_chy','Bus_row','Bch_row','Baa_row'}];
    end
    
    nsub = length(def_sub_nms);def_sub_val = cell(1, nsub);def_sub_syms = cell(1,nsub);def_sub_sym = sym(zeros(1,nsub));
    for jj = 1:length(def_sub_sym)
        def_sub_val{jj} = eval(def_sub_nms{jj});%simplify(eval(def_sub_nms{jj}),'IgnoreAnalyticConstraints',true);
        eval(['syms ' def_sub_nms{jj}]);
        def_sub_sym(jj) = eval(def_sub_nms{jj});
    end
    
    
    %Deferred sub variables always in terms of time-t parameters
    args_def  = sym_args([symvar([def_sub_val{:}]),param_list_ss],vcombo_ss);
    
  
    if redo_defsb
        if solve_dyn == 0
            
            %Def subs function
            def_sub_ss_call = sym2mex(def_sub_nms,def_sub_val,[vcombo_ss,args_def],'tofill_files/def_sub_ss_tofill.c','auto_generated/def_sub_ss_mex.c', 'def_sub_ss_mex','auto_generated');
            
            %Derivate there-of
            ddef_sub_val = jacobian([def_sub_val{:}],[vcombo_ss]);
            ddef_sub_ss_call = sym2mex({'dsub'},{ddef_sub_val},[vcombo_ss,args_def],'tofill_files/def_sub_ss_tofill.c','auto_generated/ddef_sub_ss_mex.c', 'ddef_sub_ss_mex','auto_generated');
            
        else
            matlabFunction(def_sub_val{:}, 'File', 'auto_generated/def_sub.m', 'Outputs', def_sub_nms, 'Vars',[vcombo_ss,args_def], 'Optimize', optimize);
            matlabFunction(jacobian([def_sub_val{:}],[vcombo_ss]), 'File', 'auto_generated/ddef_sub.m', 'Outputs', {'ddeff'}, 'Vars',[vcombo_ss,args_def], 'Optimize', optimize);
            matlabFunction(jacobian([def_sub_val{:}],[state_lag]), 'File', 'auto_generated/ddef_sub_lag.m', 'Outputs', {'ddeff_lag'}, 'Vars',[vcombo_ss,args_def], 'Optimize', optimize);
            
            def_sub_call = sym2mex(def_sub_nms,def_sub_val,[vcombo_ss,args_def],'tofill_files/def_sub_ss_tofill.c','auto_generated/def_sub_mex.c', 'def_sub_mex','auto_generated');
            
            
        end
    end
  
    
    %**************************************************************************
    % TRADE MODEL
    %**************************************************************************
   
    %Trading market matching, how many in each market
   
    %US
    mie_us_ch = pim_us_ch*m_us_til;
    mie_us_aa = pim_us_aa*m_us_til;
    mie_us_bb = pim_us_bb*m_us_til;
   
    
    mei_us_ch = pex_us_ch*m_us_til;
    mei_us_aa = pex_us_aa*m_us_til;
    mei_us_bb = pex_us_bb*m_us_til;
    
    %CH
    mie_ch_us = pim_ch_us*m_ch_til;
    mie_ch_aa = pim_ch_aa*m_ch_til;
    mie_ch_bb = pim_ch_bb*m_ch_til;
   
    
    mei_ch_us = pex_ch_us*m_ch_til;
    mei_ch_aa = pex_ch_aa*m_ch_til;
    mei_ch_bb = pex_ch_bb*m_ch_til;
   
    
    %Regiona A
    mie_aa_us = pim_aa_us*m_aa_til;
    mie_aa_ch = pim_aa_ch*m_aa_til;
    mie_aa_aa = pim_aa_aa*m_aa_til;
    mie_aa_bb = pim_aa_bb*m_aa_til;
   
    mei_aa_us = pex_aa_us*m_aa_til;
    mei_aa_ch = pex_aa_ch*m_aa_til;
    mei_aa_aa = pex_aa_aa*m_aa_til;
    mei_aa_bb = pex_aa_bb*m_aa_til;
    
    
    %Regiona B
    mie_bb_us = pim_bb_us*m_bb_til;
    mie_bb_ch = pim_bb_ch*m_bb_til;
    mie_bb_aa = pim_bb_aa*m_bb_til;
    mie_bb_bb = pim_bb_bb*m_bb_til;
   
    mei_bb_us = pex_bb_us*m_bb_til;
    mei_bb_ch = pex_bb_ch*m_bb_til;
    mei_bb_aa = pex_bb_aa*m_bb_til;
    mei_bb_bb = pex_bb_bb*m_bb_til;
    
    %Dollar densities in each country
    Xus_til = Xus*p_us_usd/(Xus*p_us_usd + (1-Xus)*p_us_chy);   %fraction of funded US firms with dollars
    Xch_til = Xch*p_ch_usd/(Xch*p_ch_usd + (1-Xch)*p_ch_chy);   %fraction of funded EU firms with dollars
    Xaa_til = Xaa*p_aa_usd/(Xaa*p_aa_usd + (1-Xaa)*p_aa_chy);   %fraction of funded AA firms with dollars
    Xbb_til = Xbb*p_bb_usd/(Xbb*p_bb_usd + (1-Xbb)*p_bb_chy);   %fraction of funded AA firms with dollars
    
    %trade matching
    trd_match= @(x) 1/((1+x^(1/vepst))^vepst);
    
    pie_us_ch = trd_match(mie_us_ch/mei_ch_us);
    pie_us_aa = trd_match(mie_us_aa/mei_aa_us);
    pie_us_bb = trd_match(mie_us_bb/mei_bb_us);
    
    pie_ch_us = trd_match(mie_ch_us/mei_us_ch);
    pie_ch_aa = trd_match(mie_ch_aa/mei_aa_ch);
    pie_ch_bb = trd_match(mie_ch_bb/mei_bb_ch);
    
    pie_aa_us = trd_match(mie_aa_us/mei_us_aa);
    pie_aa_ch = trd_match(mie_aa_ch/mei_ch_aa);
    pie_aa_aa = trd_match(mie_aa_aa/mei_aa_aa);
    pie_aa_bb = trd_match(mie_aa_bb/mei_bb_aa);
    
    pie_bb_us = trd_match(mie_bb_us/mei_us_bb);
    pie_bb_ch = trd_match(mie_bb_ch/mei_ch_bb);
    pie_bb_aa = trd_match(mie_bb_aa/mei_aa_bb);
    pie_bb_bb = trd_match(mie_bb_bb/mei_bb_bb);
    
    pei_us_ch = trd_match(mei_us_ch/mie_ch_us);
    pei_us_aa = trd_match(mei_us_aa/mie_aa_us);
    pei_us_bb = trd_match(mei_us_bb/mie_bb_us);
    
    pei_ch_us = trd_match(mei_ch_us/mie_us_ch);
    pei_ch_aa = trd_match(mei_ch_aa/mie_aa_ch);
    pei_ch_bb = trd_match(mei_ch_bb/mie_bb_ch);
    
    pei_aa_us = trd_match(mei_aa_us/mie_us_aa);
    pei_aa_ch = trd_match(mei_aa_ch/mie_ch_aa);
    pei_aa_aa = trd_match(mei_aa_aa/mie_aa_aa);
    pei_aa_bb = trd_match(mei_aa_bb/mie_bb_aa);
    
    pei_bb_us = trd_match(mei_bb_us/mie_us_bb);
    pei_bb_ch = trd_match(mei_bb_ch/mie_ch_bb);
    pei_bb_aa = trd_match(mei_bb_aa/mie_aa_bb);
    pei_bb_bb = trd_match(mei_bb_bb/mie_bb_bb);
    
    %**************************************************************************
    % "WHOLESALE" TRADE PRICES
    %**************************************************************************
    PWus_ch    = Pch_ch*(1+etax_us_ch) + (1-alph)*(Pus_ch   - Pch_ch*(1+etax_us_ch));
    PWus_rowa  = Paa_aa*(1+etax_us_aa) + (1-alph)*(Pus_rowa - Paa_aa*(1+etax_us_aa));
    PWus_rowb  = Pbb_bb*(1+etax_us_bb) + (1-alph)*(Pus_rowb - Pbb_bb*(1+etax_us_bb));
    
    PWch_us    = Pus_us*(1+etax_ch_us) + (1-alph)*(Pch_us   - Pus_us*(1+etax_ch_us));
    PWch_rowa  = Paa_aa*(1+etax_ch_aa) + (1-alph)*(Pch_rowa - Paa_aa*(1+etax_ch_aa));
    PWch_rowb  = Pbb_bb*(1+etax_ch_bb) + (1-alph)*(Pch_rowb - Pbb_bb*(1+etax_ch_bb));
    
    PWaa_us     = Pus_us*(1+etax_aa_us) + (1-alph)*(Paa_us   - Pus_us*(1+etax_aa_us));
    PWaa_ch     = Pch_ch*(1+etax_aa_ch) + (1-alph)*(Paa_ch   - Pch_ch*(1+etax_aa_ch));
    PWaa_rowa   = Paa_aa*(1+    0     ) + (1-alph)*(Paa_rowa - Paa_aa*(1+    0     ));
    PWaa_rowb   = Pbb_bb*(1+etax_aa_bb) + (1-alph)*(Paa_rowb - Pbb_bb*(1+etax_aa_bb));
    
    PWbb_us     = Pus_us*(1+etax_bb_us) + (1-alph)*(Pbb_us   - Pus_us*(1+etax_bb_us));
    PWbb_ch     = Pch_ch*(1+etax_bb_ch) + (1-alph)*(Pbb_ch   - Pch_ch*(1+etax_bb_ch));
    PWbb_rowa   = Paa_aa*(1+etax_bb_aa) + (1-alph)*(Pbb_rowa - Paa_aa*(1+etax_bb_aa));
    PWbb_rowb   = Pbb_bb*(1+    0     ) + (1-alph)*(Pbb_rowb - Pbb_bb*(1+    0     ));
    
    
    %% **************************************************************************
    % US Payoffs
    %**************************************************************************
    
    curr = {'usd', 'chy'};
    home = {'us', 'ch',  'aa', 'bb'};
    away = {'us', 'ch',  'aa', 'bb'};
    origr = {'us  ', 'ch  ',  'rowa', 'rowb'};
    etax_aa_aa = 0;
    etax_bb_bb = 0;
    ctr = 0;
    for hh = 1:4
        for cc = 1:2
            for oo = 1:4
                if ~strcmp(home{hh},origr{oo}(1:2))  %This if eliminates us-us exports/imports, ch-ch exports/imports
                    
                    if cc == 1
                        cpart = ['(1-X' away{oo} '_til)'];
                    else
                        cpart = ['X' away{oo} '_til'];
                    end
                    str3 = ['*(1+etax_' home{hh} '_' away{oo} ')'];
                    str4 = ['*(1+etax_' home{oo} '_' away{hh} ')'];
                    str1 = ['PI' home{hh}, '_' away{oo}, '_' curr{cc} ' = pie_' home{hh} '_' away{oo} '*(1-alph)/PW' home{hh} '_' origr{oo} '*((P' home{hh} '_' origr{oo}  '- P' away{oo} '_' away{oo} str3 ') - kap*PW' home{hh} '_' origr{oo} '*' cpart ');'];
                    str2 = ['PE' home{hh}, '_' away{oo}, '_' curr{cc} ' = pei_' home{hh} '_' away{oo} '*(  alph)/PW' away{oo} '_' origr{hh} '*((P' home{oo} '_' origr{hh}  '- P' away{hh} '_' away{hh} str4 ') - kap*PW' home{oo} '_' origr{hh} '*' cpart ');'];
                   
                    disp(str1)
                    disp(str2)
                    eval(str1)
                    eval(str2)
                    ctr = ctr+1;
                end
            end
        end
    end
     %%
    
    %Old CODE for reference
    %{
    %US firms:
    %first ling e.g. - importer profits of US firms importing from EU using dollars
    PIus_eu_usd =  pie_us_eu*(1-alph)/PWus_eu*((Pus_eu - Peu_eu) - kap*PWus_eu*(1-Xeu_til));
    PIus_rw_usd =  pie_us_rw*(1-alph)/PWus_rw*((Pus_rw - Prw_rw) - kap*PWus_rw*(1-Xrw_til));
    
    PIus_eu_eur =  pie_us_eu*(1-alph)/PWus_eu*((Pus_eu - Peu_eu) - kap*PWus_eu*(Xeu_til));
    PIus_rw_eur =  pie_us_rw*(1-alph)/PWus_rw*((Pus_rw - Prw_rw) - kap*PWus_rw*(Xrw_til));
    
    PEus_eu_usd =  pei_us_eu*alph/PWeu_us*((Peu_us - Pus_us) - kap*PWeu_us*(1-Xeu_til));
    PEus_rw_usd =  pei_us_rw*alph/PWrw_us*((Prw_us - Pus_us) - kap*PWrw_us*(1-Xrw_til));
    
    PEus_eu_eur =  pei_us_eu*alph/PWeu_us*((Peu_us - Pus_us) - kap*PWeu_us*(Xeu_til));
    PEus_rw_eur =  pei_us_rw*alph/PWrw_us*((Prw_us - Pus_us) - kap*PWrw_us*(Xrw_til));
    
    %EU firms
    PIeu_us_usd =  pie_eu_us*(1-alph)/PWeu_us*((Peu_us - Pus_us) - kap*PWeu_us*(1-Xus_til));
    PIeu_rw_usd =  pie_eu_rw*(1-alph)/PWeu_rw*((Peu_rw - Prw_rw) - kap*PWeu_rw*(1-Xrw_til));
    
    PIeu_us_eur =  pie_eu_us*(1-alph)/PWeu_us*((Peu_us - Pus_us) - kap*PWeu_us*(Xus_til));
    PIeu_rw_eur =  pie_eu_rw*(1-alph)/PWeu_rw*((Peu_rw - Prw_rw) - kap*PWeu_rw*(Xrw_til));
    
    PEeu_us_usd =  pei_eu_us*alph/PWus_eu*((Pus_eu - Peu_eu) - kap*PWus_eu*(1-Xus_til));
    PEeu_rw_usd =  pei_eu_rw*alph/PWrw_eu*((Prw_eu - Peu_eu) - kap*PWrw_eu*(1-Xrw_til));
    
    PEeu_us_eur =  pei_eu_us*alph/PWus_eu*((Pus_eu - Peu_eu) - kap*PWus_eu*(Xus_til));
    PEeu_rw_eur =  pei_eu_rw*alph/PWrw_eu*((Prw_eu - Peu_eu) - kap*PWrw_eu*(Xrw_til));
    
    %ROW firms
    PIrw_us_usd =  pie_rw_us*(1-alph)/PWrw_us *((Prw_us - Pus_us) - kap*PWrw_us *(1-Xus_til));
    PIrw_eu_usd =  pie_rw_eu*(1-alph)/PWrw_eu *((Prw_eu - Peu_eu) - kap*PWrw_eu *(1-Xeu_til));
    PIrw_rw_usd =  pie_rw_rw*(1-alph)/PWrw_row*((Prw_row - Prw_rw) - kap*PWrw_row*(1-Xrw_til));
    
    PIrw_us_eur =  pie_rw_us*(1-alph)/PWrw_us *((Prw_us - Pus_us) - kap*PWrw_us *(Xus_til));
    PIrw_eu_eur =  pie_rw_eu*(1-alph)/PWrw_eu *((Prw_eu - Peu_eu) - kap*PWrw_eu *(Xeu_til));
    PIrw_rw_eur =  pie_rw_rw*(1-alph)/PWrw_row*((Prw_row - Prw_rw) - kap*PWrw_row*(Xrw_til));
    
    PErw_us_usd =  pei_rw_us*alph/PWus_rw *((Pus_rw - Prw_rw)  - kap*PWus_rw *(1-Xus_til));
    PErw_eu_usd =  pei_rw_eu*alph/PWeu_rw *((Peu_rw - Prw_rw)  - kap*PWeu_rw *(1-Xeu_til));
    PErw_rw_usd =  pei_rw_rw*alph/PWrw_row*((Prw_row - Prw_rw) - kap*PWrw_row*(1-Xrw_til));
    
    PErw_us_eur =  pei_rw_us*alph/PWus_rw *((Pus_rw - Prw_rw)  - kap*PWus_rw *(Xus_til));
    PErw_eu_eur =  pei_rw_eu*alph/PWeu_rw *((Peu_rw - Prw_rw)  - kap*PWeu_rw *(Xeu_til));
    PErw_rw_eur =  pei_rw_rw*alph/PWrw_row*((Prw_row - Prw_rw) - kap*PWrw_row*(Xrw_til));
    %}
    
    %**************************************************************************
    % COMBINED PAYOFFS
    %**************************************************************************
    
    %Fixed trade entry costs;
    fc_us = phi*Pus*cons_us;
    fc_ch = phi*Pch*cons_ch;
    fc_aa = phi*Paa*cons_aa;
    fc_bb = phi*Pbb*cons_bb;
    
   
    fc_us = phi*Pus*cons_us/Pnumer;
    fc_ch = phi*Pch*cons_ch/Pnumer;
    fc_aa = phi*Paa*cons_aa/Pnumer;
    fc_bb = phi*Pbb*cons_bb/Pnumer;
    
    fc_us = phi*2.059788449625430*  0.406882652930739;%cons_us;
    fc_ch = phi*2.059788449625430*  0.406882652930739;%cons_ch;
    fc_aa = phi*2.654738455876790*  0.375612145397017;%cons_aa;
    fc_bb = phi*2.654738455876790*  0.375612145397017;%cons_bb;
    
    fc_us = phi;%cons_us;
    fc_ch = phi;%cons_ch;
    fc_aa = phi;%cons_aa;
    fc_bb = phi;%cons_bb;
    
    
    fr_usd = r;
    fr_chy = r;
    
    fr_us_usd = r;
    fr_ch_usd = r*(1+xtax_ch_usd);
    fr_aa_usd = r*(1+xtax_aa_usd);
    fr_bb_usd = r*(1+xtax_bb_usd);
    
    fr_us_chy = r*(1+xtax_us_chy);
    fr_ch_chy = r;
    fr_aa_chy = r*(1+xtax_aa_chy);
    fr_bb_chy = r*(1+xtax_bb_chy);
    
    %US probs and profits, use vector mult to sum
    pus_v  = [pim_us_ch pim_us_aa pim_us_bb ...
              pex_us_ch pex_us_aa pex_us_bb];
          
    Pus_USD_v = [PIus_ch_usd PIus_aa_usd PIus_bb_usd...
                 PEus_ch_usd PEus_aa_usd PEus_bb_usd].';
    
    Pus_CHY_v = [PIus_ch_chy PIus_aa_chy PIus_bb_chy...
                 PEus_ch_chy PEus_aa_chy PEus_bb_chy].';
    
    Pi_us_usd = p_us_usd*(pus_v*Pus_USD_v-fr_us_usd) - fc_us;
    Pi_us_chy = p_us_chy*(pus_v*Pus_CHY_v-fr_us_chy) - fc_us;

    %CH probs and profits, use vector mult to sum
    pch_v  = [pim_ch_us pim_ch_aa pim_ch_bb ...
              pex_ch_us pex_ch_aa pex_ch_bb];
          
    Pch_USD_v = [PIch_us_usd PIch_aa_usd PIch_bb_usd...
                 PEch_us_usd PEch_aa_usd PEch_bb_usd].';
    
    Pch_CHY_v = [PIch_us_chy PIch_aa_chy PIch_bb_chy...
                 PEch_us_chy PEch_aa_chy PEch_bb_chy].';
    
    Pi_ch_usd = p_ch_usd*(pch_v*Pch_USD_v-fr_ch_usd) - fc_ch;
    Pi_ch_chy = p_ch_chy*(pch_v*Pch_CHY_v-fr_ch_chy) - fc_ch;
    
    %Region A probs and profits, use vector mult to sum
    paa_v  = [pim_aa_us pim_aa_ch pim_aa_aa pim_aa_bb ...
              pex_aa_us pex_aa_ch pex_aa_aa pex_aa_bb];
          
    Paa_USD_v = [PIaa_us_usd PIaa_ch_usd PIaa_aa_usd PIaa_bb_usd...
                 PEaa_us_usd PEaa_ch_usd PEaa_aa_usd PEaa_bb_usd].';
    
    Paa_CHY_v = [PIaa_us_chy PIaa_ch_chy PIaa_aa_chy PIaa_bb_chy...
                 PEaa_us_chy PEaa_ch_chy PEaa_aa_chy PEaa_bb_chy].';
    
    
    Pi_aa_usd = p_aa_usd*(paa_v*Paa_USD_v-fr_aa_usd) - fc_aa;
    Pi_aa_chy = p_aa_chy*(paa_v*Paa_CHY_v-fr_aa_chy) - fc_aa;
    
    %Region B probs and profits, use vector mult to sum     
    pbb_v  = [pim_bb_ch pim_bb_us pim_bb_bb pim_bb_aa ...
              pex_bb_ch pex_bb_us pex_bb_bb pex_bb_aa];
          
    Pbb_USD_v = [PIbb_ch_usd PIbb_us_usd PIbb_bb_usd PIbb_aa_usd...
                 PEbb_ch_usd PEbb_us_usd PEbb_bb_usd PEbb_aa_usd].';
    
    Pbb_CHY_v = [PIbb_ch_chy PIbb_us_chy PIbb_bb_chy PIbb_aa_chy...
                 PEbb_ch_chy PEbb_us_chy PEbb_bb_chy PEbb_aa_chy].';
    
    

    Pi_bb_usd = p_bb_usd*(pbb_v*Pbb_USD_v-fr_bb_usd) - fc_bb;
    Pi_bb_chy = p_bb_chy*(pbb_v*Pbb_CHY_v-fr_bb_chy) - fc_bb;
    
    %**************************************************************************
    % US/EU Cutoff Choices
    %**************************************************************************
    %CUT_us = Pi_us_usd - Pi_us_eur + sbar_us*sige;
    %CUT_eu = Pi_eu_usd - Pi_eu_eur + sbar_eu*sige;
    
    %Vdef   = Vusd - (Pi_rw_usd - Pi_rw_eur)*(1-bet*(1-omg)) - bet*(1-omg)*Vusd_p;
    CUT_aa =        (1-fixx)*((Pi_aa_usd - Pi_aa_chy) + sbar_aa*sige) + fixx*(Xaa-fXaa);
    CUT_bb =        (1-fixx)*((Pi_bb_usd - Pi_bb_chy) + sbar_bb*sige) + fixx*(Xbb-fXbb);
    
    sbar_solve_aa_ = -1/sige*(Pi_aa_usd - Pi_aa_chy);
    sbar_solve_bb_ = -1/sige*(Pi_bb_usd - Pi_bb_chy);
    
    %**************************************************************************
    % ENTRY CONDITION
    %**************************************************************************
    ENTRY_us = Xus*Pi_us_usd + (1-Xus)*Pi_us_chy;
    ENTRY_ch = Xch*Pi_ch_usd + (1-Xch)*Pi_ch_chy;
    ENTRY_aa = Xaa*Pi_aa_usd + (1-Xaa)*Pi_aa_chy;
    ENTRY_bb = Xbb*Pi_bb_usd + (1-Xbb)*Pi_bb_chy;
    
    %**************************************************************************
    % US im/ex & us/eu/row probability choice
    %**************************************************************************
    
    %US nps
    np_us_usd1 = PIus_ch_usd-PIus_aa_usd;
    np_us_eur1 = PIus_ch_chy-PIus_aa_chy;
    np_us1     = Xus*np_us_usd1 + (1-Xus)*np_us_eur1;
    
    np_us_usd2 = PIus_ch_usd-PIus_bb_usd;
    np_us_eur2 = PIus_ch_chy-PIus_bb_chy;
    np_us2     = Xus*np_us_usd2 + (1-Xus)*np_us_eur2;
    
    np_us_usd3 = PEus_ch_usd-PEus_aa_usd;
    np_us_eur3 = PEus_ch_chy-PEus_aa_chy;
    np_us3     = Xus*np_us_usd3 + (1-Xus)*np_us_eur3;
    
    np_us_usd4 = PEus_ch_usd-PEus_bb_usd;
    np_us_eur4 = PEus_ch_chy-PEus_bb_chy;
    np_us4     = Xus*np_us_usd4 + (1-Xus)*np_us_eur4;
    
    np_us_usd5 = PEus_ch_usd-PIus_ch_usd;
    np_us_eur5 = PEus_ch_chy-PIus_ch_chy;
    np_us5     = Xus*np_us_usd5 + (1-Xus)*np_us_eur5;
    
    %US nps
    np_us = cell(1,5);
    for rr = 1:5
       np_us{rr} = Xus*(Pus_USD_v(1)-Pus_USD_v(rr+1)) + (1-Xus)*(Pus_CHY_v(1)-Pus_CHY_v(rr+1));
    end
    
    %CH nps
%     np_ch_usd1 = PIch_us_usd-PIch_aa_usd;
%     np_ch_eur1 = PIch_us_chy-PIch_aa_chy;
%     np_ch1     = Xch*np_ch_usd1 + (1-Xch)*np_ch_eur1;
%     
%     np_ch_usd2 = PIch_us_usd-PIch_bb_usd;
%     np_ch_eur2 = PIch_us_chy-PIch_bb_chy;
%     np_ch2     = Xch*np_ch_usd2 + (1-Xch)*np_ch_eur2;
%     
%     np_ch_usd3 = PEch_us_usd-PEch_aa_usd;
%     np_ch_eur3 = PEch_us_chy-PEch_aa_chy;
%     np_ch3     = Xch*np_ch_usd3 + (1-Xch)*np_ch_eur3;
%     
%     np_ch_usd4 = PEch_us_usd-PEch_bb_usd;
%     np_ch_eur4 = PEch_us_chy-PEch_bb_chy;
%     np_ch4     = Xch*np_ch_usd4 + (1-Xch)*np_ch_eur4;
%     
%     np_ch_usd5 = PEch_us_usd-PIch_us_usd;
%     np_ch_eur5 = PEch_us_chy-PIch_us_chy;
%     np_ch5     = Xch*np_ch_usd5 + (1-Xus)*np_ch_eur5;
    
    %CH nps
    np_ch = cell(1,5);
    for rr = 1:5
       np_ch{rr}  = Xch*(Pch_USD_v(1)-Pch_USD_v(rr+1)) + (1-Xch)*(Pch_CHY_v(1)-Pch_CHY_v(rr+1));
    end
    
    
    %Region A nps
    np_aa = cell(1,7);
    for rr = 1:7
       np_aa{rr}  = Xaa*(Paa_USD_v(1)-Paa_USD_v(rr+1)) + (1-Xaa)*(Paa_CHY_v(1)-Paa_CHY_v(rr+1));
    end
    
    %Region B nps
    np_bb = cell(1,7);
    for rr = 1:7
        np_bb{rr} = Xbb*(Pbb_USD_v(1)-Pbb_USD_v(rr+1)) + (1-Xbb)*(Pbb_CHY_v(1)-Pbb_CHY_v(rr+1));
    end
   
    nps_ = [np_us{:},...np_us1 np_us2 np_us3, np_us4, np_us5...
            np_ch{:},...%^np_ch1 np_ch2 np_ch3, np_ch4, np_ch5...
            np_aa{:},...
            np_bb{:}];
    

    %**************************************************************************
    % GENERATE FUNCTIONS THAT DESCRIBE INDIFFERENCE CONDITIONS
    %**************************************************************************
    PINDS = [ENTRY_us,ENTRY_ch,ENTRY_aa, ENTRY_bb, nps_];
    
    %**************************************************************************
    % DELTAs to output to shell model
    %**************************************************************************
    del_us_usd = ph_us_usd*r;
    del_us_chy = ph_us_chy*r;
    del_us_row = ph_us_row*r;
    
    del_ch_usd = ph_ch_usd*r;
    del_ch_chy = ph_ch_chy*r;
    del_ch_row = ph_ch_row*r;
    
    del_aa_usd = ph_aa_usd*r;
    del_aa_chy = ph_aa_chy*r;
    del_aa_row = ph_aa_row*r;
    
    
    del_bb_usd = ph_bb_usd*r;
    del_bb_chy = ph_bb_chy*r;
    del_bb_row = ph_bb_row*r;
    
%     if timing == 0 
%         %Need tomorrows del's
%         del_us_usd_p = ph_us_usd_p*r;
%         del_us_eur_p = ph_us_eur_p*r;
%         
%         del_eu_usd_p = ph_eu_usd_p*r;
%         del_eu_eur_p = ph_eu_eur_p*r;
%         
%         del_rw_usd_p = ph_rw_usd_p*r;
%         del_rw_eur_p = ph_rw_eur_p*r;
%     end
    
    %**************************************************************************
    % KAP COSTS
    %**************************************************************************
    
    pie_us_v = [pie_us_ch   , pie_us_aa , pie_us_bb];
    pei_us_v = [pei_us_ch   , pei_us_aa , pei_us_bb];
    Xie_us_v = [Xch_til     , Xaa_til   , Xbb_til];
   
    MMus_usd = Xus    *p_us_usd*sum(pus_v.*[(1-alph)*pie_us_v.*(1-Xie_us_v), alph*pei_us_v.*(1-Xie_us_v)]);
    MMus_chy = (1-Xus)*p_us_chy*sum(pus_v.*[(1-alph)*pie_us_v.*(  Xie_us_v), alph*pei_us_v.*(  Xie_us_v)]);
    
%     MMus_usd = Xus*p_us_usd*(...
%         (1-alph)*(pim_us_eu*pie_us_eu*(1-Xeu_til) + pim_us_rw*pie_us_rw*(1-Xrw_til))+...
%         alph    *(pex_us_eu*pei_us_eu*(1-Xeu_til) + pex_us_rw*pei_us_rw*(1-Xrw_til)));
%     
%     MMus_eur = (1-Xus)*p_us_eur*(...
%         (1-alph)*(pim_us_eu*pie_us_eu*(Xeu_til) + pim_us_rw*pie_us_rw*(Xrw_til))+...
%         alph    *(pex_us_eu*pei_us_eu*(Xeu_til) + pex_us_rw*pei_us_rw*(Xrw_til)));
    
    MMus = m_us*(MMus_usd + MMus_chy)*kap;
    
    %CH mismatch costs
    pie_ch_v = [pie_ch_us   , pie_ch_aa , pie_ch_bb];
    pei_ch_v = [pei_ch_us   , pei_ch_aa , pei_ch_bb];
    Xie_ch_v = [Xus_til     , Xaa_til   , Xbb_til];
   
    MMch_usd = Xch    *p_ch_usd*sum(pch_v.*[(1-alph)*pie_ch_v.*(1-Xie_ch_v), alph*pei_ch_v.*(1-Xie_ch_v)]);
    MMch_chy = (1-Xch)*p_ch_chy*sum(pch_v.*[(1-alph)*pie_ch_v.*(  Xie_ch_v), alph*pei_ch_v.*(  Xie_ch_v)]);
    
    MMch = m_ch*(MMch_usd + MMch_chy)*kap;
    

    %Region A mismatch costs
    pie_aa_v = [pie_aa_us  pie_aa_ch  , pie_aa_aa , pie_aa_bb];
    pei_aa_v = [pei_aa_us  pei_aa_ch  , pei_aa_aa , pei_aa_bb];
    Xie_aa_v = [Xus_til     Xch_til   , Xaa_til   , Xbb_til];
   
    MMaa_usd = Xaa    *p_aa_usd*sum(paa_v.*[(1-alph)*pie_aa_v.*(1-Xie_aa_v), alph*pei_aa_v.*(1-Xie_aa_v)]);
    MMaa_chy = (1-Xaa)*p_aa_chy*sum(paa_v.*[(1-alph)*pie_aa_v.*(  Xie_aa_v), alph*pei_aa_v.*(  Xie_aa_v)]);
    
    MMaa = m_aa*(MMaa_usd + MMaa_chy)*kap;
    
    
    %Region B mismatch costs
    pie_bb_v = [  pie_bb_ch pie_bb_us , pie_bb_bb , pie_bb_aa];
    pei_bb_v = [  pei_bb_ch pei_bb_us , pei_bb_bb , pei_bb_aa];
    Xie_bb_v = [  Xch_til     Xus_til   , Xbb_til   , Xaa_til];
   
    MMbb_usd = Xbb    *p_bb_usd*sum(pbb_v.*[(1-alph)*pie_bb_v.*(1-Xie_bb_v), alph*pei_bb_v.*(1-Xie_bb_v)]);
    MMbb_chy = (1-Xbb)*p_bb_chy*sum(pbb_v.*[(1-alph)*pie_bb_v.*(  Xie_bb_v), alph*pei_bb_v.*(  Xie_bb_v)]);
    
    MMbb = m_bb*(MMbb_usd + MMbb_chy)*kap;
    
    
    %**************************************************************************
    % PROFITS - should be zero
    %**************************************************************************
    PROFus_pc = m_us*(Xus*Pi_us_usd + (1-Xus)*Pi_us_chy);
    PROFch_pc = m_ch*(Xch*Pi_ch_usd + (1-Xch)*Pi_ch_chy);
    PROFaa_pc = m_aa*(Xaa*Pi_aa_usd + (1-Xaa)*Pi_aa_chy);
    PROFbb_pc = m_bb*(Xbb*Pi_bb_usd + (1-Xbb)*Pi_bb_chy);
    
    %**************************************************************************
    % Import Tariffs Collected - per capita
    %**************************************************************************
    UStariff =                           tax_us_ch*Pus_ch*Cus_ch + tax_us_aa  *Pus_rowa*Cus_rowa + tax_us_bb  *Pus_rowb*Cus_rowb;
    CHtariff = tax_ch_us*Pch_us*Cch_us +                           tax_ch_aa  *Pch_rowa*Cch_rowa + tax_ch_bb  *Pch_rowb*Cch_rowb;
    AAtariff = tax_aa_us*Paa_us*Caa_us + tax_aa_ch*Paa_ch*Caa_ch + tax_aa_rowa*Paa_rowa*Caa_rowa + tax_aa_rowb*Paa_rowb*Caa_rowb;
    BBtariff = tax_bb_us*Pbb_us*Cbb_us + tax_bb_ch*Pbb_ch*Cbb_ch + tax_bb_rowa*Pbb_rowa*Cbb_rowa + tax_bb_rowb*Pbb_rowb*Cbb_rowb;
    
    %**************************************************************************
    % Export Tariffs Collected - per capita
    %**************************************************************************
    USetariff = Pus_us*(                            mu_ch*etax_ch_us*Cch_us     + mu_aa*etax_aa_us*Caa_us   + mu_bb*etax_bb_us*Cbb_us  )/mu_us;
    CHetariff = Pch_ch*(mu_us*etax_us_ch*Cus_ch                                 + mu_aa*etax_aa_ch*Caa_ch   + mu_bb*etax_bb_ch*Cbb_ch  )/mu_ch;
    AAetariff = Paa_aa*(mu_us*etax_us_aa*Cus_rowa + mu_ch*etax_ch_aa*Cch_rowa   +                           + mu_bb*etax_bb_aa*Cbb_rowa)/mu_aa;
    BBetariff = Pbb_bb*(mu_us*etax_us_bb*Cus_rowb + mu_ch*etax_ch_bb*Cch_rowb   + mu_aa*etax_aa_bb*Caa_rowb                            )/mu_bb;
    
    
    %**************************************************************************
    % Capital Control Taxes Collected - per capita
    %**************************************************************************
    USD_return_tax = mu_ch/mu_us*(btau_ch_usd)*Pusd*Bch_usd*Qusd +...
                        mu_aa/mu_us*(btau_aa_usd)*Pusd*Baa_usd*Qusd +...
                        mu_bb/mu_us*(btau_bb_usd)*Pusd*Bbb_usd*Qusd;
                    
    CHY_return_tax = mu_us/mu_ch*(btau_us_chy)*Pchy*Bus_chy*Qchy + ...
                        mu_aa/mu_ch*(btau_aa_chy)*Pchy*Baa_chy*Qchy + ...
                        mu_bb/mu_ch*(btau_bb_chy)*Pchy*Bbb_chy*Qchy;
                    
    %**************************************************************************
    % X taxes Collected (in per capita units)
    %**************************************************************************
    USD_xtaxes = r*(mu_ch*m_ch*(Xch  )*p_ch_usd*xtax_ch_usd + mu_aa*m_aa*(Xaa  )*p_aa_usd*xtax_aa_usd + mu_bb*m_bb*(Xbb  )*p_bb_usd*xtax_bb_usd)/mu_us ;  
    CHY_xtaxes = r*(mu_us*m_us*(1-Xus)*p_us_chy*xtax_us_chy + mu_aa*m_aa*(1-Xaa)*p_aa_chy*xtax_aa_chy + mu_bb*m_bb*(1-Xbb)*p_bb_chy*xtax_bb_chy)/mu_ch ;  
    
    
    taxes_ = [UStariff, CHtariff ,AAtariff ,BBtariff; ...
             USetariff, CHetariff,AAetariff,BBetariff; ...
             USD_return_tax CHY_return_tax  NaN NaN;
             USD_xtaxes, CHY_xtaxes, NaN NaN];
         
    %**************************************************************************
    %US equations
    %**************************************************************************
    fus = sym([]);
    if prefs_type == 0
        fus(end+1) = ((1-a_us)*mu_us_ch/(a_us))*(Cus_us/Cus_ch  )^(1/eta) - ((1+tax_us_ch)*Pus_ch  )/Pus_us;
        fus(end+1) = ((1-a_us)*mu_us_aa/(a_us))*(Cus_us/Cus_rowa)^(1/eta) - ((1+tax_us_aa)*Pus_rowa)/Pus_us;
        fus(end+1) = ((1-a_us)*mu_us_bb/(a_us))*(Cus_us/Cus_rowb)^(1/eta) - ((1+tax_us_bb)*Pus_rowb)/Pus_us;
    else
        fus(end+1) = ((1-a_us)*mu_us_ch/(a_us))^(1/eta)*(Cus_us/Cus_ch  )^(1/eta) - ((1+tax_us_ch)*Pus_ch  )/Pus_us;
        fus(end+1) = ((1-a_us)*mu_us_aa/(a_us))^(1/eta)*(Cus_us/Cus_rowa)^(1/eta) - ((1+tax_us_aa)*Pus_rowa)/Pus_us;
        fus(end+1) = ((1-a_us)*mu_us_bb/(a_us))^(1/eta)*(Cus_us/Cus_rowb)^(1/eta) - ((1+tax_us_bb)*Pus_rowb)/Pus_us;
    end
    
    %NOTE: where are adjustment costs in BC?   
    
    fus(end+1) = Pus_us*Cus_us + Pus_ch*Cus_ch + Pus_rowa*Cus_rowa + Pus_rowb*Cus_rowb ...
               + Pusd*(Busd_l/mu_us) + Pusd*Bus_usd*Qusd*(1 - del_us_usd) + Pchy*Bus_chy*Qchy*(1 - del_us_chy + btau_us_chy) + Bus_row*Qrow*(1-0*del_us_row)...
               - (1-phi_usg)*Pus_us*Yus - Pusd*Qusd*Busd/mu_us  - Pusd*Bus_usd_l - Pchy*Bus_chy_l*(1 - 0) - Bus_row_l - PROFus_pc - m_us*fc_us - MMus ...
               - USD_return_tax - USD_xtaxes - USetariff - 0*UStariff;
    
          % fus(1:4)= [1,Bus_chy,Qchy,(1 - del_us_chy)];
    us_euler = sym(zeros(1,3));
    us_euler(1) = 1-bet*(Cus_p/Cus)^(-sig)*(Pus/Pus_p)*(Pusd_p/Pusd)* ( 1 + Qusd_p*tau_us_usd_p)/( Qusd*(1 + tau_us_usd - del_us_usd) );
    us_euler(2) = 1-bet*(Cus_p/Cus)^(-sig)*(Pus/Pus_p)*(Pchy_p/Pchy)* ( 1 + Qchy_p*tau_us_chy_p)/( Qchy*(1 + tau_us_chy - del_us_chy + btau_us_chy) );
    us_euler(3) = 1-bet*(Cus_p/Cus)^(-sig)*(Pus/Pus_p)*(1     /1   )* ( 1 + Qrow_p*tau_us_row_p)/( Qrow*(1 + tau_us_row - del_us_row) );
          
    %**************************************************************************
    %CH equations
    %**************************************************************************
    fch = sym([]);
    if prefs_type == 0
        fch(end+1) = ((1-a_ch)*mu_ch_us/(a_ch))*(Cch_ch/Cch_us  )^(1/eta) - ((1+tax_ch_us)*Pch_us  )/Pch_ch;
        fch(end+1) = ((1-a_ch)*mu_ch_aa/(a_ch))*(Cch_ch/Cch_rowa)^(1/eta) - ((1+tax_ch_aa)*Pch_rowa)/Pch_ch;
        fch(end+1) = ((1-a_ch)*mu_ch_bb/(a_ch))*(Cch_ch/Cch_rowb)^(1/eta) - ((1+tax_ch_bb)*Pch_rowb)/Pch_ch;
    else
        fch(end+1) = ((1-a_ch)*mu_ch_us/(a_ch))^(1/eta)*(Cch_ch/Cch_us  )^(1/eta) - ((1+tax_ch_us)*Pch_us  )/Pch_ch;
        fch(end+1) = ((1-a_ch)*mu_ch_aa/(a_ch))^(1/eta)*(Cch_ch/Cch_rowa)^(1/eta) - ((1+tax_ch_aa)*Pch_rowa)/Pch_ch;
        fch(end+1) = ((1-a_ch)*mu_ch_bb/(a_ch))^(1/eta)*(Cch_ch/Cch_rowb)^(1/eta) - ((1+tax_ch_bb)*Pch_rowb)/Pch_ch;
    end
    
                    
    fch(end+1) = Pch_ch*Cch_ch + Pch_us*Cch_us + Pch_rowa*Cch_rowa + Pch_rowb*Cch_rowb ...
               + Pchy*(Bchy_l/mu_ch) + Pchy*Bch_chy*Qchy*(1 - del_ch_chy) + Pusd*Bch_usd*Qusd*(1 - del_ch_usd + btau_ch_usd) + Bch_row*Qrow*(1-0*del_ch_row) ...
               - (1-phi_chg)*Pch_ch*Ych - Pchy*Qchy*Bchy/mu_ch  - Pchy*Bch_chy_l - Pusd*Bch_usd_l*(1 - 0)  - Bch_row_l - PROFch_pc - m_ch*fc_ch - MMch ...
               - CHY_return_tax - CHY_xtaxes - CHetariff - 0*CHtariff ;
    
    %NOTE: where are adjustment costs in BC?   
    ch_euler = sym(zeros(1,2));
    ch_euler(1) = 1-bet*(Cch_p/Cch)^(-sig)*(Pch/Pch_p)*(Pusd_p/Pusd)* ( 1 + Qusd_p*tau_ch_usd_p)/( Qusd*(1 + tau_ch_usd - del_ch_usd + btau_ch_usd) );
    ch_euler(2) = 1-bet*(Cch_p/Cch)^(-sig)*(Pch/Pch_p)*(Pchy_p/Pchy)* ( 1 + Qchy_p*tau_ch_chy_p)/( Qchy*(1 + tau_ch_chy - del_ch_chy) );
    ch_euler(3) = 1-bet*(Cch_p/Cch)^(-sig)*(Pch/Pch_p)*(1     /1   )* ( 1 + Qrow_p*tau_ch_row_p)/( Qrow*(1 + tau_ch_row - del_ch_row) );
    
    %**************************************************************************
    %AA equations
    %**************************************************************************
    faa = sym([]);
    if prefs_type == 0
        faa(end+1) = ((1-a_aa)*mu_aa_us /a_aa)*(Caa_aa/Caa_us  )^(1/eta) - ((1+tax_aa_us  )*Paa_us  )/Paa_aa;
        faa(end+1) = ((1-a_aa)*mu_aa_ch /a_aa)*(Caa_aa/Caa_ch  )^(1/eta) - ((1+tax_aa_ch  )*Paa_ch  )/Paa_aa;
        faa(end+1) = ((1-a_aa)*mu_aa_aa /a_aa)*(Caa_aa/Caa_rowa)^(1/eta) - ((1+tax_aa_rowa)*Paa_rowa)/Paa_aa;
        faa(end+1) = ((1-a_aa)*mu_aa_bb /a_aa)*(Caa_aa/Caa_rowb)^(1/eta) - ((1+tax_aa_rowb)*Paa_rowb)/Paa_aa;
    else
        faa(end+1) = ((1-a_aa)*mu_aa_us /a_aa)^(1/eta)*(Caa_aa/Caa_us  )^(1/eta) - ((1+tax_aa_us  )*Paa_us  )/Paa_aa;
        faa(end+1) = ((1-a_aa)*mu_aa_ch /a_aa)^(1/eta)*(Caa_aa/Caa_ch  )^(1/eta) - ((1+tax_aa_ch  )*Paa_ch  )/Paa_aa;
        faa(end+1) = ((1-a_aa)*mu_aa_aa /a_aa)^(1/eta)*(Caa_aa/Caa_rowa)^(1/eta) - ((1+tax_aa_rowa)*Paa_rowa)/Paa_aa;
        faa(end+1) = ((1-a_aa)*mu_aa_bb /a_aa)^(1/eta)*(Caa_aa/Caa_rowb)^(1/eta) - ((1+tax_aa_rowb)*Paa_rowb)/Paa_aa;
    end
    
    walrasaa_= Paa_aa*Caa_aa + Paa_us*Caa_us + Paa_ch*Caa_ch + Paa_rowa*Caa_rowa + Paa_rowb*Caa_rowb + ...
                 + 1*(Baa/mu_aa) + Pusd*Baa_usd*Qusd*(1 - del_aa_usd + btau_aa_usd) + Pchy*Baa_chy*Qchy*(1 - del_aa_chy + btau_aa_chy) + Baa_row*Qrow*(1-0*del_aa_row) ...
                 - (1-phi_aag)*Paa_aa*Yaa  - Qrow*Baa/mu_aa - Pusd*Baa_usd_l - Pchy*Baa_chy_l - Baa_row_l - PROFaa_pc - m_aa*fc_aa - MMaa ...
                 - AAetariff - 0*AAtariff;
    
    aa_euler = sym(zeros(1,2));
    aa_euler(1) = 1- bet*(Caa_p/Caa)^(-sig)*(Paa/Paa_p)*(Pusd_p/Pusd)*( 1  + Qusd_p*tau_aa_usd_p)/(Qusd*(1 + tau_aa_usd - del_aa_usd + btau_aa_usd) );
    aa_euler(2) = 1- bet*(Caa_p/Caa)^(-sig)*(Paa/Paa_p)*(Pchy_p/Pchy)*( 1  + Qchy_p*tau_aa_chy_p)/(Qchy*(1 + tau_aa_chy - del_aa_chy + btau_aa_chy) );
    aa_euler(3) = 1 -bet*(Caa_p/Caa)^(-sig)*(Paa/Paa_p)*(1     /1   )*( 1  + Qrow_p*tau_aa_row_p)/(Qrow*(1 + tau_aa_row - del_aa_row) );
    
    %**************************************************************************
    %BB equations
    %**************************************************************************
    fbb = sym([]);
    if prefs_type == 0
        fbb(end+1) = ((1-a_bb)*mu_bb_us /a_bb)*(Cbb_bb/Cbb_us  )^(1/eta) - ((1+tax_bb_us  )*Pbb_us  )/Pbb_bb;
        fbb(end+1) = ((1-a_bb)*mu_bb_ch /a_bb)*(Cbb_bb/Cbb_ch  )^(1/eta) - ((1+tax_bb_ch  )*Pbb_ch  )/Pbb_bb;
        fbb(end+1) = ((1-a_bb)*mu_bb_aa /a_bb)*(Cbb_bb/Cbb_rowa)^(1/eta) - ((1+tax_bb_rowa)*Pbb_rowa)/Pbb_bb;
        fbb(end+1) = ((1-a_bb)*mu_bb_bb /a_bb)*(Cbb_bb/Cbb_rowb)^(1/eta) - ((1+tax_bb_rowb)*Pbb_rowb)/Pbb_bb;
    else
        fbb(end+1) = ((1-a_bb)*mu_bb_us /a_bb)^(1/eta)*(Cbb_bb/Cbb_us  )^(1/eta) - ((1+tax_bb_us  )*Pbb_us  )/Pbb_bb;
        fbb(end+1) = ((1-a_bb)*mu_bb_ch /a_bb)^(1/eta)*(Cbb_bb/Cbb_ch  )^(1/eta) - ((1+tax_bb_ch  )*Pbb_ch  )/Pbb_bb;
        fbb(end+1) = ((1-a_bb)*mu_bb_aa /a_bb)^(1/eta)*(Cbb_bb/Cbb_rowa)^(1/eta) - ((1+tax_bb_rowa)*Pbb_rowa)/Pbb_bb;
        fbb(end+1) = ((1-a_bb)*mu_bb_bb /a_bb)^(1/eta)*(Cbb_bb/Cbb_rowb)^(1/eta) - ((1+tax_bb_rowb)*Pbb_rowb)/Pbb_bb;
    end
  
    
    bb_euler = sym(zeros(1,2));
    bb_euler(1) = 1- bet*(Cbb_p/Cbb)^(-sig)*(Pbb/Pbb_p)*(Pusd_p/Pusd)*( 1  + Qusd_p*tau_bb_usd_p)/(Qusd*(1 + tau_bb_usd - del_bb_usd + btau_bb_usd) );
    bb_euler(2) = 1- bet*(Cbb_p/Cbb)^(-sig)*(Pbb/Pbb_p)*(Pchy_p/Pchy)*( 1  + Qchy_p*tau_bb_chy_p)/(Qchy*(1 + tau_bb_chy - del_bb_chy + btau_bb_chy)  );
    bb_euler(3) = 1 -bet*(Cbb_p/Cbb)^(-sig)*(Pbb/Pbb_p)*(1     /1   )*( 1  + Qrow_p*tau_bb_row_p)/(Qrow*(1 + tau_bb_row - del_bb_row) );
    
    walrasbb_ = Pbb_bb*Cbb_bb + Pbb_us*Cbb_us + Pbb_ch*Cbb_ch + Pbb_rowa*Cbb_rowa + Pbb_rowb*Cbb_rowb ...
                 + 1*(Bbb/mu_bb) + Pusd*Bbb_usd*Qusd*(1 - del_bb_usd + btau_bb_usd) + Pchy*Bbb_chy*Qchy*(1 - del_bb_chy + btau_bb_chy) + Bbb_row*Qrow*(1-0*del_bb_row) + Pusd*(BBbb_usd*Qusd-BBbb_usd_l)... %Last term is expense/income from fixed exogenous bond holdings required by dollar sanctions
                 - (1-phi_bbg)*Pbb_bb*Ybb  - Qrow*Bbb/mu_bb - Pusd*Bbb_usd_l - Pchy*Bbb_chy_l - Bbb_row_l - PROFbb_pc - m_bb*fc_bb - MMbb ...
                 - BBetariff - 0*BBtariff;  

    %**************************************************************************
    % Import Quantities Per Capita
    %**************************************************************************
    for hh = 1:4
        for oo = 1:4
            if ~strcmp(home{hh},origr{oo}(1:2))
                str = ['IMP' home{hh}, '_', away{oo}, ' = m_' home{hh} '*pim_' home{hh} '_' away{oo} ...
                    '*(X' home{hh} '*p_' home{hh} '_usd + (1-X' home{hh} ')*p_' home{hh} '_chy)' ...
                    '*(pie_' home{hh} '_' away{oo} '/PW' home{hh} '_' origr{oo} ');'];
                disp(str);
                eval(str);
            end
        end
    end
%     
%     IMPus_eu = m_us*pim_us_eu*(Xus*p_us_usd +(1-Xus)*p_us_eur)*(pie_us_eu*1/PWus_eu);
%     IMPus_rw = m_us*pim_us_rw*(Xus*p_us_usd +(1-Xus)*p_us_eur)*(pie_us_rw*1/PWus_rw);
%     
%     IMPeu_us = m_eu*pim_eu_us*(Xeu*p_eu_usd +(1-Xeu)*p_eu_eur)*(pie_eu_us*1/PWeu_us);
%     IMPeu_rw = m_eu*pim_eu_rw*(Xeu*p_eu_usd +(1-Xeu)*p_eu_eur)*(pie_eu_rw*1/PWeu_rw);
%     
%     IMPrw_us = m_rw*pim_rw_us*(Xrw*p_rw_usd +(1-Xrw)*p_rw_eur)*(pie_rw_us*1/PWrw_us);
%     IMPrw_eu = m_rw*pim_rw_eu*(Xrw*p_rw_usd +(1-Xrw)*p_rw_eur)*(pie_rw_eu*1/PWrw_eu);
%     IMPrw_rw = m_rw*pim_rw_row*(Xrw*p_rw_usd +(1-Xrw)*p_rw_eur)*(pie_rw_rw*1/PWrw_row);
%     
    
    %**************************************************************************
    %Market Clearing Equations
    %**************************************************************************
    fmc = sym([]);
    fmc(end+1) = Cus_ch      - IMPus_ch;
    fmc(end+1) = Cus_rowa    - IMPus_aa;
    fmc(end+1) = Cus_rowb    - IMPus_bb;
    
    fmc(end+1) = Cch_us      - IMPch_us;
    fmc(end+1) = Cch_rowa    - IMPch_aa;
    fmc(end+1) = Cch_rowb    - IMPch_bb;
    
    fmc(end+1) = Caa_us    - IMPaa_us;
    fmc(end+1) = Caa_ch    - IMPaa_ch;
    fmc(end+1) = Caa_rowa  - IMPaa_aa;
    fmc(end+1) = Caa_rowb  - IMPaa_bb;
    
    fmc(end+1) = Cbb_us    - IMPbb_us;
    fmc(end+1) = Cbb_ch    - IMPbb_ch;
    fmc(end+1) = Cbb_rowa  - IMPbb_aa;
    fmc(end+1) = Cbb_rowb  - IMPbb_bb;
    
    %**************************************************************************
    %Make Symbolic Residula Vector
    %**************************************************************************
    
    if solve_dyn
        fcombo_dyn = transpose([fus,fch,faa,fbb,PINDS,fmc,100*us_euler,100*ch_euler,100*aa_euler,100*bb_euler,walrasaa_,Paa_aa-Pnumer,100*CUT_aa, 100*CUT_bb]); %Use to have 100's here on eulers
        dpres      = jacobian(fcombo_dyn,[jump_vars,state_vars,def_sub_sym]);
        dfutr      = [jacobian(fcombo_dyn,jump_prime),jacobian(fcombo_dyn,state_prime)];
        dpast      = jacobian(fcombo_dyn,state_lag);
        dpast_def  = jacobian(fcombo_dyn,def_sub_sym);
    else
        
        %Extra eq
        %fcombo     = transpose([fus,fch,faa,fbb,PINDS,fmc,100*us_euler,100*ch_euler,100*aa_euler,100*bb_euler,walrasaa_,walrasbb_,100*CUT_aa, 100*CUT_bb]); fcombo_ss = subs(fcombo,[jump_prime,state_lag,state_prime,param_listp,param_listl],[jump_vars,state_vars,state_vars,param_listt,param_listt]);
        
        %nx=neq
        fcombo     = transpose([fus,fch,faa,fbb,PINDS,fmc,100*us_euler,walrasaa_,walrasbb_,Paa_aa-Pnumer,100*CUT_aa, 100*CUT_bb]); fcombo_ss = subs(fcombo,[jump_prime,state_lag,state_prime,param_listp,param_listl],[jump_vars,state_vars,state_vars,param_listt,param_listt]);
        
        dfcombo_ss = jacobian(fcombo_ss,[jump_vars,state_vars,def_sub_sym]);
        
        dfcombo_tau = jacobian(fcombo_ss,[tax_bb_rowa,tax_aa_rowb,def_sub_sym]);
    end
    
    
    %% make frac(B's)
    
    frac_    = sym(zeros(6,1));
    frac_(1) = Baa_usd*mu_aa/(Busd-mu_bb*BBbb_usd);
    frac_(2) = Bbb_usd*mu_bb/(Busd-mu_bb*BBbb_usd);
    
    frac_(3) = Baa_chy*mu_aa/Bchy;
    frac_(4) = Bbb_chy*mu_bb/Bchy;
    
    
    frac_(5) = Bus_usd*mu_us./((Busd-mu_bb*BBbb_usd)*(1-frac_(1)-frac_(2)));
    frac_(6) = Bch_chy*mu_ch./(Bchy                 *(1-frac_(3)-frac_(4)));
    
    frac_(7) = Bus_row*mu_us/(Baa+Bbb);
    frac_(8) = Bch_row*mu_ch/(Baa+Bbb);
    frac_(9) = Baa_row*mu_aa/((Baa+Bbb)*(1-frac_(7)-frac_(8)));
    
    Bvec = state_vars;%[Baa_usda, Bbb_usda, Baa_chya, Bbb_chya, Bus_usda, Bch_chya,Bus_row,Bch_row,Baa_row];
    
    
    dfrac_ = jacobian(frac_,Bvec);
    
    
    syms frac_aa_usd frac_bb_usd frac_aa_chy frac_bb_chy frac_us_usd frac_ch_chy frac_us_row frac_ch_row frac_aa_row
    B_ = sym(zeros(6,1));
    B_(1) = frac_aa_usd*(Busd-mu_bb*BBbb_usd);
    B_(2) = frac_bb_usd*(Busd-mu_bb*BBbb_usd);
    B_(3) = frac_aa_chy*Bchy;
    B_(4) = frac_bb_chy*Bchy;
    
    B_(5) = frac_us_usd*(1-frac_aa_usd-frac_bb_usd)*(Busd-mu_bb*BBbb_usd);
    B_(6) = frac_ch_chy*(1-frac_aa_chy-frac_bb_chy)*Bchy;
    
    B_(7) = frac_us_row*(Baa+Bbb); 
    B_(8) = frac_ch_row*(Baa+Bbb); 
    B_(9) = frac_aa_row*(1-frac_us_row-frac_ch_row)*(Baa+Bbb); 
    
    
    if redo_bonds && solve_dyn == 1
        matlabFunction(frac_ , 'File', 'auto_generated/B2frac.m', 'Outputs', {'out'}, 'Vars',{Bvec.',Busd,Bchy,Baa,Bbb,mu_us,mu_ch,mu_aa,mu_bb,BBbb_usd}, 'Optimize', optimize);
        matlabFunction(dfrac_, 'File', 'auto_generated/dfrac.m', 'Outputs', {'out'}, 'Vars',symvar(dfrac_), 'Optimize', optimize);
        matlabFunction(B_    , 'File', 'auto_generated/frac2B.m', 'Outputs', {'out'}, 'Vars',{[frac_aa_usd; frac_bb_usd; frac_aa_chy; frac_bb_chy; frac_us_usd; frac_ch_chy; frac_us_row; frac_ch_row; frac_aa_row],Busd,Bchy,Baa,Bbb,mu_us,mu_ch,mu_aa,mu_bb,BBbb_usd}, 'Optimize', optimize);
    end
    %}
    %% THINGS TO COMPUTE
    
    %Interest rates
    Rusd = 1/Qusd - 1;
    Rchy = 1/Qchy - 1;
    Rrow = 1/Qrow - 1;
    
    %DELTAS
    delts_ = [del_us_usd,del_ch_usd,del_aa_usd,del_bb_usd;
              del_us_chy,del_ch_chy,del_aa_chy,del_bb_chy;
              del_us_row,del_ch_row,del_aa_row,del_bb_row];
    
    %BOND HOLDINGS
    bonds_ = [Bus_usd Bch_usd Baa_usd totBbb_usd;
              Bus_chy Bch_chy Baa_chy Bbb_chy;
              Bus_row Bch_row Baa_row Bbb_row];
    
    %PRICES
    prices_ = [Pus    Pch    Paa    Pbb    ;...
               Pus_us,Pch_ch,Paa_aa Pbb_bb];
    
    %Fixed costs in units of home C
    fixed_ = [m_us*fc_us/Pus, m_ch*fc_ch/Pch, m_aa*fc_aa/Paa,m_bb*fc_bb/Pbb];
           
    %Mistmactch costs
    mmc_ = [MMus/Pus, MMch/Pch, MMaa/Paa,MMbb/Pbb];
           
           
           
    %GROSS FOREIGN ASSET POSITIONS (ROW 1, FOREIGN ASSETS; ROW 2, FOREIGN LIABILITIES
    gross_ = [(                    Pchy*Bus_chy*Qchy + Bus_row*Qrow)/(per_p_year*Pus_us*Yus),...
              (Pusd*   Bch_usd*Qusd +                     Bch_row*Qrow)/(per_p_year*Pch_ch*Ych),...
              (Pusd*   Baa_usd*Qusd + Pchy*Baa_chy*Qchy + Baa_row*Qrow)/(per_p_year*Paa_aa*Yaa),...
              (Pusd*totBbb_usd*Qusd + Pchy*Bbb_chy*Qchy + Bbb_row*Qrow)/(per_p_year*Pbb_bb*Ybb);...
              Pusd*(Bch_usd*mu_ch+Baa_usd*mu_aa+totBbb_usd*mu_bb)*Qusd/(per_p_year*Pus_us*Yus*mu_us) ...  
              Pchy*(Bus_chy*mu_us+Baa_chy*mu_aa+   Bbb_chy*mu_bb)*Qchy/(per_p_year*Pch_ch*Ych*mu_ch) ...
              1   *(Baa/mu_aa)*Qrow/(per_p_year*Paa_aa*Yaa),...
              1   *(Bbb/mu_bb)*Qrow/(per_p_year*Pbb_bb*Ybb)];
    
    %Trade share
    PWIus = [        PWus_ch PWus_rowa PWus_rowb];
    PWIch = [PWch_us         PWch_rowa PWch_rowb];
    PWIaa = [PWaa_us PWaa_ch PWaa_rowa PWaa_rowb];
    PWIbb = [PWbb_us PWbb_ch PWbb_rowa PWbb_rowb];
    
    PWEus = [          PWch_us   PWaa_us   PWbb_us];  
    PWEch = [PWus_ch             PWaa_ch   PWbb_ch];  
    PWEaa = [PWus_rowa PWch_rowa PWaa_rowa PWbb_rowa];  
    PWEbb = [PWus_rowb PWch_rowb PWaa_rowb PWbb_rowb];
    
    CIus = [        Cus_ch Cus_rowa Cus_rowb];
    CIch = [Cch_us         Cch_rowa Cch_rowb];
    CIaa = [Caa_us Caa_ch Caa_rowa Caa_rowb];
    CIbb = [Cbb_us Cbb_ch Cbb_rowa Cbb_rowb];
    
    CEus = [          Cch_us   Caa_us   Cbb_us];  
    CEch = [Cus_ch             Caa_ch   Cbb_ch];  
    CEaa = [Cus_rowa Cch_rowa Caa_rowa Cbb_rowa];  
    CEbb = [Cus_rowb Cch_rowb Caa_rowb Cbb_rowb];
    
    ts_ = [(sum(mu_us.*PWIus.*CIus) + sum([      mu_ch,mu_aa,mu_bb].*PWEus.*CEus))/(mu_us*Pus_us*Yus)...
           (sum(mu_ch.*PWIch.*CIch) + sum([mu_us,      mu_aa,mu_bb].*PWEch.*CEch))/(mu_ch*Pch_ch*Ych)...
           (sum(mu_aa.*PWIaa.*CIaa) + sum([mu_us,mu_ch,mu_aa,mu_bb].*PWEaa.*CEaa))/(mu_aa*Paa_aa*Yaa)...
           (sum(mu_bb.*PWIbb.*CIbb) + sum([mu_us,mu_ch,mu_aa,mu_bb].*PWEbb.*CEbb))/(mu_bb*Pbb_bb*Ybb)];
          
    %Trade balance
    tb_ = -[(sum(mu_us.*PWIus.*CIus) - sum([      mu_ch,mu_aa,mu_bb].*PWEus.*CEus))/(mu_us*Pus_us*Yus)...
           (sum(mu_ch.*PWIch.*CIch) - sum([mu_us,      mu_aa,mu_bb].*PWEch.*CEch))/(mu_ch*Pch_ch*Ych)...
           (sum(mu_aa.*PWIaa.*CIaa) - sum([mu_us,mu_ch,mu_aa,mu_bb].*PWEaa.*CEaa))/(mu_aa*Paa_aa*Yaa)...
           (sum(mu_bb.*PWIbb.*CIbb) - sum([mu_us,mu_ch,mu_aa,mu_bb].*PWEbb.*CEbb))/(mu_bb*Pbb_bb*Ybb)];
       
       
     %world export
    wexp_ = [ 0 [      mu_ch,mu_aa,mu_bb].*PWEus.*CEus;...
             [mu_us,      mu_aa,mu_bb].*PWEch.*CEch 0;...
             [mu_us,mu_ch,mu_aa,mu_bb].*PWEaa.*CEaa;
             [mu_us,mu_ch,mu_aa,mu_bb].*PWEbb.*CEbb];
    wexp_(2,:) = wexp_(2,[1 4 2 3]);  %Put zero in CH col for CH export.
    
    wimp_ =   [0,mu_us.*PWIus.*CIus;  mu_ch.*PWIch.*CIch, 0; mu_aa.*PWIaa.*CIaa;mu_bb.*PWIbb.*CIbb];
    wimp_(2,:) = wimp_(2,[1 4 2 3]);  %Put zero in CH col for CH imports.
    
    %Home bias in portfolios #CHECK ROSEN!#
    sh_us_usd   = Pusd*Bus_usd*Qusd/(Pchy*Bus_chy*Qchy + Pusd*Bus_usd*Qusd + Bus_row*Qrow);
    sh_ch_usd   = Pusd*Bch_usd*Qusd/(Pchy*Bch_chy*Qchy + Pusd*Bch_usd*Qusd + Bch_row*Qrow);
    sh_aa_usd   = Pusd*Baa_usd*Qusd/(Pchy*Baa_chy*Qchy + Pusd*Baa_usd*Qusd + Baa_row*Qrow);
    sh_bb_usd   = Pusd*Bbb_usd*Qusd/(Pchy*Bbb_chy*Qchy + Pusd*Bbb_usd*Qusd + Bbb_row*Qrow);
    
    sh_us_chy   = 1-sh_us_usd;
    sh_ch_chy   = 1-sh_ch_usd;
    sh_aa_chy   = 1-sh_aa_usd;
    sh_bb_chy   = 1-sh_bb_usd;
    
    sh_wrld_usd = Pusd*(Busd)*Qusd/(Pchy*(Bchy)*Qchy  + Pusd*(Busd)*Qusd);
    sh_wrld_chy = Pchy*(Bchy)*Qchy/(Pusd*(Busd)*Qusd  + Pchy*(Bchy)*Qchy);
    
    
    home_bias_ = [1 - sh_us_chy/sh_wrld_chy, 1 - sh_ch_usd/sh_wrld_usd,0 0];
    
    usd_shr_ = [sh_us_usd,sh_ch_usd,sh_aa_usd,sh_bb_usd];
    
    %EP
    EP_ = -100*((1+Rusd)^per_p_year - (1+Rchy)^per_p_year);
    
    %Gross debts
    GD_ = [Pusd*Qusd*Busd/(per_p_year*mu_us*Pus_us*Yus), ...
           Pchy*Qchy*Bchy/(per_p_year*mu_ch*Pch_ch*Ych),...
           1   *Qrow*Baa /(per_p_year*mu_aa*Paa_aa*Yaa),...
           1   *Qrow*Bbb /(per_p_year*mu_bb*Pbb_bb*Ybb)];
    
    %Implied revenue (what if all my assets and liabilities earned a counterfactual
    %interest rate, not valid yet when BBbb_usd > 0)
    IR_    = ((Rchy*Pchy*Bus_chy*mu_us*Qchy - Rusd*Pusd*(Bch_usd*mu_ch+Baa_usd*mu_aa+Bbb_usd*mu_bb)*Qusd)-(1/bet-1)*(Pchy*Bus_chy*mu_us*Qchy-Pusd*(Bch_usd*mu_ch+Baa_usd*mu_aa+Bbb_usd*mu_bb)*Qusd))./(mu_us*Pus_us*Yus);
    IR_(2) = ((Rusd*Pusd*Bch_usd*mu_ch*Qusd - Rchy*Pchy*(Bus_chy*mu_us+Baa_chy*mu_aa+Bbb_chy*mu_bb)*Qchy)-(1/bet-1)*(Pusd*Bch_usd*mu_ch*Qusd-Pchy*(Bus_chy*mu_us+Baa_chy*mu_aa+Bbb_chy*mu_bb)*Qchy))./(mu_ch*Pch_ch*Ych);
    IR_(3) = NaN;
    IR_(4) = NaN;((Rchy*Pchy*Bus_chy*mu_us*Qchy - Rusd*Pusd*(Bch_usd*mu_ch+Baa_usd*mu_aa+Bbb_usd*mu_bb)*Qusd)-(1/bet-1)*(Pchy*Bus_chy*mu_us*Qchy-Pusd*(Bch_usd*mu_ch+Baa_usd*mu_aa+Bbb_usd*mu_bb)*Qusd)); %Gross seniorage
    
    
    IR_    = ((-Rusd*Pusd*(Bch_usd*mu_ch+Baa_usd*mu_aa+Bbb_usd*mu_bb)*Qusd)-(1/bet-1)*(-Pusd*(Bch_usd*mu_ch+Baa_usd*mu_aa+Bbb_usd*mu_bb)*Qusd))./(mu_us*Pus_us*Yus);  %Gross seniorage
    IR_(2) = ((-Rchy*Pchy*(Bus_chy*mu_us+Baa_chy*mu_aa+Bbb_chy*mu_bb)*Qchy)-(1/bet-1)*(-Pchy*(Bus_chy*mu_us+Baa_chy*mu_aa+Bbb_chy*mu_bb)*Qchy))./(mu_ch*Pch_ch*Ych);  %Gross seniorage
    IR_(3) = NaN;
    IR_(4) = NaN;
   
    
    
    %Funding probs
    fund_probs_ = [p_us_usd p_ch_usd p_aa_usd p_bb_usd;...
                   p_us_chy p_ch_chy p_aa_chy p_bb_chy];
    
    %Trade matching probs
    tr_probs_ = [0        , pei_us_ch, pei_us_aa, pei_us_bb;
                 pei_ch_us, 0        , pei_ch_aa, pei_ch_bb;
                 pei_aa_us, pei_aa_ch, pei_aa_aa, pei_aa_bb;
                 pei_bb_us, pei_bb_ch, pei_bb_aa, pei_bb_bb;
                 0        , pie_us_ch, pie_us_aa, pie_us_bb;
                 pie_ch_us, 0        , pie_ch_aa, pie_ch_bb;
                 pie_aa_us, pie_aa_ch, pie_aa_aa, pie_aa_bb;
                 pie_bb_us, pie_bb_ch, pie_bb_aa, pie_bb_bb;
                 ];
    
    tr_probs_  = subs(tr_probs_, plev,pexp);
    
    PTRAD_ = [NaN       , pim_us_ch, pim_us_aa, pim_us_bb , NaN       , pex_us_ch  ,pex_us_aa, pex_us_bb;
              pim_ch_us ,     NaN  , pim_ch_aa, pim_ch_bb , pex_ch_us , NaN        ,pex_ch_aa, pex_ch_bb;
              pim_aa_us , pim_aa_ch, pim_aa_aa, pim_aa_bb , pex_aa_us , pex_aa_ch  ,pex_aa_aa, pex_aa_bb;
              pim_bb_us , pim_bb_ch, pim_bb_aa, pim_bb_bb , pex_bb_us , pex_bb_ch  ,pex_bb_aa, pex_bb_bb];
    
    
    PTRAD_  = subs(PTRAD_, plev,pexp);
    
    tau_  = [tau_us_usd   tau_ch_usd   tau_aa_usd   tau_bb_usd  ; tau_us_chy   tau_ch_chy   tau_aa_chy   tau_bb_chy];
    taup_ = [tau_us_usd_p tau_ch_usd_p tau_aa_usd_p tau_bb_usd_p; tau_us_chy_p tau_ch_chy_p tau_aa_chy_p tau_bb_chy_p];
    
    returns_ = [ Pusd_p/Pusd*(1/Qusd) Pchy_p/Pchy*(1/Qchy) ];
    
    %Net payoffs of visintg US/EU for EU firms
    %nps_ = [np_us, np_eu, np_rw1, np_rw2]./phi;
    
    
    %% Redo main
    if redo_main
        if solve_dyn
            
            targ_q_  = [sige , kap  , r    , Xaa, GD_(1), ts_(2),ts_(3), Paa_rowb/Pbb_bb, eta , GD_(3),delts_(3,1)]';
            
            vars_dyn = [jump_vars,state_vars,jump_prime,state_prime,state_lag];
            
            matlabFunction(sbar_solve_aa_, 'File', 'auto_generated/sbar_solve.m', 'Outputs', {'out1'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            function_subs_mex('auto_generated/sbar_solve.m', def_sub_call, 'auto_generated/temp.text', def_sub_nms);
            
            matlabFunction(walrasbb_, 'File', 'auto_generated/walras.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            function_subs_mex('auto_generated/walras.m', def_sub_call, 'auto_generated/temp.text', def_sub_nms);
            
            matlabFunction(fcombo_dyn, 'File', 'auto_generated/resid_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            function_subs_mex('auto_generated/resid_dyn.m', def_sub_call, 'auto_generated/temp.text', def_sub_nms);
            
            matlabFunction(dpres, 'File', 'auto_generated/dpres.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            function_subs_mex('auto_generated/dpres.m', def_sub_call, 'auto_generated/temp.text', def_sub_nms);
            
            
            matlabFunction(dfutr, 'File', 'auto_generated/dprlg.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            function_subs_mex('auto_generated/dprlg.m', def_sub_call, 'auto_generated/temp.text', def_sub_nms);
            
            matlabFunction(dpast, 'File', 'auto_generated/dpast.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            function_subs_mex('auto_generated/dpast.m', def_sub_call, 'auto_generated/temp.text', def_sub_nms);
            
            matlabFunction(dpast_def, 'File', 'auto_generated/dpast_def.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            function_subs_mex('auto_generated/dpast_def.m', def_sub_call, 'auto_generated/temp.text', def_sub_nms);
            
            %Outpute for "impulse responses"
            matlabFunction(usd_shr_, 'File', 'auto_generated/usd_shr_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction([Cus,Cch,Caa,Cbb].', 'File', 'auto_generated/cons_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(walrasbb_, 'File', 'auto_generated/walras_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            
            matlabFunction(fixed_, 'File', 'auto_generated/fixed_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(mmc_, 'File', 'auto_generated/mismatch_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(delts_, 'File', 'auto_generated/delts_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(vec(bonds_.'), 'File', 'auto_generated/bonds_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(prices_, 'File', 'auto_generated/prices_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(gross_, 'File', 'auto_generated/gross_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(gross_(1,:)-gross_(2,:), 'File', 'auto_generated/NFA_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(ts_, 'File', 'auto_generated/tshare_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(tb_, 'File', 'auto_generated/tb_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(home_bias_, 'File', 'auto_generated/home_bias_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(EP_, 'File', 'auto_generated/EP_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction([Xaa,Xbb], 'File', 'auto_generated/XRW_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(GD_, 'File', 'auto_generated/GD_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(IR_, 'File', 'auto_generated/ir_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(fund_probs_, 'File', 'auto_generated/fund_probs_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(tr_probs_, 'File', 'auto_generated/tr_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(nps_, 'File', 'auto_generated/nps_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(PTRAD_, 'File', 'auto_generated/PTRAD_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(wexp_, 'File', 'auto_generated/wexp_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(vec(wimp_.'), 'File', 'auto_generated/wimp_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(vec(wexp_.'), 'File', 'auto_generated/wexp_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(targ_q_, 'File', 'auto_generated/targ_q_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(targ_q_, 'File', 'auto_generated/targ_q_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(taxes_, 'File', 'auto_generated/taxes_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            
            
            
            matlabFunction(tau_, 'File', 'auto_generated/tau_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(taup_, 'File', 'auto_generated/taup_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            matlabFunction(returns_, 'File', 'auto_generated/return_dyn.m', 'Outputs', {'out'}, 'Vars',[vars_dyn,def_sub_sym,param_list_dy], 'Optimize', optimize);
            
        else
            %dresid_tau_call = sym2mex_double({'out'},{dfcombo_tau},def_sub_nms,def_sub_val,[jump_vars,state_vars,param_list_ss],'tofill_files/double_tofill.c','auto_generated/dresid_tau_mex.c', 'resid_tau_mex', 'auto_generated');
            
            resid_ss_call = sym2mex_double({'out'},{fcombo_ss},def_sub_nms,def_sub_val,[jump_vars,state_vars,param_list_ss],'tofill_files/double_tofill.c','auto_generated/resid_ss_mex.c', 'resid_ss_mex', 'auto_generated');
            dresid_ss_call = sym2mex_double({'dout'},{dfcombo_ss},def_sub_nms,def_sub_val,[jump_vars,state_vars,param_list_ss],'tofill_files/double_tofill.c','auto_generated/dresid_ss_mex.c', 'dresid_ss_mex','auto_generated');
            
        end
    end
    
    %% Redo Extra
    if redo_extra && solve_dyn == 0
        matlabFunction(taxes_, 'File', 'auto_generated/taxes.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list_ss], 'Optimize', false);
        
        matlabFunction(fixed_, 'File', 'auto_generated/fixed.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list_ss], 'Optimize', false);
         matlabFunction(mmc_, 'File', 'auto_generated/mismatch.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list_ss], 'Optimize', false);
        matlabFunction(delts_, 'File', 'auto_generated/delts.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list_ss], 'Optimize', false);
        matlabFunction(bonds_, 'File', 'auto_generated/bonds.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list_ss], 'Optimize', false);
        matlabFunction(prices_, 'File', 'auto_generated/prices.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list_ss], 'Optimize', false);
        matlabFunction(gross_, 'File', 'auto_generated/gross.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list_ss], 'Optimize', false);
        matlabFunction(ts_   , 'File', 'auto_generated/ts.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list_ss], 'Optimize', false);
        matlabFunction(tb_   , 'File', 'auto_generated/tb.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list_ss], 'Optimize', false);
        matlabFunction(home_bias_, 'File', 'auto_generated/home_bias.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list_ss], 'Optimize', false);
        matlabFunction(EP_   , 'File', 'auto_generated/EP.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list_ss], 'Optimize', false);
        matlabFunction([Xaa,Xbb]   , 'File', 'auto_generated/XRW.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list_ss], 'Optimize', false);
        matlabFunction(GD_   , 'File', 'auto_generated/GD.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list_ss], 'Optimize', false);
        matlabFunction(IR_   , 'File', 'auto_generated/IR.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list_ss], 'Optimize', false);
        matlabFunction(fund_probs_, 'File', 'auto_generated/fund_probs.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list_ss], 'Optimize', false);
        matlabFunction(tr_probs_  , 'File', 'auto_generated/tr_probs.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list_ss], 'Optimize', false);
        matlabFunction(nps_   , 'File', 'auto_generated/nps.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list_ss], 'Optimize', false);
        matlabFunction(PTRAD_   , 'File', 'auto_generated/PTRAD.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list_ss], 'Optimize', false);
        matlabFunction(wexp_   , 'File', 'auto_generated/wexp.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list_ss], 'Optimize', false);
        matlabFunction(wimp_   , 'File', 'auto_generated/wimp.m', 'Outputs', {'out'}, 'Vars',[jump_vars,state_vars,def_sub_sym,param_list_ss], 'Optimize', false);
        
    end
    
    
    %% Redo steady_residual.m and expand_steady.m
    endog_str = []; endog_futr = []; endog_past = [];
    endog_ss_vars = [jump_vars,state_vars];
    endog_futr_vars = [jump_prime,state_prime];
    endog_past_vars = state_lag;
    for jj = 1:length(state_lag)
        endog_past = [endog_past ' ' char(state_lag(jj)) '=xl(' num2str(jj) ');' sprintf('%s\n', '')];
    end
    
    for jj = 1:length(endog_ss_vars)
        endog_str  = [endog_str ' ' char(endog_ss_vars(jj)) '=x(' num2str(jj) ');' sprintf('%s\n', '')];
        endog_futr = [endog_futr ' ' char(endog_futr_vars(jj)) '=xp(' num2str(jj) ');' sprintf('%s\n', '')];
    end
    dfrac_str = args_string(symvar(dfrac_));
    def_args_str   = args_string([vcombo_ss,args_def]);
    def_outs_str   = args_string(def_sub_sym);
    args_endog_str = args_string(endog_ss_vars);
    args_prlg_str  = args_string([endog_ss_vars,endog_futr_vars,endog_past_vars]);
    
    if solve_dyn == 0
        text_insert('tofill_files/steady_residual.text', 'auto_generated/steady_residual.m', {endog_str,args_endog_str,args_param_ss,def_args_str});
        text_insert('tofill_files/expand_steady.text'  , 'auto_generated/expand_steady.m'  , {endog_str,args_endog_str,args_param_ss,def_args_str,def_outs_str});
    else

        text_insert('tofill_files/shooting.text', 'auto_generated/shooting.m', {str_shoot1,str_shoot2,args_param_dy});
        text_insert('tofill_files/dynamic_residual.text', 'auto_generated/dynamic_residual.m', {endog_str,endog_futr,endog_past,args_prlg_str,args_param_dy,def_args_str,dfrac_str});
        text_insert('tofill_files/dynamic_responses.text', 'auto_generated/dynamic_responses.m', {endog_str,endog_futr,endog_past,args_prlg_str,args_param_dy,def_args_str,def_outs_str});
        text_insert('tofill_files/expand_steady2.text', 'auto_generated/expand_steady2.m'    , {endog_str,endog_futr,endog_past,args_prlg_str,args_param_dy,def_args_str,def_outs_str});
        text_insert('tofill_files/sbar_eval.txt', 'auto_generated/sbar_eval.m', {endog_str,endog_futr,endog_past,args_prlg_str,args_param_dy,def_args_str,dfrac_str});
        text_insert('tofill_files/walras_residual.text', 'auto_generated/walras_residual.m', {endog_str,endog_futr,endog_past,args_prlg_str,args_param_dy,def_args_str,def_outs_str});
    end
    
    %Deliver mex version of code, much faster!
    if solve_dyn
        convert_to_mex
    end
    
end
toc

