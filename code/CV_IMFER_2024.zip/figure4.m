%% FIGURE 4 : BASELINE - ATTRACTION REGIONS 
load saved_results/baseline_to_symdollar_transition frac_path
load saved_results/attraction_region_baseline frac_rw_usd_dense frac_rw_chy_dense solve_indic frac_ss



solve_indic_chy = solve_indic<1e-5;
solve_indic_usd = solve_indic_chy';
solve_indic_both = (solve_indic_usd + solve_indic_chy) == 2;
solve_indic_usdonly = solve_indic_usd - solve_indic_both;
solve_indic_chyonly = solve_indic_chy - solve_indic_both;


f1 = figure;
s = subplot(1,1,1);hold on;
s.XLim = frac_rw_usd_dense([1,end]);
s.YLim = frac_rw_chy_dense([1,end]);
s.FontSize = 14;


fgrid      = frac_rw_usd_dense;
fgrid_flip = fliplr(frac_rw_usd_dense);

np = length(frac_rw_chy_dense); 

%Multi
[X,Ym] = shrinkwrap(solve_indic_both,fgrid,fgrid,'below');
[X,Ym] = shrinkwrap(solve_indic_both,fgrid,fgrid,'above',X,Ym);
p3 = patch(X(~isnan(Ym)),Ym(~isnan(Ym)), color_mul);
p3.LineStyle = '-';
p3.LineWidth = .1;
p3.FaceAlpha = 0.8;

%USD zone
[X,Y] = shrinkwrap(solve_indic_usdonly,fgrid,fgrid,'above');
Y(end:-1:end-np+1) = Ym(1:np); %Sub in the bottom of the multi range
p1= patch(X(~isnan(Y)),Y(~isnan(Y)), color_usd);
p1.LineStyle = '-';
p1.LineWidth = .1;
p1.FaceAlpha = 0.8;


%Euro zone
[X,Y] = shrinkwrap(solve_indic_chyonly,fgrid,fgrid,'below');
Y(1:np) = Ym(end:-1:end-np+1); %Sub in top of multi range
p2 = patch(X(~isnan(Y)),Y(~isnan(Y)), color_chy);
p2.LineStyle = '-';
p2.LineWidth = .1;
p2.FaceAlpha = 0.8;




%{
Y1 = fliplr(frac_rw_chy_dense);
X1 = nan(1,length(frac_rw_usd_dense));
for jj = 1:length(X1)
    X1(jj) = frac_rw_usd_dense(find(solve_indic{jj}<1e-5, 1, 'last'));
end

X = [max(frac_rw_usd_dense), X1,min(frac_rw_usd_dense),fliplr(Y1),max(frac_rw_usd_dense)];
Y = [max(frac_rw_chy_dense), Y1,min(frac_rw_chy_dense),fliplr(X1),max(frac_rw_chy_dense)];
p1= patch(X,Y, color_mul);
p1.LineStyle = '-';
p1.LineWidth = .1;
p1.FaceAlpha = 0.8;



X = [max(frac_rw_usd_dense), X1,max(frac_rw_usd_dense),max(frac_rw_usd_dense)];
Y = [max(frac_rw_chy_dense), Y1,min(frac_rw_chy_dense),max(frac_rw_usd_dense)];
p2 = patch(X,Y, color_usd);
p2.LineStyle = '-';
p2.LineWidth = .1;
p2.FaceAlpha = 0.8;


X = [fliplr(Y1),min(frac_rw_usd_dense)];
Y = [fliplr(X1),max(frac_rw_chy_dense)];
p3 = patch(X,Y, color_chy);
p3.LineStyle = '-';
p3.LineWidth = .1;
p3.FaceAlpha = 0.8;
%}

p = scatter(frac_ss(1,[1,3]),frac_ss(3,[1,3]), 'marker', 'o', 'SizeData',75, 'MarkerEdgeColor', [0,0,0], 'MarkerFaceColor', [0 0 0]);
p = scatter(frac_ss(1,2),frac_ss(3,2), 'marker', 'o', 'SizeData', 90, 'MarkerEdgeColor', [0,0,0], 'MarkerFaceColor', [1 1 1]);

xlabel('RW USD bond holdings (fraction of $\bar{B}$)', 'interpreter', 'latex', 'fontsize',18);
ylabel('RW CNY bond holdings (fraction of $\bar{B}$)', 'interpreter', 'latex', 'fontsize',18);


%Add flight path to region
%p = plot(frac_path(1,1:70),frac_path(3,1:70), '-k', 'linewidth', 2.5);
%a=annotation('arrow', frac_path(1,[end-100,end-75]), frac_path(3,[end-100,end-75]));
%a.Parent     = gca;
%a.HeadWidth  = 8;
%a.HeadLength = 8;
%a.Color  = [.7,.7,.7]';
%p.Color  = [.7,.7,.7]';
l = legend([p1,p2,p3],'USD','CNY', 'Indet.', 'location', 'southwest');
l.FontSize = 14;

s.XLim = [.15,.45];
s.YLim = [.15,.45];
saveas(f1, 'saved_figures/figure4.eps', 'epsc')
