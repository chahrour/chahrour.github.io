%% Table 1: Fixed Parameters

%load saved
load saved_results/steady_baseline

cols = {'Param', 'Val'};
rows = {'Bet',  'kap', 'r','mu_us', 'X_{us}', 'X_{ch}', 'alph', 'sig','eta' 'veps', 'sigtht','tau', 'upps', 'btau(%)'};

table_dat = [bet;kap;r;mu_us;Xus;Xch;alph;1;eta;vepst;sige^2;tau;upp_usd;100*btau_aa_chy ];

table_insert('tofill_files/calib_table.text', 'saved_tables/calib_table.tex',...
    table_dat, {'%0.3f','%0.3f','%0.3f','%0.3f','%0.3f','%0.3f','%0.3f','%0.3f','%0.3f','%0.3f','%1.0s', '%1.3f', '%1.3f'});


disp('*******************************************************************')
disp('Table 1: ')
disp('*******************************************************************') 

sprint_mat('% 1.3f \t',table_dat,cols,rows)
disp(' ')

%% Table 2: Calibrated parameters
load saved_results/steady_baseline
disp(' ')
disp('*******************************************************************')
disp('Table 2:');
disp('*******************************************************************')

table_dat = [[.6;0.45;0.35;0.65;.95;1.2;1],[GDs(1);GDs(3);TSHRs(2);TSHRs(3);Xs(3);Paa_rowb/Pbb_bb;1]];
disp('2a: ')
cols = {'Cncpt', 'Data','Model'};
rows = {'D/GDP', 'Daa/GDP','TrC/GDP','TrB/GDP', 'USD%', 'IMKP', 'LS ROW'};
sprint_mat('% 1.2f \t',table_dat,cols,rows)



disp(' ')
disp('2b: ')
cols = {'Param', 'Val'};
rows = {'B', 'Brow','a_ch','a_aa' 'vepsf', 'phi','zrow'};
sprint_mat('% 1.3f \t',[Busd;Baa;a_ch;a_bb;vepsf;phi;zrow],cols,rows)
disp(' ')

table_insert('tofill_files/targets_table.text', 'saved_tables/targets_table.tex',...
    [Busd;Baa;a_us;a_aa;vepsf;phi;zrow], {'%0.3f'});


%% Table 3
disp('*******************************************************************')
disp('Table 3:');
disp('*******************************************************************')

load saved_results/steady_baseline.mat table_dat
Cbase = table_dat(7,1:4);

load saved_results/steady_baseline.mat

disp('3a:')

cols = {'US', 'EZ', 'AA', ' BB', 'US', 'EZ', 'AA', ' BB','US', 'EZ', 'AA', ' BB'};
rows = {'Xj','ExPrv','Sein','NFA','GFA','TB','C'};


%table_dat(:,1:8) = []; % we only want the 3 ss (the last two just fill space)
table_dat(7,:) = repmat(Cbase,[1,3]);
table_dat(2,[2,3, 4, 6, 7, 8, 10 11 12]) = NaN;

sprint_mat('% 1.2f\t',table_dat,cols,rows)

table_insert('tofill_files/steady_table.text', 'saved_tables/steady_table.tex', table_dat, {'%0.2f','%0.2f','%0.2f','%0.2f','%0.2f','%0.2f','%0.2f','%0.3f','%0.3f','%0.3f'});

%% Table 4: Compressed scenarios
disp(' ');
disp('*******************************************************************')
disp('Table 4: Many steady-states')
disp('*******************************************************************')


table_data = NaN(7,3*3);
load saved_results/steady_baseline.mat table_dat
table_data(1,1+[0 3 6]) = table_dat(2,  [1,5,9]); %Priv
table_data(1,2+[0,3,6]) = table_dat(1,2+[1,5,9]); %USD in US
table_data(1,3+[0,3,6]) = table_dat(1,3+[1,5,9]); %CNY in US

load saved_results/steady_symbaseline.mat table_dat
table_data(2,1+[0 3 6]) = table_dat(2,  [1,5,9]); %Priv
table_data(2,2+[0,3,6]) = table_dat(1,2+[1,5,9]); %USD in US
table_data(2,3+[0,3,6]) = table_dat(1,3+[1,5,9]); %CNY in US

load saved_results/steady_unilateral40.mat
table_data(3,1+[0 3 6]) = table_dat(2,  [1,5,9]); %Priv
table_data(3,2+[0,3,6]) = table_dat(1,2+[1,5,9]);  %USD in US
table_data(3,3+[0,3,6]) = table_dat(1,3+[1,5,9]);  %CNY in US

load saved_results/steady_hands40.mat
table_data(4,1+[0 3 6]) = table_dat(2,  [1,5,9]); %Priv
table_data(4,2+[0,3,6]) = table_dat(1,2+[1,5,9]);  %USD in US
table_data(4,3+[0,3,6]) = table_dat(1,3+[1,5,9]);  %CNY in US

load saved_results/steady_coordinated40.mat
table_data(5,1+[0 3 6]) = table_dat(2,  [1,5,9]); %Priv
table_data(5,2+[0,3,6]) = table_dat(1,2+[1,5,9]);  %USD in US
table_data(5,3+[0,3,6]) = table_dat(1,3+[1,5,9]);  %CNY in US

load saved_results/steady_titfortat40.mat
table_data(6,1+[0 3 6]) = table_dat(2,  [1,5,9]); %Priv
table_data(6,2+[0,3,6]) = table_dat(1,2+[1,5,9]);  %USD in US
table_data(6,3+[0,3,6]) = table_dat(1,3+[1,5,9]);  %CNY in US

load saved_results/steady_aabbchytau.mat
table_data(7,1+[0 3 6]) = table_dat(2,  [1,5,9]); %Priv
table_data(7,2+[0,3,6]) = table_dat(1,2+[1,5,9]);  %USD in US
table_data(7,3+[0,3,6]) = table_dat(1,3+[1,5,9]);  %CNY in US

load saved_results/steady_bloc40.mat
table_data(8,1+[3]) = table_dat(2,0+[1]); %Priv
table_data(8,2+[3]) = table_dat(1,2+[1]);  %USD in US
table_data(8,3+[3]) = table_dat(1,3+[1]);  %CNY in US


table_data(table_data==0) = NaN;

sprint_mat('% 1.2f \t',table_data)

table_insert('tofill_files/steady_table_together.text', 'saved_tables/steady_table_together.tex', table_data, {'%0.2f','%0.2f','%0.2f','%0.2f','%0.2f','%0.2f','%0.2f','%0.2f','%0.2f','%0.2f'});


%% Table 5: Welfare under tariff scenarios
disp(' ');
disp('*******************************************************************')
disp('Table 5:');
disp('*******************************************************************')


%Transition from middle to dollar
load saved_results/steady_symbaseline cons_steady
cons0 = cons_steady(:,1);

load saved_results/dollar_to_unilateral40_transition cons_equiv
cons1 = 100*log(cons_equiv./cons0);

load saved_results/dollar_to_hands40_transition cons_equiv
cons2 = 100*log(cons_equiv./cons0);

load saved_results/dollar_to_coordinated40_transition cons_equiv
cons3 = 100*log(cons_equiv./cons0);

load saved_results/dollar_to_titfortat40_transition cons_equiv
cons4 = 100*log(cons_equiv./cons0);

load saved_results/dollar_to_bloc40_transition cons_equiv
cons5 = 100*log(cons_equiv./cons0);

load saved_results/dollar_to_bloc40fix_transition cons_equiv
cons6 = 100*log(cons_equiv./cons0);



table_dat = [cons1,cons2,cons3,cons4,cons5,cons6]';

sprint_mat('% 1.2f \t',table_dat)

table_insert('tofill_files/welfare_table_Ia.text', 'saved_tables/welfare_table_Ia.tex', table_dat, {'%0.2f','%0.2f','%0.2f','%0.2f','%0.2f','%0.2f','%0.2f','%0.3f','%0.3f','%0.3f'});



%% Table 6: Welfare under financial policy scenarios
disp(' ');
disp('*******************************************************************')
disp('Table 6:')
disp('*******************************************************************')



%Transition from middle to dollar
load saved_results/steady_symbaseline cons_steady
cons0 = cons_steady(:,1);

load saved_results/dollar_to_aabbchytau_transition cons_equiv
cons1 = 100*log(cons_equiv./cons0);

load saved_results/xtaxand_transition_to_usd Cequiv
cons2 = 100*log(Cequiv(:,6)./cons0);  %6 = five years

load saved_results/sanctionand_transition_to_usd Cequiv
cons3 = 100*log(Cequiv(:,6)./cons0); %6 = five years

load saved_results/xtaxand_transition_to_chy Cequiv
cons4 = 100*log(Cequiv(:,11)./cons0);  %11 = ten years

load saved_results/sanctionand_transition_to_chy Cequiv
cons5 = 100*log(Cequiv(:,21)./cons0); %21 = 20 years


table_dat = [cons1,cons2,cons3,cons4,cons5]';

sprint_mat('% 1.2f \t',table_dat)

table_insert('tofill_files/welfare_table_IIa.text', 'saved_tables/welfare_table_IIa.tex', table_dat, {'%0.2f','%0.2f','%0.2f','%0.2f','%0.2f','%0.2f','%0.2f','%0.3f','%0.3f','%0.3f'});


%% Table 7: Welfare cost of sanctions
disp(' ');
disp('*******************************************************************')
disp('Table 7: Russia Sanctions Welfare Losses')
disp('*******************************************************************')



%Transition from middle to dollar
load saved_results/steady_russia_xsmall.mat  cons_steady
cons0 = cons_steady(:,1);

load saved_results/sanction_transition_to_usd.mat Cequiv
cons1 = 100*log(Cequiv(:,6)./cons0);

load saved_results/tariffs_transition_to_usd.mat  Cequiv
cons2 = 100*log(Cequiv(:,6)./cons0);

load saved_results/combo_transition_to_usd.mat  Cequiv
cons3 = 100*log(Cequiv(:,6)./cons0);  

table_dat = [cons1,cons2,cons3]';

sprint_mat('% 1.2f \t',table_dat)


table_insert('tofill_files/welfare_table_III.text', 'saved_tables/welfare_table_III.tex', table_dat, {'%0.2f','%0.2f','%0.2f','%0.2f','%0.2f','%0.2f','%0.2f','%0.3f','%0.3f','%0.3f'});


%% Trade share numbers for the text
load saved_results/steady_symbaseline  WIMPs WEXPs GDPs

t_shr = (sum(WIMPs(:)) + sum(WEXPs(:)))/sum(mu_us*GDPs(1) + mu_ch*GDPs(2) + mu_aa*GDPs(3) + mu_bb*(GDPs(4)));
west_east_imps = sum(sum(WIMPs([1,3],[2,4])));
west_east_exps = sum(sum(WEXPs([1,3],[2,4])));

load saved_results/steady_bloc40.mat  WIMPs WEXPs GDPs
west_east_imps_bloc40 = sum(sum(WIMPs([1,3],[2,4])));
west_east_exps_bloc40 = sum(sum(WEXPs([1,3],[2,4])));
t_shr_bloc40 = (sum(WIMPs(:)) + sum(WEXPs(:)))/sum(mu_us*GDPs(1) + mu_ch*GDPs(2) + mu_aa*GDPs(3) + mu_bb*(GDPs(4)));

disp(['Cross-bloc trade fall in bloc fragmentation scenario (%):' ...
    num2str(100*(1-(west_east_imps_bloc40+west_east_imps_bloc40)/(west_east_imps+west_east_imps)))]);

disp(['Trade shares before and after bloc scenario (%):' ...
    num2str(100*[t_shr,t_shr_bloc40])]);


%% China-US interest rate differential
compute_interest_rates
