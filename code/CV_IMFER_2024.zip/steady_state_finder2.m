%Finds steady states, but doesn't search as hard as steady-solve. Use only
%for cases that steady-unfriendly.
% load saved_results/steady_symbaseline.mat  pol_mat
% 

assemble_params
obj_test = @(x)steady_residual2(x,log_idx,ny,dynargs{:});

options.DerivativeCheck = 'off';
options.Jacobian = 'on';


disp('Here are the steady states I found!')


%% Find the SS's
xspecial1 = zeros(ny+nx,size(xspecial,2));
fout2     = zeros(ny+nx,size(pol_mat,2));
for jj = 1:size(pol_mat,2)
    [xout,fout2(:,jj)] = fsolve(obj_test,pol_mat(:,jj),options);
    xspecial1(:,jj) = xout(:);
end


%% Keep only unique steady-states
xspecial  = xspecial1(:,sum(abs(fout2))<1e-8);
[~,idx]   = sort(xspecial(ny,:),'ascend');
xspecial  = xspecial(:,idx);
idx_kp    = unique_ss(xspecial(ny-1:ny,:));
xspecial  = xspecial(:,idx_kp);
xspecial(log_idx,:) = exp(xspecial(log_idx,:));



%% DISPALAY INFO ON STEADY-STATES
table_dat = zeros(7,12);
xspecial_long = zeros(ny+nx,size(xspecial,2));
frac_ss = zeros(nx,size(xspecial,2));
tmp = zeros(1,size(xspecial,2));
cons_steady = zeros(4,size(xspecial,2));
Xrw_all = zeros(2,size(xspecial,2));
CCs = cell(3,size(xspecial,2));
for jj = size(xspecial,2):-1:1
    xout = xspecial(:,jj);
    expand_steady2
    
    disp_steady
    
    xspecial_long(:,jj)   = xout;
%     BBX = [mu_aa*Baa_usd,mu_bb*Bbb_usd,...
%            mu_aa*Baa_chy,mu_bb*Bbb_chy, ...
%            mu_us*Bus_usd, ...
%            mu_ch*Bch_chy,...
%            mu_us*Bus_row,mu_ch*Bch_row,mu_aa*Baa_row...
%          ]';
    steady_stats;  %Store table info for steady-state

end


%%
%**************************************************************************
% Compute linear policies
%**************************************************************************
%Initial linear policies
pol_mat = xspecial;
nss     = size(pol_mat,2);
hx_cell = cell(1,nss);
gx_cell = cell(1,nss);
ss_use  = false(1,nss);
for jj = 1:nss
    
    pol_mat(log_idx,jj) = log(pol_mat(log_idx,jj));
    
    [a,d_f,d_futr,dfrac_waste,d_past] = dynamic_residual(pol_mat(:,jj),pol_mat(:,jj),pol_mat(ny+(1:nx),jj),log_idx,ny,dynargs{:});
    if sum(abs(a))>1e-8
        disp('Uhoh')
        pause
    end
    
    %To accomodate t+1 states, phew!
    fx = [d_past;zeros(nx,nx)];
    fy = [d_f(:,1:ny),zeros(ny+nx,nx);zeros(nx,ny),-eye(nx)];
    fxp =[d_f(:,ny+(1:nx));eye(nx)];
    fyp =[d_futr;zeros(nx,ny+nx)];
    
    
    [gx,hx,flag] = gx_hx_alt(fy,fx,fyp,fxp,1.00000000);
    eigg = nan;
    if ~isempty(hx) && ~isnan(hx(1))
        eigg = sort(abs(eig(hx)));
    end
    
    if flag == 1 && max(max(abs(hx)))<1e8
        %Only use the locally determinant SS
        ss_use(jj) = true;
    end
    
    disp(['Steady-state ' num2str(jj) '|resid: ' num2str2(sum(abs(a))) '|flag: ' num2str(flag), '|eig: ' num2str(eigg(end),'%1.6f') '|usd use:' num2str(Xrw_all(:,jj)','%1.2f ')])
    
    hx_cell{jj} = hx;
    gx_cell{jj} = gx;
end