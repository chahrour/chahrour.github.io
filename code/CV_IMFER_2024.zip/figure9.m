%% FIGURE 6: US-ROW TRADE WAR AS FCN OF TIME
load saved_results/steady_symbaseline cons_steady
load saved_results/sanctionand_transition_to_chy.mat Cequiv; Cequiv_chy = Cequiv;
load saved_results/sanctionand_transition_to_usd.mat Cequiv; Cequiv_usd = Cequiv;
Tmax = length(Cequiv_usd)-1;
ceq_stay = 100*(Cequiv_usd./cons_steady(:,1)-1);
ceq_go   = 100*(Cequiv_chy./cons_steady(:,1)-1);

f1 = figure;
f1.PaperPosition = [.25, .25, dim_sqr];
%f1.PaperSize     = [4,10];

s = subplot(2,2,1);
plot(0:Tmax,ceq_stay(1,:), 'linewidth', 2.5); hold on
plot(0:Tmax,ceq_go(1,1:Tmax+1), 'linewidth',2.5, 'LineStyle', ls_ch);
s.YLim = [-.75,0.75];
%s.YTick = [-1,-.5,0,0.5,1];
s.XLim = [1,30];
s.XTick = [1, 10, 20, 30]; 

s.FontSize = 12; 
title('US');

legend('USD in long run', 'CNY in long run');
xlabel('years');
ylabel('cons. equivalent');

s = subplot(2,2,2);
plot(0:Tmax,ceq_stay(2,:), 'linewidth', 2.5); hold on
plot(0:Tmax,ceq_go(2,1:Tmax+1), 'linewidth',2.5, 'LineStyle', ls_ch);
s.YLim = [-.75,0.75];
%s.YTick = [-1,-.5,0,0.5,1];
s.XLim = [1,30];
s.XTick = [1, 10, 20, 30]; 
s.FontSize = 12; 
xlabel('years');
%ylabel('cons. equivalent');
title('CN');

s = subplot(2,2,3);
plot(0:Tmax,ceq_stay(3,:), 'linewidth', 2.5); hold on
plot(0:Tmax,ceq_go(3,1:Tmax+1), 'linewidth',2.5, 'LineStyle', ls_ch);
s.YLim = [-.075,0.075];
%s.YTick = [-1,-.5,0,0.5,1];
s.XLim = [1,30];
s.XTick = [1, 10, 20, 30]; 
s.FontSize = 12; 
xlabel('years');
%ylabel('cons. equivalent');
title('RW A');

s = subplot(2,2,4);
plot(0:Tmax,ceq_stay(4,:), 'linewidth', 2.5); hold on
plot(0:Tmax,ceq_go(4,1:Tmax+1), 'linewidth',2.5, 'LineStyle', ls_ch);
s.YLim = [-.075,0.075];
%s.YTick = [-1,-.5,0,0.5,1];
s.XLim = [1,30];
s.XTick = [1, 10, 20, 30]; 
s.FontSize = 12; 
xlabel('years');
%ylabel('cons. equivalent');
title('RW B');

saveas(f1, 'saved_figures/figure9.eps', 'epsc');

