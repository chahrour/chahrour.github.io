
%Transition from asymmetric baseline to symmetric baseline
figure3

%Attraction regions for symmetric baseline
figure4

%Attraction regions for unilateral tariff scenario
figure5

%Attraction regions for tariffs only on Region B scenario
figure6

%Temporary subsidy for using CHY trade finance (under symmeteric baseline)
figure7

%Sanctions only on Region B (under symmetric baseline)
figure8
figure9

%Flight paths for the permanent bloc scenario (starting from asymmetric baseline)
figure10

%Sanctions and tariffs on a small Russia (under asymmetric baseline)
figure11

