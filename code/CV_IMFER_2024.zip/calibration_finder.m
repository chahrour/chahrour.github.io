%Find a calibration that best matches some moments in steady-state
log_idx = [];
save_me = true;

%% the symmetric baseline but tax CH bond returns ... requires special steady-state procedure (need to check walras for this case, and to add sanction on bb)
load saved_results/steady_symbaseline
load calib_params

%Make past and future values equal
prime_up;


save_str = 'baseline';


btau_us_chy = 1*.0075;
btau_bb_chy = 1*.0075;
btau_aa_chy = 1*.0075;  %100 basis points

prime_up

assemble_params
[aa,bb] = steady_residual2(pol_mat(:,end),log_idx,ny,dynargs{:});

obj_test = @(x)steady_residual2(x,log_idx,ny,dynargs{:});

options = optimoptions('fsolve');
options.DerivativeCheck = 'off';
options.Jacobian = 'on';

xout = fsolve(obj_test,pol_mat(:,1),options);

expand_steady2
disp_steady



%% Now use the ss solution above to find an assymertric calibration


%Starting point
if exist('xcalib', 'var') 
    x0 = xcalib(:);
else
    x0 = [xout(:)',Busd,vepsf,phi,r,sige,kap,a_us,a_aa,eta Baa zrow]';
end

%Log things
x0(log_idx) = log(x0(log_idx));


%Optimizer options
ss_opt = optimoptions('lsqnonlin');
ss_opt.CheckGradients = false;
ss_opt.SpecifyObjectiveGradient = false;
ss_opt.MaxFunctionEvaluations = 30000;
ss_opt.MaxIterations = 200;
ss_opt.FiniteDifferenceType = 'central';
ss_opt.FunctionTolerance = 1e-11;
ss_opt.StepTolerance = 1e-9;
ss_opt.Display = 'iter';

%TAREGT PARAMS: %B,vepsf,phi,r,sige,kap,ah
%neq = 29;
lbnd = [-inf*ones(1,ny+nx),0.5, .01 , .01, 0.0001, 1.0e-9, .001, .2,.2, 0.9999 .1  0.001]; 
ubnd = [+inf*ones(1,ny+nx),25, 1.2,  .2, 0.020, 0.01,     .1  ,.9, .9  10  4       2];

%Target objective (inputs copied from dynamic residual)
obj_tmp = @(x)obj_calib(x,log_idx,nx,ny,dynargs{:})

fout0 = obj_tmp(x0);


%Solve for calibration/SS at once
[xcalib,fout,fout2] = lsqnonlin(obj_tmp,x0,lbnd,ubnd,ss_opt);

xcalib(log_idx) = exp(xcalib(log_idx));

if fout < 1e-10
    disp('Success, Continue...')
    
    %assign param values
    Busd   = xcalib(nx+ny+1);
    Bchy   = xcalib(nx+ny+1);
    vepsf  = xcalib(nx+ny+2);
    phi    = xcalib(nx+ny+3);
    r      = xcalib(nx+ny+4);
    sige   = xcalib(nx+ny+5);
    kap    = xcalib(nx+ny+6);
    a_us  = xcalib(nx+ny+7);
    a_ch  = xcalib(nx+ny+7);
    a_aa  = xcalib(nx+ny+8);
    a_bb  = xcalib(nx+ny+8);
    eta   = xcalib(nx+ny+9);
    Baa   = xcalib(nx+ny+10);
    Bbb   = xcalib(nx+ny+10);
    zrow  = xcalib(nx+ny+11);
    
    %Make past and future values equal
    prime_up;
    
    %save param values
    save calib_params Busd Bchy vepsf phi r sige kap a_us a_ch a_aa a_bb eta Baa Bbb zrow
    xout = xcalib(1:end-10);
    save xout_tmp xout

    assemble_params;
    obj_test = @(x)steady_residual2(x,log_idx,ny,dynargs{:});
    
    options.DerivativeCheck = 'off';
    options.Jacobian = 'on';
    
    steady_state_finder2
    
    if save_me
    disp(' ');
    disp(['Saving as saved_results/steady_' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end
    
else
    disp('Incomplete, Stop.')
    return
end


%% OBJECTIVE FUNCTION
function out = obj_calib(x,log_idx,nx,ny,...%Copy args below from assemble_params
   Busd,Bchy,Yus,Ych,Yaa,Ybb,mu_us,mu_ch,mu_aa,mu_bb,a_us,a_ch,a_aa,a_bb,BBbb_usd,zusd_aa,zusd_bb,zchy_aa,zchy_bb,tax_us_ch,tax_us_aa,tax_us_bb,tax_ch_us,tax_ch_aa,tax_ch_bb,tax_aa_us,tax_aa_ch,tax_aa_rowa,tax_aa_rowb,tax_bb_us,tax_bb_ch,tax_bb_rowa,tax_bb_rowb,etax_ch_us,etax_aa_us,etax_bb_us,etax_us_ch,etax_aa_ch,etax_bb_ch,etax_us_aa,etax_ch_aa,etax_bb_aa,etax_us_bb,etax_ch_bb,etax_aa_bb,xtax_ch_usd,xtax_aa_usd,xtax_bb_usd,xtax_us_chy,xtax_aa_chy,xtax_bb_chy,Busd_l,Bchy_l,Yus_l,Ych_l,Yaa_l,Ybb_l,mu_us_l,mu_ch_l,mu_aa_l,mu_bb_l,a_us_l,a_ch_l,a_aa_l,a_bb_l,BBbb_usd_l,zusd_aa_l,zusd_bb_l,zchy_aa_l,zchy_bb_l,tax_us_ch_l,tax_us_aa_l,tax_us_bb_l,tax_ch_us_l,tax_ch_aa_l,tax_ch_bb_l,tax_aa_us_l,tax_aa_ch_l,tax_aa_rowa_l,tax_aa_rowb_l,tax_bb_us_l,tax_bb_ch_l,tax_bb_rowa_l,tax_bb_rowb_l,etax_ch_us_l,etax_aa_us_l,etax_bb_us_l,etax_us_ch_l,etax_aa_ch_l,etax_bb_ch_l,etax_us_aa_l,etax_ch_aa_l,etax_bb_aa_l,etax_us_bb_l,etax_ch_bb_l,etax_aa_bb_l,xtax_ch_usd_l,xtax_aa_usd_l,xtax_bb_usd_l,xtax_us_chy_l,xtax_aa_chy_l,xtax_bb_chy_l,Busd_p,Bchy_p,Yus_p,Ych_p,Yaa_p,Ybb_p,mu_us_p,mu_ch_p,mu_aa_p,mu_bb_p,a_us_p,a_ch_p,a_aa_p,a_bb_p,BBbb_usd_p,zusd_aa_p,zusd_bb_p,zchy_aa_p,zchy_bb_p,tax_us_ch_p,tax_us_aa_p,tax_us_bb_p,tax_ch_us_p,tax_ch_aa_p,tax_ch_bb_p,tax_aa_us_p,tax_aa_ch_p,tax_aa_rowa_p,tax_aa_rowb_p,tax_bb_us_p,tax_bb_ch_p,tax_bb_rowa_p,tax_bb_rowb_p,etax_ch_us_p,etax_aa_us_p,etax_bb_us_p,etax_us_ch_p,etax_aa_ch_p,etax_bb_ch_p,etax_us_aa_p,etax_ch_aa_p,etax_bb_aa_p,etax_us_bb_p,etax_ch_bb_p,etax_aa_bb_p,xtax_ch_usd_p,xtax_aa_usd_p,xtax_bb_usd_p,xtax_us_chy_p,xtax_aa_chy_p,xtax_bb_chy_p,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_chg,phi_aag,phi_bbg,bet,sig,eta,Pnumer,Xus,Xch,zrow,upp_usd,upp_chy,sanc_usd_bb,sanc_usd_ch,chi,btau_ch_usd,btau_aa_usd,btau_bb_usd,btau_us_chy,btau_aa_chy,btau_bb_chy,per_p_year,fXaa,fXbb,fixx,Baa,Bbb);
%assign param values we want to estimate
    Busd   = x(nx+ny+1);
    Bchy   = x(nx+ny+1);
    vepsf  = x(nx+ny+2);
    phi    = x(nx+ny+3);
    r      = x(nx+ny+4);
    sige   = x(nx+ny+5);
    kap    = x(nx+ny+6);
    a_us  = x(nx+ny+7);
    a_ch  = x(nx+ny+7);
    a_aa  = x(nx+ny+8);
    a_bb  = x(nx+ny+8);
    eta   = x(nx+ny+9);
    Baa   = x(nx+ny+10);
    Bbb   = x(nx+ny+10);
    zrow  = x(nx+ny+11);
    
    %Make past and future values equal
    prime_up;
    
    out1 = steady_residual2(x,log_idx,ny,...%Copy args below from assemble_params
        Busd,Bchy,Yus,Ych,Yaa,Ybb,mu_us,mu_ch,mu_aa,mu_bb,a_us,a_ch,a_aa,a_bb,BBbb_usd,zusd_aa,zusd_bb,zchy_aa,zchy_bb,tax_us_ch,tax_us_aa,tax_us_bb,tax_ch_us,tax_ch_aa,tax_ch_bb,tax_aa_us,tax_aa_ch,tax_aa_rowa,tax_aa_rowb,tax_bb_us,tax_bb_ch,tax_bb_rowa,tax_bb_rowb,etax_ch_us,etax_aa_us,etax_bb_us,etax_us_ch,etax_aa_ch,etax_bb_ch,etax_us_aa,etax_ch_aa,etax_bb_aa,etax_us_bb,etax_ch_bb,etax_aa_bb,xtax_ch_usd,xtax_aa_usd,xtax_bb_usd,xtax_us_chy,xtax_aa_chy,xtax_bb_chy,Busd_l,Bchy_l,Yus_l,Ych_l,Yaa_l,Ybb_l,mu_us_l,mu_ch_l,mu_aa_l,mu_bb_l,a_us_l,a_ch_l,a_aa_l,a_bb_l,BBbb_usd_l,zusd_aa_l,zusd_bb_l,zchy_aa_l,zchy_bb_l,tax_us_ch_l,tax_us_aa_l,tax_us_bb_l,tax_ch_us_l,tax_ch_aa_l,tax_ch_bb_l,tax_aa_us_l,tax_aa_ch_l,tax_aa_rowa_l,tax_aa_rowb_l,tax_bb_us_l,tax_bb_ch_l,tax_bb_rowa_l,tax_bb_rowb_l,etax_ch_us_l,etax_aa_us_l,etax_bb_us_l,etax_us_ch_l,etax_aa_ch_l,etax_bb_ch_l,etax_us_aa_l,etax_ch_aa_l,etax_bb_aa_l,etax_us_bb_l,etax_ch_bb_l,etax_aa_bb_l,xtax_ch_usd_l,xtax_aa_usd_l,xtax_bb_usd_l,xtax_us_chy_l,xtax_aa_chy_l,xtax_bb_chy_l,Busd_p,Bchy_p,Yus_p,Ych_p,Yaa_p,Ybb_p,mu_us_p,mu_ch_p,mu_aa_p,mu_bb_p,a_us_p,a_ch_p,a_aa_p,a_bb_p,BBbb_usd_p,zusd_aa_p,zusd_bb_p,zchy_aa_p,zchy_bb_p,tax_us_ch_p,tax_us_aa_p,tax_us_bb_p,tax_ch_us_p,tax_ch_aa_p,tax_ch_bb_p,tax_aa_us_p,tax_aa_ch_p,tax_aa_rowa_p,tax_aa_rowb_p,tax_bb_us_p,tax_bb_ch_p,tax_bb_rowa_p,tax_bb_rowb_p,etax_ch_us_p,etax_aa_us_p,etax_bb_us_p,etax_us_ch_p,etax_aa_ch_p,etax_bb_ch_p,etax_us_aa_p,etax_ch_aa_p,etax_bb_aa_p,etax_us_bb_p,etax_ch_bb_p,etax_aa_bb_p,xtax_ch_usd_p,xtax_aa_usd_p,xtax_bb_usd_p,xtax_us_chy_p,xtax_aa_chy_p,xtax_bb_chy_p,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_chg,phi_aag,phi_bbg,bet,sig,eta,Pnumer,Xus,Xch,zrow,upp_usd,upp_chy,sanc_usd_bb,sanc_usd_ch,chi,btau_ch_usd,btau_aa_usd,btau_bb_usd,btau_us_chy,btau_aa_chy,btau_bb_chy,per_p_year,fXaa,fXbb,fixx,Baa,Bbb);

    
    xout = x;
    xout(log_idx) = exp(x(log_idx));
    expand_steady2
    
    
    %BASELINE TARGETS
    targ_val = [0.001, 0.010, 0.005, 0.95  , 0.60  , 0.35    ,0.65    , 1.20           , 4.00, 0.45   ,     delta_bonds(2,2)]';
    targ_qs  = [sige , kap  , r    , Xrw(1), GDs(1), TSHRs(2),TSHRs(3), Paa_rowb/Pbb_bb, eta , GDs(3),      delta_bonds(3,1)]';
    
    
    
    out2 = (targ_qs-targ_val)./targ_val;
    
    out = 100*[1*out1; 100*out2];


end