% Attraction_regions - compute attraction regions by trying to shoot
% steady-state from many different starting points.
%
% This versions makes use of the symmetry of the economy.  
%
% Step 1: we crawl the diagonal, and confirm that we can always converge to
% the CHY steady-state. From this, we know anywhere above the diagonal can 
% arrive at the steady state.
% 
% Step 2: starting from each diagonal point, we try to crawl further right
% (away from the Euro steady-state) until the solver can no longer find a
% solution that converges to Euro. This determines the right boundry of the
% the indterminancy zones. (Beyond this point, everything can only converge
% to the dollar dominant equilbrium.)


%% make initial grid
np = 131;
%np = 39;
frac_rw_usd_dense = .5*linspace(.2,.85,np);
frac_rw_chy_dense = .5*linspace(.2,.85,np);

frac_rw_usd_dense = linspace(.15,.45,np);
frac_rw_chy_dense = linspace(.15,.45,np);

[grid_rw_usd_dense,grid_rw_chy_dense] = ndgrid(frac_rw_usd_dense,frac_rw_chy_dense);

assemble_params;
%% shooting solver settings
T = 275*per_p_year;

options = optimoptions('fsolve');   
options.Display = 'iter';
options.MaxIterations = 800;
options.FiniteDifferenceType = 'central';
options.SpecifyObjectiveGradient = true;
options.CheckGradients = false;

solve_indic = cell(length(frac_rw_usd_dense),1);
bond_path   = cell(length(frac_rw_usd_dense),1);
polc_path   = cell(length(frac_rw_usd_dense),1);

for jj = 1:length(bond_path(:))
    bond_path{jj} = nan(6,10);
end

%ALWAYS LANDING AT
eq_idx = 3;%Euro steady
targ_ss = xspecial_long(:,eq_idx);  
    
 
%% PART 1: crawl the diagonal of the grid linearly, shooting for Euro steady-state
for ii = 1:length(frac_rw_chy_dense)
    disp(num2str(ii));
    
    solve_indic{ii} = NaN(1,length(frac_rw_usd_dense));
    bond_path{ii} = cell(1,length(frac_rw_usd_dense));
    polc_path{ii} = cell(1,length(frac_rw_usd_dense));
    
    %initial starting point
    if ii == 1
        xshoot_final = repmat(targ_ss,[1,T]);
    end
    
    %FLYING FROM:
    frac_shoot = [frac_rw_usd_dense(ii),frac_rw_usd_dense(ii),frac_rw_chy_dense(ii),frac_rw_chy_dense(ii),0.90,0.90,.1262,.1262,.5];
    X0 = frac2B(frac_shoot(:),Busd,Bchy,Baa,Bbb,mu_us,mu_ch,mu_aa,mu_bb,BBbb_usd);

    %SHOOT
    shoot_ = @(x) shooting(x,X0,targ_ss,T,log_idx,nx,ny,[],dynargs{:});
    % Solve the shoot
    [xshoot_final,fval] = fsolve(shoot_,xshoot_final(:),options);
    [~,~,~,dfinal]      = shoot_(xshoot_final);
    xshoot_final        = reshape(xshoot_final,[ny+nx,T]);
    
    % Store results
    xshoot_final(log_idx,:)     = exp(xshoot_final(log_idx,:));
    polc_path{ii}{ii} = xshoot_final ;
    
    if (sum(fval.^2) + sum(dfinal.^2))>1e-4
        error('missed on diagonal, try again');
    end
    
end


%% PART 2: Now try to creep to the right, shooting for CHY
options.MaxIterations = 30;
options.Display = 'off';
solve_indic = inf(np,np);

parfor jj = 1:np %For each level of chy
    xshoot_final = [];
    
    for ii = 1:np
        if ii < jj
            %Assume we've succeeded
            solve_indic(jj,ii) = 1e-10;
        else
            if ii == jj
                %initial starting point
                xshoot_final = polc_path{jj}{jj};
            end
            
            %FLYING FROM:
            frac_shoot = [frac_rw_usd_dense(ii),frac_rw_usd_dense(ii),frac_rw_chy_dense(jj),frac_rw_chy_dense(jj),0.90,0.90,.1262,.1262,.5];
            
            
            X0 = frac2B(frac_shoot(:),Busd,Bchy,Baa,Bbb,mu_us,mu_ch,mu_aa,mu_bb,BBbb_usd);
            
            %SHOOT
            shoot_ = @(x) shooting(x,X0,targ_ss,T,log_idx,nx,ny,[],dynargs{:});

            r0 = shoot_(xshoot_final(:));
            
            disp([num2str(jj) ':' num2str(ii) '-> r0 = ' num2str(sum(r0.^2),'%1.2s')]);
            % Solve the shoot
            [xshoot_final,fval] = fsolve(shoot_,xshoot_final(:),options);
            [~,~,~,dfinal]      = shoot_(xshoot_final);
            xshoot_final        =reshape(xshoot_final,[ny+nx,T]);
            
            %Store results
            xshoot_final(log_idx,:) = exp(xshoot_final(log_idx,:));
            polc_path{jj}{ii}       = xshoot_final ;
            solve_indic(jj,ii)      = sum(fval.^2) + sum(dfinal.^2);
            
            if (sum(fval.^2) + sum(dfinal.^2))>1e-4
                disp('no solution, exiting subloop');
                break;
            end
        end
    end
end


