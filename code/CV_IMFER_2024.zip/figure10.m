%% FIGURE 10: BASELINE - FLIGHT PATH FROM MIDDLE TO DOLLAR SS
load saved_results/steady_baseline cons_steady per_p_year 
load saved_results/dollar_to_bloc40fix_longtransition  *out *use *shrs frac_path cons_equiv
con_fix =con_out;
load saved_results/dollar_to_bloc40_longtransition  *out *use *shrs frac_path cons_equiv

con_out = con_out./con_fix;
yrs= 50;
max_year = 40;
f2 = figure;
f2.PaperPosition = [.25, .25, dim_sqr];

xgrid = (0:per_p_year:per_p_year*(yrs-1))/per_p_year;
yidx  = 1:per_p_year:per_p_year*yrs;

s=subplot(3,2,1);

plot(xgrid,100*log(con_out(1,yidx)).','linewidth' ,2.5,'Color',color_us); hold on;
plot(xgrid,100*log(con_out(2,yidx)).','linewidth' ,2.5, 'Color', color_ch, 'LineStyle',ls_ch); hold on;
plot(xgrid,0*xgrid, ':k');
title('Cons. relative to counterfactual (%)')
xlabel('years')
s.XLim = [0,max_year];
%s.YLim = [-3.5,.75];
s.FontSize = 12;

s= subplot(3,2,2);
p1 = plot([-1 -2],[-1,-2],'linewidth' ,2.5,'Color',color_us); hold on;
p2 = plot([-1 -2],[-1,-2],'linewidth' ,2.5,'Color',color_ch,'Linestyle',ls_ch);
p3 = plot(xgrid,usd_use(1,yidx),'linewidth' ,2.5,'Color',color_rw, 'LineStyle', ls_rw);
p4 = plot(xgrid,usd_use(2,yidx),'linewidth' ,2.5,'Color',color_rw2, 'LineStyle', ls_rw2);
title('USD use by RW firms')
s.YLim = [-0.05, 1.1];
s.XLim = [0,max_year];
s.FontSize = 12;
legend('US', 'CN', 'RW A', 'RW B','Location', 'southeast')


s= subplot(3,2,3);
plot(xgrid,ep_out(1,yidx)','linewidth' ,2.5)
title(['r^' char(165) ' - r^$ (%)'])
s.YLim = [0,1.6];
s.XLim = [0,max_year];
s.FontSize = 12;

s=subplot(3,2,4);
plot(xgrid,usd_shrs(1,yidx)','linewidth' ,2.5,'Color',color_us); hold on;
plot(xgrid,usd_shrs(2,yidx)','linewidth' ,2.5,'Color',color_ch,'Linestyle',ls_ch);
plot(xgrid,usd_shrs(3,yidx)','linewidth' ,2.5,'Color',color_rw,'Linestyle',ls_rw);
plot(xgrid,usd_shrs(4,yidx)','linewidth' ,2.5,'Color',color_rw2,'Linestyle',ls_rw2);

title('USD bond portfolio share')
s.XLim = [0,max_year];
s.FontSize = 12;

s=subplot(3,2,5);
plot(xgrid,nfa_out(1,yidx)','linewidth' ,2.5, 'Color', color_us)
title('US net foreign assets/GDP')
s.XLim = [0,max_year];
s.FontSize = 12;

s=subplot(3,2,6);
plot(xgrid,nfa_out(2,yidx),'linewidth' ,2.5, 'Color',color_ch,'LineStyle',ls_ch);
title('CN net foreign assets/GDP')
s.XLim = [0,max_year];
s.FontSize = 12;

saveas(f2, 'saved_figures/figure10.eps', 'epsc')