%% FIGURE 11: Sanctions
load saved_results/steady_baseline cons_steady per_p_year 

load saved_results/sanction_transition_to_usd.mat  *out *use *shrs frac_path cons_equiv usdv wimpv wexpv shrsv
usdv_sanc = usdv;
wimpv_sanc = wimpv;
wexpv_sanc = wexpv;
shrsv_sanc = shrsv;

load saved_results/tariffs_transition_to_usd.mat  *out *use *shrs frac_path cons_equiv usdv wimpv wexpv shrsv
usdv_tar = usdv;
wimpv_tar = wimpv;
wexpv_tar = wexpv;
shrsv_tar = shrsv;
 
load saved_results/combo_transition_to_usd.mat  *out *use *shrs frac_path cons_equiv usdv wimpv wexpv shrsv

yrs= 25;
max_year = 25;
f9 = figure;
f9.PaperPosition = [.25, .25, dim_sqr];

xgrid = (1:per_p_year:per_p_year*(yrs))/per_p_year;
yidx  = 1:per_p_year:per_p_year*yrs;

s=subplot(2,2,1);

for ii = 6
    plot(xgrid,usdv_tar{ii}(1,yidx),'linewidth' ,2.5,'Color',color_us,'linestyle', ':'); hold on;
    plot(xgrid,usdv_sanc{ii}(1,yidx),'linewidth' ,2.5,'Color',color_us*2/3, 'linestyle','--'); hold on;
    plot(xgrid,usdv{ii}(1,yidx),'linewidth' ,2.5,'Color',color_us*1/3); hold on;
end

s.YLim = [.8,1];
s.XLim = [1,max_year];
s.FontSize = 12;
title('USD use: Rest-of-world')
xlabel('years')
legend('Tariffs only','Sanctions only', 'Tariffs & Sanctions', 'location', 'southeast')

%USD use: Russia
s=subplot(2,2,2);
for ii = 6
    plot(xgrid,usdv_tar{ii}(2,yidx),'linewidth' ,2.5,'Color',color_chy,'linestyle', ':'); hold on;
    plot(xgrid,usdv_sanc{ii}(2,yidx),'linewidth' ,2.5,'Color',color_chy*2/3, 'linestyle','--'); hold on;
plot(xgrid,usdv{ii}(2,yidx),'linewidth' ,2.5,'Color',color_chy*1/3); hold on;
end

s.YLim = [.8,1];
s.XLim = [1,max_year];
s.FontSize = 12;
title('USD use: Russia')



%Bond holding
s=subplot(2,2,3);
for ii = 6
    
     %Trade just with China Divided by total trade
    trade_tar = (wimpv_tar{ii}(end-2,:) + wexpv_tar{ii}(end-2,:))./sum(wimpv_tar{ii}(end-3:end,:) + wexpv_tar{ii}(end-3:end,:));  
    trade_sanc = (wimpv_tar{ii}(end-2,:) + wexpv_sanc{ii}(end-2,:))./sum(wimpv_sanc{ii}(end-3:end,:) + wexpv_sanc{ii}(end-3:end,:));  
    trade = (wimpv{ii}(end-2,:) + wexpv{ii}(end-2,:))./sum(wimpv{ii}(end-3:end,:) + wexpv{ii}(end-3:end,:));  
    
    
    
    plot(xgrid,trade_tar(yidx),'linewidth' ,2.5,'Color',color_chy,'linestyle', ':'); hold on;
    plot(xgrid,trade_sanc(yidx),'linewidth' ,2.5,'Color',color_chy*2/3, 'linestyle','--'); hold on;
    plot(xgrid,trade(yidx),'linewidth' ,2.5,'Color',color_chy*1/3); hold on;
end
%legend('Tariffs only','Sanction only', 'Tariffs & Sanctions')
s.YLim = [.1,.3];
s.XLim = [1,max_year];
s.FontSize = 12;
title('Share of Russian trade with China')


%Trade with China
s=subplot(2,2,4);
for ii = 6
    plot(xgrid,shrsv_tar{ii}(4,yidx),'linewidth' ,2.5,'Color',color_chy,'linestyle', ':'); hold on;
    plot(xgrid,shrsv_sanc{ii}(4,yidx),'linewidth' ,2.5,'Color',color_chy*2/3, 'linestyle','--'); hold on;
    plot(xgrid,shrsv{ii}(4,yidx),'linewidth' ,2.5,'Color',color_chy*1/3); hold on;
end
%legend('Tariffs only','Sanction only', 'Tariffs & Sanctions')
s.YLim = [.1,.5];
s.XLim = [1,max_year];
s.FontSize = 12;
title('Share of (unsanctioned) USD in Russian portfolio')





saveas(f9, 'saved_figures/figure11.eps', 'epsc')