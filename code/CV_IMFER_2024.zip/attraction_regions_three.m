% Attraction_regions_two - compute attraction regions by trying to shoot
% steady-state from many different starting points. 
%
% This versions DOES NOT make use of symmetry assumption.
%
% Step 0: we confirm that in bottom-right converges to Euro steady-state.
% So best case for USD is region of multiplicity, it can never be unqiue. 
% We thus only need to check when we can reach the US steady-state from
% other points.

% Step 1: we crawl along the right edge of the figure to the US. Success
% tells us the right boundry of the figure is in the indetermancy region.
% 
% Step 2: crawl from right to left. When no solution going to USD can be
% found, we've detected the edge of the multiplicty region.


%% make initial grid

np = 131;
%np = 51;
frac_rw_usd_dense = .5*linspace(.2,.85,np);
frac_rw_chy_dense = .5*linspace(.2,.85,np);


frac_rw_usd_dense = linspace(.15,.45,np);
frac_rw_chy_dense = linspace(.15,.45,np);

[grid_rw_usd_dense,grid_rw_chy_dense] = ndgrid(frac_rw_usd_dense,frac_rw_chy_dense);
assemble_params;

%% shooting solver settings
T = 260*per_p_year;

options = optimoptions('fsolve');   
options.Display = 'off';
options.MaxIterations = 60;
options.MaxFunctionEvaluations = 70;

options.FiniteDifferenceType = 'central';
options.SpecifyObjectiveGradient = true;
options.CheckGradients = false;
%options.Algorithm = 'levenberg-marquardt';

solve_indic = cell(length(frac_rw_usd_dense),1);
bond_path   = cell(length(frac_rw_usd_dense),1);
polc_path   = cell(length(frac_rw_usd_dense),1);

for jj = 1:length(bond_path(:))
    bond_path{jj} = nan(9,10);
end
 

%% STEP1: Crawl from right side shooting for USD
solve_indic_right = inf(np,np);
polc_path_right   = cell(np,1);

%ALWAYS LANDING AT
eq_idx = 1;%USD steady
targ_ss = xspecial_long(:,eq_idx);
for jj = 1:np  %For each level of CHY
    xshoot_final = [];
    for ii = np:-1:1  %Start with high USD and move left
        disp([num2str(jj) ':' num2str(ii)]);
        %initial starting point
        if ii == np
            xshoot_final = repmat(targ_ss,[1,T]);
        end
        
        %FLYING FROM:
        frac_shoot = [frac_rw_usd_dense(ii),frac_rw_usd_dense(ii),frac_rw_chy_dense(jj),frac_rw_chy_dense(jj),0.90,0.90,.1262,.1262,.5]; %leaning dollar
        X0 = frac2B(frac_shoot(:),Busd,Bchy,Baa,Bbb,mu_us,mu_ch,mu_aa,mu_bb,BBbb_usd);
        
        %SHOOT
        shoot_ = @(x) shooting(x,X0,targ_ss,T,log_idx,nx,ny,[],dynargs{:});

        % Solve the shoot
        [xshoot_final,fval] = fsolve(shoot_,xshoot_final(:),options);
        [~,~,~,dfinal] = shoot_(xshoot_final);
        xshoot_final=reshape(xshoot_final,[ny+nx,T]);
        
        % Store results
        xshoot_final(log_idx,:)  = exp(xshoot_final(log_idx,:));
        polc_path_right{jj}{ii}  = xshoot_final ;
        solve_indic_right(jj,ii) = sum(fval.^2) + sum(dfinal.^2);
        
        if (sum(fval.^2) + sum(dfinal.^2))>1e-4
            disp('no solution, exiting subloop');
            break
        end
    end
end

%% STEP2: Crawl from top side shooting for EUR
solve_indic_top = inf(np,np);
polc_path_top   = cell(np,1);

%ALWAYS LANDING AT
eq_idx = 3;%USD steady
targ_ss = xspecial_long(:,eq_idx);
parfor jj = 1:np  %For each level of CHY
    for ii = np:-1:1  %Start with high USD and move left
        disp([num2str(jj) ':' num2str(ii)]);
        %initial starting point
        if ii == np
            xshoot_final = repmat(targ_ss,[1,T]);
        end
        
        %FLYING FROM:
        frac_shoot = [frac_rw_usd_dense(jj),frac_rw_usd_dense(jj),frac_rw_chy_dense(ii),frac_rw_chy_dense(ii),0.90,0.90,.1262,.1262,.5]; %leaning dollar
        X0 = frac2B(frac_shoot(:),Busd,Bchy,Baa,Bbb,mu_us,mu_ch,mu_aa,mu_bb,BBbb_usd);
        
        %SHOOT
        shoot_ = @(x) shooting(x,X0,targ_ss,T,log_idx,nx,ny,[],dynargs{:});
        % Solve the shoot
        [xshoot_final,fval] = fsolve(shoot_,xshoot_final(:),options);
        [~,~,~,dfinal]      = shoot_(xshoot_final);
        xshoot_final        = reshape(xshoot_final,[ny+nx,T]);
        
        % Store results
        xshoot_final(log_idx,:) = exp(xshoot_final(log_idx,:));
        polc_path_top{jj}{ii}   = xshoot_final ;
        
        solve_indic_top(jj,ii)  = sum(fval.^2) + sum(dfinal.^2);
        if sum(fval.^2) + sum(dfinal.^2)>1e-4
            disp('no solution, exiting subloop');
            break
        end
    end
end

%}

%% STEP3a: Crawl down right side shooting for CROSS
solve_indic_cright0 = inf(np,1);
polc_path_cright0    = cell(np,1);

%ALWAYS LANDING AT
eq_idx = 2;%CROSS steady
targ_ss = xspecial_long(:,eq_idx);
for ii = np:-1:1  %For each level of CHY
    disp([num2str(ii)]);
    
    %initial starting point
    xshoot_final = repmat(targ_ss,[1,T]);

    %FLYING FROM:
    frac_shoot = [frac_rw_usd_dense(np),frac_rw_usd_dense(np),frac_rw_chy_dense(ii),frac_rw_chy_dense(ii),0.90,0.90,.1262,.1262,.5]; %leaning dollar
    X0 = frac2B(frac_shoot(:),Busd,Bchy,Baa,Bbb,mu_us,mu_ch,mu_aa,mu_bb,BBbb_usd);
    
    %SHOOT
    shoot_ = @(x) shooting(x,X0,targ_ss,T,log_idx,nx,ny,[],dynargs{:});

    % Solve the shoot
    [xshoot_final,fval] = fsolve(shoot_,xshoot_final(:),options);
    [~,~,~,dfinal] = shoot_(xshoot_final);
    xshoot_final=reshape(xshoot_final,[ny+nx,T]);
    
    % Store results
    xshoot_final(log_idx,:) = exp(xshoot_final(log_idx,:));
    polc_path_cright0{ii}        = xshoot_final ;
    
    solve_indic_cright0(ii) = sum(fval.^2) + sum(dfinal.^2);
    if (sum(fval.^2) + sum(dfinal.^2))>1e-4
        disp('no solution, exiting subloop');
        break
    end
    
end


%% STEP3b: Crawl from right side shooting for CROSS
solve_indic_cright = inf(np,np);
polc_path_cright   = cell(np,1);

%ALWAYS LANDING AT
eq_idx = 2;%CROSS steady
targ_ss = xspecial_long(:,eq_idx);
parfor jj = find(solve_indic_cright0<1e-5)'  %For each level of CHY
    for ii = np:-1:1  %Start with high USD and move left
        disp([num2str(jj) ':' num2str(ii)]);
        
        %initial starting point
        if ii == np
            xshoot_final = polc_path_cright0{jj};
        end
        
        %FLYING FROM:
        frac_shoot = [frac_rw_usd_dense(ii),frac_rw_usd_dense(ii),frac_rw_chy_dense(jj),frac_rw_chy_dense(jj),0.90,0.90,.1262,.1262,.5]; %leaning dollar
        X0 = frac2B(frac_shoot(:),Busd,Bchy,Baa,Bbb,mu_us,mu_ch,mu_aa,mu_bb,BBbb_usd);
        
        %SHOOT
        shoot_ = @(x) shooting(x,X0,targ_ss,T,log_idx,nx,ny,[],dynargs{:});

        % Solve the shoot
        [xshoot_final,fval] = fsolve(shoot_,xshoot_final(:),options);
        [~,~,~,dfinal]      = shoot_(xshoot_final);
        xshoot_final        = reshape(xshoot_final,[ny+nx,T]);
        
        % Store results
        xshoot_final(log_idx,:)    = exp(xshoot_final(log_idx,:));
        polc_path_cright{jj}{ii}   = xshoot_final ;
        
        solve_indic_cright(jj,ii) = sum(fval.^2) + sum(dfinal.^2);
        if (sum(fval.^2) + sum(dfinal.^2))>1e-4
            disp('no solution, exiting subloop');
            break
        end
       
    end
    
end

