%% FIGURE 8: sanctions
load saved_results/steady_baseline cons_steady per_p_year 
load saved_results/sanctionand_transition_to_chy.mat  *usdv *out *use *shrs frac_path cons_equiv
usdv_sw = usdv;
load saved_results/sanctionand_transition_to_usd.mat  *usdv *out *use *shrs frac_path cons_equiv
usdv_st = usdv;

yrs= 40;
max_year = 40;
f9 = figure;
f9.PaperPosition = [.25, .25, dim_row];

xgrid = (1:per_p_year:per_p_year*(yrs))/per_p_year;
yidx  = 1:per_p_year:per_p_year*yrs;

s=subplot(1,2,1);

for ii = length(usdv):-1:2
    if ~isempty(usdv_sw{ii})
        plot(xgrid,usdv_sw{ii}(1,yidx),'linewidth' ,2.5,'Color',color_ch*(ii/length(usdv_sw))); hold on;
    end
    
    if ~isempty(usdv{ii})
        plot(xgrid,usdv_st{ii}(1,yidx),'linewidth' ,2.5,'Color',color_us*(1-ii/length(usdv_st))); hold on;
    end
end

s.YLim = [0,1];
s.XLim = [1,max_year];
s.FontSize = 12;
title('USD use: Region A')
xlabel('years')

s=subplot(1,2,2);
for ii = length(usdv_sw):-1:2
    if ~isempty(usdv_sw{ii})
        plot(xgrid,usdv_sw{ii}(2,yidx),'linewidth' ,2.5,'Color',color_ch*(ii/length(usdv_sw))); hold on;
    end
    if ~isempty(usdv{ii})
        plot(xgrid,usdv_st{ii}(2,yidx),'linewidth' ,2.5,'Color',color_us*(1-ii/length(usdv_st))); hold on;
    end
end

s.YLim = [0,1];

title('USD use: Region B')
xlabel('years')

s.XLim = [1,max_year];

s.FontSize = 12;



saveas(f9, 'saved_figures/figure8.eps', 'epsc')