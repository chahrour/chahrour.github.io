function str_new = char_dot(exp)
str = char(exp);
deq_idx = strfind(str, '==');
if ~isempty(deq_idx)
    str(deq_idx) = [];
end

str_new = char(zeros(1,2*length(str)));
ii = 1;
for jj = 1:length(str)
    str_tmp = str(jj);
    dot = sum(strcmp(str_tmp, {'*', '^', '/'}))==1;
    if dot && (jj-1>0)&&(str(jj-1)~='.')
        str_new(ii) = '.';
        ii =ii+1;
    end
    str_new(ii) = str_tmp;
    ii = ii+1;
end
str_new(str_new==0) = [];
