function [head_str,dcl_str,ptr_str,tnstr,tstr,str_bind,str,str_dcl] = import_matlabFunction(file_name);

fid = fopen(file_name,'r');
l = fgetl(fid);
idx_comma  = find(l==',');
idx_parenO = find(l=='(');
idx_parenC = find(l==')');
idx_comma(idx_comma<idx_parenO) = []; %drop commare comming before input args
blcks = [idx_parenO,idx_comma,idx_parenC];
head_str = cell(length(blcks)-1,1);
ptr_str = cell(length(blcks)-1,1);
dcl_str = ' double ';
for jj = 1:length(blcks)-1
    vname = l(blcks(jj)+1:blcks(jj+1)-1);
    head_str{jj} = ['#define ', vname,	'_in	prhs[' num2str(jj-1) ']'];
    ptr_str{jj} = [ vname '= *mxGetPr(' vname '_in);'];
    dcl_str = [dcl_str, '', vname , ','];
end
dcl_str = {[dcl_str(1:end-1),';']};

tcount = 0;
fcount = 0;
dfcount = 0;
idfcount = 0;
rcount = 0;
ecount = 0;


tnstr = cell(0,1);
tstr  = cell(0,1);
fstr  = cell(0,1);
rstr = cell(0,1);
estr = cell(0,1);
str_nbind = cell(0,1);
str_bind = cell(0,1);

str = cell(0,1);
str_dcl  = 'double ';
for jj = 1:1500
    
    try
        l = strtrim(fgetl(fid));
        
        if length(l)>0 && l(1)=='t'
            eq_idx = find(l=='=');
            tmp = ['double ' l(1:eq_idx-1) ';'];
            tnstr{end+1} = tmp;
            tstr{end+1} = [l(1:eq_idx), pow_sym(l(eq_idx+1:end))];
        end
        
     %   if length(l)>0 && l(1) == 'f'
     %       fstr{end+1} = ['resid[' num2str(fcount) '] = ' pow_sym(l(5:end))];
     %       fcount = fcount+1;
     %   end
        
        if length(l)>0 && (l(1) == 'd' || l(1) == 'o')
            l = [',' l(find(l=='[')+1:find(l==']')-1) ','];
            
            idx_comma = find(l==',');
            idx_semi = find(l==';');
            idx_comma =sort([idx_comma,idx_semi]);
            
            for ll = 1:length(idx_comma)-1
                tmp= l(idx_comma(ll)+1:idx_comma(ll+1)-1);
                if ~strcmp(tmp,'0.0')
                    str_bind{end+1} = ['OUT [' num2str(ll-1) '] ='  pow_sym(tmp) , ';'];
                end
            end
        end
        
        %Straight copy
        if length(l)>0 && l(1) ~= 't' && l(1) ~= 'd' && l(1) ~= '%'
            idx_eq = find(l=='=');
            if ~isempty(idx_eq)
            str{end+1} = [l(1:idx_eq), pow_sym(l(idx_eq+1:end))];
            str_dcl = [str_dcl,  l(1:idx_eq-1) ','];
            end
        end
        
        
        
        
    catch
        
        break
    end
end
str_dcl = {[str_dcl(1:end-1), ';']};

%str_nbind = str_nbind(1:9);