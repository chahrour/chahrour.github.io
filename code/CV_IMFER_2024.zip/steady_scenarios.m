%************************************************************************
% Find steady-states associated with a variety of scenarios in the paper
%**************************************************************************

save_me = true;
%% The symmetric baseline
load saved_results/steady_baseline
save_str = 'symbaseline';
btau_us_chy = 0*.01;
btau_bb_chy = 0*.01;
btau_aa_chy = 0*.01;  


%xtax_aa_chy = -0.00;
%xtax_bb_chy = -0.05;
prime_up
steady_state_finder
disp_params
if save_me
    disp(' ');
    disp(['Saving as saved_results/steady_' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end



%% The symmetric baseline - lowr
load saved_results/steady_baseline
save_str = 'symbaseline_lowr';

btau_us_chy = 0*.01;
btau_bb_chy = 0*.01;
btau_aa_chy = 0*.01;  

r = 0.5*r;


prime_up
steady_state_finder
disp_params
if save_me
    disp(' ');
    disp(['Saving as saved_results/steady_' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end


%% The symmetric baseline + sanctions case
load saved_results/steady_symbaseline
save_str = 'sanctionsand';

BBbb_usd = Bbb_usd*.15;

prime_up
steady_state_finder
disp_params
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end

%% The symmetric baseline + CN grows to 25, US to 15
load saved_results/steady_symbaseline
save_str = 'cngrowth';

mu_us = .16;
mu_ch = .4-mu_us;

prime_up
steady_state_finder
disp_params
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end

%% The symmetric baseline + CN grows to 25, US to 15
load saved_results/steady_symbaseline
save_str = 'usdgrowth';

Busd = 1.5*Busd;

prime_up
steady_state_finder
disp_params
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end


%% the symmetric baseline + 40 percent tarrifs from us on ch
load saved_results/steady_symbaseline
save_str = 'unilateral40';
trf = .30;

%etax_ch_us = 1*trf;  %tax US exports to CH
tax_us_ch  = 1*trf;  %tax US imports from CH


prime_up
steady_state_finder
disp_params
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end

%% the symmetric baseline + 40 percent tarrifs between us and bb
load saved_results/steady_symbaseline
save_str = 'hands40';
trf = .30;

%etax_bb_us = 1*trf;
tax_us_bb  = 1*trf;


prime_up
steady_state_finder
disp_params
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end

%% the symmetric baseline + tarrifs, us on ch and aa on ch
load saved_results/steady_symbaseline
save_str = 'coordinated40';
trf = .30;

%etax_ch_us = 1*trf;
%etax_ch_aa = 1*trf;
tax_us_ch  = 1*trf;
tax_aa_ch  = 1*trf;



prime_up
steady_state_finder
disp_params
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end


%% the symmetric baseline + 20 percent tarrifs between us and ch
load saved_results/steady_symbaseline
save_str = 'titfortat40';
trf = .30;


%etax_us_ch = 1*trf;
%etax_ch_us = 1*trf;
tax_us_ch  = 1*trf;
tax_ch_us  = 1*trf;


prime_up
steady_state_finder
disp_params
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end





%% the symmetric baseline + 20 percent tarrifs between competing bloc
load saved_results/steady_symbaseline
save_str = 'bloc40';
trf = .7;

tax_us_ch  = 1*trf;
tax_us_aa  = 0*trf;
tax_us_bb  = 1*trf;

tax_ch_us  = 1*trf;
tax_ch_aa  = 1*trf;
tax_ch_bb  = 0*trf;


tax_aa_us   = 0*trf;
tax_aa_ch   = 1*trf;
tax_aa_rowa = 0*trf;
tax_aa_rowb = 1*trf;

tax_bb_us   = 1*trf;
tax_bb_ch   = 0*trf;
tax_bb_rowa = 1*trf;
tax_bb_rowb = 0*trf;

%zusd_aa = 0.2;%5*0.025;
%zchy_bb = 0.2;%5*0.025;


prime_up
steady_state_finder
disp_params
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end

%% the symmetric baseline + 20 percent tarrifs between competing bloc + FIXED
load saved_results/steady_symbaseline
save_str = 'bloc40_fixx';
trf = .7;

fixx = 1;
fXaa = 0.87;
fXbb = 0.87;


tax_us_ch  = 1*trf;
tax_us_aa  = 0*trf;
tax_us_bb  = 1*trf;

tax_ch_us  = 1*trf;
tax_ch_aa  = 1*trf;
tax_ch_bb  = 0*trf;


tax_aa_us   = 0*trf;
tax_aa_ch   = 1*trf;
tax_aa_rowa = 0*trf;
tax_aa_rowb = 1*trf;

tax_bb_us   = 1*trf;
tax_bb_ch   = 0*trf;
tax_bb_rowa = 1*trf;
tax_bb_rowb = 0*trf;

zusd_aa = 0.0;5*0.025;
zchy_bb = 0.0;%5*0.025;


prime_up
steady_state_finder
disp_params
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end

%% the symmetric baseline + 20 percent tarrifs between competing bloc + FIXED
load saved_results/steady_symbaseline
save_str = 'fixx_forR1';
trf = 0;

fixx = 1;


mu_us = 0.05;
mu_aa = 0.3+.5*(.2-mu_us);
mu_bb = 0.3+.5*(.2-mu_us);


Xus = 0.05;

fXaa = 0.95;
fXbb = 0.95;


prime_up
steady_state_finder
disp_params
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end



%% the symmetric baseline + zchy_bb = 15 percent 
load saved_results/steady_symbaseline
save_str = 'zzz10';
trf = .0;

tax_us_ch  = 1*trf;
tax_us_aa  = 0*trf;
tax_us_bb  = 1*trf;

tax_ch_us  = 1*trf;
tax_ch_aa  = 1*trf;
tax_ch_bb  = 0*trf;


tax_aa_us   = 0*trf;
tax_aa_ch   = 1*trf;
tax_aa_rowa = 0*trf;
tax_aa_rowb = 1*trf;

tax_bb_us   = 1*trf;
tax_bb_ch   = 0*trf;
tax_bb_rowa = 1*trf;
tax_bb_rowb = 0*trf;

zchy_bb = 6*0.025;


prime_up
steady_state_finder
disp_params
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end



%% the symmetric baseline but less use of CHY in CH percent 
load saved_results/steady_symbaseline
save_str = 'lesschy';
trf = .0;
Xch = .21;


tax_us_ch  = 0*trf;
tax_us_aa  = 0*trf;
tax_us_bb  = 0*trf;

tax_ch_us  = 0*trf;
tax_ch_aa  = 0*trf;
tax_ch_bb  = 0*trf;


tax_aa_us   = 0*trf;
tax_aa_ch   = 0*trf;
tax_aa_rowa = 0*trf;
tax_aa_rowb = 0*trf;

tax_bb_us   = 0*trf;
tax_bb_ch   = 0*trf;
tax_bb_rowa = 0*trf;
tax_bb_rowb = 0*trf;
  
zusd_aa = 0*0.025;
zchy_bb = 0*0.025;


prime_up
steady_state_finder
disp_params
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});

end

%% The symmetric baseline + Busd grows
load saved_results/steady_symbaseline
save_str = 'bondsize';

Busd = 1.5*Busd;

prime_up

steady_state_finder
disp_params
if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end


%% EVERYTHING AFTER THIS POINT REQUIRES THE SPECIAL STEADY-STATE PROCEDURE THAT IS NEEDED WHEN CAPITAL CONTROLS ARE ON IN S.S.

%% The baseline but subsidize CH bonds returns ... requires special steady-state procedure 
load saved_results/steady_symbaseline
save_str = 'bbchytau';


btau_us_chy = 0*.01;
btau_bb_chy = -0.0025; %25 basis points of yuan support in region B
btau_aa_chy = 0*.01;  

prime_up

steady_state_finder2



if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end

%% the baseline but subsidize CH bonds returns in aa and bb ... requires special steady-state procedure
load saved_results/steady_symbaseline
save_str = 'aabbchytau';


btau_us_chy = 0*0.0075;
btau_bb_chy = -.0025; %25 basis points of yuan support in region B
btau_aa_chy = -.0025; %25 basis points

prime_up

steady_state_finder2



if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end


%% the baseline but Region B is Russia ... requires special steady-state procedure 
load saved_results/steady_baseline
save_str = 'russia_small';

mu_aa = 0.5;
mu_bb = 0.1;

Baa = .5/.3*Baa;
Bbb = .1/.3*Bbb;



prime_up

steady_state_finder2



if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end

%% the baseline but but Region B is Russia and even smaller ... requires special steady-state procedure
load saved_results/steady_russia_small
load saved_results/steady_baseline Baa Bbb
save_str = 'russia_xsmall';

mu_aa = 0.55;
mu_bb = 0.05;

Baa = .55/.3*Baa;
Bbb = .05/.3*Bbb;



prime_up

steady_state_finder2



if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end


%% the baseline but but Region B is Russia and even smaller ... requires special steady-state procedure
load saved_results/steady_russia_xsmall
load saved_results/steady_baseline Baa Bbb % to make it easier to calibrate bonds 
save_str = 'russia_xsmall_test';

mu_aa = 0.55;
mu_bb = 0.05;

Baa = .55/.3*Baa;
Bbb = .05/.3*Bbb;


trf = 0;
tax_us_bb = 0*trf;
tax_aa_rowb = 0*trf;
etax_bb_us = 0*trf;
etax_bb_aa = 1*trf;
    


prime_up

steady_state_finder2



if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end



%% the baseline, but low r
load saved_results/steady_baseline
save_str = 'baseline_lowr';

r = 0.5*r;

prime_up

steady_state_finder2


if save_me
    disp(' ');
    disp(['Saving as saved_results/' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end



