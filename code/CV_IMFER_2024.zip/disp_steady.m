% DISP_STEADY - display statistics from steady-state calculations


sfor = '%+2.3f|';
disp( ' ')
disp( '******************************************************')
disp( '                  STEADY STATE                        ')
disp( '******************************************************')
disp( '                 US      CH    AA     BB ')
disp(['GDP            : ' sprintf2(sfor, GDPs)]);
disp(['Prices Idx     : ' sprintf2(sfor, Ps(1,:))]);
disp(['Delta USD      : ' sprintf2(sfor, delta_bonds(1,:)*100)]);
disp(['Delta CHY      : ' sprintf2(sfor, delta_bonds(2,:)*100)]);
disp(['Delta ROW      : ' sprintf2(sfor, delta_bonds(3,:)*100)]);
disp(['Bs USD         : ' sprintf2(sfor, Bs(1,:))]);
disp(['Bs CHY         : ' sprintf2(sfor, Bs(2,:))]);
disp(['Bs ROW         : ' sprintf2(sfor, Bs(3,:))]);
disp(['Firm measure   : ' sprintf2(sfor, [m_us,m_ch,m_aa,m_bb])]);
disp(['Fixed costs    : ' sprintf2(sfor, fixed_costs)]);
disp(['Mismatch costs : ' sprintf2(sfor, mistmatch_costs)]);
disp(['Xs             : ' sprintf2(sfor, Xs)]);

disp(' ')
disp(['C agg          : ' sprintf2(sfor, Cs)]);
disp(['US C from      : ' sprintf2(sfor, CUSs)]);
disp(['CH C from      : ' sprintf2(sfor, CCHs)]);
disp(['AA C from      : ' sprintf2(sfor, CRWs(1,:))]);
disp(['BB C from      : ' sprintf2(sfor, CRWs(2,:))]);

disp(['US imp values  : ' sprintf2(sfor, WIMPs(1,:))]);
disp(['CH imp values  : ' sprintf2(sfor, WIMPs(2,:))]);
disp(['AA imp values  : ' sprintf2(sfor, WIMPs(3,:))]);
disp(['BB imp values  : ' sprintf2(sfor, WIMPs(4,:))]);


disp(' ')
disp(['World Trade shr: '  sprintf2(sfor,(sum(WIMPs(:)) + sum(WEXPs(:)))/sum(mu_us*GDPs(1) + mu_ch*GDPs(2) + mu_aa*GDPs(3) + mu_bb*(GDPs(4))))]);
disp(['Trade shar     : ' sprintf2(sfor, TSHRs)]);
disp(['T.B.           : ' sprintf2(sfor, TBs*100)]);
disp(['World Exp      : ' sprintf2(sfor, WEXPs./sum(WEXPs))]);



disp(' ')
disp(['NFA            : ' sprintf2(sfor, NFAs)]);
disp(['Gross F. Ass.  : ' sprintf2(sfor, GROSSs(1,:))]);
disp(['Gross F. Lia.  : ' sprintf2(sfor, GROSSs(2,:))]);
disp(['Home Bias      : ' sprintf2(sfor, HMBSs)]);
disp(['Gross Dom Debt : ' sprintf2(sfor, GDs)]);

disp(' ')
disp(['Bond interest  : ' sprintf2(sfor, [Rusd, Rchy, Rrow, Rrow])]);
disp(['Rf  - Ri       : ' sprintf2(sfor, (100*per_p_year*(1/bet -1)-[Rusd,Rchy,Rrow,Rrow]))]);
disp(['Ex. Priv.      : ' sprintf2(sfor, EPs)]);
disp(['Impl.  Re      : ' sprintf2(sfor, 100*IRs)]);

disp(' ')
disp(['$ Fnd Prbs     : ' sprintf2(sfor, FR_PROBs(1,:))]);
disp(['e Fnd Prbs     : ' sprintf2(sfor, FR_PROBs(2,:))]);

disp(['Exp Prbs fm US : ' sprintf2(sfor, TR_PROBs(1,:))]);
disp(['Exp Prbs fm EU : ' sprintf2(sfor, TR_PROBs(2,:))]);
disp(['Exp Prbs fm AA : ' sprintf2(sfor, TR_PROBs(3,:))]);
disp(['Exp Prbs fm BB : ' sprintf2(sfor, TR_PROBs(4,:))]);

disp(['Imp Prbs to US : ' sprintf2(sfor, TR_PROBs(5,:))]);
disp(['Imp Prbs to EU : ' sprintf2(sfor, TR_PROBs(6,:))]);
disp(['Imp Prbs to AA : ' sprintf2(sfor, TR_PROBs(7,:))]);
disp(['Imp Prbs to BB : ' sprintf2(sfor, TR_PROBs(8,:))]);

PTRADs(isnan(PTRADs)) = 0;
disp(['US P trade with: ' sprintf2(sfor, PTRADs(1,:))]);
disp(['EU P trade with: ' sprintf2(sfor, PTRADs(2,:))]);
disp(['AA P trade with: ' sprintf2(sfor, PTRADs(3,:))]);
disp(['BB P trade with: ' sprintf2(sfor, PTRADs(4,:))]);


disp( ' ');
disp(['Markup US good : ' sprintf2(sfor, [0    , Pch_us/(1+etax_ch_us)  , Paa_us   Pbb_us]./Pus_us)])
disp(['Markup CH good : ' sprintf2(sfor, [Pus_ch  , 0    , Paa_ch   Pbb_ch ]./Pch_ch)])
disp(['Markup AA good : ' sprintf2(sfor, [Pus_rowa, Pch_rowa, Paa_rowa Pbb_rowa]./Paa_aa)])
disp(['Markup BB good : ' sprintf2(sfor, [Pus_rowb, Pch_rowb, Paa_rowb Pbb_rowb]./Pbb_bb)])


%SPRINTF2: A little prettier
function out = sprintf2(sfor,x)

out = sprintf(sfor,x);

idx =  out=='+';
out(idx) = ' ';


%Replace NaN's
while contains(out,'NaN')
    idx = strfind(out,'NaN');
    out = [out(1:idx-1), ' -----', out(idx+3:end)];
end

end

