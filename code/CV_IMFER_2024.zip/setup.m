% SETUP - call before running any of the other programs
addpath('auto_generated');
addpath('DSGE_tools');
addpath('mex_tools');
addpath('ts_box');

%Do you want to rerun all computations or use saved results?
scratch = false;    %true  = compute everything (excl attraction regions) from scratch; 
                   %false = use saved results to generate figures.tables
                   
attr    = false;   %true = compute attraction regions from scratch, adds a lot of time

%Timing: use lagged bonds (= 0) or current bonds (= 1)
timing  = 1;

%Include a state variable Xrw
xstate = false;

%endog choice of which country to trade with
endog_ctry = false;

%If country + im/ex are jointly optimal (supercedes above)
endog_all = true;

if endog_ctry && endog_all
    error('You can''t be in two places at once!')
end

%Periods for basic shooting
Tshoot = 425;

%Color palette for plotting
clrs =   [[255,60,0]*.9
    255,120,25
    0 0 0
    [0,  0,255 ]*.9
    0,128,255 ]./255;

clist =   [ [0,  89,255 ]*.9
    [89,255,89]*0.9
    [255,89,0]*.9
    255,120,50        ]./255;

color_usd = .8*[0, 0.2, 1]+.2*[1, 0.5, 0];
color_chy = .2*[0, 0.2, 1]+.8*[1, 0.5, 0];
color_mul = [.9,.9,.9];%.7*[0, 0.2, 1]+.7*[1, 0.5, 0];
color_eur = color_mul;

dim_sqr = [13,9.5];
dim_row = [13,5];

%Colors from https://www.color-hex.com/color-palette/1026128
color_us  = [   0         0.4470    0.7410]; 
color_us  = [27,133,184]/255;
color_ch  = [   0.8500    0.3250    0.0980]; ls_ch = '-.';
color_ch = [174,90,64]/255;
color_rw  = [   0.9290    0.6940    0.1250]; ls_rw = '--';
color_rw  = [85,158,131]/255;
color_rw2 = [   0.9290    0.6940    0.1250]; ls_rw2 = ':';
color_rw2 = [118,87,181]/255;
return
%% Open the key files
try
    edit setup
    edit run_all_new.m
    edit simplify_expressions
    edit steady_solve
    edit steady_scenarios.m
    edit calibration_finder
    %edit make_all_figures
    %edit make_all_tables
    edit shooting_solve
    edit shooting
    
    %edit steady_state_finder
    %edit global_solve
    %edit regions_fancy
    %edit flows_fancy
    
catch
    disp('No editor available')
end