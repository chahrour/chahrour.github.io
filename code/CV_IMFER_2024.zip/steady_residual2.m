%% Steady-state residual using dynamic model equations
function [out,d_out] = steady_residual2(x,log_idx,ny,varargin)


if nargout == 1
    [out] = dynamic_residual(x,x,x(ny+1:end),log_idx,ny,varargin{:});
else
    
    [a,d_f,d_futr,dfrac_waste,d_past] = dynamic_residual(x,x,x(ny+1:end),log_idx,ny,varargin{:});
    
    
    out = a;
    
    d_out = d_f + d_futr;
    d_out(:,ny+1:end) = d_out(:,ny+1:end) + d_past;
end
end