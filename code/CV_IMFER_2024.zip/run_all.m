clc; close all; %clear all;

%Add helper functions to the path
setup

%**************************************************************************
% ALL COMPUTATIONS - All results generated here are saved for use in
% figure/tables.
%**************************************************************************
if ~scratch
    make_all_figures
    make_all_tables
else
    
    %% GENERATE: the mex & automatically generated m-files: ~1.5 min
    simplify_expressions
    
    clear all; rehash; setup; tic0 = tic;
    %% COMPUTE: Parameterization that satisfies targets: ~1min
    calibration_finder
    
    %% COMPUTE: Steady-states of the baseline : ~1min
    steady_solve
    
    %% COMPUTE: Steady-states of alternative scenarios: ~1min
    steady_scenarios

    % *************************************************************************
    % COMPUTE TRANSITION SCENARIOS
    % *************************************************************************
    
    %% BASELINE: asym baseline to symmetric dollar SS (flight path): <1min
    load saved_results/steady_baseline
    clear xshoot_final
    frac_shoot = [.75*mu_aa,.75*mu_aa,.75*mu_bb,.75*mu_bb,.9,.9,.1263,.1263,.5]';        %leave from middle
    targ_ss    = xspecial_long(:,1);  %land at dollar
    shooting_solve
    save saved_results/middle_to_asymdollar_transition *out *use *shrs frac_path cons_equiv
    
    %Associated figure
    figure3
    
    %% BASELINE: asym baseline to symmetric dollar SS (flight path): <1min
    load saved_results/steady_baseline frac_ss
    frac_shoot = frac_ss(:,1);
    load saved_results/steady_symbaseline
    clear xshoot_final
    targ_ss    = xspecial_long(:,1);  %land at dollar
    shooting_solve
    save saved_results/baseline_to_symdollar_transition *out *use *shrs frac_path cons_equiv
    
    %% BASELINE: middle to dollar SS (flight path): <1min
    load saved_results/steady_symbaseline
    clear xshoot_final
    frac_shoot = [.75*mu_aa,.75*mu_aa,.75*mu_bb,.75*mu_bb,.9,.9,.1263,.1263,.5]';frac_ss(:,2);        %leave from middle
    targ_ss    = xspecial_long(:,1);  %land at dollar
    shooting_solve
    save saved_results/sym_to_dollar_transition *out *use *shrs frac_path cons_equiv
    
    %% BASELINE: attraction regions for the baseline model: - ~15 min on 8 cores
    if attr
        load saved_results/steady_symbaseline
        attraction_regions
        save saved_results/attraction_region_baseline frac_rw_usd_dense frac_rw_chy_dense solve_indic* frac_ss
    end
   
    %Associated figure
    figure4
        
    %% *************************************************************************
    % COMPUTE SCENARIO TEMP_SANC - US sanctions for X years, but China doesn't
    % change capital controls
    % *************************************************************************
    
    load saved_results/steady_russia_xsmall.mat
    clear xshoot_final
    frac_shoot = frac_ss(:,1);        %leave from usd
    targ_ss    = xspecial_long(:,1);  %land at usd
    Tmax       = 5;
    sanc_lev   = 1/2*Bbb_usd;
    
    % Now crawl back to shorter horizons
    Cequiv = NaN(4,Tmax+1);usdv = cell(1,Tmax+1);shrsv = cell(1,Tmax+1); conv = cell(1,Tmax+1); tbv = cell(1,Tmax+1); epv = cell(1,Tmax+1);nfav = cell(1,Tmax+1);BBbbv=cell(1,Tmax+1); bondv = cell(1,Tmax+1); statev = cell(1,Tmax+1);wimpv = cell(1,Tmax+1);wexpv = cell(1,Tmax+1);
    for zz = Tmax:-1:1
        BBbb_usd = zeros(1,Tshoot+2);
        BBbb_usd(2:zz+1) = sanc_lev;
        
        xshoot_final = repmat(targ_ss,[1,Tshoot]);
        xshoot_final(ny+2,1:zz) = xshoot_final(ny+2,1:zz) - mu_bb*sanc_lev; %Subtract frozen bonds for better guess that doesn't make bonds negative
        
        shooting_solve
        if sum(resid_final.^2) + sum(dfinal.^2) > 1e-5
            break
        end
        
        Cequiv(:,zz+1) = cons_equiv;
        BBbbv{zz+1}  = BBbb_usd;
        usdv{zz+1}   = usd_use;
        conv{zz+1}   = con_out;
        tbv{zz+1}    = tb_out;
        epv{zz+1}    = ep_out;
        nfav{zz+1}   = nfa_out;
        bondv{zz+1}  = bonds_out;
        statev{zz+1} = bond_path;
        wimpv{zz+1}  = wimps_out;
        wexpv{zz+1}  = wexps_out;
        shrsv{zz+1}  = usd_shrs;
    end
    
    save saved_results/sanction_transition_to_usd *out *use *shrs *v frac_path Cequiv*
    
    %% *************************************************************************
    % COMPUTE SCENARIO TEMP_TAR - US/Region A tariffs on Region B for X years, but China doesn't
    % change capital controls
    % *************************************************************************
    
    load saved_results/steady_russia_xsmall.mat
    clear xshoot_final
    frac_shoot = frac_ss(:,1);        %leave from usd
    targ_ss    = xspecial_long(:,1);  %land at usd
    Tmax       = 5;
    
    trf = 0.25;
    
    
    % Now crawl back to shorter horizons
    Cequiv = NaN(4,Tmax+1);usdv = cell(1,Tmax+1);shrsv = cell(1,Tmax+1); conv = cell(1,Tmax+1); tbv = cell(1,Tmax+1); epv = cell(1,Tmax+1);nfav = cell(1,Tmax+1);BBbbv=cell(1,Tmax+1); bondv = cell(1,Tmax+1); statev = cell(1,Tmax+1);wimpv = cell(1,Tmax+1);wexpv = cell(1,Tmax+1);
    for zz = Tmax:Tmax
        
        tax_us_bb   = zeros(1,Tshoot+2);
        tax_aa_rowb = zeros(1,Tshoot+2);
        etax_bb_us  = zeros(1,Tshoot+2);
        etax_bb_aa  = zeros(1,Tshoot+2);
        
        if zz == Tmax
            for kk = 1:3
                tax_us_bb(2:zz+1)   = kk/3*trf;
                tax_aa_rowb(2:zz+1) = kk/3*trf;
                etax_bb_us(2:zz+1)  = kk/3*trf;
                etax_bb_aa(2:zz+1)  = kk/3*trf;
                shooting_solve
            end
        else
            tax_us_bb(2:zz+1)   = 1*trf;
            tax_aa_rowb(2:zz+1) = 1*trf;
            etax_bb_us(2:zz+1)  = 1*trf;
            etax_bb_aa(2:zz+1)  = 1*trf;
            shooting_solve
        end
        
        
        if sum(resid_final.^2) + sum(dfinal.^2) > 1e-5
            break
        end
        
        Cequiv(:,zz+1) = cons_equiv;
        BBbbv{zz+1}  = BBbb_usd;
        usdv{zz+1}   = usd_use;
        conv{zz+1}   = con_out;
        tbv{zz+1}    = tb_out;
        epv{zz+1}    = ep_out;
        nfav{zz+1}   = nfa_out;
        bondv{zz+1}  = bonds_out;
        statev{zz+1} = bond_path;
        wimpv{zz+1}  = wimps_out;
        wexpv{zz+1}  = wexps_out;
        shrsv{zz+1}  = usd_shrs;
    end
    
    save saved_results/tariffs_transition_to_usd *out *use *shrs *v frac_path Cequiv*
    
    %Associated figure
    figure11
    
    %% *************************************************************************
    % COMPUTE SCENARIO TEMP_COMBO - US sanctions & tarrifs for X years, but China doesn't
    % change capital controls
    % *************************************************************************
    
    load saved_results/steady_russia_xsmall.mat
    clear xshoot_final
    frac_shoot = frac_ss(:,1);        %leave from usd
    targ_ss    = xspecial_long(:,1);  %land at usd
    Tmax       = 5;
    sanc_lev   = 1/2*Bbb_usd;
    trf        = 0.25;
    
    % Now crawl back to shorter horizons
    Cequiv = NaN(4,Tmax+1);usdv = cell(1,Tmax+1);shrsv = cell(1,Tmax+1); conv = cell(1,Tmax+1); tbv = cell(1,Tmax+1); epv = cell(1,Tmax+1);nfav = cell(1,Tmax+1);BBbbv=cell(1,Tmax+1); bondv = cell(1,Tmax+1); statev = cell(1,Tmax+1);wimpv = cell(1,Tmax+1);wexpv = cell(1,Tmax+1);
    for zz = Tmax:-1:Tmax
        BBbb_usd = zeros(1,Tshoot+2);
        BBbb_usd(2:zz+1) = sanc_lev;
        
        tax_us_bb   = zeros(1,Tshoot+2);
        tax_aa_rowb = zeros(1,Tshoot+2);
        etax_bb_us  = zeros(1,Tshoot+2);
        etax_bb_aa  = zeros(1,Tshoot+2);
        
        tax_us_bb(2:zz+1)   = 1*trf;
        tax_aa_rowb(2:zz+1) = 1*trf;
        etax_bb_us(2:zz+1)  = 1*trf;
        etax_bb_aa(2:zz+1)  = 1*trf;
        
        xshoot_final = repmat(targ_ss,[1,Tshoot]);
        xshoot_final(ny+2,1:zz) = xshoot_final(ny+2,1:zz) - mu_bb*sanc_lev; %Subtract frozen bonds for better guess that doesn't make bonds negative
        
        shooting_solve
        if sum(resid_final.^2) + sum(dfinal.^2) > 1e-5
            break
        end
        
        Cequiv(:,zz+1) = cons_equiv;
        BBbbv{zz+1}  = BBbb_usd;
        usdv{zz+1}   = usd_use;
        conv{zz+1}   = con_out;
        tbv{zz+1}    = tb_out;
        epv{zz+1}    = ep_out;
        nfav{zz+1}   = nfa_out;
        bondv{zz+1}  = bonds_out;
        statev{zz+1} = bond_path;
        wimpv{zz+1}  = wimps_out;
        wexpv{zz+1}  = wexps_out;
        shrsv{zz+1} = usd_shrs;
    end
    
    save saved_results/combo_transition_to_usd *out *use *shrs *v frac_path Cequiv*
    
    
    %% *************************************************************************
    % COMPUTE SCENARIO TEMP_SANC_AND - US sanctions for X years, and china
    % removes capital controls
    % *************************************************************************
    %
    load saved_results/steady_symbaseline
    clear xshoot_final
    frac_shoot = frac_ss(:,1);        %leave from usd
    targ_ss    = xspecial_long(:,1);  %land at usd
    Tmax       = 30;
    sanc_lev   = 1/3*Bbb_usd;
    
    Cequiv = NaN(4,Tmax+1);usdv = cell(1,Tmax+1);shrsv = cell(1,Tmax+1); conv = cell(1,Tmax+1); tbv = cell(1,Tmax+1); epv = cell(1,Tmax+1);nfav = cell(1,Tmax+1);BBbbv=cell(1,Tmax+1); bondv = cell(1,Tmax+1); statev = cell(1,Tmax+1);wimpv = cell(1,Tmax+1);wexpv = cell(1,Tmax+1);
    for zz = 1:Tmax
        BBbb_usd = zeros(1,Tshoot+2);
        BBbb_usd(2:zz+1) = sanc_lev;
        
        xshoot_final = repmat(targ_ss,[1,Tshoot]);
        xshoot_final(ny+2,1:zz) = xshoot_final(ny+2,1:zz) - mu_bb*sanc_lev; %Subtract frozen bonds for better guess that doesn't make bonds negative
        
        shooting_solve
        if sum(resid_final.^2) + sum(dfinal.^2) > 1e-5
            break
        end
        
        Cequiv(:,zz+1) = cons_equiv;
        BBbbv{zz+1}  = BBbb_usd;
        usdv{zz+1}   = usd_use;
        conv{zz+1}   = con_out;
        tbv{zz+1}    = tb_out;
        epv{zz+1}    = ep_out;
        nfav{zz+1}   = nfa_out;
        bondv{zz+1}  = bonds_out;
        statev{zz+1} = bond_path;
        wimpv{zz+1}  = wimps_out;
        wexpv{zz+1}  = wexps_out;
        shrsv{zz+1} = usd_shrs;
    end
    
    save saved_results/sanctionand_transition_to_usd *out *use *shrs *v frac_path Cequiv*
    
    
    %% *************************************************************************
    % COMPUTE SCENARIO TEMP_SANC_AND - US sanctions for X years, and china
    % removes capital controls, transition to CHY?
    % *************************************************************************
    %
    load saved_results/steady_symbaseline
    clear xshoot_final
    frac_shoot = frac_ss(:,1);        %leave from usd
    targ_ss    = xspecial_long(:,3);  %land at chy
    Tmax       = 30;
    sanc_lev   = 1/3*Bbb_usd;
    
    % Now count down and stop when there's not solution
    Cequiv = NaN(4,Tmax+1);usdv = cell(1,Tmax+1);shrsv = cell(1,Tmax+1); conv = cell(1,Tmax+1); tbv = cell(1,Tmax+1); epv = cell(1,Tmax+1);nfav = cell(1,Tmax+1);BBbbv=cell(1,Tmax+1); bondv = cell(1,Tmax+1); statev = cell(1,Tmax+1);wimpv = cell(1,Tmax+1);wexpv = cell(1,Tmax+1);
    for zz = Tmax:-1:1
        BBbb_usd = zeros(1,Tshoot+2);
        BBbb_usd(2:zz+1) = sanc_lev;
        
        xshoot_final = repmat(xspecial_long(:,3),[1,Tshoot]);
        xshoot_final(ny+2,1:zz) = xshoot_final(ny+2,1:zz) - 1*mu_bb*sanc_lev; %Subtract frozen bonds for better guess that doesn't make bonds negative
        %xshoot_final(ny+1,1:zz+1) = xshoot_final(ny+1,1:zz+1) - .1*mu_aa*sanc_lev; %Subtract frozen bonds for better guess that doesn't make bonds negative
        
        shooting_solve
        if sum(resid_final.^2) + sum(dfinal.^2) > 1e-5
            break
        end
        
        Cequiv(:,zz+1) = cons_equiv;
        BBbbv{zz+1}  = BBbb_usd;
        usdv{zz+1}   = usd_use;
        conv{zz+1}   = con_out;
        tbv{zz+1}    = tb_out;
        epv{zz+1}    = ep_out;
        nfav{zz+1}   = nfa_out;
        bondv{zz+1}  = bonds_out;
        statev{zz+1} = bond_path;
        wimpv{zz+1}  = wimps_out;
        wexpv{zz+1}  = wexps_out;
        shrsv{zz+1} = usd_shrs;
    end
    
    save saved_results/sanctionand_transition_to_chy *out *use *shrs *v frac_path Cequiv*

    %Associated figure
    figure9
    
    
    %% *************************************************************************
    % COMPUTE SCENARIO XTAX_AND - Subsidize Yuan for X years, and china
    % removes capital controls, go to USD
    % *************************************************************************
    %
    
    load saved_results/steady_symbaseline
    clear xshoot_final
    frac_shoot = frac_ss(:,1);        %leave from usd
    targ_ss    = xspecial_long(:,1);  %land at usd
    Tmax       = 10;
    xtax_lev   = -0.5;
    
    Cequiv = NaN(4,Tmax+1);usdv = cell(1,Tmax+1);shrsv = cell(1,Tmax+1); conv = cell(1,Tmax+1); tbv = cell(1,Tmax+1); epv = cell(1,Tmax+1);nfav = cell(1,Tmax+1);BBbbv=cell(1,Tmax+1); bondv = cell(1,Tmax+1); statev = cell(1,Tmax+1);wimpv = cell(1,Tmax+1);wexpv = cell(1,Tmax+1);
    for zz = 5:Tmax
        xtax_bb_chy         = zeros(1,Tshoot+2);
        xtax_bb_chy(2:zz+1) = xtax_lev;
        
        %    xshoot_final = repmat(targ_ss,[1,Tshoot]);
        %    xshoot_final(ny+2,1:zz) = xshoot_final(ny+2,1:zz) - mu_bb*sanc_lev; %Subtract frozen bonds for better guess that doesn't make bonds negative
        
        shooting_solve
        if sum(resid_final.^2) + sum(dfinal.^2) > 1e-5
            break
        end
        
        Cequiv(:,zz+1) = cons_equiv;
        BBbbv{zz+1}  = BBbb_usd;
        usdv{zz+1}   = usd_use;
        conv{zz+1}   = con_out;
        tbv{zz+1}    = tb_out;
        epv{zz+1}    = ep_out;
        nfav{zz+1}   = nfa_out;
        bondv{zz+1}  = bonds_out;
        statev{zz+1} = bond_path;
        wimpv{zz+1}  = wimps_out;
        wexpv{zz+1}  = wexps_out;
        shrsv{zz+1}  = usd_shrs;
    end
    
    save saved_results/xtaxand_transition_to_usd *out *use *shrs *v frac_path Cequiv*
    
    %% *************************************************************************
    % COMPUTE SCENARIO XTAX_AND - Subsidize Yuan for X years, and china
    % removes capital controls, go to USD
    % *************************************************************************
    %
    load saved_results/steady_symbaseline
    clear xshoot_final
    frac_shoot = frac_ss(:,1); %leave from usd
    targ_ss    = xspecial_long(:,3);  %land at usd
    Tmax       = 15;
    xtax_lev   = -0.5;
    
    Cequiv = NaN(4,Tmax+1);usdv = cell(1,Tmax+1);shrsv = cell(1,Tmax+1); conv = cell(1,Tmax+1); tbv = cell(1,Tmax+1); epv = cell(1,Tmax+1);nfav = cell(1,Tmax+1);BBbbv=cell(1,Tmax+1); bondv = cell(1,Tmax+1); statev = cell(1,Tmax+1);wimpv = cell(1,Tmax+1);wexpv = cell(1,Tmax+1);
    for zz = Tmax:-1:1
        xtax_bb_chy         = zeros(1,Tshoot+2);
        xtax_bb_chy(2:zz+1) = xtax_lev;
        
        %    xshoot_final = repmat(targ_ss,[1,Tshoot]);
        %    xshoot_final(ny+2,1:zz) = xshoot_final(ny+2,1:zz) - mu_bb*sanc_lev; %Subtract frozen bonds for better guess that doesn't make bonds negative
        
        shooting_solve
        if sum(resid_final.^2) + sum(dfinal.^2) > 1e-5
            break
        end
        
        Cequiv(:,zz+1) = cons_equiv;
        BBbbv{zz+1}  = BBbb_usd;
        usdv{zz+1}   = usd_use;
        conv{zz+1}   = con_out;
        tbv{zz+1}    = tb_out;
        epv{zz+1}    = ep_out;
        nfav{zz+1}   = nfa_out;
        bondv{zz+1}  = bonds_out;
        statev{zz+1} = bond_path;
        wimpv{zz+1}  = wimps_out;
        wexpv{zz+1}  = wexps_out;
        shrsv{zz+1} = usd_shrs;
    end
    
    save saved_results/xtaxand_transition_to_chy *out *use *shrs *v frac_path Cequiv*

    %Associated figure
    figure7
    
    %% *************************************************************************
    % COMPUTE SCENARIO UNILATERAL - 40% unilateral US trade war
    % *************************************************************************
    % UNILATERAL: flight path from dollar ss to dollar SS: < 1min
    clear xshoot_final
    
    load saved_results/steady_symbaseline
    frac_shoot = frac_ss(:,1);        %leave from dollar baseline
    
    load saved_results/steady_unilateral40.mat %tax* xspecial*
    targ_ss    = xspecial_long(:,1);  %land at dollar
    
    shooting_solve
    save saved_results/dollar_to_unilateral40_transition *out *use *shrs frac_path cons_equiv
    
    %% UNILATERAL: attraction regions: - ~15 min on 8 cores
    if attr
        load saved_results/steady_unilateral40.mat
        attraction_regions_two
        save saved_results/attraction_region_unilateral40 frac_rw_usd_dense frac_rw_chy_dense solve_indic* frac_ss
    end
  
  
    %Associate figure
    figure5
    %%
    
    % *************************************************************************
    % COMPUTE SCENARIO HANDSOFF - 40% US on Region B, CH does not respond
    % *************************************************************************
    %% HANDS:  flight path from dollar ss to dollar SS: < 1min
    load saved_results/steady_symbaseline
    clear xshoot_final
    frac_shoot = frac_ss(:,1);        %leave from dollar
    
    load saved_results/steady_hands40.mat %tax* xspecial*
    targ_ss    = xspecial_long(:,1);  %land at dollar
    
    shooting_solve
    save saved_results/dollar_to_hands40_transition *out *use *shrs frac_path cons_equiv

    
    %% HANDS: attraction regions: - ~15 min on 8 cores
    if attr
        load saved_results/steady_hands40.mat
        ttic = tic;
        attraction_regions_three
        save saved_results/attraction_region_hands40 frac_rw_usd_dense frac_rw_chy_dense solve_indic* frac_ss
        toc(ttic)
    end
    
    % Associated figure
    figure6

    
    %% *************************************************************************
    % COMPUTE SCENARIO TITFORTAT - 20% tit-for-tat US-China
    % *************************************************************************
    % TITTAT:  flight path from dollar ss to dollar SS: < 1min
    load saved_results/steady_symbaseline
    clear xshoot_final
    frac_shoot = frac_ss(:,1);        %leave from dollar
    
    load saved_results/steady_titfortat40.mat %tax* xspecial*
    targ_ss    = xspecial_long(:,1);  %land at dollar
    
    shooting_solve
    save saved_results/dollar_to_titfortat40_transition *out *use *shrs frac_path cons_equiv
    
 
    %% TITAT: attraction regions: - ~15 min on 8 cores
    if attr
        load saved_results/steady_titfortat40.mat
        attraction_regions
        save saved_results/attraction_region_titfortat frac_rw_usd_dense frac_rw_chy_dense solve_indic frac_ss
    end
   
 
    
    % *************************************************************************
    % COMPUTE SCENARIO COORD - US and RW A hit CH
    % *************************************************************************
    %% COORD:  flight path from dollar ss to crossed SS: < 1min
    load saved_results/steady_symbaseline
    clear xshoot_final
    frac_shoot = frac_ss(:,1);        %leave from dollar
    
    load saved_results/steady_coordinated40.mat %tax* xspecial*
    targ_ss    = xspecial_long(:,1);  %land at dollar
    
    shooting_solve
    save saved_results/dollar_to_coordinated40_transition *out *use *shrs frac_path cons_equiv
    
    
    % *************************************************************************
    % COMPUTE SCENARIO BLOC - 75% of each block on the other
    % *************************************************************************
    %% BLOC:  flight path from dollar ss to crossed SS: < 1min
    load saved_results/steady_symbaseline frac_ss
    clear xshoot_final
    frac_shoot = frac_ss(:,1);        %leave from dollar
    
    load saved_results/steady_bloc40.mat
    targ_ss    = xspecial_long(:,1);  %land at cross
    
    shooting_solve
    
    save saved_results/dollar_to_bloc40_transition *out *use *shrs frac_path cons_equiv
    
    % *************************************************************************
    % COMPUTE SCENARIO BLOC FIX - 70% of each block on the other + X fixed at
    % initial
    % *************************************************************************
    %% BLOC:  flight path from dollar ss to crossed SS: < 1min
    load saved_results/steady_symbaseline
    clear xshoot_final
    frac_shoot = frac_ss(:,1);        %leave from dollar
    
    load saved_results/steady_bloc40_fixx.mat %tax* xspecial* z* fixx fXaa fXbb
    targ_ss    = xspecial_long(:,1);  %land at cross
    
    shooting_solve
    save saved_results/dollar_to_bloc40fix_transition *out *use *shrs frac_path cons_equiv
    

    
    
    
    
    % *************************************************************************
    % COMPUTE SCENARIO BLOC LONG - 70% of each block on the other, starting from assymetric point
    % *************************************************************************
    %% BLOC:  flight path from dollar ss to crossed SS: < 1min
    load saved_results/steady_baseline frac_ss
    clear xshoot_final
    frac_shoot = frac_ss(:,1);        %leave from dollar
    frac_ss1 = frac_ss;
    load saved_results/steady_bloc40.mat
    
    targ_ss    = xspecial_long(:,1);  %land at cross
    
    
    for zz = 1:3
        frac_shoot = zz/3*frac_ss1(:,1) + (1-zz/3)*frac_ss(:,1);
        shooting_solve
    end
    save saved_results/dollar_to_bloc40_longtransition *out *use *shrs frac_path cons_equiv
    
    % *************************************************************************
    % COMPUTE SCENARIO BLOC FIX - 40% of each block on the other + X fixed at
    % initial starting from assymetric point
    % *************************************************************************
    %% BLOC:  flight path from dollar ss to crossed SS: < 1min
    load saved_results/steady_baseline
    clear xshoot_final
    frac_shoot = frac_ss(:,1);        %leave from dollar
    
    load saved_results/steady_bloc40_fixx.mat %tax* xspecial* z* fixx fXaa fXbb
    targ_ss    = xspecial_long(:,1);  %land at cross
    
    shooting_solve
    save saved_results/dollar_to_bloc40fix_longtransition *out *use *shrs frac_path cons_equiv

    %associated figure
    figure10
    %% *************************************************************************
    % COMPUTE SCENARIO PERM HOLD SUPPT - CH supports yuan holdings foreever
    % *************************************************************************
    load saved_results/steady_symbaseline
    clear xshoot_final
    frac_shoot = frac_ss(:,1);        %leave from dollar
    
    load saved_results/steady_aabbchytau
    targ_ss    = xspecial_long(:,1);  %land at dollar
    
    shooting_solve
    
    save saved_results/dollar_to_aabbchytau_transition *out *use *shrs frac_path cons_equiv
    
    
    %% **********SCENARIOS AFTER THIS POINT NOT LIKELY TO BE USED
    
    
    % *************************************************************************
    % COMPUTE CH GROWS SCENARIO
    % *************************************************************************
    %% BLOC:  flight path from dollar ss to crossed SS: < 1min
    load saved_results/steady_symbaseline
    clear xshoot_final
    frac_shoot = frac_ss(:,1);        %leave from dollar
    
    load saved_results/steady_cngrowth.mat
    targ_ss    = xspecial_long(:,1);  %land at CHY, only steady state
    
    %Gradual growth of CN, shrinkg of US
    mu_us = [linspace(.2,0.16,20), .16*ones(1,Tshoot+2-20)]
    mu_ch = .4-mu_us;
    
    mu_us+mu_ch+mu_aa+mu_bb; %Check they always add to 1
    
    shooting_solve
    
    save saved_results/dollar_to_smallus_transition *out *use *shrs frac_path cons_equiv
    

       
    
    % *************************************************************************
    % COMPUTE SCENARIO PERM SUPPT - CH supports yuan at 10 foreever
    % *************************************************************************
    %% BLOC:  flight path from dollar ss to crossed SS: < 1min
    load saved_results/steady_symbaseline
    clear xshoot_final
    frac_shoot = frac_ss(:,1);        %leave from dollar
    
    load saved_results/steady_zzz10.mat tax* xspecial* z*
    targ_ss    = xspecial_long(:,1);  %land at dollar
    
    shooting_solve
    
    save saved_results/dollar_to_permsup10_transition *out *use *shrs frac_path cons_equiv
    
    
    %%
    
    % *************************************************************************
    % COMPUTE SCENARIO TEMPSUPP - China supports CHY in B for X years
    % *************************************************************************
    %% TMPSUPP: transition to CHY @20%
    load saved_results/steady_symbaseline
    clear xshoot_final
    frac_shoot = frac_ss(:,1);        %leave from usd
    targ_ss    = xspecial_long(:,3);  %land at chy
    
    Tmax = 40;
    Cequiv = NaN(4,Tmax+1); usdv = cell(1,Tmax+1); conv = cell(1,Tmax+1); tbv = cell(1,Tmax+1); epv = cell(1,Tmax+1);nfav = cell(1,Tmax+1);
    for zz = Tmax:-1:0
        zchy_bb = zeros(1,Tshoot+2);
        zchy_bb(2:zz+1) = .2;
        shooting_solve
        
        if sum(resid_final.^2) + sum(dfinal.^2) > 1e-5
            break
        end
        
        
        Cequiv(:,zz+1) = cons_equiv;
        BBbbv{zz+1}  = BBbb_usd;
        usdv{zz+1}   = usd_use;
        conv{zz+1}   = con_out;
        tbv{zz+1}    = tb_out;
        epv{zz+1}    = ep_out;
        nfav{zz+1}   = nfa_out;
        %bondv{zz+1}  = bonds_out;
        %statev{zz+1} = bond_path;
        %wimpv{zz+1}  = wimps_out;
        %wexpv{zz+1}  = wexps_out;
        shrsv{zz+1} = usd_shrs;
        
        
    end
    clear bondv wimpv statev wexpv
    save saved_results/tsupp_transition_to_chy *out *use *shrs *v frac_path Cequiv
    
    
    %% TMPSUPP: stay at USD @20%
    load saved_results/steady_symbaseline
    clear xshoot_final
    frac_shoot = frac_ss(:,1);        %leave from usd
    targ_ss    = xspecial_long(:,1);  %land at usd
    
    Tmax = 40;
    Cequiv = NaN(4,Tmax); usdv = cell(1,Tmax+1); conv = cell(1,Tmax+1); tbv = cell(1,Tmax+1); epv = cell(1,Tmax+1);nfav = cell(1,Tmax+1);
    for zz = 0:Tmax
        zchy_bb = zeros(1,Tshoot+2);
        zchy_bb(2:zz+1) = .2;
        shooting_solve
        
        if sum(resid_final.^2) + sum(dfinal.^2) > 1e-5
            break
        end
        
        Cequiv(:,zz+1) = cons_equiv;
        BBbbv{zz+1}  = BBbb_usd;
        usdv{zz+1}   = usd_use;
        conv{zz+1}   = con_out;
        tbv{zz+1}    = tb_out;
        epv{zz+1}    = ep_out;
        nfav{zz+1}   = nfa_out;
        %bondv{zz+1}  = bonds_out;
        %statev{zz+1} = bond_path;
        %wimpv{zz+1}  = wimps_out;
        %wexpv{zz+1}  = wexps_out;
        shrsv{zz+1} = usd_shrs;
        
        
    end
    clear bondv wimpv statev wexpv
    save saved_results/tsupp_transition_to_usd *out *use *shrs *v frac_path Cequiv
    
    %% TMPSUPP: transition to CHY @10%
    load saved_results/steady_symbaseline
    clear xshoot_final
    frac_shoot = frac_ss(:,1);        %leave from usd
    targ_ss    = xspecial_long(:,3);  %land at chy
    
    Tmax = 50;
    Cequiv = NaN(4,Tmax+1);
    usdv = cell(1,Tmax+1); conv = cell(1,Tmax+1); tbv = cell(1,Tmax+1); epv = cell(1,Tmax+1);nfav = cell(1,Tmax+1);
    for zz = Tmax:-1:0
        zchy_bb = zeros(1,Tshoot+2);
        zchy_bb(2:zz+1) = .1;
        shooting_solve
        
        if sum(resid_final.^2) + sum(dfinal.^2) > 1e-5
            break
        end
        
        Cequiv(:,zz+1) = cons_equiv;
        BBbbv{zz+1}  = BBbb_usd;
        usdv{zz+1}   = usd_use;
        conv{zz+1}   = con_out;
        tbv{zz+1}    = tb_out;
        epv{zz+1}    = ep_out;
        nfav{zz+1}   = nfa_out;
        %bondv{zz+1}  = bonds_out;
        %statev{zz+1} = bond_path;
        %wimpv{zz+1}  = wimps_out;
        %wexpv{zz+1}  = wexps_out;
        shrsv{zz+1} = usd_shrs;
        
    end
    clear bondv wimpv statev wexpv
    save saved_results/tsupp_transition_to_chy10 *out *use *shrs *v frac_path Cequiv
    
    %% TMPSUPP: stay at USD @10%
    load saved_results/steady_symbaseline
    clear xshoot_final
    frac_shoot = frac_ss(:,1);        %leave from usd
    targ_ss    = xspecial_long(:,1);  %land at usd
    
    Tmax = 50;
    Cequiv = NaN(4,Tmax);
    usdv = cell(1,Tmax+1); conv = cell(1,Tmax+1); tbv = cell(1,Tmax+1); epv = cell(1,Tmax+1);nfav = cell(1,Tmax+1);
    for zz = 0:Tmax
        zchy_bb = zeros(1,Tshoot+2);
        zchy_bb(2:zz+1) = .1;
        shooting_solve
        
        if sum(resid_final.^2) + sum(dfinal.^2) > 1e-5
            break
        end
        
        Cequiv(:,zz+1) = cons_equiv;
        BBbbv{zz+1}  = BBbb_usd;
        usdv{zz+1}   = usd_use;
        conv{zz+1}   = con_out;
        tbv{zz+1}    = tb_out;
        epv{zz+1}    = ep_out;
        nfav{zz+1}   = nfa_out;
        %bondv{zz+1}  = bonds_out;
        %statev{zz+1} = bond_path;
        %wimpv{zz+1}  = wimps_out;
        %wexpv{zz+1}  = wexps_out;
        shrsv{zz+1} = usd_shrs;
    end
    clear bondv wimpv statev wexpv
    save saved_results/tsupp_transition_to_usd10 *out *use *shrs *v frac_path Cequiv
    
  
    %% Now make all the tables
    make_all_tables
    
    tot_time = toc(tic0);
    
    disp(['Run took ' num2str(tot_time/60) ' minutes.']);
end

