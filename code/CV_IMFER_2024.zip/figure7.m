%% FIGURE 9: sanctions
load saved_results/steady_baseline cons_steady per_p_year 
load saved_results/xtaxand_transition_to_usd.mat  *out *use *shrs frac_path cons_equiv usdv
usdv_usd = usdv;

load saved_results/xtaxand_transition_to_chy.mat  *out *use *shrs frac_path cons_equiv usdv

yrs= 40;
max_year = 40;
f9 = figure;
f9.PaperPosition = [.25, .25, dim_row];

xgrid = (1:per_p_year:per_p_year*(yrs))/per_p_year;
yidx  = 1:per_p_year:per_p_year*yrs;

s=subplot(1,2,1);

plot(xgrid,usdv_usd{6}(1,yidx),'linewidth' ,2.5,'Color',color_us, 'linestyle', '--'); hold on;
plot(xgrid,usdv{11}(1,yidx),'linewidth' ,2.5,'Color',color_ch); hold on;
s.YLim = [0,1];

%s.YLim = [.5,1];
s.XLim = [1,max_year];
s.FontSize = 12;
title('USD use: Region A')
xlabel('years')
ylabel('fraction of firms')


s=subplot(1,2,2);
plot(xgrid,usdv_usd{6}(2,yidx),'linewidth' ,2.5,'Color',color_us,'linestyle', '--'); hold on;
plot(xgrid,usdv{11}(2,yidx),'linewidth' ,2.5,'Color',color_ch); hold on;

legend('5 years of subsidy', '10 years of subsidy','location','northwest');

%s.YLim = [.5,1];

title('USD use: Region B')

s.XLim = [1,max_year];

s.FontSize = 12;

s.YLim = [0,1];

saveas(f9, 'saved_figures/figure7.eps', 'epsc')