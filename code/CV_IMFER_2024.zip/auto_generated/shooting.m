% SHOOTING - computes the residuals of model equilibrium conditions for a
% given conjecture of the path of the economy.


function [resid,dF,xshoot,dfinal,usd_shrs,usd_use,con_out,tb_out,ep_out,nfa_out,prices_out,delts_out,walras_out,tau_out,taup_out,returns_out,irs_out,bonds_out,wimps_out,wexps_out] = shooting(xin,X0,YXT,T,log_idx,nx,ny,dF0,...
    Busd,Bchy,Yus,Ych,Yaa,Ybb,mu_us,mu_ch,mu_aa,mu_bb,a_us,a_ch,a_aa,a_bb,BBbb_usd,zusd_aa,zusd_bb,zchy_aa,zchy_bb,tax_us_ch,tax_us_aa,tax_us_bb,tax_ch_us,tax_ch_aa,tax_ch_bb,tax_aa_us,tax_aa_ch,tax_aa_rowa,tax_aa_rowb,tax_bb_us,tax_bb_ch,tax_bb_rowa,tax_bb_rowb,etax_ch_us,etax_aa_us,etax_bb_us,etax_us_ch,etax_aa_ch,etax_bb_ch,etax_us_aa,etax_ch_aa,etax_bb_aa,etax_us_bb,etax_ch_bb,etax_aa_bb,xtax_ch_usd,xtax_aa_usd,xtax_bb_usd,xtax_us_chy,xtax_aa_chy,xtax_bb_chy,Busd_l,Bchy_l,Yus_l,Ych_l,Yaa_l,Ybb_l,mu_us_l,mu_ch_l,mu_aa_l,mu_bb_l,a_us_l,a_ch_l,a_aa_l,a_bb_l,BBbb_usd_l,zusd_aa_l,zusd_bb_l,zchy_aa_l,zchy_bb_l,tax_us_ch_l,tax_us_aa_l,tax_us_bb_l,tax_ch_us_l,tax_ch_aa_l,tax_ch_bb_l,tax_aa_us_l,tax_aa_ch_l,tax_aa_rowa_l,tax_aa_rowb_l,tax_bb_us_l,tax_bb_ch_l,tax_bb_rowa_l,tax_bb_rowb_l,etax_ch_us_l,etax_aa_us_l,etax_bb_us_l,etax_us_ch_l,etax_aa_ch_l,etax_bb_ch_l,etax_us_aa_l,etax_ch_aa_l,etax_bb_aa_l,etax_us_bb_l,etax_ch_bb_l,etax_aa_bb_l,xtax_ch_usd_l,xtax_aa_usd_l,xtax_bb_usd_l,xtax_us_chy_l,xtax_aa_chy_l,xtax_bb_chy_l,Busd_p,Bchy_p,Yus_p,Ych_p,Yaa_p,Ybb_p,mu_us_p,mu_ch_p,mu_aa_p,mu_bb_p,a_us_p,a_ch_p,a_aa_p,a_bb_p,BBbb_usd_p,zusd_aa_p,zusd_bb_p,zchy_aa_p,zchy_bb_p,tax_us_ch_p,tax_us_aa_p,tax_us_bb_p,tax_ch_us_p,tax_ch_aa_p,tax_ch_bb_p,tax_aa_us_p,tax_aa_ch_p,tax_aa_rowa_p,tax_aa_rowb_p,tax_bb_us_p,tax_bb_ch_p,tax_bb_rowa_p,tax_bb_rowb_p,etax_ch_us_p,etax_aa_us_p,etax_bb_us_p,etax_us_ch_p,etax_aa_ch_p,etax_bb_ch_p,etax_us_aa_p,etax_ch_aa_p,etax_bb_aa_p,etax_us_bb_p,etax_ch_bb_p,etax_aa_bb_p,xtax_ch_usd_p,xtax_aa_usd_p,xtax_bb_usd_p,xtax_us_chy_p,xtax_aa_chy_p,xtax_bb_chy_p,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_chg,phi_aag,phi_bbg,bet,sig,eta,Pnumer,Xus,Xch,zrow,upp_usd,upp_chy,sanc_usd_bb,sanc_usd_ch,chi,btau_ch_usd,btau_aa_usd,btau_bb_usd,btau_us_chy,btau_aa_chy,btau_bb_chy,per_p_year,fXaa,fXbb,fixx,Baa,Bbb);
nvar = ny+nx;

xshoot = reshape(xin,[nvar,T]);

%Compute residuals
resid = NaN(nvar,T);
if isempty(dF0)
    dF   = spalloc(numel(resid),numel(resid),nvar^2);
else
    dF   = dF0;
end


%Parameters that change, unpack
Busdv = zeros(1,T+2); Busdv(:) = Busd;
Bchyv = zeros(1,T+2); Bchyv(:) = Bchy;
Yusv = zeros(1,T+2); Yusv(:) = Yus;
Ychv = zeros(1,T+2); Ychv(:) = Ych;
Yaav = zeros(1,T+2); Yaav(:) = Yaa;
Ybbv = zeros(1,T+2); Ybbv(:) = Ybb;
mu_usv = zeros(1,T+2); mu_usv(:) = mu_us;
mu_chv = zeros(1,T+2); mu_chv(:) = mu_ch;
mu_aav = zeros(1,T+2); mu_aav(:) = mu_aa;
mu_bbv = zeros(1,T+2); mu_bbv(:) = mu_bb;
a_usv = zeros(1,T+2); a_usv(:) = a_us;
a_chv = zeros(1,T+2); a_chv(:) = a_ch;
a_aav = zeros(1,T+2); a_aav(:) = a_aa;
a_bbv = zeros(1,T+2); a_bbv(:) = a_bb;
BBbb_usdv = zeros(1,T+2); BBbb_usdv(:) = BBbb_usd;
zusd_aav = zeros(1,T+2); zusd_aav(:) = zusd_aa;
zusd_bbv = zeros(1,T+2); zusd_bbv(:) = zusd_bb;
zchy_aav = zeros(1,T+2); zchy_aav(:) = zchy_aa;
zchy_bbv = zeros(1,T+2); zchy_bbv(:) = zchy_bb;
tax_us_chv = zeros(1,T+2); tax_us_chv(:) = tax_us_ch;
tax_us_aav = zeros(1,T+2); tax_us_aav(:) = tax_us_aa;
tax_us_bbv = zeros(1,T+2); tax_us_bbv(:) = tax_us_bb;
tax_ch_usv = zeros(1,T+2); tax_ch_usv(:) = tax_ch_us;
tax_ch_aav = zeros(1,T+2); tax_ch_aav(:) = tax_ch_aa;
tax_ch_bbv = zeros(1,T+2); tax_ch_bbv(:) = tax_ch_bb;
tax_aa_usv = zeros(1,T+2); tax_aa_usv(:) = tax_aa_us;
tax_aa_chv = zeros(1,T+2); tax_aa_chv(:) = tax_aa_ch;
tax_aa_rowav = zeros(1,T+2); tax_aa_rowav(:) = tax_aa_rowa;
tax_aa_rowbv = zeros(1,T+2); tax_aa_rowbv(:) = tax_aa_rowb;
tax_bb_usv = zeros(1,T+2); tax_bb_usv(:) = tax_bb_us;
tax_bb_chv = zeros(1,T+2); tax_bb_chv(:) = tax_bb_ch;
tax_bb_rowav = zeros(1,T+2); tax_bb_rowav(:) = tax_bb_rowa;
tax_bb_rowbv = zeros(1,T+2); tax_bb_rowbv(:) = tax_bb_rowb;
etax_ch_usv = zeros(1,T+2); etax_ch_usv(:) = etax_ch_us;
etax_aa_usv = zeros(1,T+2); etax_aa_usv(:) = etax_aa_us;
etax_bb_usv = zeros(1,T+2); etax_bb_usv(:) = etax_bb_us;
etax_us_chv = zeros(1,T+2); etax_us_chv(:) = etax_us_ch;
etax_aa_chv = zeros(1,T+2); etax_aa_chv(:) = etax_aa_ch;
etax_bb_chv = zeros(1,T+2); etax_bb_chv(:) = etax_bb_ch;
etax_us_aav = zeros(1,T+2); etax_us_aav(:) = etax_us_aa;
etax_ch_aav = zeros(1,T+2); etax_ch_aav(:) = etax_ch_aa;
etax_bb_aav = zeros(1,T+2); etax_bb_aav(:) = etax_bb_aa;
etax_us_bbv = zeros(1,T+2); etax_us_bbv(:) = etax_us_bb;
etax_ch_bbv = zeros(1,T+2); etax_ch_bbv(:) = etax_ch_bb;
etax_aa_bbv = zeros(1,T+2); etax_aa_bbv(:) = etax_aa_bb;
xtax_ch_usdv = zeros(1,T+2); xtax_ch_usdv(:) = xtax_ch_usd;
xtax_aa_usdv = zeros(1,T+2); xtax_aa_usdv(:) = xtax_aa_usd;
xtax_bb_usdv = zeros(1,T+2); xtax_bb_usdv(:) = xtax_bb_usd;
xtax_us_chyv = zeros(1,T+2); xtax_us_chyv(:) = xtax_us_chy;
xtax_aa_chyv = zeros(1,T+2); xtax_aa_chyv(:) = xtax_aa_chy;
xtax_bb_chyv = zeros(1,T+2); xtax_bb_chyv(:) = xtax_bb_chy;


if nargout > 4
    usd_shrs = zeros(4,T-1);
    usd_use  = zeros(2,T-1);
    con_out  = zeros(4,T-1);
    tb_out   = zeros(4,T-1);
    nfa_out  = zeros(4,T-1);
    ep_out   = zeros(1,T-1);
    prices_out = zeros(2,4,T-1);
    delts_out = zeros(3,4,T-1);
    walras_out = zeros(2,T-1);
    tau_out = zeros(2,4,T-1);
    taup_out = zeros(2,4,T-1);
    returns_out = zeros(2,T-1);
    irs_out = zeros(4,T-1);
    bonds_out = zeros(12,T-1);
    wimps_out = zeros(16,T-1);
    wexps_out = zeros(16,T-1);
end



for jj = 1:T-1
    eqidx  = (jj-1)*nvar+ (1:nvar);
    vidx   = (jj-1)*nvar+ (1:(2*nvar));
    vs_idx = (jj-2)*nvar + (ny+(1:nx));
    
    %Past and future exogenous params
    Busd   = Busdv(jj+1);
Busd_l = Busdv(jj);
Busd_p = Busdv(jj+2);

Bchy   = Bchyv(jj+1);
Bchy_l = Bchyv(jj);
Bchy_p = Bchyv(jj+2);

Yus   = Yusv(jj+1);
Yus_l = Yusv(jj);
Yus_p = Yusv(jj+2);

Ych   = Ychv(jj+1);
Ych_l = Ychv(jj);
Ych_p = Ychv(jj+2);

Yaa   = Yaav(jj+1);
Yaa_l = Yaav(jj);
Yaa_p = Yaav(jj+2);

Ybb   = Ybbv(jj+1);
Ybb_l = Ybbv(jj);
Ybb_p = Ybbv(jj+2);

mu_us   = mu_usv(jj+1);
mu_us_l = mu_usv(jj);
mu_us_p = mu_usv(jj+2);

mu_ch   = mu_chv(jj+1);
mu_ch_l = mu_chv(jj);
mu_ch_p = mu_chv(jj+2);

mu_aa   = mu_aav(jj+1);
mu_aa_l = mu_aav(jj);
mu_aa_p = mu_aav(jj+2);

mu_bb   = mu_bbv(jj+1);
mu_bb_l = mu_bbv(jj);
mu_bb_p = mu_bbv(jj+2);

a_us   = a_usv(jj+1);
a_us_l = a_usv(jj);
a_us_p = a_usv(jj+2);

a_ch   = a_chv(jj+1);
a_ch_l = a_chv(jj);
a_ch_p = a_chv(jj+2);

a_aa   = a_aav(jj+1);
a_aa_l = a_aav(jj);
a_aa_p = a_aav(jj+2);

a_bb   = a_bbv(jj+1);
a_bb_l = a_bbv(jj);
a_bb_p = a_bbv(jj+2);

BBbb_usd   = BBbb_usdv(jj+1);
BBbb_usd_l = BBbb_usdv(jj);
BBbb_usd_p = BBbb_usdv(jj+2);

zusd_aa   = zusd_aav(jj+1);
zusd_aa_l = zusd_aav(jj);
zusd_aa_p = zusd_aav(jj+2);

zusd_bb   = zusd_bbv(jj+1);
zusd_bb_l = zusd_bbv(jj);
zusd_bb_p = zusd_bbv(jj+2);

zchy_aa   = zchy_aav(jj+1);
zchy_aa_l = zchy_aav(jj);
zchy_aa_p = zchy_aav(jj+2);

zchy_bb   = zchy_bbv(jj+1);
zchy_bb_l = zchy_bbv(jj);
zchy_bb_p = zchy_bbv(jj+2);

tax_us_ch   = tax_us_chv(jj+1);
tax_us_ch_l = tax_us_chv(jj);
tax_us_ch_p = tax_us_chv(jj+2);

tax_us_aa   = tax_us_aav(jj+1);
tax_us_aa_l = tax_us_aav(jj);
tax_us_aa_p = tax_us_aav(jj+2);

tax_us_bb   = tax_us_bbv(jj+1);
tax_us_bb_l = tax_us_bbv(jj);
tax_us_bb_p = tax_us_bbv(jj+2);

tax_ch_us   = tax_ch_usv(jj+1);
tax_ch_us_l = tax_ch_usv(jj);
tax_ch_us_p = tax_ch_usv(jj+2);

tax_ch_aa   = tax_ch_aav(jj+1);
tax_ch_aa_l = tax_ch_aav(jj);
tax_ch_aa_p = tax_ch_aav(jj+2);

tax_ch_bb   = tax_ch_bbv(jj+1);
tax_ch_bb_l = tax_ch_bbv(jj);
tax_ch_bb_p = tax_ch_bbv(jj+2);

tax_aa_us   = tax_aa_usv(jj+1);
tax_aa_us_l = tax_aa_usv(jj);
tax_aa_us_p = tax_aa_usv(jj+2);

tax_aa_ch   = tax_aa_chv(jj+1);
tax_aa_ch_l = tax_aa_chv(jj);
tax_aa_ch_p = tax_aa_chv(jj+2);

tax_aa_rowa   = tax_aa_rowav(jj+1);
tax_aa_rowa_l = tax_aa_rowav(jj);
tax_aa_rowa_p = tax_aa_rowav(jj+2);

tax_aa_rowb   = tax_aa_rowbv(jj+1);
tax_aa_rowb_l = tax_aa_rowbv(jj);
tax_aa_rowb_p = tax_aa_rowbv(jj+2);

tax_bb_us   = tax_bb_usv(jj+1);
tax_bb_us_l = tax_bb_usv(jj);
tax_bb_us_p = tax_bb_usv(jj+2);

tax_bb_ch   = tax_bb_chv(jj+1);
tax_bb_ch_l = tax_bb_chv(jj);
tax_bb_ch_p = tax_bb_chv(jj+2);

tax_bb_rowa   = tax_bb_rowav(jj+1);
tax_bb_rowa_l = tax_bb_rowav(jj);
tax_bb_rowa_p = tax_bb_rowav(jj+2);

tax_bb_rowb   = tax_bb_rowbv(jj+1);
tax_bb_rowb_l = tax_bb_rowbv(jj);
tax_bb_rowb_p = tax_bb_rowbv(jj+2);

etax_ch_us   = etax_ch_usv(jj+1);
etax_ch_us_l = etax_ch_usv(jj);
etax_ch_us_p = etax_ch_usv(jj+2);

etax_aa_us   = etax_aa_usv(jj+1);
etax_aa_us_l = etax_aa_usv(jj);
etax_aa_us_p = etax_aa_usv(jj+2);

etax_bb_us   = etax_bb_usv(jj+1);
etax_bb_us_l = etax_bb_usv(jj);
etax_bb_us_p = etax_bb_usv(jj+2);

etax_us_ch   = etax_us_chv(jj+1);
etax_us_ch_l = etax_us_chv(jj);
etax_us_ch_p = etax_us_chv(jj+2);

etax_aa_ch   = etax_aa_chv(jj+1);
etax_aa_ch_l = etax_aa_chv(jj);
etax_aa_ch_p = etax_aa_chv(jj+2);

etax_bb_ch   = etax_bb_chv(jj+1);
etax_bb_ch_l = etax_bb_chv(jj);
etax_bb_ch_p = etax_bb_chv(jj+2);

etax_us_aa   = etax_us_aav(jj+1);
etax_us_aa_l = etax_us_aav(jj);
etax_us_aa_p = etax_us_aav(jj+2);

etax_ch_aa   = etax_ch_aav(jj+1);
etax_ch_aa_l = etax_ch_aav(jj);
etax_ch_aa_p = etax_ch_aav(jj+2);

etax_bb_aa   = etax_bb_aav(jj+1);
etax_bb_aa_l = etax_bb_aav(jj);
etax_bb_aa_p = etax_bb_aav(jj+2);

etax_us_bb   = etax_us_bbv(jj+1);
etax_us_bb_l = etax_us_bbv(jj);
etax_us_bb_p = etax_us_bbv(jj+2);

etax_ch_bb   = etax_ch_bbv(jj+1);
etax_ch_bb_l = etax_ch_bbv(jj);
etax_ch_bb_p = etax_ch_bbv(jj+2);

etax_aa_bb   = etax_aa_bbv(jj+1);
etax_aa_bb_l = etax_aa_bbv(jj);
etax_aa_bb_p = etax_aa_bbv(jj+2);

xtax_ch_usd   = xtax_ch_usdv(jj+1);
xtax_ch_usd_l = xtax_ch_usdv(jj);
xtax_ch_usd_p = xtax_ch_usdv(jj+2);

xtax_aa_usd   = xtax_aa_usdv(jj+1);
xtax_aa_usd_l = xtax_aa_usdv(jj);
xtax_aa_usd_p = xtax_aa_usdv(jj+2);

xtax_bb_usd   = xtax_bb_usdv(jj+1);
xtax_bb_usd_l = xtax_bb_usdv(jj);
xtax_bb_usd_p = xtax_bb_usdv(jj+2);

xtax_us_chy   = xtax_us_chyv(jj+1);
xtax_us_chy_l = xtax_us_chyv(jj);
xtax_us_chy_p = xtax_us_chyv(jj+2);

xtax_aa_chy   = xtax_aa_chyv(jj+1);
xtax_aa_chy_l = xtax_aa_chyv(jj);
xtax_aa_chy_p = xtax_aa_chyv(jj+2);

xtax_bb_chy   = xtax_bb_chyv(jj+1);
xtax_bb_chy_l = xtax_bb_chyv(jj);
xtax_bb_chy_p = xtax_bb_chyv(jj+2);


    
    [resid(:,jj),dft,dfp,~,dfl] = dynamic_residual(xshoot(:,jj),xshoot(:,jj+1),X0,log_idx,ny,...
         Busd,Bchy,Yus,Ych,Yaa,Ybb,mu_us,mu_ch,mu_aa,mu_bb,a_us,a_ch,a_aa,a_bb,BBbb_usd,zusd_aa,zusd_bb,zchy_aa,zchy_bb,tax_us_ch,tax_us_aa,tax_us_bb,tax_ch_us,tax_ch_aa,tax_ch_bb,tax_aa_us,tax_aa_ch,tax_aa_rowa,tax_aa_rowb,tax_bb_us,tax_bb_ch,tax_bb_rowa,tax_bb_rowb,etax_ch_us,etax_aa_us,etax_bb_us,etax_us_ch,etax_aa_ch,etax_bb_ch,etax_us_aa,etax_ch_aa,etax_bb_aa,etax_us_bb,etax_ch_bb,etax_aa_bb,xtax_ch_usd,xtax_aa_usd,xtax_bb_usd,xtax_us_chy,xtax_aa_chy,xtax_bb_chy,Busd_l,Bchy_l,Yus_l,Ych_l,Yaa_l,Ybb_l,mu_us_l,mu_ch_l,mu_aa_l,mu_bb_l,a_us_l,a_ch_l,a_aa_l,a_bb_l,BBbb_usd_l,zusd_aa_l,zusd_bb_l,zchy_aa_l,zchy_bb_l,tax_us_ch_l,tax_us_aa_l,tax_us_bb_l,tax_ch_us_l,tax_ch_aa_l,tax_ch_bb_l,tax_aa_us_l,tax_aa_ch_l,tax_aa_rowa_l,tax_aa_rowb_l,tax_bb_us_l,tax_bb_ch_l,tax_bb_rowa_l,tax_bb_rowb_l,etax_ch_us_l,etax_aa_us_l,etax_bb_us_l,etax_us_ch_l,etax_aa_ch_l,etax_bb_ch_l,etax_us_aa_l,etax_ch_aa_l,etax_bb_aa_l,etax_us_bb_l,etax_ch_bb_l,etax_aa_bb_l,xtax_ch_usd_l,xtax_aa_usd_l,xtax_bb_usd_l,xtax_us_chy_l,xtax_aa_chy_l,xtax_bb_chy_l,Busd_p,Bchy_p,Yus_p,Ych_p,Yaa_p,Ybb_p,mu_us_p,mu_ch_p,mu_aa_p,mu_bb_p,a_us_p,a_ch_p,a_aa_p,a_bb_p,BBbb_usd_p,zusd_aa_p,zusd_bb_p,zchy_aa_p,zchy_bb_p,tax_us_ch_p,tax_us_aa_p,tax_us_bb_p,tax_ch_us_p,tax_ch_aa_p,tax_ch_bb_p,tax_aa_us_p,tax_aa_ch_p,tax_aa_rowa_p,tax_aa_rowb_p,tax_bb_us_p,tax_bb_ch_p,tax_bb_rowa_p,tax_bb_rowb_p,etax_ch_us_p,etax_aa_us_p,etax_bb_us_p,etax_us_ch_p,etax_aa_ch_p,etax_bb_ch_p,etax_us_aa_p,etax_ch_aa_p,etax_bb_aa_p,etax_us_bb_p,etax_ch_bb_p,etax_aa_bb_p,xtax_ch_usd_p,xtax_aa_usd_p,xtax_bb_usd_p,xtax_us_chy_p,xtax_aa_chy_p,xtax_bb_chy_p,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_chg,phi_aag,phi_bbg,bet,sig,eta,Pnumer,Xus,Xch,zrow,upp_usd,upp_chy,sanc_usd_bb,sanc_usd_ch,chi,btau_ch_usd,btau_aa_usd,btau_bb_usd,btau_us_chy,btau_aa_chy,btau_bb_chy,per_p_year,fXaa,fXbb,fixx,Baa,Bbb);
    
    dF(eqidx,vidx) = dF(eqidx,vidx) + [dft,dfp];
    
    
    if jj >1
        dF(eqidx,vs_idx) = dF(eqidx,vs_idx) + dfl;
    end
    
    if nargout > 4
        [usd_shrs(:,jj),usd_use(:,jj),con_out(:,jj),tb_out(:,jj),ep_out(jj),nfa_out(:,jj),bonds_out(:,jj),prices_out(:,:,jj),~,delts_out(:,:,jj),walras_out(jj),tau_out(:,:,jj), taup_out(:,:,jj),returns_out(:,jj),irs_out(:,jj),wimps_out(:,jj),wexps_out(:,jj)] =   dynamic_responses(xshoot(:,jj),xshoot(:,jj+1),X0,log_idx,ny,...
             Busd,Bchy,Yus,Ych,Yaa,Ybb,mu_us,mu_ch,mu_aa,mu_bb,a_us,a_ch,a_aa,a_bb,BBbb_usd,zusd_aa,zusd_bb,zchy_aa,zchy_bb,tax_us_ch,tax_us_aa,tax_us_bb,tax_ch_us,tax_ch_aa,tax_ch_bb,tax_aa_us,tax_aa_ch,tax_aa_rowa,tax_aa_rowb,tax_bb_us,tax_bb_ch,tax_bb_rowa,tax_bb_rowb,etax_ch_us,etax_aa_us,etax_bb_us,etax_us_ch,etax_aa_ch,etax_bb_ch,etax_us_aa,etax_ch_aa,etax_bb_aa,etax_us_bb,etax_ch_bb,etax_aa_bb,xtax_ch_usd,xtax_aa_usd,xtax_bb_usd,xtax_us_chy,xtax_aa_chy,xtax_bb_chy,Busd_l,Bchy_l,Yus_l,Ych_l,Yaa_l,Ybb_l,mu_us_l,mu_ch_l,mu_aa_l,mu_bb_l,a_us_l,a_ch_l,a_aa_l,a_bb_l,BBbb_usd_l,zusd_aa_l,zusd_bb_l,zchy_aa_l,zchy_bb_l,tax_us_ch_l,tax_us_aa_l,tax_us_bb_l,tax_ch_us_l,tax_ch_aa_l,tax_ch_bb_l,tax_aa_us_l,tax_aa_ch_l,tax_aa_rowa_l,tax_aa_rowb_l,tax_bb_us_l,tax_bb_ch_l,tax_bb_rowa_l,tax_bb_rowb_l,etax_ch_us_l,etax_aa_us_l,etax_bb_us_l,etax_us_ch_l,etax_aa_ch_l,etax_bb_ch_l,etax_us_aa_l,etax_ch_aa_l,etax_bb_aa_l,etax_us_bb_l,etax_ch_bb_l,etax_aa_bb_l,xtax_ch_usd_l,xtax_aa_usd_l,xtax_bb_usd_l,xtax_us_chy_l,xtax_aa_chy_l,xtax_bb_chy_l,Busd_p,Bchy_p,Yus_p,Ych_p,Yaa_p,Ybb_p,mu_us_p,mu_ch_p,mu_aa_p,mu_bb_p,a_us_p,a_ch_p,a_aa_p,a_bb_p,BBbb_usd_p,zusd_aa_p,zusd_bb_p,zchy_aa_p,zchy_bb_p,tax_us_ch_p,tax_us_aa_p,tax_us_bb_p,tax_ch_us_p,tax_ch_aa_p,tax_ch_bb_p,tax_aa_us_p,tax_aa_ch_p,tax_aa_rowa_p,tax_aa_rowb_p,tax_bb_us_p,tax_bb_ch_p,tax_bb_rowa_p,tax_bb_rowb_p,etax_ch_us_p,etax_aa_us_p,etax_bb_us_p,etax_us_ch_p,etax_aa_ch_p,etax_bb_ch_p,etax_us_aa_p,etax_ch_aa_p,etax_bb_aa_p,etax_us_bb_p,etax_ch_bb_p,etax_aa_bb_p,xtax_ch_usd_p,xtax_aa_usd_p,xtax_bb_usd_p,xtax_us_chy_p,xtax_aa_chy_p,xtax_bb_chy_p,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_chg,phi_aag,phi_bbg,bet,sig,eta,Pnumer,Xus,Xch,zrow,upp_usd,upp_chy,sanc_usd_bb,sanc_usd_ch,chi,btau_ch_usd,btau_aa_usd,btau_bb_usd,btau_us_chy,btau_aa_chy,btau_bb_chy,per_p_year,fXaa,fXbb,fixx,Baa,Bbb);
    end
    
    %Update state for next round
    X0 = xshoot(end-nx+1:end,jj);
end


resid(:,T) = xshoot(:,end)-YXT;
dF(end-nvar+1:end,end-nvar+1:end) = eye(nvar);



%% Scaling
resid = 1000*resid(:);
dF    = 1000*dF;

%To test if economy has converged at the end.
dfinal = 10*(xshoot(nvar-nx+1:nvar,end-1) - xshoot(nvar-nx+1:nvar,end));


