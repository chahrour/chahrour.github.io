#include <math.h>
#include <mex.h>
#include <lapack.h>
#include <blas.h>
#include <stdlib.h>
#include <string.h>


#if !defined(MAX)
#define	MAX(A, B)	((A) > (B) ? (A) : (B))
#endif

#if !defined(MIN)
#define	MIN(A, B)	((A) < (B) ? (A) : (B))
#endif

#define pi  3.141592653589793
        
/* Prints an MxN matrix to Screen*/
void printmat_rowmaj(int m, int n, double M[m*n]){
    int x,y,k;
    k = 0;
    printf("\n");
    for(x=0;x<m;x++){
        for(y=0;y<n;y++){
            printf("%1.11lf\t", M[k]);
            k++;
        }
        printf("%\n");
    }
    return;
}


void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] )

{

    /*Check for proper number of arguments*/
    if (nrhs == 162)  {} else{mexErrMsgTxt(" 162 inputs arguments required.");}
        
    if (nlhs == 67)  {} else{mexErrMsgTxt(" 67 inputs arguments required.");}

            
    
    /*declare scalar input args*/
    double Cus_ch,Cus_rowa,Cus_rowb,Cch_us,Cch_rowa,Cch_rowb,Caa_us,Caa_ch,Caa_rowa,Caa_rowb,Cbb_us,Cbb_ch,Cbb_rowa,Cbb_rowb,Qusd,Qchy,Qrow,Pus_us,Pus_ch,Pus_rowb,Pus_rowa,Pch_ch,Pch_us,Pch_rowa,Pch_rowb,Paa_aa,Paa_ch,Paa_rowa,Paa_rowb,Paa_us,Pbb_bb,Pbb_us,Pbb_rowa,Pbb_rowb,Pbb_ch,m_us,m_ch,m_aa,m_bb,pim_us_ch_,pim_us_aa_,pim_us_bb_,pex_us_ch_,pex_us_aa_,pim_ch_us_,pim_ch_aa_,pim_ch_bb_,pex_ch_us_,pex_ch_bb_,pim_aa_us_,pim_aa_ch_,pim_aa_rowa_,pim_aa_rowb_,pex_aa_us_,pex_aa_ch_,pex_aa_rowa_,pim_bb_us_,pim_bb_ch_,pim_bb_rowa_,pim_bb_rowb_,pex_bb_us_,pex_bb_ch_,pex_bb_rowb_,sbar_aa,sbar_bb,Baa_usda,Bbb_usda,Baa_chya,Bbb_chya,Bus_usda,Bch_chya,Bus_rowa,Bch_rowa,Baa_rowa,BBbb_usd,Baa,Bbb,Bchy,Busd,Pnumer,Xch,Xus,Yaa,Ybb,Ych,Yus,a_aa,a_bb,a_ch,a_us,alph,bet,btau_aa_chy,btau_bb_chy,btau_aa_usd,btau_bb_usd,btau_ch_usd,btau_us_chy,chi,eta,etax_aa_bb,etax_bb_aa,etax_aa_ch,etax_ch_aa,etax_bb_ch,etax_ch_bb,etax_aa_us,etax_us_aa,etax_bb_us,etax_us_bb,etax_ch_us,etax_us_ch,fXaa,fXbb,fixx,kap,mu_aa,mu_bb,mu_ch,mu_us,per_p_year,phi,phi_aag,phi_bbg,phi_chg,phi_usg,r,sanc_usd_bb,sanc_usd_ch,sig,sige,tau,taup,tax_aa_ch,tax_ch_aa,tax_bb_ch,tax_ch_bb,tax_aa_us,tax_us_aa,tax_bb_us,tax_us_bb,tax_ch_us,tax_us_ch,tax_aa_rowa,tax_aa_rowb,tax_bb_rowa,tax_bb_rowb,upp_chy,upp_usd,vepsf,vepst,xtax_aa_chy,xtax_bb_chy,xtax_aa_usd,xtax_bb_usd,xtax_ch_usd,xtax_us_chy,zchy_aa,zchy_bb,zrow,zusd_aa,zusd_bb;
Cus_ch= mxGetScalar(prhs[0]);
Cus_rowa= mxGetScalar(prhs[1]);
Cus_rowb= mxGetScalar(prhs[2]);
Cch_us= mxGetScalar(prhs[3]);
Cch_rowa= mxGetScalar(prhs[4]);
Cch_rowb= mxGetScalar(prhs[5]);
Caa_us= mxGetScalar(prhs[6]);
Caa_ch= mxGetScalar(prhs[7]);
Caa_rowa= mxGetScalar(prhs[8]);
Caa_rowb= mxGetScalar(prhs[9]);
Cbb_us= mxGetScalar(prhs[10]);
Cbb_ch= mxGetScalar(prhs[11]);
Cbb_rowa= mxGetScalar(prhs[12]);
Cbb_rowb= mxGetScalar(prhs[13]);
Qusd= mxGetScalar(prhs[14]);
Qchy= mxGetScalar(prhs[15]);
Qrow= mxGetScalar(prhs[16]);
Pus_us= mxGetScalar(prhs[17]);
Pus_ch= mxGetScalar(prhs[18]);
Pus_rowb= mxGetScalar(prhs[19]);
Pus_rowa= mxGetScalar(prhs[20]);
Pch_ch= mxGetScalar(prhs[21]);
Pch_us= mxGetScalar(prhs[22]);
Pch_rowa= mxGetScalar(prhs[23]);
Pch_rowb= mxGetScalar(prhs[24]);
Paa_aa= mxGetScalar(prhs[25]);
Paa_ch= mxGetScalar(prhs[26]);
Paa_rowa= mxGetScalar(prhs[27]);
Paa_rowb= mxGetScalar(prhs[28]);
Paa_us= mxGetScalar(prhs[29]);
Pbb_bb= mxGetScalar(prhs[30]);
Pbb_us= mxGetScalar(prhs[31]);
Pbb_rowa= mxGetScalar(prhs[32]);
Pbb_rowb= mxGetScalar(prhs[33]);
Pbb_ch= mxGetScalar(prhs[34]);
m_us= mxGetScalar(prhs[35]);
m_ch= mxGetScalar(prhs[36]);
m_aa= mxGetScalar(prhs[37]);
m_bb= mxGetScalar(prhs[38]);
pim_us_ch_= mxGetScalar(prhs[39]);
pim_us_aa_= mxGetScalar(prhs[40]);
pim_us_bb_= mxGetScalar(prhs[41]);
pex_us_ch_= mxGetScalar(prhs[42]);
pex_us_aa_= mxGetScalar(prhs[43]);
pim_ch_us_= mxGetScalar(prhs[44]);
pim_ch_aa_= mxGetScalar(prhs[45]);
pim_ch_bb_= mxGetScalar(prhs[46]);
pex_ch_us_= mxGetScalar(prhs[47]);
pex_ch_bb_= mxGetScalar(prhs[48]);
pim_aa_us_= mxGetScalar(prhs[49]);
pim_aa_ch_= mxGetScalar(prhs[50]);
pim_aa_rowa_= mxGetScalar(prhs[51]);
pim_aa_rowb_= mxGetScalar(prhs[52]);
pex_aa_us_= mxGetScalar(prhs[53]);
pex_aa_ch_= mxGetScalar(prhs[54]);
pex_aa_rowa_= mxGetScalar(prhs[55]);
pim_bb_us_= mxGetScalar(prhs[56]);
pim_bb_ch_= mxGetScalar(prhs[57]);
pim_bb_rowa_= mxGetScalar(prhs[58]);
pim_bb_rowb_= mxGetScalar(prhs[59]);
pex_bb_us_= mxGetScalar(prhs[60]);
pex_bb_ch_= mxGetScalar(prhs[61]);
pex_bb_rowb_= mxGetScalar(prhs[62]);
sbar_aa= mxGetScalar(prhs[63]);
sbar_bb= mxGetScalar(prhs[64]);
Baa_usda= mxGetScalar(prhs[65]);
Bbb_usda= mxGetScalar(prhs[66]);
Baa_chya= mxGetScalar(prhs[67]);
Bbb_chya= mxGetScalar(prhs[68]);
Bus_usda= mxGetScalar(prhs[69]);
Bch_chya= mxGetScalar(prhs[70]);
Bus_rowa= mxGetScalar(prhs[71]);
Bch_rowa= mxGetScalar(prhs[72]);
Baa_rowa= mxGetScalar(prhs[73]);
BBbb_usd= mxGetScalar(prhs[74]);
Baa= mxGetScalar(prhs[75]);
Bbb= mxGetScalar(prhs[76]);
Bchy= mxGetScalar(prhs[77]);
Busd= mxGetScalar(prhs[78]);
Pnumer= mxGetScalar(prhs[79]);
Xch= mxGetScalar(prhs[80]);
Xus= mxGetScalar(prhs[81]);
Yaa= mxGetScalar(prhs[82]);
Ybb= mxGetScalar(prhs[83]);
Ych= mxGetScalar(prhs[84]);
Yus= mxGetScalar(prhs[85]);
a_aa= mxGetScalar(prhs[86]);
a_bb= mxGetScalar(prhs[87]);
a_ch= mxGetScalar(prhs[88]);
a_us= mxGetScalar(prhs[89]);
alph= mxGetScalar(prhs[90]);
bet= mxGetScalar(prhs[91]);
btau_aa_chy= mxGetScalar(prhs[92]);
btau_bb_chy= mxGetScalar(prhs[93]);
btau_aa_usd= mxGetScalar(prhs[94]);
btau_bb_usd= mxGetScalar(prhs[95]);
btau_ch_usd= mxGetScalar(prhs[96]);
btau_us_chy= mxGetScalar(prhs[97]);
chi= mxGetScalar(prhs[98]);
eta= mxGetScalar(prhs[99]);
etax_aa_bb= mxGetScalar(prhs[100]);
etax_bb_aa= mxGetScalar(prhs[101]);
etax_aa_ch= mxGetScalar(prhs[102]);
etax_ch_aa= mxGetScalar(prhs[103]);
etax_bb_ch= mxGetScalar(prhs[104]);
etax_ch_bb= mxGetScalar(prhs[105]);
etax_aa_us= mxGetScalar(prhs[106]);
etax_us_aa= mxGetScalar(prhs[107]);
etax_bb_us= mxGetScalar(prhs[108]);
etax_us_bb= mxGetScalar(prhs[109]);
etax_ch_us= mxGetScalar(prhs[110]);
etax_us_ch= mxGetScalar(prhs[111]);
fXaa= mxGetScalar(prhs[112]);
fXbb= mxGetScalar(prhs[113]);
fixx= mxGetScalar(prhs[114]);
kap= mxGetScalar(prhs[115]);
mu_aa= mxGetScalar(prhs[116]);
mu_bb= mxGetScalar(prhs[117]);
mu_ch= mxGetScalar(prhs[118]);
mu_us= mxGetScalar(prhs[119]);
per_p_year= mxGetScalar(prhs[120]);
phi= mxGetScalar(prhs[121]);
phi_aag= mxGetScalar(prhs[122]);
phi_bbg= mxGetScalar(prhs[123]);
phi_chg= mxGetScalar(prhs[124]);
phi_usg= mxGetScalar(prhs[125]);
r= mxGetScalar(prhs[126]);
sanc_usd_bb= mxGetScalar(prhs[127]);
sanc_usd_ch= mxGetScalar(prhs[128]);
sig= mxGetScalar(prhs[129]);
sige= mxGetScalar(prhs[130]);
tau= mxGetScalar(prhs[131]);
taup= mxGetScalar(prhs[132]);
tax_aa_ch= mxGetScalar(prhs[133]);
tax_ch_aa= mxGetScalar(prhs[134]);
tax_bb_ch= mxGetScalar(prhs[135]);
tax_ch_bb= mxGetScalar(prhs[136]);
tax_aa_us= mxGetScalar(prhs[137]);
tax_us_aa= mxGetScalar(prhs[138]);
tax_bb_us= mxGetScalar(prhs[139]);
tax_us_bb= mxGetScalar(prhs[140]);
tax_ch_us= mxGetScalar(prhs[141]);
tax_us_ch= mxGetScalar(prhs[142]);
tax_aa_rowa= mxGetScalar(prhs[143]);
tax_aa_rowb= mxGetScalar(prhs[144]);
tax_bb_rowa= mxGetScalar(prhs[145]);
tax_bb_rowb= mxGetScalar(prhs[146]);
upp_chy= mxGetScalar(prhs[147]);
upp_usd= mxGetScalar(prhs[148]);
vepsf= mxGetScalar(prhs[149]);
vepst= mxGetScalar(prhs[150]);
xtax_aa_chy= mxGetScalar(prhs[151]);
xtax_bb_chy= mxGetScalar(prhs[152]);
xtax_aa_usd= mxGetScalar(prhs[153]);
xtax_bb_usd= mxGetScalar(prhs[154]);
xtax_ch_usd= mxGetScalar(prhs[155]);
xtax_us_chy= mxGetScalar(prhs[156]);
zchy_aa= mxGetScalar(prhs[157]);
zchy_bb= mxGetScalar(prhs[158]);
zrow= mxGetScalar(prhs[159]);
zusd_aa= mxGetScalar(prhs[160]);
zusd_bb= mxGetScalar(prhs[161]);

         
  
    /*Create output arguments*/
    plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[1] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[2] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[3] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[4] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[5] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[6] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[7] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[8] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[9] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[10] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[11] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[12] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[13] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[14] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[15] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[16] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[17] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[18] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[19] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[20] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[21] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[22] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[23] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[24] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[25] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[26] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[27] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[28] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[29] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[30] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[31] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[32] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[33] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[34] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[35] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[36] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[37] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[38] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[39] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[40] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[41] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[42] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[43] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[44] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[45] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[46] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[47] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[48] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[49] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[50] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[51] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[52] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[53] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[54] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[55] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[56] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[57] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[58] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[59] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[60] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[61] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[62] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[63] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[64] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[65] = mxCreateDoubleMatrix(1,1,mxREAL);
plhs[66] = mxCreateDoubleMatrix(1,1,mxREAL);

    double *Cus,*Cch,*Caa,*Cbb,*Cus_us,*Cch_ch,*Caa_aa,*Cbb_bb,*Pus,*Pch,*Paa,*Pbb,*Bch_usd,*Bus_chy,*Bbb_row,*p_aa_chy,*p_aa_usd,*p_bb_chy,*p_bb_usd,*p_ch_chy,*p_ch_usd,*p_us_chy,*p_us_usd,*ph_aa_chy,*ph_aa_row,*ph_aa_usd,*ph_bb_chy,*ph_bb_row,*ph_bb_usd,*ph_ch_chy,*ph_ch_row,*ph_ch_usd,*ph_us_chy,*ph_us_row,*ph_us_usd,*m_us_til,*m_ch_til,*m_aa_til,*m_bb_til,*pim_us_ch,*pim_us_aa,*pim_us_bb,*pex_us_ch,*pex_us_aa,*pex_us_bb,*pim_ch_us,*pim_ch_aa,*pim_ch_bb,*pex_ch_us,*pex_ch_aa,*pex_ch_bb,*pim_aa_us,*pim_aa_ch,*pim_aa_aa,*pim_aa_bb,*pex_aa_us,*pex_aa_ch,*pex_aa_aa,*pex_aa_bb,*pim_bb_us,*pim_bb_ch,*pim_bb_aa,*pim_bb_bb,*pex_bb_us,*pex_bb_ch,*pex_bb_aa,*pex_bb_bb;
Cus= mxGetPr(plhs[0]);
Cch= mxGetPr(plhs[1]);
Caa= mxGetPr(plhs[2]);
Cbb= mxGetPr(plhs[3]);
Cus_us= mxGetPr(plhs[4]);
Cch_ch= mxGetPr(plhs[5]);
Caa_aa= mxGetPr(plhs[6]);
Cbb_bb= mxGetPr(plhs[7]);
Pus= mxGetPr(plhs[8]);
Pch= mxGetPr(plhs[9]);
Paa= mxGetPr(plhs[10]);
Pbb= mxGetPr(plhs[11]);
Bch_usd= mxGetPr(plhs[12]);
Bus_chy= mxGetPr(plhs[13]);
Bbb_row= mxGetPr(plhs[14]);
p_aa_chy= mxGetPr(plhs[15]);
p_aa_usd= mxGetPr(plhs[16]);
p_bb_chy= mxGetPr(plhs[17]);
p_bb_usd= mxGetPr(plhs[18]);
p_ch_chy= mxGetPr(plhs[19]);
p_ch_usd= mxGetPr(plhs[20]);
p_us_chy= mxGetPr(plhs[21]);
p_us_usd= mxGetPr(plhs[22]);
ph_aa_chy= mxGetPr(plhs[23]);
ph_aa_row= mxGetPr(plhs[24]);
ph_aa_usd= mxGetPr(plhs[25]);
ph_bb_chy= mxGetPr(plhs[26]);
ph_bb_row= mxGetPr(plhs[27]);
ph_bb_usd= mxGetPr(plhs[28]);
ph_ch_chy= mxGetPr(plhs[29]);
ph_ch_row= mxGetPr(plhs[30]);
ph_ch_usd= mxGetPr(plhs[31]);
ph_us_chy= mxGetPr(plhs[32]);
ph_us_row= mxGetPr(plhs[33]);
ph_us_usd= mxGetPr(plhs[34]);
m_us_til= mxGetPr(plhs[35]);
m_ch_til= mxGetPr(plhs[36]);
m_aa_til= mxGetPr(plhs[37]);
m_bb_til= mxGetPr(plhs[38]);
pim_us_ch= mxGetPr(plhs[39]);
pim_us_aa= mxGetPr(plhs[40]);
pim_us_bb= mxGetPr(plhs[41]);
pex_us_ch= mxGetPr(plhs[42]);
pex_us_aa= mxGetPr(plhs[43]);
pex_us_bb= mxGetPr(plhs[44]);
pim_ch_us= mxGetPr(plhs[45]);
pim_ch_aa= mxGetPr(plhs[46]);
pim_ch_bb= mxGetPr(plhs[47]);
pex_ch_us= mxGetPr(plhs[48]);
pex_ch_aa= mxGetPr(plhs[49]);
pex_ch_bb= mxGetPr(plhs[50]);
pim_aa_us= mxGetPr(plhs[51]);
pim_aa_ch= mxGetPr(plhs[52]);
pim_aa_aa= mxGetPr(plhs[53]);
pim_aa_bb= mxGetPr(plhs[54]);
pex_aa_us= mxGetPr(plhs[55]);
pex_aa_ch= mxGetPr(plhs[56]);
pex_aa_aa= mxGetPr(plhs[57]);
pex_aa_bb= mxGetPr(plhs[58]);
pim_bb_us= mxGetPr(plhs[59]);
pim_bb_ch= mxGetPr(plhs[60]);
pim_bb_aa= mxGetPr(plhs[61]);
pim_bb_bb= mxGetPr(plhs[62]);
pex_bb_us= mxGetPr(plhs[63]);
pex_bb_ch= mxGetPr(plhs[64]);
pex_bb_aa= mxGetPr(plhs[65]);
pex_bb_bb= mxGetPr(plhs[66]);

    

Cus[0] = pow(pow(Cus_ch,(eta - 1.0)/eta)*pow(-(mu_ch*(a_us - 1.0))/(mu_aa + mu_bb + mu_ch),1.0/eta) + pow(Cus_rowa,(eta - 1.0)/eta)*pow(-(mu_aa*(a_us - 1.0))/(mu_aa + mu_bb + mu_ch),1.0/eta) + pow(Cus_rowb,(eta - 1.0)/eta)*pow(-(mu_bb*(a_us - 1.0))/(mu_aa + mu_bb + mu_ch),1.0/eta) + pow(a_us,1.0/eta)*pow(-(Caa_us*mu_aa + Cbb_us*mu_bb + Cch_us*mu_ch + Yus*mu_us*(phi_usg - 1.0))/mu_us,(eta - 1.0)/eta),eta/(eta - 1.0));
Cch[0] = pow(pow(Cch_us,(eta - 1.0)/eta)*pow(-(mu_us*(a_ch - 1.0))/(mu_aa + mu_bb + mu_us),1.0/eta) + pow(Cch_rowa,(eta - 1.0)/eta)*pow(-(mu_aa*(a_ch - 1.0))/(mu_aa + mu_bb + mu_us),1.0/eta) + pow(Cch_rowb,(eta - 1.0)/eta)*pow(-(mu_bb*(a_ch - 1.0))/(mu_aa + mu_bb + mu_us),1.0/eta) + pow(a_ch,1.0/eta)*pow(-(Caa_ch*mu_aa + Cbb_ch*mu_bb + Cus_ch*mu_us + Ych*mu_ch*(phi_chg - 1.0))/mu_ch,(eta - 1.0)/eta),eta/(eta - 1.0));
Caa[0] = pow(pow(Caa_ch,(eta - 1.0)/eta)*pow(-(mu_ch*(a_aa - 1.0))/(mu_aa + mu_bb + mu_ch + mu_us),1.0/eta) + pow(Caa_us,(eta - 1.0)/eta)*pow(-(mu_us*(a_aa - 1.0))/(mu_aa + mu_bb + mu_ch + mu_us),1.0/eta) + pow(Caa_rowa,(eta - 1.0)/eta)*pow(-(mu_aa*(a_aa - 1.0))/(mu_aa + mu_bb + mu_ch + mu_us),1.0/eta) + pow(Caa_rowb,(eta - 1.0)/eta)*pow(-(mu_bb*(a_aa - 1.0))/(mu_aa + mu_bb + mu_ch + mu_us),1.0/eta) + pow(a_aa,1.0/eta)*pow(-(Caa_rowa*mu_aa + Cbb_rowa*mu_bb + Cch_rowa*mu_ch + Cus_rowa*mu_us + Yaa*mu_aa*(phi_aag - 1.0))/mu_aa,(eta - 1.0)/eta),eta/(eta - 1.0));
Cbb[0] = pow(pow(Cbb_ch,(eta - 1.0)/eta)*pow(-(mu_ch*(a_bb - 1.0))/(mu_aa + mu_bb + mu_ch + mu_us),1.0/eta) + pow(Cbb_us,(eta - 1.0)/eta)*pow(-(mu_us*(a_bb - 1.0))/(mu_aa + mu_bb + mu_ch + mu_us),1.0/eta) + pow(Cbb_rowa,(eta - 1.0)/eta)*pow(-(mu_aa*(a_bb - 1.0))/(mu_aa + mu_bb + mu_ch + mu_us),1.0/eta) + pow(Cbb_rowb,(eta - 1.0)/eta)*pow(-(mu_bb*(a_bb - 1.0))/(mu_aa + mu_bb + mu_ch + mu_us),1.0/eta) + pow(a_bb,1.0/eta)*pow(-(Caa_rowb*mu_aa + Cbb_rowb*mu_bb + Cch_rowb*mu_ch + Cus_rowb*mu_us + Ybb*mu_bb*(phi_bbg - 1.0))/mu_bb,(eta - 1.0)/eta),eta/(eta - 1.0));
Cus_us[0] = -(Caa_us*mu_aa + Cbb_us*mu_bb + Cch_us*mu_ch + Yus*mu_us*(phi_usg - 1.0))/mu_us;
Cch_ch[0] = -(Caa_ch*mu_aa + Cbb_ch*mu_bb + Cus_ch*mu_us + Ych*mu_ch*(phi_chg - 1.0))/mu_ch;
Caa_aa[0] = -(Caa_rowa*mu_aa + Cbb_rowa*mu_bb + Cch_rowa*mu_ch + Cus_rowa*mu_us + Yaa*mu_aa*(phi_aag - 1.0))/mu_aa;
Cbb_bb[0] = -(Caa_rowb*mu_aa + Cbb_rowb*mu_bb + Cch_rowb*mu_ch + Cus_rowb*mu_us + Ybb*mu_bb*(phi_bbg - 1.0))/mu_bb;
Pus[0] = 1.0/pow(pow(Pus_us,1.0 - eta)*a_us - (mu_ch*pow(Pus_ch*(tax_us_ch + 1.0),1.0 - eta)*(a_us - 1.0))/(mu_aa + mu_bb + mu_ch) - (mu_aa*pow(Pus_rowa*(tax_us_aa + 1.0),1.0 - eta)*(a_us - 1.0))/(mu_aa + mu_bb + mu_ch) - (mu_bb*pow(Pus_rowb*(tax_us_bb + 1.0),1.0 - eta)*(a_us - 1.0))/(mu_aa + mu_bb + mu_ch),1.0/(eta - 1.0));
Pch[0] = 1.0/pow(pow(Pch_ch,1.0 - eta)*a_ch - (mu_us*pow(Pch_us*(tax_ch_us + 1.0),1.0 - eta)*(a_ch - 1.0))/(mu_aa + mu_bb + mu_us) - (mu_aa*pow(Pch_rowa*(tax_ch_aa + 1.0),1.0 - eta)*(a_ch - 1.0))/(mu_aa + mu_bb + mu_us) - (mu_bb*pow(Pch_rowb*(tax_ch_bb + 1.0),1.0 - eta)*(a_ch - 1.0))/(mu_aa + mu_bb + mu_us),1.0/(eta - 1.0));
Paa[0] = 1.0/pow(pow(Paa_aa,1.0 - eta)*a_aa - (mu_ch*pow(Paa_ch*(tax_aa_ch + 1.0),1.0 - eta)*(a_aa - 1.0))/(mu_aa + mu_bb + mu_ch + mu_us) - (mu_us*pow(Paa_us*(tax_aa_us + 1.0),1.0 - eta)*(a_aa - 1.0))/(mu_aa + mu_bb + mu_ch + mu_us) - (mu_aa*pow(Paa_rowa*(tax_aa_rowa + 1.0),1.0 - eta)*(a_aa - 1.0))/(mu_aa + mu_bb + mu_ch + mu_us) - (mu_bb*pow(Paa_rowb*(tax_aa_rowb + 1.0),1.0 - eta)*(a_aa - 1.0))/(mu_aa + mu_bb + mu_ch + mu_us),1.0/(eta - 1.0));
Pbb[0] = 1.0/pow(pow(Pbb_bb,1.0 - eta)*a_bb - (mu_ch*pow(Pbb_ch*(tax_bb_ch + 1.0),1.0 - eta)*(a_bb - 1.0))/(mu_aa + mu_bb + mu_ch + mu_us) - (mu_us*pow(Pbb_us*(tax_bb_us + 1.0),1.0 - eta)*(a_bb - 1.0))/(mu_aa + mu_bb + mu_ch + mu_us) - (mu_aa*pow(Pbb_rowa*(tax_bb_rowa + 1.0),1.0 - eta)*(a_bb - 1.0))/(mu_aa + mu_bb + mu_ch + mu_us) - (mu_bb*pow(Pbb_rowb*(tax_bb_rowb + 1.0),1.0 - eta)*(a_bb - 1.0))/(mu_aa + mu_bb + mu_ch + mu_us),1.0/(eta - 1.0));
Bch_usd[0] = -(Baa_usda - Busd + Bus_usda + mu_bb*(BBbb_usd + Bbb_usda/mu_bb))/mu_ch;
Bus_chy[0] = -(Baa_chya + Bbb_chya - Bchy + Bch_chya)/mu_us;
Bbb_row[0] = -(Baa_rowa - Baa - Bbb + Bch_rowa + Bus_rowa)/mu_bb;
p_aa_chy[0] = (Baa_chya*Pch_ch*Qchy*chi*upp_chy)/(mu_aa*pow(pow(m_aa*((erfc((pow(2.0,1.0/2.0)*sbar_aa)/2.0)*(zchy_aa + zusd_aa - 1.0))/2.0 - zusd_aa + 1.0),1.0/vepsf) + pow((Baa_chya*Pch_ch*Qchy*upp_chy)/mu_aa,1.0/vepsf),vepsf));
p_aa_usd[0] = (Baa_usda*Pus_us*Qusd*chi*upp_usd)/(mu_aa*pow(pow(m_aa*(zusd_aa - (erfc((pow(2.0,1.0/2.0)*sbar_aa)/2.0)*(zchy_aa + zusd_aa - 1.0))/2.0),1.0/vepsf) + pow((Baa_usda*Pus_us*Qusd*upp_usd)/mu_aa,1.0/vepsf),vepsf));
p_bb_chy[0] = (Bbb_chya*Pch_ch*Qchy*chi*upp_chy)/(mu_bb*pow(pow(m_bb*((erfc((pow(2.0,1.0/2.0)*sbar_bb)/2.0)*(zchy_bb + zusd_bb - 1.0))/2.0 - zusd_bb + 1.0),1.0/vepsf) + pow((Bbb_chya*Pch_ch*Qchy*upp_chy)/mu_bb,1.0/vepsf),vepsf));
p_bb_usd[0] = (Bbb_usda*Pus_us*Qusd*chi*sanc_usd_bb*upp_usd)/(mu_bb*pow(pow(m_bb*sanc_usd_bb*(zusd_bb - (erfc((pow(2.0,1.0/2.0)*sbar_bb)/2.0)*(zchy_bb + zusd_bb - 1.0))/2.0),1.0/vepsf) + pow((Bbb_usda*Pus_us*Qusd*upp_usd)/mu_bb,1.0/vepsf),vepsf));
p_ch_chy[0] = (Bch_chya*Pch_ch*Qchy*chi*upp_chy)/(mu_ch*pow(pow(-m_ch*(Xch - 1.0),1.0/vepsf) + pow((Bch_chya*Pch_ch*Qchy*upp_chy)/mu_ch,1.0/vepsf),vepsf));
p_ch_usd[0] = -(Pus_us*Qusd*chi*sanc_usd_ch*upp_usd*(Baa_usda - Busd + Bus_usda + mu_bb*(BBbb_usd + Bbb_usda/mu_bb)))/(mu_ch*pow(pow(Xch*m_ch*sanc_usd_ch,1.0/vepsf) + pow(-(Pus_us*Qusd*upp_usd*(Baa_usda - Busd + Bus_usda + mu_bb*(BBbb_usd + Bbb_usda/mu_bb)))/mu_ch,1.0/vepsf),vepsf));
p_us_chy[0] = -(Pch_ch*Qchy*chi*upp_chy*(Baa_chya + Bbb_chya - Bchy + Bch_chya))/(mu_us*pow(pow(-(Pch_ch*Qchy*upp_chy*(Baa_chya + Bbb_chya - Bchy + Bch_chya))/mu_us,1.0/vepsf) + pow(-m_us*(Xus - 1.0),1.0/vepsf),vepsf));
p_us_usd[0] = (Bus_usda*Pus_us*Qusd*chi*upp_usd)/(mu_us*pow(pow(Xus*m_us,1.0/vepsf) + pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),vepsf));
ph_aa_chy[0] = (chi*m_aa*upp_chy*((erfc((pow(2.0,1.0/2.0)*sbar_aa)/2.0)*(zchy_aa + zusd_aa - 1.0))/2.0 - zusd_aa + 1.0))/pow(pow(m_aa*((erfc((pow(2.0,1.0/2.0)*sbar_aa)/2.0)*(zchy_aa + zusd_aa - 1.0))/2.0 - zusd_aa + 1.0),1.0/vepsf) + pow((Baa_chya*Pch_ch*Qchy*upp_chy)/mu_aa,1.0/vepsf),vepsf);
ph_aa_row[0] = (chi*m_aa*upp_usd*zrow)/pow(pow((Baa_rowa*Qrow*upp_usd)/mu_aa,1.0/vepsf) + pow(m_aa*zrow,1.0/vepsf),vepsf);
ph_aa_usd[0] = (chi*m_aa*upp_usd*(zusd_aa - (erfc((pow(2.0,1.0/2.0)*sbar_aa)/2.0)*(zchy_aa + zusd_aa - 1.0))/2.0))/pow(pow(m_aa*(zusd_aa - (erfc((pow(2.0,1.0/2.0)*sbar_aa)/2.0)*(zchy_aa + zusd_aa - 1.0))/2.0),1.0/vepsf) + pow((Baa_usda*Pus_us*Qusd*upp_usd)/mu_aa,1.0/vepsf),vepsf);
ph_bb_chy[0] = (chi*m_bb*upp_chy*((erfc((pow(2.0,1.0/2.0)*sbar_bb)/2.0)*(zchy_bb + zusd_bb - 1.0))/2.0 - zusd_bb + 1.0))/pow(pow(m_bb*((erfc((pow(2.0,1.0/2.0)*sbar_bb)/2.0)*(zchy_bb + zusd_bb - 1.0))/2.0 - zusd_bb + 1.0),1.0/vepsf) + pow((Bbb_chya*Pch_ch*Qchy*upp_chy)/mu_bb,1.0/vepsf),vepsf);
ph_bb_row[0] = (chi*m_bb*upp_usd*zrow)/pow(pow(m_bb*zrow,1.0/vepsf) + pow(-(Qrow*upp_usd*(Baa_rowa - Baa - Bbb + Bch_rowa + Bus_rowa))/mu_bb,1.0/vepsf),vepsf);
ph_bb_usd[0] = (chi*m_bb*sanc_usd_bb*upp_usd*(zusd_bb - (erfc((pow(2.0,1.0/2.0)*sbar_bb)/2.0)*(zchy_bb + zusd_bb - 1.0))/2.0))/pow(pow(m_bb*sanc_usd_bb*(zusd_bb - (erfc((pow(2.0,1.0/2.0)*sbar_bb)/2.0)*(zchy_bb + zusd_bb - 1.0))/2.0),1.0/vepsf) + pow((Bbb_usda*Pus_us*Qusd*upp_usd)/mu_bb,1.0/vepsf),vepsf);
ph_ch_chy[0] = -(chi*m_ch*upp_chy*(Xch - 1.0))/pow(pow(-m_ch*(Xch - 1.0),1.0/vepsf) + pow((Bch_chya*Pch_ch*Qchy*upp_chy)/mu_ch,1.0/vepsf),vepsf);
ph_ch_row[0] = (chi*m_ch*upp_usd*zrow)/pow(pow((Bch_rowa*Qrow*upp_usd)/mu_ch,1.0/vepsf) + pow(m_ch*zrow,1.0/vepsf),vepsf);
ph_ch_usd[0] = (Xch*chi*m_ch*sanc_usd_ch*upp_usd)/pow(pow(Xch*m_ch*sanc_usd_ch,1.0/vepsf) + pow(-(Pus_us*Qusd*upp_usd*(Baa_usda - Busd + Bus_usda + mu_bb*(BBbb_usd + Bbb_usda/mu_bb)))/mu_ch,1.0/vepsf),vepsf);
ph_us_chy[0] = -(chi*m_us*upp_chy*(Xus - 1.0))/pow(pow(-(Pch_ch*Qchy*upp_chy*(Baa_chya + Bbb_chya - Bchy + Bch_chya))/mu_us,1.0/vepsf) + pow(-m_us*(Xus - 1.0),1.0/vepsf),vepsf);
ph_us_row[0] = (chi*m_us*upp_usd*zrow)/pow(pow((Bus_rowa*Qrow*upp_usd)/mu_us,1.0/vepsf) + pow(m_us*zrow,1.0/vepsf),vepsf);
ph_us_usd[0] = (Xus*chi*m_us*upp_usd)/pow(pow(Xus*m_us,1.0/vepsf) + pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),vepsf);
m_us_til[0] = m_us*mu_us*((Pch_ch*Qchy*chi*upp_chy*(Xus - 1.0)*(Baa_chya + Bbb_chya - Bchy + Bch_chya))/(mu_us*pow(pow(-(Pch_ch*Qchy*upp_chy*(Baa_chya + Bbb_chya - Bchy + Bch_chya))/mu_us,1.0/vepsf) + pow(-m_us*(Xus - 1.0),1.0/vepsf),vepsf)) + (Bus_usda*Pus_us*Qusd*Xus*chi*upp_usd)/(mu_us*pow(pow(Xus*m_us,1.0/vepsf) + pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),vepsf)));
m_ch_til[0] = -m_ch*mu_ch*((Bch_chya*Pch_ch*Qchy*chi*upp_chy*(Xch - 1.0))/(mu_ch*pow(pow(-m_ch*(Xch - 1.0),1.0/vepsf) + pow((Bch_chya*Pch_ch*Qchy*upp_chy)/mu_ch,1.0/vepsf),vepsf)) + (Pus_us*Qusd*Xch*chi*sanc_usd_ch*upp_usd*(Baa_usda - Busd + Bus_usda + mu_bb*(BBbb_usd + Bbb_usda/mu_bb)))/(mu_ch*pow(pow(Xch*m_ch*sanc_usd_ch,1.0/vepsf) + pow(-(Pus_us*Qusd*upp_usd*(Baa_usda - Busd + Bus_usda + mu_bb*(BBbb_usd + Bbb_usda/mu_bb)))/mu_ch,1.0/vepsf),vepsf)));
m_aa_til[0] = m_aa*mu_aa*((Baa_chya*Pch_ch*Qchy*chi*upp_chy*((erfc((pow(2.0,1.0/2.0)*sbar_aa)/2.0)*(zchy_aa + zusd_aa - 1.0))/2.0 - zusd_aa + 1.0))/(mu_aa*pow(pow(m_aa*((erfc((pow(2.0,1.0/2.0)*sbar_aa)/2.0)*(zchy_aa + zusd_aa - 1.0))/2.0 - zusd_aa + 1.0),1.0/vepsf) + pow((Baa_chya*Pch_ch*Qchy*upp_chy)/mu_aa,1.0/vepsf),vepsf)) + (Baa_usda*Pus_us*Qusd*chi*upp_usd*(zusd_aa - (erfc((pow(2.0,1.0/2.0)*sbar_aa)/2.0)*(zchy_aa + zusd_aa - 1.0))/2.0))/(mu_aa*pow(pow(m_aa*(zusd_aa - (erfc((pow(2.0,1.0/2.0)*sbar_aa)/2.0)*(zchy_aa + zusd_aa - 1.0))/2.0),1.0/vepsf) + pow((Baa_usda*Pus_us*Qusd*upp_usd)/mu_aa,1.0/vepsf),vepsf)));
m_bb_til[0] = m_bb*mu_bb*((Bbb_chya*Pch_ch*Qchy*chi*upp_chy*((erfc((pow(2.0,1.0/2.0)*sbar_bb)/2.0)*(zchy_bb + zusd_bb - 1.0))/2.0 - zusd_bb + 1.0))/(mu_bb*pow(pow(m_bb*((erfc((pow(2.0,1.0/2.0)*sbar_bb)/2.0)*(zchy_bb + zusd_bb - 1.0))/2.0 - zusd_bb + 1.0),1.0/vepsf) + pow((Bbb_chya*Pch_ch*Qchy*upp_chy)/mu_bb,1.0/vepsf),vepsf)) + (Bbb_usda*Pus_us*Qusd*chi*sanc_usd_bb*upp_usd*(zusd_bb - (erfc((pow(2.0,1.0/2.0)*sbar_bb)/2.0)*(zchy_bb + zusd_bb - 1.0))/2.0))/(mu_bb*pow(pow(m_bb*sanc_usd_bb*(zusd_bb - (erfc((pow(2.0,1.0/2.0)*sbar_bb)/2.0)*(zchy_bb + zusd_bb - 1.0))/2.0),1.0/vepsf) + pow((Bbb_usda*Pus_us*Qusd*upp_usd)/mu_bb,1.0/vepsf),vepsf)));
pim_us_ch[0] = exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0);
pim_us_aa[0] = -(exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) - 1.0))/(exp(pim_us_aa_) + 1.0);
pim_us_bb[0] = (exp(pim_us_bb_)*((exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) - 1.0))/(exp(pim_us_aa_) + 1.0) - exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) + 1.0))/(exp(pim_us_bb_) + 1.0);
pex_us_ch[0] = -(exp(pex_us_ch_)*(exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) + (exp(pim_us_bb_)*((exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) - 1.0))/(exp(pim_us_aa_) + 1.0) - exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) + 1.0))/(exp(pim_us_bb_) + 1.0) - (exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) - 1.0))/(exp(pim_us_aa_) + 1.0) - 1.0))/(exp(pex_us_ch_) + 1.0);
pex_us_aa[0] = (exp(pex_us_aa_)*((exp(pex_us_ch_)*(exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) + (exp(pim_us_bb_)*((exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) - 1.0))/(exp(pim_us_aa_) + 1.0) - exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) + 1.0))/(exp(pim_us_bb_) + 1.0) - (exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) - 1.0))/(exp(pim_us_aa_) + 1.0) - 1.0))/(exp(pex_us_ch_) + 1.0) - exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) - (exp(pim_us_bb_)*((exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) - 1.0))/(exp(pim_us_aa_) + 1.0) - exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) + 1.0))/(exp(pim_us_bb_) + 1.0) + (exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) - 1.0))/(exp(pim_us_aa_) + 1.0) + 1.0))/(exp(pex_us_aa_) + 1.0);
pex_us_bb[0] = (exp(pex_us_ch_)*(exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) + (exp(pim_us_bb_)*((exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) - 1.0))/(exp(pim_us_aa_) + 1.0) - exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) + 1.0))/(exp(pim_us_bb_) + 1.0) - (exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) - 1.0))/(exp(pim_us_aa_) + 1.0) - 1.0))/(exp(pex_us_ch_) + 1.0) - (exp(pex_us_aa_)*((exp(pex_us_ch_)*(exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) + (exp(pim_us_bb_)*((exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) - 1.0))/(exp(pim_us_aa_) + 1.0) - exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) + 1.0))/(exp(pim_us_bb_) + 1.0) - (exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) - 1.0))/(exp(pim_us_aa_) + 1.0) - 1.0))/(exp(pex_us_ch_) + 1.0) - exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) - (exp(pim_us_bb_)*((exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) - 1.0))/(exp(pim_us_aa_) + 1.0) - exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) + 1.0))/(exp(pim_us_bb_) + 1.0) + (exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) - 1.0))/(exp(pim_us_aa_) + 1.0) + 1.0))/(exp(pex_us_aa_) + 1.0) - exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) - (exp(pim_us_bb_)*((exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) - 1.0))/(exp(pim_us_aa_) + 1.0) - exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) + 1.0))/(exp(pim_us_bb_) + 1.0) + (exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_) + 1.0) - 1.0))/(exp(pim_us_aa_) + 1.0) + 1.0;
pim_ch_us[0] = exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0);
pim_ch_aa[0] = (exp(pim_ch_aa_)*((exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) - 1.0))/(exp(pim_ch_bb_) + 1.0) - exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) + 1.0))/(exp(pim_ch_aa_) + 1.0);
pim_ch_bb[0] = -(exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) - 1.0))/(exp(pim_ch_bb_) + 1.0);
pex_ch_us[0] = -(exp(pex_ch_us_)*(exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) + (exp(pim_ch_aa_)*((exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) - 1.0))/(exp(pim_ch_bb_) + 1.0) - exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) + 1.0))/(exp(pim_ch_aa_) + 1.0) - (exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) - 1.0))/(exp(pim_ch_bb_) + 1.0) - 1.0))/(exp(pex_ch_us_) + 1.0);
pex_ch_aa[0] = (exp(pex_ch_us_)*(exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) + (exp(pim_ch_aa_)*((exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) - 1.0))/(exp(pim_ch_bb_) + 1.0) - exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) + 1.0))/(exp(pim_ch_aa_) + 1.0) - (exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) - 1.0))/(exp(pim_ch_bb_) + 1.0) - 1.0))/(exp(pex_ch_us_) + 1.0) - (exp(pex_ch_bb_)*((exp(pex_ch_us_)*(exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) + (exp(pim_ch_aa_)*((exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) - 1.0))/(exp(pim_ch_bb_) + 1.0) - exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) + 1.0))/(exp(pim_ch_aa_) + 1.0) - (exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) - 1.0))/(exp(pim_ch_bb_) + 1.0) - 1.0))/(exp(pex_ch_us_) + 1.0) - exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) - (exp(pim_ch_aa_)*((exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) - 1.0))/(exp(pim_ch_bb_) + 1.0) - exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) + 1.0))/(exp(pim_ch_aa_) + 1.0) + (exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) - 1.0))/(exp(pim_ch_bb_) + 1.0) + 1.0))/(exp(pex_ch_bb_) + 1.0) - exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) - (exp(pim_ch_aa_)*((exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) - 1.0))/(exp(pim_ch_bb_) + 1.0) - exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) + 1.0))/(exp(pim_ch_aa_) + 1.0) + (exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) - 1.0))/(exp(pim_ch_bb_) + 1.0) + 1.0;
pex_ch_bb[0] = (exp(pex_ch_bb_)*((exp(pex_ch_us_)*(exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) + (exp(pim_ch_aa_)*((exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) - 1.0))/(exp(pim_ch_bb_) + 1.0) - exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) + 1.0))/(exp(pim_ch_aa_) + 1.0) - (exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) - 1.0))/(exp(pim_ch_bb_) + 1.0) - 1.0))/(exp(pex_ch_us_) + 1.0) - exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) - (exp(pim_ch_aa_)*((exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) - 1.0))/(exp(pim_ch_bb_) + 1.0) - exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) + 1.0))/(exp(pim_ch_aa_) + 1.0) + (exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_) + 1.0) - 1.0))/(exp(pim_ch_bb_) + 1.0) + 1.0))/(exp(pex_ch_bb_) + 1.0);
pim_aa_us[0] = exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0);
pim_aa_ch[0] = -(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0);
pim_aa_aa[0] = (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0);
pim_aa_bb[0] = -(exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) - (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - 1.0))/(exp(pim_aa_rowb_) + 1.0);
pex_aa_us[0] = (exp(pex_aa_us_)*((exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) - (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - 1.0))/(exp(pim_aa_rowb_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) + (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) + 1.0))/(exp(pex_aa_us_) + 1.0);
pex_aa_ch[0] = -(exp(pex_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + (exp(pex_aa_us_)*((exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) - (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - 1.0))/(exp(pim_aa_rowb_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) + (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) + 1.0))/(exp(pex_aa_us_) + 1.0) - (exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) - (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - 1.0))/(exp(pim_aa_rowb_) + 1.0) + (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) - (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - 1.0))/(exp(pex_aa_ch_) + 1.0);
pex_aa_aa[0] = (exp(pex_aa_rowa_)*((exp(pex_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + (exp(pex_aa_us_)*((exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) - (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - 1.0))/(exp(pim_aa_rowb_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) + (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) + 1.0))/(exp(pex_aa_us_) + 1.0) - (exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) - (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - 1.0))/(exp(pim_aa_rowb_) + 1.0) + (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) - (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - 1.0))/(exp(pex_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - (exp(pex_aa_us_)*((exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) - (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - 1.0))/(exp(pim_aa_rowb_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) + (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) + 1.0))/(exp(pex_aa_us_) + 1.0) + (exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) - (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - 1.0))/(exp(pim_aa_rowb_) + 1.0) - (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) + (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) + 1.0))/(exp(pex_aa_rowa_) + 1.0);
pex_aa_bb[0] = (exp(pex_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + (exp(pex_aa_us_)*((exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) - (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - 1.0))/(exp(pim_aa_rowb_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) + (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) + 1.0))/(exp(pex_aa_us_) + 1.0) - (exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) - (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - 1.0))/(exp(pim_aa_rowb_) + 1.0) + (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) - (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - 1.0))/(exp(pex_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - (exp(pex_aa_rowa_)*((exp(pex_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + (exp(pex_aa_us_)*((exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) - (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - 1.0))/(exp(pim_aa_rowb_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) + (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) + 1.0))/(exp(pex_aa_us_) + 1.0) - (exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) - (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - 1.0))/(exp(pim_aa_rowb_) + 1.0) + (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) - (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - 1.0))/(exp(pex_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - (exp(pex_aa_us_)*((exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) - (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - 1.0))/(exp(pim_aa_rowb_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) + (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) + 1.0))/(exp(pex_aa_us_) + 1.0) + (exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) - (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - 1.0))/(exp(pim_aa_rowb_) + 1.0) - (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) + (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) + 1.0))/(exp(pex_aa_rowa_) + 1.0) - (exp(pex_aa_us_)*((exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) - (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - 1.0))/(exp(pim_aa_rowb_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) + (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) + 1.0))/(exp(pex_aa_us_) + 1.0) + (exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) - (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - 1.0))/(exp(pim_aa_rowb_) + 1.0) - (exp(pim_aa_rowa_)*((exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) - exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) + 1.0))/(exp(pim_aa_rowa_) + 1.0) + (exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_) + 1.0) - 1.0))/(exp(pim_aa_ch_) + 1.0) + 1.0;
pim_bb_us[0] = exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0);
pim_bb_ch[0] = -(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0);
pim_bb_aa[0] = -(exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) - (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - 1.0))/(exp(pim_bb_rowa_) + 1.0);
pim_bb_bb[0] = (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0);
pex_bb_us[0] = (exp(pex_bb_us_)*((exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) - (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - 1.0))/(exp(pim_bb_rowa_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) + (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) + 1.0))/(exp(pex_bb_us_) + 1.0);
pex_bb_ch[0] = -(exp(pex_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + (exp(pex_bb_us_)*((exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) - (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - 1.0))/(exp(pim_bb_rowa_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) + (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) + 1.0))/(exp(pex_bb_us_) + 1.0) - (exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) - (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - 1.0))/(exp(pim_bb_rowa_) + 1.0) + (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) - (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - 1.0))/(exp(pex_bb_ch_) + 1.0);
pex_bb_aa[0] = (exp(pex_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + (exp(pex_bb_us_)*((exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) - (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - 1.0))/(exp(pim_bb_rowa_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) + (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) + 1.0))/(exp(pex_bb_us_) + 1.0) - (exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) - (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - 1.0))/(exp(pim_bb_rowa_) + 1.0) + (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) - (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - 1.0))/(exp(pex_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - (exp(pex_bb_rowb_)*((exp(pex_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + (exp(pex_bb_us_)*((exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) - (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - 1.0))/(exp(pim_bb_rowa_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) + (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) + 1.0))/(exp(pex_bb_us_) + 1.0) - (exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) - (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - 1.0))/(exp(pim_bb_rowa_) + 1.0) + (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) - (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - 1.0))/(exp(pex_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - (exp(pex_bb_us_)*((exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) - (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - 1.0))/(exp(pim_bb_rowa_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) + (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) + 1.0))/(exp(pex_bb_us_) + 1.0) + (exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) - (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - 1.0))/(exp(pim_bb_rowa_) + 1.0) - (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) + (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) + 1.0))/(exp(pex_bb_rowb_) + 1.0) - (exp(pex_bb_us_)*((exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) - (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - 1.0))/(exp(pim_bb_rowa_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) + (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) + 1.0))/(exp(pex_bb_us_) + 1.0) + (exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) - (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - 1.0))/(exp(pim_bb_rowa_) + 1.0) - (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) + (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) + 1.0;
pex_bb_bb[0] = (exp(pex_bb_rowb_)*((exp(pex_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + (exp(pex_bb_us_)*((exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) - (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - 1.0))/(exp(pim_bb_rowa_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) + (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) + 1.0))/(exp(pex_bb_us_) + 1.0) - (exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) - (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - 1.0))/(exp(pim_bb_rowa_) + 1.0) + (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) - (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - 1.0))/(exp(pex_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - (exp(pex_bb_us_)*((exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) - (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - 1.0))/(exp(pim_bb_rowa_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) + (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) + 1.0))/(exp(pex_bb_us_) + 1.0) + (exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) - (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - 1.0))/(exp(pim_bb_rowa_) + 1.0) - (exp(pim_bb_rowb_)*((exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) - exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) + 1.0))/(exp(pim_bb_rowb_) + 1.0) + (exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_) + 1.0) - 1.0))/(exp(pim_bb_ch_) + 1.0) + 1.0))/(exp(pex_bb_rowb_) + 1.0);
        
      
                            
                  
}




