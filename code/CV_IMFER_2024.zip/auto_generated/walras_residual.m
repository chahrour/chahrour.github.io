function [out] = walras_residual(x,xp,xl,log_idx,...
    Busd,Bchy,Yus,Ych,Yaa,Ybb,mu_us,mu_ch,mu_aa,mu_bb,a_us,a_ch,a_aa,a_bb,BBbb_usd,zusd_aa,zusd_bb,zchy_aa,zchy_bb,tax_us_ch,tax_us_aa,tax_us_bb,tax_ch_us,tax_ch_aa,tax_ch_bb,tax_aa_us,tax_aa_ch,tax_aa_rowa,tax_aa_rowb,tax_bb_us,tax_bb_ch,tax_bb_rowa,tax_bb_rowb,etax_ch_us,etax_aa_us,etax_bb_us,etax_us_ch,etax_aa_ch,etax_bb_ch,etax_us_aa,etax_ch_aa,etax_bb_aa,etax_us_bb,etax_ch_bb,etax_aa_bb,xtax_ch_usd,xtax_aa_usd,xtax_bb_usd,xtax_us_chy,xtax_aa_chy,xtax_bb_chy,Busd_l,Bchy_l,Yus_l,Ych_l,Yaa_l,Ybb_l,mu_us_l,mu_ch_l,mu_aa_l,mu_bb_l,a_us_l,a_ch_l,a_aa_l,a_bb_l,BBbb_usd_l,zusd_aa_l,zusd_bb_l,zchy_aa_l,zchy_bb_l,tax_us_ch_l,tax_us_aa_l,tax_us_bb_l,tax_ch_us_l,tax_ch_aa_l,tax_ch_bb_l,tax_aa_us_l,tax_aa_ch_l,tax_aa_rowa_l,tax_aa_rowb_l,tax_bb_us_l,tax_bb_ch_l,tax_bb_rowa_l,tax_bb_rowb_l,etax_ch_us_l,etax_aa_us_l,etax_bb_us_l,etax_us_ch_l,etax_aa_ch_l,etax_bb_ch_l,etax_us_aa_l,etax_ch_aa_l,etax_bb_aa_l,etax_us_bb_l,etax_ch_bb_l,etax_aa_bb_l,xtax_ch_usd_l,xtax_aa_usd_l,xtax_bb_usd_l,xtax_us_chy_l,xtax_aa_chy_l,xtax_bb_chy_l,Busd_p,Bchy_p,Yus_p,Ych_p,Yaa_p,Ybb_p,mu_us_p,mu_ch_p,mu_aa_p,mu_bb_p,a_us_p,a_ch_p,a_aa_p,a_bb_p,BBbb_usd_p,zusd_aa_p,zusd_bb_p,zchy_aa_p,zchy_bb_p,tax_us_ch_p,tax_us_aa_p,tax_us_bb_p,tax_ch_us_p,tax_ch_aa_p,tax_ch_bb_p,tax_aa_us_p,tax_aa_ch_p,tax_aa_rowa_p,tax_aa_rowb_p,tax_bb_us_p,tax_bb_ch_p,tax_bb_rowa_p,tax_bb_rowb_p,etax_ch_us_p,etax_aa_us_p,etax_bb_us_p,etax_us_ch_p,etax_aa_ch_p,etax_bb_ch_p,etax_us_aa_p,etax_ch_aa_p,etax_bb_aa_p,etax_us_bb_p,etax_ch_bb_p,etax_aa_bb_p,xtax_ch_usd_p,xtax_aa_usd_p,xtax_bb_usd_p,xtax_us_chy_p,xtax_aa_chy_p,xtax_bb_chy_p,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_chg,phi_aag,phi_bbg,bet,sig,eta,Pnumer,Xus,Xch,zrow,upp_usd,upp_chy,sanc_usd_bb,sanc_usd_ch,chi,btau_ch_usd,btau_aa_usd,btau_bb_usd,btau_us_chy,btau_aa_chy,btau_bb_chy,per_p_year,fXaa,fXbb,fixx,Baa,Bbb)

x(log_idx) = exp(x(log_idx));
xp(log_idx) = exp(xp(log_idx));

log_idx_past = log_idx(log_idx>25)-25; %Get only the states that are logged
xl(log_idx_past) = exp(xl(log_idx_past));


%Time t variables
 Cus_ch=x(1);
 Cus_rowa=x(2);
 Cus_rowb=x(3);
 Cch_us=x(4);
 Cch_rowa=x(5);
 Cch_rowb=x(6);
 Caa_us=x(7);
 Caa_ch=x(8);
 Caa_rowa=x(9);
 Caa_rowb=x(10);
 Cbb_us=x(11);
 Cbb_ch=x(12);
 Cbb_rowa=x(13);
 Cbb_rowb=x(14);
 Qusd=x(15);
 Qchy=x(16);
 Qrow=x(17);
 Pus_us=x(18);
 Pus_ch=x(19);
 Pus_rowb=x(20);
 Pus_rowa=x(21);
 Pch_ch=x(22);
 Pch_us=x(23);
 Pch_rowa=x(24);
 Pch_rowb=x(25);
 Paa_aa=x(26);
 Paa_ch=x(27);
 Paa_rowa=x(28);
 Paa_rowb=x(29);
 Paa_us=x(30);
 Pbb_bb=x(31);
 Pbb_us=x(32);
 Pbb_rowa=x(33);
 Pbb_rowb=x(34);
 Pbb_ch=x(35);
 m_us=x(36);
 m_ch=x(37);
 m_aa=x(38);
 m_bb=x(39);
 pim_us_ch_=x(40);
 pim_us_aa_=x(41);
 pim_us_bb_=x(42);
 pex_us_ch_=x(43);
 pex_us_aa_=x(44);
 pim_ch_us_=x(45);
 pim_ch_aa_=x(46);
 pim_ch_bb_=x(47);
 pex_ch_us_=x(48);
 pex_ch_bb_=x(49);
 pim_aa_us_=x(50);
 pim_aa_ch_=x(51);
 pim_aa_rowa_=x(52);
 pim_aa_rowb_=x(53);
 pex_aa_us_=x(54);
 pex_aa_ch_=x(55);
 pex_aa_rowa_=x(56);
 pim_bb_us_=x(57);
 pim_bb_ch_=x(58);
 pim_bb_rowa_=x(59);
 pim_bb_rowb_=x(60);
 pex_bb_us_=x(61);
 pex_bb_ch_=x(62);
 pex_bb_rowb_=x(63);
 sbar_aa=x(64);
 sbar_bb=x(65);
 Baa_usda=x(66);
 Bbb_usda=x(67);
 Baa_chya=x(68);
 Bbb_chya=x(69);
 Bus_usda=x(70);
 Bch_chya=x(71);
 Bus_rowa=x(72);
 Bch_rowa=x(73);
 Baa_rowa=x(74);


%Be sure it's xp and not x;
 Cus_ch_p=xp(1);
 Cus_rowa_p=xp(2);
 Cus_rowb_p=xp(3);
 Cch_us_p=xp(4);
 Cch_rowa_p=xp(5);
 Cch_rowb_p=xp(6);
 Caa_us_p=xp(7);
 Caa_ch_p=xp(8);
 Caa_rowa_p=xp(9);
 Caa_rowb_p=xp(10);
 Cbb_us_p=xp(11);
 Cbb_ch_p=xp(12);
 Cbb_rowa_p=xp(13);
 Cbb_rowb_p=xp(14);
 Qusd_p=xp(15);
 Qchy_p=xp(16);
 Qrow_p=xp(17);
 Pus_us_p=xp(18);
 Pus_ch_p=xp(19);
 Pus_rowb_p=xp(20);
 Pus_rowa_p=xp(21);
 Pch_ch_p=xp(22);
 Pch_us_p=xp(23);
 Pch_rowa_p=xp(24);
 Pch_rowb_p=xp(25);
 Paa_aa_p=xp(26);
 Paa_ch_p=xp(27);
 Paa_rowa_p=xp(28);
 Paa_rowb_p=xp(29);
 Paa_us_p=xp(30);
 Pbb_bb_p=xp(31);
 Pbb_us_p=xp(32);
 Pbb_rowa_p=xp(33);
 Pbb_rowb_p=xp(34);
 Pbb_ch_p=xp(35);
 m_us_p=xp(36);
 m_ch_p=xp(37);
 m_aa_p=xp(38);
 m_bb_p=xp(39);
 pim_us_ch__p=xp(40);
 pim_us_aa__p=xp(41);
 pim_us_bb__p=xp(42);
 pex_us_ch__p=xp(43);
 pex_us_aa__p=xp(44);
 pim_ch_us__p=xp(45);
 pim_ch_aa__p=xp(46);
 pim_ch_bb__p=xp(47);
 pex_ch_us__p=xp(48);
 pex_ch_bb__p=xp(49);
 pim_aa_us__p=xp(50);
 pim_aa_ch__p=xp(51);
 pim_aa_rowa__p=xp(52);
 pim_aa_rowb__p=xp(53);
 pex_aa_us__p=xp(54);
 pex_aa_ch__p=xp(55);
 pex_aa_rowa__p=xp(56);
 pim_bb_us__p=xp(57);
 pim_bb_ch__p=xp(58);
 pim_bb_rowa__p=xp(59);
 pim_bb_rowb__p=xp(60);
 pex_bb_us__p=xp(61);
 pex_bb_ch__p=xp(62);
 pex_bb_rowb__p=xp(63);
 sbar_aa_p=xp(64);
 sbar_bb_p=xp(65);
 Baa_usda_p=xp(66);
 Bbb_usda_p=xp(67);
 Baa_chya_p=xp(68);
 Bbb_chya_p=xp(69);
 Bus_usda_p=xp(70);
 Bch_chya_p=xp(71);
 Bus_rowa_p=xp(72);
 Bch_rowa_p=xp(73);
 Baa_rowa_p=xp(74);


%Be sure it's xp and not x;
 Baa_usda_l=xl(1);
 Bbb_usda_l=xl(2);
 Baa_chya_l=xl(3);
 Bbb_chya_l=xl(4);
 Bus_usda_l=xl(5);
 Bch_chya_l=xl(6);
 Bus_rowa_l=xl(7);
 Bch_rowa_l=xl(8);
 Baa_rowa_l=xl(9);


%Shell Residual
out =  walras(Cus_ch,Cus_rowa,Cus_rowb,Cch_us,Cch_rowa,Cch_rowb,Caa_us,Caa_ch,Caa_rowa,Caa_rowb,Cbb_us,Cbb_ch,Cbb_rowa,Cbb_rowb,Qusd,Qchy,Qrow,Pus_us,Pus_ch,Pus_rowb,Pus_rowa,Pch_ch,Pch_us,Pch_rowa,Pch_rowb,Paa_aa,Paa_ch,Paa_rowa,Paa_rowb,Paa_us,Pbb_bb,Pbb_us,Pbb_rowa,Pbb_rowb,Pbb_ch,m_us,m_ch,m_aa,m_bb,pim_us_ch_,pim_us_aa_,pim_us_bb_,pex_us_ch_,pex_us_aa_,pim_ch_us_,pim_ch_aa_,pim_ch_bb_,pex_ch_us_,pex_ch_bb_,pim_aa_us_,pim_aa_ch_,pim_aa_rowa_,pim_aa_rowb_,pex_aa_us_,pex_aa_ch_,pex_aa_rowa_,pim_bb_us_,pim_bb_ch_,pim_bb_rowa_,pim_bb_rowb_,pex_bb_us_,pex_bb_ch_,pex_bb_rowb_,sbar_aa,sbar_bb,Baa_usda,Bbb_usda,Baa_chya,Bbb_chya,Bus_usda,Bch_chya,Bus_rowa,Bch_rowa,Baa_rowa,Cus_ch_p,Cus_rowa_p,Cus_rowb_p,Cch_us_p,Cch_rowa_p,Cch_rowb_p,Caa_us_p,Caa_ch_p,Caa_rowa_p,Caa_rowb_p,Cbb_us_p,Cbb_ch_p,Cbb_rowa_p,Cbb_rowb_p,Qusd_p,Qchy_p,Qrow_p,Pus_us_p,Pus_ch_p,Pus_rowb_p,Pus_rowa_p,Pch_ch_p,Pch_us_p,Pch_rowa_p,Pch_rowb_p,Paa_aa_p,Paa_ch_p,Paa_rowa_p,Paa_rowb_p,Paa_us_p,Pbb_bb_p,Pbb_us_p,Pbb_rowa_p,Pbb_rowb_p,Pbb_ch_p,m_us_p,m_ch_p,m_aa_p,m_bb_p,pim_us_ch__p,pim_us_aa__p,pim_us_bb__p,pex_us_ch__p,pex_us_aa__p,pim_ch_us__p,pim_ch_aa__p,pim_ch_bb__p,pex_ch_us__p,pex_ch_bb__p,pim_aa_us__p,pim_aa_ch__p,pim_aa_rowa__p,pim_aa_rowb__p,pex_aa_us__p,pex_aa_ch__p,pex_aa_rowa__p,pim_bb_us__p,pim_bb_ch__p,pim_bb_rowa__p,pim_bb_rowb__p,pex_bb_us__p,pex_bb_ch__p,pex_bb_rowb__p,sbar_aa_p,sbar_bb_p,Baa_usda_p,Bbb_usda_p,Baa_chya_p,Bbb_chya_p,Bus_usda_p,Bch_chya_p,Bus_rowa_p,Bch_rowa_p,Baa_rowa_p,Baa_usda_l,Bbb_usda_l,Baa_chya_l,Bbb_chya_l,Bus_usda_l,Bch_chya_l,Bus_rowa_l,Bch_rowa_l,Baa_rowa_l,Busd,Bchy,Yus,Ych,Yaa,Ybb,mu_us,mu_ch,mu_aa,mu_bb,a_us,a_ch,a_aa,a_bb,BBbb_usd,zusd_aa,zusd_bb,zchy_aa,zchy_bb,tax_us_ch,tax_us_aa,tax_us_bb,tax_ch_us,tax_ch_aa,tax_ch_bb,tax_aa_us,tax_aa_ch,tax_aa_rowa,tax_aa_rowb,tax_bb_us,tax_bb_ch,tax_bb_rowa,tax_bb_rowb,etax_ch_us,etax_aa_us,etax_bb_us,etax_us_ch,etax_aa_ch,etax_bb_ch,etax_us_aa,etax_ch_aa,etax_bb_aa,etax_us_bb,etax_ch_bb,etax_aa_bb,xtax_ch_usd,xtax_aa_usd,xtax_bb_usd,xtax_us_chy,xtax_aa_chy,xtax_bb_chy,Busd_l,Bchy_l,Yus_l,Ych_l,Yaa_l,Ybb_l,mu_us_l,mu_ch_l,mu_aa_l,mu_bb_l,a_us_l,a_ch_l,a_aa_l,a_bb_l,BBbb_usd_l,zusd_aa_l,zusd_bb_l,zchy_aa_l,zchy_bb_l,tax_us_ch_l,tax_us_aa_l,tax_us_bb_l,tax_ch_us_l,tax_ch_aa_l,tax_ch_bb_l,tax_aa_us_l,tax_aa_ch_l,tax_aa_rowa_l,tax_aa_rowb_l,tax_bb_us_l,tax_bb_ch_l,tax_bb_rowa_l,tax_bb_rowb_l,etax_ch_us_l,etax_aa_us_l,etax_bb_us_l,etax_us_ch_l,etax_aa_ch_l,etax_bb_ch_l,etax_us_aa_l,etax_ch_aa_l,etax_bb_aa_l,etax_us_bb_l,etax_ch_bb_l,etax_aa_bb_l,xtax_ch_usd_l,xtax_aa_usd_l,xtax_bb_usd_l,xtax_us_chy_l,xtax_aa_chy_l,xtax_bb_chy_l,Busd_p,Bchy_p,Yus_p,Ych_p,Yaa_p,Ybb_p,mu_us_p,mu_ch_p,mu_aa_p,mu_bb_p,a_us_p,a_ch_p,a_aa_p,a_bb_p,BBbb_usd_p,zusd_aa_p,zusd_bb_p,zchy_aa_p,zchy_bb_p,tax_us_ch_p,tax_us_aa_p,tax_us_bb_p,tax_ch_us_p,tax_ch_aa_p,tax_ch_bb_p,tax_aa_us_p,tax_aa_ch_p,tax_aa_rowa_p,tax_aa_rowb_p,tax_bb_us_p,tax_bb_ch_p,tax_bb_rowa_p,tax_bb_rowb_p,etax_ch_us_p,etax_aa_us_p,etax_bb_us_p,etax_us_ch_p,etax_aa_ch_p,etax_bb_ch_p,etax_us_aa_p,etax_ch_aa_p,etax_bb_aa_p,etax_us_bb_p,etax_ch_bb_p,etax_aa_bb_p,xtax_ch_usd_p,xtax_aa_usd_p,xtax_bb_usd_p,xtax_us_chy_p,xtax_aa_chy_p,xtax_bb_chy_p,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_chg,phi_aag,phi_bbg,bet,sig,eta,Pnumer,Xus,Xch,zrow,upp_usd,upp_chy,sanc_usd_bb,sanc_usd_ch,chi,btau_ch_usd,btau_aa_usd,btau_bb_usd,btau_us_chy,btau_aa_chy,btau_bb_chy,per_p_year,fXaa,fXbb,fixx,Baa,Bbb);
     







