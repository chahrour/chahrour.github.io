

#include <math.h>
#include <mex.h>
#include <lapack.h>
#include <blas.h>
#include <stdlib.h>
#include <string.h>


/* Input Arguments */
#define Cus_ch_in	prhs[0]
#define Cus_rowa_in	prhs[1]
#define Cus_rowb_in	prhs[2]
#define Cch_us_in	prhs[3]
#define Cch_rowa_in	prhs[4]
#define Cch_rowb_in	prhs[5]
#define Caa_us_in	prhs[6]
#define Caa_ch_in	prhs[7]
#define Caa_rowa_in	prhs[8]
#define Caa_rowb_in	prhs[9]
#define Cbb_us_in	prhs[10]
#define Cbb_ch_in	prhs[11]
#define Cbb_rowa_in	prhs[12]
#define Cbb_rowb_in	prhs[13]
#define Qusd_in	prhs[14]
#define Qchy_in	prhs[15]
#define Qrow_in	prhs[16]
#define Pus_us_in	prhs[17]
#define Pus_ch_in	prhs[18]
#define Pus_rowb_in	prhs[19]
#define Pus_rowa_in	prhs[20]
#define Pch_ch_in	prhs[21]
#define Pch_us_in	prhs[22]
#define Pch_rowa_in	prhs[23]
#define Pch_rowb_in	prhs[24]
#define Paa_aa_in	prhs[25]
#define Paa_ch_in	prhs[26]
#define Paa_rowa_in	prhs[27]
#define Paa_rowb_in	prhs[28]
#define Paa_us_in	prhs[29]
#define Pbb_bb_in	prhs[30]
#define Pbb_us_in	prhs[31]
#define Pbb_rowa_in	prhs[32]
#define Pbb_rowb_in	prhs[33]
#define Pbb_ch_in	prhs[34]
#define m_us_in	prhs[35]
#define m_ch_in	prhs[36]
#define m_aa_in	prhs[37]
#define m_bb_in	prhs[38]
#define pim_us_ch__in	prhs[39]
#define pim_us_aa__in	prhs[40]
#define pim_us_bb__in	prhs[41]
#define pex_us_ch__in	prhs[42]
#define pex_us_aa__in	prhs[43]
#define pim_ch_us__in	prhs[44]
#define pim_ch_aa__in	prhs[45]
#define pim_ch_bb__in	prhs[46]
#define pex_ch_us__in	prhs[47]
#define pex_ch_bb__in	prhs[48]
#define pim_aa_us__in	prhs[49]
#define pim_aa_ch__in	prhs[50]
#define pim_aa_rowa__in	prhs[51]
#define pim_aa_rowb__in	prhs[52]
#define pex_aa_us__in	prhs[53]
#define pex_aa_ch__in	prhs[54]
#define pex_aa_rowa__in	prhs[55]
#define pim_bb_us__in	prhs[56]
#define pim_bb_ch__in	prhs[57]
#define pim_bb_rowa__in	prhs[58]
#define pim_bb_rowb__in	prhs[59]
#define pex_bb_us__in	prhs[60]
#define pex_bb_ch__in	prhs[61]
#define pex_bb_rowb__in	prhs[62]
#define sbar_aa_in	prhs[63]
#define sbar_bb_in	prhs[64]
#define Baa_usda_in	prhs[65]
#define Bbb_usda_in	prhs[66]
#define Baa_chya_in	prhs[67]
#define Bbb_chya_in	prhs[68]
#define Bus_usda_in	prhs[69]
#define Bch_chya_in	prhs[70]
#define Bus_rowa_in	prhs[71]
#define Bch_rowa_in	prhs[72]
#define Baa_rowa_in	prhs[73]
#define Cus_ch_p_in	prhs[74]
#define Cus_rowa_p_in	prhs[75]
#define Cus_rowb_p_in	prhs[76]
#define Cch_us_p_in	prhs[77]
#define Cch_rowa_p_in	prhs[78]
#define Cch_rowb_p_in	prhs[79]
#define Caa_us_p_in	prhs[80]
#define Caa_ch_p_in	prhs[81]
#define Caa_rowa_p_in	prhs[82]
#define Caa_rowb_p_in	prhs[83]
#define Cbb_us_p_in	prhs[84]
#define Cbb_ch_p_in	prhs[85]
#define Cbb_rowa_p_in	prhs[86]
#define Cbb_rowb_p_in	prhs[87]
#define Qusd_p_in	prhs[88]
#define Qchy_p_in	prhs[89]
#define Qrow_p_in	prhs[90]
#define Pus_us_p_in	prhs[91]
#define Pus_ch_p_in	prhs[92]
#define Pus_rowb_p_in	prhs[93]
#define Pus_rowa_p_in	prhs[94]
#define Pch_ch_p_in	prhs[95]
#define Pch_us_p_in	prhs[96]
#define Pch_rowa_p_in	prhs[97]
#define Pch_rowb_p_in	prhs[98]
#define Paa_aa_p_in	prhs[99]
#define Paa_ch_p_in	prhs[100]
#define Paa_rowa_p_in	prhs[101]
#define Paa_rowb_p_in	prhs[102]
#define Paa_us_p_in	prhs[103]
#define Pbb_bb_p_in	prhs[104]
#define Pbb_us_p_in	prhs[105]
#define Pbb_rowa_p_in	prhs[106]
#define Pbb_rowb_p_in	prhs[107]
#define Pbb_ch_p_in	prhs[108]
#define m_us_p_in	prhs[109]
#define m_ch_p_in	prhs[110]
#define m_aa_p_in	prhs[111]
#define m_bb_p_in	prhs[112]
#define pim_us_ch__p_in	prhs[113]
#define pim_us_aa__p_in	prhs[114]
#define pim_us_bb__p_in	prhs[115]
#define pex_us_ch__p_in	prhs[116]
#define pex_us_aa__p_in	prhs[117]
#define pim_ch_us__p_in	prhs[118]
#define pim_ch_aa__p_in	prhs[119]
#define pim_ch_bb__p_in	prhs[120]
#define pex_ch_us__p_in	prhs[121]
#define pex_ch_bb__p_in	prhs[122]
#define pim_aa_us__p_in	prhs[123]
#define pim_aa_ch__p_in	prhs[124]
#define pim_aa_rowa__p_in	prhs[125]
#define pim_aa_rowb__p_in	prhs[126]
#define pex_aa_us__p_in	prhs[127]
#define pex_aa_ch__p_in	prhs[128]
#define pex_aa_rowa__p_in	prhs[129]
#define pim_bb_us__p_in	prhs[130]
#define pim_bb_ch__p_in	prhs[131]
#define pim_bb_rowa__p_in	prhs[132]
#define pim_bb_rowb__p_in	prhs[133]
#define pex_bb_us__p_in	prhs[134]
#define pex_bb_ch__p_in	prhs[135]
#define pex_bb_rowb__p_in	prhs[136]
#define sbar_aa_p_in	prhs[137]
#define sbar_bb_p_in	prhs[138]
#define Baa_usda_p_in	prhs[139]
#define Bbb_usda_p_in	prhs[140]
#define Baa_chya_p_in	prhs[141]
#define Bbb_chya_p_in	prhs[142]
#define Bus_usda_p_in	prhs[143]
#define Bch_chya_p_in	prhs[144]
#define Bus_rowa_p_in	prhs[145]
#define Bch_rowa_p_in	prhs[146]
#define Baa_rowa_p_in	prhs[147]
#define Baa_usda_l_in	prhs[148]
#define Bbb_usda_l_in	prhs[149]
#define Baa_chya_l_in	prhs[150]
#define Bbb_chya_l_in	prhs[151]
#define Bus_usda_l_in	prhs[152]
#define Bch_chya_l_in	prhs[153]
#define Bus_rowa_l_in	prhs[154]
#define Bch_rowa_l_in	prhs[155]
#define Baa_rowa_l_in	prhs[156]
#define Busd_in	prhs[157]
#define Bchy_in	prhs[158]
#define Yus_in	prhs[159]
#define Ych_in	prhs[160]
#define Yaa_in	prhs[161]
#define Ybb_in	prhs[162]
#define mu_us_in	prhs[163]
#define mu_ch_in	prhs[164]
#define mu_aa_in	prhs[165]
#define mu_bb_in	prhs[166]
#define a_us_in	prhs[167]
#define a_ch_in	prhs[168]
#define a_aa_in	prhs[169]
#define a_bb_in	prhs[170]
#define BBbb_usd_in	prhs[171]
#define zusd_aa_in	prhs[172]
#define zusd_bb_in	prhs[173]
#define zchy_aa_in	prhs[174]
#define zchy_bb_in	prhs[175]
#define tax_us_ch_in	prhs[176]
#define tax_us_aa_in	prhs[177]
#define tax_us_bb_in	prhs[178]
#define tax_ch_us_in	prhs[179]
#define tax_ch_aa_in	prhs[180]
#define tax_ch_bb_in	prhs[181]
#define tax_aa_us_in	prhs[182]
#define tax_aa_ch_in	prhs[183]
#define tax_aa_rowa_in	prhs[184]
#define tax_aa_rowb_in	prhs[185]
#define tax_bb_us_in	prhs[186]
#define tax_bb_ch_in	prhs[187]
#define tax_bb_rowa_in	prhs[188]
#define tax_bb_rowb_in	prhs[189]
#define etax_ch_us_in	prhs[190]
#define etax_aa_us_in	prhs[191]
#define etax_bb_us_in	prhs[192]
#define etax_us_ch_in	prhs[193]
#define etax_aa_ch_in	prhs[194]
#define etax_bb_ch_in	prhs[195]
#define etax_us_aa_in	prhs[196]
#define etax_ch_aa_in	prhs[197]
#define etax_bb_aa_in	prhs[198]
#define etax_us_bb_in	prhs[199]
#define etax_ch_bb_in	prhs[200]
#define etax_aa_bb_in	prhs[201]
#define xtax_ch_usd_in	prhs[202]
#define xtax_aa_usd_in	prhs[203]
#define xtax_bb_usd_in	prhs[204]
#define xtax_us_chy_in	prhs[205]
#define xtax_aa_chy_in	prhs[206]
#define xtax_bb_chy_in	prhs[207]
#define Busd_l_in	prhs[208]
#define Bchy_l_in	prhs[209]
#define Yus_l_in	prhs[210]
#define Ych_l_in	prhs[211]
#define Yaa_l_in	prhs[212]
#define Ybb_l_in	prhs[213]
#define mu_us_l_in	prhs[214]
#define mu_ch_l_in	prhs[215]
#define mu_aa_l_in	prhs[216]
#define mu_bb_l_in	prhs[217]
#define a_us_l_in	prhs[218]
#define a_ch_l_in	prhs[219]
#define a_aa_l_in	prhs[220]
#define a_bb_l_in	prhs[221]
#define BBbb_usd_l_in	prhs[222]
#define zusd_aa_l_in	prhs[223]
#define zusd_bb_l_in	prhs[224]
#define zchy_aa_l_in	prhs[225]
#define zchy_bb_l_in	prhs[226]
#define tax_us_ch_l_in	prhs[227]
#define tax_us_aa_l_in	prhs[228]
#define tax_us_bb_l_in	prhs[229]
#define tax_ch_us_l_in	prhs[230]
#define tax_ch_aa_l_in	prhs[231]
#define tax_ch_bb_l_in	prhs[232]
#define tax_aa_us_l_in	prhs[233]
#define tax_aa_ch_l_in	prhs[234]
#define tax_aa_rowa_l_in	prhs[235]
#define tax_aa_rowb_l_in	prhs[236]
#define tax_bb_us_l_in	prhs[237]
#define tax_bb_ch_l_in	prhs[238]
#define tax_bb_rowa_l_in	prhs[239]
#define tax_bb_rowb_l_in	prhs[240]
#define etax_ch_us_l_in	prhs[241]
#define etax_aa_us_l_in	prhs[242]
#define etax_bb_us_l_in	prhs[243]
#define etax_us_ch_l_in	prhs[244]
#define etax_aa_ch_l_in	prhs[245]
#define etax_bb_ch_l_in	prhs[246]
#define etax_us_aa_l_in	prhs[247]
#define etax_ch_aa_l_in	prhs[248]
#define etax_bb_aa_l_in	prhs[249]
#define etax_us_bb_l_in	prhs[250]
#define etax_ch_bb_l_in	prhs[251]
#define etax_aa_bb_l_in	prhs[252]
#define xtax_ch_usd_l_in	prhs[253]
#define xtax_aa_usd_l_in	prhs[254]
#define xtax_bb_usd_l_in	prhs[255]
#define xtax_us_chy_l_in	prhs[256]
#define xtax_aa_chy_l_in	prhs[257]
#define xtax_bb_chy_l_in	prhs[258]
#define Busd_p_in	prhs[259]
#define Bchy_p_in	prhs[260]
#define Yus_p_in	prhs[261]
#define Ych_p_in	prhs[262]
#define Yaa_p_in	prhs[263]
#define Ybb_p_in	prhs[264]
#define mu_us_p_in	prhs[265]
#define mu_ch_p_in	prhs[266]
#define mu_aa_p_in	prhs[267]
#define mu_bb_p_in	prhs[268]
#define a_us_p_in	prhs[269]
#define a_ch_p_in	prhs[270]
#define a_aa_p_in	prhs[271]
#define a_bb_p_in	prhs[272]
#define BBbb_usd_p_in	prhs[273]
#define zusd_aa_p_in	prhs[274]
#define zusd_bb_p_in	prhs[275]
#define zchy_aa_p_in	prhs[276]
#define zchy_bb_p_in	prhs[277]
#define tax_us_ch_p_in	prhs[278]
#define tax_us_aa_p_in	prhs[279]
#define tax_us_bb_p_in	prhs[280]
#define tax_ch_us_p_in	prhs[281]
#define tax_ch_aa_p_in	prhs[282]
#define tax_ch_bb_p_in	prhs[283]
#define tax_aa_us_p_in	prhs[284]
#define tax_aa_ch_p_in	prhs[285]
#define tax_aa_rowa_p_in	prhs[286]
#define tax_aa_rowb_p_in	prhs[287]
#define tax_bb_us_p_in	prhs[288]
#define tax_bb_ch_p_in	prhs[289]
#define tax_bb_rowa_p_in	prhs[290]
#define tax_bb_rowb_p_in	prhs[291]
#define etax_ch_us_p_in	prhs[292]
#define etax_aa_us_p_in	prhs[293]
#define etax_bb_us_p_in	prhs[294]
#define etax_us_ch_p_in	prhs[295]
#define etax_aa_ch_p_in	prhs[296]
#define etax_bb_ch_p_in	prhs[297]
#define etax_us_aa_p_in	prhs[298]
#define etax_ch_aa_p_in	prhs[299]
#define etax_bb_aa_p_in	prhs[300]
#define etax_us_bb_p_in	prhs[301]
#define etax_ch_bb_p_in	prhs[302]
#define etax_aa_bb_p_in	prhs[303]
#define xtax_ch_usd_p_in	prhs[304]
#define xtax_aa_usd_p_in	prhs[305]
#define xtax_bb_usd_p_in	prhs[306]
#define xtax_us_chy_p_in	prhs[307]
#define xtax_aa_chy_p_in	prhs[308]
#define xtax_bb_chy_p_in	prhs[309]
#define tau_in	prhs[310]
#define taup_in	prhs[311]
#define alph_in	prhs[312]
#define vepsf_in	prhs[313]
#define vepst_in	prhs[314]
#define kap_in	prhs[315]
#define phi_in	prhs[316]
#define r_in	prhs[317]
#define sige_in	prhs[318]
#define phi_usg_in	prhs[319]
#define phi_chg_in	prhs[320]
#define phi_aag_in	prhs[321]
#define phi_bbg_in	prhs[322]
#define bet_in	prhs[323]
#define sig_in	prhs[324]
#define eta_in	prhs[325]
#define Pnumer_in	prhs[326]
#define Xus_in	prhs[327]
#define Xch_in	prhs[328]
#define zrow_in	prhs[329]
#define upp_usd_in	prhs[330]
#define upp_chy_in	prhs[331]
#define sanc_usd_bb_in	prhs[332]
#define sanc_usd_ch_in	prhs[333]
#define chi_in	prhs[334]
#define btau_ch_usd_in	prhs[335]
#define btau_aa_usd_in	prhs[336]
#define btau_bb_usd_in	prhs[337]
#define btau_us_chy_in	prhs[338]
#define btau_aa_chy_in	prhs[339]
#define btau_bb_chy_in	prhs[340]
#define per_p_year_in	prhs[341]
#define fXaa_in	prhs[342]
#define fXbb_in	prhs[343]
#define fixx_in	prhs[344]
#define Baa_in	prhs[345]
#define Bbb_in	prhs[346]


/* Output Arguments */
#define out plhs[0]


#if !defined(MAX)
#define	MAX(A, B)	((A) > (B) ? (A) : (B))
#endif

#if !defined(MIN)
#define	MIN(A, B)	((A) < (B) ? (A) : (B))
#endif

#define pi  3.141592653589793
        
/* Prints an MxN matrix to Screen*/
void printmat_rowmaj(int m, int n, double M[m*n]){
    int x,y,k;
        k = 0;
    printf("\n");
    for(x=0;x<m;x++){
        for(y=0;y<n;y++){
            printf("%1.11lf\t", M[k]);
            k++;
        }
        printf("%\n");
    }
    return;
}


void mexFunction( int nlhs, mxArray *plhs[], int nrhs, const mxArray*prhs[] )

{
     /*Values in Loops*/
    double C,H,D_p,K_p,MU,E1,E2,E3,D,K,HL,LAML,GAMtildeL,GAM,A,RW,MUtmp;
    
    double *OUT;
    
    /*variables needed to declare*/
    double Cus ,Cch ,Caa ,Cbb ,Cus_us ,Cch_ch ,Caa_aa ,Cbb_bb ,Pus ,Pch ,Paa ,Pbb ,Bch_usd ,Bus_chy ,Bbb_row ,p_aa_chy ,p_aa_usd ,p_bb_chy ,p_bb_usd ,p_ch_chy ,p_ch_usd ,p_us_chy ,p_us_usd ,ph_aa_chy ,ph_aa_row ,ph_aa_usd ,ph_bb_chy ,ph_bb_row ,ph_bb_usd ,ph_ch_chy ,ph_ch_row ,ph_ch_usd ,ph_us_chy ,ph_us_row ,ph_us_usd ,m_us_til ,m_ch_til ,m_aa_til ,m_bb_til ,pim_us_ch ,pim_us_aa ,pim_us_bb ,pex_us_ch ,pex_us_aa ,pex_us_bb ,pim_ch_us ,pim_ch_aa ,pim_ch_bb ,pex_ch_us ,pex_ch_aa ,pex_ch_bb ,pim_aa_us ,pim_aa_ch ,pim_aa_aa ,pim_aa_bb ,pex_aa_us ,pex_aa_ch ,pex_aa_aa ,pex_aa_bb ,pim_bb_us ,pim_bb_ch ,pim_bb_aa ,pim_bb_bb ,pex_bb_us ,pex_bb_ch ,pex_bb_aa ,pex_bb_bb ;

     double Cus_ch,Cus_rowa,Cus_rowb,Cch_us,Cch_rowa,Cch_rowb,Caa_us,Caa_ch,Caa_rowa,Caa_rowb,Cbb_us,Cbb_ch,Cbb_rowa,Cbb_rowb,Qusd,Qchy,Qrow,Pus_us,Pus_ch,Pus_rowb,Pus_rowa,Pch_ch,Pch_us,Pch_rowa,Pch_rowb,Paa_aa,Paa_ch,Paa_rowa,Paa_rowb,Paa_us,Pbb_bb,Pbb_us,Pbb_rowa,Pbb_rowb,Pbb_ch,m_us,m_ch,m_aa,m_bb,pim_us_ch_,pim_us_aa_,pim_us_bb_,pex_us_ch_,pex_us_aa_,pim_ch_us_,pim_ch_aa_,pim_ch_bb_,pex_ch_us_,pex_ch_bb_,pim_aa_us_,pim_aa_ch_,pim_aa_rowa_,pim_aa_rowb_,pex_aa_us_,pex_aa_ch_,pex_aa_rowa_,pim_bb_us_,pim_bb_ch_,pim_bb_rowa_,pim_bb_rowb_,pex_bb_us_,pex_bb_ch_,pex_bb_rowb_,sbar_aa,sbar_bb,Baa_usda,Bbb_usda,Baa_chya,Bbb_chya,Bus_usda,Bch_chya,Bus_rowa,Bch_rowa,Baa_rowa,Cus_ch_p,Cus_rowa_p,Cus_rowb_p,Cch_us_p,Cch_rowa_p,Cch_rowb_p,Caa_us_p,Caa_ch_p,Caa_rowa_p,Caa_rowb_p,Cbb_us_p,Cbb_ch_p,Cbb_rowa_p,Cbb_rowb_p,Qusd_p,Qchy_p,Qrow_p,Pus_us_p,Pus_ch_p,Pus_rowb_p,Pus_rowa_p,Pch_ch_p,Pch_us_p,Pch_rowa_p,Pch_rowb_p,Paa_aa_p,Paa_ch_p,Paa_rowa_p,Paa_rowb_p,Paa_us_p,Pbb_bb_p,Pbb_us_p,Pbb_rowa_p,Pbb_rowb_p,Pbb_ch_p,m_us_p,m_ch_p,m_aa_p,m_bb_p,pim_us_ch__p,pim_us_aa__p,pim_us_bb__p,pex_us_ch__p,pex_us_aa__p,pim_ch_us__p,pim_ch_aa__p,pim_ch_bb__p,pex_ch_us__p,pex_ch_bb__p,pim_aa_us__p,pim_aa_ch__p,pim_aa_rowa__p,pim_aa_rowb__p,pex_aa_us__p,pex_aa_ch__p,pex_aa_rowa__p,pim_bb_us__p,pim_bb_ch__p,pim_bb_rowa__p,pim_bb_rowb__p,pex_bb_us__p,pex_bb_ch__p,pex_bb_rowb__p,sbar_aa_p,sbar_bb_p,Baa_usda_p,Bbb_usda_p,Baa_chya_p,Bbb_chya_p,Bus_usda_p,Bch_chya_p,Bus_rowa_p,Bch_rowa_p,Baa_rowa_p,Baa_usda_l,Bbb_usda_l,Baa_chya_l,Bbb_chya_l,Bus_usda_l,Bch_chya_l,Bus_rowa_l,Bch_rowa_l,Baa_rowa_l,Busd,Bchy,Yus,Ych,Yaa,Ybb,mu_us,mu_ch,mu_aa,mu_bb,a_us,a_ch,a_aa,a_bb,BBbb_usd,zusd_aa,zusd_bb,zchy_aa,zchy_bb,tax_us_ch,tax_us_aa,tax_us_bb,tax_ch_us,tax_ch_aa,tax_ch_bb,tax_aa_us,tax_aa_ch,tax_aa_rowa,tax_aa_rowb,tax_bb_us,tax_bb_ch,tax_bb_rowa,tax_bb_rowb,etax_ch_us,etax_aa_us,etax_bb_us,etax_us_ch,etax_aa_ch,etax_bb_ch,etax_us_aa,etax_ch_aa,etax_bb_aa,etax_us_bb,etax_ch_bb,etax_aa_bb,xtax_ch_usd,xtax_aa_usd,xtax_bb_usd,xtax_us_chy,xtax_aa_chy,xtax_bb_chy,Busd_l,Bchy_l,Yus_l,Ych_l,Yaa_l,Ybb_l,mu_us_l,mu_ch_l,mu_aa_l,mu_bb_l,a_us_l,a_ch_l,a_aa_l,a_bb_l,BBbb_usd_l,zusd_aa_l,zusd_bb_l,zchy_aa_l,zchy_bb_l,tax_us_ch_l,tax_us_aa_l,tax_us_bb_l,tax_ch_us_l,tax_ch_aa_l,tax_ch_bb_l,tax_aa_us_l,tax_aa_ch_l,tax_aa_rowa_l,tax_aa_rowb_l,tax_bb_us_l,tax_bb_ch_l,tax_bb_rowa_l,tax_bb_rowb_l,etax_ch_us_l,etax_aa_us_l,etax_bb_us_l,etax_us_ch_l,etax_aa_ch_l,etax_bb_ch_l,etax_us_aa_l,etax_ch_aa_l,etax_bb_aa_l,etax_us_bb_l,etax_ch_bb_l,etax_aa_bb_l,xtax_ch_usd_l,xtax_aa_usd_l,xtax_bb_usd_l,xtax_us_chy_l,xtax_aa_chy_l,xtax_bb_chy_l,Busd_p,Bchy_p,Yus_p,Ych_p,Yaa_p,Ybb_p,mu_us_p,mu_ch_p,mu_aa_p,mu_bb_p,a_us_p,a_ch_p,a_aa_p,a_bb_p,BBbb_usd_p,zusd_aa_p,zusd_bb_p,zchy_aa_p,zchy_bb_p,tax_us_ch_p,tax_us_aa_p,tax_us_bb_p,tax_ch_us_p,tax_ch_aa_p,tax_ch_bb_p,tax_aa_us_p,tax_aa_ch_p,tax_aa_rowa_p,tax_aa_rowb_p,tax_bb_us_p,tax_bb_ch_p,tax_bb_rowa_p,tax_bb_rowb_p,etax_ch_us_p,etax_aa_us_p,etax_bb_us_p,etax_us_ch_p,etax_aa_ch_p,etax_bb_ch_p,etax_us_aa_p,etax_ch_aa_p,etax_bb_aa_p,etax_us_bb_p,etax_ch_bb_p,etax_aa_bb_p,xtax_ch_usd_p,xtax_aa_usd_p,xtax_bb_usd_p,xtax_us_chy_p,xtax_aa_chy_p,xtax_bb_chy_p,tau,taup,alph,vepsf,vepst,kap,phi,r,sige,phi_usg,phi_chg,phi_aag,phi_bbg,bet,sig,eta,Pnumer,Xus,Xch,zrow,upp_usd,upp_chy,sanc_usd_bb,sanc_usd_ch,chi,btau_ch_usd,btau_aa_usd,btau_bb_usd,btau_us_chy,btau_aa_chy,btau_bb_chy,per_p_year,fXaa,fXbb,fixx,Baa,Bbb;

            
    /*Results*/
    double rsum=1;
    
    /*Create output argument*/
    out = mxCreateDoubleMatrix(74,9,mxREAL);

    OUT = mxGetPr(out);
    
    
    /*Counters*/
    long ns, ii,tt;
    
    /*BLAS working memory*/
    ptrdiff_t one = 1;
    ptrdiff_t info = 0;
    long IPIV[4] = {0,1,2,3};

    
    /*Check for proper number of arguments*/
    if (nrhs == 347)  {} else{mexErrMsgTxt(" 347 inputs arguments required.");}

    
    /* Get Dimensions of Input Arguments*/
    ptrdiff_t four  = 4;
    ptrdiff_t three = 3;
         
    /*Parameters intialized*/
    Cus_ch= *mxGetPr(Cus_ch_in);
Cus_rowa= *mxGetPr(Cus_rowa_in);
Cus_rowb= *mxGetPr(Cus_rowb_in);
Cch_us= *mxGetPr(Cch_us_in);
Cch_rowa= *mxGetPr(Cch_rowa_in);
Cch_rowb= *mxGetPr(Cch_rowb_in);
Caa_us= *mxGetPr(Caa_us_in);
Caa_ch= *mxGetPr(Caa_ch_in);
Caa_rowa= *mxGetPr(Caa_rowa_in);
Caa_rowb= *mxGetPr(Caa_rowb_in);
Cbb_us= *mxGetPr(Cbb_us_in);
Cbb_ch= *mxGetPr(Cbb_ch_in);
Cbb_rowa= *mxGetPr(Cbb_rowa_in);
Cbb_rowb= *mxGetPr(Cbb_rowb_in);
Qusd= *mxGetPr(Qusd_in);
Qchy= *mxGetPr(Qchy_in);
Qrow= *mxGetPr(Qrow_in);
Pus_us= *mxGetPr(Pus_us_in);
Pus_ch= *mxGetPr(Pus_ch_in);
Pus_rowb= *mxGetPr(Pus_rowb_in);
Pus_rowa= *mxGetPr(Pus_rowa_in);
Pch_ch= *mxGetPr(Pch_ch_in);
Pch_us= *mxGetPr(Pch_us_in);
Pch_rowa= *mxGetPr(Pch_rowa_in);
Pch_rowb= *mxGetPr(Pch_rowb_in);
Paa_aa= *mxGetPr(Paa_aa_in);
Paa_ch= *mxGetPr(Paa_ch_in);
Paa_rowa= *mxGetPr(Paa_rowa_in);
Paa_rowb= *mxGetPr(Paa_rowb_in);
Paa_us= *mxGetPr(Paa_us_in);
Pbb_bb= *mxGetPr(Pbb_bb_in);
Pbb_us= *mxGetPr(Pbb_us_in);
Pbb_rowa= *mxGetPr(Pbb_rowa_in);
Pbb_rowb= *mxGetPr(Pbb_rowb_in);
Pbb_ch= *mxGetPr(Pbb_ch_in);
m_us= *mxGetPr(m_us_in);
m_ch= *mxGetPr(m_ch_in);
m_aa= *mxGetPr(m_aa_in);
m_bb= *mxGetPr(m_bb_in);
pim_us_ch_= *mxGetPr(pim_us_ch__in);
pim_us_aa_= *mxGetPr(pim_us_aa__in);
pim_us_bb_= *mxGetPr(pim_us_bb__in);
pex_us_ch_= *mxGetPr(pex_us_ch__in);
pex_us_aa_= *mxGetPr(pex_us_aa__in);
pim_ch_us_= *mxGetPr(pim_ch_us__in);
pim_ch_aa_= *mxGetPr(pim_ch_aa__in);
pim_ch_bb_= *mxGetPr(pim_ch_bb__in);
pex_ch_us_= *mxGetPr(pex_ch_us__in);
pex_ch_bb_= *mxGetPr(pex_ch_bb__in);
pim_aa_us_= *mxGetPr(pim_aa_us__in);
pim_aa_ch_= *mxGetPr(pim_aa_ch__in);
pim_aa_rowa_= *mxGetPr(pim_aa_rowa__in);
pim_aa_rowb_= *mxGetPr(pim_aa_rowb__in);
pex_aa_us_= *mxGetPr(pex_aa_us__in);
pex_aa_ch_= *mxGetPr(pex_aa_ch__in);
pex_aa_rowa_= *mxGetPr(pex_aa_rowa__in);
pim_bb_us_= *mxGetPr(pim_bb_us__in);
pim_bb_ch_= *mxGetPr(pim_bb_ch__in);
pim_bb_rowa_= *mxGetPr(pim_bb_rowa__in);
pim_bb_rowb_= *mxGetPr(pim_bb_rowb__in);
pex_bb_us_= *mxGetPr(pex_bb_us__in);
pex_bb_ch_= *mxGetPr(pex_bb_ch__in);
pex_bb_rowb_= *mxGetPr(pex_bb_rowb__in);
sbar_aa= *mxGetPr(sbar_aa_in);
sbar_bb= *mxGetPr(sbar_bb_in);
Baa_usda= *mxGetPr(Baa_usda_in);
Bbb_usda= *mxGetPr(Bbb_usda_in);
Baa_chya= *mxGetPr(Baa_chya_in);
Bbb_chya= *mxGetPr(Bbb_chya_in);
Bus_usda= *mxGetPr(Bus_usda_in);
Bch_chya= *mxGetPr(Bch_chya_in);
Bus_rowa= *mxGetPr(Bus_rowa_in);
Bch_rowa= *mxGetPr(Bch_rowa_in);
Baa_rowa= *mxGetPr(Baa_rowa_in);
Cus_ch_p= *mxGetPr(Cus_ch_p_in);
Cus_rowa_p= *mxGetPr(Cus_rowa_p_in);
Cus_rowb_p= *mxGetPr(Cus_rowb_p_in);
Cch_us_p= *mxGetPr(Cch_us_p_in);
Cch_rowa_p= *mxGetPr(Cch_rowa_p_in);
Cch_rowb_p= *mxGetPr(Cch_rowb_p_in);
Caa_us_p= *mxGetPr(Caa_us_p_in);
Caa_ch_p= *mxGetPr(Caa_ch_p_in);
Caa_rowa_p= *mxGetPr(Caa_rowa_p_in);
Caa_rowb_p= *mxGetPr(Caa_rowb_p_in);
Cbb_us_p= *mxGetPr(Cbb_us_p_in);
Cbb_ch_p= *mxGetPr(Cbb_ch_p_in);
Cbb_rowa_p= *mxGetPr(Cbb_rowa_p_in);
Cbb_rowb_p= *mxGetPr(Cbb_rowb_p_in);
Qusd_p= *mxGetPr(Qusd_p_in);
Qchy_p= *mxGetPr(Qchy_p_in);
Qrow_p= *mxGetPr(Qrow_p_in);
Pus_us_p= *mxGetPr(Pus_us_p_in);
Pus_ch_p= *mxGetPr(Pus_ch_p_in);
Pus_rowb_p= *mxGetPr(Pus_rowb_p_in);
Pus_rowa_p= *mxGetPr(Pus_rowa_p_in);
Pch_ch_p= *mxGetPr(Pch_ch_p_in);
Pch_us_p= *mxGetPr(Pch_us_p_in);
Pch_rowa_p= *mxGetPr(Pch_rowa_p_in);
Pch_rowb_p= *mxGetPr(Pch_rowb_p_in);
Paa_aa_p= *mxGetPr(Paa_aa_p_in);
Paa_ch_p= *mxGetPr(Paa_ch_p_in);
Paa_rowa_p= *mxGetPr(Paa_rowa_p_in);
Paa_rowb_p= *mxGetPr(Paa_rowb_p_in);
Paa_us_p= *mxGetPr(Paa_us_p_in);
Pbb_bb_p= *mxGetPr(Pbb_bb_p_in);
Pbb_us_p= *mxGetPr(Pbb_us_p_in);
Pbb_rowa_p= *mxGetPr(Pbb_rowa_p_in);
Pbb_rowb_p= *mxGetPr(Pbb_rowb_p_in);
Pbb_ch_p= *mxGetPr(Pbb_ch_p_in);
m_us_p= *mxGetPr(m_us_p_in);
m_ch_p= *mxGetPr(m_ch_p_in);
m_aa_p= *mxGetPr(m_aa_p_in);
m_bb_p= *mxGetPr(m_bb_p_in);
pim_us_ch__p= *mxGetPr(pim_us_ch__p_in);
pim_us_aa__p= *mxGetPr(pim_us_aa__p_in);
pim_us_bb__p= *mxGetPr(pim_us_bb__p_in);
pex_us_ch__p= *mxGetPr(pex_us_ch__p_in);
pex_us_aa__p= *mxGetPr(pex_us_aa__p_in);
pim_ch_us__p= *mxGetPr(pim_ch_us__p_in);
pim_ch_aa__p= *mxGetPr(pim_ch_aa__p_in);
pim_ch_bb__p= *mxGetPr(pim_ch_bb__p_in);
pex_ch_us__p= *mxGetPr(pex_ch_us__p_in);
pex_ch_bb__p= *mxGetPr(pex_ch_bb__p_in);
pim_aa_us__p= *mxGetPr(pim_aa_us__p_in);
pim_aa_ch__p= *mxGetPr(pim_aa_ch__p_in);
pim_aa_rowa__p= *mxGetPr(pim_aa_rowa__p_in);
pim_aa_rowb__p= *mxGetPr(pim_aa_rowb__p_in);
pex_aa_us__p= *mxGetPr(pex_aa_us__p_in);
pex_aa_ch__p= *mxGetPr(pex_aa_ch__p_in);
pex_aa_rowa__p= *mxGetPr(pex_aa_rowa__p_in);
pim_bb_us__p= *mxGetPr(pim_bb_us__p_in);
pim_bb_ch__p= *mxGetPr(pim_bb_ch__p_in);
pim_bb_rowa__p= *mxGetPr(pim_bb_rowa__p_in);
pim_bb_rowb__p= *mxGetPr(pim_bb_rowb__p_in);
pex_bb_us__p= *mxGetPr(pex_bb_us__p_in);
pex_bb_ch__p= *mxGetPr(pex_bb_ch__p_in);
pex_bb_rowb__p= *mxGetPr(pex_bb_rowb__p_in);
sbar_aa_p= *mxGetPr(sbar_aa_p_in);
sbar_bb_p= *mxGetPr(sbar_bb_p_in);
Baa_usda_p= *mxGetPr(Baa_usda_p_in);
Bbb_usda_p= *mxGetPr(Bbb_usda_p_in);
Baa_chya_p= *mxGetPr(Baa_chya_p_in);
Bbb_chya_p= *mxGetPr(Bbb_chya_p_in);
Bus_usda_p= *mxGetPr(Bus_usda_p_in);
Bch_chya_p= *mxGetPr(Bch_chya_p_in);
Bus_rowa_p= *mxGetPr(Bus_rowa_p_in);
Bch_rowa_p= *mxGetPr(Bch_rowa_p_in);
Baa_rowa_p= *mxGetPr(Baa_rowa_p_in);
Baa_usda_l= *mxGetPr(Baa_usda_l_in);
Bbb_usda_l= *mxGetPr(Bbb_usda_l_in);
Baa_chya_l= *mxGetPr(Baa_chya_l_in);
Bbb_chya_l= *mxGetPr(Bbb_chya_l_in);
Bus_usda_l= *mxGetPr(Bus_usda_l_in);
Bch_chya_l= *mxGetPr(Bch_chya_l_in);
Bus_rowa_l= *mxGetPr(Bus_rowa_l_in);
Bch_rowa_l= *mxGetPr(Bch_rowa_l_in);
Baa_rowa_l= *mxGetPr(Baa_rowa_l_in);
Busd= *mxGetPr(Busd_in);
Bchy= *mxGetPr(Bchy_in);
Yus= *mxGetPr(Yus_in);
Ych= *mxGetPr(Ych_in);
Yaa= *mxGetPr(Yaa_in);
Ybb= *mxGetPr(Ybb_in);
mu_us= *mxGetPr(mu_us_in);
mu_ch= *mxGetPr(mu_ch_in);
mu_aa= *mxGetPr(mu_aa_in);
mu_bb= *mxGetPr(mu_bb_in);
a_us= *mxGetPr(a_us_in);
a_ch= *mxGetPr(a_ch_in);
a_aa= *mxGetPr(a_aa_in);
a_bb= *mxGetPr(a_bb_in);
BBbb_usd= *mxGetPr(BBbb_usd_in);
zusd_aa= *mxGetPr(zusd_aa_in);
zusd_bb= *mxGetPr(zusd_bb_in);
zchy_aa= *mxGetPr(zchy_aa_in);
zchy_bb= *mxGetPr(zchy_bb_in);
tax_us_ch= *mxGetPr(tax_us_ch_in);
tax_us_aa= *mxGetPr(tax_us_aa_in);
tax_us_bb= *mxGetPr(tax_us_bb_in);
tax_ch_us= *mxGetPr(tax_ch_us_in);
tax_ch_aa= *mxGetPr(tax_ch_aa_in);
tax_ch_bb= *mxGetPr(tax_ch_bb_in);
tax_aa_us= *mxGetPr(tax_aa_us_in);
tax_aa_ch= *mxGetPr(tax_aa_ch_in);
tax_aa_rowa= *mxGetPr(tax_aa_rowa_in);
tax_aa_rowb= *mxGetPr(tax_aa_rowb_in);
tax_bb_us= *mxGetPr(tax_bb_us_in);
tax_bb_ch= *mxGetPr(tax_bb_ch_in);
tax_bb_rowa= *mxGetPr(tax_bb_rowa_in);
tax_bb_rowb= *mxGetPr(tax_bb_rowb_in);
etax_ch_us= *mxGetPr(etax_ch_us_in);
etax_aa_us= *mxGetPr(etax_aa_us_in);
etax_bb_us= *mxGetPr(etax_bb_us_in);
etax_us_ch= *mxGetPr(etax_us_ch_in);
etax_aa_ch= *mxGetPr(etax_aa_ch_in);
etax_bb_ch= *mxGetPr(etax_bb_ch_in);
etax_us_aa= *mxGetPr(etax_us_aa_in);
etax_ch_aa= *mxGetPr(etax_ch_aa_in);
etax_bb_aa= *mxGetPr(etax_bb_aa_in);
etax_us_bb= *mxGetPr(etax_us_bb_in);
etax_ch_bb= *mxGetPr(etax_ch_bb_in);
etax_aa_bb= *mxGetPr(etax_aa_bb_in);
xtax_ch_usd= *mxGetPr(xtax_ch_usd_in);
xtax_aa_usd= *mxGetPr(xtax_aa_usd_in);
xtax_bb_usd= *mxGetPr(xtax_bb_usd_in);
xtax_us_chy= *mxGetPr(xtax_us_chy_in);
xtax_aa_chy= *mxGetPr(xtax_aa_chy_in);
xtax_bb_chy= *mxGetPr(xtax_bb_chy_in);
Busd_l= *mxGetPr(Busd_l_in);
Bchy_l= *mxGetPr(Bchy_l_in);
Yus_l= *mxGetPr(Yus_l_in);
Ych_l= *mxGetPr(Ych_l_in);
Yaa_l= *mxGetPr(Yaa_l_in);
Ybb_l= *mxGetPr(Ybb_l_in);
mu_us_l= *mxGetPr(mu_us_l_in);
mu_ch_l= *mxGetPr(mu_ch_l_in);
mu_aa_l= *mxGetPr(mu_aa_l_in);
mu_bb_l= *mxGetPr(mu_bb_l_in);
a_us_l= *mxGetPr(a_us_l_in);
a_ch_l= *mxGetPr(a_ch_l_in);
a_aa_l= *mxGetPr(a_aa_l_in);
a_bb_l= *mxGetPr(a_bb_l_in);
BBbb_usd_l= *mxGetPr(BBbb_usd_l_in);
zusd_aa_l= *mxGetPr(zusd_aa_l_in);
zusd_bb_l= *mxGetPr(zusd_bb_l_in);
zchy_aa_l= *mxGetPr(zchy_aa_l_in);
zchy_bb_l= *mxGetPr(zchy_bb_l_in);
tax_us_ch_l= *mxGetPr(tax_us_ch_l_in);
tax_us_aa_l= *mxGetPr(tax_us_aa_l_in);
tax_us_bb_l= *mxGetPr(tax_us_bb_l_in);
tax_ch_us_l= *mxGetPr(tax_ch_us_l_in);
tax_ch_aa_l= *mxGetPr(tax_ch_aa_l_in);
tax_ch_bb_l= *mxGetPr(tax_ch_bb_l_in);
tax_aa_us_l= *mxGetPr(tax_aa_us_l_in);
tax_aa_ch_l= *mxGetPr(tax_aa_ch_l_in);
tax_aa_rowa_l= *mxGetPr(tax_aa_rowa_l_in);
tax_aa_rowb_l= *mxGetPr(tax_aa_rowb_l_in);
tax_bb_us_l= *mxGetPr(tax_bb_us_l_in);
tax_bb_ch_l= *mxGetPr(tax_bb_ch_l_in);
tax_bb_rowa_l= *mxGetPr(tax_bb_rowa_l_in);
tax_bb_rowb_l= *mxGetPr(tax_bb_rowb_l_in);
etax_ch_us_l= *mxGetPr(etax_ch_us_l_in);
etax_aa_us_l= *mxGetPr(etax_aa_us_l_in);
etax_bb_us_l= *mxGetPr(etax_bb_us_l_in);
etax_us_ch_l= *mxGetPr(etax_us_ch_l_in);
etax_aa_ch_l= *mxGetPr(etax_aa_ch_l_in);
etax_bb_ch_l= *mxGetPr(etax_bb_ch_l_in);
etax_us_aa_l= *mxGetPr(etax_us_aa_l_in);
etax_ch_aa_l= *mxGetPr(etax_ch_aa_l_in);
etax_bb_aa_l= *mxGetPr(etax_bb_aa_l_in);
etax_us_bb_l= *mxGetPr(etax_us_bb_l_in);
etax_ch_bb_l= *mxGetPr(etax_ch_bb_l_in);
etax_aa_bb_l= *mxGetPr(etax_aa_bb_l_in);
xtax_ch_usd_l= *mxGetPr(xtax_ch_usd_l_in);
xtax_aa_usd_l= *mxGetPr(xtax_aa_usd_l_in);
xtax_bb_usd_l= *mxGetPr(xtax_bb_usd_l_in);
xtax_us_chy_l= *mxGetPr(xtax_us_chy_l_in);
xtax_aa_chy_l= *mxGetPr(xtax_aa_chy_l_in);
xtax_bb_chy_l= *mxGetPr(xtax_bb_chy_l_in);
Busd_p= *mxGetPr(Busd_p_in);
Bchy_p= *mxGetPr(Bchy_p_in);
Yus_p= *mxGetPr(Yus_p_in);
Ych_p= *mxGetPr(Ych_p_in);
Yaa_p= *mxGetPr(Yaa_p_in);
Ybb_p= *mxGetPr(Ybb_p_in);
mu_us_p= *mxGetPr(mu_us_p_in);
mu_ch_p= *mxGetPr(mu_ch_p_in);
mu_aa_p= *mxGetPr(mu_aa_p_in);
mu_bb_p= *mxGetPr(mu_bb_p_in);
a_us_p= *mxGetPr(a_us_p_in);
a_ch_p= *mxGetPr(a_ch_p_in);
a_aa_p= *mxGetPr(a_aa_p_in);
a_bb_p= *mxGetPr(a_bb_p_in);
BBbb_usd_p= *mxGetPr(BBbb_usd_p_in);
zusd_aa_p= *mxGetPr(zusd_aa_p_in);
zusd_bb_p= *mxGetPr(zusd_bb_p_in);
zchy_aa_p= *mxGetPr(zchy_aa_p_in);
zchy_bb_p= *mxGetPr(zchy_bb_p_in);
tax_us_ch_p= *mxGetPr(tax_us_ch_p_in);
tax_us_aa_p= *mxGetPr(tax_us_aa_p_in);
tax_us_bb_p= *mxGetPr(tax_us_bb_p_in);
tax_ch_us_p= *mxGetPr(tax_ch_us_p_in);
tax_ch_aa_p= *mxGetPr(tax_ch_aa_p_in);
tax_ch_bb_p= *mxGetPr(tax_ch_bb_p_in);
tax_aa_us_p= *mxGetPr(tax_aa_us_p_in);
tax_aa_ch_p= *mxGetPr(tax_aa_ch_p_in);
tax_aa_rowa_p= *mxGetPr(tax_aa_rowa_p_in);
tax_aa_rowb_p= *mxGetPr(tax_aa_rowb_p_in);
tax_bb_us_p= *mxGetPr(tax_bb_us_p_in);
tax_bb_ch_p= *mxGetPr(tax_bb_ch_p_in);
tax_bb_rowa_p= *mxGetPr(tax_bb_rowa_p_in);
tax_bb_rowb_p= *mxGetPr(tax_bb_rowb_p_in);
etax_ch_us_p= *mxGetPr(etax_ch_us_p_in);
etax_aa_us_p= *mxGetPr(etax_aa_us_p_in);
etax_bb_us_p= *mxGetPr(etax_bb_us_p_in);
etax_us_ch_p= *mxGetPr(etax_us_ch_p_in);
etax_aa_ch_p= *mxGetPr(etax_aa_ch_p_in);
etax_bb_ch_p= *mxGetPr(etax_bb_ch_p_in);
etax_us_aa_p= *mxGetPr(etax_us_aa_p_in);
etax_ch_aa_p= *mxGetPr(etax_ch_aa_p_in);
etax_bb_aa_p= *mxGetPr(etax_bb_aa_p_in);
etax_us_bb_p= *mxGetPr(etax_us_bb_p_in);
etax_ch_bb_p= *mxGetPr(etax_ch_bb_p_in);
etax_aa_bb_p= *mxGetPr(etax_aa_bb_p_in);
xtax_ch_usd_p= *mxGetPr(xtax_ch_usd_p_in);
xtax_aa_usd_p= *mxGetPr(xtax_aa_usd_p_in);
xtax_bb_usd_p= *mxGetPr(xtax_bb_usd_p_in);
xtax_us_chy_p= *mxGetPr(xtax_us_chy_p_in);
xtax_aa_chy_p= *mxGetPr(xtax_aa_chy_p_in);
xtax_bb_chy_p= *mxGetPr(xtax_bb_chy_p_in);
tau= *mxGetPr(tau_in);
taup= *mxGetPr(taup_in);
alph= *mxGetPr(alph_in);
vepsf= *mxGetPr(vepsf_in);
vepst= *mxGetPr(vepst_in);
kap= *mxGetPr(kap_in);
phi= *mxGetPr(phi_in);
r= *mxGetPr(r_in);
sige= *mxGetPr(sige_in);
phi_usg= *mxGetPr(phi_usg_in);
phi_chg= *mxGetPr(phi_chg_in);
phi_aag= *mxGetPr(phi_aag_in);
phi_bbg= *mxGetPr(phi_bbg_in);
bet= *mxGetPr(bet_in);
sig= *mxGetPr(sig_in);
eta= *mxGetPr(eta_in);
Pnumer= *mxGetPr(Pnumer_in);
Xus= *mxGetPr(Xus_in);
Xch= *mxGetPr(Xch_in);
zrow= *mxGetPr(zrow_in);
upp_usd= *mxGetPr(upp_usd_in);
upp_chy= *mxGetPr(upp_chy_in);
sanc_usd_bb= *mxGetPr(sanc_usd_bb_in);
sanc_usd_ch= *mxGetPr(sanc_usd_ch_in);
chi= *mxGetPr(chi_in);
btau_ch_usd= *mxGetPr(btau_ch_usd_in);
btau_aa_usd= *mxGetPr(btau_aa_usd_in);
btau_bb_usd= *mxGetPr(btau_bb_usd_in);
btau_us_chy= *mxGetPr(btau_us_chy_in);
btau_aa_chy= *mxGetPr(btau_aa_chy_in);
btau_bb_chy= *mxGetPr(btau_bb_chy_in);
per_p_year= *mxGetPr(per_p_year_in);
fXaa= *mxGetPr(fXaa_in);
fXbb= *mxGetPr(fXbb_in);
fixx= *mxGetPr(fixx_in);
Baa= *mxGetPr(Baa_in);
Bbb= *mxGetPr(Bbb_in);

            
            
    /*Declare MatlabFunction Terms*/
    
    Cus = pow(pow(Cus_ch,(eta-1.0)/eta)*pow(-(mu_ch*(a_us-1.0))/(mu_aa+mu_bb+mu_ch),1.0/eta)+pow(Cus_rowa,(eta-1.0)/eta)*pow(-(mu_aa*(a_us-1.0))/(mu_aa+mu_bb+mu_ch),1.0/eta)+pow(Cus_rowb,(eta-1.0)/eta)*pow(-(mu_bb*(a_us-1.0))/(mu_aa+mu_bb+mu_ch),1.0/eta)+pow(a_us,1.0/eta)*pow(-(Caa_us*mu_aa+Cbb_us*mu_bb+Cch_us*mu_ch+Yus*mu_us*(phi_usg-1.0))/mu_us,(eta-1.0)/eta),eta/(eta-1.0));
Cch = pow(pow(Cch_us,(eta-1.0)/eta)*pow(-(mu_us*(a_ch-1.0))/(mu_aa+mu_bb+mu_us),1.0/eta)+pow(Cch_rowa,(eta-1.0)/eta)*pow(-(mu_aa*(a_ch-1.0))/(mu_aa+mu_bb+mu_us),1.0/eta)+pow(Cch_rowb,(eta-1.0)/eta)*pow(-(mu_bb*(a_ch-1.0))/(mu_aa+mu_bb+mu_us),1.0/eta)+pow(a_ch,1.0/eta)*pow(-(Caa_ch*mu_aa+Cbb_ch*mu_bb+Cus_ch*mu_us+Ych*mu_ch*(phi_chg-1.0))/mu_ch,(eta-1.0)/eta),eta/(eta-1.0));
Caa = pow(pow(Caa_ch,(eta-1.0)/eta)*pow(-(mu_ch*(a_aa-1.0))/(mu_aa+mu_bb+mu_ch+mu_us),1.0/eta)+pow(Caa_us,(eta-1.0)/eta)*pow(-(mu_us*(a_aa-1.0))/(mu_aa+mu_bb+mu_ch+mu_us),1.0/eta)+pow(Caa_rowa,(eta-1.0)/eta)*pow(-(mu_aa*(a_aa-1.0))/(mu_aa+mu_bb+mu_ch+mu_us),1.0/eta)+pow(Caa_rowb,(eta-1.0)/eta)*pow(-(mu_bb*(a_aa-1.0))/(mu_aa+mu_bb+mu_ch+mu_us),1.0/eta)+pow(a_aa,1.0/eta)*pow(-(Caa_rowa*mu_aa+Cbb_rowa*mu_bb+Cch_rowa*mu_ch+Cus_rowa*mu_us+Yaa*mu_aa*(phi_aag-1.0))/mu_aa,(eta-1.0)/eta),eta/(eta-1.0));
Cbb = pow(pow(Cbb_ch,(eta-1.0)/eta)*pow(-(mu_ch*(a_bb-1.0))/(mu_aa+mu_bb+mu_ch+mu_us),1.0/eta)+pow(Cbb_us,(eta-1.0)/eta)*pow(-(mu_us*(a_bb-1.0))/(mu_aa+mu_bb+mu_ch+mu_us),1.0/eta)+pow(Cbb_rowa,(eta-1.0)/eta)*pow(-(mu_aa*(a_bb-1.0))/(mu_aa+mu_bb+mu_ch+mu_us),1.0/eta)+pow(Cbb_rowb,(eta-1.0)/eta)*pow(-(mu_bb*(a_bb-1.0))/(mu_aa+mu_bb+mu_ch+mu_us),1.0/eta)+pow(a_bb,1.0/eta)*pow(-(Caa_rowb*mu_aa+Cbb_rowb*mu_bb+Cch_rowb*mu_ch+Cus_rowb*mu_us+Ybb*mu_bb*(phi_bbg-1.0))/mu_bb,(eta-1.0)/eta),eta/(eta-1.0));
Cus_us = -(Caa_us*mu_aa+Cbb_us*mu_bb+Cch_us*mu_ch+Yus*mu_us*(phi_usg-1.0))/mu_us;
Cch_ch = -(Caa_ch*mu_aa+Cbb_ch*mu_bb+Cus_ch*mu_us+Ych*mu_ch*(phi_chg-1.0))/mu_ch;
Caa_aa = -(Caa_rowa*mu_aa+Cbb_rowa*mu_bb+Cch_rowa*mu_ch+Cus_rowa*mu_us+Yaa*mu_aa*(phi_aag-1.0))/mu_aa;
Cbb_bb = -(Caa_rowb*mu_aa+Cbb_rowb*mu_bb+Cch_rowb*mu_ch+Cus_rowb*mu_us+Ybb*mu_bb*(phi_bbg-1.0))/mu_bb;
Pus = pow(pow(Pus_us,-eta+1.0)*a_us-(mu_ch*pow(Pus_ch*(tax_us_ch+1.0),-eta+1.0)*(a_us-1.0))/(mu_aa+mu_bb+mu_ch)-(mu_aa*pow(Pus_rowa*(tax_us_aa+1.0),-eta+1.0)*(a_us-1.0))/(mu_aa+mu_bb+mu_ch)-(mu_bb*pow(Pus_rowb*(tax_us_bb+1.0),-eta+1.0)*(a_us-1.0))/(mu_aa+mu_bb+mu_ch),-1.0/(eta-1.0));
Pch = pow(pow(Pch_ch,-eta+1.0)*a_ch-(mu_us*pow(Pch_us*(tax_ch_us+1.0),-eta+1.0)*(a_ch-1.0))/(mu_aa+mu_bb+mu_us)-(mu_aa*pow(Pch_rowa*(tax_ch_aa+1.0),-eta+1.0)*(a_ch-1.0))/(mu_aa+mu_bb+mu_us)-(mu_bb*pow(Pch_rowb*(tax_ch_bb+1.0),-eta+1.0)*(a_ch-1.0))/(mu_aa+mu_bb+mu_us),-1.0/(eta-1.0));
Paa = pow(pow(Paa_aa,-eta+1.0)*a_aa-(mu_ch*pow(Paa_ch*(tax_aa_ch+1.0),-eta+1.0)*(a_aa-1.0))/(mu_aa+mu_bb+mu_ch+mu_us)-(mu_us*pow(Paa_us*(tax_aa_us+1.0),-eta+1.0)*(a_aa-1.0))/(mu_aa+mu_bb+mu_ch+mu_us)-(mu_aa*pow(Paa_rowa*(tax_aa_rowa+1.0),-eta+1.0)*(a_aa-1.0))/(mu_aa+mu_bb+mu_ch+mu_us)-(mu_bb*pow(Paa_rowb*(tax_aa_rowb+1.0),-eta+1.0)*(a_aa-1.0))/(mu_aa+mu_bb+mu_ch+mu_us),-1.0/(eta-1.0));
Pbb = pow(pow(Pbb_bb,-eta+1.0)*a_bb-(mu_ch*pow(Pbb_ch*(tax_bb_ch+1.0),-eta+1.0)*(a_bb-1.0))/(mu_aa+mu_bb+mu_ch+mu_us)-(mu_us*pow(Pbb_us*(tax_bb_us+1.0),-eta+1.0)*(a_bb-1.0))/(mu_aa+mu_bb+mu_ch+mu_us)-(mu_aa*pow(Pbb_rowa*(tax_bb_rowa+1.0),-eta+1.0)*(a_bb-1.0))/(mu_aa+mu_bb+mu_ch+mu_us)-(mu_bb*pow(Pbb_rowb*(tax_bb_rowb+1.0),-eta+1.0)*(a_bb-1.0))/(mu_aa+mu_bb+mu_ch+mu_us),-1.0/(eta-1.0));
Bch_usd = -(Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb))/mu_ch;
Bus_chy = -(Baa_chya+Bbb_chya-Bchy+Bch_chya)/mu_us;
Bbb_row = -(-Baa+Baa_rowa-Bbb+Bch_rowa+Bus_rowa)/mu_bb;
p_aa_chy = (Baa_chya*Pch_ch*Qchy*chi*upp_chy*pow(pow(m_aa*(-zusd_aa+(erfc((sqrt(2.0)*sbar_aa)/2.0)*(zchy_aa+zusd_aa-1.0))/2.0+1.0),1.0/vepsf)+pow((Baa_chya*Pch_ch*Qchy*upp_chy)/mu_aa,1.0/vepsf),-vepsf))/mu_aa;
p_aa_usd = (Baa_usda*Pus_us*Qusd*chi*upp_usd*pow(pow(m_aa*(zusd_aa-(erfc((sqrt(2.0)*sbar_aa)/2.0)*(zchy_aa+zusd_aa-1.0))/2.0),1.0/vepsf)+pow((Baa_usda*Pus_us*Qusd*upp_usd)/mu_aa,1.0/vepsf),-vepsf))/mu_aa;
p_bb_chy = (Bbb_chya*Pch_ch*Qchy*chi*upp_chy*pow(pow(m_bb*(-zusd_bb+(erfc((sqrt(2.0)*sbar_bb)/2.0)*(zchy_bb+zusd_bb-1.0))/2.0+1.0),1.0/vepsf)+pow((Bbb_chya*Pch_ch*Qchy*upp_chy)/mu_bb,1.0/vepsf),-vepsf))/mu_bb;
p_bb_usd = (Bbb_usda*Pus_us*Qusd*chi*sanc_usd_bb*upp_usd*pow(pow(m_bb*sanc_usd_bb*(zusd_bb-(erfc((sqrt(2.0)*sbar_bb)/2.0)*(zchy_bb+zusd_bb-1.0))/2.0),1.0/vepsf)+pow((Bbb_usda*Pus_us*Qusd*upp_usd)/mu_bb,1.0/vepsf),-vepsf))/mu_bb;
p_ch_chy = (Bch_chya*Pch_ch*Qchy*chi*upp_chy*pow(pow(-m_ch*(Xch-1.0),1.0/vepsf)+pow((Bch_chya*Pch_ch*Qchy*upp_chy)/mu_ch,1.0/vepsf),-vepsf))/mu_ch;
p_ch_usd = -(Pus_us*Qusd*chi*sanc_usd_ch*upp_usd*pow(pow(Xch*m_ch*sanc_usd_ch,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb)))/mu_ch,1.0/vepsf),-vepsf)*(Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb)))/mu_ch;
p_us_chy = -(Pch_ch*Qchy*chi*upp_chy*pow(pow(-(Pch_ch*Qchy*upp_chy*(Baa_chya+Bbb_chya-Bchy+Bch_chya))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf)*(Baa_chya+Bbb_chya-Bchy+Bch_chya))/mu_us;
p_us_usd = (Bus_usda*Pus_us*Qusd*chi*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf))/mu_us;
ph_aa_chy = chi*m_aa*upp_chy*pow(pow(m_aa*(-zusd_aa+(erfc((sqrt(2.0)*sbar_aa)/2.0)*(zchy_aa+zusd_aa-1.0))/2.0+1.0),1.0/vepsf)+pow((Baa_chya*Pch_ch*Qchy*upp_chy)/mu_aa,1.0/vepsf),-vepsf)*(-zusd_aa+(erfc((sqrt(2.0)*sbar_aa)/2.0)*(zchy_aa+zusd_aa-1.0))/2.0+1.0);
ph_aa_row = chi*m_aa*upp_usd*zrow*pow(pow((Baa_rowa*Qrow*upp_usd)/mu_aa,1.0/vepsf)+pow(m_aa*zrow,1.0/vepsf),-vepsf);
ph_aa_usd = chi*m_aa*upp_usd*(zusd_aa-(erfc((sqrt(2.0)*sbar_aa)/2.0)*(zchy_aa+zusd_aa-1.0))/2.0)*pow(pow(m_aa*(zusd_aa-(erfc((sqrt(2.0)*sbar_aa)/2.0)*(zchy_aa+zusd_aa-1.0))/2.0),1.0/vepsf)+pow((Baa_usda*Pus_us*Qusd*upp_usd)/mu_aa,1.0/vepsf),-vepsf);
ph_bb_chy = chi*m_bb*upp_chy*pow(pow(m_bb*(-zusd_bb+(erfc((sqrt(2.0)*sbar_bb)/2.0)*(zchy_bb+zusd_bb-1.0))/2.0+1.0),1.0/vepsf)+pow((Bbb_chya*Pch_ch*Qchy*upp_chy)/mu_bb,1.0/vepsf),-vepsf)*(-zusd_bb+(erfc((sqrt(2.0)*sbar_bb)/2.0)*(zchy_bb+zusd_bb-1.0))/2.0+1.0);
ph_bb_row = chi*m_bb*upp_usd*zrow*pow(pow(m_bb*zrow,1.0/vepsf)+pow(-(Qrow*upp_usd*(-Baa+Baa_rowa-Bbb+Bch_rowa+Bus_rowa))/mu_bb,1.0/vepsf),-vepsf);
ph_bb_usd = chi*m_bb*sanc_usd_bb*upp_usd*(zusd_bb-(erfc((sqrt(2.0)*sbar_bb)/2.0)*(zchy_bb+zusd_bb-1.0))/2.0)*pow(pow(m_bb*sanc_usd_bb*(zusd_bb-(erfc((sqrt(2.0)*sbar_bb)/2.0)*(zchy_bb+zusd_bb-1.0))/2.0),1.0/vepsf)+pow((Bbb_usda*Pus_us*Qusd*upp_usd)/mu_bb,1.0/vepsf),-vepsf);
ph_ch_chy = -chi*m_ch*upp_chy*(Xch-1.0)*pow(pow(-m_ch*(Xch-1.0),1.0/vepsf)+pow((Bch_chya*Pch_ch*Qchy*upp_chy)/mu_ch,1.0/vepsf),-vepsf);
ph_ch_row = chi*m_ch*upp_usd*zrow*pow(pow((Bch_rowa*Qrow*upp_usd)/mu_ch,1.0/vepsf)+pow(m_ch*zrow,1.0/vepsf),-vepsf);
ph_ch_usd = Xch*chi*m_ch*sanc_usd_ch*upp_usd*pow(pow(Xch*m_ch*sanc_usd_ch,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb)))/mu_ch,1.0/vepsf),-vepsf);
ph_us_chy = -chi*m_us*upp_chy*pow(pow(-(Pch_ch*Qchy*upp_chy*(Baa_chya+Bbb_chya-Bchy+Bch_chya))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf)*(Xus-1.0);
ph_us_row = chi*m_us*upp_usd*zrow*pow(pow((Bus_rowa*Qrow*upp_usd)/mu_us,1.0/vepsf)+pow(m_us*zrow,1.0/vepsf),-vepsf);
ph_us_usd = Xus*chi*m_us*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf);
m_us_til = m_us*mu_us*((Pch_ch*Qchy*chi*upp_chy*pow(pow(-(Pch_ch*Qchy*upp_chy*(Baa_chya+Bbb_chya-Bchy+Bch_chya))/mu_us,1.0/vepsf)+pow(-m_us*(Xus-1.0),1.0/vepsf),-vepsf)*(Xus-1.0)*(Baa_chya+Bbb_chya-Bchy+Bch_chya))/mu_us+(Bus_usda*Pus_us*Qusd*Xus*chi*upp_usd*pow(pow(Xus*m_us,1.0/vepsf)+pow((Bus_usda*Pus_us*Qusd*upp_usd)/mu_us,1.0/vepsf),-vepsf))/mu_us);
m_ch_til = -m_ch*mu_ch*((Bch_chya*Pch_ch*Qchy*chi*upp_chy*(Xch-1.0)*pow(pow(-m_ch*(Xch-1.0),1.0/vepsf)+pow((Bch_chya*Pch_ch*Qchy*upp_chy)/mu_ch,1.0/vepsf),-vepsf))/mu_ch+(Pus_us*Qusd*Xch*chi*sanc_usd_ch*upp_usd*pow(pow(Xch*m_ch*sanc_usd_ch,1.0/vepsf)+pow(-(Pus_us*Qusd*upp_usd*(Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb)))/mu_ch,1.0/vepsf),-vepsf)*(Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb)))/mu_ch);
m_aa_til = m_aa*mu_aa*((Baa_chya*Pch_ch*Qchy*chi*upp_chy*pow(pow(m_aa*(-zusd_aa+(erfc((sqrt(2.0)*sbar_aa)/2.0)*(zchy_aa+zusd_aa-1.0))/2.0+1.0),1.0/vepsf)+pow((Baa_chya*Pch_ch*Qchy*upp_chy)/mu_aa,1.0/vepsf),-vepsf)*(-zusd_aa+(erfc((sqrt(2.0)*sbar_aa)/2.0)*(zchy_aa+zusd_aa-1.0))/2.0+1.0))/mu_aa+(Baa_usda*Pus_us*Qusd*chi*upp_usd*(zusd_aa-(erfc((sqrt(2.0)*sbar_aa)/2.0)*(zchy_aa+zusd_aa-1.0))/2.0)*pow(pow(m_aa*(zusd_aa-(erfc((sqrt(2.0)*sbar_aa)/2.0)*(zchy_aa+zusd_aa-1.0))/2.0),1.0/vepsf)+pow((Baa_usda*Pus_us*Qusd*upp_usd)/mu_aa,1.0/vepsf),-vepsf))/mu_aa);
m_bb_til = m_bb*mu_bb*((Bbb_chya*Pch_ch*Qchy*chi*upp_chy*pow(pow(m_bb*(-zusd_bb+(erfc((sqrt(2.0)*sbar_bb)/2.0)*(zchy_bb+zusd_bb-1.0))/2.0+1.0),1.0/vepsf)+pow((Bbb_chya*Pch_ch*Qchy*upp_chy)/mu_bb,1.0/vepsf),-vepsf)*(-zusd_bb+(erfc((sqrt(2.0)*sbar_bb)/2.0)*(zchy_bb+zusd_bb-1.0))/2.0+1.0))/mu_bb+(Bbb_usda*Pus_us*Qusd*chi*sanc_usd_bb*upp_usd*(zusd_bb-(erfc((sqrt(2.0)*sbar_bb)/2.0)*(zchy_bb+zusd_bb-1.0))/2.0)*pow(pow(m_bb*sanc_usd_bb*(zusd_bb-(erfc((sqrt(2.0)*sbar_bb)/2.0)*(zchy_bb+zusd_bb-1.0))/2.0),1.0/vepsf)+pow((Bbb_usda*Pus_us*Qusd*upp_usd)/mu_bb,1.0/vepsf),-vepsf))/mu_bb);
pim_us_ch = exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0);
pim_us_aa = -(exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)-1.0))/(exp(pim_us_aa_)+1.0);
pim_us_bb = (exp(pim_us_bb_)*(-exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)+(exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)-1.0))/(exp(pim_us_aa_)+1.0)+1.0))/(exp(pim_us_bb_)+1.0);
pex_us_ch = -(exp(pex_us_ch_)*(exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)+(exp(pim_us_bb_)*(-exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)+(exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)-1.0))/(exp(pim_us_aa_)+1.0)+1.0))/(exp(pim_us_bb_)+1.0)-(exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)-1.0))/(exp(pim_us_aa_)+1.0)-1.0))/(exp(pex_us_ch_)+1.0);
pex_us_aa = (exp(pex_us_aa_)*(-exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)+(exp(pex_us_ch_)*(exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)+(exp(pim_us_bb_)*(-exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)+(exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)-1.0))/(exp(pim_us_aa_)+1.0)+1.0))/(exp(pim_us_bb_)+1.0)-(exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)-1.0))/(exp(pim_us_aa_)+1.0)-1.0))/(exp(pex_us_ch_)+1.0)-(exp(pim_us_bb_)*(-exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)+(exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)-1.0))/(exp(pim_us_aa_)+1.0)+1.0))/(exp(pim_us_bb_)+1.0)+(exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)-1.0))/(exp(pim_us_aa_)+1.0)+1.0))/(exp(pex_us_aa_)+1.0);
pex_us_bb = -exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)-(exp(pex_us_aa_)*(-exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)+(exp(pex_us_ch_)*(exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)+(exp(pim_us_bb_)*(-exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)+(exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)-1.0))/(exp(pim_us_aa_)+1.0)+1.0))/(exp(pim_us_bb_)+1.0)-(exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)-1.0))/(exp(pim_us_aa_)+1.0)-1.0))/(exp(pex_us_ch_)+1.0)-(exp(pim_us_bb_)*(-exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)+(exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)-1.0))/(exp(pim_us_aa_)+1.0)+1.0))/(exp(pim_us_bb_)+1.0)+(exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)-1.0))/(exp(pim_us_aa_)+1.0)+1.0))/(exp(pex_us_aa_)+1.0)+(exp(pex_us_ch_)*(exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)+(exp(pim_us_bb_)*(-exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)+(exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)-1.0))/(exp(pim_us_aa_)+1.0)+1.0))/(exp(pim_us_bb_)+1.0)-(exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)-1.0))/(exp(pim_us_aa_)+1.0)-1.0))/(exp(pex_us_ch_)+1.0)-(exp(pim_us_bb_)*(-exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)+(exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)-1.0))/(exp(pim_us_aa_)+1.0)+1.0))/(exp(pim_us_bb_)+1.0)+(exp(pim_us_aa_)*(exp(pim_us_ch_)/(exp(pim_us_ch_)+1.0)-1.0))/(exp(pim_us_aa_)+1.0)+1.0;
pim_ch_us = exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0);
pim_ch_aa = (exp(pim_ch_aa_)*(-exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)+(exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)-1.0))/(exp(pim_ch_bb_)+1.0)+1.0))/(exp(pim_ch_aa_)+1.0);
pim_ch_bb = -(exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)-1.0))/(exp(pim_ch_bb_)+1.0);
pex_ch_us = -(exp(pex_ch_us_)*(exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)+(exp(pim_ch_aa_)*(-exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)+(exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)-1.0))/(exp(pim_ch_bb_)+1.0)+1.0))/(exp(pim_ch_aa_)+1.0)-(exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)-1.0))/(exp(pim_ch_bb_)+1.0)-1.0))/(exp(pex_ch_us_)+1.0);
pex_ch_aa = -exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)-(exp(pex_ch_bb_)*(-exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)+(exp(pex_ch_us_)*(exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)+(exp(pim_ch_aa_)*(-exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)+(exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)-1.0))/(exp(pim_ch_bb_)+1.0)+1.0))/(exp(pim_ch_aa_)+1.0)-(exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)-1.0))/(exp(pim_ch_bb_)+1.0)-1.0))/(exp(pex_ch_us_)+1.0)-(exp(pim_ch_aa_)*(-exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)+(exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)-1.0))/(exp(pim_ch_bb_)+1.0)+1.0))/(exp(pim_ch_aa_)+1.0)+(exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)-1.0))/(exp(pim_ch_bb_)+1.0)+1.0))/(exp(pex_ch_bb_)+1.0)+(exp(pex_ch_us_)*(exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)+(exp(pim_ch_aa_)*(-exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)+(exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)-1.0))/(exp(pim_ch_bb_)+1.0)+1.0))/(exp(pim_ch_aa_)+1.0)-(exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)-1.0))/(exp(pim_ch_bb_)+1.0)-1.0))/(exp(pex_ch_us_)+1.0)-(exp(pim_ch_aa_)*(-exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)+(exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)-1.0))/(exp(pim_ch_bb_)+1.0)+1.0))/(exp(pim_ch_aa_)+1.0)+(exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)-1.0))/(exp(pim_ch_bb_)+1.0)+1.0;
pex_ch_bb = (exp(pex_ch_bb_)*(-exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)+(exp(pex_ch_us_)*(exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)+(exp(pim_ch_aa_)*(-exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)+(exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)-1.0))/(exp(pim_ch_bb_)+1.0)+1.0))/(exp(pim_ch_aa_)+1.0)-(exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)-1.0))/(exp(pim_ch_bb_)+1.0)-1.0))/(exp(pex_ch_us_)+1.0)-(exp(pim_ch_aa_)*(-exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)+(exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)-1.0))/(exp(pim_ch_bb_)+1.0)+1.0))/(exp(pim_ch_aa_)+1.0)+(exp(pim_ch_bb_)*(exp(pim_ch_us_)/(exp(pim_ch_us_)+1.0)-1.0))/(exp(pim_ch_bb_)+1.0)+1.0))/(exp(pex_ch_bb_)+1.0);
pim_aa_us = exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0);
pim_aa_ch = -(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0);
pim_aa_aa = (exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0);
pim_aa_bb = -(exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)-(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)-1.0))/(exp(pim_aa_rowb_)+1.0);
pex_aa_us = (exp(pex_aa_us_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)-(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)-1.0))/(exp(pim_aa_rowb_)+1.0)-(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pex_aa_us_)+1.0);
pex_aa_ch = -(exp(pex_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pex_aa_us_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)-(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)-1.0))/(exp(pim_aa_rowb_)+1.0)-(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pex_aa_us_)+1.0)-(exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)-(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)-1.0))/(exp(pim_aa_rowb_)+1.0)+(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)-(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)-1.0))/(exp(pex_aa_ch_)+1.0);
pex_aa_aa = (exp(pex_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pex_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pex_aa_us_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)-(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)-1.0))/(exp(pim_aa_rowb_)+1.0)-(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pex_aa_us_)+1.0)-(exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)-(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)-1.0))/(exp(pim_aa_rowb_)+1.0)+(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)-(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)-1.0))/(exp(pex_aa_ch_)+1.0)-(exp(pex_aa_us_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)-(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)-1.0))/(exp(pim_aa_rowb_)+1.0)-(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pex_aa_us_)+1.0)+(exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)-(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)-1.0))/(exp(pim_aa_rowb_)+1.0)-(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pex_aa_rowa_)+1.0);
pex_aa_bb = -exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pex_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pex_aa_us_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)-(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)-1.0))/(exp(pim_aa_rowb_)+1.0)-(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pex_aa_us_)+1.0)-(exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)-(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)-1.0))/(exp(pim_aa_rowb_)+1.0)+(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)-(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)-1.0))/(exp(pex_aa_ch_)+1.0)-(exp(pex_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pex_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pex_aa_us_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)-(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)-1.0))/(exp(pim_aa_rowb_)+1.0)-(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pex_aa_us_)+1.0)-(exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)-(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)-1.0))/(exp(pim_aa_rowb_)+1.0)+(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)-(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)-1.0))/(exp(pex_aa_ch_)+1.0)-(exp(pex_aa_us_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)-(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)-1.0))/(exp(pim_aa_rowb_)+1.0)-(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pex_aa_us_)+1.0)+(exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)-(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)-1.0))/(exp(pim_aa_rowb_)+1.0)-(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pex_aa_rowa_)+1.0)-(exp(pex_aa_us_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)-(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)-1.0))/(exp(pim_aa_rowb_)+1.0)-(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pex_aa_us_)+1.0)+(exp(pim_aa_rowb_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)-(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)-1.0))/(exp(pim_aa_rowb_)+1.0)-(exp(pim_aa_rowa_)*(-exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0))/(exp(pim_aa_rowa_)+1.0)+(exp(pim_aa_ch_)*(exp(pim_aa_us_)/(exp(pim_aa_us_)+1.0)-1.0))/(exp(pim_aa_ch_)+1.0)+1.0;
pim_bb_us = exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0);
pim_bb_ch = -(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0);
pim_bb_aa = -(exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)-(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)-1.0))/(exp(pim_bb_rowa_)+1.0);
pim_bb_bb = (exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0);
pex_bb_us = (exp(pex_bb_us_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)-(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)-1.0))/(exp(pim_bb_rowa_)+1.0)-(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pex_bb_us_)+1.0);
pex_bb_ch = -(exp(pex_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pex_bb_us_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)-(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)-1.0))/(exp(pim_bb_rowa_)+1.0)-(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pex_bb_us_)+1.0)-(exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)-(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)-1.0))/(exp(pim_bb_rowa_)+1.0)+(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)-(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)-1.0))/(exp(pex_bb_ch_)+1.0);
pex_bb_aa = -exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pex_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pex_bb_us_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)-(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)-1.0))/(exp(pim_bb_rowa_)+1.0)-(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pex_bb_us_)+1.0)-(exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)-(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)-1.0))/(exp(pim_bb_rowa_)+1.0)+(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)-(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)-1.0))/(exp(pex_bb_ch_)+1.0)-(exp(pex_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pex_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pex_bb_us_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)-(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)-1.0))/(exp(pim_bb_rowa_)+1.0)-(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pex_bb_us_)+1.0)-(exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)-(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)-1.0))/(exp(pim_bb_rowa_)+1.0)+(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)-(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)-1.0))/(exp(pex_bb_ch_)+1.0)-(exp(pex_bb_us_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)-(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)-1.0))/(exp(pim_bb_rowa_)+1.0)-(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pex_bb_us_)+1.0)+(exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)-(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)-1.0))/(exp(pim_bb_rowa_)+1.0)-(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pex_bb_rowb_)+1.0)-(exp(pex_bb_us_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)-(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)-1.0))/(exp(pim_bb_rowa_)+1.0)-(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pex_bb_us_)+1.0)+(exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)-(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)-1.0))/(exp(pim_bb_rowa_)+1.0)-(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0;
pex_bb_bb = (exp(pex_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pex_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pex_bb_us_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)-(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)-1.0))/(exp(pim_bb_rowa_)+1.0)-(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pex_bb_us_)+1.0)-(exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)-(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)-1.0))/(exp(pim_bb_rowa_)+1.0)+(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)-(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)-1.0))/(exp(pex_bb_ch_)+1.0)-(exp(pex_bb_us_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)-(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)-1.0))/(exp(pim_bb_rowa_)+1.0)-(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pex_bb_us_)+1.0)+(exp(pim_bb_rowa_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)-(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)-1.0))/(exp(pim_bb_rowa_)+1.0)-(exp(pim_bb_rowb_)*(-exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pim_bb_rowb_)+1.0)+(exp(pim_bb_ch_)*(exp(pim_bb_us_)/(exp(pim_bb_us_)+1.0)-1.0))/(exp(pim_bb_ch_)+1.0)+1.0))/(exp(pex_bb_rowb_)+1.0);
        
            
    
                  
    /*Output argument*/
    OUT [7] =Pus_us/mu_ch_l;
OUT [61] =(Pch*Pus_us_p*bet*(Qusd_p*((pow(mu_ch,2)*taup*pow((Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb))/mu_ch-(Baa_usda_p-Busd_p+Bus_usda_p+mu_bb_p*(BBbb_usd_p+Bbb_usda_p/mu_bb_p))/mu_ch_p,2)*1.0/pow(Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb),2))/2.0-(mu_ch*taup*((Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb))/mu_ch-(Baa_usda_p-Busd_p+Bus_usda_p+mu_bb_p*(BBbb_usd_p+Bbb_usda_p/mu_bb_p))/mu_ch_p))/(Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb)))+1.0)*pow(pow(pow(Cch_us_p,(eta-1.0)/eta)*pow(-(mu_us_p*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p),1.0/eta)+pow(Cch_rowa_p,(eta-1.0)/eta)*pow(-(mu_aa_p*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p),1.0/eta)+pow(Cch_rowb_p,(eta-1.0)/eta)*pow(-(mu_bb_p*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p),1.0/eta)+pow(a_ch_p,1.0/eta)*pow(-(Caa_ch_p*mu_aa_p+Cbb_ch_p*mu_bb_p+Cus_ch_p*mu_us_p+Ych_p*mu_ch_p*(phi_chg-1.0))/mu_ch_p,(eta-1.0)/eta),eta/(eta-1.0))/Cch,-sig)*(tau/(Baa_usda_l-Busd_l+Bus_usda_l+mu_bb_l*(BBbb_usd_l+Bbb_usda_l/mu_bb_l))+mu_ch_l*tau*((Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb))/mu_ch-(Baa_usda_l-Busd_l+Bus_usda_l+mu_bb_l*(BBbb_usd_l+Bbb_usda_l/mu_bb_l))/mu_ch_l)*1.0/pow(Baa_usda_l-Busd_l+Bus_usda_l+mu_bb_l*(BBbb_usd_l+Bbb_usda_l/mu_bb_l),2))*1.0/pow(btau_ch_usd-ph_ch_usd*r+(mu_ch_l*tau*((Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb))/mu_ch-(Baa_usda_l-Busd_l+Bus_usda_l+mu_bb_l*(BBbb_usd_l+Bbb_usda_l/mu_bb_l))/mu_ch_l))/(Baa_usda_l-Busd_l+Bus_usda_l+mu_bb_l*(BBbb_usd_l+Bbb_usda_l/mu_bb_l))+1.0,2)*pow(pow(Pch_ch_p,-eta+1.0)*a_ch_p-(mu_us_p*pow(Pch_us_p*(tax_ch_us_p+1.0),-eta+1.0)*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p)-(mu_aa_p*pow(Pch_rowa_p*(tax_ch_aa_p+1.0),-eta+1.0)*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p)-(mu_bb_p*pow(Pch_rowb_p*(tax_ch_bb_p+1.0),-eta+1.0)*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p),1.0/(eta-1.0))*-1.0e+2)/(Pus_us*Qusd);
OUT [64] =(Paa*Pus_us_p*bet*(Qusd_p*((mu_aa*taup*(Baa_usda/mu_aa-Baa_usda_p/mu_aa_p))/Baa_usda-(1.0/pow(Baa_usda,2)*pow(mu_aa,2)*taup*pow(Baa_usda/mu_aa-Baa_usda_p/mu_aa_p,2))/2.0)-1.0)*pow(pow(pow(Caa_ch_p,(eta-1.0)/eta)*pow(-(mu_ch_p*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Caa_us_p,(eta-1.0)/eta)*pow(-(mu_us_p*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Caa_rowa_p,(eta-1.0)/eta)*pow(-(mu_aa_p*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Caa_rowb_p,(eta-1.0)/eta)*pow(-(mu_bb_p*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(a_aa_p,1.0/eta)*pow(-(Caa_rowa_p*mu_aa_p+Cbb_rowa_p*mu_bb_p+Cch_rowa_p*mu_ch_p+Cus_rowa_p*mu_us_p+Yaa_p*mu_aa_p*(phi_aag-1.0))/mu_aa_p,(eta-1.0)/eta),eta/(eta-1.0))/Caa,-sig)*(tau/Baa_usda_l+1.0/pow(Baa_usda_l,2)*mu_aa_l*tau*(Baa_usda/mu_aa-Baa_usda_l/mu_aa_l))*1.0/pow(btau_aa_usd-ph_aa_usd*r+(mu_aa_l*tau*(Baa_usda/mu_aa-Baa_usda_l/mu_aa_l))/Baa_usda_l+1.0,2)*pow(pow(Paa_aa_p,-eta+1.0)*a_aa_p-(mu_ch_p*pow(Paa_ch_p*(tax_aa_ch_p+1.0),-eta+1.0)*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_us_p*pow(Paa_us_p*(tax_aa_us_p+1.0),-eta+1.0)*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_aa_p*pow(Paa_rowa_p*(tax_aa_rowa_p+1.0),-eta+1.0)*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_bb_p*pow(Paa_rowb_p*(tax_aa_rowb_p+1.0),-eta+1.0)*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/(eta-1.0))*1.0e+2)/(Pus_us*Qusd);
OUT [70] =-Pus_us/mu_aa_l;
OUT [81] =Pus_us/mu_ch_l;
OUT [135] =(Pch*Pus_us_p*bet*(Qusd_p*((pow(mu_ch,2)*taup*pow((Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb))/mu_ch-(Baa_usda_p-Busd_p+Bus_usda_p+mu_bb_p*(BBbb_usd_p+Bbb_usda_p/mu_bb_p))/mu_ch_p,2)*1.0/pow(Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb),2))/2.0-(mu_ch*taup*((Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb))/mu_ch-(Baa_usda_p-Busd_p+Bus_usda_p+mu_bb_p*(BBbb_usd_p+Bbb_usda_p/mu_bb_p))/mu_ch_p))/(Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb)))+1.0)*pow(pow(pow(Cch_us_p,(eta-1.0)/eta)*pow(-(mu_us_p*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p),1.0/eta)+pow(Cch_rowa_p,(eta-1.0)/eta)*pow(-(mu_aa_p*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p),1.0/eta)+pow(Cch_rowb_p,(eta-1.0)/eta)*pow(-(mu_bb_p*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p),1.0/eta)+pow(a_ch_p,1.0/eta)*pow(-(Caa_ch_p*mu_aa_p+Cbb_ch_p*mu_bb_p+Cus_ch_p*mu_us_p+Ych_p*mu_ch_p*(phi_chg-1.0))/mu_ch_p,(eta-1.0)/eta),eta/(eta-1.0))/Cch,-sig)*(tau/(Baa_usda_l-Busd_l+Bus_usda_l+mu_bb_l*(BBbb_usd_l+Bbb_usda_l/mu_bb_l))+mu_ch_l*tau*((Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb))/mu_ch-(Baa_usda_l-Busd_l+Bus_usda_l+mu_bb_l*(BBbb_usd_l+Bbb_usda_l/mu_bb_l))/mu_ch_l)*1.0/pow(Baa_usda_l-Busd_l+Bus_usda_l+mu_bb_l*(BBbb_usd_l+Bbb_usda_l/mu_bb_l),2))*1.0/pow(btau_ch_usd-ph_ch_usd*r+(mu_ch_l*tau*((Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb))/mu_ch-(Baa_usda_l-Busd_l+Bus_usda_l+mu_bb_l*(BBbb_usd_l+Bbb_usda_l/mu_bb_l))/mu_ch_l))/(Baa_usda_l-Busd_l+Bus_usda_l+mu_bb_l*(BBbb_usd_l+Bbb_usda_l/mu_bb_l))+1.0,2)*pow(pow(Pch_ch_p,-eta+1.0)*a_ch_p-(mu_us_p*pow(Pch_us_p*(tax_ch_us_p+1.0),-eta+1.0)*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p)-(mu_aa_p*pow(Pch_rowa_p*(tax_ch_aa_p+1.0),-eta+1.0)*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p)-(mu_bb_p*pow(Pch_rowb_p*(tax_ch_bb_p+1.0),-eta+1.0)*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p),1.0/(eta-1.0))*-1.0e+2)/(Pus_us*Qusd);
OUT [141] =(Pbb*Pus_us_p*bet*(Qusd_p*((taup*(BBbb_usd-BBbb_usd_p+Bbb_usda/mu_bb-Bbb_usda_p/mu_bb_p))/(BBbb_usd+Bbb_usda/mu_bb)-(taup*1.0/pow(BBbb_usd+Bbb_usda/mu_bb,2)*pow(BBbb_usd-BBbb_usd_p+Bbb_usda/mu_bb-Bbb_usda_p/mu_bb_p,2))/2.0)-1.0)*(tau/(mu_bb_l*(BBbb_usd_l+Bbb_usda_l/mu_bb_l))+(tau*1.0/pow(BBbb_usd_l+Bbb_usda_l/mu_bb_l,2)*(BBbb_usd-BBbb_usd_l+Bbb_usda/mu_bb-Bbb_usda_l/mu_bb_l))/mu_bb_l)*pow(pow(pow(Cbb_ch_p,(eta-1.0)/eta)*pow(-(mu_ch_p*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Cbb_us_p,(eta-1.0)/eta)*pow(-(mu_us_p*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Cbb_rowa_p,(eta-1.0)/eta)*pow(-(mu_aa_p*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Cbb_rowb_p,(eta-1.0)/eta)*pow(-(mu_bb_p*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(a_bb_p,1.0/eta)*pow(-(Caa_rowb_p*mu_aa_p+Cbb_rowb_p*mu_bb_p+Cch_rowb_p*mu_ch_p+Cus_rowb_p*mu_us_p+Ybb_p*mu_bb_p*(phi_bbg-1.0))/mu_bb_p,(eta-1.0)/eta),eta/(eta-1.0))/Cbb,-sig)*1.0/pow(btau_bb_usd-ph_bb_usd*r+(tau*(BBbb_usd-BBbb_usd_l+Bbb_usda/mu_bb-Bbb_usda_l/mu_bb_l))/(BBbb_usd_l+Bbb_usda_l/mu_bb_l)+1.0,2)*pow(pow(Pbb_bb_p,-eta+1.0)*a_bb_p-(mu_ch_p*pow(Pbb_ch_p*(tax_bb_ch_p+1.0),-eta+1.0)*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_us_p*pow(Pbb_us_p*(tax_bb_us_p+1.0),-eta+1.0)*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_aa_p*pow(Pbb_rowa_p*(tax_bb_rowa_p+1.0),-eta+1.0)*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_bb_p*pow(Pbb_rowb_p*(tax_bb_rowb_p+1.0),-eta+1.0)*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/(eta-1.0))*1.0e+2)/(Pus_us*Qusd);
OUT [151] =Pch_ch/mu_us_l;
OUT [207] =(Pch_ch_p*Pus*bet*(tau/(Baa_chya_l+Bbb_chya_l-Bchy_l+Bch_chya_l)+mu_us_l*tau*((Baa_chya+Bbb_chya-Bchy+Bch_chya)/mu_us-(Baa_chya_l+Bbb_chya_l-Bchy_l+Bch_chya_l)/mu_us_l)*1.0/pow(Baa_chya_l+Bbb_chya_l-Bchy_l+Bch_chya_l,2))*pow(pow(pow(Cus_ch_p,(eta-1.0)/eta)*pow(-(mu_ch_p*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p),1.0/eta)+pow(Cus_rowa_p,(eta-1.0)/eta)*pow(-(mu_aa_p*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p),1.0/eta)+pow(Cus_rowb_p,(eta-1.0)/eta)*pow(-(mu_bb_p*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p),1.0/eta)+pow(a_us_p,1.0/eta)*pow(-(Caa_us_p*mu_aa_p+Cbb_us_p*mu_bb_p+Cch_us_p*mu_ch_p+Yus_p*mu_us_p*(phi_usg-1.0))/mu_us_p,(eta-1.0)/eta),eta/(eta-1.0))/Cus,-sig)*(Qchy_p*((pow(mu_us,2)*taup*pow((Baa_chya+Bbb_chya-Bchy+Bch_chya)/mu_us-(Baa_chya_p+Bbb_chya_p-Bchy_p+Bch_chya_p)/mu_us_p,2)*1.0/pow(Baa_chya+Bbb_chya-Bchy+Bch_chya,2))/2.0-(mu_us*taup*((Baa_chya+Bbb_chya-Bchy+Bch_chya)/mu_us-(Baa_chya_p+Bbb_chya_p-Bchy_p+Bch_chya_p)/mu_us_p))/(Baa_chya+Bbb_chya-Bchy+Bch_chya))+1.0)*1.0/pow(btau_us_chy-ph_us_chy*r+(mu_us_l*tau*((Baa_chya+Bbb_chya-Bchy+Bch_chya)/mu_us-(Baa_chya_l+Bbb_chya_l-Bchy_l+Bch_chya_l)/mu_us_l))/(Baa_chya_l+Bbb_chya_l-Bchy_l+Bch_chya_l)+1.0,2)*pow(pow(Pus_us_p,-eta+1.0)*a_us_p-(mu_ch_p*pow(Pus_ch_p*(tax_us_ch_p+1.0),-eta+1.0)*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p)-(mu_aa_p*pow(Pus_rowa_p*(tax_us_aa_p+1.0),-eta+1.0)*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p)-(mu_bb_p*pow(Pus_rowb_p*(tax_us_bb_p+1.0),-eta+1.0)*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p),1.0/(eta-1.0))*-1.0e+2)/(Pch_ch*Qchy);
OUT [213] =(Paa*Pch_ch_p*bet*(Qchy_p*((mu_aa*taup*(Baa_chya/mu_aa-Baa_chya_p/mu_aa_p))/Baa_chya-(1.0/pow(Baa_chya,2)*pow(mu_aa,2)*taup*pow(Baa_chya/mu_aa-Baa_chya_p/mu_aa_p,2))/2.0)-1.0)*pow(pow(pow(Caa_ch_p,(eta-1.0)/eta)*pow(-(mu_ch_p*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Caa_us_p,(eta-1.0)/eta)*pow(-(mu_us_p*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Caa_rowa_p,(eta-1.0)/eta)*pow(-(mu_aa_p*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Caa_rowb_p,(eta-1.0)/eta)*pow(-(mu_bb_p*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(a_aa_p,1.0/eta)*pow(-(Caa_rowa_p*mu_aa_p+Cbb_rowa_p*mu_bb_p+Cch_rowa_p*mu_ch_p+Cus_rowa_p*mu_us_p+Yaa_p*mu_aa_p*(phi_aag-1.0))/mu_aa_p,(eta-1.0)/eta),eta/(eta-1.0))/Caa,-sig)*(tau/Baa_chya_l+1.0/pow(Baa_chya_l,2)*mu_aa_l*tau*(Baa_chya/mu_aa-Baa_chya_l/mu_aa_l))*1.0/pow(btau_aa_chy-ph_aa_chy*r+(mu_aa_l*tau*(Baa_chya/mu_aa-Baa_chya_l/mu_aa_l))/Baa_chya_l+1.0,2)*pow(pow(Paa_aa_p,-eta+1.0)*a_aa_p-(mu_ch_p*pow(Paa_ch_p*(tax_aa_ch_p+1.0),-eta+1.0)*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_us_p*pow(Paa_us_p*(tax_aa_us_p+1.0),-eta+1.0)*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_aa_p*pow(Paa_rowa_p*(tax_aa_rowa_p+1.0),-eta+1.0)*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_bb_p*pow(Paa_rowb_p*(tax_aa_rowb_p+1.0),-eta+1.0)*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/(eta-1.0))*1.0e+2)/(Pch_ch*Qchy);
OUT [218] =-Pch_ch/mu_aa_l;
OUT [225] =Pch_ch/mu_us_l;
OUT [281] =(Pch_ch_p*Pus*bet*(tau/(Baa_chya_l+Bbb_chya_l-Bchy_l+Bch_chya_l)+mu_us_l*tau*((Baa_chya+Bbb_chya-Bchy+Bch_chya)/mu_us-(Baa_chya_l+Bbb_chya_l-Bchy_l+Bch_chya_l)/mu_us_l)*1.0/pow(Baa_chya_l+Bbb_chya_l-Bchy_l+Bch_chya_l,2))*pow(pow(pow(Cus_ch_p,(eta-1.0)/eta)*pow(-(mu_ch_p*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p),1.0/eta)+pow(Cus_rowa_p,(eta-1.0)/eta)*pow(-(mu_aa_p*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p),1.0/eta)+pow(Cus_rowb_p,(eta-1.0)/eta)*pow(-(mu_bb_p*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p),1.0/eta)+pow(a_us_p,1.0/eta)*pow(-(Caa_us_p*mu_aa_p+Cbb_us_p*mu_bb_p+Cch_us_p*mu_ch_p+Yus_p*mu_us_p*(phi_usg-1.0))/mu_us_p,(eta-1.0)/eta),eta/(eta-1.0))/Cus,-sig)*(Qchy_p*((pow(mu_us,2)*taup*pow((Baa_chya+Bbb_chya-Bchy+Bch_chya)/mu_us-(Baa_chya_p+Bbb_chya_p-Bchy_p+Bch_chya_p)/mu_us_p,2)*1.0/pow(Baa_chya+Bbb_chya-Bchy+Bch_chya,2))/2.0-(mu_us*taup*((Baa_chya+Bbb_chya-Bchy+Bch_chya)/mu_us-(Baa_chya_p+Bbb_chya_p-Bchy_p+Bch_chya_p)/mu_us_p))/(Baa_chya+Bbb_chya-Bchy+Bch_chya))+1.0)*1.0/pow(btau_us_chy-ph_us_chy*r+(mu_us_l*tau*((Baa_chya+Bbb_chya-Bchy+Bch_chya)/mu_us-(Baa_chya_l+Bbb_chya_l-Bchy_l+Bch_chya_l)/mu_us_l))/(Baa_chya_l+Bbb_chya_l-Bchy_l+Bch_chya_l)+1.0,2)*pow(pow(Pus_us_p,-eta+1.0)*a_us_p-(mu_ch_p*pow(Pus_ch_p*(tax_us_ch_p+1.0),-eta+1.0)*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p)-(mu_aa_p*pow(Pus_rowa_p*(tax_us_aa_p+1.0),-eta+1.0)*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p)-(mu_bb_p*pow(Pus_rowb_p*(tax_us_bb_p+1.0),-eta+1.0)*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p),1.0/(eta-1.0))*-1.0e+2)/(Pch_ch*Qchy);
OUT [290] =(Pbb*Pch_ch_p*bet*(Qchy_p*((mu_bb*taup*(Bbb_chya/mu_bb-Bbb_chya_p/mu_bb_p))/Bbb_chya-(1.0/pow(Bbb_chya,2)*pow(mu_bb,2)*taup*pow(Bbb_chya/mu_bb-Bbb_chya_p/mu_bb_p,2))/2.0)-1.0)*pow(pow(pow(Cbb_ch_p,(eta-1.0)/eta)*pow(-(mu_ch_p*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Cbb_us_p,(eta-1.0)/eta)*pow(-(mu_us_p*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Cbb_rowa_p,(eta-1.0)/eta)*pow(-(mu_aa_p*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Cbb_rowb_p,(eta-1.0)/eta)*pow(-(mu_bb_p*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(a_bb_p,1.0/eta)*pow(-(Caa_rowb_p*mu_aa_p+Cbb_rowb_p*mu_bb_p+Cch_rowb_p*mu_ch_p+Cus_rowb_p*mu_us_p+Ybb_p*mu_bb_p*(phi_bbg-1.0))/mu_bb_p,(eta-1.0)/eta),eta/(eta-1.0))/Cbb,-sig)*(tau/Bbb_chya_l+1.0/pow(Bbb_chya_l,2)*mu_bb_l*tau*(Bbb_chya/mu_bb-Bbb_chya_l/mu_bb_l))*1.0/pow(btau_bb_chy-ph_bb_chy*r+(mu_bb_l*tau*(Bbb_chya/mu_bb-Bbb_chya_l/mu_bb_l))/Bbb_chya_l+1.0,2)*pow(pow(Pbb_bb_p,-eta+1.0)*a_bb_p-(mu_ch_p*pow(Pbb_ch_p*(tax_bb_ch_p+1.0),-eta+1.0)*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_us_p*pow(Pbb_us_p*(tax_bb_us_p+1.0),-eta+1.0)*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_aa_p*pow(Pbb_rowa_p*(tax_bb_rowa_p+1.0),-eta+1.0)*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_bb_p*pow(Pbb_rowb_p*(tax_bb_rowb_p+1.0),-eta+1.0)*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/(eta-1.0))*1.0e+2)/(Pch_ch*Qchy);
OUT [299] =-Pus_us/mu_us_l;
OUT [303] =Pus_us/mu_ch_l;
OUT [354] =(Pus*Pus_us_p*bet*(Qusd_p*((mu_us*taup*(Bus_usda/mu_us-Bus_usda_p/mu_us_p))/Bus_usda-(1.0/pow(Bus_usda,2)*pow(mu_us,2)*taup*pow(Bus_usda/mu_us-Bus_usda_p/mu_us_p,2))/2.0)-1.0)*pow(pow(pow(Cus_ch_p,(eta-1.0)/eta)*pow(-(mu_ch_p*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p),1.0/eta)+pow(Cus_rowa_p,(eta-1.0)/eta)*pow(-(mu_aa_p*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p),1.0/eta)+pow(Cus_rowb_p,(eta-1.0)/eta)*pow(-(mu_bb_p*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p),1.0/eta)+pow(a_us_p,1.0/eta)*pow(-(Caa_us_p*mu_aa_p+Cbb_us_p*mu_bb_p+Cch_us_p*mu_ch_p+Yus_p*mu_us_p*(phi_usg-1.0))/mu_us_p,(eta-1.0)/eta),eta/(eta-1.0))/Cus,-sig)*(tau/Bus_usda_l+1.0/pow(Bus_usda_l,2)*mu_us_l*tau*(Bus_usda/mu_us-Bus_usda_l/mu_us_l))*1.0/pow(-ph_us_usd*r+(mu_us_l*tau*(Bus_usda/mu_us-Bus_usda_l/mu_us_l))/Bus_usda_l+1.0,2)*pow(pow(Pus_us_p,-eta+1.0)*a_us_p-(mu_ch_p*pow(Pus_ch_p*(tax_us_ch_p+1.0),-eta+1.0)*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p)-(mu_aa_p*pow(Pus_rowa_p*(tax_us_aa_p+1.0),-eta+1.0)*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p)-(mu_bb_p*pow(Pus_rowb_p*(tax_us_bb_p+1.0),-eta+1.0)*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p),1.0/(eta-1.0))*1.0e+2)/(Pus_us*Qusd);
OUT [357] =(Pch*Pus_us_p*bet*(Qusd_p*((pow(mu_ch,2)*taup*pow((Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb))/mu_ch-(Baa_usda_p-Busd_p+Bus_usda_p+mu_bb_p*(BBbb_usd_p+Bbb_usda_p/mu_bb_p))/mu_ch_p,2)*1.0/pow(Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb),2))/2.0-(mu_ch*taup*((Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb))/mu_ch-(Baa_usda_p-Busd_p+Bus_usda_p+mu_bb_p*(BBbb_usd_p+Bbb_usda_p/mu_bb_p))/mu_ch_p))/(Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb)))+1.0)*pow(pow(pow(Cch_us_p,(eta-1.0)/eta)*pow(-(mu_us_p*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p),1.0/eta)+pow(Cch_rowa_p,(eta-1.0)/eta)*pow(-(mu_aa_p*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p),1.0/eta)+pow(Cch_rowb_p,(eta-1.0)/eta)*pow(-(mu_bb_p*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p),1.0/eta)+pow(a_ch_p,1.0/eta)*pow(-(Caa_ch_p*mu_aa_p+Cbb_ch_p*mu_bb_p+Cus_ch_p*mu_us_p+Ych_p*mu_ch_p*(phi_chg-1.0))/mu_ch_p,(eta-1.0)/eta),eta/(eta-1.0))/Cch,-sig)*(tau/(Baa_usda_l-Busd_l+Bus_usda_l+mu_bb_l*(BBbb_usd_l+Bbb_usda_l/mu_bb_l))+mu_ch_l*tau*((Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb))/mu_ch-(Baa_usda_l-Busd_l+Bus_usda_l+mu_bb_l*(BBbb_usd_l+Bbb_usda_l/mu_bb_l))/mu_ch_l)*1.0/pow(Baa_usda_l-Busd_l+Bus_usda_l+mu_bb_l*(BBbb_usd_l+Bbb_usda_l/mu_bb_l),2))*1.0/pow(btau_ch_usd-ph_ch_usd*r+(mu_ch_l*tau*((Baa_usda-Busd+Bus_usda+mu_bb*(BBbb_usd+Bbb_usda/mu_bb))/mu_ch-(Baa_usda_l-Busd_l+Bus_usda_l+mu_bb_l*(BBbb_usd_l+Bbb_usda_l/mu_bb_l))/mu_ch_l))/(Baa_usda_l-Busd_l+Bus_usda_l+mu_bb_l*(BBbb_usd_l+Bbb_usda_l/mu_bb_l))+1.0,2)*pow(pow(Pch_ch_p,-eta+1.0)*a_ch_p-(mu_us_p*pow(Pch_us_p*(tax_ch_us_p+1.0),-eta+1.0)*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p)-(mu_aa_p*pow(Pch_rowa_p*(tax_ch_aa_p+1.0),-eta+1.0)*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p)-(mu_bb_p*pow(Pch_rowb_p*(tax_ch_bb_p+1.0),-eta+1.0)*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p),1.0/(eta-1.0))*-1.0e+2)/(Pus_us*Qusd);
OUT [373] =Pch_ch/mu_us_l;
OUT [377] =-Pch_ch/mu_ch_l;
OUT [429] =(Pch_ch_p*Pus*bet*(tau/(Baa_chya_l+Bbb_chya_l-Bchy_l+Bch_chya_l)+mu_us_l*tau*((Baa_chya+Bbb_chya-Bchy+Bch_chya)/mu_us-(Baa_chya_l+Bbb_chya_l-Bchy_l+Bch_chya_l)/mu_us_l)*1.0/pow(Baa_chya_l+Bbb_chya_l-Bchy_l+Bch_chya_l,2))*pow(pow(pow(Cus_ch_p,(eta-1.0)/eta)*pow(-(mu_ch_p*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p),1.0/eta)+pow(Cus_rowa_p,(eta-1.0)/eta)*pow(-(mu_aa_p*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p),1.0/eta)+pow(Cus_rowb_p,(eta-1.0)/eta)*pow(-(mu_bb_p*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p),1.0/eta)+pow(a_us_p,1.0/eta)*pow(-(Caa_us_p*mu_aa_p+Cbb_us_p*mu_bb_p+Cch_us_p*mu_ch_p+Yus_p*mu_us_p*(phi_usg-1.0))/mu_us_p,(eta-1.0)/eta),eta/(eta-1.0))/Cus,-sig)*(Qchy_p*((pow(mu_us,2)*taup*pow((Baa_chya+Bbb_chya-Bchy+Bch_chya)/mu_us-(Baa_chya_p+Bbb_chya_p-Bchy_p+Bch_chya_p)/mu_us_p,2)*1.0/pow(Baa_chya+Bbb_chya-Bchy+Bch_chya,2))/2.0-(mu_us*taup*((Baa_chya+Bbb_chya-Bchy+Bch_chya)/mu_us-(Baa_chya_p+Bbb_chya_p-Bchy_p+Bch_chya_p)/mu_us_p))/(Baa_chya+Bbb_chya-Bchy+Bch_chya))+1.0)*1.0/pow(btau_us_chy-ph_us_chy*r+(mu_us_l*tau*((Baa_chya+Bbb_chya-Bchy+Bch_chya)/mu_us-(Baa_chya_l+Bbb_chya_l-Bchy_l+Bch_chya_l)/mu_us_l))/(Baa_chya_l+Bbb_chya_l-Bchy_l+Bch_chya_l)+1.0,2)*pow(pow(Pus_us_p,-eta+1.0)*a_us_p-(mu_ch_p*pow(Pus_ch_p*(tax_us_ch_p+1.0),-eta+1.0)*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p)-(mu_aa_p*pow(Pus_rowa_p*(tax_us_aa_p+1.0),-eta+1.0)*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p)-(mu_bb_p*pow(Pus_rowb_p*(tax_us_bb_p+1.0),-eta+1.0)*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p),1.0/(eta-1.0))*-1.0e+2)/(Pch_ch*Qchy);
OUT [432] =(Pch*Pch_ch_p*bet*(Qchy_p*((mu_ch*taup*(Bch_chya/mu_ch-Bch_chya_p/mu_ch_p))/Bch_chya-(1.0/pow(Bch_chya,2)*pow(mu_ch,2)*taup*pow(Bch_chya/mu_ch-Bch_chya_p/mu_ch_p,2))/2.0)-1.0)*pow(pow(pow(Cch_us_p,(eta-1.0)/eta)*pow(-(mu_us_p*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p),1.0/eta)+pow(Cch_rowa_p,(eta-1.0)/eta)*pow(-(mu_aa_p*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p),1.0/eta)+pow(Cch_rowb_p,(eta-1.0)/eta)*pow(-(mu_bb_p*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p),1.0/eta)+pow(a_ch_p,1.0/eta)*pow(-(Caa_ch_p*mu_aa_p+Cbb_ch_p*mu_bb_p+Cus_ch_p*mu_us_p+Ych_p*mu_ch_p*(phi_chg-1.0))/mu_ch_p,(eta-1.0)/eta),eta/(eta-1.0))/Cch,-sig)*(tau/Bch_chya_l+1.0/pow(Bch_chya_l,2)*mu_ch_l*tau*(Bch_chya/mu_ch-Bch_chya_l/mu_ch_l))*1.0/pow(-ph_ch_chy*r+(mu_ch_l*tau*(Bch_chya/mu_ch-Bch_chya_l/mu_ch_l))/Bch_chya_l+1.0,2)*pow(pow(Pch_ch_p,-eta+1.0)*a_ch_p-(mu_us_p*pow(Pch_us_p*(tax_ch_us_p+1.0),-eta+1.0)*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p)-(mu_aa_p*pow(Pch_rowa_p*(tax_ch_aa_p+1.0),-eta+1.0)*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p)-(mu_bb_p*pow(Pch_rowb_p*(tax_ch_bb_p+1.0),-eta+1.0)*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p),1.0/(eta-1.0))*1.0e+2)/(Pch_ch*Qchy);
OUT [447] =-1.0/mu_us_l;
OUT [504] =(Pus*bet*(Qrow_p*((mu_us*taup*(Bus_rowa/mu_us-Bus_rowa_p/mu_us_p))/Bus_rowa-(1.0/pow(Bus_rowa,2)*pow(mu_us,2)*taup*pow(Bus_rowa/mu_us-Bus_rowa_p/mu_us_p,2))/2.0)-1.0)*pow(pow(pow(Cus_ch_p,(eta-1.0)/eta)*pow(-(mu_ch_p*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p),1.0/eta)+pow(Cus_rowa_p,(eta-1.0)/eta)*pow(-(mu_aa_p*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p),1.0/eta)+pow(Cus_rowb_p,(eta-1.0)/eta)*pow(-(mu_bb_p*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p),1.0/eta)+pow(a_us_p,1.0/eta)*pow(-(Caa_us_p*mu_aa_p+Cbb_us_p*mu_bb_p+Cch_us_p*mu_ch_p+Yus_p*mu_us_p*(phi_usg-1.0))/mu_us_p,(eta-1.0)/eta),eta/(eta-1.0))/Cus,-sig)*(tau/Bus_rowa_l+1.0/pow(Bus_rowa_l,2)*mu_us_l*tau*(Bus_rowa/mu_us-Bus_rowa_l/mu_us_l))*1.0/pow(-ph_us_row*r+(mu_us_l*tau*(Bus_rowa/mu_us-Bus_rowa_l/mu_us_l))/Bus_rowa_l+1.0,2)*pow(pow(Pus_us_p,-eta+1.0)*a_us_p-(mu_ch_p*pow(Pus_ch_p*(tax_us_ch_p+1.0),-eta+1.0)*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p)-(mu_aa_p*pow(Pus_rowa_p*(tax_us_aa_p+1.0),-eta+1.0)*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p)-(mu_bb_p*pow(Pus_rowb_p*(tax_us_bb_p+1.0),-eta+1.0)*(a_us_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p),1.0/(eta-1.0))*1.0e+2)/Qrow;
OUT [513] =(Pbb*bet*(Qrow_p*((pow(mu_bb,2)*taup*pow((-Baa+Baa_rowa-Bbb+Bch_rowa+Bus_rowa)/mu_bb-(-Baa+Baa_rowa_p-Bbb+Bch_rowa_p+Bus_rowa_p)/mu_bb_p,2)*1.0/pow(-Baa+Baa_rowa-Bbb+Bch_rowa+Bus_rowa,2))/2.0-(mu_bb*taup*((-Baa+Baa_rowa-Bbb+Bch_rowa+Bus_rowa)/mu_bb-(-Baa+Baa_rowa_p-Bbb+Bch_rowa_p+Bus_rowa_p)/mu_bb_p))/(-Baa+Baa_rowa-Bbb+Bch_rowa+Bus_rowa))+1.0)*(tau/(-Baa+Baa_rowa_l-Bbb+Bch_rowa_l+Bus_rowa_l)+mu_bb_l*tau*((-Baa+Baa_rowa-Bbb+Bch_rowa+Bus_rowa)/mu_bb-(-Baa+Baa_rowa_l-Bbb+Bch_rowa_l+Bus_rowa_l)/mu_bb_l)*1.0/pow(-Baa+Baa_rowa_l-Bbb+Bch_rowa_l+Bus_rowa_l,2))*pow(pow(pow(Cbb_ch_p,(eta-1.0)/eta)*pow(-(mu_ch_p*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Cbb_us_p,(eta-1.0)/eta)*pow(-(mu_us_p*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Cbb_rowa_p,(eta-1.0)/eta)*pow(-(mu_aa_p*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Cbb_rowb_p,(eta-1.0)/eta)*pow(-(mu_bb_p*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(a_bb_p,1.0/eta)*pow(-(Caa_rowb_p*mu_aa_p+Cbb_rowb_p*mu_bb_p+Cch_rowb_p*mu_ch_p+Cus_rowb_p*mu_us_p+Ybb_p*mu_bb_p*(phi_bbg-1.0))/mu_bb_p,(eta-1.0)/eta),eta/(eta-1.0))/Cbb,-sig)*1.0/pow(-ph_bb_row*r+(mu_bb_l*tau*((-Baa+Baa_rowa-Bbb+Bch_rowa+Bus_rowa)/mu_bb-(-Baa+Baa_rowa_l-Bbb+Bch_rowa_l+Bus_rowa_l)/mu_bb_l))/(-Baa+Baa_rowa_l-Bbb+Bch_rowa_l+Bus_rowa_l)+1.0,2)*pow(pow(Pbb_bb_p,-eta+1.0)*a_bb_p-(mu_ch_p*pow(Pbb_ch_p*(tax_bb_ch_p+1.0),-eta+1.0)*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_us_p*pow(Pbb_us_p*(tax_bb_us_p+1.0),-eta+1.0)*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_aa_p*pow(Pbb_rowa_p*(tax_bb_rowa_p+1.0),-eta+1.0)*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_bb_p*pow(Pbb_rowb_p*(tax_bb_rowb_p+1.0),-eta+1.0)*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/(eta-1.0))*-1.0e+2)/Qrow;
OUT [525] =-1.0/mu_ch_l;
OUT [581] =(Pch*bet*(Qrow_p*((mu_ch*taup*(Bch_rowa/mu_ch-Bch_rowa_p/mu_ch_p))/Bch_rowa-(1.0/pow(Bch_rowa,2)*pow(mu_ch,2)*taup*pow(Bch_rowa/mu_ch-Bch_rowa_p/mu_ch_p,2))/2.0)-1.0)*pow(pow(pow(Cch_us_p,(eta-1.0)/eta)*pow(-(mu_us_p*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p),1.0/eta)+pow(Cch_rowa_p,(eta-1.0)/eta)*pow(-(mu_aa_p*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p),1.0/eta)+pow(Cch_rowb_p,(eta-1.0)/eta)*pow(-(mu_bb_p*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p),1.0/eta)+pow(a_ch_p,1.0/eta)*pow(-(Caa_ch_p*mu_aa_p+Cbb_ch_p*mu_bb_p+Cus_ch_p*mu_us_p+Ych_p*mu_ch_p*(phi_chg-1.0))/mu_ch_p,(eta-1.0)/eta),eta/(eta-1.0))/Cch,-sig)*(tau/Bch_rowa_l+1.0/pow(Bch_rowa_l,2)*mu_ch_l*tau*(Bch_rowa/mu_ch-Bch_rowa_l/mu_ch_l))*1.0/pow(-ph_ch_row*r+(mu_ch_l*tau*(Bch_rowa/mu_ch-Bch_rowa_l/mu_ch_l))/Bch_rowa_l+1.0,2)*pow(pow(Pch_ch_p,-eta+1.0)*a_ch_p-(mu_us_p*pow(Pch_us_p*(tax_ch_us_p+1.0),-eta+1.0)*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p)-(mu_aa_p*pow(Pch_rowa_p*(tax_ch_aa_p+1.0),-eta+1.0)*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p)-(mu_bb_p*pow(Pch_rowb_p*(tax_ch_bb_p+1.0),-eta+1.0)*(a_ch_p-1.0))/(mu_aa_p+mu_bb_p+mu_us_p),1.0/(eta-1.0))*1.0e+2)/Qrow;
OUT [587] =(Pbb*bet*(Qrow_p*((pow(mu_bb,2)*taup*pow((-Baa+Baa_rowa-Bbb+Bch_rowa+Bus_rowa)/mu_bb-(-Baa+Baa_rowa_p-Bbb+Bch_rowa_p+Bus_rowa_p)/mu_bb_p,2)*1.0/pow(-Baa+Baa_rowa-Bbb+Bch_rowa+Bus_rowa,2))/2.0-(mu_bb*taup*((-Baa+Baa_rowa-Bbb+Bch_rowa+Bus_rowa)/mu_bb-(-Baa+Baa_rowa_p-Bbb+Bch_rowa_p+Bus_rowa_p)/mu_bb_p))/(-Baa+Baa_rowa-Bbb+Bch_rowa+Bus_rowa))+1.0)*(tau/(-Baa+Baa_rowa_l-Bbb+Bch_rowa_l+Bus_rowa_l)+mu_bb_l*tau*((-Baa+Baa_rowa-Bbb+Bch_rowa+Bus_rowa)/mu_bb-(-Baa+Baa_rowa_l-Bbb+Bch_rowa_l+Bus_rowa_l)/mu_bb_l)*1.0/pow(-Baa+Baa_rowa_l-Bbb+Bch_rowa_l+Bus_rowa_l,2))*pow(pow(pow(Cbb_ch_p,(eta-1.0)/eta)*pow(-(mu_ch_p*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Cbb_us_p,(eta-1.0)/eta)*pow(-(mu_us_p*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Cbb_rowa_p,(eta-1.0)/eta)*pow(-(mu_aa_p*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Cbb_rowb_p,(eta-1.0)/eta)*pow(-(mu_bb_p*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(a_bb_p,1.0/eta)*pow(-(Caa_rowb_p*mu_aa_p+Cbb_rowb_p*mu_bb_p+Cch_rowb_p*mu_ch_p+Cus_rowb_p*mu_us_p+Ybb_p*mu_bb_p*(phi_bbg-1.0))/mu_bb_p,(eta-1.0)/eta),eta/(eta-1.0))/Cbb,-sig)*1.0/pow(-ph_bb_row*r+(mu_bb_l*tau*((-Baa+Baa_rowa-Bbb+Bch_rowa+Bus_rowa)/mu_bb-(-Baa+Baa_rowa_l-Bbb+Bch_rowa_l+Bus_rowa_l)/mu_bb_l))/(-Baa+Baa_rowa_l-Bbb+Bch_rowa_l+Bus_rowa_l)+1.0,2)*pow(pow(Pbb_bb_p,-eta+1.0)*a_bb_p-(mu_ch_p*pow(Pbb_ch_p*(tax_bb_ch_p+1.0),-eta+1.0)*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_us_p*pow(Pbb_us_p*(tax_bb_us_p+1.0),-eta+1.0)*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_aa_p*pow(Pbb_rowa_p*(tax_bb_rowa_p+1.0),-eta+1.0)*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_bb_p*pow(Pbb_rowb_p*(tax_bb_rowb_p+1.0),-eta+1.0)*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/(eta-1.0))*-1.0e+2)/Qrow;
OUT [658] =(Paa*bet*(Qrow_p*((mu_aa*taup*(Baa_rowa/mu_aa-Baa_rowa_p/mu_aa_p))/Baa_rowa-(1.0/pow(Baa_rowa,2)*pow(mu_aa,2)*taup*pow(Baa_rowa/mu_aa-Baa_rowa_p/mu_aa_p,2))/2.0)-1.0)*pow(pow(pow(Caa_ch_p,(eta-1.0)/eta)*pow(-(mu_ch_p*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Caa_us_p,(eta-1.0)/eta)*pow(-(mu_us_p*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Caa_rowa_p,(eta-1.0)/eta)*pow(-(mu_aa_p*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Caa_rowb_p,(eta-1.0)/eta)*pow(-(mu_bb_p*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(a_aa_p,1.0/eta)*pow(-(Caa_rowa_p*mu_aa_p+Cbb_rowa_p*mu_bb_p+Cch_rowa_p*mu_ch_p+Cus_rowa_p*mu_us_p+Yaa_p*mu_aa_p*(phi_aag-1.0))/mu_aa_p,(eta-1.0)/eta),eta/(eta-1.0))/Caa,-sig)*(tau/Baa_rowa_l+1.0/pow(Baa_rowa_l,2)*mu_aa_l*tau*(Baa_rowa/mu_aa-Baa_rowa_l/mu_aa_l))*1.0/pow(-ph_aa_row*r+(mu_aa_l*tau*(Baa_rowa/mu_aa-Baa_rowa_l/mu_aa_l))/Baa_rowa_l+1.0,2)*pow(pow(Paa_aa_p,-eta+1.0)*a_aa_p-(mu_ch_p*pow(Paa_ch_p*(tax_aa_ch_p+1.0),-eta+1.0)*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_us_p*pow(Paa_us_p*(tax_aa_us_p+1.0),-eta+1.0)*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_aa_p*pow(Paa_rowa_p*(tax_aa_rowa_p+1.0),-eta+1.0)*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_bb_p*pow(Paa_rowb_p*(tax_aa_rowb_p+1.0),-eta+1.0)*(a_aa_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/(eta-1.0))*1.0e+2)/Qrow;
OUT [661] =(Pbb*bet*(Qrow_p*((pow(mu_bb,2)*taup*pow((-Baa+Baa_rowa-Bbb+Bch_rowa+Bus_rowa)/mu_bb-(-Baa+Baa_rowa_p-Bbb+Bch_rowa_p+Bus_rowa_p)/mu_bb_p,2)*1.0/pow(-Baa+Baa_rowa-Bbb+Bch_rowa+Bus_rowa,2))/2.0-(mu_bb*taup*((-Baa+Baa_rowa-Bbb+Bch_rowa+Bus_rowa)/mu_bb-(-Baa+Baa_rowa_p-Bbb+Bch_rowa_p+Bus_rowa_p)/mu_bb_p))/(-Baa+Baa_rowa-Bbb+Bch_rowa+Bus_rowa))+1.0)*(tau/(-Baa+Baa_rowa_l-Bbb+Bch_rowa_l+Bus_rowa_l)+mu_bb_l*tau*((-Baa+Baa_rowa-Bbb+Bch_rowa+Bus_rowa)/mu_bb-(-Baa+Baa_rowa_l-Bbb+Bch_rowa_l+Bus_rowa_l)/mu_bb_l)*1.0/pow(-Baa+Baa_rowa_l-Bbb+Bch_rowa_l+Bus_rowa_l,2))*pow(pow(pow(Cbb_ch_p,(eta-1.0)/eta)*pow(-(mu_ch_p*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Cbb_us_p,(eta-1.0)/eta)*pow(-(mu_us_p*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Cbb_rowa_p,(eta-1.0)/eta)*pow(-(mu_aa_p*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(Cbb_rowb_p,(eta-1.0)/eta)*pow(-(mu_bb_p*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/eta)+pow(a_bb_p,1.0/eta)*pow(-(Caa_rowb_p*mu_aa_p+Cbb_rowb_p*mu_bb_p+Cch_rowb_p*mu_ch_p+Cus_rowb_p*mu_us_p+Ybb_p*mu_bb_p*(phi_bbg-1.0))/mu_bb_p,(eta-1.0)/eta),eta/(eta-1.0))/Cbb,-sig)*1.0/pow(-ph_bb_row*r+(mu_bb_l*tau*((-Baa+Baa_rowa-Bbb+Bch_rowa+Bus_rowa)/mu_bb-(-Baa+Baa_rowa_l-Bbb+Bch_rowa_l+Bus_rowa_l)/mu_bb_l))/(-Baa+Baa_rowa_l-Bbb+Bch_rowa_l+Bus_rowa_l)+1.0,2)*pow(pow(Pbb_bb_p,-eta+1.0)*a_bb_p-(mu_ch_p*pow(Pbb_ch_p*(tax_bb_ch_p+1.0),-eta+1.0)*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_us_p*pow(Pbb_us_p*(tax_bb_us_p+1.0),-eta+1.0)*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_aa_p*pow(Pbb_rowa_p*(tax_bb_rowa_p+1.0),-eta+1.0)*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p)-(mu_bb_p*pow(Pbb_rowb_p*(tax_bb_rowb_p+1.0),-eta+1.0)*(a_bb_p-1.0))/(mu_aa_p+mu_bb_p+mu_ch_p+mu_us_p),1.0/(eta-1.0))*-1.0e+2)/Qrow;
OUT [662] =-1.0/mu_aa_l;

                            
                  
}




