% SHOOTING_SOLVE - Script for solving the shooting problem for given
% starting point/paramterization. This script relies on user to set the
% right environment parmaeters before calling it.

T = Tshoot*per_p_year;
log_idx = [];


X0 = frac2B(frac_shoot(:),Busd(1),Bchy(1),Baa,Bbb,mu_us,mu_ch,mu_aa,mu_bb,BBbb_usd(1));


%starting value
if ~exist('xshoot_final','var') || length(xshoot_final)~=T
    xshoot = repmat(targ_ss,[1,T]);
else
    disp('using saved start');
    xshoot = xshoot_final;
end

%Log stuff
targ_ss(log_idx,:) = log(targ_ss(log_idx,:));
xshoot (log_idx,:) = log(xshoot (log_idx,:));

assemble_params
shoot_ = @(x) shooting(x,X0,targ_ss,T,log_idx,nx,ny,[],dynargs{:});

% SETUP
tic

options = optimoptions('fsolve');
options.Display = 'iter';%options.Display = 'iter';
options.MaxIterations = 60;
%options.FiniteDifferenceType = 'central';
options.SpecifyObjectiveGradient = true;
options.CheckGradients = false;

[a0,b] = shoot_(xshoot(:));

% FSOLVE CALL
xfinal_tmp = fsolve(shoot_,xshoot(:),options);

% COMPUTE VARIABLES TO PLOT FROM FLIGHT
[resid_final,~,xshoot_final,dfinal,usd_shrs,usd_use,con_out,tb_out,ep_out,nfa_out,prices_out,delts_out,walras_out,tau_out,taup_out,returns_out,irs_out,bonds_out,wimps_out,wexps_out] = shoot_(xfinal_tmp);

%the final paths
xshoot_final(log_idx,:) = exp(xshoot_final(log_idx,:));
frac_path = [frac_shoot(:),B2frac(xshoot_final(ny+(1:nx),:),Busd,Bchy,Baa,Bbb,mu_us,mu_ch,mu_aa,mu_bb,BBbb_usd(min(length(BBbb_usd),2):max(length(BBbb_usd)-1,1)))];
bond_path = [X0,xshoot_final(ny+(1:nx),:)];

%consumption equivalents for each country in each case
U_flt = NaN(4,2000);
for jj = 1:2000
    if sig ~= 1
        U_flt(:,jj) = bet^(jj-1)*(con_out(:,jj).^(1 - sig))./(1 - sig);
    else
        U_flt(:,jj) = bet^(jj-1)*log(con_out(:,min(jj,T-1)));
    end
    
end
welf = sum(U_flt,2);
cons_equiv  = (exp( (1- bet)*welf));
cons_steady = con_out(:,end);

[resid_sorted, sort_ind] = sort(resid_final);
nvar = ny+nx;

disp(['FINAL RESID:' num2str(sum(resid_final(:).^2)), '|| FINAL CHANGE: ' num2str(sum(dfinal.^2)) ' || Time taken: ' num2str(toc) ]);

