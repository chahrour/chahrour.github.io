%% FIGURE 5(a): 15% ASYM TRADE WAR - ATTRACTION REGIONS

load saved_results/steady_symbaseline.mat frac_ss
frac_old = frac_ss;

load saved_results/attraction_region_unilateral40 solve_indic* frac_rw_usd_dense frac_rw_chy_dense frac_ss


solve_indic_usd = solve_indic_right<1e-5;
solve_indic_chy = solve_indic_top'<1e-5;
solve_indic_both = (solve_indic_usd+solve_indic_chy)==2;

solve_indic_usdonly = solve_indic_usd-solve_indic_both;
solve_indic_chyonly = solve_indic_chy-solve_indic_both;


f1 = figure;
s = subplot(1,1,1);hold on;
s.XLim = frac_rw_usd_dense([1,end]);
s.YLim = frac_rw_chy_dense([1,end]);
s.FontSize = 14;

fgrid      = frac_rw_usd_dense;
fgrid_flip = fliplr(frac_rw_usd_dense);

np = length(frac_rw_chy_dense);

%Multi
[X,Ym] = shrinkwrap(solve_indic_both,fgrid,fgrid,'below');
[X,Ym] = shrinkwrap(solve_indic_both,fgrid,fgrid,'above',X,Ym);
p3 = patch(X(~isnan(Ym)),Ym(~isnan(Ym)), color_mul);
p3.LineStyle = '-';
p3.LineWidth = .1;
p3.FaceAlpha = 0.8;

%USD zone
[X,Y] = shrinkwrap(solve_indic_usdonly,fgrid,fgrid,'above');
Y(end:-1:end-np+1) = Ym(1:np); %Sub in the bottom of the multi range
p1= patch(X(~isnan(Y)),Y(~isnan(Y)), color_usd);
p1.LineStyle = '-';
p1.LineWidth = .1;
p1.FaceAlpha = 0.8;


%Euro zone
[X,Y] = shrinkwrap(solve_indic_chyonly,fgrid,fgrid,'below');
Y(1:np) = Ym(end:-1:end-np+1); %Sub in top of multi range
p2 = patch(X(~isnan(Y)),Y(~isnan(Y)), color_chy);
p2.LineStyle = '-';
p2.LineWidth = .1;
p2.FaceAlpha = 0.8;



p = scatter(frac_ss(1,[1,3]),frac_ss(3,[1,3]), 'marker', 'o', 'SizeData',75, 'MarkerEdgeColor', [0,0,0], 'MarkerFaceColor', [0 0 0]);
p = scatter(frac_ss(1,2),frac_ss(3,2), 'marker', 'o', 'SizeData', 90, 'MarkerEdgeColor', [0,0,0], 'MarkerFaceColor', [1 1 1]);
p = scatter(frac_old(1,1),frac_old(3,1), 'marker', 'x', 'SizeData', 100, 'MarkerEdgeColor', [0,0,0], 'MarkerFaceColor', [1 1 1]);

xlabel('RW USD bond holdings (fraction of $\bar{B}$)', 'interpreter', 'latex', 'fontsize',18);
ylabel('RW CNY bond holdings (fraction of $\bar{B}$)', 'interpreter', 'latex', 'fontsize',18);


l = legend([p1,p2,p3],'USD','CNY', 'Indet.', 'location', 'southwest');
l.FontSize = 14;
saveas(f1, 'saved_figures/figure5.eps', 'epsc')

return
%% FIGURE 5(b): 30% ASYM TRADEWARE - ATTRACTION REGIONS
load saved_results/steady_baseline frac_ss
frac_old = frac_ss(:,1);

load saved_results/dollar_to_chyo_tradewar_transition frac_path
load saved_results/steady_usrowwar30.mat frac_ss


f1 = figure;
s = subplot(1,1,1);hold on;
s.XLim = [.15,.85];
s.YLim = [.15,.85];
s.FontSize = 14;


X = [.15 .85 .85 .15];
Y = [.15 .15 .85 .85];
p3 = fill(X,Y, color_chy);
p3.LineStyle = '-';
p3.LineWidth = .1;

p = scatter(frac_ss(1,:),frac_ss(2,:), 'marker', 'o', 'SizeData',75, 'MarkerEdgeColor', [0,0,0], 'MarkerFaceColor', [0 0 0]);
p = scatter(frac_old(1),frac_old(2), 'marker', 'x', 'SizeData', 90, 'MarkerEdgeColor', [0,0,0], 'MarkerFaceColor', [1 1 1]);

xlabel('RW USD bond holdings (fraction of $\bar{B}$)', 'interpreter', 'latex', 'fontsize',18);
ylabel('RW EUR bond holdings (fraction of $\bar{B}$)', 'interpreter', 'latex', 'fontsize',18);

%Add flight path to region
p = plot(frac_path(1,1:80),frac_path(2,1:80), '-k', 'linewidth', 2.5);
a=annotation('arrow', frac_path(1,[80,end-75]), frac_path(2,[80,end-75]));
a.Parent     = gca;
a.HeadWidth  = 8;
a.HeadLength = 8;
a.Color  = [.7,.7,.7]';
p.Color  = [.7,.7,.7]';



saveas(f1, 'saved_figures/figure5b.eps', 'epsc')