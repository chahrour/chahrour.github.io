    %Table statistics for the steady-state
    
    
    tmp(jj) = walras_residual(xspecial_long(:,jj),xspecial_long(:,jj),xspecial_long(ny+(1:nx),jj),log_idx,dynargs{:});
    
    frac_ss(:,jj) = B2frac(xspecial_long(ny+(1:nx),jj),Busd,Bchy,Baa,Bbb,mu_us,mu_ch,mu_aa,mu_bb,BBbb_usd);
    
    Xrw_all(:,jj) = Xrw(:);
    table_dat(1,(jj-1)*4+(1:4)) = [Xus,Xch,Xrw(:)'];
    table_dat(2,(jj-1)*4+(1:4)) = EPs;
    table_dat(3,(jj-1)*4+(1:4)) = 100*IRs(1:4);
    table_dat(4,(jj-1)*4+(1:4)) = NFAs;
    table_dat(5,(jj-1)*4+(1:4)) = GROSSs(1,:);
    
    table_dat(6,(jj-1)*4+(1:4)) = 100*TBs;
    table_dat(7,(jj-1)*4+(1:4)) = Cs;
    
    cons_steady(:,jj) = [Cus,Cch,Caa,Cbb];
    
    CCs{1,jj} = CUSs;
    CCs{2,jj} = CCHs;
    CCs{3,jj} = CRWs;
    
    if abs(tmp(jj))>1e-6
        error('Walras is breaking the law.')
    end