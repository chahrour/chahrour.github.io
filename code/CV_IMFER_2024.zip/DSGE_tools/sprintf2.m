function out = sprintf2(a1,a2)

out = sprintf(a1,a2);

if out(1)~= '-'
    out = [' ' out];
end

idx = strfind(out,'NaN')

if ~isempty(idx)
out(idx:idx+2) = '---';
end