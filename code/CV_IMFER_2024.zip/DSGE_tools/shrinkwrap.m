function [X,Y,fig] = shrinkwrap(idx,gridx,gridy,opt,X0,Y0)

ny = length(gridy);
nx = length(gridx);
if nargin<5
    X = [gridx,fliplr(gridx)];
    Y = [min(gridy)*ones(1,ny), max(gridy)*ones(1,ny)];
else
    X = X0;
    Y = Y0;
end

stepy = mean(diff(gridy));
stepx = mean(diff(gridx));
if strcmp(opt,'above')
    for ii = 1:nx
        idxy_max = find(idx(:,ii),1,'last');
       
        if isempty(idxy_max)
            Y(ii)      = NaN;
            Y(2*nx+1-ii) = NaN;
        else
            %Y(2*nx+1-ii) = gridy(idxy_max)+.5*stepy; %Average of last 2
            Y(2*nx+1-ii) = .5*gridy(idxy_max) + .5*gridy(min(end,idxy_max+1));
        end
        
    end
end


if strcmp(opt,'below')
    for ii = 1:nx
        idxy_max = find(idx(:,ii),1,'first');
        if isempty(idxy_max)
            Y(ii)      = NaN;
            Y(2*nx+1-ii) = NaN;
        else
            %Y(ii) = gridy(idxy_max) - .5*stepy;
            Y(ii) = .5*gridy(idxy_max) + .5*gridy(max(1,idxy_max-1));
        end
    end
end
  
if nargout > 2
    [X;Y]'
    size(ans)
    fig = figure;
    patch(X,Y, [.5,.5,.5])
end