function out = vec(x)

out =x(:);