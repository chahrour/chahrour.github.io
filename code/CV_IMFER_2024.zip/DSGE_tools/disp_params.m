param_list = {'Busd', 'Bchy', 'Baa','Bbb', 'vepsf',  'phi', 'r', 'sige', 'kap' , 'a_us','a_aa','eta' 'zrow'};


for jj = 1:length(param_list)
disp([sprintf('%s       \t', param_list{jj}), ': ', sprintf('%1.13f', eval(param_list{jj}))]);
end

