
%Slow way to get a unqiue and ordered set of symbolic arguments
function out = sym_args(init,block1)

block1_str = char(block1);

init  = unique(init);
nargs = length(init);
out = sym(zeros(1,nargs-length(block1)));

ww = 1;
%drop any arg that appears in block 1
for jj = 1:nargs
    keep = true;
    
    schar =  char(init(jj));
    tester = [strfind(block1_str, [' ' schar ',']),...
              strfind(block1_str, ['[',schar,',']),...
              strfind(block1_str, [' ',schar,']'])];
    if ~isempty(tester)
        keep = false;
    end
    
    %The old way.
%    for mm = 1:length(block1)
%         if isequal(init(jj),block1(mm))
%             keep = false;
%         end
 %   end
    
    if keep
        out(ww) = init(jj);
        ww = ww+1;
    end
    
end