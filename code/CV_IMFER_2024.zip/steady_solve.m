% STEADY_SOLVE - Solve for steady-states of the economy for a variaty of
% parameterizations. Calls steady_state_finder.m

%Dec 8, 10:35am, all working fine. Going to make some big changes, may want
%to revert.

%Dec 13, 4:03pm, all working fine and have base calibration. Going to make
%big changes, in case want to revert.

setup

% KEY SAVED FILES
save_me = true;

%This code solves for the steady-state of the model
load saved_results/idx_vars
ny = ny;

nvar    = ny+nx;
neq     = nvar;

nvarss  = ny;
neqss   = nvarss+1;
nstate  = nx;


s_idx  = [sbar_aa_idx,sbar_bb_idx];


%**************************************************************************
% Parameters
%**************************************************************************
per_p_year = 1;
use_p_year = 8;  %52/6 -> 6 week contracts
upp_usd    = 1*use_p_year/per_p_year;
upp_chy    = upp_usd; 

chi = 1;  %Matching tech parameter
sanc_usd_ch = 1; %Allow for some firms to be "blocked" in their search for dollars.
sanc_usd_bb = 1;

btau_ch_usd = 0;
btau_aa_usd = 0;
btau_bb_usd = 0;

btau_us_chy = 0;
btau_aa_chy = 0;
btau_bb_chy = 0;

%Tax on used USE
xtax_ch_usd = 0.0000;
xtax_aa_usd = 0.0000;
xtax_bb_usd = 0.0000;

xtax_us_chy = 0.0000;
xtax_aa_chy = 0.0000;
xtax_bb_chy = 0.0000;

%No new bond released in steady-state
dBusd  = 0;
dBchy  = 0;

%No changes in Y in steady-state
dYus = 0;
dYch = 0;
dYaa = 0;
dYbb = 0;

%Calibrated parameters
Bchy   = 1.471035591865715;
Busd   = 1.471035591865715;
vepsf  = 0.294493519281979;
phi    = 0.038183884875547;
r      = 0.005000000000000;
sige   = 1.000000000000000e-03;
a_us   = 0.718387079962791;
a_ch   = 0.718387079962791;
a_aa   = 0.718387079962791;
a_bb   = 0.718387079962791;
kap    = 0.01;
eta    = 1.001;%1.001;%/1.001;%1.01;                   %Elasiticty of subs. across good.1
Baa = 1.5;
Bbb = 1.5;
zrow = .6;
%Load calibrated parameters (if commented, uses values above)
load calib_params



BBbb_usd = 0;


%Fixed parameters
bet    = 0.96^(1/per_p_year); %Discount Factor
sig    = 1.00;                 %IES
alph   = 0.5;                 %Nash share in trade
tau    = 0.04;%0.045;               %Adj. cost of bonds: 20% change in holding costs 10 basis points ((10000*(.05/2)*(.2)^2) = 10)
taup   = 0*tau;               %Internalized adj cost?
vepst  = 0.01; 0.25;           %Matching elasticity in trade
omg    = 1;                   %frac of firm reoptimizing every period
Pnumer = 1.0;                 %Numeraire
Xus    = 0.95;                %US traders use of $
Xch    = 1 - Xus;             %CH traders use of $
%z      = .00;                   %RW traders exog use of $/eur

mu_us = 1/5;                 %Size US
mu_ch = 1/5;                 %Size CH
mu_aa = 1/2*(1-mu_us-mu_ch); %Size AA
mu_bb = 1/2*(1-mu_us-mu_ch); %Size BB

fixx = 0;                   %1 = fix X exogenously
fXaa = 0.8;                 %fixed value for Xa
fXbb = 0.8;                 %fixed value for Xb

Yus =  12/per_p_year*1;     %Endowment GDP
Ych =  12/per_p_year*1;     %Endowment GDP
Yaa =  12/per_p_year*1;     %Endowment GDP
Ybb =  12/per_p_year*1;     %Endowment GDP

phi_usg = 0;           %Government share US
phi_chg = 0;           %Government share EU
phi_aag = 0;           %Government share AA
phi_bbg = 0;           %Government share BB

%Put tarrif everwhere
trf        = 0*.4; %Common tariff
trf_cap    = 0*0.0001; 

if trf>0
    disp('WARNING: TARIF ON!')
    pause(1)
end

%Import taxes
tax_us_ch  = 0*trf;
tax_us_aa  = 0*trf;
tax_us_bb  = 0*trf;

tax_ch_us  = 0*trf;
tax_ch_aa  = 0*trf;
tax_ch_bb  = 0*trf;


tax_aa_us   = 0*trf;
tax_aa_ch   = 0*trf;
tax_aa_rowa = 0*trf;
tax_aa_rowb = 0*trf;

tax_bb_us   = 0*trf;
tax_bb_ch   = 0*trf;
tax_bb_rowa = 0*trf;
tax_bb_rowb = 0*trf;

%Export taxes
etax_ch_us  = 0*trf;
etax_aa_us  = 0*trf;
etax_bb_us  = 0*trf;

etax_us_ch  = 0*trf;
etax_aa_ch  = 0*trf;
etax_bb_ch  = 0*trf;


etax_us_aa   = 0*trf;
etax_ch_aa   = 0*trf;
etax_bb_aa   = 0*trf;

etax_us_bb   = 0*trf;
etax_ch_bb   = 0*trf;
etax_aa_bb   = 0*trf;


zusd_aa = 0*0.025;
zusd_bb = 0*0.025;
zchy_aa = 0*0.025;
zchy_bb = 0*0.025;


prime_up

%%
%**************************************************************************
% Solving steady-state
%**************************************************************************
options = optimset('fsolve');
options.Display = 'iter';
options.MaxFunEvals = 185000;
options.MaxIter = 5000;
options.TolX = 1e-16;
options.TolFun = 1e-19;
options.DerivativeCheck = 'on';
options.Jacobian = 'on';
options.FinDiffType = 'center';
log_idx = [];

%Initiali values
load input_files/xout xout
x0 = xout;

%put parameters in array
assemble_params;

obj = @(x) steady_residual(x,log_idx,ssargs{:})

[a,b]  = obj(x0);

[xout,fout,flag] = fsolve(obj,x0, options);
disp(['Max resid at x0: ' num2str2(max(abs(a)))]);
disp(['Max resid at xout: ' num2str2(max(abs(fout)))]);
xout(log_idx) = exp(xout(log_idx));
xfinal        = xout;

save_list = {'sig','phi_*','eta','Pnumer','bet','kap','r','alph','sige','*tau*','phi','veps*','*usd*', '*chy*', 'mu*', '*us', '*ch', '*aa', '*bb', '*rowa', '*rowb','*_p_*', 'xout', '*_steady','frac_ss','xspecial','xspecial_long','GDs','TSHRs','Xs','table_dat', 'log_idx','ny', 'CCs', 'fixx', 'fXaa','fXbb', '*tau*', 'chi', '*tax*', 'pol_mat', 'nx','ny', '*_l', '*_p','zrow','options','WIMPs', 'WEXPs','GDPs','save_list'};

%% ************************************************************************
% Find steady-states associated baseline calibration
%**************************************************************************
save_str = 'symbaseline'; %the baseline steady-state


steady_state_finder
disp_params
xspecial(end-1:end,:)
if save_me
    disp(' ');
    disp(['Saving as saved_results/steady_' save_str]);
    save(['saved_results/steady_' save_str], save_list{:});
end





