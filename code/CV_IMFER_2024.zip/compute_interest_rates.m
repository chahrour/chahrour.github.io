%Compute the interest rate differential between China and US in 90 bonds.

%{
clear mth qtr
url = 'https://fred.stlouisfed.org/';
c = fred(url);

%Main data series
mth.cni  = fetch(c,'IR3TTS01CNM156N');      % 90 day CN nominal rate
mth.usi  = fetch(c,'IR3TIB01USM156N');      % 90 day US nominate rate
mth.cncpi = fetch(c,'CHNCPALTT01IXNBM');    % CN CPI 
mth.uscpi = fetch(c,'CPIAUCSL');            % US CPI

save saved_results/uscn_interest_rates mth
%}

%% Compute interest rate differential
load saved_results/uscn_interest_rates.mat
date_range  = [200001,202212];

cni = ts_fred(mth.cni);

usi = ts_fred(mth.usi);

cncpi = ts_diff(ts_log(ts_fred(mth.cncpi)));
uscpi = ts_diff(ts_log(ts_fred(mth.uscpi)));
ni  =     [vect(usi,0,date_range)  , vect(cni,0,date_range)  ];
cpi = 1200*[vect(uscpi,0,date_range), vect(cncpi,0,date_range)];


ri = ni - cpi;

disp(['China-US interest differential: ' num2str(diff(nanmean(ri)))]);

